extends Node
## Transient optics only. Existing tap/boiler/weather owners supply every input.
const FILM := preload("res://shaders/v2_glass_film.gdshader")
const STEAM := preload("res://shaders/v2_bath_steam.gdshader")
const PERIOD := 0.1
var _world: Node3D
var _sources: Array=[]
var _rooms: Dictionary={}
var _surfaces: Array=[]
var _elapsed:=0.0
var _stopped:=false
var _drop_mesh: SphereMesh
var _drop_process: ParticleProcessMaterial
var _water: StandardMaterial3D

func configure(world: Node3D) -> bool:
	_world=world
	_water=MatLib.get_mat("water_clear").duplicate() as StandardMaterial3D
	_water.uv1_triplanar=false;_water.normal_enabled=true;_water.normal_scale=0.1
	_water.albedo_color=Color(0.72,0.86,0.94,0.48);_water.roughness=0.12
	_water.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
	_water.emission_enabled=true;_water.emission=Color(0.85,0.92,1.0);_water.emission_energy_multiplier=0.2
	_water.texture_filter=BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	_drop_mesh=SphereMesh.new();_drop_mesh.radius=0.003;_drop_mesh.height=0.035
	_drop_mesh.radial_segments=6;_drop_mesh.rings=2;_drop_mesh.material=_water
	_drop_process=ParticleProcessMaterial.new();_drop_process.direction=Vector3.DOWN
	_drop_process.spread=10.0;_drop_process.gravity=Vector3.DOWN*3.0
	_drop_process.initial_velocity_min=4.0;_drop_process.initial_velocity_max=4.5
	_drop_process.particle_flag_align_y=true
	_drop_process.emission_shape=ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	_drop_process.emission_sphere_radius=0.025
	for record: Dictionary in world.layout.spaces:
		if str(record.get("class",""))!="wet": continue
		_rooms[str(record.id)]={"humidity":0.0,"target":0.0,"record":record}
	for node: Node in world.adapter.root.find_children("*","Node3D",true,false):
		if node is not TapProp or node.fixture!="shower":continue
		var room: String=world.room_at_world(node.global_position+Vector3.UP*0.3)
		if not _rooms.has(room):push_error("Shower has no wet-room moisture binding: "+str(node.get_path()));return false
		var spray:=GPUParticles3D.new();spray.name="ShowerSprayCone"
		spray.amount=64;spray.lifetime=0.38;spray.fixed_fps=30;spray.local_coords=true
		spray.emitting=false;spray.visible=false;spray.process_material=_drop_process
		spray.draw_pass_1=_drop_mesh;spray.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		spray.gi_mode=GeometryInstance3D.GI_MODE_DISABLED
		spray.visibility_aabb=AABB(Vector3(-0.4,-1.85,-0.4),Vector3(0.8,1.95,0.8))
		var legacy: Node3D=node._stream.get_child(0);legacy.hide()
		node._stream.add_child(spray)
		var source: Dictionary={"tap":node,"room":room,"spray":spray,"legacy":legacy,"tail":0.0}
		_sources.append(source);node.flow_changed.connect(_sync_spray.bind(source));_sync_spray(source)
	var rooms_in_use: Dictionary={}
	for source: Dictionary in _sources:rooms_in_use[source.room]=true
	for room: String in rooms_in_use:_make_steam(_rooms[room])
	for record: Dictionary in world.layout.windows:
		var opening: Node3D=world.adapter.root.get_node_or_null(str(record.id))
		if opening==null:continue
		var pane:=opening.get_node_or_null("Glazing") as MeshInstance3D
		if pane==null:continue
		var room_record: Dictionary=world.adapter.root._space_by_id(str(record.space))
		if room_record.is_empty():continue
		var axis:=0 if str(record.axis)=="z" else 2
		var center:=Vector3((float(room_record.rect[0])+float(room_record.rect[2]))*0.5,0.0,(float(room_record.rect[1])+float(room_record.rect[3]))*0.5)
		var sign_out:=signf(world.adapter.root.to_local(pane.global_position)[axis]-center[axis])
		var outside:=Vector3.ZERO;outside[axis]=sign_out
		var exposed: bool=world.get_node("WeatherFX").exposed(pane.global_position+world.adapter.root.global_basis*outside*0.35)
		if not _bind_surface(pane,str(record.space),Vector2(float(record.width),float(record.height)),axis==0,sign_out,false,exposed):return false
	for surface: Node in get_tree().get_nodes_in_group("planar_mirror_surface"):
		if not world.is_ancestor_of(surface):continue
		var owner_node: Node=surface.get_parent()
		while owner_node!=null and not owner_node.has_method("mirror_surface"):owner_node=owner_node.get_parent()
		if owner_node==null:continue
		var room: String=world.room_at_world(owner_node.mirror_center()+owner_node.mirror_normal()*0.06)
		if not _bind_surface(surface,room,surface.get_meta("mirror_size"),false,-1.0,true,false):return false
	return not _sources.is_empty()

func _make_steam(state: Dictionary) -> void:
	if RenderingServer.get_current_rendering_method()!="forward_plus":return
	var rect: Array=state.record.rect
	var floor_y: float=_world.adapter.root.level_y[state.record.level]
	var volume:=FogVolume.new();volume.name="LocalSteam";volume.set_meta("space_id",str(state.record.id))
	volume.size=Vector3(float(rect[2])-float(rect[0])-0.08,2.65,float(rect[3])-float(rect[1])-0.08)
	volume.position=Vector3((float(rect[0])+float(rect[2]))*0.5,floor_y+1.45,(float(rect[1])+float(rect[3]))*0.5)
	var material:=ShaderMaterial.new();material.shader=STEAM
	material.set_shader_parameter("cloud_noise",preload("res://scripts/building/weather_noise.gd").load_volume())
	volume.material=material;volume.visible=false;_world.adapter.root.add_child(volume)
	state["steam"]=volume;state["material"]=material

func _bind_surface(pane: MeshInstance3D,room: String,size: Vector2,along_z: bool,outside_sign: float,mirror: bool,exposed: bool) -> bool:
	if pane.material_overlay!=null:push_error("Moisture refuses an occupied glass overlay: "+str(pane.get_path()));return false
	var film:=ShaderMaterial.new();film.shader=FILM;film.resource_name="water_clear_condensation_film"
	film.set_shader_parameter("albedo_tex",_water.albedo_texture)
	film.set_shader_parameter("rough_tex",_water.roughness_texture)
	film.set_shader_parameter("normal_tex",_water.normal_texture)
	film.set_shader_parameter("water_uv_scale",Vector2(_water.uv1_scale.x,_water.uv1_scale.y))
	film.set_shader_parameter("glass_size",size);film.set_shader_parameter("along_z",along_z)
	film.set_shader_parameter("outside_sign",outside_sign)
	_surfaces.append({"pane":pane,"room":room,"material":film,"mirror":mirror,"exposed":exposed,"inside":0.0,"outside":0.0})
	return true

func _sync_spray(source: Dictionary) -> void:
	if _stopped:return
	var amount: float=float(source.tap.get_flow_state().flow)
	var emitting:=amount>0.0001
	if source.spray.emitting!=emitting:source.spray.emitting=emitting
	if emitting:
		if source.spray.amount_ratio!=amount:source.spray.amount_ratio=amount
		source.tail=0.5;source.spray.visible=true

func _process(delta: float) -> void:
	if _stopped:return
	_elapsed+=delta
	if _elapsed<PERIOD:return
	var step:=_elapsed;_elapsed=0.0
	for state: Dictionary in _rooms.values():state.target=0.0
	for source: Dictionary in _sources:
		var flow: Dictionary=source.tap.get_flow_state()
		var amount:=float(flow.flow)
		var emitting:=amount>0.0001
		source.tail=0.5 if emitting else maxf(0.0,float(source.tail)-step)
		source.spray.visible=float(source.tail)>0.0
		var warm:=clampf((float(flow.temperature)-0.15)/0.5,0.0,1.0)*amount
		_rooms[source.room].target=maxf(float(_rooms[source.room].target),warm)
	var eye: Vector3=_world.player.camera.global_position
	for state: Dictionary in _rooms.values():
		state.humidity=move_toward(float(state.humidity),float(state.target),step*(0.035 if float(state.target)>float(state.humidity) else 0.012))
		if state.has("steam"):
			var visible_steam: bool=float(state.humidity)>0.003 and state.steam.global_position.distance_squared_to(eye)<144.0
			state.steam.visible=visible_steam
			state.material.set_shader_parameter("density_gain",float(state.humidity)*0.12 if visible_steam else 0.0)
	var weather: Dictionary=_world.get_node("WeatherFX")._live_conditions
	var rain:=clampf(float(weather.get("rain_intensity",1.0 if weather.get("wet",false) else 0.0)),0.0,1.0)
	for surface: Dictionary in _surfaces:
		var humidity: float=float(_rooms[surface.room].humidity) if _rooms.has(surface.room) else 0.0
		surface.inside=move_toward(float(surface.inside),humidity,step*0.05)
		surface.outside=move_toward(float(surface.outside),rain if surface.exposed else 0.0,step*(0.12 if rain>float(surface.outside) else 0.02))
		var film: ShaderMaterial=surface.material
		film.set_shader_parameter("inside_wet",0.0 if surface.mirror else float(surface.inside))
		film.set_shader_parameter("outside_wet",float(surface.inside) if surface.mirror else float(surface.outside))
		var pane: MeshInstance3D=surface.pane
		if surface.mirror:pane.set_meta("v2_condensation",float(surface.inside))
		var wanted: Material=film if pane.global_position.distance_squared_to(eye)<144.0 else null
		if pane.material_overlay!=wanted:pane.material_overlay=wanted

func shutdown() -> void:
	if _stopped:return
	_stopped=true;set_process(false)
	for surface: Dictionary in _surfaces:
		if is_instance_valid(surface.pane):
			if surface.pane.material_overlay==surface.material:surface.pane.material_overlay=null
			if surface.mirror:surface.pane.remove_meta("v2_condensation")
	for source: Dictionary in _sources:
		if is_instance_valid(source.tap) and source.tap.flow_changed.is_connected(_sync_spray.bind(source)):
			source.tap.flow_changed.disconnect(_sync_spray.bind(source))
		if is_instance_valid(source.legacy):source.legacy.show()
		if is_instance_valid(source.spray):source.spray.free()
	for state: Dictionary in _rooms.values():
		if state.has("steam") and is_instance_valid(state.steam):state.steam.free()
	_sources.clear();_rooms.clear();_surfaces.clear();_drop_mesh=null;_drop_process=null;_water=null

func _exit_tree() -> void:shutdown()
