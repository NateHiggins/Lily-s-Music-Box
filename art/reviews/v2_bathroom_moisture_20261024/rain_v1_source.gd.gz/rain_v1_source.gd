extends "res://tests/v2_bathroom_moisture_review.gd"
## Untimed actual-world rain and transparent-order controls, not access proof.
func _init() -> void:route_label="V2 RAIN FILM PROBE"

func _route() -> void:
	_moisture=world.bathroom_moisture
	for source: Dictionary in _moisture._sources:
		if source.tap.unit=="4B":
			player.global_position=source.tap.to_global(Vector3(0.0,0.02,-0.9));player.velocity=Vector3.ZERO;break
	for frame in 12:await get_tree().physics_frame
	await _rain_review()
	_moisture.set_process(false)
	var rows: Array=[];var chosen: Dictionary={};var distance:=INF
	for surface: Dictionary in _moisture._surfaces:
		if surface.mirror:continue
		var pane: MeshInstance3D=surface.pane
		rows.append({"path":str(pane.get_path()),"visible":pane.visible,"visible_in_tree":pane.is_visible_in_tree(),"bounds":str(pane.mesh.get_aabb()),"basis":str(pane.global_basis),"overlay_active":pane.material_overlay==surface.material,"inside":surface.inside,"outside":surface.outside,"axis_z":surface.material.get_shader_parameter("along_z"),"sign":surface.material.get_shader_parameter("outside_sign"),"room":surface.room,"exposed":surface.exposed})
		var d:=pane.global_position.distance_squared_to(player.camera.global_position)
		if surface.exposed and d<distance:chosen=surface;distance=d
	var output:=OS.get_environment("SHOT_DIR")
	if not _require(not chosen.is_empty(),"actual exposed pane available for transparent-order control"):return
	var pane: MeshInstance3D=chosen.pane
	var normal:=Vector3.ZERO;normal[0 if chosen.material.get_shader_parameter("along_z") else 2]=float(chosen.material.get_shader_parameter("outside_sign"))
	normal=(pane.global_basis*normal).normalized()
	var camera:=Camera3D.new();world.add_child(camera);camera.fov=55.0;camera.attributes=player.camera.attributes
	camera.global_position=pane.global_position-normal*0.85;camera.look_at(pane.global_position);camera.make_current()
	var images: Array[Image]=[]
	for mode: String in ["water_priority","without_film","positive_window_mask"]:
		if mode=="without_film":pane.material_overlay=null
		if mode=="positive_window_mask":
			var debug:=ShaderMaterial.new();debug.shader=Shader.new()
			debug.shader.code="shader_type spatial; render_mode unshaded,cull_disabled,depth_draw_never; void fragment(){ ALBEDO=vec3(1.0,0.0,1.0); ALPHA=0.65; }"
			debug.render_priority=1;pane.material_overlay=debug
		for frame in 12:await RenderingServer.frame_post_draw
		var image:=get_viewport().get_texture().get_image();image.save_png(output.path_join(mode+".png"));images.append(image)
	var differences: Array=[]
	for compare in [0,2]:
		var change:=0.0;var samples:=0
		for y in range(int(images[1].get_height()*0.25),int(images[1].get_height()*0.85),4):
			for x in range(0,int(images[1].get_width()*0.5),4):
				var a:=images[compare].get_pixel(x,y);var b:=images[1].get_pixel(x,y)
				change+=absf(a.r-b.r)+absf(a.g-b.g)+absf(a.b-b.b);samples+=3
		differences.append(change/samples)
	_require(float(differences[0])>0.003,"wet film makes a visible change against its removed control")
	_require(float(differences[1])>0.05,"positive mask proves the selected pane renders above refractive glass")
	pane.material_overlay=chosen.material;camera.free();player.camera.make_current();_moisture.set_process(true)
	FileAccess.open(output.path_join("rain_probe.json"),FileAccess.WRITE).store_string(JSON.stringify({"evidence_class":"INERT","scope":"Untimed weather injection, render-only eye placement and temporary optical positive/removed controls. No traversal or runtime qualification.","states":_states,"surfaces":rows,"chosen":str(pane.get_path()),"rgb_mean_differences":differences,"failures":failures},"\t"))
