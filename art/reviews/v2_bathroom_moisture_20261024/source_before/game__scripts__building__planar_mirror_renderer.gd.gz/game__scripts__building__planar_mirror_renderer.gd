class_name PlanarMirrorRenderer
extends Node
## One honest reflected view, lent to the mirror the player can actually see.
##
## A permanent SubViewport per mirror would render the building many extra
## times. This owner instead selects one close, front-facing surface,
## reflects the production camera through its live plane, and sleeps when
## no mirror is useful. Mirror glass is presentation layer 20, excluded from
## the borrowed camera, so reflection depth is exactly zero.

const MIRROR_LAYER := 1 << 19
const WIDTH := 384
const HEIGHT := 512
const MAX_DISTANCE_M := 4.5
const SHADER := preload("res://shaders/planar_mirror.gdshader")

var _main_camera: Camera3D
var _view: SubViewport
var _camera: Camera3D
var _active: Variant
var _material: ShaderMaterial
var _texture_bound := false
var _stopped := false
var _avatar: Node3D


func setup(main_camera: Camera3D,avatar: Node3D=null) -> void:
	name = "PlanarMirrorRenderer"
	_main_camera = main_camera
	_avatar=avatar
	process_priority = 100
	_view = SubViewport.new()
	_view.name = "ReflectedView"
	_view.size = Vector2i(WIDTH, HEIGHT)
	_view.transparent_bg = false
	_view.handle_input_locally = false
	_view.physics_object_picking = false
	_view.own_world_3d = false
	_view.world_3d = main_camera.get_world_3d()
	_view.render_target_clear_mode = SubViewport.CLEAR_MODE_ALWAYS
	_view.render_target_update_mode = SubViewport.UPDATE_DISABLED
	add_child(_view)

	_camera = Camera3D.new()
	_camera.name = "ReflectedCamera"
	_camera.fov = main_camera.fov
	_camera.far = main_camera.far
	_camera.cull_mask = main_camera.cull_mask & ~MIRROR_LAYER
	if _avatar!=null:_camera.cull_mask|=preload("res://scripts/player/doodle_player_avatar.gd").LAYER
	_camera.current = true
	_view.add_child(_camera)
	call_deferred("_bind_texture")
	set_meta("shared_world", true)
	set_meta("single_borrowed_view", true)
	set_meta("excluded_layer", MIRROR_LAYER)


func _bind_texture() -> void:
	if _stopped or not is_instance_valid(_view) or not is_inside_tree():
		return
	_material = ShaderMaterial.new()
	_material.shader = SHADER
	_material.set_shader_parameter("mirror_view", _view.get_texture())
	_texture_bound = true
	# A surface can win selection on the first process tick, before this deferred
	# texture exists. Complete that same binding instead of waiting for a switch
	# to some other mirror that may never happen.
	if is_instance_valid(_active):
		_active.set_live_mirror_material(_material)


func _process(_delta: float) -> void:
	if _stopped or not is_instance_valid(_main_camera) or not is_instance_valid(_camera):
		_sleep()
		return
	var candidate: Variant = _choose_mirror()
	if candidate != _active:
		if is_instance_valid(_active):
			_active.set_live_mirror_material(null)
		_active = candidate
		if is_instance_valid(_active) and _texture_bound:
			_active.set_live_mirror_material(_material)
	if not is_instance_valid(_active) or not _texture_bound:
		_sleep()
		return
	_pose_reflection(_active)
	if is_instance_valid(_avatar):_avatar.set_reflection_active(true)
	_view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	set_meta("active_unit", _active.unit)


func _choose_mirror() -> Variant:
	var best: Variant
	var best_score := -INF
	for node in get_tree().get_nodes_in_group("planar_mirror_surface"):
		# Find the surface's actual owner, independent of cabinet door nesting.
		var cabinet: Variant = node.get_parent()
		while cabinet!=null and not cabinet.has_method("mirror_surface"):
			cabinet=cabinet.get_parent()
		if cabinet == null or cabinet.mirror_surface()!=node:
			continue
		var center: Vector3 = cabinet.mirror_center()
		var offset := center - _main_camera.global_position
		var distance_m := offset.length()
		if distance_m < 0.10 or distance_m > MAX_DISTANCE_M:
			continue
		var toward := offset / distance_m
		var camera_facing := (-_main_camera.global_basis.z).dot(toward)
		var glass_facing: float = cabinet.mirror_normal().dot(-toward)
		if camera_facing < 0.18 or glass_facing < 0.12 \
				or not _main_camera.is_position_in_frustum(center):
			continue
		var score := camera_facing * 2.0 + glass_facing - distance_m * 0.16
		if score > best_score:
			best_score = score
			best = cabinet
	return best


func _pose_reflection(cabinet: Variant) -> void:
	var center: Vector3 = cabinet.mirror_center()
	var normal: Vector3 = cabinet.mirror_normal()
	var source := _main_camera.global_transform
	var reflected_position := _reflect_point(source.origin, center, normal)
	# The glass is a window, not a television showing the player's whole FOV.
	# Align the borrowed camera to its plane and use an asymmetric frustum so
	# each glass point sees precisely the ray from the reflected eye through it.
	var up: Vector3 = cabinet.mirror_surface().global_basis.y.normalized()
	_camera.global_transform = Transform3D(
			Basis.looking_at(normal, up), reflected_position)
	_camera.far = _main_camera.far
	var plane_distance := absf((reflected_position - center).dot(normal))
	var near_plane := maxf(.01, plane_distance + .005)
	var size: Vector2 = cabinet.mirror_surface().get_meta("mirror_size")
	_material.set_shader_parameter("glass_size", size)
	_view.size = Vector2i(roundi(HEIGHT * size.x / size.y), HEIGHT)
	var local_center := _camera.to_local(center)
	var scale_at_near := near_plane / maxf(.01, plane_distance)
	_camera.keep_aspect = Camera3D.KEEP_HEIGHT
	_camera.set_frustum(size.y * scale_at_near,
			Vector2(local_center.x, local_center.y) * scale_at_near,
			near_plane, _main_camera.far)


func _reflect_point(point: Vector3, origin: Vector3, normal: Vector3) -> Vector3:
	return point - normal * (2.0 * (point - origin).dot(normal))


func _reflect_vector(vector: Vector3, normal: Vector3) -> Vector3:
	return vector - normal * (2.0 * vector.dot(normal))


func _sleep() -> void:
	if is_instance_valid(_avatar):_avatar.set_reflection_active(false)
	if is_instance_valid(_view):
		_view.render_target_update_mode = SubViewport.UPDATE_DISABLED
	if is_instance_valid(_active):
		_active.set_live_mirror_material(null)
	_active = null
	set_meta("active_unit", "")


func active_mirror() -> Variant:
	return _active

func active_camera() -> Camera3D:
	if _stopped or not is_instance_valid(_active) or not is_instance_valid(_view) or _view.render_target_update_mode==SubViewport.UPDATE_DISABLED:return null
	return _camera if is_instance_valid(_camera) else null


func shutdown() -> void:
	_stopped = true
	set_process(false)
	_sleep()
	_texture_bound = false
	# The shader holds the viewport texture. Break that reference before the
	# world or its cabinets retire, including shutdown before deferred binding.
	if _material != null: _material.set_shader_parameter("mirror_view", null)
	_material = null
	_main_camera = null
	if is_instance_valid(_view): _view.world_3d = null


func _exit_tree() -> void:
	shutdown()
