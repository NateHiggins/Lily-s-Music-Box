class_name TapProp
extends FunctionalProp
## The building's complete water fixtures: an enameled apartment-house
## lavatory, a roll-rim iron kitchen sink, or a corner shower receptor.
##
## The marker owns a complete fixture in both apartments and the warehouse.
## The bathroom sink and shower use editable Blender castings with separate
## mechanical pivots; the kitchen retains its procedural visual assembly.
##
## Water carries no signal. These are ordinary 1920s fixtures on pipe:
## second-hand porcelain enamel, exposed nickel-plated brass work, and
## the small failures caused by hands, minerals and standing water.

const PORCELAIN := Color(0.88, 0.87, 0.82)
const ENAMEL := Color(0.77, 0.79, 0.76)
const NICKEL := Color(0.72, 0.71, 0.67)
const BRASS := Color(0.55, 0.42, 0.21)
const IRON := Color(0.17, 0.17, 0.16)
const LINEN := Color(0.78, 0.76, 0.68)
const SHOWER_DUCK := Color(0.73, 0.68, 0.54)
const MINERAL := Color(0.79, 0.76, 0.65)
const RUST := Color(0.39, 0.18, 0.085)

## Set from the marker before `_ready()`. `fixture` is semantic; `prop_type`
## remains sink/shower so the possession catalog and water graph stay stable.
var fixture := "bath_sink"
var unit := ""
## The 4B pilot proved the quiet fired-glaze plate under both room light and a
## grazing torch. Lavatories now share it; kitchen sinks and shower receptors
## retain their own enamel jobs instead of inheriting this fixture finish.
var porcelain_material_key := "porcelain_fixture"
var drain_side := 1
var compact_kitchen := false
var has_drainboard := true
var warehouse_curtain_open := false

var _bath_plug: Node3D
var _plug_hand: RefCounted
var _bath_chain: Node3D
var _bath_chain_instances: MultiMesh

var _hot := false
var _cold := false
var _valve_openings := Vector2.ZERO
var _held_valve := -1
signal manipulation_changed
var _stopper := false
var _water_level := 0.0
var drain_capacity := 1.0
var _boiler_temperature := 0.70
var _handles: Array[Node3D] = []
var _handle_turns: Array[float] = []
var _handle_wall_mounted: Array[bool] = []
var _stream: Node3D
var _basin_water: MeshInstance3D
var _water_empty_y := 0.0
var _water_full_y := 0.0
var _water_full_scale := Vector3.ONE
var _water: AudioStreamPlayer3D
var _tick: AudioStreamPlayer3D
var _curtain_closed: Node3D
var _curtain_gathered: Node3D
var _curtain_area: Area3D
var _curtain_is_open := false
var _curtain_hand: RefCounted


func warehouse_variants() -> Array[Dictionary]:
	# PropWarehouse sets prop_type before asking. Returning the two sink
	# silhouettes here and the shower only under its own kind avoids the old
	# 2 kinds x 3 variants duplication.
	if prop_type == "shower":
		return [
			{"label": "shower / curtain drawn",
				"properties": {"fixture": "shower", "unit": "3B"}},
			{"label": "shower / curtain gathered",
				"properties": {"fixture": "shower", "unit": "4B",
					"warehouse_curtain_open": true}},
		]
	return [
		{"label": "sink / lavatory — legacy granular porcelain",
				"properties": {"fixture": "bath_sink", "unit": "2B",
					"porcelain_material_key": "porcelain"}},
		{"label": "sink / lavatory — calm fired glaze",
				"properties": {"fixture": "bath_sink", "unit": "4B",
					"porcelain_material_key": "porcelain_fixture"}},
		{"label": "sink / roll-rim kitchen",
				"properties": {"fixture": "kitchen_sink", "unit": "2B",
					"has_drainboard": true}},
	]


func _build_visual() -> void:
	var fixed := Node3D.new()
	fixed.name = "StaticFixture"
	add_child(fixed)
	if fixture == "shower":
		_build_shower(fixed)
	elif fixture == "kitchen_sink":
		_build_kitchen_sink(fixed)
	else:
		_build_bath_sink(fixed)

	retexture(self, [
		[PORCELAIN, porcelain_material_key, Color(0.96, 0.94, 0.86), 0.72],
		[ENAMEL, "enamel", Color(0.78, 0.80, 0.75), 0.76],
		[NICKEL, "nickel_plated", Color(0.93, 0.91, 0.84), 0.42],
		[BRASS, "brass_dull", Color(0.78, 0.68, 0.44), 0.55],
		[IRON, "cast_iron", Color(0.33, 0.32, 0.29), 0.68],
		[LINEN, "linen", Color(0.88, 0.85, 0.75), 0.74],
		[SHOWER_DUCK, "shower_duck", Color(0.90, 0.84, 0.67), 0.58],
		[MINERAL, "mineral_scale", Color(0.91,0.88,0.78)],
		[RUST, "cast_iron", Color(0.48,0.20,0.10), 0.42],
	])
	if fixture == "shower":
		_finish_curtain_material()
	# Valves, stopper and water remain separate because the player and the
	# haunting move them. Everything else is fixed enough to merge.
	merge_static(fixed)
	# Each valve still turns independently. Its stem, escutcheon, cross and
	# cap do not; merging inside the pivot preserves that verb and removes the
	# repeated primitive cost across sixty-six fixtures.
	for handle in _handles:
		merge_static(handle)
	if _curtain_closed:
		merge_static(_curtain_closed)
	if _curtain_gathered:
		merge_static(_curtain_gathered)
	if fixture == "shower":
		set_curtain_open(warehouse_curtain_open)

	_water = make_emitter(
			"shower_water" if fixture == "shower" else "sink_water",
			-21.0, true)
	if _water:
		_water.stream_paused = true
	_tick = make_emitter("tick", -27.0)


## How far a wall valve's mounting plate sits IN FRONT of the splashback it
## comes through. Negative because the escutcheon reaches ~15 mm rearward, so
## a small forward offset still buries its back edge in the enamel and the
## fitting reads as penetrating rather than floating.
##
## This is the kitchen sink's long-standing relationship, promoted to a shared
## constant. It was `d * 0.5 - 0.035` against a face at `d * 0.5 - 0.0215`,
## i.e. exactly -0.0135, and it was correct there while the lavatory used an
## unrelated literal.
const VALVE_SEAT_DZ := -0.0135

## Recorded per fixture so a test can check the geometry instead of a boolean.
var _panel_front_z := 0.0
var _valve_mount_z := 0.0


func _build_bath_sink(parent: Node3D) -> void:
	# Blender owns the complete casting and plumbing; this owner still drives
	# the existing water graph, service checks, sounds and independent valves.
	var model := preload("res://assets/props/bath_lavatory.glb").instantiate() as Node3D
	parent.add_child(model)
	_skin_fixture_model(model)
	for handle_name in ["HotValve", "ColdValve"]:
		var handle := model.find_child(handle_name, true, false) as Node3D
		handle.reparent(self)
		_handles.append(handle)
		_handle_turns.append(0.0)
		_handle_wall_mounted.append(true)
	_bath_plug = model.find_child("Stopper", true, false) as Node3D
	_bath_plug.reparent(self)
	_bath_chain = model.find_child("StopperChain", true, false) as Node3D
	_bath_chain.reparent(self)
	# All links share one draw; only their transforms change with the plug.
	var links := _bath_chain.get_children()
	_bath_chain_instances = MultiMesh.new()
	_bath_chain_instances.transform_format = MultiMesh.TRANSFORM_3D
	_bath_chain_instances.mesh = (links[0] as MeshInstance3D).mesh
	_bath_chain_instances.instance_count = links.size()
	var chain_draw := MultiMeshInstance3D.new()
	chain_draw.multimesh = _bath_chain_instances
	chain_draw.material_override = MatLib.get_mat("nickel_plated")
	for link in links:
		_bath_chain.remove_child(link)
		link.queue_free()
	_bath_chain.add_child(chain_draw)
	_panel_front_z = .135
	_valve_mount_z = _panel_front_z + VALVE_SEAT_DZ
	var outlet := Vector3(0, .885, -.075)
	var marker := Marker3D.new()
	marker.name = "SpoutOutlet"
	marker.position = outlet
	add_child(marker)
	_stream = _make_stream(outlet + Vector3(0, -.018, 0), .185, .007)
	_water_empty_y = .694
	_water_full_y = .765
	_basin_water = _make_water_surface(
			Vector3(0, _water_empty_y, -.02), Vector2(.39, .25), true)
	_update_bath_plug(1.0)


func _skin_fixture_model(node: Node) -> void:
	if node is MeshInstance3D:
		for surface in node.mesh.get_surface_count():
			var source: Material = node.mesh.surface_get_material(surface)
			if source == null: continue
			var key := source.resource_name
			if key == "porcelain_fixture": key = porcelain_material_key
			var material := MatLib.get_mat(key)
			if key == "shower_duck":
				material = material.duplicate() as StandardMaterial3D
				material.normal_scale = .14
			node.set_surface_override_material(surface, material)
	for child in node.get_children(): _skin_fixture_model(child)


func _update_bath_plug(delta: float) -> void:
	if _bath_plug == null: return
	# A lifted plug clears the throat. The ball chain follows its eye while
	# the far end remains on the back's attachment, with slack between them.
	var seat := Vector3(0, .696, -.02)
	var parked := Vector3(.115, .705, .005)
	if _plug_hand == null:
		_bath_plug.position = _bath_plug.position.move_toward(
				seat if _stopper else parked, delta * .45)
	var start := _bath_plug.position + Vector3(0, .018, 0)
	var finish := Vector3(.04, .898, .082)
	for index in _bath_chain_instances.instance_count:
		var t := float(index) / float(_bath_chain_instances.instance_count-1)
		var at := start.lerp(finish, t) - Vector3.UP * sin(t * PI) * .045
		_bath_chain_instances.set_instance_transform(index, Transform3D(Basis.IDENTITY, at))


func kitchen_rim_height() -> float:
	return .905 if compact_kitchen else .90


func _build_kitchen_sink(parent: Node3D) -> void:
	# Mott's smallest cheap roll-rim sink was 24 x 18 x 6 inches. The full
	# size fits the standard run; 4B keeps its existing 500 mm opening and
	# separate rack rather than pretending the hob has room for a board.
	var w := 0.50 if compact_kitchen else 0.61
	var d := 0.38 if compact_kitchen else 0.46
	var top := kitchen_rim_height()
	_open_rect_basin(parent, Vector3(0, top, 0), w, d, 0.15, ENAMEL)
	var panel_d := 0.035
	var panel_c := d * 0.5 - 0.004
	_box_on(parent, Vector3(w + 0.03, 0.16, panel_d),
			Vector3(0, top + 0.075, panel_c), ENAMEL)
	_panel_front_z = panel_c - panel_d * 0.5
	# Centre the valve penetrations inside the 160 mm integral back. At +170 mm
	# the escutcheons floated above its top edge; +110 mm keeps each mounting
	# plate visibly borne by enamel while leaving hand clearance over the rim.
	var mount_y := top + 0.11
	_valve_mount_z = _panel_front_z + VALVE_SEAT_DZ
	_build_pair_taps(Vector3(0, mount_y, _valve_mount_z), 0.19, true)
	# A bridge joins the two wall valves and gives the central riser a
	# mechanical origin. Without it the gooseneck was just a nickel pole
	# descending from nowhere when the player stood square to the run.
	_tube_between(parent, Vector3(-0.095, mount_y, d * 0.5 - 0.055),
			Vector3(0.095, mount_y, d * 0.5 - 0.055), 0.011, NICKEL)
	var bridge_collar := _cyl_on(parent, 0.022, 0.022, 0.035,
			Vector3(0, mount_y, d * 0.5 - 0.073), NICKEL)
	bridge_collar.rotation_degrees.x = 90.0
	_build_spout(parent, Vector3(0, mount_y, d * 0.5 - 0.055),
			Vector3(0, top + 0.13, 0.015), true)
	_build_stopper(Vector3(0, top - 0.135, 0.01))
	if has_drainboard:
		_build_drainboard(parent, w, d, top)
	_add_use_wear(parent, Vector3(-w * 0.35, top + 0.004, -d * 0.37), true)
	_stream = _make_stream(Vector3(0, top + 0.115, 0.015), 0.245, 0.008)
	_water_empty_y = top - 0.137
	_water_full_y = top - 0.025
	_basin_water = _make_water_surface(Vector3(0, _water_empty_y, 0),
			Vector2(w - 0.09, d - 0.09))


func _build_shower(parent: Node3D) -> void:
	var model := preload("res://assets/props/bath_shower.glb").instantiate() as Node3D
	parent.add_child(model)
	_skin_fixture_model(model)
	for handle_name in ["HotValve", "ColdValve"]:
		var handle := model.find_child(handle_name, true, false) as Node3D
		handle.reparent(self)
		_handles.append(handle)
		_handle_turns.append(0.0)
		_handle_wall_mounted.append(true)
	_curtain_closed = model.find_child("CurtainDrawn", true, false) as Node3D
	_curtain_gathered = model.find_child("CurtainGathered", true, false) as Node3D
	_curtain_closed.reparent(self)
	_curtain_gathered.reparent(self)
	_curtain_area = Area3D.new()
	_curtain_area.name = "CurtainInteraction"
	_curtain_area.set_meta("shower_curtain", true)
	var shape_node := CollisionShape3D.new()
	shape_node.name = "CollisionShape3D"
	var shape := BoxShape3D.new()
	shape.size = Vector3(.68, 1.55, .10)
	shape_node.shape = shape
	shape_node.position = Vector3(0, 1.18, -.31)
	_curtain_area.add_child(shape_node)
	add_child(_curtain_area)
	_build_stopper(Vector3(0, .015, .01))
	_stream = _make_stream(Vector3(0, 1.82, .18), 1.71, .017)
	_water_empty_y = .024
	_water_full_y = .105
	_basin_water = _make_water_surface(Vector3(0, _water_empty_y, 0), Vector2(.62, .62))


func _build_shower_curtain(parent: Node3D) -> void:
	# A ceiling-hung U rod encloses the three exposed edges regardless of
	# which room corner receives the receptor. The previous front bar and five
	# rigid boxes left a 200 mm gap and could never close around a bather.
	var rod_y := 2.02
	var left_rear := Vector3(-0.34, rod_y, 0.32)
	var left_front := Vector3(-0.34, rod_y, -0.32)
	var right_front := Vector3(0.34, rod_y, -0.32)
	var right_rear := Vector3(0.34, rod_y, 0.32)
	_tube_between(parent, left_rear, left_front, 0.009, NICKEL)
	_tube_between(parent, left_front, right_front, 0.009, NICKEL)
	_tube_between(parent, right_front, right_rear, 0.009, NICKEL)
	# Two wall eyes make the rod construction legible instead of allowing a
	# chrome U to end mysteriously inside the tile.
	for x in [-0.34, 0.34]:
		var eye := make_ring(0.030, 0.007, Vector3(x, rod_y, 0.338),
				NICKEL, 0.38, 0.72, parent)
		eye.rotation_degrees.x = 90.0

	_curtain_closed = Node3D.new()
	_curtain_closed.name = "CurtainDrawn"
	add_child(_curtain_closed)
	# One continuous rubberized-cotton curtain wraps both returns and the
	# front. It is three surfaces so each run can carry folds normal to itself,
	# but merges to one textured draw after construction.
	_make_curtain_panel(_curtain_closed, left_rear, left_front, 5)
	_make_curtain_panel(_curtain_closed, left_front, right_front, 7)
	_make_curtain_panel(_curtain_closed, right_front, right_rear, 5)
	_add_curtain_rings(_curtain_closed, left_rear, left_front, 4, false)
	_add_curtain_rings(_curtain_closed, left_front, right_front, 7, true)
	_add_curtain_rings(_curtain_closed, right_front, right_rear, 4, false)

	_curtain_gathered = Node3D.new()
	_curtain_gathered.name = "CurtainGathered"
	add_child(_curtain_gathered)
	# The open state is a deliberately thick stack at the back return. This
	# silhouette holds the full cloth volume without simulated drape or a flat
	# panel shrinking implausibly into nothing.
	_make_curtain_panel(_curtain_gathered,
			Vector3(0.245, rod_y, 0.305), right_rear, 8)
	_add_curtain_rings(_curtain_gathered,
			Vector3(0.245, rod_y, 0.305), right_rear, 7, true)

	_curtain_area = Area3D.new()
	_curtain_area.name = "CurtainInteraction"
	_curtain_area.set_meta("shower_curtain", true)
	var shape_node := CollisionShape3D.new()
	shape_node.name = "CollisionShape3D"
	var shape := BoxShape3D.new()
	shape.size = Vector3(0.68, 1.55, 0.10)
	shape_node.shape = shape
	shape_node.position = Vector3(0, 1.18, -0.31)
	_curtain_area.add_child(shape_node)
	add_child(_curtain_area)


func _make_curtain_panel(parent: Node3D, a: Vector3, b: Vector3,
		folds: int) -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var span := b - a
	var horizontal := Vector3(span.x, 0, span.z).normalized()
	var normal := Vector3(-horizontal.z, 0, horizontal.x)
	var segments := maxi(8, folds * 4)
	for i in segments:
		var u0 := float(i) / segments
		var u1 := float(i + 1) / segments
		var wave0 := sin(u0 * folds * TAU) * 0.040
		var wave1 := sin(u1 * folds * TAU) * 0.040
		var top0 := a.lerp(b, u0) + normal * wave0 + Vector3(0, -0.055, 0)
		var top1 := a.lerp(b, u1) + normal * wave1 + Vector3(0, -0.055, 0)
		# A slightly stronger wave and uneven hem keep the cloth from reading
		# as architectural panelling while remaining deterministic and static.
		var low0 := a.lerp(b, u0) + normal * wave0 * 1.35 \
				+ Vector3(0, -1.62 + sin(u0 * PI * 5.0) * 0.012, 0)
		var low1 := a.lerp(b, u1) + normal * wave1 * 1.35 \
				+ Vector3(0, -1.62 + sin(u1 * PI * 5.0) * 0.012, 0)
		_add_curtain_quad(st, top0, top1, low1, low0, normal, u0, u1)
	var mesh := MeshInstance3D.new()
	mesh.name = "RubberizedDuck"
	mesh.mesh = st.commit()
	mesh.material_override = _pmat(SHOWER_DUCK)
	parent.add_child(mesh)


func _finish_curtain_material() -> void:
	# The rejected linen_aged source contained a real fold, so tiling it printed
	# a horizontal band down every curtain. The approved library linen is a
	# homogeneous weave and may safely project at physical scale. Mapping its
	# square once over the full tall drop instead stretched the weave into moire.
	var cloth := MatLib.get_mat("shower_duck",
			Color(0.90, 0.84, 0.67), 0.58).duplicate() as StandardMaterial3D
	cloth.uv1_triplanar = true
	cloth.normal_scale = 0.14
	for node in find_children("RubberizedDuck", "MeshInstance3D", true, false):
		(node as MeshInstance3D).material_override = cloth


func _add_curtain_quad(st: SurfaceTool, top0: Vector3, top1: Vector3,
		low1: Vector3, low0: Vector3, normal: Vector3,
		u0: float, u1: float) -> void:
	_add_curtain_triangle(st, top0, top1, low1, normal,
			Vector2(u0, 0), Vector2(u1, 0), Vector2(u1, 1))
	_add_curtain_triangle(st, top0, low1, low0, normal,
			Vector2(u0, 0), Vector2(u1, 1), Vector2(u0, 1))
	# Duplicate the winding: a curtain must be visible from the receptor and
	# the room without requiring a special two-sided runtime material.
	_add_curtain_triangle(st, low1, top1, top0, -normal,
			Vector2(u1, 1), Vector2(u1, 0), Vector2(u0, 0))
	_add_curtain_triangle(st, low0, low1, top0, -normal,
			Vector2(u0, 1), Vector2(u1, 1), Vector2(u0, 0))


func _add_curtain_triangle(st: SurfaceTool, a: Vector3, b: Vector3,
		c: Vector3, normal: Vector3, uv_a: Vector2, uv_b: Vector2,
		uv_c: Vector2) -> void:
	for pair in [[a, uv_a], [b, uv_b], [c, uv_c]]:
		st.set_normal(normal)
		st.set_uv(pair[1])
		st.add_vertex(pair[0])


func _add_curtain_rings(parent: Node3D, a: Vector3, b: Vector3,
		count: int, rod_along_x: bool) -> void:
	for i in count:
		var t := (float(i) + 0.5) / count
		var ring := make_ring(0.022, 0.0035,
				a.lerp(b, t) + Vector3(0, -0.025, 0), NICKEL,
				0.34, 0.70, parent)
		ring.rotation_degrees.z = 90.0 if rod_along_x else 0.0
		if not rod_along_x:
			ring.rotation_degrees.x = 90.0


func _tapered_pedestal(parent: Node3D, top: float) -> void:
	_cyl_on(parent, 0.11, 0.18, 0.08, Vector3(0, 0.04, 0.06), PORCELAIN)
	_cyl_on(parent, 0.085, 0.11, top - 0.17,
			Vector3(0, (top - 0.17) * 0.5 + 0.08, 0.06), PORCELAIN)
	_cyl_on(parent, 0.20, 0.085, 0.09,
			Vector3(0, top - 0.045, 0.03), PORCELAIN)


func _open_oval_basin(parent: Node3D, at: Vector3, w: float, d: float,
		depth: float, color: Color) -> void:
	# One rolled edge, four inward-canted walls and a small elliptical floor
	# make the cavity. A second torus was tried at the bowl floor; viewed from
	# the bathroom door it read as a complete smaller sink laid over this one.
	# Real lavatories have one rim. The enamel sides carry the eye down instead.
	var outer := make_ring(w * 0.5, 0.025, at, color, 0.46, 0.0, parent)
	outer.name = "RolledRim"
	# A rolled glazed edge is read by its highlight. Twenty segments were enough
	# for the silhouette but broke that highlight into visible flats at hand
	# distance. More vertices cost no draw call after merge_static.
	var rolled_rim := outer.mesh as TorusMesh
	# TorusMesh exposes the sweep and tube axes separately. Leaving either at
	# twenty preserves a scalloped shadow even when the visible silhouette is
	# smooth, so both are stated rather than trusting a version default.
	rolled_rim.rings = 48
	rolled_rim.ring_segments = 48
	outer.scale.z = d / w
	_make_oval_bowl(parent, at, w, d, depth, color)


func _make_oval_bowl(parent: Node3D, at: Vector3, w: float, d: float,
		depth: float, color: Color) -> void:
	# A continuous low-poly enamel surface matters more here than extra
	# segments: disconnected boxes leave black seams under the bathroom's
	# grazing practical and make the floor look like a loose second object.
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	# Thirty-two is enough to outline a bowl but not to carry a close practical
	# smoothly across its shallow concave wall. This remains one indexed surface.
	var segments := 96
	# Meet the torus at its measured inner ellipse, then sit just below it.
	# The old top ring sat 2 mm outside the torus's inner edge in X. It was not
	# the starburst — isolation proved that was the pedestal cap — but two
	# overlapping glazed skins are still the wrong joint.
	var rim_inner_x := w * 0.5 - 0.025
	var rim_inner_z := rim_inner_x * d / w
	var rings := [
		Vector3(rim_inner_x - 0.001, -0.007, rim_inner_z - 0.001),
		Vector3(w * 0.5 - 0.058, -depth * 0.55, d * 0.5 - 0.058),
		Vector3(w * 0.5 - 0.120, -depth + 0.018, d * 0.5 - 0.115),
	]
	for row in 2:
		for i in segments:
			var u0 := float(i) / segments
			var u1 := float(i + 1) / segments
			var a0 := u0 * TAU
			var a1 := u1 * TAU
			var upper: Vector3 = rings[row]
			var lower: Vector3 = rings[row + 1]
			var p00 := Vector3(cos(a0) * upper.x, upper.y,
					sin(a0) * upper.z)
			var p01 := Vector3(cos(a1) * upper.x, upper.y,
					sin(a1) * upper.z)
			var p10 := Vector3(cos(a0) * lower.x, lower.y,
					sin(a0) * lower.z)
			var p11 := Vector3(cos(a1) * lower.x, lower.y,
					sin(a1) * lower.z)
			# This is the INSIDE of a vessel. The old normals pointed outward like
			# an exterior shell; the glaze highlight belongs on the inward face.
			var n0 := Vector3(-cos(a0) * 0.62, 1.0,
					-sin(a0) * 0.62).normalized()
			var n1 := Vector3(-cos(a1) * 0.62, 1.0,
					-sin(a1) * 0.62).normalized()
			# Concave faces use the opposite winding from an outside shell.
			# Explicit normals keep the enamel lit upward/inward rather than
			# inheriting the reversed triangle's downward normal.
			_bowl_vertex(st, p00, Vector2(u0, float(row) * 0.42), n0)
			_bowl_vertex(st, p11, Vector2(u1, float(row + 1) * 0.42), n1)
			_bowl_vertex(st, p10, Vector2(u0, float(row + 1) * 0.42), n0)
			_bowl_vertex(st, p00, Vector2(u0, float(row) * 0.42), n0)
			_bowl_vertex(st, p01, Vector2(u1, float(row) * 0.42), n1)
			_bowl_vertex(st, p11, Vector2(u1, float(row + 1) * 0.42), n1)
	var floor_ring: Vector3 = rings[2]
	for i in segments:
		var u0 := float(i) / segments
		var u1 := float(i + 1) / segments
		var a0 := u0 * TAU
		var a1 := u1 * TAU
		var edge0 := Vector3(cos(a0) * floor_ring.x, floor_ring.y,
				sin(a0) * floor_ring.z)
		var edge1 := Vector3(cos(a1) * floor_ring.x, floor_ring.y,
				sin(a1) * floor_ring.z)
		_bowl_vertex(st, edge0,
				Vector2(0.5 + cos(a0) * 0.5, 0.5 + sin(a0) * 0.5),
				Vector3.UP)
		_bowl_vertex(st, Vector3(0, floor_ring.y, 0), Vector2(0.5, 0.5),
				Vector3.UP)
		_bowl_vertex(st, edge1,
				Vector2(0.5 + cos(a1) * 0.5, 0.5 + sin(a1) * 0.5),
				Vector3.UP)
	st.generate_tangents()
	st.index()
	var bowl := MeshInstance3D.new()
	bowl.name = "ContinuousBowl"
	bowl.mesh = st.commit()
	bowl.position = at
	bowl.material_override = _pmat(color, 0.46, 0.0)
	parent.add_child(bowl)


func _bowl_vertex(st: SurfaceTool, point: Vector3, uv: Vector2,
		normal: Vector3) -> void:
	st.set_normal(normal)
	st.set_uv(uv)
	st.add_vertex(point)


func _open_rect_basin(parent: Node3D, at: Vector3, w: float, d: float,
		depth: float, color: Color) -> void:
	var lip := 0.035
	_box_on(parent, Vector3(w + lip, 0.025, lip),
			at + Vector3(0, 0, -d * 0.5), color)
	_box_on(parent, Vector3(w + lip, 0.025, lip),
			at + Vector3(0, 0, d * 0.5), color)
	_box_on(parent, Vector3(lip, 0.025, d),
			at + Vector3(-w * 0.5, 0, 0), color)
	_box_on(parent, Vector3(lip, 0.025, d),
			at + Vector3(w * 0.5, 0, 0), color)
	for x in [-1.0, 1.0]:
		_box_on(parent, Vector3(0.028, depth, d - 0.05),
				at + Vector3(x * (w * 0.5 - 0.026), -depth * 0.5, 0), color)
	for z in [-1.0, 1.0]:
		_box_on(parent, Vector3(w - 0.05, depth, 0.028),
				at + Vector3(0, -depth * 0.5, z * (d * 0.5 - 0.026)), color)
	_box_on(parent, Vector3(w - 0.07, 0.018, d - 0.07),
			at + Vector3(0, -depth + 0.01, 0), color)
	_build_drain(parent, at + Vector3(0, -depth + 0.021, 0))


func _build_drainboard(parent: Node3D, basin_w: float, d: float,
		top: float) -> void:
	var side := 1.0 if drain_side >= 0 else -1.0
	var board_w := 0.42
	var center_x := side * (basin_w * 0.5 + board_w * 0.5)
	_box_on(parent, Vector3(board_w, 0.026, d),
			Vector3(center_x, top - 0.003, 0), ENAMEL)
	# Raised draining ribs pitch toward the bowl. They are geometry because
	# a flat normal map disappears under the kitchen's grazing night light.
	for i in 7:
		var x := center_x + side * (-0.15 + i * 0.05)
		_box_on(parent, Vector3(0.010, 0.011, d - 0.075),
				Vector3(x, top + 0.014, 0), ENAMEL)


func _build_pair_taps(at: Vector3, separation: float,
		wall_mounted: bool) -> void:
	for i in 2:
		var pivot := Node3D.new()
		pivot.name = "HotValve" if i == 0 else "ColdValve"
		pivot.position = at + Vector3((-0.5 + i) * separation, 0, 0)
		add_child(pivot)
		_handles.append(pivot)
		_handle_turns.append(0.0)
		_handle_wall_mounted.append(wall_mounted)
		if wall_mounted:
			# These valves pierce the integral vertical back, so their stems
			# point out of it and the cross sits in the visible X/Y plane.
			# The earlier deck-mounted handle was exactly ninety degrees wrong:
			# a chrome cup with one dark bar was all the doorway could see.
			var stem := _cyl_on(pivot, 0.023, 0.027, 0.060,
					Vector3(0, 0, -0.018), NICKEL)
			stem.rotation_degrees.x = 90.0
			var escutcheon := make_ring(0.034, 0.007,
					Vector3(0, 0, 0.008), NICKEL, 0.38, 0.65, pivot)
			escutcheon.rotation_degrees.x = 90.0
			_box_on(pivot, Vector3(0.092, 0.014, 0.014),
					Vector3(0, 0, -0.052), NICKEL)
			_box_on(pivot, Vector3(0.014, 0.092, 0.014),
					Vector3(0, 0, -0.052), NICKEL)
			var cap := _cyl_on(pivot, 0.013, 0.013, 0.014,
					Vector3(0, 0, -0.060), BRASS)
			cap.rotation_degrees.x = 90.0
		else:
			_cyl_on(pivot, 0.023, 0.027, 0.058, Vector3.ZERO, NICKEL)
			for k in 2:
				var arm := _box_on(pivot, Vector3(0.085, 0.014, 0.014),
						Vector3(0, 0.035, 0), NICKEL)
				arm.rotation.y = PI * 0.5 * k
			_cyl_on(pivot, 0.012, 0.012, 0.012,
					Vector3(0, 0.035, 0), BRASS)


func _build_spout(parent: Node3D, base: Vector3, outlet: Vector3,
		high_arc := false) -> void:
	if high_arc:
		# Five short chords read as a bent gooseneck at this scale. A single
		# diagonal from back to drain read as a loose rod leaning in the bowl.
		var points := [
			base,
			base + Vector3(0, 0.12, 0),
			Vector3(0, base.y + 0.19, lerpf(base.z, outlet.z, 0.28)),
			Vector3(0, base.y + 0.21, lerpf(base.z, outlet.z, 0.62)),
			Vector3(0, outlet.y + 0.07, outlet.z),
			outlet,
		]
		for i in points.size() - 1:
			_tube_between(parent, points[i], points[i + 1], 0.012, NICKEL)
	else:
		# Compact bridge-faucet swan neck. Four short bends make a recognisable
		# cast fitting; the former two-segment diagonal looked like bent wire.
		var points := [
			base,
			base + Vector3(0, 0.060, -0.018),
			base + Vector3(0, 0.090, -0.070),
			Vector3(0, outlet.y + 0.055, outlet.z),
			outlet,
		]
		for i in points.size() - 1:
			_tube_between(parent, points[i], points[i + 1], 0.013, NICKEL)
	var mouth_r := 0.019 if high_arc else 0.014
	var mouth := _cyl_on(parent, mouth_r, mouth_r * 0.82, 0.032,
			outlet, NICKEL)
	mouth.rotation_degrees.x = 90.0
	var outlet_marker := Marker3D.new()
	outlet_marker.name = "SpoutOutlet"
	outlet_marker.position = outlet
	add_child(outlet_marker)


func _build_exposed_waste(parent: Node3D, drain_at: Vector3) -> void:
	_tube_between(parent, drain_at, Vector3(0, 0.42, drain_at.z), 0.018, NICKEL)
	# The U is deliberately legible from the doorway; exposed supplies and
	# trap are part of this inexpensive fixture's period/class identity.
	var trap := make_ring(0.075, 0.014, Vector3(0, 0.40, 0.06), NICKEL,
			0.35, 0.75, parent)
	trap.rotation_degrees.x = 90.0
	for x in [-0.09, 0.09]:
		_tube_between(parent, Vector3(x, 0.03, 0.18),
				Vector3(x, 0.76, 0.18), 0.007, NICKEL)


func _build_drain(parent: Node3D, at: Vector3) -> void:
	_cyl_on(parent, 0.041, 0.041, 0.006, at, NICKEL)
	for x in [-0.022, 0.0, 0.022]:
		_box_on(parent, Vector3(0.007, 0.004, 0.065),
				at + Vector3(x, 0.005, 0), IRON)


func _build_stopper(at: Vector3) -> void:
	var stopper := Node3D.new()
	stopper.name = "Stopper"
	stopper.position = at
	add_child(stopper)
	_cyl_on(stopper, 0.036, 0.036, 0.010, Vector3.ZERO, NICKEL)


func _add_use_wear(parent: Node3D, at: Vector3, wet: bool) -> void:
	# These marks are placed where water pools and hands abrade. A tiled
	# texture would repeat them across clean vertical enamel as wallpaper.
	# Mineral scale is a film on the glaze, not a fitted brown puck. The old
	# three-millimetre plate was thick enough to cast its own shadow and became
	# the loudest feature on an otherwise clean lavatory.
	var mineral := _cyl_on(parent, 0.035, 0.050, 0.0008,
			at, MINERAL, 0.88, 0.0)
	mineral.scale.z = 0.48
	if wet:
		var rust := _cyl_on(parent, 0.018, 0.031, 0.003,
				at + Vector3(0.05, 0.003, -0.025), RUST, 0.83, 0.0)
		rust.scale.z = 1.7


func _make_stream(from: Vector3, drop: float, radius: float) -> Node3D:
	var holder := Node3D.new()
	holder.name = "WaterStream"
	holder.position = from
	holder.visible = false
	add_child(holder)
	var mat := MatLib.get_mat("water_clear").duplicate() as StandardMaterial3D
	mat.albedo_color = Color(0.68, 0.80, 0.84, 0.36)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.roughness = 0.08
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	var column := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = radius
	cyl.bottom_radius = radius * 0.54
	cyl.height = drop
	cyl.radial_segments = 7
	column.mesh = cyl
	column.material_override = mat
	column.position.y = -drop * 0.5
	column.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	holder.add_child(column)
	return holder


func _make_water_surface(at: Vector3, size: Vector2,
		oval := false) -> MeshInstance3D:
	var tint := Color(0.59, 0.73, 0.78, 0.18)
	var water: MeshInstance3D
	if oval:
		water = _cyl_on(self, size.x * 0.5, size.x * 0.5, 0.004, at, tint)
		water.scale.z = size.y / size.x
	else:
		water = make_box(Vector3(size.x, 0.004, size.y), at, tint)
	var mat := MatLib.get_mat("water_clear", tint).duplicate() as StandardMaterial3D
	water.material_override = mat
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.roughness = 0.08
	water.visible = false
	water.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_water_full_scale = water.scale
	return water


func _box_on(parent: Node3D, size: Vector3, at: Vector3,
		color: Color) -> MeshInstance3D:
	var node := make_box(size, at, color)
	remove_child(node)
	parent.add_child(node)
	# `at` is in the requested parent's local space. Subtracting the parent's
	# root-space position here made every cross-handle arm fall back near the
	# prop origin while its cylinder stem remained correctly on the valve.
	node.position = at
	return node


func _cyl_on(parent: Node3D, rt: float, rb: float, height: float,
		at: Vector3, color: Color, rough := 0.45,
		metal := 0.0) -> MeshInstance3D:
	var node := make_cyl(rt, rb, height, at, color, rough, metal, parent)
	return node


func _tube_between(parent: Node3D, a: Vector3, b: Vector3, radius: float,
		color: Color) -> MeshInstance3D:
	var delta := b - a
	var tube := _cyl_on(parent, radius, radius, delta.length(),
			(a + b) * 0.5, color, 0.34, 0.72)
	var direction := delta.normalized()
	# Godot's arc quaternion is undefined for exact antipodes. The exposed
	# waste drops straight down, so UP -> DOWN produced a non-finite transform
	# that the GL renderer tolerated visually and WalkTest correctly rejected.
	var dot := Vector3.UP.dot(direction)
	if dot < -0.9999:
		tube.rotation_degrees.x = 180.0
	elif dot < 0.9999:
		tube.quaternion = Quaternion(Vector3.UP, direction)
	return tube


func interact_prompt() -> String:
	if fixture == "shower" and not (_hot or _cold):
		return "[E]  %s the shower curtain" % (
				"Open" if not _curtain_is_open else "Draw")
	if _hot or _cold:
		return "[E]  Turn off the %s" % _fixture_name()
	return "[E]  Turn on the %s" % _fixture_name()


func interact_area(area: Area3D) -> void:
	if area.has_meta("shower_curtain"):
		set_curtain_open(not _curtain_is_open)


func interact(_player: Node) -> void:
	# One-key interaction cycles useful temperatures, but the minigame APIs
	# below retain independent hot/cold valves and a separate stopper.
	if not _hot and not _cold:
		set_hot(true)
	elif _hot and not _cold:
		set_cold(true)
	else:
		set_hot(false)
		set_cold(false)


func set_curtain_open(open: bool) -> void:
	if _curtain_hand != null:
		if not _curtain_hand.held: _curtain_hand.set_travel(_curtain_hand.TRAVEL if open else 0.0)
		return
	_curtain_is_open = open
	if _curtain_closed:
		_curtain_closed.visible = not open
	if _curtain_gathered:
		_curtain_gathered.visible = open
	if _curtain_area:
		var shape_node := _curtain_area.get_node_or_null("CollisionShape3D") \
				as CollisionShape3D
		if shape_node and shape_node.shape is BoxShape3D:
			var box := shape_node.shape as BoxShape3D
			box.size = Vector3(0.16, 1.55, 0.24) if open \
					else Vector3(0.68, 1.55, 0.10)
			shape_node.position = Vector3(0.34, 1.18, 0.23) if open \
					else Vector3(0, 1.18, -0.31)


func is_curtain_open() -> bool:
	return _curtain_is_open


func set_hot(on: bool) -> void:
	set_valve_opening(0,1.0 if on else 0.0)


func set_cold(on: bool) -> void:
	set_valve_opening(1,1.0 if on else 0.0)

func set_valve_opening(index: int,value: float) -> void:
	if index not in [0,1] or not is_finite(value): return
	_valve_openings[index] = clampf(value,0,1)
	_hot = _valve_openings.x > .0001
	_cold = _valve_openings.y > .0001
	_update_flow()

func _build_primary_interaction() -> void:
	if _curtain_closed != null:
		_curtain_hand=preload("res://scripts/props/shower_curtain_motion.gd").new(self)
		set_curtain_open(warehouse_curtain_open)
	if _bath_plug != null:
		_plug_hand=preload("res://scripts/props/basin_plug.gd").new(self,_bath_plug,Vector3(0,.696,-.02),Vector3(.115,.705,.005))
	for index in mini(2,_handles.size()):
		preload("res://scripts/props/manipulation_area.gd").install(_handles[index],
			func(): return valve_grip(index))

func valve_grip(index: int) -> Dictionary:
	if index < 0 or index >= _handles.size(): return {}
	# Both threaded stop valves unscrew counter-clockwise viewed from the cap.
	# Wall caps face local -Z; deck-mounted caps face +Y.
	var direction := Vector3.FORWARD if _handle_wall_mounted[index] else Vector3.UP
	return {"owner":self,"part":_handles[index],"frame":self,"kind":"hinge",
		"axis":direction,"minimum":0.0,"maximum":PI*.5,
		"read":func(): return _valve_openings[index]*PI*.5,
		"write":func(angle: float):
			if _held_valve == index: set_valve_opening(index,angle/(PI*.5)),
		"owns":func(): return _held_valve == index,
		"begin":func():
			if _held_valve != -1 or (_plug_hand != null and _plug_hand.held) or (_curtain_hand != null and _curtain_hand.held): return false
			_held_valve = index
			return true,
		"end":func(): _held_valve = -1;manipulation_changed.emit()}

func mechanism_snapshot() -> Dictionary:
	var saved := {"hot":_valve_openings.x,"cold":_valve_openings.y}
	if _plug_hand != null:
		var at: Vector3=_plug_hand.part.position
		saved["plug"]=[at.x,at.y,at.z]
		saved["water"]=_water_level
	if _curtain_hand != null: saved["curtain"]=_curtain_hand.travel
	return saved

func valid_mechanism(value: Variant) -> bool:
	if value is not Dictionary or value.size() not in [2,3,4]: return false
	if value.size()==3:
		if _curtain_hand == null or typeof(value.get("curtain")) not in [TYPE_FLOAT,TYPE_INT] or not is_finite(float(value.curtain)) or float(value.curtain)<0 or float(value.curtain)>_curtain_hand.TRAVEL: return false
	if value.size()==4:
		if _plug_hand == null or not _plug_hand.valid_position(value.get("plug")): return false
		if typeof(value.get("water")) not in [TYPE_FLOAT,TYPE_INT] or not is_finite(float(value.water)) or float(value.water)<0 or float(value.water)>1: return false
	for key: String in ["hot","cold"]:
		if typeof(value.get(key)) not in [TYPE_FLOAT,TYPE_INT] or not is_finite(float(value[key])) or float(value[key])<0 or float(value[key])>1: return false
	return true

func restore_mechanism(value: Dictionary) -> void:
	if not valid_mechanism(value): return
	_held_valve = -1
	if _curtain_hand != null:
		_curtain_hand.held=false
		if value.has("curtain"): _curtain_hand.set_travel(float(value.curtain))
	if _plug_hand != null:
		_plug_hand.held=false
		if value.has("plug"):
			_plug_hand.restore(value.plug)
			_water_level=float(value.water)
	set_valve_opening(0,float(value.hot));set_valve_opening(1,float(value.cold))
	for index in mini(2,_handle_turns.size()): _handle_turns[index] = _valve_openings[index]

func manipulation_target(hit: Dictionary) -> Dictionary:
	if _curtain_hand != null and hit.collider == _curtain_area: return _curtain_hand.grip(hit.position)
	for index in _handles.size():
		if _handles[index].is_ancestor_of(hit.collider): return valve_grip(index)
	return {}


func set_stopper(closed: bool) -> void:
	if _plug_hand != null:
		_plug_hand.set_closed(closed)
		return
	_stopper = closed


func set_boiler_temperature(value: float) -> void:
	_boiler_temperature = clampf(value, 0.0, 1.0)


## Compatibility for old callers; independent valves remain authoritative.
func set_running(on: bool) -> void:
	set_cold(on)
	if not on:
		set_hot(false)


func _effective_openings() -> Vector2:
	return _valve_openings

func get_flow_state() -> Dictionary:
	var openings := _effective_openings()
	var mix := 0.0
	if openings.x > .0001 or openings.y > .0001:
		mix = _boiler_temperature*openings.x / (openings.x+openings.y)
	return {"hot": openings.x>.0001, "cold": openings.y>.0001, "stopper": _stopper,
			"temperature": mix, "water_level": _water_level,
			"hot_opening":openings.x,"cold_opening":openings.y,
			"flow":minf(1.0,openings.x+openings.y)}


## A stable maintenance pose for render/test tools: both independent valves
## open over a closed drain. Gameplay never calls this shortcut.
func set_service_pose() -> void:
	set_stopper(true)
	set_hot(true)
	set_cold(true)


func _update_flow() -> void:
	var openings := _effective_openings()
	var flowing := openings.x > .0001 or openings.y > .0001
	var amount := minf(1.0,openings.x+openings.y)
	if _stream:
		_stream.visible = flowing
		_stream.scale.x = sqrt(amount)
		_stream.scale.z = sqrt(amount)
	if _water:
		_water.volume_db = -21.0+linear_to_db(maxf(.01,amount))
		_water.stream_paused = not flowing
		if flowing and not _water.playing:
			_water.play()
	if _tick and not _tick.playing:
		_tick.play()
	state = PState.OPERATING if flowing else PState.IDLE


func _start_normal_function() -> void:
	state = PState.IDLE


func _process(delta: float) -> void:
	if _plug_hand != null: _plug_hand.process(delta)
	_update_bath_plug(delta)
	var targets := [_valve_openings.x,_valve_openings.y]
	for i in mini(_handles.size(), 2):
		_handle_turns[i] = targets[i] if _held_valve == i else move_toward(_handle_turns[i], targets[i], delta * 3.0)
		var turn := _handle_turns[i]*PI*.5
		if _handle_wall_mounted[i]:
			_handles[i].rotation.z = -turn
		else:
			_handles[i].rotation.y = turn
	var openings := _effective_openings()
	var flowing := openings.x > .0001 or openings.y > .0001
	var inflow := .075*minf(1.0,openings.x+openings.y) if flowing else 0.0
	var outflow := 0.0 if _stopper else .12*clampf(drain_capacity,0,1)
	_water_level = clampf(_water_level+delta*(inflow-outflow),0,1)
	if _basin_water:
		_basin_water.visible = _water_level > 0.01
		# Water has one surface; it rises from the drain rather than growing
		# into a thick translucent lid fixed just below the rolled rim.
		_basin_water.position.y = lerpf(
				_water_empty_y, _water_full_y, _water_level)
		var spread := lerpf(0.52, 1.0, _water_level)
		_basin_water.scale.x = _water_full_scale.x * spread
		_basin_water.scale.y = _water_full_scale.y
		_basin_water.scale.z = _water_full_scale.z * spread
	# A hot shower fogs only while it is physically hot; this state is kept
	# for the director without adding a supernatural electrical affordance.
	if fixture == "shower" and _hot:
		state = PState.OPERATING


func _perform_synced_event(index: int, accent: float, _pitch: float) -> void:
	if _held_valve != -1: return
	# Possession may only retime the mechanism: a valve twitches, or a closed
	# tap admits a brief, deniable thread of water. It does not receive data.
	if _hot or _cold:
		var which := posmod(index, 2)
		_handle_turns[which] = clampf(_handle_turns[which] - accent * 0.18, 0.0, 1.0)
	elif accent > 0.72:
		set_cold(true)
		await get_tree().create_timer(0.10 + accent * 0.18, false).timeout
		if is_inside_tree():
			set_cold(false)


func _fixture_name() -> String:
	if fixture == "shower":
		return "shower"
	if fixture == "kitchen_sink":
		return "kitchen tap"
	return "basin tap"
