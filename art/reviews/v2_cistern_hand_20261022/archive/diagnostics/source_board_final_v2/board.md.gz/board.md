# Gate board - 30b326b36fb7

- commit `30b326b36fb704c2bedd16226ed92039640a10e4`
- tree `b6c8d795d198f976d960b5a45a871ccd64819104`
- created 2026-10-22T21:33:02Z
- dirty paths: 2802

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| spatial | PASS | 0 | 5.2 | drift.new_reported 6 |
| reader | PASS | 0 | 3.47 | unread 1108; vs frozen baseline: new 0, resolved 200 |
