extends "res://tests/v2_hose_installed_world.gd"
## INERT installed spray visibility controls. Debug materials are never shipped.
var _spray_controls: Array=[]

func _picture(name: String) -> void:
	await super._picture(name)
	if name!="installed_spray":return
	var native: RefCounted=world.adapter.root.get_meta("v2_native_fire_service")
	var actor: Node3D=native.stations.F02_FIRE_LINE_STAIR.get_ref()
	var spray: GPUParticles3D=actor._live_hose._spray
	var original_mesh: Mesh=spray.draw_pass_1
	var original_override: Material=spray.material_override
	var debug:=StandardMaterial3D.new()
	debug.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED;debug.albedo_color=Color(1,0,1)
	var enlarged:=SphereMesh.new();enlarged.radius=.012;enlarged.height=.08;enlarged.radial_segments=8;enlarged.rings=4
	var description: Dictionary={"evidence_class":"INERT","scope":"Actual charged nozzle after mouse lever input. Debug visibility controls only; original resources restored. No production material exemption or runtime qualification.","emitting":spray.emitting,"amount":spray.amount,"amount_ratio":spray.amount_ratio,"local_coords":spray.local_coords,"global_transform":var_to_str(spray.global_transform),"capture_aabb":var_to_str(spray.capture_aabb()),"camera":var_to_str(player.camera.global_transform),"original_override_class":original_override.get_class() if original_override!=null else "none","original_material_class":original_mesh.surface_get_material(0).get_class(),"controls":_spray_controls}
	for treatment: String in ["original_a","magenta_original_mesh","magenta_large_mesh","original_b"]:
		spray.draw_pass_1=enlarged if treatment=="magenta_large_mesh" else original_mesh
		spray.material_override=debug if treatment.begins_with("magenta") else original_override
		profile_phase="spray_visibility_"+treatment
		for frame in 30:await RenderingServer.frame_post_draw
		var samples: Array=[]
		var previous:=Time.get_ticks_usec()
		for frame in 120:
			await RenderingServer.frame_post_draw
			var now:=Time.get_ticks_usec()
			samples.append({"wall_ms":(now-previous)/1000.,"render_cpu_ms":RenderingServer.viewport_get_measured_render_time_cpu(get_viewport().get_viewport_rid()),"render_gpu_ms":RenderingServer.viewport_get_measured_render_time_gpu(get_viewport().get_viewport_rid())});previous=now
		_spray_controls.append({"name":treatment,"samples":samples,"bounds":var_to_str(spray.capture_aabb())})
		await super._picture("spray_"+treatment)
	spray.draw_pass_1=original_mesh;spray.material_override=original_override
	FileAccess.open(OS.get_environment("SHOT_DIR").path_join("spray_visibility.json"),FileAccess.WRITE).store_string(JSON.stringify(description,"\t"))

func _save_reload(wanted: Dictionary) -> void:
	if OS.get_environment("V2_SPRAY_SKIP_REBUILD")=="1":
		FileAccess.open(OS.get_environment("SHOT_DIR").path_join("rebuild_skipped.json"),FileAccess.WRITE).store_string(JSON.stringify({"evidence_class":"INERT","scope":"Spray-only diagnostic explicitly skips the inherited disk/rebuild phase. No persistence proof from this run."},"\t"))
		return
	await super._save_reload(wanted)
