"""Inspect completed six-leg diagnostic; no runtime/artistic acceptance.
Usage: python analyze_run.py RUN_DIR [COMPARISON_DIR]
"""
import hashlib,json,math,sys
from pathlib import Path

def load(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def stats(values):
    v=sorted(values)
    assert v
    return {"n":len(v),**{f"p{p}":v[max(0,math.ceil(len(v)*p/100)-1)] for p in (50,95,99)},"max":v[-1],"over_100":sum(x>100 for x in v)}
def inspect(root):
    r=load(root/"run.log.receipt.json"); d=load(root/"stutter_probe.json"); w=load(root/"stutter_work.json")
    assert r["execution"]["completed"] and r["execution"]["exit_code"]==0 and not r["execution"]["timed_out"]
    assert not r["log"]["script_error_count"] and not r["log"]["stale_cache_suspect"]
    assert not (root/"run.log.stderr").read_bytes()
    assert d["source_before"]==d["source_after"]==r["source"]["runtime_inputs_sha256"]
    source=root/"v2_city_transport_route.gd"
    if not source.exists(): source=root/"executed_transport.gd"
    assert hashlib.sha256(source.read_bytes().replace(b"\r\n",b"\n")).hexdigest()==r["source"]["test_sha256"]
    assert not d["failures"] and len(d["legs"])==len(d["trace"])==6
    assert all(x["reached"] for x in d["legs"]) and all(x["ok"] for x in d["trace"])
    rows=w["frames"]
    reconciliation=[sum(p[k][2] for p in f["viewport_passes"].values() for k in ("visible","shadow","canvas"))-f["counters"]["RENDER_TOTAL_DRAW_CALLS_IN_FRAME"] for f in rows]
    assert all(x==0 for x in reconciliation)
    phases=[x["phase"] for x in d["legs"]]
    result={"directory":str(root),"source":d["source_before"],"settings":d["settings"],"targets":[x["target"] for x in d["trace"]],"wall_ms":stats([f["wall_render_draws_primitives"][0] for f in d["frames"]]),"by_leg":{},"structural_sources":w["structural_occluders"],"global_draw_reconciliation":True,"post_observer_max_usec":max(w["probe_post_sample_usec"])}
    for phase in phases:
        frames=[f for f in d["frames"] if f["phase"]==phase]; passes=[f for f in rows if f["phase"]==phase]
        result["by_leg"][phase]={"wall_ms":stats([f["wall_render_draws_primitives"][0] for f in frames]),"main_visible_draws":stats([f["viewport_passes"]["main"]["visible"][2] for f in passes]),"main_shadow_draws":stats([f["viewport_passes"]["main"]["shadow"][2] for f in passes])}
    if "slab_comparison" in d:
        c=d["slab_comparison"]; assert c["slab_count"]>0
        for view in c["views"]:
            assert hashlib.sha256((root/view["file"]).read_bytes()).hexdigest()==view["sha256"]
        result["slab_control"]=c
    return result
if __name__=="__main__":
    results=[inspect(Path(x)) for x in sys.argv[1:]]
    assert results
    if len(results)>1:
        assert all(x["settings"]==results[0]["settings"] and x["targets"]==results[0]["targets"] for x in results)
    out={"evidence_class":"INERT","scope":"Source-bound diagnostic distributions and actual pass counts. Comparable settings/targets do not establish causal speedup across different source, cache or process order. Image hashes are integrity only; visibility requires inspection. No save, shipping or artistic acceptance.","runs":results}
    Path(sys.argv[1],"analysis.json").write_text(json.dumps(out,indent=2)+"\n",encoding="utf8")
    print(json.dumps({r["directory"]:{"wall_ms":r["wall_ms"],"structural_sources":r["structural_sources"],"slab_control":r.get("slab_control")} for r in results},indent=2))
