"""Retained six-leg diagnostic comparison. No artistic or production acceptance.
Usage: python compare_matched_runs.py baseline01 candidate01 [reversal01]
Runs are sibling directories. Requires each executed_transport.gd copy frozen
at launch; never supply the current test in place of the executed source.
"""
import hashlib, json, math, sys
from pathlib import Path
ROOT = Path(__file__).parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def distribution(values):
    values = sorted(values)
    assert values
    return {"samples":len(values), **{f"p{p}_ms":values[max(0,math.ceil(len(values)*p/100)-1)] for p in (50,95,99)}, "max_ms":values[-1], "over_100ms":sum(x>100 for x in values)}

def review(name):
    root = ROOT/name
    raw = json.loads((root/"stutter_probe.json").read_text())
    receipt = json.loads((root/"run.log.receipt.json").read_text())
    assert receipt["execution"]["completed"] and receipt["execution"]["exit_code"]==0 and not receipt["execution"]["timed_out"]
    assert not receipt["log"]["script_error_count"] and not receipt["log"]["stale_cache_suspect"]
    assert not (root/"run.log.stderr").read_bytes()
    assert raw["source_before"]==raw["source_after"]==receipt["source"]["runtime_inputs_sha256"]
    source = (root/"executed_transport.gd").read_bytes().replace(b"\r\n",b"\n")
    assert hashlib.sha256(source).hexdigest()==receipt["source"]["test_sha256"]
    assert not raw["failures"] and len(raw["legs"])==len(raw["trace"])==6
    phases = [f"cycle_{cycle}_leg_{leg}" for cycle in range(3) for leg in range(2)]
    assert [x["phase"] for x in raw["legs"]]==phases
    assert all(x["reached"] for x in raw["legs"]) and all(x["ok"] for x in raw["trace"])
    frames = raw["frames"]
    wall = lambda f: f["wall_render_draws_primitives"][0]
    prep = raw.get("entry_render_preparation",{})
    return {"name":name,"runtime_inputs_sha256":raw["source_before"],"settings":raw["settings"],"targets":[x["target"] for x in raw["trace"]],"wall":distribution([wall(f) for f in frames]),"by_leg":{phase:distribution([wall(f) for f in frames if f["phase"]==phase]) for phase in phases},"startup_ms":raw["startup_ms"],"entry_render_preparation_enabled":raw.get("entry_render_preparation_enabled",False),"entry_render_preparation":prep,"files_sha256":{path.name:digest(path) for path in [root/"stutter_probe.json",root/"stutter_work.json",root/"run.log.receipt.json",root/"executed_transport.gd"]}}

def compare(names):
    runs = [review(name) for name in names]
    first = runs[0]
    for run in runs[1:]:
        assert run["settings"]==first["settings"],("quality or diagnostic settings changed",run["name"])
        assert run["targets"]==first["targets"],("route target changed",run["name"])
        if run["entry_render_preparation_enabled"]:
            p = run["entry_render_preparation"]
            assert p.get("completed") and p.get("render_calls")==10 and p.get("node_poses_unchanged"),("production preparation did not complete",p)
    return {"evidence_class":"INERT","scope":"Matched settings and six normal-controller legs. Raw frame intervals are not input latency. Preparation/startup cost is separate; changed process/cache order and coarse host-load coverage limit causal attribution. No visual, artistic, whole-city, save or shipping acceptance.","matching_settings_and_targets":True,"runs":runs}

if __name__=="__main__":
    names=sys.argv[1:]
    assert names,"Supply completed run directories"
    result=compare(names)
    path=ROOT/"matched_comparison.json"
    path.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({x["name"]:{"wall":x["wall"],"startup_ms":x["startup_ms"],"preparation":x["entry_render_preparation"]} for x in result["runs"]},indent=2))
