import ctypes,json,time
from ctypes import wintypes
from pathlib import Path
base=Path(__file__).parent
receipt=base/'run.log.receipt.json'
class FT(ctypes.Structure):
 _fields_=[('lo',wintypes.DWORD),('hi',wintypes.DWORD)]
def counters():
 v=[FT(),FT(),FT()]
 if not ctypes.windll.kernel32.GetSystemTimes(*(ctypes.byref(x) for x in v)):raise ctypes.WinError()
 return [(x.hi<<32)|x.lo for x in v]
while not (base/'run.log').exists():time.sleep(1)
old=counters();rows=[];costs=[];began=time.monotonic()
print('Standard-library 1Hz host CPU observer active; no per-process attribution.',flush=True)
while not receipt.exists() and time.monotonic()-began<900:
 time.sleep(1);started=time.perf_counter();new=counters();d=[n-o for n,o in zip(new,old)];old=new
 rows.append({'utc_seconds':time.time(),'elapsed_s':time.monotonic()-began,'system_cpu_percent':100*(1-d[0]/max(1,d[1]+d[2])),'run_log_bytes':(base/'run.log').stat().st_size})
 costs.append((time.perf_counter()-started)*1000)
data={'evidence_class':'INERT','scope':'External1Hz GetSystemTimes CPU samples only. Not per-frame or causal attribution; coverage starts at observer launch. No synchronized gameplay clock.','setup_note':'Same standard-library GetSystemTimes observer as baseline, launched before candidate run; not per-process or per-frame attribution.','samples':rows,'sampling_body_max_ms':max(costs,default=0),'terminal_receipt_exists':receipt.exists()}
(base/'host_load.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
print(json.dumps({'samples':len(rows),'sampling_body_max_ms':data['sampling_body_max_ms'],'receipt_exists':receipt.exists()}),flush=True)
