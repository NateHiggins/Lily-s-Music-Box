# Gate board - a3e7b1bd69d7

- commit `a3e7b1bd69d7ae6593cf5e351e1fe3f24591da57`
- tree `8798ecfde3051411aceb1bf3288adc120321a104`
- created 2026-10-22T22:39:01Z
- dirty paths: 3124

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| physical_import_sources | PASS | 0 | 0.5 | no defects counted |
| v2_recipe_projections | PASS | 0 | 0.75 | no defects counted |
| v2_mesh_uv_imports | PASS | 0 | 0.14 | no defects counted |
| v2_surface_imports | PASS | 0 | 0.44 | no defects counted |
| spatial | PASS | 0 | 6.67 | drift.new_reported 6 |
| reader | PASS | 0 | 4.41 | unread 1108; vs frozen baseline: new 0, resolved 200 |
