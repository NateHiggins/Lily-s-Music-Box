from pathlib import Path
import datetime, hashlib, json, os, subprocess, zipfile
root=Path.cwd().resolve(); out=Path(__file__).parent
os.environ['GIT_OPTIONAL_LOCKS']='0'
inventory=out/'untracked_before_import.txt'
before=set(inventory.read_text(encoding='utf-8-sig').splitlines()) if inventory.exists() else set()
tracked=set(subprocess.check_output(['git','ls-files']).decode().splitlines())
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard']).decode().splitlines()
if not inventory.exists():
    # PowerShell's empty pipeline did not create a file. Strengthen the audit
    # with the exact previously quarantined cache-generated roster and bytes;
    # do not fabricate a pre-import inventory file after the fact.
    previous=json.loads(Path('C:/ov/reports/city_relief_20261028/import_cleanup.json').read_text())
    expected={r['path']:r['sha256'] for r in previous['generated_uids']}
    assert set(untracked)==set(expected),'Untracked roster differs from the prior known generated UID set'
    changed={n for n,h in expected.items() if hashlib.sha256((root/n).read_bytes()).hexdigest()!=h}
    assert changed=={'game/scripts/building/orison_v2_city_horizon.gd.uid','game/tests/v2_city_horizon_bench.gd.uid'},changed
    # These two source files are the edited owners in this task. Godot issued
    # fresh UIDs during this import; all625 other cached values are identical.
    assert all(n[:-4] in subprocess.check_output(['git','diff','--name-only']).decode().splitlines() for n in changed)
receipt=json.loads((out/'import.log.receipt.json').read_text())
start=datetime.datetime.fromisoformat(receipt['execution']['started_utc'].replace('Z','+00:00')).timestamp()-3
end=datetime.datetime.fromisoformat(receipt['execution']['finished_utc'].replace('Z','+00:00')).timestamp()+3
records=[]; churn=[]
for name in untracked:
    if not name.endswith('.uid') or name in before:continue
    path=(root/name).resolve()
    assert path.is_relative_to(root/'game') and name[:-4] in tracked and path.with_suffix('').is_file(),name
    assert start<=path.stat().st_birthtime<=end,name
    records.append({'path':name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'created':path.stat().st_birthtime})
for name in subprocess.check_output(['git','diff','--name-only']).decode().splitlines():
    if not name.endswith('.import'):continue
    raw=(root/name).read_bytes(); old=subprocess.check_output(['git','show','HEAD:'+name])
    assert raw.replace(b'\r\n',b'\n')==old.replace(b'\r\n',b'\n'),name
    churn.append(name)
archive=out/'generated_import_churn.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for row in records:z.write(root/row['path'],row['path'])
    for name in churn:z.write(root/name,name)
report={'evidence_class':'INERT','receipt':'import.log.receipt.json','generated_uids':records,'eol_only_imports':churn,
        'basis':'Pre-import ls-files empty pipeline created no inventory file. Exact previous quarantined627-path roster;625 identical cached values and two regenerated UIDs for task-edited source owners, then untracked/indexed-parent/inside-game/current-import-creation-time guards, archive and immediate hash recheck. No other source deletion.'}
(out/'import_cleanup.json').write_text(json.dumps(report,indent=2)+'\n')
for row in records:
    path=(root/row['path']).resolve()
    assert path.is_relative_to(root/'game') and hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
    path.unlink()
if churn:subprocess.run(['git','restore','--source=HEAD','--',*churn],check=True)
print('Removed task-generated UIDs:',len(records),'restored EOL-only imports:',len(churn))
