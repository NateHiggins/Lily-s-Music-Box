from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();here=Path(__file__).parent
dest=root/'art/reviews/skywatch_20261027';archive=dest/'diagnostics.zip';prefix='city_building_studies_three/'
receipt=json.loads((here/'bench_bearings.log.receipt.json').read_text())
assert receipt['execution']['completed'] and receipt['execution']['exit_code']==0
assert not (here/'bench_bearings.log.stderr').read_bytes()
files=[p for p in here.glob('*') if p.is_file() and p.suffix in {'.log','.stderr','.json','.ps1','.py','.zip','.bin','.txt'}]
files += [here/'native_bearings/review.json',here/'native_bearings/HORIZON_NEAR_0_0_P0R1.png']
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
    assert not any(n.startswith(prefix) for n in z.namelist())
    for path in files:z.write(path,prefix+path.relative_to(here).as_posix())
m=json.loads((dest/'manifest.json').read_text())
construction=json.loads((root/'art/blender/city_horizon_construction.json').read_text())
inputs=['art/data/city_horizon/source_plan.json','art/blender/scripts/build_city_horizon.py','art/blender/scripts/city_horizon_geometry.py',
 'game/scripts/building/orison_v2_city_horizon.gd','game/tests/v2_city_horizon_bench.gd','game/tests/fixtures/orison_city_horizon.json']
m['city_building_studies_three']={'evidence_class':'INERT','scope':'Three authored architectural studies; native and imported neutral bench only. No composed-world/full-surface, played-access, save-rebuild or human acceptance.',
 'base':'499ebad0','mode':'3440x1440 fullscreen; patched4.7.1 LLVM Vulkan; neutral bench lighting',
 'studies':[{k:r[k] for k in ['id','height_m','architecture']} for r in construction['buildings'] if 'architecture'in r],
 'remaining':'25 near-city plus121 horizon buildings require individual studies/acceptance; repair eight29.5–44.715m near-city background masses with dependent roof equipment next.',
 'final_bench':{'receipt':'bench_bearings.log.receipt.json','checks':12534,'failures':0,'elapsed_s':receipt['execution']['elapsed_s'],'shutdown_stderr_empty':True,'kind':'suite_run, not runtime_contract'},
 'native_checks':construction['native_checks'],'unrelated_arrays':json.loads((here/'unrelated_arrays_final.json').read_text()),
 'source_lf_sha256':{n:hashlib.sha256((root/n).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for n in inputs},
 'captures':{str(path.relative_to(here)):{'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'external_path':str(path),'inspected':True} for folder in ['native_bearings','imported_bearings'] for path in (here/folder).glob('*.png')},
 'limits':['Authored proportions, not surveyed facsimiles.','Simplified ornament and opaque distant panes; neutral renders are not final atmospheric acceptance.','Earlier terrain route predates these building changes and is not their performance qualification.','Earlier bench wrappers retained but stale after added checks/geometry correction.','Cleanup preflight failures exist in tool transcript; no fabricated traceback log.']}
with zipfile.ZipFile(archive) as z:m['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
m['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archived three-study diagnostic packet:',archive.stat().st_size,'bytes')
