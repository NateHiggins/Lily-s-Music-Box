from pathlib import Path
import hashlib,json,zipfile,subprocess,sys
root=Path.cwd();out=Path('C:/ov/reports/city_sohmer_20261028');dest=root/'art/reviews/skywatch_20261027';archive=dest/'diagnostics.zip'
verification=json.loads((out/'candidate/verification.json').read_text())
assert not verification['blocking'] and not verification['comparison']['regressions']
assert verification['candidate']=='1cb5f10418a1b1cc8f4899d2c88b080d51de2a65'
assert verification['protected']['matched']==17 and verification['selector']['value']=='v2'
assert not verification['comparison']['requirements_changed']
merge=sys.argv[1]
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==merge
assert subprocess.check_output(['git','rev-parse',merge+'^{tree}'],text=True)==subprocess.check_output(['git','rev-parse',verification['candidate']+'^{tree}'],text=True)
m=json.loads((dest/'manifest.json').read_text());assert hashlib.sha256(archive.read_bytes()).hexdigest()==m['archive_sha256']
with zipfile.ZipFile(archive) as z:
 for n,h in m['members'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h,n
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in [out/'candidate/verification.json',out/'candidate/verification.md',out/'finalize.py']:
  name='city_sohmer/'+p.relative_to(out).as_posix();assert name not in z.namelist();z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()));m['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
assert archive.stat().st_size<50*1024*1024
m['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
record=m['city_sohmer'];record['candidate_verification']={'candidate':verification['candidate'],'base':verification['base'],'gates':114,'regressions':0,'protected_unchanged':17,'selector':'v2','requirements_changed':[],'mode':'clean in-place --no-godot; separately executed source-bound Godot receipts','merge':merge,'pr':int(sys.argv[2]),'tree_matches_candidate':True}
record['limits']=[v for v in record['limits'] if v!='Candidate verification pending.']
(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
p=root/'design/V2_CITY_CONTEXT_REPORT_2026-10-19.md';s=p.read_text(encoding='utf-8');old='budgets remain. Candidate verification remains the final integration step.'
assert old in s
s=s.replace(old,f'''budgets remain. Frozen candidate **1cb5f104** passes the **114-gate** comparison
with **zero regressions**, all **17 protected paths unchanged**, selector **V2**,
clean changed-document lint and no changed requirement statuses. The one
test-camera manifest addition was reviewed; no scanner or baseline weakened.
Existing unrelated red gates remain red. Verification is in-place with separately
executed source-bound Godot receipts, not fresh-checkout import/autocrlf proof.

Merged through **PR #{sys.argv[2]}**, commit **{merge}**; its tree exactly matches
the qualified candidate. This final report/archive update changes metadata only;
runtime and test sources remain the executed candidate. The four review images,
original failures, raw measurements and candidate verdict are preserved in the
existing archive, below 50 MiB. No runtime qualification is inferred from this
metadata update.''')
p.write_text(s,encoding='utf-8',newline='\n')
print('Recorded qualified merge; archive bytes',archive.stat().st_size)
