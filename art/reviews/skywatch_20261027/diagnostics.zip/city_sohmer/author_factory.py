from pathlib import Path
import json
p=Path('art/data/city_elevations/source_plan.json');d=json.loads(p.read_text(encoding='utf-8'));b=next(v for v in d['buildings'] if v['id']=='site_far_e');b.update(description='Sohmer-inspired six-storey piano factory: continuous masonry, segmental openings, selected belt courses and a seated curved-mansard clock pavilion',massing='straight_eave',window_treatment='roller');b['architecture']={'type':'sohmer_factory','arch_rise_m':0.22,'belt_floors':[1,2,5],'tower':{'rect':[74.24,9.76,80.24,15.76],'wall_height_m':3.3,'roof_height_m':4.1}};b['precedent']['pdf_pages']=[1,8,14,15];b['precedent']['adaptation']='Authored dimensions and fixed gameplay footprint, not an exact replica or relocated historic factory. Six continuous storeys, segmental openings, bands above floors 1/2/5, corner clock pavilion and curved metal mansard; existing roof equipment and its support heights retained.';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('art/blender/scripts/build_city_elevations.py');t=p.read_text(encoding='utf-8');t=t.replace('from fabrication_native_batch import material,partition,export','from fabrication_native_batch import material,partition,export\nfrom city_horizon_geometry import cornice_ring')
t=t.replace('buffers=collections.defaultdict(lambda:([],[]));stats=[];window_rows=[]','buffers=collections.defaultdict(lambda:([],[]));stats=[];window_rows=[]\nhand_origins={};clock_hands=[];architecture_checks=[]')
needle='def facade(name,p,rect,z0,z1):'
helpers='''def profile_stock(name,key,origin,tangent,out,points,back,front):
    """Closed metric planar stock; front faces outward on all four elevations."""
    assert front>back and len(points)>=3
    points=list(points)
    area=sum(x*Z-X*z for (x,z),(X,Z) in zip(points,points[1:]+points[:1]))
    if area<0:points.reverse()
    n=len(points)
    vv=[tuple(origin+tangent*x+out*y+Vector((0,0,z))) for y in [back,front] for x,z in points]
    ff=[tuple(range(n)),tuple(range(2*n-1,n-1,-1))]
    ff += [(i,i+n,j+n,j) for i,j in zip(range(n),list(range(1,n))+[0])]
    add(name,key,vv,ff)

def arch_stock(name,key,origin,tangent,out,cx,spring,half,rise,width,back,front,steps=12):
    inner=[(cx-half*math.cos(i*math.pi/steps),spring+rise*math.sin(i*math.pi/steps)) for i in range(steps+1)]
    outer=[(cx-(half+width)*math.cos(i*math.pi/steps),spring+(rise+width)*math.sin(i*math.pi/steps)) for i in range(steps+1)]
    for i in range(steps):profile_stock(name,key,origin,tangent,out,[inner[i],inner[i+1],outer[i+1],outer[i]],back,front)

def factory_tower(name,p,seat):
    tower=p['architecture']['tower'];x,y,X,Y=tower['rect'];cx=(x+X)/2;cy=(y+Y)/2
    width=X-x;assert abs(width-(Y-y))<1e-6
    base=seat;wall=base+float(tower['wall_height_m']);height=float(tower['roof_height_m']);half=width/2+.15
    box(name,p['wall_key'],(x,y,base),(X,Y,wall))
    # A closed roof volume with a curved profile, four raised hip seams and a cap.
    levels=[(wall+height*i/10,half*(.28+.72*math.cos(i*math.pi/20))) for i in range(11)]
    vv=[(cx+a*r,cy+b*r,z) for z,r in levels for a,b in [(-1,-1),(1,-1),(1,1),(-1,1)]]
    ff=[(3,2,1,0),tuple(range(40,44))]
    for i in range(10):
        for j in range(4):ff.append((i*4+j,i*4+(j+1)%4,(i+1)*4+(j+1)%4,(i+1)*4+j))
    add(name,'copper_aged',vv,ff)
    for a,b in [(-1,-1),(1,-1),(1,1),(-1,1)]:
        points=[Vector((cx+a*r,cy+b*r,z)) for z,r in levels]
        vertices=[]
        for i,at in enumerate(points):
            along=(points[min(i+1,10)]-points[max(i-1,0)]).normalized()
            across=Vector((-b,a,0)).normalized();other=along.cross(across).normalized()
            vertices.extend(tuple(at+.055*(across*math.cos(k*math.tau/6)+other*math.sin(k*math.tau/6))) for k in range(6))
        faces=[tuple(reversed(range(6))),tuple(range(60,66))]
        faces += [(i*6+j,i*6+(j+1)%6,(i+1)*6+(j+1)%6,(i+1)*6+j) for i in range(10) for j in range(6)]
        add(name,'copper_aged',vertices,faces)
    cap=levels[-1][1]+.12
    box(name,'copper_aged',(cx-cap,cy-cap,wall+height),(cx+cap,cy+cap,wall+height+.18))
    faces=[('south',Vector((cx,y,0)),Vector((1,0,0)),Vector((0,-1,0))),('east',Vector((X,cy,0)),Vector((0,1,0)),Vector((1,0,0))),('north',Vector((cx,Y,0)),Vector((-1,0,0)),Vector((0,1,0))),('west',Vector((x,cy,0)),Vector((0,-1,0)),Vector((-1,0,0)))]
    for face,origin,u,out in faces:
        center=base+1.8
        profile_stock(name,p['wall_key'],origin,u,out,[(-width/2,wall),(-width/2,wall+.06),(0,wall+1.05),(width/2,wall+.06),(width/2,wall)],-.10,.14)
        circle=[(math.cos(i*math.tau/48)*1.06,center+math.sin(i*math.tau/48)*1.06) for i in range(48)]
        profile_stock(name,'enamel',origin,u,out,circle,.15,.20)
        for i in range(48):
            a=i*math.tau/48;b=(i+1)*math.tau/48
            profile_stock(name,'copper_aged',origin,u,out,[(math.cos(a)*1.07,center+math.sin(a)*1.07),(math.cos(b)*1.07,center+math.sin(b)*1.07),(math.cos(b)*1.18,center+math.sin(b)*1.18),(math.cos(a)*1.18,center+math.sin(a)*1.18)],.13,.25)
        for tick in range(12):
            angle=tick*math.tau/12
            points=[(r*math.sin(angle)+w*math.cos(angle),center+r*math.cos(angle)-w*math.sin(angle)) for r,w in [(.84,-.025),(.97,-.025),(.97,.025),(.84,.025)]]
            profile_stock(name,'iron_blackened',origin,u,out,points,.205,.23)
        for kind,length,width_hand,period in [('hour',.62,.09,720),('minute',.88,.055,60)]:
            identity=name+'__clock_'+face+'_'+kind
            profile_stock(identity,'iron_blackened',origin,u,out,[(-width_hand,-.13+center),(width_hand,-.13+center),(width_hand,center+length*.75),(0,center+length),(-width_hand,center+length*.75)],.24,.28)
            pivot=origin+out*.26+Vector((0,0,center));hand_origins[identity]=pivot
            clock_hands.append(dict(part=identity+'__iron_blackened',pivot=[pivot.x,pivot.z,-pivot.y],normal=[out.x,out.z,-out.y],period_minutes=period))
        profile_stock(name,'copper_aged',origin,u,out,[(math.cos(i*math.tau/16)*.12,center+math.sin(i*math.tau/16)*.12) for i in range(16)],.28,.31)
    architecture_checks.append(dict(building=name,tower_rect=[x,y,X,Y],tower_seat=seat,tower_top=wall+height+.18,arch_windows=0))

'''
assert needle in t;t=t.replace(needle,helpers+needle)
t=t.replace("depth=float(p['reveal_depth']);recess=float(p['window_recess']);assert 0<recess<depth","depth=float(p['reveal_depth']);recess=float(p['window_recess']);assert 0<recess<depth\n    factory=p.get('architecture',{}).get('type')=='sohmer_factory'")
needle="                # Glazed, closed backing: these passive shells imply no accessible interior."
spandrel='''                if factory:
                    rise=float(p['architecture']['arch_rise_m']);spring=high-rise
                    # Closed spandrels cut the square opening to a true segmental head.
                    for step in range(12):
                        a0=step*math.pi/12;a1=(step+1)*math.pi/12
                        l=cx-w*.5*math.cos(a0);r=cx-w*.5*math.cos(a1)
                        z=spring+rise*math.sin(a0);Z=spring+rise*math.sin(a1)
                        profile_stock(name,p['wall_key'],origin,tangent,out,[(l,z),(r,Z),(r,high+.04),(l,high+.04)],-depth,0)
                    arch_stock(name,p['wall_key'],origin,tangent,out,cx,spring,w/2,rise,.12,-.08,.035)
                    arch_stock(name,p['sash'],origin,tangent,out,cx,spring,w/2-.055,rise-.025,.055,-recess-.044,-recess)
'''
assert needle in t;t=t.replace(needle,spandrel+needle)
t=t.replace('if pattern%5 != 0:', 'if (pattern%5 == 0 if factory else pattern%5 != 0):')
t=t.replace("                local_box(name,p['lintel_key'],origin,tangent,out,(wl-.09,-.08,high),(wr+.09,.025,high+float(p['lintel_height'])))","                if not factory:local_box(name,p['lintel_key'],origin,tangent,out,(wl-.09,-.08,high),(wr+.09,.025,high+float(p['lintel_height'])))")
# The factory has a continuous six-storey facade. Its old final cap is retained
# as interior bearing stock; the roof extension meets it with disjoint strips.
t=t.replace("    ring=rings[name];cap=", "    factory=p.get('architecture',{}).get('type')=='sohmer_factory'\n    ring=rings[name];cap=")
t=t.replace("    for face in ring.data.polygons:","    for face in ([] if factory else ring.data.polygons):")
t=t.replace("    split=last['z0'] if len(ss)>1 else top", "    split=top if factory else last['z0'] if len(ss)>1 else top")
t=t.replace("    if len(ss)>1:\n        n+=facade", "    if len(ss)>1 and not factory:\n        n+=facade")
needle="    stats.append(dict(id=name,old_setbacks=len(ss)-1,new_setbacks=min(1,len(ss)-1),"
addition='''    if factory:
        cap_row=next(r for r in rr if r['id']==name+'_c'+last['id'].rsplit('_s',1)[1]);roof=cap_row['z0']+cap_row['h']
        a,b,c,d=rect0;u,v,U,V=cap_row['rect'];u+=dx;U+=dx
        for lo,hi in [((a-.16,b-.16,top),(c+.16,v,roof)),((a-.16,V,top),(c+.16,d+.16,roof)),((a-.16,v,top),(u,V,roof)),((U,v,top),(c+.16,V,roof))]:box(name,'roof_bitumen',lo,hi)
        outline=[(c,d),(a,d),(a,b),(c,b)]
        vv,ff=cornice_ring(outline,.16,roof,roof+.18);add(name,p['wall_key'],vv,ff)
        for floor in p['architecture']['belt_floors']:
            edge=sum(p['floor_heights'][:floor]);vv,ff=cornice_ring(outline,.11,edge-.07,edge+.07);add(name,p['wall_key'],vv,ff)
        factory_tower(name,p,roof)
        architecture_checks[-1]['arch_windows']=n
'''
assert needle in t;t=t.replace(needle,addition+needle.replace('new_setbacks=min(1,len(ss)-1)','new_setbacks=0 if factory else min(1,len(ss)-1)'))
t=t.replace('    p=groups[name];tint=',"    p=groups[name.split('__')[0]];tint=")
t=t.replace('    for v in mesh.vertices:v.co-=center','    if name in hand_origins:center=hand_origins[name]\n    for v in mesh.vertices:v.co-=center')
t=t.replace("'frame_tint']} for p in profiles['buildings']]}","'frame_tint']} for p in profiles['buildings']], 'clock_hands':clock_hands}")
t=t.replace('construction.update(anchor_seats=anchor_seats,','construction.update(clock_hands=clock_hands,architecture_checks=architecture_checks,anchor_seats=anchor_seats,')
p.write_text(t,encoding='utf-8',newline='\n')
compile(t,str(p),'exec');print('Authored factory geometry and source plan; runtime integration still pending')
