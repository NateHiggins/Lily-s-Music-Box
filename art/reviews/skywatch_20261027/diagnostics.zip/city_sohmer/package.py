from pathlib import Path
import json,hashlib,zipfile,gzip,subprocess
root=Path.cwd();out=Path('C:/ov/reports/city_sohmer_20261028');dest=root/'art/reviews/skywatch_20261027';archive=dest/'diagnostics.zip';prefix='city_sohmer/'
m=json.loads((dest/'manifest.json').read_text(encoding='utf-8'));assert hashlib.sha256(archive.read_bytes()).hexdigest()==m['archive_sha256']
backup=out/'published_backup/previous_surface_packet';review=json.loads((backup/'visual_review.json').read_text(encoding='utf-8'));names=['runtime_contract.json','surface-inventory.json','suite_run.receipt.json','suite_run.stdout.log.gz','suite_run.stderr.log.gz','visual_review.json']+[v['file'] for v in review['images']]
verified={}
for name in names:
 p=backup/(name+'.gz' if name=='surface-inventory.json' else name);raw=gzip.decompress(p.read_bytes()) if name=='surface-inventory.json' else p.read_bytes();old=subprocess.check_output(['git','show','8d295207:art/renders/orison_v2/surface_requirements_20261011/'+name]);assert old==raw,name;verified[name]=hashlib.sha256(raw).hexdigest()
(out/'previous_packet_recovery.json').write_text(json.dumps({'commit':'8d2952079cfa46296bc13eff54a5ef2ab6d714ab','byte_verified':verified},indent=2)+'\n')
files=[p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.ps1','.json','.log','.stderr','.gd','.bin','.zip'}]
files += [out/'main_baseline/board.json',out/'preflight/board.json',out/'surface_final/runtime_contract.json']
for folder in ['route','route_clock_profile']:
 files += sorted((out/folder).glob('*.json'))
files += sorted((out/'review_images').glob('*.webp'))
with zipfile.ZipFile(archive) as z: old_members={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 assert not any(v.startswith(prefix) for v in z.namelist())
 for p in files:z.write(p,prefix+p.relative_to(out).as_posix())
m['city_sohmer']={'evidence_class':'INERT','base':'8d295207','scope':'One individual near-city factory study, calendar-clock projection and measured cost; not whole-city or human artistic acceptance.','raw_prefix':prefix,'comparison':json.loads((out/'performance_comparison.json').read_text()),'baseline_raw_member':'passage_publication/after_physics/cloud_world_frames.json','surface':{'checks':39265,'contracts':json.loads((out/'surface_final/runtime_contract.json').read_text())['contracts'],'wrapper_seconds':774,'stderr_empty':True,'captures':237,'individually_reviewed':7},'previous_packet':json.loads((out/'previous_packet_recovery.json').read_text()),'review_images':json.loads((out/'lossless_review_images.json').read_text()),'limits':['145 of 149 individual city studies remain.','Typical/GPU costs essentially unchanged; after maxima exceed this baseline and large stalls remain unattributed.','Clock timing excludes deferred engine work.','Save reconstruction and unchanged hose input not executed; no human acceptance.','Candidate verification pending.']}
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()));m['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
 for n,h in old_members.items(): assert m['members'][n]==h,n
m['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest();(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archived',len(files),'files; previous packet',len(verified),'exact bytes verified; archive',archive.stat().st_size)
