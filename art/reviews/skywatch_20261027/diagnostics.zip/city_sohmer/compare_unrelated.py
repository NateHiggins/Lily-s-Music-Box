from pathlib import Path
import hashlib, json, struct, subprocess
import numpy as np

OUT=Path(__file__).parent
SELECTED={'site_far_e'}
def read(raw):
    chunks={};pos=12
    while pos<len(raw):
        size,kind=struct.unpack_from('<II',raw,pos);chunks[kind]=raw[pos+8:pos+8+size];pos+=8+size
    doc=json.loads(chunks[0x4e4f534a]);blob=chunks[0x004e4942]
    def array(index):
        a=doc['accessors'][index];b=doc['bufferViews'][a['bufferView']]
        width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
        dtype=np.dtype({5121:'u1',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']])
        values=np.ndarray((a['count'],width),dtype=dtype,buffer=blob,
            offset=b.get('byteOffset',0)+a.get('byteOffset',0),strides=(b.get('byteStride',dtype.itemsize*width),dtype.itemsize))
        return hashlib.sha256(values.tobytes()).hexdigest()
    result={}
    for node in doc['nodes']:
        if 'mesh' not in node:continue
        mesh=doc['meshes'][node['mesh']]
        result[node['name']]={'pose':{k:node[k] for k in ['matrix','translation','rotation','scale'] if k in node},
            'arrays':[{**{k:array(v) for k,v in p['attributes'].items()},'indices':array(p['indices'])} for p in mesh['primitives']]}
    return result

result={'evidence_class':'INERT','base':'8d295207','scope':'All exported arrays and node poses of unedited building draws; not loaded runtime or optical acceptance.','families':{}}
for family in ['elevations','masts','aerials','tanks','beacons','shells']:
    path='game/assets/props/city_'+family+'.glb'
    old=subprocess.check_output(['git','show','8d295207:'+path]);new=Path(path).read_bytes()
    before=read(old);after=read(new)
    unchanged=[n for n in before if n.split('__')[0] not in SELECTED]
    failures=[n for n in unchanged if after.get(n)!=before[n]]
    added_unrelated=[n for n in after if n not in before and n.split('__')[0] not in SELECTED]
    assert not failures and not added_unrelated,(failures,added_unrelated)
    result['families'][family]={'unchanged_draws':len(unchanged),'array_or_pose_changes':failures,'added_unrelated':added_unrelated,
        'whole_glb_identical':old==new,'before_sha256':hashlib.sha256(old).hexdigest(),'after_sha256':hashlib.sha256(new).hexdigest()}
(OUT/'unrelated_arrays.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
