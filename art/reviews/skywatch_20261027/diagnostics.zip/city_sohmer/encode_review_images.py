from pathlib import Path
from PIL import Image
import hashlib,json
out=Path('C:/ov/reports/city_sohmer_20261028');folder=out/'review_images';folder.mkdir(exist_ok=True);rows=[]
for name in ['site_far_e.png','factory_clock_0000.png','factory_clock_0180.png','factory_clock_0735.png']:
 source=out/'imported_bound'/name;target=folder/(source.stem+'.webp')
 with Image.open(source) as im:
  im.load();im.save(target,'WEBP',lossless=True,quality=100,method=6)
  with Image.open(target) as decoded:assert decoded.convert(im.mode).tobytes()==im.tobytes()
  rows.append({'source':str(source),'source_png_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'webp':target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'mode':im.mode,'size':list(im.size),'pixel_sha256':hashlib.sha256(im.tobytes()).hexdigest(),'pixel_exact':True,'bytes':target.stat().st_size})
(out/'lossless_review_images.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Lossless image representation; decoded pixels verified exact against actual Godot PNGs. Original PNG bytes retained externally with hashes.','images':rows},indent=2)+'\n');print('Lossless reviewed images:',sum(v['bytes'] for v in rows),'bytes')
