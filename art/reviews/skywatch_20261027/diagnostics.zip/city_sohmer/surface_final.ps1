$ErrorActionPreference='Stop'
Set-Location -LiteralPath C:/PleaseRemainOnTheLine
Remove-Item Env:AGENDA_QUERY_ONLY,Env:AGENDA_QUERY_PROFILE,Env:V2_PROFILE_RELEASES,Env:SKYWATCH_MIRAGE_PROFILE,Env:WEATHER_RESOURCE_SCOPE_CONTROL,Env:WEATHER_LIFECYCLE_REVIEW,Env:WEATHER_FALLOUT_RELOAD,Env:WEATHER_PRECIP_REVIEW,Env:SKY_LIBRARY_YEAR,Env:SKY_NATIVE_SAMPLING_PLAN,Env:SKY_REVIEW_SHADER_SOURCE,Env:SKYWATCH_OPTICAL_REVIEW,Env:WEATHER_SIMULATE,Env:WEATHER_FORMATION,Env:WEATHER_PHENOMENON,Env:DAYNIGHT_FORCE -ErrorAction SilentlyContinue
$env:ORISON_SURFACE_SKIP_FIRE_INTERACTION='1'
$env:SKYWATCH_CLOUD_PROFILE='1'
$nativeArgs=@('--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440')
$runs=@(
    @{scene='res://tests/OrisonV2SurfaceInventory.tscn';runner='long';timeout=1200;windowed=$true;shot_dir='C:/ov/reports/city_sohmer_20261028/surface_final';log='C:/ov/reports/city_sohmer_20261028/surface_final.log';extra_args=$nativeArgs}
)
$runs | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath C:/ov/reports/city_sohmer_20261028/surface_final_batch.json -Encoding utf8
& ./tools/lane.ps1 batch -BatchFile C:/ov/reports/city_sohmer_20261028/surface_final_batch.json -WaitMinutes 15
exit $LASTEXITCODE
