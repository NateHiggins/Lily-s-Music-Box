from pathlib import Path
import json,struct,numpy as np
root=Path.cwd();raw=(root/'game/assets/props/city_elevations.glb').read_bytes();chunks={};pos=12
while pos<len(raw):
 n,kind=struct.unpack_from('<II',raw,pos);chunks[kind]=raw[pos+8:pos+8+n];pos+=8+n
d=json.loads(chunks[0x4e4f534a]);blob=chunks[0x004e4942];parents={child:i for i,node in enumerate(d['nodes']) for child in node.get('children',[])}
def transform(i):
 n=d['nodes'][i]
 if 'matrix' in n:m=np.array(n['matrix']).reshape(4,4).T
 else:
  x,y,z,w=n.get('rotation',[0,0,0,1]);m=np.eye(4);m[:3,:3]=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])@np.diag(n.get('scale',[1,1,1]));m[:3,3]=n.get('translation',[0,0,0])
 return transform(parents[i])@m if i in parents else m
points={}
for i,node in enumerate(d['nodes']):
 if 'mesh' not in node or '__clock_' not in node['name']:continue
 p=d['meshes'][node['mesh']]['primitives'][0];a=d['accessors'][p['attributes']['POSITION']];b=d['bufferViews'][a['bufferView']];v=np.ndarray((a['count'],3),dtype='<f4',buffer=blob,offset=b.get('byteOffset',0)+a.get('byteOffset',0),strides=(b.get('byteStride',12),4));points[node['name']]=(np.column_stack((v,np.ones(len(v))))@transform(i).T)[:,:3]
meta=json.loads((root/'game/data/orison_v2/exterior/city_elevations.json').read_text());results=[]
for hand in meta['clock_hands']:
 if hand['period_minutes']!=60:continue
 hour=hand['part'].replace('_minute__','_hour__');axis=np.array(hand['normal']);gap=float(min(points[hand['part']]@axis)-max(points[hour]@axis));assert .0078<gap<.0082,(hand['part'],gap);results.append({'minute':hand['part'],'hour':hour,'exported_float32_clearance_m':gap})
assert len(results)==4
out=Path('C:/ov/reports/city_sohmer_20261028');(out/'hand_clearance.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Decoded float32 GLB transformed plate geometry, not a loaded-Godot gap measurement.','faces':results},indent=2)+'\n');print(results)
