$ErrorActionPreference='Stop'
Set-Location -LiteralPath C:/PleaseRemainOnTheLine
$env:GIT_OPTIONAL_LOCKS='0'
$arguments=@('--editor','--import')
& ./tools/lane.ps1 run -Runner serial -TimeoutSeconds 175 -LogPath C:/ov/reports/city_sohmer_20261028/import.log -ExtraArgs $arguments -WaitMinutes 15
exit $LASTEXITCODE
