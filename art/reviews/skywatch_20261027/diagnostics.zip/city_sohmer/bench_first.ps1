$ErrorActionPreference='Stop'
Set-Location -LiteralPath C:/PleaseRemainOnTheLine
$nativeArgs=@('--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440')
& ./tools/lane.ps1 run -Scene res://tests/V2CityElevationBench.tscn -Runner serial -TimeoutSeconds 175 -Windowed -ShotDir C:/ov/reports/city_sohmer_20261028/imported_first -LogPath C:/ov/reports/city_sohmer_20261028/bench_first.log -ExtraArgs $nativeArgs -WaitMinutes 15
exit $LASTEXITCODE
