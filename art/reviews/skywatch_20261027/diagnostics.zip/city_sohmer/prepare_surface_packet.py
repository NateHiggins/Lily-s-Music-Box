from pathlib import Path
import gzip,json,shutil,hashlib
out=Path(__file__).parent;source=out/'surface_final';dest=out/'surface_packet';dest.mkdir(exist_ok=True)
contract=json.loads((source/'runtime_contract.json').read_text());assert contract['execution']['completed'] and contract['execution']['exit_code']==0
observations={
 'city_street_skyline.png':'Brick courses, window surrounds, slatted blinds and the lower rooftop tank/supports remain present together. Representative technical review after publication repair; individual city identities remain unfinished.',
 'city_weather_storm.png':'Roof tanks, aerials and supports remain visible through warm grey/sepia storm haze. The near-flat, very low-contrast storm ceiling remains weather presentation debt; this image does not approve the dramatic or annual sky.',
 'front_gallery_05.png':'Timber wainscot, pale plaster, speckled floor, curtains and blind slats remain separate. Strong ceiling highlights remain a presentation limit; no lighting-art acceptance is granted.',
 'street_paving.png':'Kerb profiles, paving joints, dark asphalt and brick masonry remain distinct. Street exposure is dark; this is not a new wet/dry equivalence or traffic acceptance claim.',
 'front_restored_entrance.png':'The installed panelled door, brass pulls, glazed marquee and brick/trim surround remain present together. The requested larger entrance remodel and every join are not accepted by this frame.',
 'public_arcade_hall.png':'Diner counter/stools, laundry stock, cart, masonry, timber panels, pale paving, canopy ribs and coloured light remain present through the public arcade. No claim that every storefront clearance or interaction has been accepted.',
 'tile_F02_A_BATH_corner.png':'Tile wainscot stops below plaster with a finishing cap against the door surround. Floor hexagons, curtain folds, rings and exposed plumbing remain distinct; this does not renew plumbing or shower input acceptance.'}
images=[]
for name,observation in observations.items():
 shutil.copyfile(source/name,dest/name);images.append({'file':name,'sha256':hashlib.sha256((dest/name).read_bytes()).hexdigest(),'observation':observation,'origin':'Agent inspected actual 3440x1440 fullscreen composed V2 capture, patched Vulkan. Technical visual review only; not human artistic acceptance.'})
for name in ['runtime_contract.json','surface-inventory.json']:shutil.copyfile(source/name,dest/name)
shutil.copyfile(out/'surface_final.log.receipt.json',dest/'suite_run.receipt.json')
for channel,suffix in [('stdout','.log'),('stderr','.log.stderr')]:
 (dest/f'suite_run.{channel}.log.gz').write_bytes(gzip.compress((out/('surface_final'+suffix)).read_bytes(),mtime=0))
(dest/'visual_review.json').write_text(json.dumps({'evidence_class':'INERT','status':'PASS','surface_inputs_sha256':contract['surface_inputs_sha256'],'images':images},indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared exact test-written packet and seven actually inspected optical images')
