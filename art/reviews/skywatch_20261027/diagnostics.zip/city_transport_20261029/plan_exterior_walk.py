import json,heapq,math
from pathlib import Path
root=Path('C:/ov/city')
h=json.loads((root/'art/data/city_horizon/source_plan.json').read_text())['buildings']
front=next(r for r in json.loads((root/'game/data/orison_v2_blockout.json').read_text())['doors'] if r['id']=='F01_DOOR_06')['center'][1]
rects=[]
for row in h:
    a,b,c,d=row['rect'];rects.append((-c-.8,front-d-.8,-a+.8,front-b+.8))
def clear(a,b):
    for x,z,X,Z in rects:
        low,high=0.,1.
        for p,q,lo,hi in [(a[0],b[0],x,X),(a[1],b[1],z,Z)]:
            if abs(q-p)<1e-9:
                if not lo<p<hi:low=2.;break
            else:
                t,u=sorted([(lo-p)/(q-p),(hi-p)/(q-p)]);low=max(low,t);high=min(high,u)
        if low<high and low<1 and high>0:return False
    return True
def solve(start,goal):
    queue=[(0,start)];cost={start:0};parent={}
    while queue:
        _,p=heapq.heappop(queue)
        if p==goal:break
        for dx,dz in [(2,0),(-2,0),(0,2),(0,-2),(2,2),(2,-2),(-2,2),(-2,-2)]:
            q=p[0]+dx,p[1]+dz
            if abs(q[0])>320 or abs(q[0])<100 or not -120<=q[1]<=80 or not clear(p,q):continue
            c=cost[p]+math.hypot(dx,dz)
            if c<cost.get(q,1e99):cost[q]=c;parent[q]=p;heapq.heappush(queue,(c+math.dist(q,goal),q))
    assert goal in cost
    path=[goal]
    while path[-1]!=start:path.append(parent[path[-1]])
    path.reverse();result=[path[0]];i=0
    while i<len(path)-1:
        j=len(path)-1
        while not clear(path[i],path[j]):j-=1
        result.append(path[j]);i=j
    return result
result={'evidence_class':'INERT','scope':'Inflated source footprints guide routes; actual controller and collision still required.','east':solve((140,-10),(280,-10)),'west':solve((-140,-10),(-280,-10))}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
