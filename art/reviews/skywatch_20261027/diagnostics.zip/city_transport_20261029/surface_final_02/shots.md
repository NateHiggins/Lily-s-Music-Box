
## shot_001.png
pos (-35.20, 1.60, 9.41)  yaw 0.0  pitch 17.9
looking at: OrisonV2Runtime/CityShells/city_elevations/site_nw2__mirror_agedCollision  @ world (-35.20, 5.87, -3.81)  13.89 m away
stand: @-35.20_1.60_9.41:0.0|17.9
note:
