"""Append this checkpoint's original diagnostics, preserving archive history."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,zipfile
parser=argparse.ArgumentParser();parser.add_argument('--packet')
parser.add_argument('--phase',choices=['construction','qualification'],required=True)
args=parser.parse_args();P=Path(__file__).parent;R=Path('C:/ov/city')
archive=R/'art/reviews/skywatch_20261027/diagnostics.zip'
index=archive.with_name('manifest.json');prefix='city_transport_20261029/'
def sha(raw):return hashlib.sha256(raw).hexdigest()
manifest=json.loads(index.read_text());old_index=dict(manifest['members'])
assert sha(archive.read_bytes())==manifest['archive_sha256']
with zipfile.ZipFile(archive) as z:
    old={n:sha(z.read(n)) for n in z.namelist()}
assert args.phase!='construction' or not (P/'surface_final_01.log').exists(), 'Do not archive a live surface log'
assert args.phase!='qualification' or args.packet
played=json.loads((P/'open_exterior_04/city_exterior_contract.json').read_text())
assert played['execution']['completed'] and played['execution']['exit_code']==0 and not played['failures']
contract=None
if args.packet:
    packet=P/args.packet;contract=json.loads((packet/'runtime_contract.json').read_text())
    assert contract['execution']['completed'] and contract['execution']['exit_code']==0
    assert contract['evidence_kind']=='runtime_contract' and contract['schema_version']==2
texts={'.json','.log','.stderr','.txt','.py','.ps1','.gd','.md','.gz','.npz'}
files=[f for f in P.rglob('*') if f.is_file() and f.suffix in texts and 'previous_surface_packet' not in f.parts]
files += [P/name for name in [
 'native_composition_03/open_west_frontage.png',
 'native_composition_03/open_scaffold.png',
 'native_review_04/near_overview.png',
 'open_shed_native_01/approach_candidate.png',
 'open_exterior_04/plaza_approach.png',
 'open_exterior_04/public_entry.png',
 'open_exterior_04/upper_platform_0.png',
 'open_exterior_04/street_-280.png',
 'open_exterior_04/street_280.png'] if (P/name).is_file()]
pending=P/'city_transport_pending_archive.zip';assert not pending.exists()
shutil.copyfile(archive,pending);members={}
with zipfile.ZipFile(pending,'a',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted(set(files)):
        name=prefix+f.relative_to(P).as_posix();raw=f.read_bytes()
        if name in old:
            assert old[name]==sha(raw), 'Never overwrite earlier evidence: '+name
            continue
        z.writestr(name,raw);members[name]=sha(raw)
    external={f.relative_to(P).as_posix():dict(bytes=f.stat().st_size,sha256=sha(f.read_bytes()))
              for f in P.rglob('*') if f.is_file() and f!=pending and f.suffix in {'.png','.npz','.zip'} }
    raw=(json.dumps(dict(evidence_class='INERT',scope='External originals, hash index only; not implementation or acceptance.',root=str(P),files=external),indent=2)+'\n').encode()
    name=prefix+'external_media_index_'+args.phase+'.json';assert name not in old
    z.writestr(name,raw);members[name]=sha(raw)
with zipfile.ZipFile(pending) as z:
    assert all(sha(z.read(n))==h for n,h in old.items())
    assert all(sha(z.read(n))==h for n,h in members.items())
assert pending.stat().st_size<100_000_000, 'Keep existing archive below the remote blob limit'
os.replace(pending,archive)
manifest['members'].update(members);manifest['archive_sha256']=sha(archive.read_bytes())
assert all(manifest['members'][n]==h for n,h in old_index.items())
phase_key='city_transport_'+args.phase+'_20261029';assert phase_key not in manifest
manifest[phase_key]=dict(
 evidence_class='INERT',base='3ea80715bd201738d5566dea18bc17d4353ca867',
 branch='codex/v2-city-20261029',raw_prefix=prefix,
 scope='Native elevated plaza/station and seven retained eastern assembly placements; open exterior with temporary450m collision wall. No whole-city, train service, sleep event or artistic acceptance.',
 prior_members_preserved=len(old),new_members=len(members),played_checks=228,
 played_waypoints=164,surface_checks=contract.get('checks') if contract else None,
 full_surface_status='qualified' if contract else 'pending; construction checkpoint is not a merge candidate',
 surface_contracts=contract['contracts'] if contract else None,measurements=prefix+'open_exterior_04/timing_summary.json',
 replay_identity=prefix+'open_replay_identity_03.json',failures_retained=True,
 source_snapshot_scope='Original failed sources/logs/receipts; exact successful contracts and numerical diagnostics. Selected actual captures embedded; remaining originals externally indexed. No reference photographs included.')
index.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Preserved',len(old),'members; added',len(members),'archive bytes',archive.stat().st_size)
