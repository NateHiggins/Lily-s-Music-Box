"""Review only the removed-hoarding delta before refreshing paving provenance."""
from pathlib import Path
import hashlib,json,subprocess
R=Path('C:/ov/city');P=Path(__file__).parent;old_dir=P/'paving_before_closure_01';old_dir.mkdir(exist_ok=True)
def sha(raw):return hashlib.sha256(raw).hexdigest()
relative='game/data/orison_v2/exterior/construction_shed.json'
old=json.loads(subprocess.check_output(['git','-C',str(R),'show','8f7d81f3:'+relative]))
current=json.loads((R/relative).read_text())
removed={'ClosureCrossbrace','ClosureNoticeBoard','ShedEastHoarding','ShedInnerReturn','ShedInnerStreetHoarding','ShedRoadHoarding','ShedTemporaryClosure'}
assert {r['id'] for r in old['boxes']}-{r['id'] for r in current['boxes']}==removed
assert [r for r in old['boxes'] if r['id'] not in removed]==current['boxes']
assert {k:v for k,v in old.items() if k!='boxes'}=={k:v for k,v in current.items() if k!='boxes'}
paths=['art/blender/front_pavement_construction.json','game/tests/fixtures/orison_front_pavement_construction.json']
data=[json.loads((R/p).read_text()) for p in paths];assert data[0]==data[1]
fixture=data[0];lo,hi=fixture['y'];a,b,c,d=fixture['envelope']
door=next(r for r in json.loads((R/'game/data/orison_v2_blockout.json').read_text())['doors'] if r['id']=='F01_DOOR_06')['center'][1]
def projection(source):
    result=[]
    for r in source['boxes']:
        x,y,z=r['center'];sx,sy,sz=r['size']
        if y-sy/2>=hi or y+sy/2<=lo:continue
        assert r.get('roll_degrees',0)==0
        rect=[-x-sx/2,door-z-sz/2,-x+sx/2,door-z+sz/2]
        if rect[2]>a and rect[0]<c and rect[3]>b and rect[1]<d:
            result.append(dict(owner='StreetBoundaries/'+r['id'],bounds=rect,kind='retained_authored_shed_solid'))
    return result
native_masks=[r for r in fixture['masks'] if r['kind']=='retained_authored_shed_solid']
assert projection(old)==projection(current)==native_masks
asset=R/'game/assets/props/front_pavement.glb';assert sha(asset.read_bytes())==fixture['asset_sha256']
hashes={p:sha((R/p).read_bytes()) for p in ['art/blender/front_pavement.blend','game/assets/props/front_pavement.glb']}
pin=sha((R/relative).read_bytes().replace(b'\r\n',b'\n'))
for path,document in zip(paths,data):
    backup=old_dir/('native_construction.json' if path.startswith('art/') else 'fixture_construction.json');assert not backup.exists();backup.write_bytes((R/path).read_bytes())
    previous=document['source_bindings'][relative];document['source_bindings'][relative]=pin
    (R/path).write_text(json.dumps(document,indent=2)+'\n',encoding='utf-8',newline='\n')
review=R/'game/tests/fixtures/orison_front_pavement_review.json'
(old_dir/'consumed_review.json').write_bytes(review.read_bytes())
result=dict(evidence_class='INERT',scope='Exact consumed shed-mask equivalence before metadata refresh. Native/export geometry retained, not runtime qualification.',removed_above_slab=sorted(removed),retained_records_exact=True,other_source_fields_exact=True,shed_masks=native_masks,native_geometry_hashes=hashes,old_binding=previous,new_binding=pin,total_masks=len(fixture['masks']),parts=len(fixture['parts']),volume_m3=fixture['volume_m3'])
(P/'paving_source_equivalence_01.json').write_text(json.dumps(result,indent=2)+'\n')
print('PAVING SOURCE EQUIVALENCE:',len(removed),'removed; retained masks exact; native/export unchanged')
