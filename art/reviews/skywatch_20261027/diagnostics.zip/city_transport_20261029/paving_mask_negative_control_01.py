"""Read-only native guard control: a fresh hash cannot hide a shifted floor."""
from pathlib import Path
import hashlib,json,os,runpy
from unittest.mock import patch
R=Path('C:/ov/city');P=Path(__file__).parent
source=R/'game/data/orison_v2/exterior/construction_shed.json'
fixture=R/'game/tests/fixtures/orison_front_pavement_construction.json'
read_text=Path.read_text;read_bytes=Path.read_bytes
wrong=json.loads(read_text(source))
next(r for r in wrong['boxes'] if r['id']=='ShedTurnFloor')['center'][0]+=.05
payload=(json.dumps(wrong,indent=2)+'\n').encode()
document=json.loads(read_text(fixture))
document['source_bindings'][source.relative_to(R).as_posix()]=hashlib.sha256(payload).hexdigest()
fixture_payload=(json.dumps(document,indent=2)+'\n').encode()
def raw(path):
    if path.resolve()==source:return payload
    if path.resolve()==fixture:return fixture_payload
    return None
def altered_text(path,*args,**kwargs):
    value=raw(path)
    return value.decode() if value is not None else read_text(path,*args,**kwargs)
def altered_bytes(path):
    value=raw(path)
    return value if value is not None else read_bytes(path)
os.environ['STREET_REVIEW_OUT']=str(P/'paving_mask_negative_control_01')
os.environ['STREET_WRITE_REVIEW']='0'
with patch.object(Path,'read_text',altered_text),patch.object(Path,'read_bytes',altered_bytes):
    try:runpy.run_path(str(R/'art/blender/scripts/inspect_front_pavement.py'),run_name='__main__')
    except AssertionError as error:
        assert str(error)=='Current shed floor masks differ from the saved native slab',str(error)
        result=dict(evidence_class='INERT',status='PASS',scope='In-memory5cm floor shift plus matching whole-file binding rejected by consumed-mask guard. No disk-source modification or runtime proof.',rejection=str(error))
    else:raise AssertionError('A shifted floor with a fresh hash was accepted')
(P/'paving_mask_negative_control_01.json').write_text(json.dumps(result,indent=2)+'\n')
print('PAVING MASK NEGATIVE CONTROL: PASS; fresh hash did not hide shifted floor')
