"""Archive only this isolated worktree's generated EOL/UID import churn."""
from pathlib import Path
import subprocess,json,zipfile,io,sys
R=Path('C:/ov/city').resolve();O=Path(__file__).parent
KEEP={'game/scripts/building/orison_v2_city_transport.gd.uid',
      'game/tests/v2_city_transport_bench.gd.uid',
      'game/tests/v2_city_transport_route.gd.uid'}
def git(*args):return subprocess.check_output(['git','-C',str(R),*args],stderr=subprocess.DEVNULL)
sys.path.insert(0,str(R/'tools'))
from run_receipt import runtime_inputs_sha256
before=runtime_inputs_sha256(R)
for p in KEEP:
    assert (R/p).is_file(),p
    prior=subprocess.run(['git','-C',str(R),'show','origin/main:'+p],capture_output=True)
    assert prior.returncode!=0 or prior.stdout==(R/p).read_bytes(),p
paths=[p.decode() for p in git('ls-files','-m','-z').split(b'\0') if p and p.decode().endswith('.import')]
batch=subprocess.run(['git','-C',str(R),'cat-file','--batch'],input=''.join(':'+p+'\n' for p in paths).encode(),capture_output=True,check=True)
stream=io.BytesIO(batch.stdout);restored=[];meaningful=[]
for p in paths:
    header=stream.readline().split();assert len(header)==3 and header[1]==b'blob',(p,header)
    indexed=stream.read(int(header[2]));assert stream.read(1)==b'\n'
    actual=(R/p).read_bytes()
    (restored if actual.replace(b'\r\n',b'\n')==indexed.replace(b'\r\n',b'\n') else meaningful).append(p)
uids=[p.decode() for p in git('ls-files','--others','--exclude-standard','-z').split(b'\0') if p and p.decode().endswith('.uid') and p.decode() not in KEEP]
archive=O/'final_owned_import_churn.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in restored+uids:z.write(R/p,p)
for i in range(0,len(restored),100):
    subprocess.run(['git','-C',str(R),'restore','--worktree','--',*restored[i:i+100]],check=True)
for p in uids:
    target=(R/p).resolve();assert target.is_relative_to(R) and target.suffix=='.uid';target.unlink()
after=runtime_inputs_sha256(R);assert before==after
report=dict(evidence_class='INERT',restored_eol_only_to_index=restored,
            removed_own_generated_uids=uids,preserved_new_uids=sorted(KEEP),
            meaningful_import_changes_preserved=meaningful,runtime_inputs_before=before,runtime_inputs_after=after)
(O/'final_owned_import_churn.json').write_text(json.dumps(report,indent=2)+'\n')
print(len(restored),'EOL-only imports restored;',len(uids),'own generated UIDs archived/removed; meaningful preserved:',meaningful)
