from pathlib import Path
import json,gzip,hashlib,shutil
P=Path(__file__).parent;packet=P/'surface_final_03'
contract=json.loads((packet/'runtime_contract.json').read_text())
observations={
'city_open_west_frontage.png':'Retired barricade is absent; retained brick/plaster rows, surrounds, cornices and roof tanks remain. Generic distant stock, unfinished streets and dark exposure remain city presentation debt.',
'construction_closure_carried.png':'Former closure is open beneath the retained scaffold, with seated timber posts and grain; station stairs/steel remain beyond. Raw dark street surfaces remain unfinished.',
'street_paving.png':'Retained brick, curb profiles, joints, damp film, gas lamps, drainpipe, bodega access and period traffic remain together beneath station steel. Dark exposure and placeholder props remain limitations.',
'front_restored_entrance.png':'Installed door, brass pulls, glazed marquee, Orison blade, masonry, sash and blinds remain in place. This is the installed entrance, not the reserved entrance prototype.',
'public_arcade_hall.png':'Retained luncheonette, laundry, storefronts, handcart, bench, glass/iron canopy and paving remain together. Bright upper fascia remains an existing lighting limitation; no new shop authority acceptance.',
'city_weather_storm.png':'Tank and aerial silhouettes remain low against warm grey haze. The flat, low-contrast sky is not weather artistic acceptance; weather implementation is unchanged.',
'front_gallery_05.png':'Retained timber panels, plaster, speckled floor, curtains, blinds and benches remain distinct. Strong ceiling glare remains an existing limitation; interiors are unchanged.',
'tile_F02_A_BATH_corner.png':'Unchanged subway tile, hexagonal floor, glazed basin, plumbing, curtain rings and door remain distinct. No new apartment or bathroom interaction acceptance.'}
review=dict(evidence_class='INERT',status='PASS',surface_inputs_sha256=contract['surface_inputs_sha256'],scope='Representative technical inspection of actual fullscreen 3440x1440 patched-Vulkan captures. No whole-city, human artistic, weather, narrative or save-reconstruction acceptance.',images=[])
for name,observation in observations.items():
    raw=(packet/name).read_bytes()
    review['images'].append(dict(file=name,sha256=hashlib.sha256(raw).hexdigest(),observation=observation,origin='Agent inspected this actual surface_final_03 capture; no generated or substituted image.'))
(packet/'visual_review.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(P/'surface_final_03.log.receipt.json',packet/'suite_run.receipt.json')
for channel,suffix in [('stdout','.log'),('stderr','.log.stderr')]:
    (packet/('suite_run.'+channel+'.log.gz')).write_bytes(gzip.compress((P/('surface_final_03'+suffix)).read_bytes(),mtime=0))
print('Packaged',len(review['images']),'actually reviewed captures',contract['surface_inputs_sha256'])
