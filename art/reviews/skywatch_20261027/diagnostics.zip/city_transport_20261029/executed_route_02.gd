extends "res://tests/v2_city_west_frontage.gd"
## Continuous installed street-to-station access with the actual five-foot body.
## The retained crossing/frontage/door programme runs first in the same world.
var programme_before: Dictionary = {}

func _ready() -> void:
	super._ready()
	route_label = "V2 EASTERN TRANSPORT"

func _programme_sources() -> Dictionary:
	var result: Dictionary = {}
	for path: String in ["res://tests/v2_city_transport_route.gd", "res://tests/v2_city_west_frontage.gd", "res://tests/orison_v2_street_crossing_test.gd", "res://tests/orison_v2_vertical_route_test.gd", "res://tests/orison_v2_first_slice_contract_test.gd", "res://tests/fixtures/orison_city_transport.json", "res://assets/props/city_transport.glb", "res://assets/props/city_transport_lod1.glb", "res://assets/props/orison_ground.glb", "res://assets/props/city_foundations.glb", "res://assets/props/city_elevations.glb"]:
		result[path] = FileAccess.get_file_as_string(path).replace("\r\n", "\n").sha256_text() if path.get_extension() in ["gd", "json"] else FileAccess.get_sha256(path)
	return result

func _run() -> void:
	programme_before = _programme_sources()
	city_observations["programme_sources"] = programme_before
	await super._run()

func _evidence_scope() -> String:
	return "Production controller through retained frontage, crossing and door hand programme, then eastern dogleg, public station entry, both lower and upper islands and return. No train service, save reconstruction, whole city or artistic acceptance."

func _evidence_file() -> String:
	return "transport_route_contract.json"

func _city_walk(point: Vector3) -> bool:
	var city := world.get_node("CityShells") as Node3D
	print("CITY STATION WALK: source target ",point)
	var reached := await _walk(world.adapter.root.to_local(city.to_global(GameBoot.b2g([point.x, point.y, point.z]))))
	print("CITY STATION WALK: reached=",reached," actual world=",player.global_position)
	return reached

func _station_view(label: String, target: Vector3) -> void:
	var city := world.get_node("CityShells") as Node3D
	player.face_world_point(city.to_global(GameBoot.b2g([target.x,target.y,target.z])))
	await get_tree().create_timer(.25).timeout
	await RenderingServer.frame_post_draw
	var directory := OS.get_environment("SHOT_DIR")
	check(not directory.is_empty() and get_viewport().get_texture().get_image().save_png(directory.path_join(label+".png")) == OK, "actual standing station capture: " + label)

func _stairs(route: Dictionary, up: bool) -> bool:
	var from: Array = route.from_m
	var to: Array = route.to_m
	var lane := lane_from_route(route)
	var x := float(from[0])
	var y := float(from[1])
	var low := float(from[2])
	var high := float(to[2])
	var count := roundi((high - low) / (2. * float(route.riser_m)))
	var run := count * float(route.tread_m)
	# Land well inside each real landing before reversing direction. The run
	# itself is traversed under continuous controller input, never by teleport.
	var points: Array[Vector3] = [Vector3(x-.5,y,low), Vector3(x+run+.65,y,(low+high)/2.), Vector3(x+run+.65,y+lane,(low+high)/2.), Vector3(x-.5,y+lane,high)]
	if not up: points.reverse()
	for point: Vector3 in points:
		if not await _city_walk(point): return false
	return true

func _route() -> void:
	await super._route()
	if not failures.is_empty(): return
	# This is a third use of the live leaf, whose closer may leave it partly
	# open. Approach the actual hinge-side contact before grabbing again.
	for point: Vector3 in [Vector3(1.925,0,-6.5),Vector3(0,0,-7.65),Vector3(0,0,-10.2),Vector3(0,0,-10.8)]:
		if not await _walk(point): return
	if not await _open_front_entrance(): return
	if not await _walk(Vector3(0,0,-12.2)): return
	# Existing construction shed remains physical. Follow its genuine roadward
	# dogleg before entering the larger public plaza from the existing sidewalk.
	for point: Vector3 in [Vector3(0,0,3),Vector3(14,0,3),Vector3(18,0,4.2),Vector3(25,0,4.2),Vector3(30,0,3)]:
		if not await _walk(world.adapter.root.to_local(point)): return
	for point: Vector3 in [Vector3(40,-12.8,0),Vector3(40,8,0),Vector3(31,8,0),Vector3(31.5,4.2,0)]:
		if not await _city_walk(point): return
	await _station_view("public_entry",Vector3(38,5,4))
	var station := world.get_node("CityShells/EasternPlazaStation") as Node3D
	var checked_materials: Dictionary = {}
	for draw: MeshInstance3D in station.find_children("*","MeshInstance3D",true,false):
		var material := draw.material_override as StandardMaterial3D
		check(material != null and not material.uv1_triplanar, "composed station keeps authored maps: " + str(draw.name))
		if material != null and not checked_materials.has(material.get_instance_id()):
			checked_materials[material.get_instance_id()] = true
			for texture: Texture2D in [material.albedo_texture,material.roughness_texture,material.normal_texture]:
				check(texture != null and texture.get_image().has_mipmaps(), "composed station PBR mip chain")
	var fixture: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://tests/fixtures/orison_city_transport.json"))
	var routes: Dictionary = {}
	for row: Dictionary in fixture.stair_routes: routes[str(row.id)] = row
	check(routes.size() == 5, "one public entry and four platform stair connections")
	if not await _stairs(routes.PublicEntry, true): return
	var before := trace.size()
	for island in 2:
		var lower: Dictionary = routes["PlatformStair_0_"+str(island)]
		var upper: Dictionary = routes["PlatformStair_1_"+str(island)]
		var base: Array = lower.from_m
		for point: Vector3 in [Vector3(30.8,5.75,6.2),Vector3(30.8,float(base[1]),6.2)]:
			if not await _city_walk(point): return
		if not await _stairs(lower, true): return
		await _station_view("lower_platform_"+str(island),Vector3(86,float(lower.to_m[1]),float(lower.to_m[2])+1))
		var upper_base: Array = upper.from_m
		var bypass := float(base[1]) - 1.8
		var lower_top := float(lower.to_m[2])
		var upper_top := float(upper.to_m[2])
		for point: Vector3 in [Vector3(31.5,bypass,lower_top),Vector3(50,bypass,lower_top),Vector3(61.5,bypass,lower_top),Vector3(61.5,float(upper_base[1]),lower_top)]:
			if not await _city_walk(point): return
		if not await _stairs(upper, true): return
		await _station_view("upper_platform_"+str(island),Vector3(90,float(upper.to_m[1]),float(upper.to_m[2])+1))
		var end: Array = upper.to_m
		if not await _city_walk(Vector3(55,float(end[1]),upper_top)): return
		if not await _stairs(upper, false): return
		for point: Vector3 in [Vector3(61.5,bypass,lower_top),Vector3(50,bypass,lower_top),Vector3(31.5,bypass,lower_top),Vector3(31.5,float(base[1])+lane_from_route(lower),lower_top)]:
			if not await _city_walk(point): return
		if not await _stairs(lower, false): return
	if not await _city_walk(Vector3(30.8,5.75,6.2)): return
	if not await _stairs(routes.PublicEntry, false): return
	for point: Vector3 in [Vector3(31,8,0),Vector3(40,8,0),Vector3(40,-12.8,0)]:
		if not await _city_walk(point): return
	for point: Vector3 in [Vector3(30,0,3),Vector3(25,0,4.2),Vector3(18,0,4.2),Vector3(14,0,3),Vector3(0,0,3)]:
		if not await _walk(world.adapter.root.to_local(point)): return
	city_observations["station_route"] = {"completed":true,"platform_connections":4,"waypoints":trace.size()-before}
	check(not player.noclip and not player.crouched and is_equal_approx(player.STANDING_HEIGHT,1.524), "actual standing production body remained active")
	check(programme_before == _programme_sources(), "executed route sources and physical station/ground bodies remain frozen")

func lane_from_route(route: Dictionary) -> float:
	return float(route.to_m[1]) - float(route.from_m[1])
