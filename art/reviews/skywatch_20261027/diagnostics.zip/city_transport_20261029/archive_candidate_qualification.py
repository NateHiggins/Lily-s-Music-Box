"""Append original candidate diagnostics without replacing any earlier member."""
from pathlib import Path
import hashlib,json,os,shutil,zipfile
P=Path(__file__).parent;R=Path('C:/ov/city')
A=R/'art/reviews/skywatch_20261027/diagnostics.zip';M=A.with_name('manifest.json')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
m=json.loads(M.read_text());assert sha(A.read_bytes())==m['archive_sha256']
v=json.loads((P/'candidate_qualification_01/verification.json').read_text())
assert not v['blocking'] and not v['comparison']['regressions'] and not v['accepted_regressions']['lines']
assert v['protected']['matched']==17 and not v['fresh_checkout_dirty']
files=[P/'candidate_qualification_01'/n for n in ['verification.json','verification.md']]
files += [P/n for n in ['street_junction_discovery.py','street_junction_source_discovery.json','street_junction_source_discovery.png']]
files.append(Path(__file__))
with zipfile.ZipFile(A) as z:old={n:sha(z.read(n)) for n in z.namelist()}
pending=P/'candidate_pending_archive.zip';assert not pending.exists();shutil.copyfile(A,pending)
new={}
with zipfile.ZipFile(pending,'a',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in files:
        n='city_transport_20261029/'+f.relative_to(P).as_posix();assert n not in old
        raw=f.read_bytes();z.writestr(n,raw);new[n]=sha(raw)
with zipfile.ZipFile(pending) as z:
    assert all(sha(z.read(n))==h for n,h in {**old,**new}.items())
assert pending.stat().st_size<100_000_000
os.replace(pending,A);m['members'].update(new);m['archive_sha256']=sha(A.read_bytes())
m['city_transport_candidate_20261029']=dict(evidence_class='INERT',candidate=v['candidate'],base=v['base'],merge_base=v['merge_base'],gates=len(v['candidate_board']['gates']),regressions=0,accepted_regressions=0,protected='17/17',mode='in-place isolated city checkout; no new Godot execution',prior_members_preserved=len(old),new_members=len(new),scope='Static candidate verification plus source-only next-street discovery. Original surface03/open-route04 receipts remain separate runtime evidence. No merge or whole-city acceptance.')
M.write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Preserved',len(old),'members; added',len(new),'archive bytes',A.stat().st_size)
