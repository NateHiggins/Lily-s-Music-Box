extends Node3D
## Imported isolated station diagnostics. This does not qualify the composed city.
var failures: Array[String] = []
var checks := 0
var observations: Array[Dictionary] = []

func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures.append(label)
		push_error("TRANSPORT BENCH: " + label)

func _ready() -> void:
	call_deferred("_run")

func _run() -> void:
	RealityState.persistence_enabled = false
	var station := preload("res://scripts/building/orison_v2_city_transport.gd").mount(self)
	var data: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/orison_v2/exterior/city_transport.json"))
	var metrics := preload("res://tests/orison_v2_domestic_native_test.gd").new()
	var low_source := (load("res://assets/props/city_transport_lod1.glb") as PackedScene).instantiate()
	for draw: MeshInstance3D in low_source.find_children("*", "MeshInstance3D", true, false):
		metrics._check_cap_mapping(draw.mesh, true)
	low_source.free()
	var parts := 0
	for draw: MeshInstance3D in station.find_children("*", "MeshInstance3D", true, false):
		parts += 1
		var mesh := draw.mesh as ArrayMesh
		var surface := RenderingServer.mesh_get_surface(mesh.get_rid(), 0)
		var lods: Array = surface.get("lods", [])
		check(lods.size() == 1 and is_equal_approx(float(lods[0].edge_length), float(data.lod_error_m)), "real replacement index buffer: " + str(draw.name))
		metrics._check_cap_mapping(mesh, true)
		var material := draw.material_override as StandardMaterial3D
		check(material != null and not MatLib.is_shared_material(material) and not material.uv1_triplanar, "local authored UV finish: " + str(draw.name))
		for texture: Texture2D in [material.albedo_texture, material.roughness_texture, material.normal_texture]:
			check(texture != null and texture.get_image().has_mipmaps(), "loaded PBR mip chain: " + str(draw.name))
		var shape := draw.get_node("SourceCollision/NearSurface") as CollisionShape3D
		check((shape.shape as ConcavePolygonShape3D).get_faces() == mesh.get_faces(), "near-only visible collision: " + str(draw.name))
	check(parts == data.parts.size() and parts > 0, "nonempty source roster")
	check(metrics.failures.is_empty(), "imported metre charts and tangent metrics: " + str(metrics.failures))
	var environment := WorldEnvironment.new()
	environment.environment = Environment.new()
	environment.environment.background_mode = Environment.BG_COLOR
	environment.environment.background_color = Color(.24, .3, .36)
	environment.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.environment.ambient_light_color = Color(.7, .8, 1.)
	environment.environment.ambient_light_energy = .7
	add_child(environment)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-45, -30, 0)
	sun.light_energy = 2.
	sun.shadow_enabled = true
	add_child(sun)
	var camera := Camera3D.new()
	add_child(camera)
	camera.current = true
	var target := Vector3(65, 9, 10)
	camera.position = Vector3(65, 90, 240)
	camera.look_at(target)
	var viewport := get_viewport()
	var original_threshold := viewport.mesh_lod_threshold
	for row: Dictionary in [{"id":"forced_near", "threshold":0., "fov":75.}, {"id":"forced_far", "threshold":10000., "fov":75.}, {"id":"wide", "threshold":1., "fov":75.}, {"id":"narrow", "threshold":1., "fov":5.}]:
		viewport.mesh_lod_threshold = float(row.threshold)
		camera.fov = float(row.fov)
		for frame in 12: await get_tree().process_frame
		await RenderingServer.frame_post_draw
		var primitives := RenderingServer.viewport_get_render_info(viewport.get_viewport_rid(), RenderingServer.VIEWPORT_RENDER_INFO_TYPE_VISIBLE, RenderingServer.VIEWPORT_RENDER_INFO_PRIMITIVES_IN_FRAME)
		var calls := RenderingServer.viewport_get_render_info(viewport.get_viewport_rid(), RenderingServer.VIEWPORT_RENDER_INFO_TYPE_VISIBLE, RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME)
		observations.append({"id":row.id,"fov":camera.fov,"lod_threshold":viewport.mesh_lod_threshold,"visible_primitives":primitives,"visible_draw_calls":calls,"resolution":str(viewport.get_visible_rect().size)})
		var out := OS.get_environment("SHOT_DIR")
		if not out.is_empty():
			check(viewport.get_texture().get_image().save_png(out.path_join(str(row.id)+".png")) == OK, "render saved: " + str(row.id))
	check(int(observations[1].visible_primitives) < int(observations[0].visible_primitives), "forced far actually renders fewer triangles")
	check(int(observations[3].visible_primitives) > int(observations[2].visible_primitives), "narrow FOV selects more detail at the same distance")
	viewport.mesh_lod_threshold = original_threshold
	var output := OS.get_environment("SHOT_DIR")
	var sources: Dictionary = {}
	for path: String in ["res://tests/v2_city_transport_bench.gd", "res://scripts/building/orison_v2_city_transport.gd", "res://assets/props/city_transport.glb", "res://assets/props/city_transport_lod1.glb", "res://data/orison_v2/exterior/city_transport.json", "res://data/runtime_material_sets.json", "res://scripts/material_library.gd"]:
		sources[path] = FileAccess.get_sha256(path)
	var result := {"evidence_class":"INERT", "scope":"Isolated imported geometry, collision, PBR maps and per-view LOD diagnostics; no composed route, performance or artistic acceptance.", "checks":checks,"failures":failures,"observations":observations,"source_hashes":sources}
	if not output.is_empty(): FileAccess.open(output.path_join("transport_bench.json"), FileAccess.WRITE).store_string(JSON.stringify(result,"\t")+"\n")
	print("TRANSPORT BENCH: %d checks; %d failures" % [checks, failures.size()])
	get_tree().quit(0 if failures.is_empty() else 1)
