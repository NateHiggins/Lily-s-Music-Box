"""Preserve original inventories externally; avoid duplicating the primary packet."""
from pathlib import Path
import argparse,hashlib,json,runpy,sys
from unittest.mock import patch
parser=argparse.ArgumentParser();parser.add_argument('--packet',required=True)
args=parser.parse_args();P=Path(__file__).parent
contract=json.loads((P/args.packet/'runtime_contract.json').read_text())
assert contract['execution']['completed'] and contract['execution']['exit_code']==0
inventories={p.relative_to(P).as_posix():dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),external_original=str(p)) for p in P.rglob('surface-inventory.json')}
index=P/'surface_inventory_external_index_qualification.json';assert not index.exists()
index.write_text(json.dumps(dict(evidence_class='INERT',scope='Unmodified original full inventories remain at these external paths. Successful inventory is also published once in the existing project surface packet. Original test-written contracts and logs are embedded separately; this index is not runtime proof.',successful_packet=args.packet,files=inventories),indent=2)+'\n')
original=Path.rglob
def selection(path,pattern,*positional,**named):
    for item in original(path,pattern,*positional,**named):
        if item.name!='surface-inventory.json':yield item
previous=sys.argv
try:
    sys.argv=['archive_city_evidence.py','--phase','qualification','--packet',args.packet]
    with patch.object(Path,'rglob',selection):
        runpy.run_path(str(P/'archive_city_evidence.py'),run_name='__main__')
finally:sys.argv=previous
