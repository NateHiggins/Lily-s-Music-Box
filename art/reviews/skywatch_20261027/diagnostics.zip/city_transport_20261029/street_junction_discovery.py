"""Read-only source topology diagram; not collision or construction proof."""
from pathlib import Path
import json,hashlib
from PIL import Image,ImageDraw
R=Path('C:/ov/city');P=Path(__file__).parent
paths=['game/tests/fixtures/orison_city_elevations.json','art/data/city_elevations/source_plan.json','art/data/city_transport/source_plan.json','game/data/orison_v2/exterior/street_traffic.json']
e,p,t,v=[json.loads((R/n).read_text()) for n in paths]
offsets={b['id']:b.get('assembly_translation_m',[0,0,0]) for b in p['buildings']}
im=Image.new('RGB',(1600,1000),'#e8e3d7');d=ImageDraw.Draw(im)
def at(x,y):return ((x+125)*6,760-y*6)
def rect(b,fill,outline='#202020'):
    a,c=at(b[0],b[3]),at(b[2],b[1]);d.rectangle([a,c],fill=fill,outline=outline)
def label(x,y,text):d.text(at(x,y),text,fill='#101010')
for b in e['buildings']:
    r=b['main_rect'];o=offsets[b['id']];r=[r[0]+o[0],r[1]+o[1],r[2]+o[0],r[3]+o[1]]
    rect(r,'#b7a08d');label(r[0],r[3]+1,b['id'])
for lo,hi in [t['plaza']['y_ends_m'],t['plaza']['south_y_ends_m']]:rect([*t['plaza']['x_ends_m'][:1],lo,t['plaza']['x_ends_m'][1],hi],'#d1cfbc')
threshold=9.795;road=[-20.3,-threshold-v['site']['carriageway_z'][1],20.8,-threshold-v['site']['carriageway_z'][0]]
rect(road,'#4a5153');label(-20,-26,'RETAINED ROAD: top -0.10m')
discoveries=[]
for side in ['west','east']:
    x=v['junctions'][side+'_x'];a=x-v['junctions']['cross_half_width'];b=x+v['junctions']['cross_half_width'];y=-threshold-v['junctions']['center_z']
    # Dashed outlines indicate traffic corridors, not newly installed roads.
    for cy in range(-37,1,2):
        d.line([at(a,cy),at(a,cy+1)],fill='#1760a0',width=3);d.line([at(b,cy),at(b,cy+1)],fill='#1760a0',width=3)
    label(a,-35,side+' traffic corridor')
    near=[]
    for px in t['station']['bent_x_m']:
        for py in t['station']['column_y_m']:
            pad=[px-.4,py-.4,px+.4,py+.4]
            if pad[0]<b and pad[2]>a and -37<py<0:near.append(dict(column=[px,py],pad=pad))
    discoveries.append(dict(side=side,traffic_center_city_source_m=[x,y],cross_x_bounds_m=[a,b],station_pad_intersections=near))
for x in t['station']['bent_x_m']:
    for y in t['station']['column_y_m']:rect([x-.4,y-.4,x+.4,y+.4],'#862f23')
label(-120,110,'SOURCE TOPOLOGY ONLY: native city X/Y metres. Brown=retained building footprints; grey=station paving; red=station pads.')
label(-120,105,'Dashed blue=existing traffic cross-corridor. It is not an installed-road or full-height collision measurement.')
label(-120,100,'Orison/arcade/shops/scaffold detail is omitted here and requires the saved runtime/native survey before construction.')
im.save(P/'street_junction_source_discovery.png')
report=dict(evidence_class='INERT',scope='Read-only source topology; no new runtime or historical survey claim.',source_bindings={n:hashlib.sha256((R/n).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for n in paths},junctions=discoveries,remaining='Fit road/paving around actual occupied and access owners; cut station paving at the crossing; reserve foundation support and protect piers. No production edits yet.')
(P/'street_junction_source_discovery.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(discoveries,indent=2))
