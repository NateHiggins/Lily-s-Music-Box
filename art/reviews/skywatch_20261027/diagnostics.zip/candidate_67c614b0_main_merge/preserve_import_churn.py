from pathlib import Path
import subprocess,json,hashlib,shutil,datetime
root=Path.cwd().resolve();out=Path('C:/ov/reports/skywatch40/import_uid_churn');out.mkdir(parents=True,exist_ok=True)
rows=[(x[:2],x[3:]) for x in subprocess.check_output(['git','status','--porcelain','-z']).decode().split('\0') if x]
imports=[json.loads(p.read_text(encoding='utf-8'))['execution'] for p in Path('C:/ov/reports/skywatch40/candidate_qualified/godot').glob('import*.receipt.json')]
lo=min(datetime.datetime.fromisoformat(r['started_utc'].replace('Z','+00:00')).timestamp() for r in imports);hi=max(datetime.datetime.fromisoformat(r['finished_utc'].replace('Z','+00:00')).timestamp() for r in imports)
records=[];restored=[]
for status,name in rows:
 source=(root/name).resolve();assert source.is_relative_to(root/'game')
 if status=='??' and name.endswith('.uid'):
  assert lo<=source.stat().st_mtime<=hi,(name,source.stat().st_mtime)
  raw=source.read_bytes();assert raw.strip().startswith(b'uid://') and len(raw)<100
  target=out/'files'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
  records.append({'path':str(source),'backup':str(target),'sha256':hashlib.sha256(raw).hexdigest()})
 elif status==' M' and name.endswith('.import'):
  raw=source.read_bytes();original=subprocess.check_output(['git','show','HEAD:'+name])
  assert raw.replace(b'\r\n',b'\n')==original.replace(b'\r\n',b'\n'),name
  target=out/'line_endings'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
  subprocess.run(['git','restore','--',name],check=True);restored.append(name)
 else:raise ValueError('Unexpected work preserved: '+str((status,name)))
(out/'manifest.json').write_text(json.dumps({'scope':'Verifier import churn only; initial checkout clean, UID mtimes within import window, all bytes preserved externally','uid_files':records,'line_ending_only_restored':restored},indent=2)+'\n',encoding='utf-8',newline='\n')
print('Backed up',len(records),'generated UIDs; restored',len(restored),'line-ending-only sidecars')
