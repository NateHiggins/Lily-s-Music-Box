from pathlib import Path
import subprocess,json,collections,datetime
root=Path.cwd();raw=subprocess.check_output(['git','status','--porcelain','-z']).decode();rows=[(x[:2],x[3:]) for x in raw.split('\0') if x]
print('status counts',collections.Counter((status,Path(name).suffix) for status,name in rows))
for log in sorted(Path('C:/ov/reports/skywatch40/candidate_qualified/godot').glob('import*.receipt.json')):
 d=json.loads(log.read_text());print(log.name,d['execution'])
uids=[root/name for status,name in rows if status=='??' and name.endswith('.uid')]
print('untracked uid count',len(uids),'mtime range',min(datetime.datetime.fromtimestamp(p.stat().st_mtime).isoformat() for p in uids),max(datetime.datetime.fromtimestamp(p.stat().st_mtime).isoformat() for p in uids))
print('other changes',[(s,n) for s,n in rows if not(s=='??' and n.endswith('.uid'))][:12])
