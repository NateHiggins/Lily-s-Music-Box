# Candidate verification - 67c614b04561

- candidate `67c614b04561035d86e164f1fefd5d9f269e40f7`
- base `6ff8922fbedbd0ad8a224aabea283d7362783332`
- merge-base `6ff8922fbedbd0ad8a224aabea283d7362783332`
- verified 2026-10-27T20:59:59Z from verifier `67c614b04561`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 0 regressions, 0 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 4 |
| godot (import) | exit 0 |
| godot (import) | exit 0 |
| godot res://tests/CampaignWeatherTest.tscn | exit 0, receipt binds |

## Blocking reasons (0)

- none

## Needs human review (not blocking) (2)

- candidate changes 4 gate file(s); read those diffs before trusting the board
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (0)

- none

## Accepted regressions (0)

- none

## Improvements (0)

- none

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (4)

- M tools/audit_period_dates.py
- M tools/audit_v2_surfaces.py
- M tools/orison_spatial_dependency_manifest.json
- M tools/tests/test_v2_surface_requirements.py

MERGE-CANDIDATE 67c614b04561035d86e164f1fefd5d9f269e40f7
