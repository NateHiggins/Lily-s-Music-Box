from pathlib import Path
import re,json,hashlib
root=Path.cwd();out=Path('C:/ov/reports/skywatch42');out.mkdir(parents=True,exist_ok=True)
def flatten(path,stack=()):
 assert path not in stack,path
 text=path.read_text(encoding='utf-8')
 return re.sub(r'^\s*#include\s+"(res://[^"]+)"',lambda m:flatten(root/'game'/m.group(1).removeprefix('res://'),stack+(path,)),text,flags=re.M)
source=flatten(root/'game/shaders/queens_weather_sky.gdshader')
needle='vec3 footprint=abs(direction)*ds;';assert source.count(needle)==1
output='        COLOR=mix(combined,wx_haze_color(normalize(sun_direction)),1.0-exp(-tau));';assert source.count(output)==1
variants={'current':source,'shadow_half':source.replace(needle,'vec3 footprint=abs(direction)*ds*.5;'),'shadow_zero':source.replace(needle,'vec3 footprint=vec3(0.0);'),'no_analytic_haze':source.replace(output,'        tau=0.0;\n'+output)}
meta={}
for name,text in variants.items():
 p=out/(name+'.gdshader');p.write_text(text,encoding='utf-8',newline='\n');meta[name]=hashlib.sha256(p.read_bytes()).hexdigest()
 dates=[]
 for stamp,label in [('1929-01-08T12:00:00','cu'),('1929-01-30T08:59:00','flat_front'),('1929-02-25T08:39:00','flat_front_second'),('1929-06-25T18:00:00','cb'),('1928-12-12T23:00:00','winter_night'),('1929-10-29T23:00:00','autumn_night')]:dates.append({'date':stamp,'period':label,'seeds':[1928],'particle_control':True})
 run=[{'scene':'res://tests/V2SkySpectacleBench.tscn','runner':'long','timeout':300,'windowed':True,'shot_dir':str(out/name),'log':str(out/(name+'.log')),'extra_args':['--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440']}]
 (out/(name+'_batch.json')).write_text(json.dumps(run,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'plan.json').write_text(json.dumps({'calendar_sha256':hashlib.sha256((root/'game/data/weather/campaign_weather.json').read_bytes()).hexdigest(),'captures':dates},indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'controls.json').write_text(json.dumps({'evidence_class':'INERT','scope':'External controlled lighting-only shaders; production source unchanged; density, clock and sample count fixed','variants':meta},indent=2)+'\n',encoding='utf-8',newline='\n')
