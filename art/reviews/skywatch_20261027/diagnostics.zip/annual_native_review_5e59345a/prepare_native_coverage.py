from pathlib import Path
import json,hashlib,subprocess
out=Path('C:/ov/reports/skywatch41');r=json.loads((out/'annual_batch.json').read_text(encoding='utf-8'));r[0].update(log=str(out/'native_coverage.log'),shot_dir=str(out/'native_coverage'),timeout=1500)
(out/'native_coverage_batch.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('game/tests/v2_sky_spectacle_bench.gd');binding={'evidence_class':'INERT','base_commit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'test_sha256_lf':hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest(),'plan_sha256':hashlib.sha256((out/'annual_analysis/native_sampling_plan.json').read_bytes()).hexdigest(),'scope':'162 exact-minute native colour/cloud-alpha samples, seeded layout variants and twilight triplets; no artistic acceptance'}
(out/'native_source_before.json').write_text(json.dumps(binding,indent=2)+'\n',encoding='utf-8',newline='\n')
