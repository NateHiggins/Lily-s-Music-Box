from pathlib import Path
import json
for day in json.loads(Path('game/data/weather/campaign_weather.json').read_text(encoding='utf-8'))['days']:
 if day['date'] in ['1928-11-11','1928-11-24']:
  print(day['date'],day['kind']);print(str(day['frames'])[:1400])
