from pathlib import Path
import json,hashlib,zipfile,subprocess
r=Path.cwd();p=Path(__file__).parent;q=Path('C:/ov/reports/skywatch42');dest=r/'art/reviews/skywatch_20261027';archive=dest/'diagnostics.zip';prefix='annual_native_review_5e59345a/'
binding=json.loads((p/'native_source_binding.json').read_text());assert binding['status']=='PASS_EXACT_REQUESTS_AND_SOURCE'
assert not json.loads((p/'annual/annual_gallery.json').read_text()).get('failures')
files=[]
for folder in [p,p/'annual_analysis',p/'native_analysis',q]:
 for f in folder.iterdir():
  if f.is_file() and f.suffix in ['.json','.py','.log','.stderr','.gd','.gdshader','.jpg','.png']:
   files.append((f,('controls/' if folder==q else str(f.relative_to(p).parent).replace('\\','/')+'/').replace('./','')+f.name))
files.append((p/'annual/annual_gallery.json','annual/annual_gallery.json'))
for name in ['particle_controls','exact_minute_controls','native_coverage']:
 files.append((p/name/'native_detail.json',name+'/native_detail.json'))
for name in ['current','shadow_half','shadow_zero','no_analytic_haze']:
 files.append((q/name/'native_detail.json','controls/'+name+'/native_detail.json'))
# Raw native captures remain external, each content-hashed; contacts are for review only.
capture_hashes={}
for folder in [p/'native_coverage',p/'exact_minute_controls',p/'particle_controls']+[q/n for n in ['current','shadow_half','shadow_zero','no_analytic_haze']]:
 for f in folder.glob('*.png'):capture_hashes[str(f)]=hashlib.sha256(f.read_bytes()).hexdigest()
(p/'native_capture_hashes.json').write_text(json.dumps(capture_hashes,indent=2)+'\n')
files.append((p/'native_capture_hashes.json','native_capture_hashes.json'))
files.append((p/'main_baseline/board.json','main_baseline/board.json'))
# Snapshot source states: annual used main; native used the exact current diagnostic helper.
(p/'bench_annual_source.gd').write_bytes(subprocess.check_output(['git','show','5e59345a:game/tests/v2_sky_spectacle_bench.gd']))
(p/'bench_native_source.gd').write_bytes((r/'game/tests/v2_sky_spectacle_bench.gd').read_bytes())
files += [(p/'bench_annual_source.gd','bench_annual_source.gd'),(p/'bench_native_source.gd','bench_native_source.gd')]
unique={name:f for f,name in files}
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
 assert not any(n.startswith(prefix) for n in z.namelist())
 for name,f in sorted(unique.items()):z.write(f,prefix+name)
manifest=json.loads((dest/'manifest.json').read_text())
manifest['annual_native_review']={'evidence_class':'INERT','base_commit':'5e59345a7dd8dc472e0aea6bbc80f1fe46773d54','annual_samples':2190,'native_samples':162,'control_samples':24,'scope':'Actual native optical diagnostics, exact-minute helper repair, annual coverage assessment; not occupied-world qualification, performance or human artistic acceptance','raw_frames_external':'C:/ov/reports/skywatch41 and skywatch42; hash index archived'}
with zipfile.ZipFile(archive) as z:manifest['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
manifest['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archive bytes',archive.stat().st_size,'new members',len(unique))
