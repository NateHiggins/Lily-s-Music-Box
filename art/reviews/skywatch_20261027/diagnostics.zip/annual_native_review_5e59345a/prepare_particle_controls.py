from pathlib import Path
import json
out=Path('C:/ov/reports/skywatch41');source=json.loads((out/'annual_analysis/native_sampling_plan.json').read_text(encoding='utf-8'))
requests=[]
for date in ['1928-11-11T08:29:00','1928-11-24T08:40:00']:
 for suffix in ['','_repeat']:requests.append({'date':date,'period':'artifact_morning'+suffix,'seeds':[1928],'particle_control':True})
(out/'particle_control_plan.json').write_text(json.dumps({'calendar_sha256':source['calendar_sha256'],'captures':requests},indent=2)+'\n',encoding='utf-8',newline='\n')
run=json.loads((out/'annual_batch.json').read_text(encoding='utf-8'));run[0].update(log=str(out/'particle_controls.log'),shot_dir=str(out/'particle_controls'),timeout=240)
(out/'particle_control_batch.json').write_text(json.dumps(run,indent=2)+'\n',encoding='utf-8',newline='\n')
