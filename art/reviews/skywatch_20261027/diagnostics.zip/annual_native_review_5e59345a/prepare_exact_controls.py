from pathlib import Path
import json
out=Path('C:/ov/reports/skywatch41');r=json.loads((out/'particle_control_batch.json').read_text(encoding='utf-8'));r[0].update(log=str(out/'exact_minute_controls.log'),shot_dir=str(out/'exact_minute_controls'));(out/'exact_minute_batch.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8',newline='\n')
