from pathlib import Path
import hashlib,json,subprocess
paths=['game/tests/v2_sky_spectacle_bench.gd','game/shaders/queens_weather_sky.gdshader','game/shaders/queens_weather_math.gdshaderinc','game/scripts/building/living_sky.gd','game/scripts/building/WeatherManager.gd','game/assets/environment/weather/perlin_worley_128.r8','game/assets/environment/weather/cloud_curl_32.rgb8']
rows={p:hashlib.sha256(Path(p).read_bytes() if Path(p).suffix in ['.r8','.rgb8'] else Path(p).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in paths}
Path('C:/ov/reports/skywatch41/source_before.json').write_text(json.dumps({'evidence_class':'INERT','commit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'files':rows,'resolution':[3440,1440],'seed':1928,'scope':'Full-year six-period optical atlas; native frames reduced to review thumbnails, not a runtime performance or artistic acceptance'},indent=2)+'\n',encoding='utf-8',newline='\n')
