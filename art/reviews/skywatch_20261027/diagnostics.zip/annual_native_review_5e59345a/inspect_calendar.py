from pathlib import Path
import json
p=Path('game/data/weather/campaign_weather.json');d=json.loads(p.read_text(encoding='utf-8'));print(type(d).__name__,list(d) if isinstance(d,dict) else len(d))
for key,value in d.items():
 if isinstance(value,list):print(key,len(value),str(value[0])[:350])
