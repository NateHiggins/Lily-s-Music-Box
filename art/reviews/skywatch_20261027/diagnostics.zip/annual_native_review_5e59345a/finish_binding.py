from pathlib import Path
import json,hashlib,subprocess
out=Path('C:/ov/reports/skywatch41');before=json.loads((out/'source_before.json').read_text(encoding='utf-8'));run=json.loads((out/'annual.log.receipt.json').read_text(encoding='utf-8'))
assert run['execution']['completed'] and run['execution']['exit_code']==0 and not run['execution']['timed_out'],run['execution']
assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()==before['commit']
assert json.loads((out/'runtime_before.json').read_text())==json.loads((out/'runtime_after.json').read_text())
for name,expected in before['files'].items():
 p=Path(name);raw=p.read_bytes();raw=raw if p.suffix in ['.r8','.rgb8'] else raw.replace(b'\r\n',b'\n');assert hashlib.sha256(raw).hexdigest()==expected,name
p=out/'annual/annual_gallery.json';gallery=json.loads(p.read_text(encoding='utf-8'));assert not gallery['failures'];assert gallery['samples']==2190 and len(gallery['days'])==365
assert gallery['calendar_sha256']==hashlib.sha256(Path('game/data/weather/campaign_weather.json').read_bytes()).hexdigest()
assert gallery['days'][0]['samples'][0]['date'].startswith('1928-11-10') and gallery['days'][-1]['samples'][-1]['date'].startswith('1929-11-09')
images={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((out/'annual').glob('year_*.png'))};assert len(images)==23
report={'evidence_class':'INERT','status':'PASS_SOURCE_BINDING','scope':'Completed annual optical atlas and unchanged source proof; not performance, composed-world qualification or artistic acceptance','commit':before['commit'],'source_before_sha256':hashlib.sha256((out/'source_before.json').read_bytes()).hexdigest(),'runtime_binding':json.loads((out/'runtime_after.json').read_text()),'gallery_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'samples':gallery['samples'],'days':len(gallery['days']),'reverse_date_replays':gallery['reverse_date_replays'],'atlas_sha256':images}
(out/'annual_source_binding.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({key:report[key] for key in ['status','samples','days','reverse_date_replays']}))
