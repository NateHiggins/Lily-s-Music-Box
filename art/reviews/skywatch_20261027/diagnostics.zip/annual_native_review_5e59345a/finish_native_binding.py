from pathlib import Path
import json,hashlib,sys
root=Path.cwd();out=Path('C:/ov/reports/skywatch41');sys.path.insert(0,str(root/'tools'));import run_receipt
before=json.loads((out/'native_source_before.json').read_text(encoding='utf-8'));assert before['test_sha256_lf']==hashlib.sha256((root/'game/tests/v2_sky_spectacle_bench.gd').read_bytes().replace(b'\r\n',b'\n')).hexdigest()
plan=json.loads((out/'annual_analysis/native_sampling_plan.json').read_text(encoding='utf-8'));requests=plan['captures'].copy()
for row in plan['transition_triplets']:
 for date in row['dates']:requests.append({'date':date,'period':'transition_'+row['period'],'seeds':[row['seed']]})
expected=[(r['date'],r['period'],seed) for r in requests for seed in r['seeds']];data=json.loads((out/'native_coverage/native_detail.json').read_text(encoding='utf-8'));actual=[(r['date'],r['period'],r['seed']) for r in data['rows']]
assert len(actual)==162 and actual==expected and not data['failures']
code,defects=run_receipt.verify(out/'native_coverage.log.receipt.json',root);assert code==0,defects
report={'evidence_class':'INERT','status':'PASS_EXACT_REQUESTS_AND_SOURCE','samples':len(actual),'receipt_binds':True,'defects':defects,'test_sha256_lf':before['test_sha256_lf'],'scope':'Exact calendar request and source binding for native review; no runtime/human artistic acceptance'}
(out/'native_source_binding.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(report))
