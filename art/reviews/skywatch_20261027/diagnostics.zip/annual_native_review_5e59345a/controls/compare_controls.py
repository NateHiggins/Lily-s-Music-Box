from pathlib import Path
import json
import numpy as np
from PIL import Image,ImageDraw
p=Path(__file__).parent
names=['current','shadow_half','shadow_zero','no_analytic_haze']
reports={n:json.loads((p/n/'native_detail.json').read_text()) for n in names}
results=[]
sheet=Image.new('RGB',(480*4,250*6),(20,20,20));draw=ImageDraw.Draw(sheet)
for i,baseline in enumerate(reports['current']['rows']):
 for j,n in enumerate(names):
  row=reports[n]['rows'][i]
  assert not reports[n]['failures']
  assert (row['date'],row['seed'])==(baseline['date'],baseline['seed'])
  image=Image.open(p/n/row['particle_control']['file']).convert('RGB')
  sample=np.asarray(image.resize((320,134)),dtype=float)/255
  luminance=sample@np.array([.2126,.7152,.0722])
  # Upper two-thirds avoids most skyline; paired scene/opacity stays fixed.
  region=luminance[:89]
  hp=region[1:-1,1:-1]-(region[:-2,1:-1]+region[2:,1:-1]+region[1:-1,:-2]+region[1:-1,2:])/4
  results.append(dict(variant=n,date=row['date'],period=row['period'],mean=float(region.mean()),std=float(region.std()),highpass_rms=float(np.sqrt(np.mean(hp**2))),mean_alpha=row['mean_alpha_upper_frame']))
  sheet.paste(image.resize((480,201)),(j*480,i*250+32))
  draw.text((j*480+5,i*250+5),n+' '+row['period'],fill='white')
sheet.save(p/'lighting_controls_contact.jpg',quality=92)
(p/'comparison.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Display-space upper-frame statistics, not physical flux, performance or artistic acceptance','rows':results},indent=2)+'\n')
for r in results:print(r)
