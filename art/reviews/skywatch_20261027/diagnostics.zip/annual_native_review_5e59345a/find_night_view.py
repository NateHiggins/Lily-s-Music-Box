from pathlib import Path
import json
p=Path('C:/ov/reports/skywatch41/native_coverage/native_detail.json');d=json.loads(p.read_text(encoding='utf-8'))
for i,r in enumerate(d['rows']):
 if r['date']=='1928-12-12T23:00:00' and r['seed']==1928:print(i,r['colour'])
