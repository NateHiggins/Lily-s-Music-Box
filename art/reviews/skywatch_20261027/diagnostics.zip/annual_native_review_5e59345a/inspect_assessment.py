from pathlib import Path
import json
p=Path('C:/ov/reports/skywatch41/annual_analysis/native_sampling_plan.json');d=json.loads(p.read_text(encoding='utf-8'));print('plan dates',len(d['captures']),'seed samples',sum(len(x['seeds']) for x in d['captures']),'transition samples',sum(len(x['dates']) for x in d['transition_triplets']))
a=json.loads(Path('C:/ov/reports/skywatch41/annual_analysis/annual_assessment.json').read_text(encoding='utf-8'))
for period,values in a['by_period'].items():print(period,'contrast',values['contrast_p10_p50_p90'],'nearest similarity',values['nonadjacent_nearest_correlation_p50_p90'])
for date in ['1928-11-11','1928-11-24']:
 print('artifact',[(r['date'],r['period'],r['regime'],r['declared_coverage']) for r in a['rows'] if r['date'].startswith(date) and r['period']=='morning'])
