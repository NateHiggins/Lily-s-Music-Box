from pathlib import Path
from PIL import Image,ImageDraw
import json,numpy as np
p=Path('C:/ov/reports/skywatch41/particle_controls');d=json.loads((p/'native_detail.json').read_text(encoding='utf-8'));sheet=Image.new('RGB',(1600,4*365),'#171820');draw=ImageDraw.Draw(sheet)
for i,row in enumerate(d['rows']):
 a=Image.open(p/row['colour']).convert('RGB');b=Image.open(p/row['particle_control']['file']).convert('RGB')
 diff=np.abs(np.asarray(a,dtype=np.int16)-np.asarray(b,dtype=np.int16));print(row['date'],row['period'],'changed>8',float((diff.max(axis=2)>8).mean()),'owners',len(row['particle_control']['hidden_owners']))
 for col,(image,label) in enumerate([(a,'with particles'),(b,'without particles')]):
  image.thumbnail((800,335));sheet.paste(image,(col*800,i*365+25));draw.text((col*800+8,i*365+7),row['date']+' '+label,fill='white')
sheet.save(p/'particle_pair_contact.jpg',quality=94,subsampling=0)
