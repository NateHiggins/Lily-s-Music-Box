from pathlib import Path
import json,numpy as np
out=Path('C:/ov/reports/skywatch41');a=json.loads((out/'native_analysis/native_assessment.json').read_text(encoding='utf-8'));meta=json.loads((out/'native_coverage/native_detail.json').read_text(encoding='utf-8'));print(list(a))
indices=sorted(range(len(a['rows'])),key=lambda i:a['rows'][i]['cloud_luminance_std'] if a['rows'][i]['cloud_luminance_std'] is not None else 1)
for i in indices[:14]:
 r=a['rows'][i];m=meta['rows'][i];print(i,r['date'],r['period'],r['seed'],'alpha',round(r['mean_alpha_upper_frame'],3),'std',round(r['cloud_luminance_std'],5),'regime',m['state']['regime'],'genera',[v['genus'] for v in m['state']['layers']])
print('seed differences',a['seed_alpha_differences'][:3])
