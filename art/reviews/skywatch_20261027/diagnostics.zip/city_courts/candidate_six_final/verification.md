# Candidate verification - faf0c1ec7e7d

- candidate `faf0c1ec7e7d95826ff2a47c6eb5e8221cedce44`
- base `9896ebe7ff215100884bd4c57eef2f40c3c18044`
- merge-base `9896ebe7ff215100884bd4c57eef2f40c3c18044`
- verified 2026-10-28T13:16:32Z from verifier `faf0c1ec7e7d`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 0 regressions, 0 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 1 |

## Blocking reasons (0)

- none

## Needs human review (not blocking) (3)

- candidate changes 1 gate file(s); read those diffs before trusting the board
- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (0)

- none

## Accepted regressions (0)

- none

## Improvements (0)

- none

## Report claims contradicted (0)

- none

## Design doc lint (1)

- WARN design/AUDIT_UNUSED_SYSTEMS_REPORT.md: 1 backticked id-like token(s) in a non-evidence document (F04_B_MONITOR_01); harmless under its current name, promoting if ever renamed. Write ids in bold.

## Gates changed by the candidate (1)

- M tools/tests/test_additive_material_rebind.py

MERGE-CANDIDATE faf0c1ec7e7d95826ff2a47c6eb5e8221cedce44
