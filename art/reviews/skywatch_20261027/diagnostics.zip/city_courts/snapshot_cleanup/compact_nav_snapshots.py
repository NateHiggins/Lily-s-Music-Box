"""Consolidate named historical snapshots; preserve every byte and live receipt."""
from pathlib import Path
import subprocess,json,hashlib,tarfile,shutil,io

root=Path('C:/PleaseRemainOnTheLine').resolve()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
prefix=Path('design/astra/evidence/resident_f01_haunt/nav_validation')
out=Path(__file__).parent/'snapshot_cleanup';out.mkdir(exist_ok=True)
tracked=[p for p in subprocess.check_output(['git','ls-files','-z','--',prefix.as_posix()],cwd=root).decode().split('\0') if p]
selected=[]
for name in tracked:
    parts=Path(name).parts
    if len(parts)>10 and parts[6]=='runs' and parts[8] in {'before','after'} and parts[9]=='source':selected.append(name)
assert len(selected)==25740,len(selected)
assert not subprocess.check_output(['git','diff','HEAD','--name-only','--',*[(prefix/d).as_posix() for d in ['nav_direct_01','nav_direct_02','nav_direct_03']]],cwd=root).strip()
groups={}
for name in selected:groups.setdefault(Path(name).parts[5],[]).append(name)
summary=[]
for group,names in groups.items():
    directory=root/prefix/group; destination=directory/'source_snapshots.tar.gz'
    temporary=out/(group+'.tar.gz'); records=[]
    if destination.exists():assert destination.read_bytes()==temporary.read_bytes(),destination
    seen={}
    with tarfile.open(temporary,'w:gz',compresslevel=6) as z:
        for name in names:
            path=(root/name).resolve();assert path.is_relative_to(directory.resolve())
            data=path.read_bytes();relative=path.relative_to(directory).as_posix()
            digest=hashlib.sha256(data).hexdigest()
            records.append({'path':relative,'bytes':len(data),'sha256':digest})
            info=tarfile.TarInfo(relative);info.mode=0o444
            if digest in seen:
                info.type=tarfile.LNKTYPE;info.linkname=seen[digest];z.addfile(info)
            else:
                info.size=len(data);z.addfile(info,io.BytesIO(data));seen[digest]=relative
        data=(json.dumps({'evidence_class':'INERT','kind':'historical_source_snapshot_archive','source_commit':base,'original_directory':directory.relative_to(root).as_posix(),'semantics':'Exact bytes; identical frozen contents use archive hardlinks. Extract only into a disposable review directory. Original result maps unchanged; no new runtime acceptance.','members':records},indent=1)+'\n').encode()
        info=tarfile.TarInfo('ARCHIVE_INDEX.json');info.size=len(data);z.addfile(info,io.BytesIO(data))
    assert temporary.stat().st_size<50*1024*1024
    with tarfile.open(temporary,'r:gz') as z:
        data_by_name={};wanted={r['path']:r for r in records}
        for member in z:
            if member.name=='ARCHIVE_INDEX.json':continue
            assert member.name in wanted and member.name not in data_by_name
            data=data_by_name[member.linkname] if member.islnk() else z.extractfile(member).read()
            row=wanted[member.name]
            assert data==(directory/member.name).read_bytes() and hashlib.sha256(data).hexdigest()==row['sha256']
            data_by_name[member.name]=data
        assert len(data_by_name)==len(records)
    shutil.copyfile(temporary,destination)
    assert destination.read_bytes()==temporary.read_bytes()
    summary.append({'directory':directory.relative_to(root).as_posix(),'archive':destination.relative_to(root).as_posix(),'members':len(records),'original_bytes':sum(r['bytes'] for r in records),'archive_bytes':destination.stat().st_size,'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'all_members_roundtrip_exact':True})
plan=out/'named_snapshot_deletions.nul';plan.write_bytes(b''.join(n.encode()+b'\0' for n in selected))
(out/'verified_plan.json').write_text(json.dumps({'evidence_class':'INERT','base':base,'source_files':len(selected),'groups':summary,'scope':'Only redundant before/after/source trees. All loose logs, result.json, artifact hash maps, invocation and aggregate receipts retained.','pathspec':str(plan)},indent=2)+'\n')
print(json.dumps(summary,indent=2))
print('All archives verified. No source files removed yet. Named deletion list:',plan)
