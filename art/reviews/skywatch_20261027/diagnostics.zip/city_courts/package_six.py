from pathlib import Path
import json, hashlib, zipfile, gzip, subprocess, io
from PIL import Image

root=Path('C:/PleaseRemainOnTheLine'); out=Path(__file__).parent
dest=root/'art/reviews/skywatch_20261027'; archive=dest/'diagnostics.zip'
base='9896ebe7ff215100884bd4c57eef2f40c3c18044'
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((dest/'manifest.json').read_text())
assert sha(archive.read_bytes())==m['archive_sha256']
backup=out/'publication_six/previous_surface_packet'
review=json.loads((backup/'visual_review.json').read_text())
verified={}
for name in ['runtime_contract.json','surface-inventory.json','suite_run.receipt.json','suite_run.stdout.log.gz','suite_run.stderr.log.gz','visual_review.json']+[r['file'] for r in review['images']]:
    p=backup/(name+'.gz' if name=='surface-inventory.json' else name)
    raw=gzip.decompress(p.read_bytes()) if name=='surface-inventory.json' else p.read_bytes()
    original=subprocess.check_output(['git','show',base+':art/renders/orison_v2/surface_requirements_20261011/'+name],cwd=root)
    assert original==raw,name
    verified[name]=sha(raw)
(out/'previous_six_packet_recovery.json').write_text(json.dumps({'commit':base,'byte_verified':verified},indent=2)+'\n')

images=out/'six_review_images'; images.mkdir(exist_ok=True); records=[]
sources=list((out/'city_diag_six_shaft').glob('city_batch_*.png'))
sources+=list((out/'native_six_final_review').glob('*roof_detail.png'))
sources+=[out/'native_pair_review/site_far_w.png']
assert len(sources)==21,len(sources)
for p in sources:
    name=p.parent.name+'_'+p.stem+'.webp'; target=images/name
    im=Image.open(p)
    if not target.exists():im.save(target,'WEBP',lossless=True,method=3)
    assert Image.open(target).convert(im.mode).tobytes()==im.tobytes()
    records.append({'file':name,'original_png_sha256':sha(p.read_bytes()),'decoded_pixel_sha256':sha(im.tobytes()),'webp_sha256':sha(target.read_bytes()),'size':im.size,'pixel_exact':True,'external_original':str(p)})
(out/'six_review_images.json').write_text(json.dumps({'evidence_class':'INERT','images':records},indent=2)+'\n')
files=[p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.ps1','.json','.log','.stderr','.gd','.bin','.zip'} and not p.name.startswith('diagnostics_')]
files+=[out/'main_baseline_9896ebe7/board.json']
for folder in ['bench_six','bench_six_fixed','bench_six_typed','bench_six_shaft','city_diag_six','city_diag_six_bound','city_diag_six_calibrated','city_diag_six_shaft','route_six_shaft','surface_six_shaft','native_six_final_review','candidate_six']:
    files+=list((out/folder).glob('*.json'))
for folder in out.iterdir():
    if folder.is_dir() and (folder.name.startswith(('native_','imported_')) or folder.name in {'catalog_negative_control','city_material_additive_renewal'}):files+=list(folder.glob('*.json'))
files += [images/r['file'] for r in records]
payload={'city_courts/'+p.relative_to(out).as_posix():p.read_bytes() for p in dict.fromkeys(files)}
with zipfile.ZipFile(archive) as z: old={n:z.read(n) for n in z.namelist()}
assert not any(n.startswith('city_courts/') for n in old)
base_zip=zipfile.ZipFile(io.BytesIO(subprocess.check_output(['git','show',base+':art/reviews/skywatch_20261027/diagnostics.zip'],cwd=root)))
removed=[]; candidates=sorted((n for n in old if Path(n).suffix.lower() in {'.webp','.png','.jpg','.jpeg'}),key=lambda n:len(old[n]),reverse=True)
target=out/'diagnostics_six_prepared.zip'
while True:
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,b in {**old,**payload}.items():z.writestr(n,b)
    if target.stat().st_size<49*1024*1024:break
    assert candidates,'Evidence exceeds limit even with all historical image recovery'
    n=candidates.pop(0); raw=old[n]; assert raw==base_zip.read(n)
    removed.append({'member':n,'sha256':sha(raw),'commit':base,'archive_path':'art/reviews/skywatch_20261027/diagnostics.zip','bytes':len(raw)})
    del old[n]
with zipfile.ZipFile(target) as z:
    assert len(z.namelist())==len(set(z.namelist()))
    members={n:sha(z.read(n)) for n in z.namelist()}
    for n,b in old.items():assert members[n]==sha(b)
contract=json.loads((out/'surface_six_shaft/runtime_contract.json').read_text())
m['city_courts']={'evidence_class':'INERT','base':base,'qualified_commit':'7f301c66','scope':'Six passive apartment adaptations; no new occupied interiors or save reconstruction.','raw_prefix':'city_courts/','surface_checks':39427,'loaded_checks':5557,'diagnostic_checks':5270,'contracts':contract['contracts'],'comparison':json.loads((out/'six_route_comparison.json').read_text()),'previous_packet':{'commit':base,'byte_verified':verified},'review_images':records,'immutable_git_recovery':removed,'limits':['138 further city studies after integration; queue update pending merge.','No stutter improvement: largest frame171ms during first passage loading; cause not isolated.','Dim exterior exposure and flat storm ceiling remain presentation debt.','Save reconstruction NOT_EXECUTED; no human artistic acceptance.','Candidate verification and integration pending.']}
m['members']=members;m['archive_sha256']=sha(target.read_bytes())
(out/'manifest_six_prepared.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared',target.stat().st_size,'bytes;',len(payload),'new members;',len(removed),'historical images exact Git-recoverable; all other old members exact.')
