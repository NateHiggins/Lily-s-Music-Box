$ErrorActionPreference='Stop'
Set-Location -LiteralPath C:/PleaseRemainOnTheLine
Remove-Item Env:ORISON_SURFACE_FIRE_ONLY,Env:ORISON_DEVELOPER_OVERLAYS,Env:ROOF_PREVIEW_PROFILE_YEAR,Env:AGENDA_QUERY_ONLY,Env:AGENDA_QUERY_PROFILE,Env:V2_PROFILE_RELEASES,Env:SKYWATCH_MIRAGE_PROFILE,Env:WEATHER_RESOURCE_SCOPE_CONTROL,Env:WEATHER_LIFECYCLE_REVIEW,Env:WEATHER_FALLOUT_RELOAD,Env:WEATHER_PRECIP_REVIEW,Env:SKY_LIBRARY_YEAR,Env:SKY_NATIVE_SAMPLING_PLAN,Env:SKY_REVIEW_SHADER_SOURCE,Env:SKYWATCH_OPTICAL_REVIEW,Env:WEATHER_SIMULATE,Env:WEATHER_FORMATION,Env:WEATHER_PHENOMENON,Env:DAYNIGHT_FORCE -ErrorAction SilentlyContinue
$env:GIT_OPTIONAL_LOCKS='0'
$env:SKYWATCH_CLOUD_PROFILE='1'
$env:ORISON_SURFACE_SKIP_FIRE_INTERACTION='1'
$nativeArgs=@('--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440')
& ./tools/lane.ps1 run -Scene res://tests/V2CityElevationBench.tscn -Runner serial -TimeoutSeconds 170 -Windowed -ShotDir C:/ov/reports/city_reference_next_20261028/bench_six_shaft -LogPath C:/ov/reports/city_reference_next_20261028/bench_six_shaft.log -ExtraArgs $nativeArgs -WaitMinutes 15
if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
$env:ORISON_SURFACE_CITY_ONLY='1'
& ./tools/lane.ps1 run -Scene res://tests/OrisonV2SurfaceInventory.tscn -Runner long -TimeoutSeconds 450 -Windowed -ShotDir C:/ov/reports/city_reference_next_20261028/city_diag_six_shaft -LogPath C:/ov/reports/city_reference_next_20261028/city_diag_six_shaft.log -ExtraArgs $nativeArgs -WaitMinutes 15
if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
Remove-Item Env:ORISON_SURFACE_CITY_ONLY
& ./tools/lane.ps1 run -Scene res://tests/V2WeatherRouteProfile.tscn -Runner long -TimeoutSeconds 700 -Windowed -ShotDir C:/ov/reports/city_reference_next_20261028/route_six_shaft -LogPath C:/ov/reports/city_reference_next_20261028/route_six_shaft.log -ExtraArgs $nativeArgs -WaitMinutes 15
if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
& ./tools/lane.ps1 run -Scene res://tests/OrisonV2SurfaceInventory.tscn -Runner long -TimeoutSeconds 1200 -Windowed -ShotDir C:/ov/reports/city_reference_next_20261028/surface_six_shaft -LogPath C:/ov/reports/city_reference_next_20261028/surface_six_shaft.log -ExtraArgs $nativeArgs -WaitMinutes 15
exit $LASTEXITCODE



