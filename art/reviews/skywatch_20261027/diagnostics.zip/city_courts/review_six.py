from pathlib import Path
import bpy,json,hashlib
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
ROOT=Path.cwd();out=Path('C:/ov/reports/city_reference_next_20261028/native_six_review');out.mkdir(parents=True,exist_ok=True)
ids={'site_far_se','site_far_w','site_far_n','site_far_sw','site_far_ne','site_far_s'}
paths=[ROOT/f'art/blender/city_{f}.blend' for f in ['elevations','masts','aerials','tanks','beacons']]
before={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
bpy.ops.wm.read_factory_settings(use_empty=True);objects=[]
for path in paths:
 with bpy.data.libraries.load(str(path),link=False) as (a,b):b.objects=[n for n in a.objects if n.split('__')[0] in ids]
 for o in b.objects:
  if o.hide_render:continue
  bpy.context.scene.collection.objects.link(o);objects.append(o)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=12
scene.render.resolution_x=1280;scene.render.resolution_y=800;scene.render.resolution_percentage=100
scene.world=bpy.data.worlds.new('Review');scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.6,.7,.8,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.7
l=bpy.data.lights.new('Sun','SUN');l.energy=3;o=bpy.data.objects.new('Sun',l);scene.collection.objects.link(o);o.rotation_euler=(.45,-.35,-.7)
c=bpy.data.cameras.new('Review');o=bpy.data.objects.new('Review',c);scene.collection.objects.link(o);scene.camera=o;c.lens=28
report=json.loads((ROOT/'art/blender/city_elevations_construction.json').read_text());views=[];normal_checks=[]
from mathutils.bvhtree import BVHTree
bpy.context.view_layer.update()
vv=[];ff=[]
for ob in objects:
 at=len(vv);vv.extend(ob.matrix_world@v.co for v in ob.data.vertices);ff.extend(tuple(at+i for i in f.vertices) for f in ob.data.polygons)
bvh=BVHTree.FromPolygons(vv,ff,all_triangles=True)
for study in report['buildings']:
 if study['id'] not in ids:continue
 x,y,X,Y=study['main_rect'];top=study['roof_height'];identity=study['id']
 origin,u,d,projection,back={'site_far_se':(Vector((x,y+.26,0)),Vector((0,1,0)),Vector((-1,0,0)),.24,0),'site_far_w':(Vector((X,Y-.26,0)),Vector((0,-1,0)),Vector((1,0,0)),.24,0),'site_far_n':(Vector((X,y,0)),Vector((-1,0,0)),Vector((0,-1,0)),.26,.30),'site_far_sw':(Vector((x,Y,0)),Vector((1,0,0)),Vector((0,1,0)),.26,0),'site_far_ne':(Vector((X,y,0)),Vector((-1,0,0)),Vector((0,-1,0)),.26,0),'site_far_s':(Vector((x,Y,0)),Vector((1,0,0)),Vector((0,1,0)),.18,0)}[identity]
 length=Y-y-.52 if identity in ['site_far_se','site_far_w'] else X-x
 point=origin+u*(length*.10 if identity!='site_far_s' else length*.85)+d*(projection-back)+Vector((0,0,top+.14 if identity!='site_far_s' else 17.17))
 hit,n,index,distance=bvh.ray_cast(point+d*.1,-d,.4)
 assert hit is not None and (hit-point).length<.0001 and n.dot(d)>.99,(identity,hit,n)
 normal_checks.append({'building':identity,'outward_dot':n.dot(d),'error_m':(hit-point).length})
for b in report['buildings']:
 if b['id'] not in ids:continue
 r=b['main_rect'];span=max(r[2]-r[0],r[3]-r[1]);h=b['roof_height'];cx=(r[0]+r[2])*.5;cy=(r[1]+r[3])*.5
 direction=Vector({'site_far_se':(-1,0,0),'site_far_w':(1,0,0),'site_far_n':(0,-1,0),'site_far_sw':(0,1,0),'site_far_ne':(0,-1,0),'site_far_s':(0,1,0)}[b['id']]);tangent=Vector((-direction.y,direction.x,0))
 top=max((ob.matrix_world@v.co).z for ob in objects if ob.name.startswith(b['id']+'__') for v in ob.data.vertices)
 target=Vector((cx,cy,top*.48));o.location=target+direction*span*1.35+tangent*span*.08+Vector((0,0,h*.35));o.rotation_euler=(target-o.location).to_track_quat('-Z','Y').to_euler()
 for obj in objects:obj.hide_render=not obj.name.startswith(b['id']+'__')
 offset=o.location-target
 for attempt in range(12):
  o.location=target+offset*1.2**attempt;o.rotation_euler=(target-o.location).to_track_quat('-Z','Y').to_euler();bpy.context.view_layer.update()
  points=[world_to_camera_view(scene,o,ob.matrix_world@Vector(corner)) for ob in objects if not ob.hide_render for corner in ob.bound_box]
  if all(p.z>0 and .05<=p.x<=.95 and .05<=p.y<=.95 for p in points):break
 else:raise AssertionError(('cannot frame complete native stock',b['id']))
 scene.render.filepath=str(out/(b['id']+'.png'));bpy.ops.render.render(write_still=True);views.append({'id':b['id'],'at':list(o.location),'target':list(target)})
for index,portal in enumerate(report['portals']):
 identity=portal['building']
 if identity not in ids:continue
 direction=[Vector((0,-1,0)),Vector((1,0,0)),Vector((0,1,0)),Vector((-1,0,0))][int(portal['side'])]
 for obj in objects:obj.hide_render=not obj.name.startswith(identity+'__')
 target=Vector(portal['point']);target.z=2.5;o.location=target+direction*12+Vector((0,0,.7));o.rotation_euler=(target-o.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(identity+'_entry_'+str(index)+'.png'));bpy.ops.render.render(write_still=True)
for index,detail in enumerate(report['court_details']):
 identity=detail['building']
 if identity not in ids:continue
 direction=[Vector((0,-1,0)),Vector((1,0,0)),Vector((0,1,0)),Vector((-1,0,0))][int(detail['front_side'])]
 for obj in objects:obj.hide_render=not obj.name.startswith(identity+'__')
 target=Vector(detail['void_probe'])+Vector((0,0,-3));o.location=Vector(detail['void_probe'])+direction*8+Vector((0,0,6));o.rotation_euler=(target-o.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(identity+'_roof_'+str(index)+'.png'));bpy.ops.render.render(write_still=True)
for detail in report['roof_details']:
 identity=detail['building']
 for obj in objects:obj.hide_render=not obj.name.startswith(identity+'__')
 if detail['style']=='towers':
  x,y,X,Y=detail['rect'];target=Vector(((x+X)/2,(y+Y)/2,detail['base']+1.15));at=target+Vector((-8,-10,4));c.lens=40
 else:
  target=Vector((6,-71,19.9));at=Vector((6,-46,25));c.lens=32
 o.location=at;o.rotation_euler=(target-at).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(identity+'_roof_detail.png'));bpy.ops.render.render(write_still=True)
assert all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in before.items())
(out/'review.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Read-only native court-apartment and seated equipment study, not runtime acceptance.','source_bindings':before,'views':views,'crown_outward_normals':normal_checks},indent=2)+'\n')



