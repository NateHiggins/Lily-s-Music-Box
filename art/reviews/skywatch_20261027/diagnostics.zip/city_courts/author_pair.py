from pathlib import Path
import json
root=Path('C:/PleaseRemainOnTheLine');out=Path(__file__).parent
p=root/'art/blender/scripts/build_city_elevations.py';s=p.read_text();(out/'before_courts_builder.py').write_text(s)
s=s.replace('portal_rows=[];townhouse_details=[]','portal_rows=[];townhouse_details=[];court_details=[]')
s=s.replace('for side,(origin,tangent,out,length) in enumerate(facade_frames(rect,depth)):',"for side,(origin,tangent,out,length) in p.get('_frames',list(enumerate(facade_frames(rect,depth)))):")
s=s.replace("bays=3*int(p['architecture']['terraces']) if townhouse else max(1,math.floor(length/p['bay_pitch']));pitch=length/bays", "bays=int(p.get('_bays',3*int(p['architecture']['terraces']) if townhouse else max(1,math.floor(length/p['bay_pitch']))));pitch=length/bays")
s=s.replace("arched=factory or (townhouse and side==int(p['architecture']['front_side']))", "arched=factory or (townhouse and side==int(p['architecture']['front_side'])) or (p.get('_arch_top',False) and floor==len(intervals)-1 and bay==bays//2)")
s=s.replace("and bay%3==0)\n                if portal", "and bay%3==0) or (p.get('_entry',False) and floor==0 and bay==bays//2)\n                if p.get('_arch_top',False) and floor==len(intervals)-1 and bay==bays//2:w=float(p.get('_top_width',w))\n                if portal")
s=s.replace('if portal:w=min(1.45 if townhouse else 2.0,pitch-.35);h=3.2',"if portal:w=min(float(p.get('_entry_width',1.45 if townhouse else 2.0)),pitch-.35);h=float(p.get('_entry_height',3.2));arched=arched or bool(p.get('_entry_arch',False))")
s=s.replace("                if p['window_joinery']=='paired_sash':", """                if p.get('_six_over_one',False) and not portal:
                    for division in [-1,1]:
                        at=cx+division*w/6
                        local_box(name,p['sash'],origin,tangent,out,(at-.014,-recess-.038,(low+high)/2),(at+.014,-recess+.008,frame_top-.055))
                    middle=(frame_top+(low+high)/2)/2
                    local_box(name,p['sash'],origin,tangent,out,(wl+.055,-recess-.038,middle-.014),(wr-.055,-recess+.008,middle+.014))
                if p.get('_palladian',False) and floor==len(intervals)-1 and bay==bays//2:
                    for direction in [-1,1]:
                        at=cx+direction*w*.25
                        local_box(name,p['sash'],origin,tangent,out,(at-.035,-recess-.044,low),(at+.035,-recess+.02,frame_top))
                if p['window_joinery']=='paired_sash':""")
insert='''
def turned_stock(name,key,center,profile,sides=12,flute=0.):
    """Closed seated column/baluster, including its base and capital profile."""
    vv=[]
    for z,r in profile:
        for i in range(sides):
            a=i*math.tau/sides;radius=r*(1.-flute*(i%2))
            vv.append(tuple(center+Vector((math.cos(a)*radius,math.sin(a)*radius,z))))
    ff=[tuple(reversed(range(sides))),tuple(range((len(profile)-1)*sides,len(profile)*sides))]
    ff += [(j*sides+i,j*sides+(i+1)%sides,(j+1)*sides+(i+1)%sides,(j+1)*sides+i) for j in range(len(profile)-1) for i in range(sides)]
    add(name,key,vv,ff)

def court_apartment(name,p,rect,top,cap_row):
    a=p['architecture'];front=int(a['front_side']);depth=float(p['reveal_depth'])
    frames=facade_frames(rect,depth);origin,u,out,length=frames[front]
    width=float(a['recess_width_m']);inset=float(a['recess_depth_m']);left=(length-width)/2;right=left+width
    # A genuine sky-open shallow court, wholly outside the retained roof field.
    x,y,X,Y=rect;cut_points=[origin+u*t-out*d for t,d in [(left,0),(right,0),(left,inset),(right,inset)]]
    cut=[min(v.x for v in cut_points),min(v.y for v in cut_points),max(v.x for v in cut_points),max(v.y for v in cut_points)]
    roof_rect=list(cap_row['rect']);dx=cap_row['registration_offset_x'];roof_rect[0]+=dx;roof_rect[2]+=dx
    assert cut[2]<=roof_rect[0] or cut[0]>=roof_rect[2] or cut[3]<=roof_rect[1] or cut[1]>=roof_rect[3],(name,'court cuts retained roof',cut,roof_rect)
    count=0
    for side,frame in enumerate(frames):
        if side==front:continue
        q=dict(p,_frames=[(side,frame)])
        count+=facade(name,q,rect,0.,top)
    for start,end,back,bays,entry in [(0,left,0,int(a['side_bays']),False),(left,right,inset,1,True),(right,length,0,int(a['side_bays']),False)]:
        at=origin+u*start-out*back
        q=dict(p,_frames=[(front,(at,u,out,end-start))],_bays=bays,_entry=entry,_entry_width=1.45,_entry_height=2.65,_entry_arch=entry,_arch_top=entry,_top_width=float(a['stair_window_width_m']),_palladian=a['style']=='cambridge',_six_over_one=a['style']=='elm')
        count+=facade(name,q,rect,0.,top)
        local_box(name,'limestone',at,u,out,(0,-depth,0),(end-start,.035,.52))
    for at in [left,right]:
        # Full-height masonry returns close the recess without a hidden roof.
        local_box(name,p['wall_key'],origin,u,out,(at-depth,-inset,0),(at,0,top))
    # Complement the exact original top cap; subtract the court from each annulus strip.
    A,B,C,D=roof_rect
    panels=[(x,y,X,B),(x,D,X,Y),(x,B,A,D),(C,B,X,D)]
    for l,b,r,t in panels:
        if l>=r or b>=t:continue
        L=max(l,cut[0]);R=min(r,cut[2]);B0=max(b,cut[1]);T=min(t,cut[3])
        pieces=[(l,b,r,t)] if L>=R or B0>=T else [(l,b,r,B0),(l,T,r,t),(l,B0,L,T),(R,B0,r,T)]
        for l0,b0,r0,t0 in pieces:
            if r0>l0 and t0>b0:box(name,'roof_bitumen',(l0,b0,top),(r0,t0,top+.26))
    # Clockwise complete wall perimeter, including both court returns.
    outline=[(X,Y),(x,Y),(x,y),(X,y)]
    first=Vector((origin.x,origin.y));last=first+u*length
    edge=next(i for i in range(4) if (Vector(outline[i])-Vector((last.x,last.y))).length<depth+.001 and (Vector(outline[(i+1)%4])-first).length<depth+.001)
    # Use exact wall corner endpoints rather than the reveal-trimmed side frame.
    corners=[(origin+u*t-out*d) for t,d in [(right,0),(right,inset),(left,inset),(left,0)]]
    outline[edge+1:edge+1]=[(v.x,v.y) for v in corners]
    for projection,bottom,high in [(.10,top-.18,top+.05),(.24,top+.05,top+.22)]:
        vv,ff=cornice_ring(outline,projection,bottom,high);add(name,'wood_dark' if a['style']=='cambridge' else 'limestone',vv,ff)
    # Portico is a supported assembly: foundation, profiled columns/pilasters,
    # architrave, roof deck and railing. Door belongs to closed passive stock.
    center=length/2;roof=3.05;porch=width-.25
    local_box(name,'limestone',origin,u,out,(left+.08,-inset,.0),(right-.08,.02,.12))
    for side in [-1,1]:
        c=origin+u*(center+side*(porch*.5-.35))-out*.28
        if a['style']=='elm':
            turned_stock(name,'limestone',c,[(.12,.30),(.22,.30),(.28,.23),(.38,.20),(2.65,.17),(2.74,.25),(2.88,.25)],16,.035)
        else:
            local_box(name,'limestone',origin,u,out,(center+side*(porch*.5-.35)-.16,-.55,.12),(center+side*(porch*.5-.35)+.16,-.14,2.88))
            for delta in [-.075,0,.075]:
                local_box(name,'limestone',origin,u,out,(center+side*(porch*.5-.35)+delta-.01,-.14,.38),(center+side*(porch*.5-.35)+delta+.01,-.12,2.64))
    local_box(name,'limestone',origin,u,out,(left+.10,-inset-.02,2.88),(right-.10,.10,roof))
    local_box(name,'limestone',origin,u,out,(left+.03,-inset-.03,roof),(right-.03,.14,roof+.14))
    key='limestone' if a['style']=='elm' else 'iron_blackened'
    for i in range(13):
        t=left+.25+(width-.50)*i/12;c=origin+u*t-out*.015
        if key=='limestone':turned_stock(name,key,c,[(roof+.14,.065),(roof+.20,.065),(roof+.27,.035),(roof+.42,.060),(roof+.50,.035),(roof+.62,.060)],8)
        else:local_box(name,key,origin,u,out,(t-.014,-.03,roof+.14),(t+.014,0,roof+.63))
    local_box(name,key,origin,u,out,(left+.13,-.065,roof+.62),(right-.13,.035,roof+.70))
    # Modillions are seated under the front cornice; no per-brick geometry.
    for i in range(int(length/.55)):
        t=(i+.5)*length/int(length/.55)
        if left-.08<t<right+.08:continue
        local_box(name,'limestone',origin,u,out,(t-.045,-.03,top-.32),(t+.045,.16,top-.12))
    # Open court ray above the porch must reach its deck, never a roof slab.
    probe=origin+u*center-out*(inset*.5)+Vector((0,0,top+.8))
    court_details.append(dict(building=name,style=a['style'],front_side=front,recess_depth_m=inset,recess_width_m=width,outline=outline,void_probe=list(probe),porch_top=roof+.14,roof_height=top,entry_count=1))
    return count

'''
s=s.replace('def facade(name,p,rect,z0,z1):',insert+'def facade(name,p,rect,z0,z1):')
# Both selected families retain their original roof, support parapet and caps;
# replace only facade distribution and the obsolete concrete podium/bands.
s=s.replace("        if ('vertical_profile' in p or townhouse)","        if ('vertical_profile' in p or townhouse)")
needle="    split=top if factory or townhouse else last['z0'] if len(ss)>1 else top\n    n=facade"
s=s.replace(needle,"    court=p.get('architecture',{}).get('type')=='court_apartment'\n    split=top if factory or townhouse or court else last['z0'] if len(ss)>1 else top\n    if court:\n        cap_row=next(r for r in rr if r['id']==name+'_c'+last['id'].rsplit('_s',1)[1])\n        n=court_apartment(name,p,rect0,top,cap_row)\n    else:n=facade")
s=s.replace('if len(ss)>1 and not factory and not townhouse:', 'if len(ss)>1 and not factory and not townhouse and not court:')
s=s.replace('new_setbacks=0 if factory or townhouse else', 'new_setbacks=0 if factory or townhouse or court else')
s=s.replace('townhouse_details=townhouse_details,anchor_seats=', 'townhouse_details=townhouse_details,court_details=court_details,anchor_seats=')
assert s!=p.read_text();compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
p=root/'art/data/city_elevations/source_plan.json';data=json.loads(p.read_text());(out/'before_courts_source_plan.json').write_text(json.dumps(data,indent=2)+'\n')
for id,style,front,bays,width,inset,stair,ref in [('site_far_se','elm',3,4,5.,1.,1.4,'Elm Court, 34-27 79th Street, George H. Wells, 1921–22'),('site_far_w','cambridge',1,6,4.8,.9,2.65,'Cambridge Court, 37-14 86th Street, George H. Wells, 1922')]:
 b=next(b for b in data['buildings'] if b['id']==id)
 b['architecture']=dict(type='court_apartment',style=style,front_side=front,side_bays=bays,recess_width_m=width,recess_depth_m=inset,stair_window_width_m=stair,arch_rise_m=.36 if style=='elm' else .60)
 b.update(wall_key='brick',wall_tint=[.66,.47,.38,1] if style=='elm' else [.60,.40,.32,1],bay_pitch=2.8 if style=='elm' else 2.7,window_width=1.05,window_height=1.85,window_joinery='single_sash',detail_faces='all')
 b['description']=ref+' — authored four-storey passive study; actual shallow open court, seated entry assembly and distinct upper stair glazing'
 b['precedent']['name']=ref;b['precedent']['adaptation']='Authored proportions within the retained mass and roof/equipment reservation. Four-storey Georgian court vocabulary; no new interior, actor or access. Cambridge uses the documented flat-roof end A pavilion, not the mansard B block. Native/imported review remains pending.'
 b['precedent']['pdf_pages']=[136] if style=='elm' else [203,204,66]
p.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Authored first two six-building court studies; no runtime qualification claimed')
