from pathlib import Path
import json
root=Path('C:/PleaseRemainOnTheLine');out=Path(__file__).parent
p=root/'art/blender/scripts/build_city_elevations.py';s=p.read_text();(out/'before_second_pair_builder.py').write_text(s)
code='''
def terraced_courts(name,p,rect,top,cap_row):
    """A measured multi-court perimeter and edited roof, not an extra facade skin."""
    a=p['architecture'];style=a['style'];depth=float(p['reveal_depth']);x,y,X,Y=rect
    frames=facade_frames(rect,depth);schedules={int(k):v for k,v in a['segments'].items()}
    cuts=[];entries=[];courts=[];count=0;outline=[]
    # Full corner frames for the roof boundary; facade corners retain their
    # existing reveal-depth ownership so adjacent sides do not overlap.
    corners={0:(Vector((X,y,0)),Vector((-1,0,0)),Vector((0,-1,0)),X-x),3:(Vector((x,y,0)),Vector((0,1,0)),Vector((-1,0,0)),Y-y),2:(Vector((x,Y,0)),Vector((1,0,0)),Vector((0,1,0)),X-x),1:(Vector((X,Y,0)),Vector((0,-1,0)),Vector((1,0,0)),Y-y)}
    for side in [0,3,2,1]:
        origin,u,out,length=corners[side]
        schedule=schedules.get(side,[[0,length,0,max(1,int(length/p['bay_pitch'])),False]])
        assert abs(schedule[0][0])<1e-6 and abs(schedule[-1][1]-length)<1e-6
        previous=0.
        for i,(left,right,back,bays,entry) in enumerate(schedule):
            assert right>left and back>=0 and bays>0 and (i==0 or abs(left-schedule[i-1][1])<1e-6)
            start=origin+u*left-out*back;end=origin+u*right-out*back
            if not outline or (Vector(outline[-1])-Vector((start.x,start.y))).length>1e-6:outline.append((start.x,start.y))
            outline.append((end.x,end.y))
            if back>0:
                points=[origin+u*t-out*d for t,d in [(left,0),(right,0),(left,back),(right,back)]]
                cuts.append([min(v.x for v in points),min(v.y for v in points),max(v.x for v in points),max(v.y for v in points)])
            if side not in schedules:
                count+=facade(name,dict(p,_frames=[(side,frames[side])]),rect,0.,top)
                break
            # Every depth change has a closed masonry return with real thickness.
            if abs(back-previous)>1e-6:
                local_box(name,p['wall_key'],origin,u,out,(left-depth,-max(back,previous),0),(left,-min(back,previous),top))
            q=dict(p,_frames=[(side,(start,u,out,right-left))],_bays=int(bays),_entry=bool(entry),_entry_width=1.45,_entry_height=2.70,_entry_arch=bool(entry),_arch_top=style=='laburnum' and side==int(a['front_side']),_arch_top_all=style=='laburnum',_arch_finish='limestone',_top_width=p['window_width'])
            count+=facade(name,q,rect,0.,top)
            local_box(name,'limestone',start,u,out,(0,-depth,0),(right-left,.035,.65))
            if side==int(a['front_side']):
                level=p['floor_heights'][0]
                local_box(name,'limestone',start,u,out,(0,-depth,level-.06),(right-left,.065,level+.06))
            if back>=1.0:
                local_box(name,'limestone',origin,u,out,(left+.02,-back,.0),(right-.02,-.01,.14))
                courts.append((side,origin,u,out,left,right,back,entry))
            if entry:entries.append((side,origin,u,out,left,right,back))
            previous=back
        if previous>0:local_box(name,p['wall_key'],origin,u,out,(length-depth,-previous,0),(length,0,top))
    # Remove collinear vertices before generating full-depth mitred courses.
    compact=[]
    for v in outline:
        if not compact or (Vector(v)-Vector(compact[-1])).length>1e-6:compact.append(v)
    if (Vector(compact[0])-Vector(compact[-1])).length<1e-6:compact.pop()
    while True:
        keep=[]
        for i,v in enumerate(compact):
            before=Vector(v)-Vector(compact[i-1]);after=Vector(compact[(i+1)%len(compact)])-Vector(v)
            if abs(before.x*after.y-before.y*after.x)>1e-7:keep.append(v)
        if len(keep)==len(compact):break
        compact=keep
    assert len(compact)>=4
    if sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(compact,compact[1:]+compact[:1]))>0:compact.reverse()
    # The owner permits replacing the legacy slab. Keep every surviving roof
    # at the original physical bearing height; subtract actual court voids.
    pieces=[rect]
    for L,B,R,T in cuts:
        result=[]
        for l,b,r,t in pieces:
            A=max(l,L);C=min(r,R);D=max(b,B);E=min(t,T)
            candidates=[(l,b,r,t)] if A>=C or D>=E else [(l,b,r,D),(l,E,r,t),(l,D,A,E),(C,D,r,E)]
            result.extend(v for v in candidates if v[2]-v[0]>1e-6 and v[3]-v[1]>1e-6)
        pieces=result
    for l,b,r,t in pieces:box(name,'roof_bitumen',(l,b,top),(r,t,top+.26))
    for projection,bottom,high in [(.12,top-.20,top+.03),(.26,top+.03,top+.24)]:
        vv,ff=cornice_ring(compact,projection,bottom,high);add(name,'limestone',vv,ff)
    for side,origin,u,out,left,right,back in entries:
        center=(left+right)/2
        if style=='greystone':
            # Tudor doorway has keyed pale stone attached to its masonry jambs.
            for sign in [-1,1]:
                at=center+sign*.86
                local_box(name,'limestone',origin,u,out,(at-.11,-back-.08,0),(at+.11,-back+.12,2.74))
                for z in [.15,.65,1.15,1.65,2.15]:local_box(name,'limestone',origin,u,out,(at-.16,-back+.12,z),(at+.16,-back+.16,z+.16))
            profile_stock(name,'limestone',origin,u,out,[(center-.16,2.92),(center+.16,2.92),(center+.12,3.17),(center-.12,3.17)],-back-.03,-back+.18)
            for sign in [-1,0,1]:
                t=center+sign*1.8
                local_box(name,p['wall_key'],origin,u,out,(t-.40,-back-depth,top+.24),(t+.40,-back+.02,top+.88))
                local_box(name,'limestone',origin,u,out,(t-.46,-back-depth-.04,top+.88),(t+.46,-back+.08,top+.99))
        else:
            # Four-sided support: masonry at the back and two front pilasters
            # carry the real portico deck, with a small iron balcony crown.
            for sign in [-1,1]:
                at=center+sign*((right-left)*.5-.38)
                local_box(name,'limestone',origin,u,out,(at-.18,-.48,.14),(at+.18,-.12,2.90))
                local_box(name,'limestone',origin,u,out,(at-.23,-.54,2.78),(at+.23,-.08,2.92))
            local_box(name,'limestone',origin,u,out,(left+.05,-back-.04,2.90),(right-.05,.08,3.15))
            for i in range(15):
                t=left+.18+(right-left-.36)*i/14
                local_box(name,'iron_blackened',origin,u,out,(t-.014,-.025,3.15),(t+.014,.005,3.70))
            local_box(name,'iron_blackened',origin,u,out,(left+.12,-.055,3.70),(right-.12,.035,3.76))
    for side,origin,u,out,left,right,back,entry in courts:
        probe=origin+u*((left+right)/2)-out*back*.5+Vector((0,0,top+.8))
        court_details.append(dict(building=name,style=style,front_side=side,recess_depth_m=back,recess_width_m=right-left,outline=compact,void_probe=list(probe),porch_top=3.15 if entry else .14,roof_height=top,entry_count=len(entries),edited_legacy_roof=True))
    return count

'''
s=s.replace('def court_apartment(name,p,rect,top,cap_row):',code+"def court_apartment(name,p,rect,top,cap_row):\n    if p['architecture']['style'] in ['greystone','laburnum']:return terraced_courts(name,p,rect,top,cap_row)")
s=s.replace("and bay==bays//2)\n                portal=", "and (p.get('_arch_top_all',False) or bay==bays//2))\n                portal=")
s=s.replace("arch_stock(name,'limestone' if townhouse else p['wall_key']", "arch_stock(name,p.get('_arch_finish','limestone' if townhouse else p['wall_key'])")
needle="        key=r['key']\n        if factory"
s=s.replace(needle,"        if p.get('architecture',{}).get('style') in ['greystone','laburnum'] and suffix=='c'+last['id'].rsplit('_s',1)[1]:continue\n        key=r['key']\n        if factory")
s=s.replace("for face in ([] if factory else ring.data.polygons):", "for face in ([] if factory or p.get('architecture',{}).get('style') in ['greystone','laburnum'] else ring.data.polygons):")
s=s.replace("Vector((0,0,-1)),detail['roof_height'])", "Vector((0,0,-1)),detail['roof_height']+1.)")
compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
p=root/'art/data/city_elevations/source_plan.json';j=json.loads(p.read_text())
for b in j['buildings']:
 if b['id']=='site_far_n':
  b.update(wall_key='city_grey_brick',wall_tint=[1,1,1,1],detail_faces='all',window_width=1.08,window_height=1.90,bay_pitch=2.65,window_joinery='single_sash')
  b['architecture']=dict(type='court_apartment',style='greystone',front_side=0,arch_rise_m=.22,segments={'0':[[0,16.4,.30,6,False],[16.4,23.6,0,3,True],[23.6,40,.30,6,False]],'2':[[0,16.4,0,6,False],[16.4,23.6,3.0,3,False],[23.6,40,0,6,False]]})
  b['description']='Greystone-inspired five-storey gray-brick Tudor apartment composition: fifteen front axes, keyed doorway, raised centre parapet and an open rear court'
  b['precedent'].update(name='Greystone Apartments, 35-15 80th Street, George H. Wells, 1916–18',pdf_pages=[30,31,147,148,61],adaptation='Authored enlarged 40 m mass, gray brick, fifteen axes and Tudor entry vocabulary; not a surveyed replica. The old slab is edited for a true rear court. Roof bearings remain measured; no new interior or access.')
 if b['id']=='site_far_sw':
  b.update(wall_key='brick',wall_tint=[.72,.48,.39,1],detail_faces='all',window_width=1.02,window_height=1.90,bay_pitch=2.75,window_joinery='single_sash')
  b['architecture']=dict(type='court_apartment',style='laburnum',front_side=2,arch_rise_m=.48,segments={'2':[[0,7,0,3,False],[7,12,2.8,1,True],[12,22,0,3,False],[22,27,2.8,1,True],[27,34,0,3,False]]})
  b['description']='Laburnum-inspired five-storey red-brick court apartment: two open entry courts, supported iron-crowned porticoes and arched upper sash'
  b['precedent'].update(name='Laburnum Court, 37-15 79th Street, George H. Wells, 1921–22',pdf_pages=[138,34,65],adaptation='Two 2.8 m-deep courts adapt the group to one existing mass; original roof slabs are cut rather than hiding the courts. Keep the registered -4.83 m X offset once, supported equipment and passive doors. No new interior, garden route or actor.')
p.write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Authored Greystone and Laburnum; native review pending')
