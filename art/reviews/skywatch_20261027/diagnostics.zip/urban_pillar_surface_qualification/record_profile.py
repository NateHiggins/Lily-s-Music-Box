from pathlib import Path
p=Path('design/V2_SKYWATCH_ASTRONOMY_2026-10-27.md');s=p.read_text(encoding='utf-8').rstrip()+'''

### Existing route costs: narrowed follow-up, not a new speedup

Read-only aggregation of the retained **skywatch39/published_V2WeatherRouteProfile**
arrays is in **skywatch40/phase_attribution_limits.json**. Pooled walking has
3,482 samples, wall p50/p95 **35.591/69.216 ms**; outdoor turning has 636,
**24.486/39.670 ms**; the fixed sky bearing has 623, **51.063/57.304 ms**.
Different bearings, residency and visible stock prevent causal comparisons
between these phases. Main-viewport GPU medians are respectively **14.654**,
**11.041** and **20.502 ms**; private viewport costs are not summed.

The bounded final 256 input records contain 197 constrained-motion calls,
median **0.011 ms**, maximum **0.038 ms**, but 20 release/end calls at median
**13.390 ms**, maximum **14.502 ms**. The separately timed world-modified signal
is at most **0.011 ms**. Three thresholded slow player-physics records show
landing slide calls around **5.3 ms**; they are not a complete physics distribution.
Static tracing puts transform publication, physics synchronization, settling
and the manipulation-changed/save notification inside the release interval.
The next release investigation must separate those costs before changing any
save or collision owner. This evidence narrows the target; it does not identify
a responsible function or explain the 100+ ms frames. No firehose run was used.
''';p.write_text(s+'\n',encoding='utf-8',newline='\n')
