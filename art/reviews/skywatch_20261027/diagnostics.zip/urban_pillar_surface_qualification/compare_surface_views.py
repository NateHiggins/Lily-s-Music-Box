from pathlib import Path
import hashlib,json
out=Path('C:/ov/reports/skywatch40');names=['city_street_skyline.png','city_weather_storm.png','front_gallery_05.png','street_paving.png','front_restored_entrance.png','public_arcade_hall.png','tile_F02_A_BATH_corner.png'];rows=[]
for name in names:
 a=out/'surface_clouds'/name;b=out/'surface_classified'/name
 if not b.exists():continue
 ha=hashlib.sha256(a.read_bytes()).hexdigest();hb=hashlib.sha256(b.read_bytes()).hexdigest()
 rows.append({'file':name,'original_sha256':ha,'new_sha256':hb,'same_bytes':ha==hb})
(out/'surface_render_comparison_partial.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Available current captures compared against inspected original failed-run captures; not a completed runtime qualification','images':rows},indent=2)+'\n',encoding='utf-8',newline='\n');print([(r['file'],r['same_bytes']) for r in rows])
