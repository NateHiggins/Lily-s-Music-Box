from pathlib import Path
import json,hashlib,zipfile
root=Path.cwd();out=Path('C:/ov/reports/skywatch40');folder=root/'art/reviews/skywatch_20261027';archive=folder/'diagnostics.zip';prefix='urban_pillar_surface_qualification/'
manifest=json.loads((folder/'manifest.json').read_text(encoding='utf-8'));scope={'evidence_class':'INERT','scope':'Original failed surface qualification, exact optical-role classifier correction, fresh passing runtime contract and published seven-view review; no annual or whole-game human acceptance','source_lf_sha256':{},'external_png_sha256':{}}
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
 assert not any(n.startswith(prefix) for n in z.namelist())
 for name in ['tools/audit_v2_surfaces.py','tools/tests/test_v2_surface_requirements.py','tools/v2_surface_evidence.py','game/scripts/building/orison_v2_street_lamps.gd','game/shaders/street_ice_pillar.gdshader']:
  b=(root/name).read_bytes();scope['source_lf_sha256'][name]=hashlib.sha256(b.replace(b'\r\n',b'\n')).hexdigest();z.writestr(prefix+'tested_source/'+name,b)
 for f in sorted(out.iterdir()):
  if f.is_file() and (f.suffix in ['.json','.py'] or '.log' in f.name):z.write(f,prefix+f.name)
 for name in ['surface_clouds','surface_classified','final_cloud_optical_analysis']:
  directory=out/name
  for f in directory.glob('*.json'):
   if f.name=='surface-inventory.json' and name=='surface_classified':continue
   z.write(f,prefix+name+'/'+f.name)
  for f in directory.glob('*.png'):scope['external_png_sha256'][str(f)]=hashlib.sha256(f.read_bytes()).hexdigest()
 z.write(out/'surface_classified_contact.jpg',prefix+'surface_classified_contact.jpg')
manifest['urban_pillar_surface_qualification']=scope
with zipfile.ZipFile(archive) as z:manifest['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
manifest['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest();(folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
p=root/'design/V2_SKYWATCH_ASTRONOMY_2026-10-27.md';s=p.read_text(encoding='utf-8').rstrip()+'''

### Fresh surface result and publication

**skywatch40/surface_classified.log.receipt.json** completes successfully in
**784 s**, native fullscreen **3440x1440**, patched Vulkan, empty stderr:
**39,169 checks / zero failures**. Its schema-2 runtime contract records PASS
for production composition, loaded surface requirements and runtime-owned
teardown. Inventory: **27,820 draws**, **17,006 meshes**, **6,309 materials**,
**527 textures**. Fire-service interaction was explicitly skipped; its physical
draws remain inventoried. Save reconstruction is **NOT_EXECUTED**, not a pass.

Seven actual current captures were reviewed: street skyline, storm skyline,
front gallery, paving, entrance, public arcade and bathroom corner. Native
source PNGs and their hashes are in the published packet. The storm ceiling
is still low contrast and the street exposure remains dark; this surface review
does not grant annual atmospheric or lighting artistic acceptance. The new
cloud optics have their separate native-pixel controlled comparisons above.

The existing surface publisher validates and installs the new test-written
contract, raw inventory, corroborating logs and review, with zero defects.
The previous packet is preserved externally in **skywatch40/publication_backup**;
the failed original run, classifier source/control and fresh result are retained
under **urban_pillar_surface_qualification/** in the existing diagnostic archive.
No failed receipt was edited or promoted. Full candidate comparison against the
clean **6ff8922f** main baseline is the next integration gate; the broader
weather/roof and responsiveness limitations above remain open.
''';p.write_text(s+'\n',encoding='utf-8',newline='\n')
print('Archive',archive.stat().st_size,'bytes')
