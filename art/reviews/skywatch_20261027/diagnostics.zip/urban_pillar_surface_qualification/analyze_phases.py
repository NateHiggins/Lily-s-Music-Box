from pathlib import Path
import json,numpy as np
from collections import defaultdict
out=Path('C:/ov/reports/skywatch40');d=json.loads(Path('C:/ov/reports/skywatch39/published_V2WeatherRouteProfile/cloud_world_frames.json').read_text(encoding='utf-8'));groups=defaultdict(list)
for row in d['samples']:
 name=row[0]
 phase='walk' if '_walk_' in name else 'turn' if 'mouse_turn' in name else 'hold' if 'sky_hold' in name else 'door' if 'door' in name else name
 groups[phase].append(row)
summary={}
for key,rows in groups.items():
 summary[key]={'frames':len(rows),'wall_ms':dict(zip(['p50','p95','p99','max'],np.percentile([r[1] for r in rows],[50,95,99,100]).tolist())),'gpu_ms':dict(zip(['p50','p95','max'],np.percentile([r[5] for r in rows],[50,95,100]).tolist())),'frames_above_50ms':sum(r[1]>50 for r in rows)}
inputs=defaultdict(list)
for row in d['input_costs']: inputs[row['stage']].append(row['ms'])
report={'evidence_class':'INERT','source':'skywatch39/published_V2WeatherRouteProfile/cloud_world_frames.json','scope':'Read-only aggregation of existing actual-world ABBA. Pooled phases do not control scene visibility, NPC or residency. Bounded last-256 input samples and thresholded slow player physics are not full distributions. No additional Godot run or causal attribution.','phases':summary,'retained_input_ms':{key:{'count':len(values),'p50':float(np.median(values)),'max':max(values)} for key,values in inputs.items()},'slow_player_physics':d['player_physics']}
(out/'phase_attribution_limits.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({'phases':summary,'retained_input':report['retained_input_ms']},indent=2))
