from pathlib import Path
s=Path('C:/ov/reports/skywatch33/prepare_surface_packet.py').read_text(encoding='utf-8')
s=s.replace("out=Path('C:/ov/reports/skywatch33'); p=out/'surface_astronomy'","out=Path('C:/ov/reports/skywatch40'); p=out/'surface_classified'").replace('surface_astronomy.log','surface_classified.log').replace('source 1b0b5997','source 824a7eff')
s=s.replace('clear blue cloud bands','blue sky with broad wisps').replace('flat storm ceiling in this diagnostic is retained','very low-contrast storm ceiling in this diagnostic remains a presentation limitation')
Path('C:/ov/reports/skywatch40/prepare_classified_packet.py').write_text(s,encoding='utf-8',newline='\n')
