from pathlib import Path
from PIL import Image,ImageDraw
out=Path('C:/ov/reports/skywatch40');p=out/'surface_classified'
names=['city_street_skyline.png','city_weather_storm.png','front_gallery_05.png','street_paving.png','front_restored_entrance.png','public_arcade_hall.png','tile_F02_A_BATH_corner.png']
sheet=Image.new('RGB',(1600,1460),'#171820');draw=ImageDraw.Draw(sheet)
for i,name in enumerate(names):
 x=i%2*800;y=i//2*365;im=Image.open(p/name).convert('RGB');assert im.size==(3440,1440);im.thumbnail((800,335));sheet.paste(im,(x,y+25));draw.text((x+8,y+7),name,fill='white')
sheet.save(out/'surface_classified_contact.jpg',quality=94,subsampling=0)
