from pathlib import Path
import json
p=Path('C:/ov/reports/skywatch39/published_V2WeatherRouteProfile/cloud_world_frames.json');d=json.loads(p.read_text(encoding='utf-8'))
for key in ['input_costs','player_physics']:
 v=d[key];print(key,type(v).__name__,len(v));print(str(v[:2] if isinstance(v,list) else v)[:2200])
