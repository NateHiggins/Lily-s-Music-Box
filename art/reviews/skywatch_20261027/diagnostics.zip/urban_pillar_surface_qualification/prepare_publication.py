from pathlib import Path
source=Path('C:/ov/reports/skywatch33/prepare_surface_packet.py').read_text(encoding='utf-8')
source=source.replace("out=Path('C:/ov/reports/skywatch33'); p=out/'surface_astronomy'","out=Path('C:/ov/reports/skywatch40'); p=out/'surface_clouds'").replace('surface_astronomy.log','surface_clouds.log').replace('source 1b0b5997','source f96acaa7')
source=source.replace('clear blue cloud bands','blue sky with broad wisps').replace('flat storm ceiling in this diagnostic is retained','very low-contrast storm ceiling in this diagnostic remains a presentation limitation')
Path('C:/ov/reports/skywatch40/prepare_surface_packet.py').write_text(source,encoding='utf-8',newline='\n')
