from pathlib import Path
import subprocess
out=Path('C:/ov/reports/skywatch40');(out/'audit_v2_surfaces_original.py').write_bytes(subprocess.check_output(['git','show','HEAD:tools/audit_v2_surfaces.py']))
p=Path('design/V2_SKYWATCH_ASTRONOMY_2026-10-27.md');s=p.read_text(encoding='utf-8').rstrip()+'''

### Surface classification failure retained before renewed qualification

**skywatch40/surface_clouds.log.receipt.json** completes with exit 1 in **783 s**,
**39,169 checks**, one assertion failure. Its inventory has **27,820 draws**,
**17,006 meshes**, **6,309 materials**, **527 textures**. All four technical
findings are the actual street lamps' **IcePillar** optical quads. The lamp
owner already labels these **weather_optics**; the audit did not recognize the
new shader/owner combination. There is no missing physical-lamp material repair.

The audit now classifies only the exact unshaded **street_ice_pillar.gdshader**,
weather-optics role, exterior-cell owner, installed street subtree and terminal
IcePillar part as an urban ice light effect. A focused unit regression passes
with negative controls for housing/foreign paths, physical role, wrong owner,
wrong shader and shaded material. This follows the existing separate optical
inventory rule; it is not an exemption for physical stock.

Re-evaluation of the unchanged failed-run inventory reports zero unresolved
surfaces in **reclassified_diagnostic.json**. That is a diagnostic only: the
original test-written failed runtime contract and stderr remain untouched.
The checker is a bound input, so a fresh complete surface run remains required.
The failed packet is not published, repinned or described as partial acceptance.
''';p.write_text(s+'\n',encoding='utf-8',newline='\n')
