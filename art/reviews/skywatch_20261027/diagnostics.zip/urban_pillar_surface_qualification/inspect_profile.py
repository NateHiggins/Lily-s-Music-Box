from pathlib import Path
import json
p=Path('C:/ov/reports/skywatch39/published_V2WeatherRouteProfile/cloud_world_frames.json');d=json.loads(p.read_text(encoding='utf-8'));print('keys',list(d));print('columns',d['columns']);print('block',d['blocks'][0]);print('summary keys',list(json.loads(Path('C:/ov/reports/skywatch39/cloud_world_summary.json').read_text()).keys()))
