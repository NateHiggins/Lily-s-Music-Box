# Candidate verification - 3a0c0096c8de

- candidate `3a0c0096c8de2e7481ad2a3b6ce0a5c969c22eb3`
- base `e27606315052d157bc56eddf0abd49f7d25642ca`
- merge-base `e27606315052d157bc56eddf0abd49f7d25642ca`
- verified 2026-10-27T14:22:46Z from verifier `3a0c0096c8de`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 0 regressions, 0 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 5 |

## Blocking reasons (0)

- none

## Needs human review (not blocking) (3)

- candidate changes 5 gate file(s); read those diffs before trusting the board
- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (0)

- none

## Accepted regressions (0)

- none

## Improvements (0)

- none

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (5)

- M tools/audit_period_dates.py
- M tools/audit_v2_surfaces.py
- M tools/orison_spatial_dependency_manifest.json
- M tools/tests/test_additive_material_bindings.py
- M tools/tests/test_v2_surface_requirements.py

MERGE-CANDIDATE 3a0c0096c8de2e7481ad2a3b6ce0a5c969c22eb3
