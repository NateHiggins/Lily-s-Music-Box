import json
from pathlib import Path
from PIL import Image,ImageDraw
p=Path('C:/ov/reports/skywatch34/roof_survey');d=json.loads((p/'skywatch_roof_survey.json').read_text());im=Image.new('RGB',(1400,1100),'#f2f2ed');draw=ImageDraw.Draw(im)
def screen(x,z):return (int(80+(x+16)*38),int(100+(12-z)*38))
for q in d['standing_samples']:
 x,y=screen(*q['xz']);draw.rectangle((x-4,y-4,x+4,y+4),fill='#268567' if q['clear'] else '#b64e46')
for x in range(-15,16,5):
 a,b=screen(x,12),screen(x,-12);draw.line((a,b),fill='#a5a5a5');draw.text((a[0]-10,65),str(x),fill='black')
for z in range(-10,11,5):
 a,b=screen(-16,z),screen(16,z);draw.line((a,b),fill='#a5a5a5');draw.text((30,a[1]),str(z),fill='black')
for name,x,z in [('Telescope',-10,7),('Gathering',-6,7),('Grill',-3.5,10),('Weather inspector',3,-9),('Public access',-3.9,0),('Tank service',-9.4,-3.05)]:
 a,b=screen(x,z);draw.ellipse((a-6,b-6,a+6,b+6),fill='#204bbb');draw.text((a+10,b-16),name,fill='#123a96')
draw.text((80,20),'ROOF LOCAL X / Z metres. Green: standing capsule clear; red: unsupported or obstructed.',fill='black');draw.text((80,45),'Posed authoring survey, not played access. Candidate centres only; all stock footprints still require checking.',fill='black');im.save(p/'standing_map.png')
for name,x,z in [('scope',-10,7),('gathering',-6,7),('grill',-3.5,10)]:
 nearby=[q for q in d['standing_samples'] if abs(q['xz'][0]-x)<=1.5 and abs(q['xz'][1]-z)<=1.5];print(name,'clear',sum(q['clear'] for q in nearby),'of',len(nearby),'height',min(q.get('floor_y',100) for q in nearby),max(q.get('floor_y',-100) for q in nearby));print({q['floor'] for q in nearby})
