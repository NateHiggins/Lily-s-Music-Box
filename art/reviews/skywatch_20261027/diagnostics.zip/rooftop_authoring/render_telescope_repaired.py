import bpy,math
from pathlib import Path
from mathutils import Vector
root=Path('C:/PleaseRemainOnTheLine');out=Path('C:/ov/reports/skywatch34/native_review');out.mkdir(exist_ok=True)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=True
scene.render.resolution_x=1440;scene.render.resolution_y=1200;scene.render.resolution_percentage=100
scene.world=bpy.data.worlds.new('Review world');scene.world.color=(.12,.12,.12)
def aim(obj,at):obj.rotation_euler=(Vector(at)-obj.location).to_track_quat('-Z','Y').to_euler()
for name,location,energy,size in [('Key',(2,-3,4),600,3),('Rim',(-2,1,3),400,2),('Fill',(1,2,2),150,3)]:
 data=bpy.data.lights.new(name,'AREA');data.energy=energy;data.shape='DISK';data.size=size;obj=bpy.data.objects.new(name,data);scene.collection.objects.link(obj);obj.location=location;aim(obj,(0,0,1))
camera_data=bpy.data.cameras.new('Review');camera=bpy.data.objects.new('Review',camera_data);scene.collection.objects.link(camera);scene.camera=camera;camera_data.lens=55
for name,eye,target in [('whole',(2.2,-3.3,2.2),(0,0,.9)),('objective',(1.2,2.0,2.1),(0,.2,1.40)),('mount',(1.1,-1.0,1.8),(0,0,1.37))]:
 camera.location=eye;aim(camera,target);scene.render.filepath=str(out/(name+'.png'));bpy.ops.render.render(write_still=True)

