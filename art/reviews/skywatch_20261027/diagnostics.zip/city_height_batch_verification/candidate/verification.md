# Candidate verification - a9703c457b55

- candidate `a9703c457b55094c4011e95ced41d9a8a0d6b5df`
- base `04d72f3a47c233d0bc7ec786df5f33358f53577c`
- merge-base `04d72f3a47c233d0bc7ec786df5f33358f53577c`
- verified 2026-10-28T04:04:57Z from verifier `a9703c457b55`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 0 regressions, 0 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 3 |

## Blocking reasons (0)

- none

## Needs human review (not blocking) (3)

- candidate changes 3 gate file(s); read those diffs before trusting the board
- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (0)

- none

## Accepted regressions (0)

- none

## Improvements (0)

- none

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (3)

- M tools/tests/test_city_closure_source.py
- M tools/tests/test_city_ground_apron.py
- M tools/tests/test_city_horizon.py

MERGE-CANDIDATE a9703c457b55094c4011e95ced41d9a8a0d6b5df
