from pathlib import Path
import hashlib, json, subprocess, zipfile

root = Path.cwd()
here = Path(__file__).parent
dest = root / 'art/reviews/skywatch_20261027'
archive = dest / 'diagnostics.zip'
prefix = 'candidate_dbd91cc6_main_merge/'
v = json.loads((here / 'final_candidate/verification.json').read_text())
assert not v['blocking'] and not v['accepted_regressions']['lines']
assert v['last_line'] == 'MERGE-CANDIDATE dbd91cc6e31ddc682f0b39db88afb16622a31417'
merge = subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip()
assert merge == 'ca4835ee6f7bf609b9e975fc2ff5bdfc4c82204d'
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}']) == subprocess.check_output(['git','rev-parse','dbd91cc6^{tree}'])
with zipfile.ZipFile(archive, 'a', zipfile.ZIP_DEFLATED) as z:
    assert not any(n.startswith(prefix) for n in z.namelist())
    for f in (here / 'final_candidate').rglob('*'):
        if f.is_file():
            z.write(f, prefix + 'candidate/' + f.relative_to(here / 'final_candidate').as_posix())
    z.write(Path(__file__), prefix + 'package_merge.py')
m = json.loads((dest / 'manifest.json').read_text())
m['candidate_dbd91cc6_main_merge'] = {
    'evidence_class': 'INERT', 'tested_candidate': v['candidate'], 'merge_commit': merge,
    'merged_tree_identical_to_tested_candidate': True, 'regressions': 0,
    'protected_unchanged': 17, 'waivers': 0,
    'scope': 'Clean canonical in-place 114-gate comparison. Verifier --no-godot; separate lane receipts provide runtime evidence. No fresh checkout, whole-V2 or human acceptance.'
}
m['occupied_larder_query_profile']['candidate_verification'] = '9cdaa97f blocked on stale surface; final dbd91cc6 PASS after renewed surface and approved cleanup. PR71 merged ca4835ee; no ordinary-route FPS gain.'
m['approved_task_reconciliation']['next'] = 'Final candidate PASS and PR71 merged; city construction next.'
with zipfile.ZipFile(archive) as z:
    m['members'] = {n: hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
m['archive_sha256'] = hashlib.sha256(archive.read_bytes()).hexdigest()
(dest / 'manifest.json').write_text(json.dumps(m, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Archived final candidate and identical-tree main merge:', archive.stat().st_size)
