# Candidate verification - dbd91cc6e31d

- candidate `dbd91cc6e31ddc682f0b39db88afb16622a31417`
- base `c5f8400a27d582738c620f23c0a887f4ae9724e8`
- merge-base `c5f8400a27d582738c620f23c0a887f4ae9724e8`
- verified 2026-10-28T01:01:39Z from verifier `dbd91cc6e31d`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 0 regressions, 12 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 0 |

## Blocking reasons (0)

- none

## Needs human review (not blocking) (2)

- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (0)

- none

## Accepted regressions (0)

- none

## Improvements (12)

- reader: unread 1102 -> 1091
- reader: resolved FIELD_UNREAD|game/data/creature_index.json|clips
- reader: resolved FIELD_UNREAD|game/data/creature_index.json|comment
- reader: resolved FIELD_UNREAD|game/data/creature_index.json|creatures
- reader: resolved FIELD_UNREAD|game/data/creature_index.json|harpy
- reader: resolved FIELD_UNREAD|game/data/creature_index.json|missing
- reader: resolved FIELD_UNREAD|game/data/creature_index.json|model
- reader: resolved FIELD_UNREAD|game/data/creature_index.json|moves
- reader: resolved FIELD_UNREAD|game/data/creature_index.json|notes
- reader: resolved FIELD_UNREAD|game/data/creature_index.json|oni
- reader: resolved FIELD_UNREAD|game/data/creature_index.json|skeleton
- reader: resolved FILE_UNREAD|game/data/creature_index.json|

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (0)

- none

MERGE-CANDIDATE dbd91cc6e31ddc682f0b39db88afb16622a31417
