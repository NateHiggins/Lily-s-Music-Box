from pathlib import Path
import json,numpy as np,sys
p=Path(__file__).parent
name=sys.argv[1] if len(sys.argv)>1 else 'release_route'
d=json.loads((p/name/'cloud_world_frames.json').read_text())
a=d['release_attribution'];out={}
def distribution(values):
 v=np.array(values,float)
 return dict(n=len(v),p50=float(np.percentile(v,50)),p95=float(np.percentile(v,95)),max=float(v.max())) if len(v) else {}
for door in a['doors']:
 print(door['owner'],len(door['samples']))
 for key in ['publish_usec','sync_usec','settle_usec','callbacks_usec']:print(key,distribution([r[key]/1000 for r in door['samples']]))
out['door_stages']={key:distribution([r[key]/1000 for door in a['doors'] for r in door['samples']]) for key in ['publish_usec','sync_usec','settle_usec','callbacks_usec']}
for stage in sorted({r['stage'] for r in a['household']}):
 out[stage]=distribution([(r['end_usec']-r['start_usec'])/1000 for r in a['household'] if r['stage']==stage])
print(json.dumps(out,indent=2))
out['frames']=distribution([r[1] for r in d['samples']])
out['gpu_ms']=distribution([r[5] for r in d['samples']])
out['failures']=d['failures'];out['source_frozen']=d['source_before']==d['source_after']
(p/(name+'_summary.json')).write_text(json.dumps(out,indent=2)+'\n')
