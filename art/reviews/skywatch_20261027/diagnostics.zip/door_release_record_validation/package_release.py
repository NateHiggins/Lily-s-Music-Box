from pathlib import Path
import json,hashlib,zipfile
from PIL import Image,ImageDraw
r=Path.cwd();p=Path(__file__).parent;dest=r/'art/reviews/skywatch_20261027';archive=dest/'diagnostics.zip';prefix='door_release_record_validation/'
for name in ['release_route','release_route_cached']:
 d=json.loads((p/name/'cloud_world_frames.json').read_text());receipt=json.loads((p/(name+'.log.receipt.json')).read_text())
 assert not d['failures'] and d['source_before']==d['source_after']
 assert receipt['execution']['completed'] and receipt['execution']['exit_code']==0
 assert receipt['log']['stderr_sha256']==hashlib.sha256(b'').hexdigest()
 assert sum(b['waypoints'] for b in d['blocks'])==116
 assert len(json.loads((p/name/'route.json').read_text())['trace'])==124
contact=Image.new('RGB',(960,804));pen=ImageDraw.Draw(contact)
captures={}
for i,name in enumerate(['release_route','release_route_cached']):
 f=p/name/'cloud_3_off_street.png';image=Image.open(f).convert('RGB');image.thumbnail((960,402));contact.paste(image,(0,i*402));pen.text((4,i*402+4),name,fill='white')
 for f in (p/name).glob('*.png'):captures[str(f)]=hashlib.sha256(f.read_bytes()).hexdigest()
contact.save(p/'release_contact.jpg',quality=88)
(p/'capture_hashes.json').write_text(json.dumps(captures,indent=2)+'\n')
files=[]
for f in p.iterdir():
 if f.is_file() and f.suffix in ['.json','.gd','.py','.log','.stderr','.jpg']:files.append((f,f.name))
for name in ['release_route','release_route_cached','record_cache']:
 for f in (p/name).glob('*.json'):files.append((f,name+'/'+f.name))
for path in ['game/scripts/building/orison_v2_household_state.gd','game/scripts/props/door_prop.gd','game/tests/v2_weather_route_profile.gd','game/tests/v2_household_unchanged_bench.gd']:
 files.append((r/path,'tested_source/'+path))
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
 assert not any(n.startswith(prefix) for n in z.namelist())
 for f,name in sorted(files,key=lambda row:row[1]):z.write(f,prefix+name)
m=json.loads((dest/'manifest.json').read_text())
m['door_release_record_validation']={'evidence_class':'INERT','base_commit':'c5d1290210334da3bb2e7c9c54dc808e9a8e59c9','scope':'Matched source-frozen occupied controller routes; opt-in synchronous callback attribution, disk persistence disabled in both profiles. Component cache safety checks; save/load, surface renewal and candidate verification pending. Not full-world performance or human acceptance.','median_callback_ms_before':13.775,'median_callback_ms_after':8.08,'external':'C:/ov/reports/skywatch43/'}
with zipfile.ZipFile(archive) as z:m['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
m['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest();(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archived actual paired routes; bytes',archive.stat().st_size)
