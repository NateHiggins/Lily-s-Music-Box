from pathlib import Path
import bpy
from mathutils import Vector
ROOT=Path.cwd();out=Path('C:/ov/reports/city_mass_20261028/native')
bpy.ops.wm.read_factory_settings(use_empty=True)
for family in ['elevations','masts','aerials','tanks','beacons']:
 with bpy.data.libraries.load(str(ROOT/f'art/blender/city_{family}.blend'),link=False) as (a,b):
  b.objects=[n for n in a.objects if n.startswith('site_far_n__')]
 for o in b.objects:
  if o.hide_render:continue
  bpy.context.scene.collection.objects.link(o)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=12
scene.render.resolution_x=1280;scene.render.resolution_y=800;scene.render.resolution_percentage=100
scene.world=bpy.data.worlds.new('Review');scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.6,.7,.8,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.7
l=bpy.data.lights.new('Sun','SUN');l.energy=3;o=bpy.data.objects.new('Sun',l);scene.collection.objects.link(o);o.rotation_euler=(.45,-.35,-.7)
c=bpy.data.cameras.new('Review');o=bpy.data.objects.new('Review',c);scene.collection.objects.link(o);scene.camera=o;c.lens=35
o.location=(22,6,16);o.rotation_euler=(Vector((-6,48,9))-o.location).to_track_quat('-Z','Y').to_euler()
scene.render.filepath=str(out/'north_five_storeys.png');bpy.ops.render.render(write_still=True)
