from pathlib import Path
import json
root=Path.cwd(); p=root/'art/data/city_elevations/source_plan.json'
s=json.loads(p.read_text());r=next(r for r in s['buildings'] if r['id']=='site_far_n')
r.update(description='Five-storey Greystone-inspired north block; authored height repair, individual Tudor entrance/court study remains open',vertical_profile=[0,3.25,3.59,13.,16.25],floor_heights=[3.25]*5,precedent={'name':'Greystone Apartments, 80th Street, George H. Wells, 1917–18','source':'https://s-media.nyc.gov/agencies/lpc/lp/1831.pdf','pdf_pages':[30,31,62],'adaptation':'Five-storey height hierarchy is documented. Dimensions are authored; existing reservation and roof hardware are retained. This is not a replica or completed individual architectural study.'})
s['scope']='Passive V2 masonry adaptation. Explicit vertical_profile rows project frozen V1 stock into V2; other original reservations and roof datums are retained. No occupied interior or play area added.'
p.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8',newline='\n')
# Native owner projects the immutable layout before constructing any solid.
p=root/'art/blender/scripts/build_city_shells.py';t=p.read_text();t=t.replace("from city_closure_source import shell_projection\nprojection_records = shell_projection(layout)","from city_closure_source import shell_projection, v2_layout\nsource_records = shell_projection(layout)\nheight_plan_path = ROOT/'art/data/city_elevations/source_plan.json'\nlayout = v2_layout(layout, json.loads(height_plan_path.read_text()))\nfloor = next(f for f in layout['floors'] if f['id']=='F01')\nrecords = [r for r in floor['furniture'] if is_city_shell(r['id']) and 'rect' in r and not r['id'].endswith('_beacon')]\nprojection_records = shell_projection(layout)")
t=t.replace("Path(__file__).with_name('city_closure_source.py')]}","Path(__file__).with_name('city_closure_source.py'),height_plan_path]}")
t=t.replace('"records":projection_records,','"source_records":source_records,\n    "records":projection_records,')
p.write_text(t,encoding='utf-8',newline='\n')
# All native roof consumers derive precisely the same projected layout, after
# checking original source/authoring bindings. No blanket stale-hash exception.
for name in ['closure','masts','aerials','tanks','beacons']:
 p=root/f'art/blender/scripts/build_city_{name}.py';t=p.read_text()
 if name=='closure':
  t=t.replace('from city_closure_source import check_registered_layout','from city_closure_source import check_registered_layout, v2_layout')
  t=t.replace('check_registered_layout(layout,json.loads(projection_path.read_text()),registration)',"height_plan=json.loads((ROOT/'art/data/city_elevations/source_plan.json').read_text())\ncheck_registered_layout(layout,json.loads(projection_path.read_text()),registration,height_plan)\nlayout=v2_layout(layout,height_plan)")
 else:
  marker='# The historical registration predates later blockout ports.'
  assert marker in t,name
  t=t.replace(marker,"from city_closure_source import check_registered_layout, v2_layout\nheight_plan=json.loads((ROOT/'art/data/city_elevations/source_plan.json').read_text())\ncheck_registered_layout(layout,json.loads((ROOT/'art/blender/city_shells_consumed_layout.json').read_text()),registration,height_plan)\nlayout=v2_layout(layout,height_plan)\n"+marker,1)
 # Bind helper+height plan in every exported construction report.
 t=t.replace("Path(__file__).with_name('city_registration.py'),ROOT/'game/data/runtime_material_sets.json'","Path(__file__).with_name('city_registration.py'),Path(__file__).with_name('city_closure_source.py'),ROOT/'art/data/city_elevations/source_plan.json',ROOT/'game/data/runtime_material_sets.json'")
 p.write_text(t,encoding='utf-8',newline='\n')
