$ErrorActionPreference='Stop'
$env:GIT_OPTIONAL_LOCKS='0'
$nativeArgs=@('--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440')
& ./tools/lane.ps1 run -Scene res://tests/OrisonV2CityClosureTest.tscn -Runner long -TimeoutSeconds 600 -Windowed -ShotDir C:/ov/reports/city_mass_20261028/world_closure -LogPath C:/ov/reports/city_mass_20261028/world_closure.log -ExtraArgs $nativeArgs -WaitMinutes 15
exit $LASTEXITCODE
