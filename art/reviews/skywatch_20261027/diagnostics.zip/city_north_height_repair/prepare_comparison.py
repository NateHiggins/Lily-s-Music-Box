from pathlib import Path
p=Path('C:/ov/reports/city_studies_20261028/compare_unrelated.py')
t=p.read_text().replace("SELECTED={'HORIZON_NEAR_0_0_P0R0','HORIZON_NEAR_0_0_P0R1','HORIZON_NEAR_0_0_P2'}","SELECTED={'site_far_n'}").replace('499ebad0','586a0ddd').replace("for family in ['near','far']:","for family in ['elevations','masts','aerials','tanks','beacons','shells']:").replace("'game/assets/props/city_horizon_'+family+'.glb'","'game/assets/props/city_'+family+'.glb'")
Path('C:/ov/reports/city_mass_20261028/compare_unrelated.py').write_text(t)
