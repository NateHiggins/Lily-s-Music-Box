from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();out=Path(__file__).parent;dest=root/'art/reviews/skywatch_20261027';a=dest/'diagnostics.zip';prefix='city_north_height_repair/'
r=json.loads((out/'bench_frozen.log.receipt.json').read_text());w=json.loads((out/'world_closure.log.receipt.json').read_text())
assert all(x['execution']['completed'] and x['execution']['exit_code']==0 for x in [r,w])
assert not (out/'bench_frozen.log.stderr').read_bytes() and not (out/'world_closure.log.stderr').read_bytes()
files=[p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.ps1','.json','.log','.stderr','.zip','.txt'}]
files += [out/'board/board.json',out/'board/board.md',out/'native/north_five_storeys.png',out/'imported_frozen/north_five_storeys.png']
files += sorted(out.glob('world_sheet_*.png'))
with zipfile.ZipFile(a,'a',zipfile.ZIP_DEFLATED) as z:
 assert not any(n.startswith(prefix) for n in z.namelist())
 for p in files:z.write(p,prefix+p.relative_to(out).as_posix())
m=json.loads((dest/'manifest.json').read_text())
m['city_north_height_repair']={'evidence_class':'INERT','base':'586a0ddd','scope':'One height/floor repair, not a fourth completed architectural study or full city qualification.',
 'height_m':{'before':44.,'body_after':16.25,'cap_after':16.51},'floor_heights_m':[3.25]*5,
 'diagnostics':{'native_support_samples':1205,'native_pane_samples':3489,'imported_checks':5213,'imported_seconds':r['execution']['elapsed_s'],'composed_checks':3846,'composed_seconds':w['execution']['elapsed_s'],'composed_capture_count':58,'shutdown_stderr_empty':True,'receipt_kind':'suite_run, not schema-2 runtime_contract'},
 'unrelated_arrays':json.loads((out/'unrelated_arrays_final.json').read_text()),'asset_deltas':json.loads((out/'asset_deltas.json').read_text()),
 'limits':['Greystone five-storey proportions inform height only; unique entrance, court, Tudor details and finish remain open.','Seven other oversized near-city masses remain.','Full surface/rendered-review qualification and frozen candidate gates pending.','Early board spans a report edit; its raw camera finding is fixed with a bound framing derivation and renewed spatial audit.','Ground reconstruction refused stale pavement binding; ground geometry was not changed or repinned.','First capture save error and later stale intermediate wrappers retained.','58 full-resolution composed captures remain external; their four inspected contact sheets are archived. No walked route, frame-rate or human acceptance claim.'],
 'captures':{str(p.relative_to(out)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'external_path':str(p),'review':'native/imported focused image or complete contact-sheet review'} for folder in ['native','imported_frozen','world_closure'] for p in (out/folder).glob('*.png')}}
with zipfile.ZipFile(a) as z:
 assert len(z.namelist())==len(set(z.namelist()))
 m['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
m['archive_sha256']=hashlib.sha256(a.read_bytes()).hexdigest()
(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archived',len(files),'diagnostic artifacts;',a.stat().st_size,'bytes total')
