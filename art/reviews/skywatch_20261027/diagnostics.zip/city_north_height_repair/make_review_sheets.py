from pathlib import Path
from PIL import Image,ImageDraw
root=Path('C:/ov/reports/city_mass_20261028');files=sorted((root/'world_closure').glob('*.png'))
for start in range(0,len(files),16):
 batch=files[start:start+16];sheet=Image.new('RGB',(1600,4*210),(24,24,24));draw=ImageDraw.Draw(sheet)
 for i,p in enumerate(batch):
  with Image.open(p) as im:
   im=im.convert('RGB');im.thumbnail((400,175));sheet.paste(im,((i%4)*400,(i//4)*210))
  draw.text(((i%4)*400+4,(i//4)*210+178),p.name,fill='white')
 sheet.save(root/f'world_sheet_{start//16}.png')
