$ErrorActionPreference='Stop'
foreach ($part in @('masts','aerials','tanks','beacons')) {
  & 'C:/Program Files/Blender Foundation/Blender 5.2/blender.exe' -b --python-exit-code 1 --python "art/blender/scripts/build_city_$part.py" *> "C:/ov/reports/city_mass_20261028/$part.log"
  if ($LASTEXITCODE -ne 0) { throw "$part failed: $LASTEXITCODE" }
}
$env:CITY_ELEVATIONS_REVIEW_DIR='C:/ov/reports/city_mass_20261028/native'
& 'C:/Program Files/Blender Foundation/Blender 5.2/blender.exe' -b --python-exit-code 1 --python art/blender/scripts/build_city_elevations.py *> C:/ov/reports/city_mass_20261028/elevations.log
if ($LASTEXITCODE -ne 0) { throw "elevations failed: $LASTEXITCODE" }
