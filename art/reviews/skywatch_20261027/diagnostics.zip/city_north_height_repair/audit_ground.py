from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();out=Path(__file__).parent
plan=json.loads((root/'art/data/orison_ground/retained_grade_source.json').read_text())
rows=[]
for name,expected in plan['bindings'].items():
 p=root/name;raw=p.read_bytes();raw=raw if p.suffix in ['.blend','.glb','.bin'] else raw.replace(b'\r\n',b'\n');actual=hashlib.sha256(raw).hexdigest()
 if actual!=expected:
  prior=subprocess.check_output(['git','show','586a0ddd:'+name]);prior=prior if p.suffix in ['.blend','.glb','.bin'] else prior.replace(b'\r\n',b'\n')
  rows.append({'path':name,'expected':expected,'actual':actual,'prior_sha256':hashlib.sha256(prior).hexdigest(),'already_mismatched_at_586a0ddd':hashlib.sha256(prior).hexdigest()!=expected})
(out/'ground_binding_refusal.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Read-only binding audit after the reconciliation refusal, not renewed ground acceptance.','original_failure':'Observed in tool transcript: AssertionError: art/blender/front_pavement.blend; reconciliation stopped before writing.','mismatches':rows,'ground_glb_byte_identical_to_parent':(root/'game/assets/props/orison_ground.glb').read_bytes()==subprocess.check_output(['git','show','586a0ddd:game/assets/props/orison_ground.glb'])},indent=2)+'\n')
print('Read-only ground audit saved',len(rows),'mismatches')
