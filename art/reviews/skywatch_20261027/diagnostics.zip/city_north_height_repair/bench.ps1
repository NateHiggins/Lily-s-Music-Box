$ErrorActionPreference='Stop'
Set-Location -LiteralPath C:/PleaseRemainOnTheLine
$env:GIT_OPTIONAL_LOCKS='0'
$before=@(git ls-files --others --exclude-standard)
[IO.File]::WriteAllText('C:/ov/reports/city_mass_20261028/untracked_before_import.txt',($before -join "`n"),[Text.UTF8Encoding]::new($false))
$nativeArgs=@('--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440')
$runs=@(
 @{scene='';runner='serial';timeout=175;windowed=$false;shot_dir='';log='C:/ov/reports/city_mass_20261028/import.log';extra_args=@('--editor','--import','--quit')},
 @{scene='res://tests/V2CityElevationBench.tscn';runner='serial';timeout=175;windowed=$true;shot_dir='C:/ov/reports/city_mass_20261028/imported';log='C:/ov/reports/city_mass_20261028/bench.log';extra_args=$nativeArgs}
)
$runs | ConvertTo-Json -Depth 5 | Set-Content C:/ov/reports/city_mass_20261028/bench.json -Encoding utf8
& ./tools/lane.ps1 batch -BatchFile C:/ov/reports/city_mass_20261028/bench.json -WaitMinutes 15
exit $LASTEXITCODE
