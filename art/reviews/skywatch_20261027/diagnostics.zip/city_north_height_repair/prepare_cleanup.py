from pathlib import Path
p=Path('C:/ov/reports/city_studies_20261028/clean_bearing_import.py')
t=p.read_text().replace('untracked_before_bearing_import.txt','untracked_before_import.txt').replace('import_bearings.log.receipt.json','import.log.receipt.json').replace('bearing_generated_import_churn.zip','generated_import_churn.zip').replace('bearing_import_cleanup.json','import_cleanup.json')
Path('C:/ov/reports/city_mass_20261028/clean_import.py').write_text(t)
