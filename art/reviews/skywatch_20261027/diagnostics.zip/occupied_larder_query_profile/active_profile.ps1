$ErrorActionPreference='Stop'
Set-Location -LiteralPath C:/PleaseRemainOnTheLine
Remove-Item Env:V2_PROFILE_RELEASES,Env:SKYWATCH_MIRAGE_PROFILE,Env:WEATHER_RESOURCE_SCOPE_CONTROL,Env:WEATHER_LIFECYCLE_REVIEW,Env:WEATHER_FALLOUT_RELOAD,Env:WEATHER_PRECIP_REVIEW,Env:SKY_LIBRARY_YEAR,Env:SKY_NATIVE_SAMPLING_PLAN,Env:SKY_REVIEW_SHADER_SOURCE,Env:SKYWATCH_OPTICAL_REVIEW,Env:WEATHER_SIMULATE,Env:WEATHER_FORMATION,Env:WEATHER_PHENOMENON,Env:DAYNIGHT_FORCE -ErrorAction SilentlyContinue
$env:SKYWATCH_CLOUD_PROFILE='1'
$nativeArgs=@('--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440','--debug','--profiling','--ignore-error-breaks')
& ./tools/lane.ps1 run -Scene res://tests/V2WeatherRouteProfile.tscn -Runner long -TimeoutSeconds 850 -Windowed -ShotDir C:/ov/reports/skywatch44/profile_active -LogPath C:/ov/reports/skywatch44/profile_active.log -ExtraArgs $nativeArgs -WaitMinutes 15
exit $LASTEXITCODE
