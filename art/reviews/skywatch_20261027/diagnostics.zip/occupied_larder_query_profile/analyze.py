from pathlib import Path
import collections
import hashlib
import json
import re
import statistics

ROOT = Path('C:/ov/reports/skywatch44')
def percentile(values, fraction):
    values = sorted(values)
    if not values: return None
    at = (len(values)-1)*fraction
    low = int(at)
    return values[low] + (values[min(low+1,len(values)-1)]-values[low])*(at-low)
def distribution(values):
    return {'n':len(values),'p50':percentile(values,.5),'p95':percentile(values,.95),'p99':percentile(values,.99),'max':max(values) if values else None}
def route(name):
    source=ROOT/name/'cloud_world_frames.json'
    data=json.loads(source.read_text())
    rows=data['samples']
    result={'resolution':data['resolution'],'msaa':data['msaa'],'taa':data['taa'],'failures':data['failures'],'source_before':data['source_before'],'source_after':data['source_after'],'wall_ms':distribution([x[1] for x in rows]),'gpu_ms':distribution([x[5] for x in rows]),'blocks':[]}
    for b in data['blocks']:
        subset=rows[b['frame_start']:b['frame_end']]
        result['blocks'].append({'id':b['id'],'waypoints':b['waypoints'],'first_traversal':b['first_traversal'],'wall_ms':distribution([x[1] for x in subset]),'gpu_ms':distribution([x[5] for x in subset])})
    return result

def profile():
    log=ROOT/'profile_active.log'
    frames=[]; accumulated=None; frame=None; signature=None; window_ready=False
    header=re.compile(r'^FRAME: total: ([\d.eE+-]+) script: ([\d.eE+-]+)/')
    value=re.compile(r'^\s*total: ([\d.eE+-]+)/.*?self: ([\d.eE+-]+)/.*?tcalls: (\d+)')
    for line in log.read_text(encoding='utf-8',errors='replace').splitlines():
        if line.startswith('NATIVE DEBUG WINDOW:'):window_ready=True
        match=header.match(line)
        if match:
            frame={'window_ready':window_ready,'frame_ms':float(match[1])*1000,'script_ms':float(match[2])*1000,'functions':[]}
            frames.append(frame);signature=None;continue
        if line.startswith('ACCUMULATED:'):
            accumulated={'functions':[]};frame=accumulated;signature=None;continue
        match=re.match(r'^\d+:(.+)',line)
        if match:signature=match[1];continue
        match=value.match(line)
        if match and frame is not None and signature:
            frame['functions'].append({'signature':signature,'total_ms':float(match[1])*1000,'self_ms':float(match[2])*1000,'calls':int(match[3])})
            signature=None
    occupied=[f for f in frames if f['window_ready'] and any('player_controller.gd' in x['signature'] for x in f['functions'])]
    grouped=collections.defaultdict(list)
    for i,f in enumerate(occupied):
        for row in f['functions']:grouped[row['signature']].append((i,row))
    functions=[]
    for signature, rows in grouped.items():
        costs=[x['self_ms'] for _,x in rows]
        functions.append({'signature':signature,'sampled_frames_present':len(rows),'sampled_self_ms_mean_over_all_occupied_frames':sum(costs)/max(1,len(occupied)),'self_ms_when_present':distribution(costs),'calls_in_sampled_frames':sum(x['calls'] for _,x in rows)})
    functions.sort(key=lambda x:x['sampled_self_ms_mean_over_all_occupied_frames'],reverse=True)
    return {'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'latest_frame_prints':len(frames),'occupied_frame_prints':len(occupied),'sampling_limit':'Latest frame once per second, not all frames. Occupied selection begins after native-window message and requires player callback in that sampled frame. Does not align exactly to measured route collection. Self time includes native work charged to scripts. Shutdown accumulation includes startup.','sampled_frame_ms':distribution([f['frame_ms'] for f in occupied]),'sampled_script_ms':distribution([f['script_ms'] for f in occupied]),'ranked_occupied_functions':functions,'accumulated_functions':sorted((accumulated or {}).get('functions',[]),key=lambda x:x['self_ms'],reverse=True)}

if __name__=='__main__':
    result={'evidence_class':'INERT','scope':'Matched diagnostic routes; local debugger plus profiler cost/ranking, not normal-FPS qualification or whole-world acceptance. Original --profiling-only attempt was cancelled with no active debugger and supplies no profile.','plain':route('plain'),'profiled':route('profile_active'),'script_profile':profile()}
    result['route_after']=route('route_after')
    before=json.loads((ROOT/'queries_before_clean.json').read_text())
    after=json.loads((ROOT/'queries_after.json').read_text())
    result['queries']={'before_ms':distribution(before['samples_ms']),'after_ms':distribution(after['samples_ms']),'identical_answers':before['answers']==after['answers'],'identical_inventory':before['inventory']==after['inventory'],'identical_larder':before['larder']==after['larder']}
    (ROOT/'analysis.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({name:result[name] for name in ['plain','profiled']},indent=2))
    print(json.dumps({'top_functions':result['script_profile']['ranked_occupied_functions'][:15]},indent=2))
