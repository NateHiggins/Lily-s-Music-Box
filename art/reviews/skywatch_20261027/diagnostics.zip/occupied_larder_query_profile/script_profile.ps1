$ErrorActionPreference='Stop'
Set-Location -LiteralPath C:/PleaseRemainOnTheLine
Remove-Item Env:V2_PROFILE_RELEASES,Env:SKYWATCH_MIRAGE_PROFILE,Env:WEATHER_RESOURCE_SCOPE_CONTROL,Env:WEATHER_LIFECYCLE_REVIEW,Env:WEATHER_FALLOUT_RELOAD,Env:WEATHER_PRECIP_REVIEW,Env:SKY_LIBRARY_YEAR,Env:SKY_NATIVE_SAMPLING_PLAN,Env:SKY_REVIEW_SHADER_SOURCE,Env:SKYWATCH_OPTICAL_REVIEW,Env:WEATHER_SIMULATE,Env:WEATHER_FORMATION,Env:WEATHER_PHENOMENON,Env:DAYNIGHT_FORCE -ErrorAction SilentlyContinue
$env:SKYWATCH_CLOUD_PROFILE='1'
$nativeArgs=@('--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440')
$runs=@(
    @{scene='res://tests/V2WeatherRouteProfile.tscn';runner='long';timeout=700;windowed=$true;shot_dir='C:/ov/reports/skywatch44/plain';log='C:/ov/reports/skywatch44/plain.log';extra_args=$nativeArgs},
    @{scene='res://tests/V2WeatherRouteProfile.tscn';runner='long';timeout=850;windowed=$true;shot_dir='C:/ov/reports/skywatch44/profile';log='C:/ov/reports/skywatch44/profile.log';extra_args=($nativeArgs+@('--profiling'))}
)
$runs | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath C:/ov/reports/skywatch44/batch.json -Encoding utf8
& ./tools/lane.ps1 batch -BatchFile C:/ov/reports/skywatch44/batch.json -WaitMinutes 15
exit $LASTEXITCODE
