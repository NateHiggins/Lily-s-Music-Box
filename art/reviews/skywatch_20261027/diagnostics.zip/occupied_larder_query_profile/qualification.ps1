$ErrorActionPreference='Stop'
Set-Location -LiteralPath C:/PleaseRemainOnTheLine
Remove-Item Env:AGENDA_QUERY_ONLY,Env:AGENDA_QUERY_PROFILE,Env:V2_PROFILE_RELEASES,Env:SKYWATCH_MIRAGE_PROFILE,Env:WEATHER_RESOURCE_SCOPE_CONTROL,Env:WEATHER_LIFECYCLE_REVIEW,Env:WEATHER_FALLOUT_RELOAD,Env:WEATHER_PRECIP_REVIEW,Env:SKY_LIBRARY_YEAR,Env:SKY_NATIVE_SAMPLING_PLAN,Env:SKY_REVIEW_SHADER_SOURCE,Env:SKYWATCH_OPTICAL_REVIEW,Env:WEATHER_SIMULATE,Env:WEATHER_FORMATION,Env:WEATHER_PHENOMENON,Env:DAYNIGHT_FORCE -ErrorAction SilentlyContinue
$env:SKYWATCH_CLOUD_PROFILE='1'
$nativeArgs=@('--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440')
$runs=@(
    @{scene='res://tests/ResidentAgendaTest.tscn';runner='serial';timeout=175;windowed=$false;shot_dir='';log='C:/ov/reports/skywatch44/agenda_after.log';extra_args=@()},
    @{scene='res://tests/V2WeatherRouteProfile.tscn';runner='long';timeout=700;windowed=$true;shot_dir='C:/ov/reports/skywatch44/route_after';log='C:/ov/reports/skywatch44/route_after.log';extra_args=$nativeArgs}
)
$runs | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath C:/ov/reports/skywatch44/qualification.json -Encoding utf8
& ./tools/lane.ps1 batch -BatchFile C:/ov/reports/skywatch44/qualification.json -WaitMinutes 15
exit $LASTEXITCODE
