from pathlib import Path
import hashlib,json,subprocess,zipfile

root=Path('C:/PleaseRemainOnTheLine')
source=Path(__file__).parent
destination=root/'art/reviews/skywatch_20261027'
archive=destination/'diagnostics.zip'
prefix='occupied_larder_query_profile/'
engine=Path('C:/devkit/tentacle-engine-fix/godot-4.7.1-stable')
hashes={name:hashlib.sha256((engine/name).read_text(encoding='utf-8').encode()).hexdigest() for name in ['main/main.cpp','core/debugger/engine_debugger.cpp','core/debugger/local_debugger.cpp','modules/gdscript/gdscript.cpp']}
provenance={
 'evidence_class':'INERT','baseline':'c5f8400a27d582738c620f23c0a887f4ae9724e8',
 'engine_source_lf_sha256':hashes,
 'qualification':'query_after:13 checks; agenda_after:40 checks; route_after:124 waypoints. Wrappers bind final code; route diagnostics are not a whole-world runtime contract.',
 'failures':'profile: deliberately cancelled owned process after inactive --profiling-only launch, exit -1; profile_active: six waypoints, two failures, observer-distorted route, exit1. Both retained.',
 'baseline_history':'main_baseline is dirty and source-mutated during checks; it is NOT used. clean_main_baseline has114 gates, exact main commit, dirty_paths[], frozen throughout.',
 'timing_limits':'agenda_before overlaps preliminary static checks and uses an earlier fixture variant. Only query_before_clean/queries_before_clean.json is the final-fixture uncontended kernel baseline. No world FPS or ordinary first-view callback improvement established.',
 'component_invocation':{'scene':'res://tests/ResidentAgendaTest.tscn','runner':'serial','windowed':False,'environment':{'AGENDA_QUERY_ONLY':'1','AGENDA_QUERY_PROFILE':'C:/ov/reports/skywatch44/queries_before_clean.json or queries_after.json'},'before_kernel':'kitchen_larder_before.gd','after_kernel':'kitchen_larder_after.gd'},
 'host':'Intel i7-13700KF; NVIDIA RTX4080; patched4.7.1 LLVM Vulkan',
 'candidate_verification':'pending; no whole-V2 or human acceptance'
}
(source/'provenance.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
 assert not any(name.startswith(prefix) for name in z.namelist())
 for f in source.rglob('*'):
  if f.is_file() and f.suffix.lower() not in ['.png','.pyc'] and '__pycache__' not in f.parts:
   z.write(f,prefix+f.relative_to(source).as_posix())
m=json.loads((destination/'manifest.json').read_text())
m['occupied_larder_query_profile']=provenance
m['occupied_larder_query_profile']['capture_sha256']={f.relative_to(source).as_posix():{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'external_path':str(f)} for f in source.rglob('*.png')}
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))
 m['members']={name:hashlib.sha256(z.read(name)).hexdigest() for name in z.namelist()}
m['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
(destination/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Retained diagnostic packet, bytes',archive.stat().st_size)
