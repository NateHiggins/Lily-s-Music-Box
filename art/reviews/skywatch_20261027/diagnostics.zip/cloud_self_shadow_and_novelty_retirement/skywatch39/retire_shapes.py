from pathlib import Path
root=Path.cwd()
def read(p): return (root/p).read_text(encoding='utf-8')
def write(p,s): (root/p).write_text(s,encoding='utf-8',newline='\n')
p='game/scripts/building/WeatherManager.gd';s=read(p)
for line in ['const SHAPE_START_MINUTE := 12.0*60.0\n','var _shape_age := 900.0\n','var _shape := 0\n','\t\t_publish_shape()\n','\t# A full publication cannot leave appearance waiting on the 10 Hz motion gate.\n','\t_publish_shape()\n']: s=s.replace(line,'')
a=s.index('static func shape_for_day(');b=s.index('func _process(',a);s=s[:a]+s[b:]
a=s.index('\t\t_shape=shape_for_day');b=s.index('\t_update_phenomena(delta)',a);s=s[:a]+s[b:]
a=s.index('func _publish_shape()');b=s.index('func _publish()',a);s=s[:a]+s[b:];write(p,s)
for p in ['game/shaders/queens_weather_sky.gdshader','game/shaders/v2_seasonal_sky.gdshader']:
 s=read(p);s=s.replace('uniform int shape_kind = 0;\n','').replace('uniform float shape_opacity = 0.0;\n','')
 a=s.index('float cloud_object(');b=s.index('float density_tagged(',a);s=s[:a]+s[b:]
 a=s.index('    if',s.index('float density_tagged('))
 # Remove just the novelty density branch, leaving real rare formations intact.
 a=s.index('    if',s.index('shape_kind',a)-10) if False else s.rfind('    if',0,s.index('shape_kind',s.index('float density_tagged(')))
 b=s.index('    }',a)+6;s=s[:a]+s[b:]
 s='\n'.join(line for line in s.split('\n') if not ('shape_kind' in line and 'ceiling=' in line))
 s=s.replace('+(shape_kind>0 ? shape_opacity : 0.0)','').replace('(shape_kind>0 && shape_opacity>0.0) ? 64.0 : 40.0','40.0').replace('(shape_kind>0 && shape_opacity>0.0) || base_low<1.25 ? 64 : 48','base_low<1.25 ? 64 : 48')
 write(p,s)
p='game/tests/skywatch_optical_review.gd';s=read(p)
a=s.index('\t\t\tcheck(absf(bench.manager._shape_age');b=s.index('\t\t\tbench.manager._process(0.)',a);s=s[:a]+s[b:]
a=s.index('\t\t\tbench.sky_material.set_shader_parameter("shape_opacity",1.)');b=s.index('\t\t\tfor uniform:',a);s=s[:a]+s[b:]
s='\n'.join(line for line in s.split('\n') if not any(t in line for t in ['set_shader_parameter("shape_', 'bench.manager._shape_age', '# Isolate ordinary density from the retained random animal SDF,','# whose appearance envelope still follows instance uptime.']))
s=s.replace('"shape_opacity",','');write(p,s)
p='game/tests/v2_millwork_weather_test.gd';s=read(p);a=s.index('\tvar shapes := 0');b=s.index('\t# Independently',a);s=s[:a]+s[b:];write(p,s)
p='game/tests/v2_millwork_weather_review.gd';s=read(p);a=s.index('\tfor shape in [1,2,3]:');b=s.index('\tmanager.set_process(true)',a);s=s[:a]+s[b:];write(p,s)
p='game/tests/v2_sky_review.gd';s=read(p);a=s.index('\tmat.set_shader_parameter("cloud_coverage",.08)');b=s.index('\tclock.configure_date(1928,7,15,1140)',a);s=s[:a]+s[b:];write(p,s)
p='game/docs/V2_MILLWORK_AND_WEATHER.md';s=read(p);a=s.index('One deterministic 1%');b=s.index('Run lightweight',a);s=s[:a]+'The experimental duck, whale and ship cloud silhouettes were retired at the\nowner\'s request on 2026-10-27. Ordinary and meteorological rare formations remain.\nExisting `WEATHER_SIMULATE`, `WEATHER_SEED`, `DAYNIGHT_FORCE`, and reduced-flash\nsettings remain available.\n\n'+s[b:];s=s.replace('the cloud shader adds stratified ray jitter.','the current Queens cloud shader uses coherent midpoint sampling.');write(p,s)
p='tools/audit_period_dates.py';write(p,read(p).replace('campaign_season_and_deterministic_cloud_shape','campaign_season_and_weather_presentation'))
