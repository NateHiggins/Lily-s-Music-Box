from pathlib import Path
from PIL import Image,ImageDraw
import json
out=Path('C:/ov/reports/skywatch39'); folder=Path('art/reviews/skywatch_20261027')
sheet=Image.new('RGB',(1600,980),'#18181b');draw=ImageDraw.Draw(sheet)
for row,(name,box) in enumerate([('000_cu_1928_colour.png',(500,150,1300,600)),('002_cb_1928_colour.png',(1100,300,1900,750))]):
 for col,variant in enumerate(['midpoint','final_detail']):
  sheet.paste(Image.open(out/variant/name).convert('RGB').crop(box),(col*800,row*490+35))
  draw.text((col*800+8,row*490+8),variant+' / native pixels / '+('Cu' if row==0 else 'Cb'),fill='white')
sheet.save(folder/'cloud_lighting_contact.png')
for variant in ['midpoint','final_detail']:
 d=json.loads((out/variant/'native_detail.json').read_text())
 print(variant,[(r['period'],round(r['mean_alpha_upper_frame'],6),round(r['fraction_alpha_above_point_one'],6)) for r in d['rows']])
