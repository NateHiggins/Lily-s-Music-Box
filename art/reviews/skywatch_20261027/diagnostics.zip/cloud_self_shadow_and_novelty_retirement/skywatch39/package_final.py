from pathlib import Path
import zipfile,json,hashlib
root=Path.cwd();out=Path('C:/ov/reports/skywatch39');folder=root/'art/reviews/skywatch_20261027';archive=folder/'diagnostics.zip';prefix='cloud_self_shadow_and_novelty_retirement/'
manifest=json.loads((folder/'manifest.json').read_text());scope={'evidence_class':'INERT','scope':'Cloud self-shadow controls and owner-retired novelty; diagnostic renders and prior source-bound world ABBA, no renewed surface/annual/human acceptance','source_lf_sha256':{},'capture_files':{}}
paths=['game/scripts/building/WeatherManager.gd','game/scripts/building/roof_weather_preview.gd','game/shaders/queens_weather_math.gdshaderinc','game/shaders/queens_weather_sky.gdshader','game/shaders/v2_seasonal_sky.gdshader','game/tests/skywatch_optical_review.gd','game/tests/v2_millwork_weather_review.gd','game/tests/v2_millwork_weather_test.gd','game/tests/v2_sky_review.gd','tools/v2_surface_evidence.py','tools/tests/test_v2_surface_requirements.py']
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
 assert not any(n.startswith(prefix) for n in z.namelist())
 for name in paths:
  b=(root/name).read_bytes();scope['source_lf_sha256'][name]=hashlib.sha256(b.replace(b'\r\n',b'\n')).hexdigest();z.writestr(prefix+'final_source/'+name,b)
 for f in sorted(out.rglob('*')):
  if not f.is_file():continue
  relative=f.relative_to(out).as_posix()
  if f.suffix=='.png':scope['capture_files'][str(f)]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size}
  elif f.suffix in ['.json','.py','.gdshader'] or '.log' in f.name:z.write(f,prefix+'skywatch39/'+relative)
 for sub in ['main_baseline','candidate_ad9302f8']:
  parent=Path('C:/ov/reports/skywatch38')/sub
  for f in parent.rglob('*'):
   if f.is_file():z.write(f,prefix+'skywatch38/'+sub+'/'+f.relative_to(parent).as_posix())
scope['contact_sha256']=hashlib.sha256((folder/'cloud_lighting_contact.png').read_bytes()).hexdigest();manifest['cloud_self_shadow_and_novelty_retirement']=scope
with zipfile.ZipFile(archive) as z:manifest['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
manifest['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest();(folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',newline='\n')
print('Evidence archive',archive.stat().st_size,'bytes; native contact',(folder/'cloud_lighting_contact.png').stat().st_size,'bytes')
