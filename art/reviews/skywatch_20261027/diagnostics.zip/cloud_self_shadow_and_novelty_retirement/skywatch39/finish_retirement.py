from pathlib import Path
p=Path('game/shaders/v2_seasonal_sky.gdshader');s=p.read_text();s=s.replace('(shape_kind>0 && shape_opacity>0.0) || base_low<1.25 ? 64 : 40','base_low<1.25 ? 64 : 40');p.write_text(s,newline='\n')
p=Path('game/scripts/building/roof_weather_preview.gd');p.write_text(p.read_text().replace('"WEATHER_CLOUD_SHAPE",',''),newline='\n')
p=Path('tools/v2_surface_evidence.py');s=p.read_text().replace("'.bin','.rg8'","'.bin','.rg8','.r8','.rgb8'");p.write_text(s,newline='\n')
p=Path('tools/tests/test_v2_surface_requirements.py');s=p.read_text();marker='    def test_material_sources_cannot_escape_or_disappear(self):';assert marker in s
s=s.replace(marker,'''    def test_raw_cloud_fields_expire_surface_proof(self):
        import v2_surface_evidence as evidence
        with patch.object(evidence,'file_hash',return_value='source'):
            before=evidence.inputs()['sha256']
        for name in ('perlin_worley_128.r8','cloud_curl_32.rgb8'):
            with self.subTest(name=name):
                with patch.object(evidence,'file_hash',side_effect=lambda path:
                                  'changed' if path.name==name else 'source'):
                    self.assertNotEqual(before,evidence.inputs()['sha256'])

'''+marker);p.write_text(s,newline='\n')
