from pathlib import Path
import json
out=Path('C:/ov/reports/skywatch39')
source=(out/'filtered.gdshader').read_text()
source=source.replace('    float x=(h-a)/(b-a);float w=max(.0001,width/(b-a));','    if(width<.0001)return smoothstep(a,b,h);\n    float x=(h-a)/(b-a);float w=max(.0001,width/(b-a));')
macro='clamp(log2(max(1.0,128.0*max(qwidth*mark_scale,hwidth*.55))),1.0,6.0)'
detail='clamp(log2(max(1.0,64.0*3.0*max(qwidth*mark_scale,hwidth*.55))),1.0,5.0)'
assert macro in source and detail in source
no_macro=source.replace(macro,'1.0')
height_only=no_macro.replace(detail,'1.0')
shadow_only=source.replace('float d=density_tagged(p,fire,footprint);','float d=density_tagged(p,fire,vec3(0.0));')
for name,text in {'no_macro':no_macro,'height_only':height_only,'shadow_only':shadow_only}.items():
 (out/(name+'.gdshader')).write_text(text,encoding='utf-8',newline='\n')
 spec={'scene':'res://tests/V2SkySpectacleBench.tscn','runner':'long','timeout':300,'windowed':True,'shot_dir':str(out/name),'log':str(out/(name+'.log')),'extra_args':['--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440']}
 (out/(name+'_batch.json')).write_text(json.dumps([spec],indent=2),encoding='utf-8')
print('Isolated height integration, erosion filtering and light-only filtering')
