from pathlib import Path
import re,json,hashlib
root=Path.cwd()/'game';out=Path('C:/ov/reports/skywatch38');out.mkdir(exist_ok=True)
def expand(path,chain=()):
 assert str(path) not in chain
 text=path.read_text(encoding='utf-8').replace('\r\n','\n')
 return re.sub(r'#include\s+"res://([^"]+)"',lambda m:expand(root/m.group(1),chain+(str(path),)),text)
source=expand(root/'shaders/queens_weather_sky.gdshader')
expression='fract(sin(dot(screen_uv*vec2(1280.0,720.0),vec2(12.9898,78.233))+temporal_phase*13.17)*43758.5453)'
assert source.count('float jitter='+expression+';')==2
variants={'current':source,'midpoint':source.replace('float jitter='+expression+';','float jitter=0.5;'),'small_jitter':source.replace('float jitter='+expression+';','float jitter=0.5+0.04*('+expression+'-0.5);')}
for name,text in variants.items():
 (out/(name+'.gdshader')).write_text(text,encoding='utf-8',newline='\n')
 spec={'scene':'res://tests/V2SkySpectacleBench.tscn','runner':'long','timeout':300,'windowed':True,'shot_dir':str(out/name),'log':str(out/(name+'.log')),'extra_args':['--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440']}
 (out/(name+'_batch.json')).write_text(json.dumps([spec],indent=2),encoding='utf-8')
plan={'calendar_sha256':hashlib.sha256((root/'data/weather/campaign_weather.json').read_bytes()).hexdigest(),'captures':[{'date':date,'period':period,'seeds':[1928]} for date,period in [('1929-01-08T12:00:00','cu'),('1929-01-08T12:00:00','cu_repeat'),('1929-06-25T18:00:00','cb'),('1929-06-25T18:00:00','cb_repeat')]]}
(out/'plan.json').write_text(json.dumps(plan,indent=2),encoding='utf-8')
print('Three source-controlled jitter comparisons, four actual dated captures each')
