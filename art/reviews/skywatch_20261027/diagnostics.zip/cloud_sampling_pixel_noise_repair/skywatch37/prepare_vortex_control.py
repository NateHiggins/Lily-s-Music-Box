from pathlib import Path
import re,json,hashlib
root=Path.cwd()/'game'; out=Path('C:/ov/reports/skywatch37')
old=Path('C:/ov/reports/skywatch36/cloud_before_sources')
overrides={str(root/'shaders/queens_weather_sky.gdshader'):old/'queens_weather_sky.gdshader',str(root/'shaders/queens_weather_math.gdshaderinc'):old/'queens_weather_math.gdshaderinc'}
sources={}
def expand(path,chain=()):
 key=str(path)
 assert key not in chain,'include cycle'
 source=overrides.get(key,path)
 text=source.read_text(encoding='utf-8').replace('\r\n','\n')
 sources[str(source)] = hashlib.sha256(text.encode()).hexdigest()
 return re.sub(r'#include\s+"res://([^"]+)"',lambda match:expand(root/match.group(1),chain+(key,)),text)
text=expand(root/'shaders/queens_weather_sky.gdshader')
(out/'pre_flow_vortex_control.gdshader').write_text(text,encoding='utf-8',newline='\n')
(out/'pre_flow_vortex_sources.json').write_text(json.dumps(sources,indent=2),encoding='utf-8')
run={'scene':'res://tests/V2SkySpectacleBench.tscn','runner':'long','timeout':400,'windowed':True,'shot_dir':str(out/'vortex'),'log':str(out/'vortex.log'),'extra_args':['--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440']}
(out/'vortex_batch.json').write_text(json.dumps([run],indent=2),encoding='utf-8')
print('Prepared frozen pre-flow control and eight matched views')
