from pathlib import Path
import json,numpy as np
out=Path('C:/ov/reports/skywatch37');data=json.loads((out/'cloud_world/cloud_world_frames.json').read_text())
assert not data['failures'],data['failures']
assert len(data['blocks'])==4 and data['source_before']==data['source_after']
def distribution(rows,column):
 values=[row[column] for row in rows]
 return dict(zip(['p50','p95','p99','max'],np.percentile(values,[50,95,99,100]).tolist()))
blocks=[]
for block in data['blocks']:
 rows=data['samples'][block['frame_start']:block['frame_end']]
 parts={name:distribution(rows,column) for column,name in enumerate(data['columns']) if column in [1,2,3,4,5]}
 phases={label:distribution([row for row in rows if label in row[0]],1) for label in ['door_grab','outdoor_mouse_turn','outdoor_sky_hold'] if any(label in row[0] for row in rows)}
 residency={label:distribution([row for row in rows if row[6]==label],1) for label in sorted({row[6] for row in rows})}
 compilations={key:max(row[7][key] for row in rows)-min(row[7][key] for row in rows) for key in rows[0][7] if key.startswith('PIPELINE_COMPILATIONS')}
 blocks.append({'id':block['id'],'frames':len(rows),'waypoints':block['waypoints'],'distributions':parts,'phases':phases,'residency':residency,'pipeline_counter_growth':compilations})
report={'evidence_class':'INERT','scope':'same-world ABBA dated cloud-flow comparison; first traversal cold; live NPC/traffic variation remains; CPU/physics counters lag and overlap, cannot be summed or assigned to individual frames','resolution':data['resolution'],'msaa':data['msaa'],'taa':data['taa'],'calendar':data['calendar'],'blocks':blocks,'spikes':[{'phase':row[0],'wall_ms':row[1],'process_ms':row[2],'physics_ms':row[3],'render_cpu_ms':row[4],'render_gpu_ms':row[5],'residency':row[6]} for row in sorted(data['samples'],key=lambda row:row[1],reverse=True)[:12]]}
(out/'cloud_world_summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
for block in blocks:print(block['id'],block['frames'],block['distributions']['wall_ms'],'GPU',block['distributions']['render_gpu_ms'])
print('Spikes',report['spikes'][:4])
