from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import json,hashlib,zipfile,numpy as np
root=Path.cwd();out=Path('C:/ov/reports/skywatch38');prior=Path('C:/ov/reports/skywatch37');folder=root/'art/reviews/skywatch_20261027'
archive=folder/'diagnostics.zip';prefix='cloud_sampling_pixel_noise_repair/'
manifest=json.loads((folder/'manifest.json').read_text())
metrics={}
for name in ['current','midpoint','small_jitter']:
 image=Image.open(out/name/'002_cb_1928_colour.png').convert('RGB').crop((1000,100,2600,800))
 residual=np.asarray(image,dtype=float)-np.asarray(image.filter(ImageFilter.GaussianBlur(2)),dtype=float)
 metrics[name]={'displayed_crop_highpass_rms':float(np.sqrt(np.mean(residual**2))/255),'native_detail':json.loads((out/name/'native_detail.json').read_text())}
assert metrics['current']['native_detail']['rows'][2]['state']==metrics['midpoint']['native_detail']['rows'][2]['state']
(out/'noise_metrics.json').write_text(json.dumps({'evidence_class':'INERT','method':'RGB crop (1000,100)-(2600,800), displayed 8-bit values, 2px Gaussian residual, includes rain; not artistic acceptance','variants':metrics},indent=2)+'\n',encoding='utf-8')
sheet=Image.new('RGB',(1600,980),'#18181b');draw=ImageDraw.Draw(sheet)
for row,(label,filename) in enumerate([('storm','002_cb_1928_colour.png'),('cumulus','000_cu_1928_colour.png')]):
 for col,variant in enumerate(['current','midpoint']):
  # Native-pixel crops: no resampling that could hide the reported blocks.
  box=(1100,300,1900,750) if row==0 else (500,150,1300,600)
  image=Image.open(out/variant/filename).convert('RGB').crop(box)
  sheet.paste(image,(col*800,row*490+35));draw.text((col*800+8,row*490+8),label+' / '+variant+' / native crop',fill='white')
sheet.save(folder/'cloud_noise_contact.png')
paths=['game/shaders/queens_weather_sky.gdshader','game/shaders/queens_weather_math.gdshaderinc','game/tests/skywatch_optical_review.gd','game/tests/v2_weather_route_profile.gd','game/scripts/building/WeatherManager.gd','game/scripts/building/living_sky.gd','game/scripts/building/weather_noise.gd']
scope={'scope':'source-controlled cloud noise repair; component negatives and occupied diagnostics; not full surface/candidate/annual/human acceptance','source_lf_sha256':{},'captures':{}}
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
 assert not any(n.startswith(prefix) for n in z.namelist())
 for name in paths:
  b=(root/name).read_bytes();scope['source_lf_sha256'][name]=hashlib.sha256(b.replace(b'\r\n',b'\n')).hexdigest();z.writestr(prefix+'tested_source/'+name,b)
 for parent in [prior,out]:
  for f in sorted(parent.iterdir()):
   if f.is_file() and ('.log' in f.name or f.suffix in ['.json','.py','.gdshader']):z.write(f,prefix+parent.name+'/'+f.name)
   elif f.is_dir():
    for child in sorted(f.glob('*.json')):z.write(child,prefix+parent.name+'/'+f.name+'/'+child.name)
 for directory in [out/'current',out/'midpoint',out/'small_jitter',out/'midpoint_production',out/'midpoint_world',out/'vortex_midpoint']:
  for f in directory.glob('*.png'):scope['captures'][str(f)]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size}
scope['contact_sha256']=hashlib.sha256((folder/'cloud_noise_contact.png').read_bytes()).hexdigest();manifest['cloud_sampling_pixel_noise_repair']=scope
with zipfile.ZipFile(archive) as z:manifest['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
manifest['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
(folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archive bytes',archive.stat().st_size,'native contact bytes',(folder/'cloud_noise_contact.png').stat().st_size)
