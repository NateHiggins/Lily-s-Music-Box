from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();out=Path(__file__).parent;dest=root/'art/reviews/skywatch_20261027';archive=dest/'diagnostics.zip';prefix='city_height_batch/'
contract=json.loads((out/'surface_final/runtime_contract.json').read_text());assert contract['execution']['exit_code']==0
files=[p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.ps1','.json','.log','.stderr','.zip','.txt','.bin'}]
files += [out/'route/cloud_world_frames.json',out/'route/route.json',out/'surface_final/runtime_contract.json',out/'native_studies_fitted/review.json',out/'native_studies_fitted_sheet.png',out/'imported_fitted_sheet.png']
files += sorted(out.glob('surface_sheet_*.png'))
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
 assert not any(n.startswith(prefix) for n in z.namelist())
 for p in files:z.write(p,prefix+p.relative_to(out).as_posix())
m=json.loads((dest/'manifest.json').read_text())
m['city_height_batch']={'evidence_class':'INERT','base':'e10c0425','scope':'Seven more body-height/floor repairs, retaining the previous north repair and three horizon studies. 146 individual architectural studies and transport construction remain open.',
 'surface':{'checks':contract['checks'],'contracts':contract['contracts'],'surface_inputs_sha256':contract['surface_inputs_sha256'],'shutdown_stderr_empty':not(out/'surface_final.log.stderr').read_bytes(),'wrapper_seconds':775,'technical_visual_review_only':True,'captures_reviewed_via_contact_sheets':237,'individual_images_reviewed':7},
 'production_packet':'art/renders/orison_v2/surface_requirements_20261011','previous_packet_recovery':json.loads((out/'previous_surface_git_recovery.json').read_text()),
 'performance':json.loads((out/'performance_comparison.json').read_text()),'asset_deltas':json.loads((out/'asset_deltas.json').read_text()),'unrelated_arrays':json.loads((out/'unrelated_arrays_final.json').read_text()),'dependency_finalization':json.loads((out/'dependency_finalization.json').read_text()),
 'limits':['Height proportions do not complete individual architectural identities, courts, entrances, roofs or ornament.','Original outward/cropped camera attempts retained externally; fitted native/imported captures inspect complete bounds.','Original surface preflight failure retained; correct producer order and rerun, no hash repinning.','Earlier route/source-bound wrappers expire after fixture/native provenance finalization despite six byte-identical GLBs; measurements do not grant renewed qualification.','No demonstrated stutter gain. Node publication/resource changes are correlation; measure existing activation timing next.','No repeated hose interaction, new save reconstruction, human acceptance, annual-weather or whole-V2 completion claim.','Final frozen candidate verification/merge pending.'],
 'captures':{p.relative_to(out).as_posix():{'external_path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for folder in ['native_studies_fitted','imported_final','surface_final'] for p in (out/folder).rglob('*.png')}}
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()));m['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
m['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest();(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archived',len(files),'artifacts;',archive.stat().st_size,'total bytes. Prior PNGs recover from verified Git history, without duplicate archive payloads.')
