from pathlib import Path
import hashlib,json
r=Path.cwd();out=Path('C:/ov/reports/city_mass_batch_20261028')
paths=[f'game/assets/props/city_{f}.glb' for f in ['shells','elevations','masts','aerials','tanks','beacons']]
(out/'before_dependency_finalization.json').write_text(json.dumps({p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in paths},indent=2)+'\n')
p=out/'build_batch.ps1';p.write_text(p.read_text().replace("@('shells','closure','masts','aerials','tanks','beacons','elevations')","@('shells','masts','aerials','tanks','beacons','closure','elevations')"))
