import json,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'art/blender/scripts'))
from city_closure_source import check_registered_layout
read=lambda p:json.loads(Path(p).read_text())
try:
 check_registered_layout(read('art/data/building_layout.json'),read('art/blender/city_shells_consumed_layout.json'),read('art/blender/city_shells_registration.json'),read('art/data/city_elevations/source_plan.json'))
except AssertionError as e:print('EXPECTED OLD NATIVE REUSE REFUSAL:',e)
else:raise AssertionError('Stale native library incorrectly accepted')
