from pathlib import Path
s=Path('C:/ov/reports/city_relief_20261028/qualification.ps1').read_text().replace('city_relief_20261028','city_mass_batch_20261028')
start=s.index("    @{scene='res://tests/V2CityHorizonBench.tscn'")
end=s.index("    @{scene='res://tests/V2WeatherRouteProfile.tscn'",start)
s=s[:start]+s[end:]
Path('C:/ov/reports/city_mass_batch_20261028/qualification.ps1').write_text(s)
