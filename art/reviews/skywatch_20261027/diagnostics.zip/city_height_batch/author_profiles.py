import json
from pathlib import Path
p=Path('art/data/city_elevations/source_plan.json');s=json.loads(p.read_text())
programs={
 'site_far_nw':('Hampton Court, 35-16 79th Street, George H. Wells, 1919–21',[129],[3.5,3.3,3.3,3.3,3.3],1,'Angled frontage bays, central entry and five-storey Georgian block remain to be individually constructed.'),
 'site_far_ne':('The Towers, 33-16 81st Street, Andrew J. Thomas, 1923–25',[143],[3.6,3.25,3.25,3.25,3.25,3.2],1,'Six-storey Italianate hierarchy; asymmetrical corner tower, loggia, tiled roof and U court remain to be constructed.'),
 'site_far_e':('Sohmer & Company Piano Factory, 31-01 Vernon Boulevard, Berger & Baylies, c.1886',[5],[4.1,3.8,3.8,3.8,3.8,3.8],2,'Six generous factory storeys; segmental industrial windows and curved mansard clock tower remain to be individually constructed.'),
 'site_far_se':('Elm Court, 34-27 79th Street, George H. Wells, 1921–22',[136],[3.5,3.3,3.3,3.3],1,'Four-storey Georgian hierarchy; projecting balustraded entry, central stair bay and garden organisation remain to be constructed.'),
 'site_far_s':('The Chateau, 34-22 81st Street, Andrew J. Thomas, 1922',[145],[3.6,3.4,3.4,3.4,3.4,3.3],1,'Taller end-building hierarchy; asymmetric wing, mansard, dormers and carved portal remain to be constructed.'),
 'site_far_sw':('Laburnum Court, 37-15 79th Street, George H. Wells, 1921–22',[138],[3.5,3.3,3.3,3.3,3.3],1,'Five-storey hierarchy; H plan with recessed front courts, iron balcony and cornice remain to be constructed.'),
 'site_far_w':('Cambridge Court, 37-14 86th Street, George H. Wells, 1922',[203],[3.5,3.2,3.2,3.2],1,'Four-storey hierarchy; modified T plan, entrance porch and mansard/dormer variation remain to be constructed.')}
for r in s['buildings']:
 if r['id'] not in programs:continue
 name,pages,floors,upper,remaining=programs[r['id']]
 r.update(vertical_profile=[0.,floors[0],floors[0]+.34,sum(floors[:-upper]),sum(floors)],floor_heights=floors,
  description=name+' — authored proportion repair; individual architectural study remains open',
  precedent={'name':name,'source':'https://s-media.nyc.gov/agencies/lpc/lp/'+('2172.pdf' if r['id']=='site_far_e' else '1831.pdf'),'pdf_pages':pages,'adaptation':'Documented storey hierarchy, authored dimensions. Fixed original footprint and roof equipment retained for this repair. '+remaining})
p.write_text(json.dumps(s,indent=2)+'\n',encoding='utf-8',newline='\n')
