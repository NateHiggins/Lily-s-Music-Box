from pathlib import Path
import json
out=Path(__file__).parent;d=json.loads((out/'route/cloud_world_frames.json').read_text());rows=d['samples'];result=[]
for i in sorted(range(len(rows)),key=lambda i:rows[i][1],reverse=True)[:8]:
 before=rows[max(0,i-1)][7];now=rows[i][7]
 changes={k:now[k]-before.get(k,now[k]) for k in now if k.startswith(('PIPELINE_COMPILATIONS_','OBJECT_')) and now[k]!=before.get(k,now[k])}
 result.append({'index':i,'phase':rows[i][0],'wall_ms':rows[i][1],'main_render_cpu_ms':rows[i][4],'main_viewport_gpu_ms':rows[i][5],'residency':rows[i][6],'sampled_counter_changes':changes})
(out/'spike_correlations.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Adjacent sampled cumulative counters provide correlation only. Process/physics counters publish one-second peaks; main viewport timing excludes private viewports. No function or total GPU attribution.', 'spikes':result},indent=2)+'\n')
print(json.dumps(result[:3],indent=2))
