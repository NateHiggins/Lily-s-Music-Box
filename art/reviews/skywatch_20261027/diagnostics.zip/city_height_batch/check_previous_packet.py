from pathlib import Path
import gzip,hashlib,json,subprocess
out=Path(__file__).parent;backup=out/'publication_backup/previous_surface_packet';base='04d72f3a';rows=[]
for p in sorted(backup.iterdir()):
 name='surface-inventory.json' if p.name=='surface-inventory.json.gz' else p.name
 target='art/renders/orison_v2/surface_requirements_20261011/'+name
 raw=gzip.decompress(p.read_bytes()) if p.name=='surface-inventory.json.gz' else p.read_bytes()
 old=subprocess.check_output(['git','show',base+':'+target]);assert old==raw,target
 rows.append({'git_commit':base,'git_path':target,'sha256':hashlib.sha256(raw).hexdigest(),'external_backup':str(p),'backup_encoding':'gzip' if p.name=='surface-inventory.json.gz' else 'identity'})
(out/'previous_surface_git_recovery.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Every preceding surface-packet byte verified against immutable Git history; external publication backup retained. Do not duplicate historical PNGs in the new archive.','files':rows},indent=2)+'\n');print('Verified preceding packet:',len(rows),'files recoverable byte-for-byte from',base)
