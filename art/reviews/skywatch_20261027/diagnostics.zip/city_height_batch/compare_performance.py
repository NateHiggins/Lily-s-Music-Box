from pathlib import Path
import json,numpy as np
out=Path(__file__).parent
rows={}
for label,path in [('prior_relief',Path('C:/ov/reports/city_relief_20261028/route/cloud_world_frames.json')),('eight_heights',out/'route/cloud_world_frames.json')]:
 d=json.loads(path.read_text());samples=d['samples'];summary={}
 for column,name in [(1,'wall_ms'),(4,'main_render_cpu_ms'),(5,'main_viewport_gpu_ms')]:
  values=[s[column] for s in samples];summary[name]={str(p):float(np.percentile(values,p)) for p in [50,95,99,100]}
 summary['spikes']={str(limit):sum(s[1]>limit for s in samples) for limit in [33.333,50,100]}
 rows[label]={'frames':len(samples),'resolution':d['resolution'],'msaa':d['msaa'],'taa':d['taa'],'calendar':d['calendar'],'failures':d['failures'],'source_frozen_during_route':d['source_before']==d['source_after'],'summary':summary}
report={'evidence_class':'INERT','scope':'Same 124-waypoint route, cloud-control schedule and native settings. Live residents/traffic and collection variance remain. Subsequent native/fixture dependency finalization is separately checked for byte-identical runtime GLBs; the old route wrapper does not grant qualification after those metadata changes. No causal FPS speedup claimed. Process/physics monitors are one-second peaks, not per-frame attribution.', 'routes':rows}
(out/'performance_comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(rows,indent=2))
