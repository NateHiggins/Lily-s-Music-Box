from pathlib import Path
from PIL import Image,ImageDraw
root=Path('C:/ov/reports/city_mass_batch_20261028')
for folder in ['native_studies_v3']:
 files=sorted((root/folder).glob('*.png'));sheet=Image.new('RGB',(1600,((len(files)+3)//4)*280),(25,25,25));draw=ImageDraw.Draw(sheet)
 for i,p in enumerate(files):
  with Image.open(p) as im:
   im=im.convert('RGB');im.thumbnail((400,250));sheet.paste(im,((i%4)*400,(i//4)*280))
  draw.text(((i%4)*400+3,(i//4)*280+252),p.name,fill='white')
 sheet.save(root/(folder+'_sheet.png'))


