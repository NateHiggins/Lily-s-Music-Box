import json,hashlib
from pathlib import Path
out=Path(__file__).parent;before=json.loads((out/'before_dependency_finalization.json').read_text())
after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before}
assert before==after,(before,after)
(out/'dependency_finalization.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Native producers rerun in correct dependency order; all six runtime GLBs remain byte-identical. Native/provenance/test-fixture metadata changes still expire source-bound wrappers.','before_sha256':before,'after_sha256':after,'glbs_byte_identical':True},indent=2)+'\n')
print('All six GLBs byte-identical after dependency finalization')
