import json,subprocess
from pathlib import Path
out=Path('C:/ov/reports/city_mass_batch_20261028');root=Path.cwd()
rows={}
for family in ['elevations','masts','aerials','tanks','beacons']:
 n=f'art/blender/city_{family}_construction.json';a=json.loads(subprocess.check_output(['git','show','e10c0425:'+n]));b=json.loads((root/n).read_text());asset=f'game/assets/props/city_{family}.glb'
 rows[family]={'triangles_before':a['triangles'],'triangles_after':b['triangles'],'parts_before':len(a['parts']),'parts_after':len(b['parts']),'bytes_before':int(subprocess.check_output(['git','cat-file','-s','e10c0425:'+asset])),'bytes_after':(root/asset).stat().st_size}
(out/'asset_deltas.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
