from pathlib import Path
from PIL import Image,ImageDraw
import json
root=Path('C:/ov/reports/city_mass_batch_20261028');folder=root/'surface_final';files=sorted(folder.rglob('*.png'))
print(json.loads((folder/'runtime_contract.json').read_text())['contracts']);print('all captures',len(files),'stderr', (root/'surface_final.log.stderr').stat().st_size)
for start in range(0,len(files),36):
 batch=files[start:start+36];sheet=Image.new('RGB',(1800,6*155),(24,24,24));draw=ImageDraw.Draw(sheet)
 for i,p in enumerate(batch):
  with Image.open(p) as im:
   im=im.convert('RGB');im.thumbnail((300,126));sheet.paste(im,((i%6)*300,(i//6)*155))
  draw.text(((i%6)*300+2,(i//6)*155+128),p.relative_to(folder).as_posix()[:46],fill='white')
 sheet.save(root/f'surface_sheet_{start//36}.png')
