from pathlib import Path
p=Path('C:/ov/reports/city_mass_20261028/bench.ps1');Path('C:/ov/reports/city_mass_batch_20261028/bench.ps1').write_text(p.read_text().replace('city_mass_20261028','city_mass_batch_20261028'))
p=Path('C:/ov/reports/city_mass_20261028/clean_import.py');Path('C:/ov/reports/city_mass_batch_20261028/clean_import.py').write_text(p.read_text())
