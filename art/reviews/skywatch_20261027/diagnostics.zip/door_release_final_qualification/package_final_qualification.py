from pathlib import Path
import json,hashlib,zipfile,sys
r=Path.cwd();p=Path(__file__).parent;sys.path.insert(0,str(r/'tools'));import run_receipt
checks={}
for name in ['reload_final','surface_final','noise_scope_final','record_cache_canonical']:
 receipt=p/(name+'.log.receipt.json');code,errors=run_receipt.verify(receipt,r)
 assert code==0,(name,errors)
 data=json.loads(receipt.read_text());assert data['execution']['completed'] and data['execution']['exit_code']==0
 checks[name]={'binds':True,'errors':errors,'receipt_sha256':hashlib.sha256(receipt.read_bytes()).hexdigest()}
(p/'final_receipt_bindings.json').write_text(json.dumps(checks,indent=2)+'\n')
assert json.loads((p/'published_surface.json').read_text())['result']=='PASS'
dest=r/'art/reviews/skywatch_20261027';archive=dest/'diagnostics.zip';prefix='door_release_final_qualification/'
files=[]
for name in ['reload','reload_exact_cache','reload_final','surface','surface_final','noise_scope','noise_scope_exact','noise_scope_final','record_cache_final','record_cache_lf','record_cache_canonical']:
 for suffix in ['.log','.log.stderr','.log.receipt.json']:
  f=p/(name+suffix)
  if f.is_file():files.append((f,f.name))
 for filename in ['weather_lifecycle_contract.json','resource_scope.json','checks.json','runtime_contract.json','visual_review.json']:
  f=p/name/filename
  if f.is_file():files.append((f,name+'/'+filename))
for name in ['counter_semantics.json','lifecycle_before_noise_scope.gd','qualification.ps1','qualification_exact.ps1','qualification_final.ps1','published_surface.json','prepare_final_packet.py','final_receipt_bindings.json','surface_review_partial.jpg','main_baseline/board.json']:
 files.append((p/name,name))
for name in ['game/scripts/building/orison_v2_household_state.gd','game/scripts/props/door_prop.gd','game/tests/v2_weather_route_profile.gd','game/tests/v2_household_unchanged_bench.gd','game/tests/campaign_weather_world_review.gd']:
 files.append((r/name,'final_source/'+name))
f=p/'qualification_provenance.json'
f.write_text(json.dumps({'evidence_class':'INERT','status':'FINAL_SOURCE_RECEIPTS_BIND','scope':'Four fresh final-source wrappers bind; surface and disk reconstruction have separate test-written contracts. Original failures and diagnostic-only variants preserved. Candidate verification and human acceptance are separate.','raw_inventory':'Published surface-inventory.json is authoritative and bound by the fresh original contract; no duplicate large inventory in this archive.','intermediate_binding_limits':'Earlier component receipts may have CRLF/raw-test or temporary-timer runtime differences. Canonical LF cache fixture and exact noise-scope controls are rerun and bind to final source. The record_cache_lf attempt ran before successful normalization; its filename alone is not proof of LF bytes.','surface_preflight':'Original ten-second failure is preserved. Temporary door timers removed; geometry/fixture unchanged, no source repinning.','noise_scope':'Two exact static process-cache volumes newly recognized; separate same-class owned negative control remains tracked.'},indent=2)+'\n')
files.append((f,f.name));files.append((Path(__file__),'package_final_qualification.py'))
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
 assert not any(n.startswith(prefix) for n in z.namelist())
 for f,name in files:z.write(f,prefix+name)
m=json.loads((dest/'manifest.json').read_text())
m['door_release_final_qualification']={'evidence_class':'INERT','final_receipts_bind':True,'surface_checks':39169,'lifecycle_checks':43,'scope':'Actual final-source surface and isolated disk reconstruction/teardown; exact-identity cache fixture, state safety checks. No CampaignShell, whole-V2, human artistic or general performance acceptance.','source_snapshots_in_archive':True}
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))
 m['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
m['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Final qualification and original failures archived; bytes',archive.stat().st_size)
