from pathlib import Path
import json,hashlib,gzip,shutil
root=Path.cwd(); out=Path('C:/ov/reports/skywatch43'); p=out/'surface_final'
contract=json.loads((p/'runtime_contract.json').read_text()); receipt=json.loads((out/'surface_final.log.receipt.json').read_text())
assert contract['execution']['completed'] and contract['execution']['exit_code']==0
assert receipt['execution']['completed'] and receipt['execution']['exit_code']==0
shutil.copyfile(out/'surface_final.log.receipt.json',p/'suite_run.receipt.json')
for channel,suffix in [('stdout',''),('stderr','.stderr')]:
 raw=(out/('surface_final.log'+suffix)).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==receipt['log'][channel+'_sha256']
 (p/('suite_run.'+channel+'.log.gz')).write_bytes(gzip.compress(raw,mtime=0))
observations={
'city_street_skyline.png':'Brick courses, window surrounds and blind slats remain distinct beneath the blue sky with broad wisps. Representative composed-world surface view, not annual sky artistic acceptance.',
'city_weather_storm.png':'Storm haze reduces the distant roof blocks to blue-gray silhouettes while nearby parapets and tank structures remain legible. The very low-contrast storm ceiling in this diagnostic remains a presentation limitation, not approved as the final dramatic sky.',
'front_gallery_05.png':'Timber wainscot, pale plaster, textured floor, curtains and slatted blinds remain separate. Strong ceiling fixture highlights are retained; no new lighting-art approval.',
'street_paving.png':'Kerb, sidewalk joints, dark road and brick walls remain visually separate. Dark street exposure remains a presentation limitation, not a new wet/dry optical equivalence claim.',
'front_restored_entrance.png':'The installed paneled entrance, long brass pull, glazed marquee and brick/trim surrounds are visible together. This frame does not qualify door input or every architectural join.',
'public_arcade_hall.png':'Glazing reveals shop counters and furnishing stock; brick, lower timber panels, pale paving and canopy ribs remain distinct. No claim of every storefront clearance.',
 'tile_F02_A_BATH_corner.png':'Tile wainscot stops below plaster with a finishing cap ending at the door surround. Fine floor hexagons, curtain folds and suspended rings remain separate. No new plumbing or shower input claim.'}
review={'evidence_class':'INERT','status':'PASS','surface_inputs_sha256':contract['surface_inputs_sha256'],'images':[{'file':name,'sha256':hashlib.sha256((p/name).read_bytes()).hexdigest(),'observation':text,'origin':'Agent inspected actual native composed V2 capture, 3440x1440 fullscreen, patched Vulkan, final source bound by the test-written contract; technical surface review, not human acceptance'} for name,text in observations.items()]}
(p/'visual_review.json').write_text(json.dumps(review,indent=2)+'\n',newline='\n')
print('Prepared',len(observations),'reviewed images; unchanged fire interactions:',contract['interaction_programmes']['fire_service'])
