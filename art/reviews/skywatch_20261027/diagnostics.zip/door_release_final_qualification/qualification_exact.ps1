$ErrorActionPreference='Stop'
Set-Location -LiteralPath C:/PleaseRemainOnTheLine
$env:ORISON_SURFACE_SKIP_FIRE_INTERACTION='1'
Remove-Item Env:WEATHER_RESOURCE_SCOPE_CONTROL,Env:V2_PROFILE_RELEASES,Env:SKYWATCH_CLOUD_PROFILE,Env:SKYWATCH_MIRAGE_PROFILE,Env:WEATHER_PROFILE_CALENDAR,Env:SKY_LIBRARY_YEAR,Env:SKY_NATIVE_SAMPLING_PLAN,Env:SKY_REVIEW_SHADER_SOURCE,Env:SKYWATCH_OPTICAL_REVIEW,Env:WEATHER_SIMULATE,Env:WEATHER_FORMATION,Env:WEATHER_PHENOMENON,Env:DAYNIGHT_FORCE -ErrorAction SilentlyContinue
$env:WEATHER_LIFECYCLE_REVIEW='1'
$env:WEATHER_FALLOUT_RELOAD='1'
$env:WEATHER_PRECIP_REVIEW='0'
$nativeArgs=@('--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440')
& ./tools/lane.ps1 run -Scene res://tests/CampaignWeatherWorldReview.tscn -Runner long -TimeoutSeconds 700 -Windowed -ShotDir C:/ov/reports/skywatch43/reload_exact_cache -LogPath C:/ov/reports/skywatch43/reload_exact_cache.log -ExtraArgs $nativeArgs
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
Remove-Item Env:WEATHER_LIFECYCLE_REVIEW,Env:WEATHER_FALLOUT_RELOAD,Env:WEATHER_PRECIP_REVIEW -ErrorAction SilentlyContinue
& ./tools/lane.ps1 run -Scene res://tests/OrisonV2SurfaceInventory.tscn -Runner long -TimeoutSeconds 1200 -Windowed -ShotDir C:/ov/reports/skywatch43/surface -LogPath C:/ov/reports/skywatch43/surface.log -ExtraArgs $nativeArgs
exit $LASTEXITCODE
