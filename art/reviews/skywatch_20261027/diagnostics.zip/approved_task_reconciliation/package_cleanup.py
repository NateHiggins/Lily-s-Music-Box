from pathlib import Path
import hashlib,json,zipfile

root=Path('C:/PleaseRemainOnTheLine'); source=Path(__file__).parent
destination=root/'art/reviews/skywatch_20261027';archive=destination/'diagnostics.zip';prefix='approved_task_reconciliation/'
provenance={
 'evidence_class':'INERT','source_before':'9cdaa97f89331ac6662c6736af1e5104327d2456',
 'decisions':'All20 owner choices, with Q10/Q11/Q15/Q20 adjustments; city construction prioritized next; terrain/relief addendum integrated as approximate art direction.',
 'queue_lines_before':3816,'queue_lines_after':1436,
 'cleanup':'16 byte-identical held character files (6221555 bytes) moved outside game; authoring destinations updated; unused SmokeDetectorProp and UID removed under explicit narrow waiver.',
 'save_compat':'14/14 PASS; wrapper binds final code','save_recovery':'195/195 PASS; real isolated disk transactions/current Continue; wrapper binds final code',
 'surface':'surface_staged:39169 checks,0fail,772s,empty stderr;39169 schema2 production/surface/runtime-owned teardown; save reconstruction NOT_EXECUTED; fire interaction skipped, physical hose surfaces inventoried; wrapper binds final code.',
 'scope_limits':'No new city geometry yet, no future character/culture acceptance, no campaign temporal-travel implementation, no whole-V2 or human artistic acceptance. Ordinary route FPS/tails remain unresolved.',
 'failures_retained':'9cdaa97f candidate blocked on stale surface hash; first cleanup surface exit1 before composition due indexed-but-unstaged deleted import. Manual FileNotFoundError diagnosis is in the tool transcript, not a newly fabricated traceback log.',
 'published_surface':json.loads((source/'published_surface.json').read_text()),
 'next':'Final candidate comparison; then city construction, not more unrelated expansion.'}
(source/'cleanup_provenance.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')
skip={'inventory.json','inventory.txt','TASKS.before.md','snapshot_probe.json','snapshot_after_stage.json'}
files=[p for p in source.iterdir() if p.is_file() and p.name not in skip]
files += [source/'surface_staged'/name for name in ['runtime_contract.json','visual_review.json','suite_run.receipt.json','suite_run.stdout.log.gz','suite_run.stderr.log.gz']]
files += [p for p in Path('C:/ov/reports/skywatch44/candidate').rglob('*') if p.is_file()]
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
 assert not any(n.startswith(prefix) for n in z.namelist())
 for p in files:
  relative=p.relative_to(source).as_posix() if p.is_relative_to(source) else 'original_blocked_candidate/'+p.relative_to('C:/ov/reports/skywatch44/candidate').as_posix()
  z.write(p,prefix+relative)
m=json.loads((destination/'manifest.json').read_text());m['approved_task_reconciliation']=provenance
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))
 m['members']={name:hashlib.sha256(z.read(name)).hexdigest() for name in z.namelist()}
m['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
(destination/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archived approved reconciliation and original failures; bytes',archive.stat().st_size)
