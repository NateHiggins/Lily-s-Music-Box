from pathlib import Path
import hashlib,json,re,subprocess

ROOT=Path('C:/PleaseRemainOnTheLine')
OUT=Path(__file__).parent
path=ROOT/'TASKS.md'
original=path.read_text(encoding='utf-8')
(OUT/'TASKS.before.md').write_text(original,encoding='utf-8')
text=original
changes=[]
source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()

def replace_section(title, replacement):
    global text
    pattern=re.compile(r'^'+re.escape(title)+r'\n.*?(?=^## |\Z)',re.M|re.S)
    match=pattern.search(text)
    assert match,title
    old=match.group()
    start=original.find(old)
    changes.append({'section':title,'source_line':original[:start].count('\n')+1 if start>=0 else None,'removed_lines':len(old.splitlines()),'source_lf_sha256':hashlib.sha256(old.encode()).hexdigest(),'replacement_lines':len(replacement.splitlines())})
    text=text[:match.start()]+replacement.strip()+'\n\n'+text[match.end():]

def remove_task(prefix):
    global text
    pattern=re.compile(r'^- \*\*'+re.escape(prefix)+r'(?=\s|\*|—)[^\n]*(?:\n(?!- \*\*|## ).*)*',re.M)
    match=pattern.search(text)
    assert match,prefix
    old=match.group();changes.append({'task':prefix,'source_lf_sha256':hashlib.sha256(old.encode()).hexdigest(),'removed_lines':len(old.splitlines())})
    text=text[:match.start()]+text[match.end():]

# The old staffing announcement is history, not a present ownership rule.
text=re.sub(r'\*2026-08-10:.*?queue\. Anyone may still add\.\*\n\n','',text,count=1,flags=re.S)
text=text.replace('Product authority: `design/CLAUDE_LIVING_ORISON_EXECUTION_PLAN.md`. These are\nthe immediate executable gates, not a second copy of its milestone status.',
'''Current scope follows Bible §VIII.5.o and the owner's October 27 decisions in
`design/V2_TASK_RELEVANCE_REVIEW_2026-10-27.md`. **The city is the next construction
priority.** Existing route/save gates remain qualification fixtures, not the final
narrative's mandatory mission sequence. Finish V2, then the murder-year game;
maintenance is secondary investigative content. Funding and marketing are retired.''')
remove_task('K0-EA')
remove_task('K0-GTM')
city=re.search(r'^- \*\*K-V2-CITY-REVAMP.*$',text,re.M).group()
text=text.replace(city+'\n','',1)
city=city.replace('After current open tasks, develop','NEXT CONSTRUCTION, owner direction October 27: develop')
text=text.replace('Funding and marketing are retired.','Funding and marketing are retired.\n\n'+city,1)
text=text.replace('K0-LANGUAGE — ATTENTION MULTIPLIER:', 'K0-LANGUAGE — INVESTIGATIVE CLARITY:')
text=text.replace('K0-PHONE — ATTENTION MULTIPLIER:', 'K0-PHONE — PHYSICAL COMMUNICATION:')

d7=re.search(r'^- \*\*D7.*?(?=\n## )',text,re.M|re.S).group().strip()
replace_section('## D — Needs a decision from the owner',f'''## D — Unresolved decisions and integration

**D1–D4** travel with the deferred studio brief below. **D5** was answered by the
relative-luminance default; **D6**'s cabinet decision is retired with that plan.
Neither changes period pub games or the separate mechanical fortune-teller.

{d7}''')

a11=re.search(r'^- \*\*A11.*?(?=\n## )',text,re.M|re.S).group().strip()
replace_section('## A — Arcade / the signal parlour',f'''## A — The mechanical fortune novelty

Playable video cabinets remain retired. **A2/A4–A10** and the old cabinet-specific
plan are cancelled by the owner; original sources/programmes are preserved.
The future redesign remains deferred, separate from **A11**, which stays in V2.

{a11}''')

g3=re.search(r'^- \*\*G3.*?(?=^- \*\*)',text,re.M|re.S).group().strip()
g4b=re.search(r'^- \*\*G4b.*?(?=^- \*\*)',text,re.M|re.S).group().strip()
replace_section('## G — The phonautograph',f'''## G — Local music and found traces

Preserve local songs, recording/reconstruction and listening. The phonautograph's
existing playback/trace rules remain in Bible §III.2 and the Songbook references;
archiving a completed local-contract note does not change those rules.
Network distribution, phrase duels and the House Rig audition are deferred below.

{g3}

{g4b}''')

replace_section('## S — Basement studio','''## S — Basement studio (deferred after V2)

**D1–D4 / S1–S5 / related G2/G4b**: preserve installed space and listening systems;
defer expansion, storage cages, staffing and echo-return choices. Later survey the
actual V2 room before authoring a restoration desk, chamber or dead-channel chore.
Receiving local/shared versions must not acquire a new basement-visit gate.
Source: `design/ORISON_STUDIO_BRIEF.md`; original requirements remain in Git.''')

replace_section('## F — Film (projectors instead of televisions)','''## F — The street film tent

- **F-RELOCATION — Complete the requested period one-person film tent beside the
  bar, retire the three mounted apartment projectors and their abandoned leads,
  and verify entrance, sidewalk and subway access.** Preserve current film
  decoding, source programmes, power, case/haunting and save authorities while
  relocating presentation. A candidate tent is not an installed, qualified venue.
  See `design/V2_STARTED_WORK_CLOSURE_2026-10-23.md` and the current runtime's
  `orison_v2_projectors.gd`. Do not restore old machine counts or apartment rules.
- **F3 — Retain unresolved motion-based content curation.** Inspect complete
  clips, not a single frame; remove incompatible trailers/titles from a shortlist.
- **F5/F11/F12/F5b — Reconcile unfinished film/plate presentation with the tent.**
  Keep any still-missing long-exposure accumulation, optical wear, gate weave,
  keystone, projector beam and state-driven burn as explicit gaps after checking
  the current renderer. Reuse existing accumulators rather than duplicate one.
- **F6/F7/F8 — Preserve film audio semantics and the unresolved reel-selection
  work.** Local chosen programmes/found objects remain distinct from the Tenant
  running a machine. No invented collectible, reward or haunting reach follows
  from this queue cleanup. The magic-lantern alternative in **F13** is historical
  proposal material, not a reason to replace the owner's nickelodeon direction.

Historical completed parts and superseded **F2/F4/F4b/F4c/F14/F15/F16/F9/F10**
placement/count assumptions are archived by source commit in the review record.''')

replace_section('## Q — The hand','''## Q — Direct manipulation

Historical **Q1–Q6** completion notes are archived. The current contract remains
primary-click grab, constrained mouse motion, next-click release and supported
inspection. Actual input, pickup/held-book behavior, focus and interruption
requirements remain under **I**, **K** and AGENTS.md; old toggles prove none of them.''')

replace_section('## N — The dream (narcolepsy maze)','''## N — Installed dream content

Historical completed **N3/N6–N13** notes are archived, not deleted from the game.
The future murder-year campaign uses maintenance and dream material as optional
investigations; it has no mandatory repeating repair/narcolepsy sequence. Current
V2 route/save qualification and protected conversations remain unchanged. New
defects in installed content still enter **K4/I/H** from actual evidence.
See Bible §VIII.5.o and `design/THE_YEAR_YOU_DIED_POST_V2_2026-10-26.md`.''')

replace_section('## FA — Dream fauna (FA2 COMPLETE)','''## FA — Installed fauna, with new breadth deferred

- **FA-V2-GAPS — Retain repairs and acceptance gaps for installed creatures.**
  Preserve the native tentacle encounter, Tardi, microscopy, local autonomy and
  accepted contact/dissolution behavior. Use current family records and their
  stated limits; historical fauna contracts do not qualify all of V2.
  `design/CREATURE_MAIN_INTEGRATION_2026-10-26.md` is the integration baseline.

**FA3–FA4 / FA-V5 / CT-2**, related unbuilt **E13/E15–E17/DF/DT** breadth and new
families are deferred. As gameplay uses appear, vet them and add bounded work;
do not treat this as cancellation of installed ecology or approved future people.''')

m123=re.search(r'^## M — Materials and textures\n(.*?)(?=^### M-AUDIT)',text,re.M|re.S).group(1).strip()
replace_section('## M — Materials and textures',f'''## M — Current surface, device and creature gaps

{m123}

- **M-V2-TENTACLE-GAPS — Reconcile TB1–TB16 and DT3/DT4 against the installed
  native family and newer owner briefs.** Keep only remaining anatomy, ocular/
  crystal details, attachment, deformation, surface, collision and rendering
  acceptance gaps; do not restart completed cage/rig/bake construction. Compare
  earlier requirements rather than silently mark them all done. Source:
  `design/DREAM_TENTACLE_BLENDER_BUILD.md`, `design/HERO_TENTACLE_REMAINING.md`,
  `design/TENTACLE_GANG_SURFACE_COMPLETION_2026-10-26.md` and the PR63 baseline.
- **M-V2-ORGAN-GAPS — One installed field/organ/lifecycle gap list for DF/DO/LC.**
  Preserve signal-specific answers, local autonomy, field/optical occlusion,
  withdrawal/residue, stage handoff and save/case truth boundaries. Reconcile
  **DO3/LC6** residuals with completed substeps; defer unbuilt breadth unless a
  vetted gameplay use needs it. Historical scripts, packets and receipts remain.
- **M-V2-MICROSCOPY-GAPS — Track only current installed-family acceptance and
  repair limits.** The completed **MBIO1–MBIO6** construction journal is archived;
  use `design/V2_TARDIGRADE_MICROSCOPY_2026-10-25.md`, current Tardi records and
  `design/CREATURE_MAIN_INTEGRATION_2026-10-26.md`. Do not repeat accepted anatomy
  and field construction just because its historical checklist is long.
- **TL-GAPS — Finish the current autonomous companion, physical paper/keyboard,
  controls, sound, lamp and readable presentation against their actual owners.**
  Reconcile legacy **TL2–TL5** mechanism/material/wear/tactility goals rather than
  rebuild the retired handheld shell or restore ink/heat instructions. Preserve
  protected typing drafts, pause, power, memory and validated campaign state.
  Source: `design/V2_COMPANION_PHOSPHOR_2026-10-25.md` and companion integration
  records. **TL6–TL9** (RETURN, reality inspection, impossible correspondence and
  creature recognition) remain unresolved narrative capabilities for explicit
  story-fit reconciliation, not silently completed or cancelled features.
- **MX3/MX4 — Retain actual material-ingest and rollout gaps.** Verify calibrated
  height/relief, tile scale, ORM/detail/mask authoring and still-unaccepted classes
  against the installed pipeline. Recheck old missing-map/42-height assertions;
  do not blindly repeat old triplanar rollout, disable PBR or restore obsolete
  Compatibility budgets. Archived MX specifications and the material catalogue
  remain the reference, not another current-state claim.
- **MP/DP — Keep surface quality and loaded-mipmap verification active.** Preserve
  close-up detail, material scale/grain, UVs, normal calibration, optical glass,
  side-correct moisture and loaded texture requirements. Use
  `design/V2_SURFACE_REQUIREMENTS_2026-10-11.md` and actual same-settings renders.
  Old floor-repetition, glass-map and translucent-plane journals are references;
  archive disproved premises and promote only still-reproduced defects.
- **T4-4 — Preserve the temporal-evidence gate for future organ/anachronism work.**
  Record observation → misreading → embodiment, runtime owner and case/save/time
  boundaries. Future forensic time travel does not silently transfer authority
  to a visual effect or license arbitrary future props.

Completed **MC-P/LF/DT/DO/LC/MBIO/T4/CT/MX** clauses are archived with their
source/evidence pointers. Both contradictory **CT-1** queue entries are retired
as a historical atlas-status duplicate, not renewed V2 artistic acceptance.
Standing material specifications remain in the Bible, catalogue and surface
requirements; this queue is for outstanding work.''')

replace_section('## EN — The Encroachment (owner ruling 2026-08-21; `design/DREAM_ENCROACHMENT_BRIEF.md`)','''## EN — Encroachment presentation

- **EN1 — Owner appearance review remains open.** Historical frame delivery is
  not human acceptance. Compare the actual installed layer/portal/fold behavior
  and any still-live artistic concerns before preparing another bounded review.
  Source: `design/DREAM_ENCROACHMENT_BRIEF.md` and the original EN records.

Completed **EN1b/EN3/WK1** and completed portions of **EN2** are archived. Retain
any still-reproduced portal-camera, fold placement or ornament/performance issue
under the current installed-family gap audit; old timing numbers are not targets.''')

remove_task('L12')
replace_section('## P — Performance','''## P — Current measured V2 performance

- **P1 — Follow K-V2-FIRST-VIEW-HITCH with current occupied-world evidence.**
  Separate scripts, physics, loading/streaming, shader compilation, render
  submission, shadows and private-viewport costs; retain cold/warm distributions
  and actual input. New city work must measure its incremental cost on the same
  route/settings and preserve visual detail through measured tradeoffs.
- **P2/P3/P6/P8 — Historical leads, not automatic prescriptions.** Reproduce
  relevant occlusion, shadow, mirror/reflection and tier/culling issues in the
  current V2 composition before optimizing. Keep any reproduced defects active;
  archive old V1 station numbers, rejected fixes and superseded budget levers.

The next release is desktop-only. **L12** and mobile parts of **P1/P4** are not
near-term delivery gates; existing export/source configurations remain until
deliberate cleanup. Explicit V1 rollback/protected paths remain intact.
Measured repair history: `design/V2_BACKGROUND_HOUSEHOLD_SAVES_2026-10-23.md`.
Performance/counter procedure: `.agents/skills/godot-development/SKILL.md`.''')

# Keep actual service residuals, but remove historical completed SR2–SR5 journals.
for prefix in ['SR2','SR3','SR4','SR5','H20','H21','H24']:
    remove_task(prefix)
sr6=re.search(r'^- \*\*SR6.*?(?=\n## )',text,re.M|re.S).group()
text=text.replace(sr6,'**SR6/SR7 — Deferred after V2:** retain the rolling attention ledger and\nvertical-anatomy expansion briefs, but finish current route, maintenance,\naccessibility and reload repairs first. Existing authorities stay installed.\n',1)

u2=re.search(r'^- \*\*U2.*?(?=^- \*\*U6)',text,re.M|re.S).group()
text=text.replace(u2,'''- **U2 — Held future character originals, not discarded monsters.** The owner
  intends harpy and succubus/oni characters with in-world cultures. Audit found no
  runtime loader for their old roster/assets; 16 byte-identical files are held in
  `art/source/held_characters/` outside game packaging. The converter targets that
  location. Integration remains future vetted character work; no new resident,
  culture, schedule or gameplay authority has been invented. See the review.
''',1)
u6=re.search(r'^- \*\*U6.*?(?=\n## )',text,re.M|re.S).group()
text=text.replace(u6,'''- **U6 — Owner-approved removal of the obsolete SmokeDetectorProp save alias.**
  Consumer audit found no live class/path/UID reference. The two-file shim is
  removed; current VantryPointProp, networks and the domestic fixture kind remain.
  Current save compatibility/recovery checks pass. This is a narrow historical
  alias waiver, not permission to weaken current save validation or remove lamps.
''',1)

text += '''
## Deferred after V2 — preserved scope, not current blockers

- **G1 shared side / G2 / G6a / community S5:** network song distribution after
  V2; keep local songs, found traces and immutable playback. Consent, moderation,
  report/block, takedown, retention and platform controls remain prerequisites if
  public/friends sharing is resumed. `design/ORISON_SONGBOOK_BRIDGE_PLAN.md`.
- **G6 / related G8:** phrase-duel and lyric-book expansion after V2; retain the
  existing private music work. `design/ORISON_SONGBOOK_PHRASE_DUEL_BRIEF.md`.
- **G7:** defer the House Rig audition/decision; current sound and Music Bible
  authority remain. No added bass/distortion chain is silently approved.
- **A12:** future arcade redesign remains a commitment; the old cabinet-specific
  plan is cancelled. Do not restore cabinets ahead of that redesign.
- **E13 / E15–E17 / FA3–FA4 / FA-V5 / CT-2 / unbuilt DF/DT/LC breadth:** preserve
  current creatures; vet additional families as real gameplay uses appear. Keep
  explicit prerequisites and no new unchecked story/save/time authority.
- **SR6/SR7:** rolling attention and additional vertical anatomy are deferred;
  current route, maintenance and save repairs remain active above.

## Queue provenance and standing rules

October 27 owner decisions and exact pre-trim source references are in
`design/V2_TASK_RELEVANCE_REVIEW_2026-10-27.md`. Completed/superseded text is
recoverable from Git; original failures, receipts and assets are not erased.
The Bible, AGENTS.md, skills and existing references own standing rules. In
particular the deliberate pointer-release contract remains binding in
`design/REPO_HOUSEKEEPING_2026-09-19.md` §10; H24 was a rule, not unfinished work.
Funding, marketing and the fundable-release task are retired. Save reliability,
accessibility, responsive controls, visual quality and honest qualification remain.
'''
text=re.sub(r'\n{4,}','\n\n\n',text)
path.write_text(text,encoding='utf-8',newline='\n')
report={'evidence_class':'INERT','source_commit':source_commit,'source_lf_sha256':hashlib.sha256(original.encode()).hexdigest(),'original_lines':len(original.splitlines()),'result_lines':len(text.splitlines()),'changes':changes,'result_lf_sha256':hashlib.sha256(text.encode()).hexdigest()}
(OUT/'queue_disposition.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='changes'},indent=2))
