# Candidate verification - 9cdaa97f8933

- candidate `9cdaa97f89331ac6662c6736af1e5104327d2456`
- base `c5f8400a27d582738c620f23c0a887f4ae9724e8`
- merge-base `c5f8400a27d582738c620f23c0a887f4ae9724e8`
- verified 2026-10-28T00:20:17Z from verifier `9cdaa97f8933`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 4 regressions, 0 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 0 |

## Blocking reasons (4)

- regression: v2_surface_qualification: PASS -> FAIL (exit 0 -> 1)
- regression: v2_surface_qualification: defects 0 -> 2
- regression: v2_surface_qualification: new defect missing or stale rendered review
- regression: v2_surface_qualification: new defect stale surface qualification: rendering inputs changed

## Needs human review (not blocking) (2)

- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (4)

- v2_surface_qualification: PASS -> FAIL (exit 0 -> 1)
- v2_surface_qualification: defects 0 -> 2
- v2_surface_qualification: new defect missing or stale rendered review
- v2_surface_qualification: new defect stale surface qualification: rendering inputs changed

## Accepted regressions (0)

- none

## Improvements (0)

- none

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (0)

- none

BLOCKED regression: v2_surface_qualification: PASS -> FAIL (exit 0 -> 1); regression: v2_surface_qualification: defects 0 -> 2; regression: v2_surface_qualification: new defect missing or stale rendered review (+1 more)
