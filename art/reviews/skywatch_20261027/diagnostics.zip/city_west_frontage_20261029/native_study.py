from pathlib import Path
import bpy,json,os
from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree
R=Path('C:/ov/city'); O=Path('C:/ov/reports/city_west_20261029/native');O.mkdir(exist_ok=True)
placements={'site_nbr_w':[-35,35],'site_nw1':[0,8],'site_nw2':[0,8],'site_nw3':[0,8],'site_nw4':[0,8],'site_back_w':[0,6],'site_far_w':[-28,55]}
bpy.ops.wm.read_factory_settings(use_empty=True)
objects=[]
for family in ['elevations','masts','aerials','tanks','beacons']:
    f=json.loads((R/f'game/tests/fixtures/orison_city_{family}.json').read_text())
    names=[p['name'] for p in f['parts']]
    with bpy.data.libraries.load(str(R/f'art/blender/city_{family}.blend'),link=False) as (a,b):
        assert set(names)<=set(a.objects),family
        b.objects=names
    for obj in b.objects:
        bpy.context.scene.collection.objects.link(obj);obj.hide_render=False;obj.hide_set(False);objects.append(obj)
bpy.context.view_layer.update()
rest={o.name:o.matrix_world.copy() for o in objects}
def owner(name):return next((k for k in placements if name.startswith(k+'__')),None)
def apply(active):
    for o in objects:
        o.matrix_world=rest[o.name]
        k=owner(o.name)
        if active and k:o.location+=Vector((*placements[k],0))
    bpy.context.view_layer.update()
def rays():
    vs=[];fs=[];owners=[]
    for o in objects:
        off=len(vs);vs.extend(o.matrix_world@v.co for v in o.data.vertices);fs.extend(tuple(off+i for i in p.vertices) for p in o.data.polygons);owners.extend([o.name]*len(o.data.polygons))
    bvh=BVHTree.FromPolygons(vs,fs)
    out=[]
    for y in [-11,-12,-13,-14]:
        eye=Vector((0,y,1.41));target=Vector((-130,y,4))
        hit,n,idx,dist=bvh.ray_cast(eye,(target-eye).normalized(),(target-eye).length)
        out.append({'eye':list(eye),'target':list(target),'first_hit':owners[idx] if hit else None,'distance':dist})
    return out
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=8;scene.render.resolution_x=1280;scene.render.resolution_y=720;scene.render.resolution_percentage=100
scene.world=bpy.data.worlds.new('Review');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.55,.65,.8,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.7
sun=bpy.data.objects.new('Sun',bpy.data.lights.new('Sun','SUN'));scene.collection.objects.link(sun);sun.data.energy=3;sun.rotation_euler=(.45,-.35,-.7)
cam=bpy.data.objects.new('Camera',bpy.data.cameras.new('Camera'));scene.collection.objects.link(cam);scene.camera=cam;cam.data.lens=24
result={'evidence_class':'INERT','scope':'native relocation study; no runtime, skyline or acceptance claim','placements':placements,'rays':{}}
for active in [False,True]:
    apply(active);state='after' if active else 'before';result['rays'][state]=rays()
    for label,eye,target in [('front',(0,-11,1.41),(-100,-11,5)),('roof',(0,-11,21),(-80,15,12)),('pocket',(-42,-8,9),(-50,30,8))]:
        cam.location=eye;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(O/f'{state}_{label}.png');bpy.ops.render.render(write_still=True)
(O/'study.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

