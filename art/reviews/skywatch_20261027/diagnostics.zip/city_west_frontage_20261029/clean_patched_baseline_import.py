import subprocess,json,zipfile
from pathlib import Path
R=Path('C:/ov/city'); O=Path('C:/ov/reports/city_west_20261029'); changed=[]; fresh=[]
def git(*args):return subprocess.check_output(['git','-C',str(R),*args],stderr=subprocess.DEVNULL)
for raw in git('ls-files','-m','-z').split(b'\0'):
 if not raw:continue
 p=raw.decode(); now=(R/p).read_bytes(); old=git('show','HEAD:'+p)
 if p.endswith('.import') and now.replace(b'\r\n',b'\n')==old.replace(b'\r\n',b'\n'):changed.append(p)
for raw in git('ls-files','--others','--exclude-standard','-z').split(b'\0'):
 if raw and raw.decode().endswith('.uid'):fresh.append(raw.decode())
with zipfile.ZipFile(O/'patched_baseline_import_churn.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in changed+fresh:z.write(R/p,p)
for i in range(0,len(changed),100):subprocess.run(['git','-C',str(R),'restore','--worktree','--',*changed[i:i+100]],check=True)
for p in fresh:
 target=(R/p).resolve();assert target.is_relative_to(R.resolve());target.unlink()
(O/'patched_baseline_import_churn.json').write_text(json.dumps({'restored_eol_only_imports':changed,'removed_own_generated_uids':fresh},indent=2)+'\n')
print(len(changed),'EOL-only imports restored;',len(fresh),'own new UIDs archived and removed')


