import json, math
from pathlib import Path
P=Path(__file__).parent
def distribution(values):
    a=sorted(values)
    def q(p):
        at=(len(a)-1)*p; lo=math.floor(at);hi=math.ceil(at)
        return round(a[lo]+(a[hi]-a[lo])*(at-lo),3)
    return dict(n=len(a),p50=q(.5),p95=q(.95),p99=q(.99),maximum=round(a[-1],3))
def route(path):
    d=json.loads(path.read_text()); rows=d['samples']
    keys=['wall_ms','render_cpu_ms','render_gpu_ms']
    indices={k:d['columns'].index(k) for k in keys}
    def stats(part):
        result={k:distribution([r[i] for r in part]) for k,i in indices.items()}
        result['wall_spikes']={str(limit)+'ms':sum(r[indices['wall_ms']]>limit for r in part) for limit in [50,100]}
        result['engine_global_counters']={k:distribution([r[7][k] for r in part]) for k in part[0][7] if k.startswith('RENDER_')}
        return result
    return dict(resolution=d['resolution'],msaa=d['msaa'],taa=d['taa'],calendar=d['calendar'],conditions=d['conditions'],source_before=d['source_before'],source_after=d['source_after'],failures=d['failures'],all=stats(rows),blocks=[dict(block=b,stats=stats(rows[b['frame_start']:b['frame_end']])) for b in d['blocks']],largest_frames=[dict(phase=r[0],wall_ms=r[1],gpu_ms=r[5],counters=r[7]) for r in sorted(rows,key=lambda r:r[1],reverse=True)[:12]])
if __name__=='__main__':
    result={'_analysis':{'evidence_class':'INERT','quantiles':'Linear interpolation at (n-1)*p; rounded to 0.001.','scope':'Matched settings do not establish a causal city speedup. Main GPU excludes private viewports; rendering counters are engine-global. Live NPC/traffic and driver-cache variance remain. Startup and screenshot readback are excluded from route frames and reported separately.'}}
    for name in ['patched_before_route','patched_after_route']:
        f=P/name/'cloud_world_frames.json'
        if f.exists():result[name]=route(f)
    for name in ['west_frontage_05','west_frontage_06']:
        f=P/name/'west_frontage_contract.json'
        if not f.exists():continue
        d=json.loads(f.read_text()); o=d['observations']; control=o.get('placement_cost_control',{})
        result[name]=dict(failures=d['failures'],startup=distribution(o['startup_settle_wall_ms']),blocks=[dict(placed=b['placed'],stats={k:distribution([s[i] for s in b['samples']]) for i,k in enumerate(control['columns'])}) for b in control.get('blocks',[])])
    (P/'measured_city_comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    for name,row in result.items():
        if name.startswith('_'):continue
        print(name, row.get('all',row.get('startup')))
        for block in row['blocks']:print(' block',block.get('placed',block.get('block',{}).get('id')),block['stats'])
