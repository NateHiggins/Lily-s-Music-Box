"""Archive and clear only this isolated worktree's generated import churn."""
from pathlib import Path
import subprocess, json, zipfile, io
R=Path('C:/ov/city').resolve();O=Path(__file__).parent
def git(*args):return subprocess.check_output(['git','-C',str(R),*args],stderr=subprocess.DEVNULL)
restored=[];uids=[];meaningful=[]
paths=[p.decode() for p in git('ls-files','-m','-z').split(b'\0') if p and p.decode().endswith('.import')]
batch=subprocess.run(['git','-C',str(R),'cat-file','--batch'],input=''.join(':'+p+'\n' for p in paths).encode(),capture_output=True,check=True)
stream=io.BytesIO(batch.stdout)
for p in paths:
    header=stream.readline().split();assert len(header)==3 and header[1]==b'blob',(p,header)
    indexed=stream.read(int(header[2]));assert stream.read(1)==b'\n'
    actual=(R/p).read_bytes()
    if actual.replace(b'\r\n',b'\n')==indexed.replace(b'\r\n',b'\n'):restored.append(p)
    else:meaningful.append(p)
for raw in git('ls-files','--others','--exclude-standard','-z').split(b'\0'):
    if raw and raw.decode().endswith('.uid'):uids.append(raw.decode())
archive=O/'final_owned_import_churn.zip'
assert not archive.exists(), 'Never overwrite an earlier diagnostic archive'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in restored+uids:z.write(R/p,p)
for i in range(0,len(restored),100):
    subprocess.run(['git','-C',str(R),'restore','--worktree','--',*restored[i:i+100]],check=True)
for p in uids:
    target=(R/p).resolve();assert target.is_relative_to(R);target.unlink()
(O/'final_owned_import_churn.json').write_text(json.dumps(dict(restored_eol_only_to_index=restored,removed_own_generated_uids=uids,meaningful_import_changes_preserved=meaningful),indent=2)+'\n')
print(len(restored),'EOL-only imports restored;',len(uids),'own generated UIDs archived and removed; meaningful import changes:',meaningful)
