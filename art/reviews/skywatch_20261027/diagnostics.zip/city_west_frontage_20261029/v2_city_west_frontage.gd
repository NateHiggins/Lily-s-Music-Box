extends "res://tests/orison_v2_street_crossing_test.gd"
## Played frontage/crossing plus unfiltered visibility and ground diagnostics.
## Does not grant new routes into the passive city or artistic acceptance.
var city_checks := 0
var city_observations: Dictionary = {}
var source_before := ""

func _ready() -> void:
	OS.set_environment("DAYNIGHT_FORCE", "12:00")
	GameBoot.settings.weather_network_enabled = false
	route_label = "V2 WEST FRONTAGE"
	capture_street_line = false
	call_deferred("_run")

func check(ok: bool, label: String) -> void:
	city_checks += 1
	if not ok:
		failures.append(label)
		push_error("WEST FRONTAGE: " + label)

func _digest() -> String:
	var result: Array = []
	var root := ProjectSettings.globalize_path("res://..").simplify_path()
	if OS.execute("python", [root.path_join("tools/run_receipt.py"), "digest", "--root", root], result) != 0: return ""
	return str(result[0]).strip_edges() if not result.is_empty() else ""

func _run() -> void:
	source_before = _digest()
	RealityState.persistence_enabled = false
	RealityState.reset_campaign_for_tests()
	CampaignTime.set_frozen_for_tests(true)
	CampaignClock.new().configure_date(1928, 11, 10, 720)
	world = Runtime.instantiate()
	add_child(world)
	await get_tree().physics_frame
	await get_tree().physics_frame
	check(not world.startup_failed and world.player != null, "production composition starts")
	if not world.startup_failed and world.player != null:
		player = world.player
		_prepare_player_start()
		player.camera.make_current()
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		await get_tree().process_frame
		check(world.passage_region.cell_nodes.size() == 13, "thirteen arcade cells retain their owner")
		check(world.bar_region.actors.get_child_count() > 0, "bar actors retain their owner")
		await _route()
	Input.action_release("move_forward")
	world.shutdown_for_tests()
	world.free()
	await get_tree().physics_frame
	var source_after := _digest()
	check(not source_after.is_empty() and source_before == source_after, "frozen source across the executed route")
	var directory := OS.get_environment("SHOT_DIR")
	check(not directory.is_empty() and DirAccess.make_dir_recursive_absolute(directory) == OK, "writable evidence directory")
	if not directory.is_empty():
		var receipt := {"schema_version":2,"evidence_kind":"runtime_contract","selector":"v2","production_runtime":true,
			"scope":"Actual controller frontage walk and retained street crossing/door manipulation; unfiltered west-view, vacated-grade and restored blocker controls. No passive-lot access, save reconstruction, full city, weather or artistic acceptance.",
			"execution":{"completed":true,"exit_code":0 if failures.is_empty() else 1,"timed_out":false},
			"source":{"test_path":"game/tests/v2_city_west_frontage.gd","test_sha256":FileAccess.get_sha256(get_script().resource_path),"runtime_inputs_sha256":source_after},
			"contracts":{"production_composition":{"executed":true,"passed":failures.is_empty()},"frontage_and_crossing":{"executed":true,"passed":failures.is_empty(),"waypoints":trace.size()},"runtime_owned_teardown":{"executed":true,"passed":not is_instance_valid(world)}},
			"checks":city_checks,"failures":failures,"trace":trace,"observations":city_observations}
		FileAccess.open(directory.path_join("west_frontage_contract.json"),FileAccess.WRITE).store_string(JSON.stringify(receipt,"\t")+"\n")
	print("V2 WEST FRONTAGE: %d checks; %d waypoints; %d failures" % [city_checks,trace.size(),failures.size()])
	get_tree().quit(0 if failures.is_empty() else 1)

func _west_ray() -> Dictionary:
	return world.get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(Vector3(0,1.41,3),Vector3(-130,4,3),1,[player.get_rid()]))

func _route() -> void:
	# Retain the original crossing, arcade stance and real door hands first.
	await super._route()
	if not failures.is_empty(): return
	if not await _leave_front_entrance(): return
	for point: Vector3 in [Vector3(0,0,3),Vector3(-8,0,3),Vector3(-16,0,3),Vector3(-24,0,3),Vector3(-16,0,3),Vector3(0,0,3)]:
		if not await _walk(world.adapter.root.to_local(point)): return
	check(_west_ray().is_empty(), "unfiltered 130-metre westward sightline from the front walk")
	var city := world.get_node("CityShells") as Node3D
	# Restore one former blocker, including real physical backing. This must
	# close the same view; then restore the exact poses before continuing.
	var controls: Array[Dictionary] = []
	for draw: MeshInstance3D in city.find_children("*","MeshInstance3D",true,false):
		if not draw.get_meta("retained_city_shell",false) or not str(draw.name).begins_with("site_nw1__"): continue
		var body := draw.get_parent().get_node(str(draw.name)+"Collision") as StaticBody3D
		var shape := body.get_child(0) as CollisionShape3D
		controls.append({"draw":draw,"pose":draw.transform,"shape":shape,"physical_pose":shape.transform})
		draw.position -= draw.get_meta("city_assembly_translation",Vector3.ZERO)
		shape.transform = draw.transform
	await get_tree().physics_frame
	await get_tree().physics_frame
	var blocked := _west_ray()
	check(not controls.is_empty() and not blocked.is_empty() and city.is_ancestor_of(blocked.collider), "original west-row blocker closes the same unfiltered sightline")
	city_observations["negative_control_owner"] = str(blocked.collider.get_path()) if not blocked.is_empty() else ""
	var control_directory := OS.get_environment("SHOT_DIR")
	if not control_directory.is_empty():
		DirAccess.make_dir_recursive_absolute(control_directory)
		player.face_world_point(Vector3(-130,4,3))
		await get_tree().create_timer(.5).timeout
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(control_directory.path_join("west_restored_blocker_control.png"))
	for control: Dictionary in controls:
		control.draw.transform = control.pose
		control.shape.transform = control.physical_pose
	await get_tree().physics_frame
	await get_tree().physics_frame
	check(_west_ray().is_empty(), "exact restoration reopens the view")
	var ground: Node3D = world.adapter.root.get_node("Ground")
	var grade_samples: Array = []
	for source: Vector2 in [Vector2(-20.6,-10),Vector2(-26.5,-10),Vector2(-35.2,-10),Vector2(-45.25,-10),Vector2(-56.25,-10),Vector2(-21,20),Vector2(-93,-1)]:
		var point := city.to_global(Vector3(source.x,0,-source.y))
		var hit := world.get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(point+Vector3.UP*.3,point-Vector3.UP*.3,1,[player.get_rid()]))
		var valid := not hit.is_empty() and ground.is_ancestor_of(hit.collider) and absf(hit.position.y+.02)<.0001
		check(valid, "vacated site has rebuilt grade, not a stale excavation: "+str(source))
		grade_samples.append({"source":str(source),"height":hit.position.y if not hit.is_empty() else null,"owner":str(hit.collider.get_path()) if not hit.is_empty() else ""})
	city_observations["vacated_grade"] = grade_samples
	await _paired_view_cost(city)
	var directory := OS.get_environment("SHOT_DIR")
	if not directory.is_empty():
		DirAccess.make_dir_recursive_absolute(directory)
		player.face_world_point(Vector3(-130,4,3))
		await get_tree().create_timer(.5).timeout
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(directory.path_join("west_from_front_walk.png"))
		city_observations["resolution"] = str(get_viewport().get_visible_rect().size)
		city_observations["msaa"] = get_viewport().msaa_3d
		city_observations["taa"] = get_viewport().use_taa
	if not await _enter_front_entrance(): return



func _paired_view_cost(city: Node3D) -> void:
	# ABBA source-placement control in one warmed world/current grade. This is
	# not the historical whole-world baseline; keep that separate route result.
	var moved: Array[Dictionary] = []
	for draw: MeshInstance3D in city.find_children("*","MeshInstance3D",true,false):
		var offset: Vector3 = draw.get_meta("city_assembly_translation",Vector3.ZERO)
		if offset.is_zero_approx(): continue
		var row: Dictionary = {"draw":draw,"pose":draw.transform,"offset":offset}
		if draw.get_meta("retained_city_shell",false):
			var body := draw.get_parent().get_node(str(draw.name)+"Collision") as StaticBody3D
			row["shape"] = body.get_child(0) as CollisionShape3D
			row["physical_pose"] = row.shape.transform
		moved.append(row)
	check(moved.size()>50, "placement control includes bodies and roof equipment")
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	Engine.max_fps = 0
	var viewport := get_viewport().get_viewport_rid()
	RenderingServer.viewport_set_measure_render_time(viewport,true)
	player.face_world_point(Vector3(-130,4,3))
	var blocks: Array = []
	for placed: bool in [false,true,true,false]:
		for row: Dictionary in moved:
			row.draw.transform = row.pose
			if not placed: row.draw.position -= row.offset
			if row.has("shape"): row.shape.transform = row.draw.transform
		for frame in 30: await get_tree().process_frame
		var samples: Array = []
		var previous := Time.get_ticks_usec()
		for frame in 240:
			await get_tree().process_frame
			var now := Time.get_ticks_usec()
			samples.append([(now-previous)/1000.,RenderingServer.viewport_get_measured_render_time_cpu(viewport),RenderingServer.viewport_get_measured_render_time_gpu(viewport),Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME),Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME),Performance.get_monitor(Performance.RENDER_TOTAL_OBJECTS_IN_FRAME)])
			previous = now
		blocks.append({"placed":placed,"samples":samples})
	for row: Dictionary in moved:
		row.draw.transform = row.pose
		if row.has("shape"): row.shape.transform = row.physical_pose
	await get_tree().physics_frame
	await get_tree().physics_frame
	RenderingServer.viewport_set_measure_render_time(viewport,false)
	check(_west_ray().is_empty(), "paired placement cost control restores the actual open view")
	city_observations["placement_cost_control"] = {"scope":"Same-process warmed ABBA west-facing placement control on current grade; live NPC/traffic and driver caches uncontrolled. Screenshot readback excluded. Main-viewport GPU excludes private viewports; engine rendering counters retain their global scope. No whole-world improvement or causal CPU attribution.","moved_draws":moved.size(),"columns":["wall_ms","main_render_cpu_ms","main_render_gpu_ms","engine_draws","engine_primitives","engine_objects"],"blocks":blocks}
