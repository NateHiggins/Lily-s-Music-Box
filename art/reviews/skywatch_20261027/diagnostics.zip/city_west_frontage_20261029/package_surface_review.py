from pathlib import Path
import json,gzip,hashlib,shutil
P=Path(__file__).parent;packet=P/'surface_final_02'
contract=json.loads((packet/'runtime_contract.json').read_text())
observations={
'city_street_skyline.png':'Actual retained brick frontage, window surrounds, blinds, gas lamp and roof tank/supports remain together with the opened west strip. Generic distant stock and dark exposure remain city presentation debt.',
'city_weather_storm.png':'Existing tank/aerial silhouettes remain through the warm grey storm haze. The low-contrast ceiling remains weather presentation debt; no annual-sky or weather artistic acceptance.',
'front_gallery_05.png':'Retained timber panels, plaster, speckled floor, curtains and blind slats remain distinct. Strong ceiling highlights remain an existing lighting limitation; interiors are unchanged.',
'street_paving.png':'Actual curb profiles, paving joints, dark asphalt, masonry and retained lit shop access remain present. The street remains dark; no new road layout, drainage or wet/dry artistic acceptance.',
'front_restored_entrance.png':'The installed Orison door, brass pulls, glazed marquee, blade and masonry remain in place. Actual door manipulation/crossing is separately covered by the frontage contract.',
'public_arcade_hall.png':'Retained diner, laundry, storefronts, handcart, masonry, timber, paving and canopy remain together. No relocation or new acceptance of shop authorities.',
'tile_F02_A_BATH_corner.png':'Representative unchanged tile cap, plaster, floor hexagons, curtain/rings and exposed plumbing remain distinct. This review does not renew plumbing/shower interaction or apartment acceptance.',
'city_west_barricade_diffuse.png':'The low native works body shows individual timber boards, joints, cap, fasteners and seated posts in actual production lighting. Its original orange marker is retained at the lower cap. Dark exposure/marker appearance remain artistic limitations.',
'city_west_barricade_grazing.png':'At grazing angle the authored timber grain, cap direction, board joints and fasteners remain legible beside actual traffic/curb stock. Imported metre UV/tangent and loaded-map mip checks pass separately; no human artistic acceptance.'}
review=dict(evidence_class='INERT',status='PASS',surface_inputs_sha256=contract['surface_inputs_sha256'],scope='Fresh representative technical review of the actual native3440x1440 patched-Vulkan world. No whole-city, human artistic, weather, narrative or save-reconstruction acceptance.',images=[])
for name,observation in observations.items():
    raw=(packet/name).read_bytes()
    review['images'].append(dict(file=name,sha256=hashlib.sha256(raw).hexdigest(),observation=observation,origin='Agent inspected this actual fullscreen capture from surface_final_02; no generated or substituted image.'))
(packet/'visual_review.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(P/'surface_final_02.log.receipt.json',packet/'suite_run.receipt.json')
for channel,suffix in [('stdout','.log'),('stderr','.log.stderr')]:
    raw=(P/('surface_final_02'+suffix)).read_bytes()
    (packet/('suite_run.'+channel+'.log.gz')).write_bytes(gzip.compress(raw,mtime=0))
print('Packaged',len(review['images']),'actually reviewed images; source',contract['surface_inputs_sha256'])
