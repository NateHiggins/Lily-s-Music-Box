from pathlib import Path
import json
R=Path('C:/ov/city')
POSES={'site_nbr_w':[-35,35,0],'site_nw1':[0,8,0],'site_nw2':[0,8,0],'site_nw3':[0,8,0],'site_nw4':[0,8,0],'site_back_w':[0,6,0],'site_far_w':[-28,55,0]}
def put(p,s):(R/p).write_text(s,encoding='utf-8',newline='\n')
def change(p,a,b):
 s=(R/p).read_text(encoding='utf-8');assert a in s,(p,a[:80]);put(p,s.replace(a,b))
p='art/data/city_elevations/source_plan.json';data=json.loads((R/p).read_text())
for row in data['buildings']:
 if row['id'] in POSES:row['assembly_translation_m']=POSES[row['id']]
put(p,json.dumps(data,indent=2)+'\n')
put('game/scripts/building/orison_v2_city_placement.gd','''extends RefCounted
## Passive city assembly translations, authored in Blender metres. No state owner.
## The immutable geometry/UV stock stays shared; collision and roof fittings follow.
var source_offsets: Dictionary = {}

func _init() -> void:
\tvar data: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/orison_v2/exterior/city_elevations.json"))
\tassert(int(data.schema) == 1)
\tfor row: Dictionary in data.buildings:
\t\tvar values: Array = row.get("assembly_translation_m", [0., 0., 0.])
\t\tassert(values.size() == 3)
\t\tvar offset := Vector3(float(values[0]), float(values[1]), float(values[2]))
\t\tassert(offset.is_finite() and not source_offsets.has(str(row.id)))
\t\tsource_offsets[str(row.id)] = offset

func source_offset(identity: String) -> Vector3:
\tfor key: String in source_offsets:
\t\tif identity == key or identity.begins_with(key + "_"):
\t\t\treturn source_offsets[key]
\treturn Vector3.ZERO

func city_offset(identity: String) -> Vector3:
\tvar source := source_offset(identity)
\treturn GameBoot.b2g([source.x, source.y, source.z])

func apply(draw: MeshInstance3D) -> void:
\tassert(not draw.has_meta("city_assembly_translation"), "City assembly must move once")
\tvar offset := city_offset(str(draw.name))
\tdraw.position += offset
\tdraw.set_meta("city_assembly_translation", offset)
''')
p='game/scripts/building/orison_v2_city_shells.gd'
change(p,'var materials: Dictionary={}','var placement := preload("res://scripts/building/orison_v2_city_placement.gd").new()\n\tvar materials: Dictionary={}')
change(p,'\t\tmesh.set_meta("retained_city_shell",true)','\t\tplacement.apply(mesh)\n\t\tmesh.set_meta("retained_city_shell",true)')
change(p,'"pivot":Vector3(pivot[0],pivot[1],pivot[2]),','"pivot":Vector3(pivot[0],pivot[1],pivot[2])+placement.city_offset(str(mesh.name)),')
for family in ['masts','aerials','tanks','beacons']:
 p=f'game/scripts/building/orison_v2_city_{family}.gd'
 change(p,'\tfor draw: MeshInstance3D in model.find_children','\tvar placement := preload("res://scripts/building/orison_v2_city_placement.gd").new()\n\tfor draw: MeshInstance3D in model.find_children')
 change(p,'\t\tdraw.material_override=','\t\tplacement.apply(draw)\n\t\tdraw.material_override=')
p='art/blender/scripts/build_city_elevations.py'
change(p,"['id','wall_key','wall_tint','frame_tint']","['id','wall_key','wall_tint','frame_tint']+(['assembly_translation_m'] if 'assembly_translation_m' in p else [])")
change(p,"'game/scripts/building/orison_v2_city_shells.gd',","'game/scripts/building/orison_v2_city_shells.gd','game/scripts/building/orison_v2_city_placement.gd',")
p='art/blender/scripts/build_city_foundations.py'
change(p,"for index, first in enumerate(profiles):",'''# Re-site the complete passive assembly before fitting to retained occupied stock.
# The old cutouts are not translated: the ground builder regenerates them from
# these newly fitted components, filling vacated sites with ordinary grade.
placement_path=root/'art/data/city_elevations/source_plan.json'
placements={r['id']:r.get('assembly_translation_m',[0,0,0]) for r in json.loads(placement_path.read_text())['buildings']}
for profile in profiles:
    identity=profile['id'].removesuffix('_base0')
    dx,dy,dz=placements.get(identity,[0,0,0])
    assert all(math.isfinite(v) for v in [dx,dy,dz])
    offset=[-dx,dz,dy]
    profile['native_bounds']=[v+offset[i%3] for i,v in enumerate(profile['native_bounds'])]
    profile['underside']=[v+offset[0 if i%2==0 else 2] for i,v in enumerate(profile['underside'])]
    profile['underside_faces']=[[[v+offset[i] for i,v in enumerate(p)] for p in face] for face in profile['underside_faces']]
    profile['assembly_translation_m']=[dx,dy,dz]
for index, first in enumerate(profiles):''')
change(p,'roster_path,sets_path,Path(__file__)]','roster_path,sets_path,placement_path,Path(__file__)]')
# Posed diagnostic geometry is a copy of immutable authoring fixtures. The
# loaded meshes and independently rebuilt foundation fixtures remain the proof.
p='game/tests/v2_city_context_review.gd'
s=(R/p).read_text();s+='''

static func placed_fixture(original: Dictionary) -> Dictionary:
\tvar result: Dictionary = original.duplicate(true)
\tvar placement := preload("res://scripts/building/orison_v2_city_placement.gd").new()
\tfor row: Dictionary in result.get("buildings", []):
\t\tvar offset: Vector3 = placement.source_offset(str(row.id))
\t\tfor key: String in ["main_rect", "original_roof_rect"]:
\t\t\tif not row.has(key): continue
\t\t\tfor index in 4: row[key][index] += offset.x if index % 2 == 0 else offset.y
\tfor field: String in ["window_rows", "portals", "roof_samples", "court_details", "contacts"]:
\t\tfor row: Dictionary in result.get(field, []):
\t\t\tvar offset: Vector3 = placement.source_offset(str(row.get("building", row.get("id", ""))))
\t\t\tfor key: String in ["center", "pane_sample", "point", "void_probe"]:
\t\t\t\tif not row.has(key): continue
\t\t\t\tfor index in 3: row[key][index] += offset[index]
\t\t\tfor point: Array in row.get("footprint", []):
\t\t\t\tfor index in 3: point[index] += offset[index]
\treturn result
''';put(p,s)
for p in ['game/tests/v2_city_elevation_bench.gd','game/tests/v2_city_elevation_review.gd']:
 s=(R/p).read_text()
 for var in ['fixture','original','data']:
  lines=s.splitlines()
  for i,line in enumerate(lines):
   if f'var {var}: Dictionary=JSON.parse_string(' in line and 'orison_city_' in line:
    indent=line[:len(line)-len(line.lstrip())]
    lines[i]=line+'\n'+indent+var+' = preload("res://tests/v2_city_context_review.gd").placed_fixture('+var+')'
  s='\n'.join(lines)+'\n'
 put(p,s)
print('City placement implementation applied; native foundation/ground/apron and elevation projection rebuilds required')
