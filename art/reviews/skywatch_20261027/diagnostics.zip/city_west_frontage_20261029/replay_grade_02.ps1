$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'C:/ov/city'
$cityBlender = 'C:/Program Files/Blender Foundation/Blender 5.2/blender.exe'
$cityEvidence = 'C:/ov/reports/city_west_20261029'
function Run-CityStep([string]$name, [string]$program, [string[]]$arguments) {
    & $program @arguments *> "$cityEvidence/$name.log"
    if ($LASTEXITCODE -ne 0) { throw "$name failed; original output retained" }
    Write-Output "$name PASS"
}
Run-CityStep 'native_grade_sources_02' $cityBlender @('--background','--python-exit-code','1','--python','art/blender/scripts/export_retained_grade_sources.py','--','--survey',"$cityEvidence/grade_owner_survey_02/grade_owners.json",'--out',"$cityEvidence/native_grade_sources_02.json")
Run-CityStep 'grade_plan_02' 'python' @('tools/plan_v2_retained_grade.py','--native',"$cityEvidence/native_grade_sources_02.json",'--survey',"$cityEvidence/grade_owner_survey_02/grade_owners.json",'--out','art/data/orison_ground/retained_grade_source.json','--report',"$cityEvidence/grade_plan_02.json")
Run-CityStep 'build_city_foundations_03' $cityBlender @('--background','--python-exit-code','1','--python','art/blender/scripts/build_city_foundations.py')
Run-CityStep 'bar_reservations_02' 'python' @('art/tools/export_bar_ground_reservations.py')
Run-CityStep 'build_orison_ground_03' $cityBlender @('--background','--python-exit-code','1','--python','art/blender/scripts/build_orison_ground.py')
Run-CityStep 'build_city_ground_apron_02' $cityBlender @('--background','--python-exit-code','1','--python','art/blender/scripts/build_city_ground_apron.py')
Run-CityStep 'build_city_horizon_02' $cityBlender @('--background','--python-exit-code','1','--python','art/blender/scripts/build_city_horizon.py')
