"""Append current city diagnostics to the existing reviewed archive; preserve history."""
from pathlib import Path
import hashlib,json,zipfile
R=Path('C:/ov/city');P=Path(__file__).parent
archive=R/'art/reviews/skywatch_20261027/diagnostics.zip'
index=archive.with_name('manifest.json'); prefix='city_west_frontage_20261029/'
def sha(raw):return hashlib.sha256(raw).hexdigest()
manifest=json.loads(index.read_text(encoding='utf-8'))
previous_manifest_members=dict(manifest['members'])
assert sha(archive.read_bytes())==manifest['archive_sha256']
with zipfile.ZipFile(archive) as z:
    assert not any(n.startswith(prefix) for n in z.namelist())
    previous={n:sha(z.read(n)) for n in z.namelist()}
texts={'.json','.log','.stderr','.txt','.py','.ps1','.gd','.md'}
files=[f for f in P.rglob('*') if f.is_file() and f.suffix.lower() in texts and 'previous_surface_packet' not in f.parts]
files += [P/s for s in ['native_final_04/front_west.png','native_final_04/barricade_grazing.png','west_frontage_05/west_from_front_walk.png','west_frontage_05/west_restored_blocker_control.png']]
members={}
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted(set(files)):
        name=prefix+f.relative_to(P).as_posix();raw=f.read_bytes()
        z.writestr(name,raw);members[name]=sha(raw)
    external={f.relative_to(P).as_posix():dict(bytes=f.stat().st_size,sha256=sha(f.read_bytes())) for f in P.rglob('*') if f.is_file() and f.suffix.lower() in {'.png','.zip'}}
    raw=(json.dumps(dict(evidence_class='INERT',scope='External originals remain at the recorded evidence root. Hash index is not implementation or acceptance.',root=str(P),files=external),indent=2)+'\n').encode()
    name=prefix+'external_media_index.json';z.writestr(name,raw);members[name]=sha(raw)
with zipfile.ZipFile(archive) as z:
    assert all(sha(z.read(n))==h for n,h in previous.items()),'Earlier member changed'
    assert all(sha(z.read(n))==h for n,h in members.items()),'New member failed verification'
manifest['members'].update(members);manifest['archive_sha256']=sha(archive.read_bytes())
assert all(manifest['members'][n]==h for n,h in previous_manifest_members.items()),'Earlier index entry changed'
contract=json.loads((P/'surface_final_02/runtime_contract.json').read_text())
manifest['city_west_frontage_20261029']=dict(evidence_class='INERT',base='3ea80715bd201738d5566dea18bc17d4353ca867',branch='codex/v2-city-20261029',raw_prefix=prefix,scope='Seven retained passive assembly translations, native low closed works body, source-fitted grade. No new individual building, passive-lot access, save reconstruction or artistic acceptance.',prior_members_preserved=len(previous),new_members=len(members),played_checks=159,played_waypoints=39,matched_profile_waypoints=124,surface_checks=contract.get('checks'),surface_contracts=contract['contracts'],measurements=prefix+'measured_city_comparison.json',failures_retained=True,source_snapshot_scope='Original failed scripts/logs/receipts and current native/runtime witnesses; large original images/import-churn archives retained externally with SHA256 index.')
index.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Earlier members verified:',len(previous),'new members:',len(members),'archive MiB:',round(archive.stat().st_size/1048576,2))
