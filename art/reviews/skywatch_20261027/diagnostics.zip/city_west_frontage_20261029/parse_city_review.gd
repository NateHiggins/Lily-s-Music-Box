extends SceneTree
func _initialize() -> void:
	call_deferred("_check_sources")
func _check_sources() -> void:
	var failed := 0
	for path: String in ["res://tests/v2_city_elevation_review.gd","res://tests/orison_v2_surface_inventory.gd","res://tests/v2_city_west_frontage.gd"]:
		var source := load(path) as Script
		var valid: bool = source != null and source.can_instantiate()
		print("CITY PARSE DIAGNOSTIC: ",path," = ",valid)
		if not valid:failed+=1
	quit(0 if failed==0 else 1)
