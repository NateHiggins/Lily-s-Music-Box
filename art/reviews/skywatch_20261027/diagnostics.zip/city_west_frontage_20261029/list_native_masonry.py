import bpy
with bpy.data.libraries.load('C:/ov/city/art/blender/exterior_masonry.blend',link=False) as (a,b):
 print('COLLECTIONS',a.collections)
 print('OBJECTS',len(a.objects),a.objects[:15])
