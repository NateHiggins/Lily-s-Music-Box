import bpy,math
import json
from pathlib import Path
from mathutils import Vector
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=True
scene.render.resolution_x=1800;scene.render.resolution_y=1000;scene.render.resolution_percentage=100
scene.world=bpy.data.worlds.new('Review world');scene.world.color=(.2,.2,.2)
prop=bpy.data.objects['propeller__timber'];prop.hide_render=True
for p in json.loads(Path('C:/PleaseRemainOnTheLine/game/data/orison_v2/exterior/skyward_liner.json').read_text())['propeller_mounts']:
 obj=bpy.data.objects.new('Installed propeller',prop.data);scene.collection.objects.link(obj);obj.location=(p[0],-p[2],p[1]);obj.rotation_euler.x=.5
def aim(obj,at):obj.rotation_euler=(Vector(at)-obj.location).to_track_quat('-Z','Y').to_euler()
for name,where,energy,size in [('Key',(30,-80,120),4500000,90),('Rim',(-100,40,80),3000000,60),('Fill',(60,80,10),1000000,60)]:
 data=bpy.data.lights.new(name,'AREA');data.energy=energy;data.size=size;obj=bpy.data.objects.new(name,data);scene.collection.objects.link(obj);obj.location=where;aim(obj,(0,0,0))
camera=bpy.data.objects.new('Review',bpy.data.cameras.new('Review'));scene.collection.objects.link(camera);scene.camera=camera;camera.data.lens=55;camera.data.clip_end=2000
out=Path('C:/ov/reports/skywatch34/airship_native_review');out.mkdir(exist_ok=True)
for name,eye,target in [('whole',(160,-210,35),(0,0,-1)),('below',(110,-140,-70),(0,0,-1)),('gondola',(54,-50,-27),(18,0,-10))]:
 camera.location=eye;aim(camera,target);scene.render.filepath=str(out/(name+'.png'));bpy.ops.render.render(write_still=True)
