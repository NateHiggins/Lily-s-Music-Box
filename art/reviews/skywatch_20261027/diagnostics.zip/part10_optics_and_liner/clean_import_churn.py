from pathlib import Path
import subprocess,json,re,hashlib,time
root=Path.cwd().resolve()
log=Path('C:/ov/reports/skywatch34/airship_import_1.log.stderr').read_text()
paths=sorted(set(re.findall(r'Missing \.uid file for path "res://([^"]+)"',log)))
untracked=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','*.uid'],text=True).splitlines())
owned=['game/'+p+'.uid' for p in paths if 'game/'+p+'.uid' in untracked]
record={'proven_recreated_uids':owned,'untracked_uids_before':len(untracked),'restored_line_end_only_imports':[]}
for name in owned:
 p=(root/name).resolve();assert p.is_relative_to(root)
 p.unlink()
for row in subprocess.check_output(['git','status','--porcelain'],text=True).splitlines():
 name=row[3:]
 if not name.endswith('.import') or row[:2]=='??':continue
 before=subprocess.check_output(['git','show','HEAD:'+name])
 current=(root/name).read_bytes()
 if before.replace(b'\r\n',b'\n')==current.replace(b'\r\n',b'\n'):
  # Restore only the exact import files which this import changed in line endings.
  for attempt in range(20):
   result=subprocess.run(['git','restore','--source=HEAD','--',name],capture_output=True)
   if result.returncode==0:break
   if b'index.lock' not in result.stderr:raise RuntimeError(result.stderr.decode())
   time.sleep(.3)
  else:raise RuntimeError('Git index remained busy; no lock was removed')
  record['restored_line_end_only_imports'].append(name)
Path('C:/ov/reports/skywatch34/import_churn_cleanup.json').write_text(json.dumps(record,indent=2)+'\n')
print('Removed logged regenerated untracked UIDs:',len(owned),'restored line-only imports:',len(record['restored_line_end_only_imports']))
