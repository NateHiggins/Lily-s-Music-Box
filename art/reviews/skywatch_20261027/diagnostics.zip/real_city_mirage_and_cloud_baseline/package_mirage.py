from pathlib import Path
import hashlib,json,zipfile
from PIL import Image,ImageDraw
root=Path.cwd(); folder=root/'art/reviews/skywatch_20261027'; out=Path('C:/ov/reports/skywatch35')
archive=folder/'diagnostics.zip'; prefix='real_city_mirage_and_cloud_baseline/'
manifest=json.loads((folder/'manifest.json').read_text())
paths=['game/scripts/building/skywatch_mirage.gd','game/shaders/skywatch_mirage.compute','game/scripts/building/WeatherManager.gd','game/scripts/building/v2_city_day_night_director.gd','game/shaders/sky_spectacle.gdshaderinc','game/tests/skywatch_optical_review.gd','game/tests/v2_weather_route_profile.gd','game/tests/orison_v2_street_crossing_test.gd','tools/build_weather_noise.py']
scope={'scope':'native mirage controls, occupied ABBA diagnostic, five dated cloud baselines; not production/annual/human acceptance','source_lf_sha256':{},'captures':{}}
frames=[out/'mirage_fractional_fixed'/n for n in ['geometry_control.png','geometry_refracted.png','near_refracted.png']]+[out/'mirage_world_fixed'/n for n in ['mirage_1_on_street.png','last_position.png']]
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
 assert not any(n.startswith(prefix) for n in z.namelist())
 for name in paths:
  data=(root/name).read_bytes();z.writestr(prefix+'checkpoint_source/'+name,data)
  scope['source_lf_sha256'][name]=hashlib.sha256(data.replace(b'\r\n',b'\n')).hexdigest()
 for f in sorted(out.glob('*')):
  if f.is_file() and ('.log' in f.name or f.suffix=='.json'):z.write(f,prefix+f.name)
 for directory in out.iterdir():
  if directory.is_dir():
   for f in directory.glob('*.json'):z.write(f,prefix+directory.name+'/'+f.name)
 cloud=Path('C:/ov/reports/skywatch36')
 for f in cloud.glob('*.log*'):z.write(f,prefix+'cloud_baseline/'+f.name)
 for d in ['cloud_before_fixed','cloud_before_diurnal']:
  for f in (cloud/d).glob('*.json'):z.write(f,prefix+'cloud_baseline/'+d+'/'+f.name)
 for f in [cloud/'cloud_before_sources.json',cloud/'cloud_before_contact.jpg',out/'package_mirage.py']:
  z.write(f,prefix+f.name)
 for f in (cloud/'cloud_before_sources').iterdir():z.write(f,prefix+'cloud_baseline/original_source/'+f.name)
for f in frames:scope['captures'][str(f)]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size}
sheet=Image.new('RGB',(1280,930),'#18181b');draw=ImageDraw.Draw(sheet)
for i,f in enumerate(frames):
 im=Image.open(f).convert('RGB');im.thumbnail((640,270));x=(i%2)*640;y=(i//2)*310
 sheet.paste(im,(x,y+30));draw.text((x+8,y+8),f.parent.name+'/'+f.stem,fill='white')
sheet.save(folder/'mirage_contact.jpg',quality=90)
scope['contact_sha256']=hashlib.sha256((folder/'mirage_contact.jpg').read_bytes()).hexdigest()
manifest['real_city_mirage_and_cloud_baseline']=scope
with zipfile.ZipFile(archive) as z:manifest['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
manifest['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
(folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archive bytes',archive.stat().st_size)
