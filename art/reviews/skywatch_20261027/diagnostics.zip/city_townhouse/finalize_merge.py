from pathlib import Path
import json,hashlib,zipfile,subprocess
root=Path('C:/PleaseRemainOnTheLine');out=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
candidate='05715f1200ed3f23562fa63e7da2c73e621f4dd2';merge='3ac65118cbca8f7fe28e4ea2a86fdecea1d23883'
assert subprocess.check_output(['git','rev-parse',candidate+'^{tree}'],cwd=root)==subprocess.check_output(['git','rev-parse',merge+'^{tree}'],cwd=root)
v=json.loads((out/'candidate/verification.json').read_text());assert not v['blocking'] and not v['comparison']['regressions'];assert len(v['candidate_board']['gates'])==114
p=root/'design/V2_CITY_CONTEXT_REPORT_2026-10-19.md';s=p.read_text(encoding='utf-8');s=s.replace('provenance. Candidate verification and integration remain pending.','''provenance. Candidate **05715f12** passes the **114-gate** comparison with zero
regressions, all **17 protected paths unchanged**, selector **V2**, clean
checkout and document lint, zero NEW reader fields and unchanged requirement
statuses. Existing unrelated red gates remain red. Godot ran separately through
the lane; the in-place verifier used --no-godot and does not establish fresh
checkout import/autocrlf behavior.

Merged through **PR #75**, commit **3ac65118cbca8f7fe28e4ea2a86fdecea1d23883**.
The merge tree exactly matches the qualified candidate. This following
report/archive change is metadata only; it does not renew runtime evidence.
The evidence archive preserves 1,570 prior members byte-for-byte and records
exact immutable Git recovery for three earlier clock images, keeping the
archive below 50 MiB. Task-owned import churn was archived before cleanup;
an empty stale index lock required a no-live-Git/exclusive-open/metadata check
before its exact-path removal. No other contributor's source was discarded.''');p.write_text(s,encoding='utf-8',newline='\n')
dest=root/'art/reviews/skywatch_20261027';archive=dest/'diagnostics.zip';m=json.loads((dest/'manifest.json').read_text());assert m['archive_sha256']==sha(archive.read_bytes())
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted((out/'candidate').glob('*')):
  if p.is_file():z.write(p,'city_townhouse/candidate/'+p.name)
 z.write(__file__,'city_townhouse/finalize_merge.py')
assert archive.stat().st_size<50*1024*1024
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()));m['members']={n:sha(z.read(n)) for n in z.namelist()}
section=m['city_townhouse'];section['candidate']={'sha':candidate,'gates':114,'regressions':0,'protected_unchanged':17,'selector':'v2','requirement_statuses_changed':[],'merge_sha':merge,'pr':75,'merge_tree_exact':True,'mode':'in-place; separately executed source-bound Godot suites'}
section['limits']=[x for x in section['limits'] if x!='Candidate verification pending.']
m['archive_sha256']=sha(archive.read_bytes());(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Exact merge/candidate tree verified; archived verdict; archive bytes',archive.stat().st_size)
