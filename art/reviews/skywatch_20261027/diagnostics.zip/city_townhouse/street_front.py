from pathlib import Path
import json
root=Path.cwd();out=Path(__file__).parent
p=root/'art/data/city_elevations/source_plan.json';j=json.loads(p.read_text());b=next(b for b in j['buildings'] if b['id']=='site_nw2')
b['architecture'].update(front_side=0,terraces=1)
b['description']='One three-storey Hunters Point Italianate house on its eight-metre street front: brick over a stone plinth, segmental hoods, one pedimented entry and a four-bracket timber cornice'
b['precedent']['name']='21-13 45th Avenue, Root and Rust, 1871–72'
b['precedent']['adaptation']='One brick Italianate house with its street frontage on the narrow end of the original 8 x 23.7 m parcel. The long sides remain party walls beside neighboring buildings. Three storeys, four-bracket cornice, segmental hoods and pediment derive from the LPC record. The closed street-level entry adapts the source raised stoop; no surveyed replica or accessible interior is implied.'
p.write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8',newline='\n')
p=root/'art/blender/scripts/build_city_elevations.py';s=p.read_text();(out/'terrace_builder.py').write_text(s)
frames='''[
        (Vector((X,y,0)),Vector((-1,0,0)),Vector((0,-1,0)),X-x),
        (Vector((X,Y-depth,0)),Vector((0,-1,0)),Vector((1,0,0)),Y-y-2*depth),
        (Vector((x,Y,0)),Vector((1,0,0)),Vector((0,1,0)),X-x),
        (Vector((x,y+depth,0)),Vector((0,1,0)),Vector((-1,0,0)),Y-y-2*depth)]'''
assert frames in s
s=s.replace('def townhouse_cornice(name,p,rect,roof):','''def facade_frames(rect,depth):
    x,y,X,Y=rect
    return '''+frames+'''

def townhouse_cornice(name,p,rect,roof):''')
s=s.replace("x,y,X,Y=rect;depth=float(p['reveal_depth']);width=Y-y-2*depth\n    origin=Vector((X,Y-depth,0));u=Vector((0,-1,0));out=Vector((1,0,0))", "origin,u,out,width=facade_frames(rect,float(p['reveal_depth']))[int(p['architecture']['front_side'])]")
# Replace only the facade enumeration, leaving the new shared helper literal.
s=s.replace('for side,(origin,tangent,out,length) in enumerate('+frames+'):', 'for side,(origin,tangent,out,length) in enumerate(facade_frames(rect,depth)):')
p.write_text(s,encoding='utf-8',newline='\n')
p=root/'game/tests/v2_city_elevation_bench.gd';s=p.read_text().replace('fixture.portals.size()==5,"two factory portals and three individual terrace entrances"','fixture.portals.size()==3,"two factory portals and one street-facing townhouse entry"').replace('terrace_portals==3,"original factory portals and all three terrace entrances remain nonempty"','terrace_portals==1,"original factory portals and the townhouse entry remain nonempty"').replace('int(detail.brackets)==12','int(detail.brackets)==4').replace('int(detail.terraces)==3,"three houses retain their own four-bracket cornice groups"','int(detail.terraces)==1,"the townhouse retains one four-bracket cornice group"')
s=s.replace('var toward_city := Vector3(-target.x,0.,-target.z).normalized()', 'var toward_city := Vector3.BACK if str(building.id)=="site_nw2" else Vector3(-target.x,0.,-target.z).normalized()')
s=s.replace('var viewport_size := get_viewport().get_visible_rect().size', 'if str(building.id)=="site_nw2":offset=toward_city*span*1.35+Vector3.UP*float(building.roof_height)*.1\n\t\t\tvar viewport_size := get_viewport().get_visible_rect().size')
p.write_text(s,encoding='utf-8',newline='\n')
p=root/'game/tests/v2_city_elevation_review.gd';s=p.read_text();assert '["site_nbr_e","site_ne1","site_back_e"]' in s;s=s.replace('["site_nbr_e","site_ne1","site_back_e"]','["site_nbr_e","site_ne1","site_back_e","site_nw2"]')
marker='\tawait preload("res://tests/v2_city_horizon_review.gd").new().run(world,suite,camera)'
assert marker in s
s=s.replace(marker,'''\t# The narrow end fronts the street; the long faces adjoin the other row
\t# buildings. Review in the composed world, not just an isolated asset camera.
\tvar townhouse_bounds: Array=[]
\tfor building: Dictionary in fixture.buildings:
\t\tif str(building.id)=="site_nw2":townhouse_bounds=building.main_rect
\tsuite.check(townhouse_bounds.size()==4,"one source townhouse reservation")
\tif townhouse_bounds.size()==4:
\t\tvar center_x:=float(townhouse_bounds[0]+townhouse_bounds[2])*.5
\t\tvar front_z: float=-float(townhouse_bounds[1])
\t\tvar target:=city.to_global(Vector3(center_x,5.8,front_z))
\t\tvar visible:=false
\t\tfor offset_x: float in [0.,-.8,.8]:
\t\t\tvar eye:=city.to_global(Vector3(center_x+offset_x,1.6,front_z+13.))
\t\t\tvar inside:=city.to_global(Vector3(center_x,5.8,front_z-.4))
\t\t\tvar hit:=world.get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(eye,inside,1,[world.player.get_rid()]))
\t\t\tif hit.is_empty() or not str(bodies.get(hit.collider.get_rid(),"")).begins_with("site_nw2__"):continue
\t\t\tcamera.global_position=eye;camera.look_at(target);visible=true
\t\t\tawait suite.get_tree().create_timer(.6).timeout
\t\t\tawait suite.shot("city_townhouse_street_front")
\t\t\tbreak
\t\tsuite.check(visible,"townhouse street front is genuinely visible with real world blockers retained")
'''+marker)
p.write_text(s,encoding='utf-8',newline='\n')
print('Restored the narrow street front and added actual composed-world sightline/capture checks')
