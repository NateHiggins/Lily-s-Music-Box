$ErrorActionPreference='Stop'
$scene='res://tests/OrisonV2SurfaceInventory.tscn'
$evidence='C:/ov/reports/city_townhouse_20261028'
$until=(Get-Date).AddMinutes(4)
while ((Get-Date) -lt $until) {
 if (Test-Path -LiteralPath "$evidence/route_street_b.log.receipt.json") {
  $receipt=Get-Content -LiteralPath "$evidence/route_street_b.log.receipt.json" -Raw | ConvertFrom-Json
  if (-not $receipt.execution.completed -or $receipt.execution.exit_code -ne 0) {throw 'Second route did not finish successfully'}
  $games=@(Get-CimInstance Win32_Process -Filter "name = 'godot.windows.editor.x86_64.llvm.exe'" | Where-Object {$_.CommandLine.Contains($scene) -and $_.CommandLine.Contains('PleaseRemainOnTheLine')})
  if ($games.Count -eq 1) {
   $game=$games[0];$chain=@();$walk=$game
   for ($i=0;$i -lt 6 -and $null -ne $walk;$i++) {
    $chain+=@{pid=$walk.ProcessId;parent=$walk.ParentProcessId;command=$walk.CommandLine;created=$walk.CreationDate}
    $walk=Get-CimInstance Win32_Process -Filter "ProcessId = $($walk.ParentProcessId)" -ErrorAction SilentlyContinue
   }
   if (-not ($chain | Where-Object {$_.command -like '*C:/ov/reports/city_townhouse_20261028/final_batch.ps1*'})) {throw 'Cannot prove this process belongs to our batch'}
   @{evidence_class='INERT';reason='Owner cancelled the superseded surface leg to fix parked-player support residency. Preceding two performance legs completed; no surface qualification claimed.';utc=(Get-Date).ToUniversalTime();game_pid=$game.ProcessId;ancestors=$chain} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$evidence/surface_cancellation.json"
   Stop-Process -Id $game.ProcessId -Force
   Write-Output "Cancelled only owned superseded surface process $($game.ProcessId)"
   exit 0
  }
 }
 Start-Sleep -Milliseconds 500
}
throw 'No owned superseded surface process appeared; nothing terminated'
