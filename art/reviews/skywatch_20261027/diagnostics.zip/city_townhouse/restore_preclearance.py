"""Restore the exact historical route GLB from the recorded final asset."""
from pathlib import Path
import argparse,json,hashlib,zlib,struct
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--source',required=True,type=Path);parser.add_argument('--out',required=True,type=Path);args=parser.parse_args()
home=Path(__file__).parent;m=json.loads((home/'preclearance_structured_recovery.json').read_text());raw=args.source.read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(raw)==m['new_sha256'],'Use the qualified final canonical GLB named by the record'
at=12;bb=None
while at<len(raw):
 size,kind=struct.unpack_from('<II',raw,at)
 if kind==0x004e4942:bb=raw[at+8:at+8+size]
 at+=size+8
assert bb is not None
payload=(home/m['payload_file']).read_bytes();assert sha(payload)==m['payload_sha256'];literal=zlib.decompress(payload);binary=bytearray(m['old_binary_length'])
for r in m['views']:
 source=bb if 'new_offset' in r else literal;at=r.get('new_offset',r.get('payload_offset'));binary[r['old_offset']:r['old_offset']+r['length']]=source[at:at+r['length']]
for i,value in m['nonzero_unused_binary_bytes']:binary[i]=value
json_file=(home/m['json_file']).read_bytes();assert sha(json_file)==m['json_sha256'];doc=zlib.decompress(json_file)
old=bytes.fromhex(m['old_header_hex'])+struct.pack('<II',len(doc),0x4e4f534a)+doc+struct.pack('<II',len(binary),0x004e4942)+binary
assert sha(old)==m['old_sha256'];assert not args.out.exists(),'Refusing to overwrite existing evidence';args.out.write_bytes(old);print('Restored exact historical GLB',m['old_sha256'])
