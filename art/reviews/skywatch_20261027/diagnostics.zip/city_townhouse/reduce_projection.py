from pathlib import Path
root=Path.cwd();p=root/'art/blender/scripts/build_city_elevations.py';s=p.read_text();(Path(__file__).parent/'oriented_builder.py').write_text(s)
a=s.index('def townhouse_cornice(');b=s.index('\ndef facade(',a);block=s[a:b]
block=block.replace('    bottom=roof-.20', '''    # The neighboring sash/sills project into this narrow reservation gap.
    # Scale decorative depth only; retain the seated back faces and stock width.
    projection=.78
    def stock(key,lo,hi):
        lo=(lo[0],lo[1]*projection if lo[1]>0 else lo[1],lo[2])
        hi=(hi[0],hi[1]*projection if hi[1]>0 else hi[1],hi[2])
        local_box(name,key,origin,u,out,lo,hi)
    bottom=roof-.20''')
block=block.replace("profile_stock(name,'wood_dark',origin+u*at,out,u,[(-.03,bottom-.54),(.14,bottom-.54),(.18,bottom-.28),(.32,bottom-.09),(.42,bottom),(-.03,bottom)],-.095,.095)", "profile_stock(name,'wood_dark',origin+u*at,out,u,[(d*projection if d>0 else d,z) for d,z in [(-.03,bottom-.54),(.14,bottom-.54),(.18,bottom-.28),(.32,bottom-.09),(.42,bottom),(-.03,bottom)]],-.095,.095)")
block=block.replace("local_box(name,'", "stock('").replace(',origin,u,out,(', ',(')
# The nested stock implementation must still dispatch to the shared box builder.
assert 'local_box(name,key,origin,u,out,lo,hi)' in block
block=block.replace('out*.52+', 'out*(.52*projection)+')
s=s[:a]+block+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('Reduced decorative projection by 22 percent, without changing bearings or facade planes')
