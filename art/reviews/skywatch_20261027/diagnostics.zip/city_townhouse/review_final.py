from pathlib import Path
import bpy,json,hashlib
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
ROOT=Path.cwd();out=Path('C:/ov/reports/city_townhouse_20261028/native_final_review');out.mkdir(parents=True,exist_ok=True)
ids={'site_nw2'}
paths=[ROOT/f'art/blender/city_{f}.blend' for f in ['elevations','masts','aerials','tanks','beacons']]
before={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
bpy.ops.wm.read_factory_settings(use_empty=True);objects=[]
for path in paths:
 with bpy.data.libraries.load(str(path),link=False) as (a,b):b.objects=[n for n in a.objects if n.split('__')[0] in ids]
 for o in b.objects:
  if o.hide_render:continue
  bpy.context.scene.collection.objects.link(o);objects.append(o)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=12
scene.render.resolution_x=1280;scene.render.resolution_y=800;scene.render.resolution_percentage=100
scene.world=bpy.data.worlds.new('Review');scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.6,.7,.8,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.7
l=bpy.data.lights.new('Sun','SUN');l.energy=3;o=bpy.data.objects.new('Sun',l);scene.collection.objects.link(o);o.rotation_euler=(.45,-.35,-.7)
c=bpy.data.cameras.new('Review');o=bpy.data.objects.new('Review',c);scene.collection.objects.link(o);scene.camera=o;c.lens=28
report=json.loads((ROOT/'art/blender/city_elevations_construction.json').read_text());views=[]
for b in report['buildings']:
 if b['id'] not in ids:continue
 r=b['main_rect'];span=max(r[2]-r[0],r[3]-r[1]);h=b['roof_height'];cx=(r[0]+r[2])*.5;cy=(r[1]+r[3])*.5
 direction=Vector((-cx,-cy,0)).normalized();tangent=Vector((-direction.y,direction.x,0))
 top=max((ob.matrix_world@v.co).z for ob in objects if ob.name.startswith(b['id']+'__') for v in ob.data.vertices)
 target=Vector((cx,cy,top*.48));o.location=target+direction*span*1.35+-tangent*span*.6+Vector((0,0,h*.35));o.rotation_euler=(target-o.location).to_track_quat('-Z','Y').to_euler()
 for obj in objects:obj.hide_render=not obj.name.startswith(b['id']+'__')
 offset=o.location-target
 for attempt in range(12):
  o.location=target+offset*1.2**attempt;o.rotation_euler=(target-o.location).to_track_quat('-Z','Y').to_euler();bpy.context.view_layer.update()
  points=[world_to_camera_view(scene,o,ob.matrix_world@Vector(corner)) for ob in objects if not ob.hide_render for corner in ob.bound_box]
  if all(p.z>0 and .05<=p.x<=.95 and .05<=p.y<=.95 for p in points):break
 else:raise AssertionError(('cannot frame complete native stock',b['id']))
 scene.render.filepath=str(out/(b['id']+'.png'));bpy.ops.render.render(write_still=True);views.append({'id':b['id'],'at':list(o.location),'target':list(target)})
assert all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in before.items())
(out/'review.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Read-only native factory and seated equipment study, not runtime acceptance.','source_bindings':before,'views':views},indent=2)+'\n')

