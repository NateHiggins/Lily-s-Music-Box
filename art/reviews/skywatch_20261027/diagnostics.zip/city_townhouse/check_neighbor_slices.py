from pathlib import Path
import bpy,json,hashlib
root=Path.cwd();out=Path(__file__).parent;asset=root/'art/blender/city_elevations.blend';before=hashlib.sha256(asset.read_bytes()).hexdigest()
bpy.ops.wm.open_mainfile(filepath=str(asset));draws=list(bpy.data.collections['V2CityElevations'].objects)
def faces(prefix):
 return [[o.matrix_world@o.data.vertices[i].co for i in f.vertices] for o in draws if o.name.startswith(prefix) for f in o.data.polygons]
own=[p for p in faces('site_nw2__wood_dark') if max(v.z for v in p)>10.4]
neighbor=faces('site_nw1__')
def clip(poly,axis,edge,sign):
 result=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  da=sign*(a[axis]-edge);db=sign*(b[axis]-edge)
  if da>=0:result.append(a)
  if (da>=0)!=(db>=0):result.append(a+(b-a)*(da/(da-db)))
 return result
ymin=min(v.y for p in own for v in p);ymax=max(v.y for p in own for v in p)
zmin=min(v.z for p in own for v in p);zmax=max(v.z for p in own for v in p)
# Break at every actual vertex height, so the first whole-box diagnostic's
# unrelated low sill / high crown extrema are never paired across heights.
zs=sorted({zmin,zmax}|{float(v.z) for p in own+neighbor for v in p if zmin<v.z<zmax})
records=[]
for low,high in zip(zs,zs[1:]):
 if high-low<1e-6:continue
 samples=[]
 for face_set in [own,neighbor]:
  points=[]
  for face in face_set:
   if max(v.z for v in face)<low or min(v.z for v in face)>high:continue
   poly=face
   for axis,edge,sign in [(1,ymin,1),(1,ymax,-1),(2,low,1),(2,high,-1)]:
    if poly:poly=clip(poly,axis,edge,sign)
   points.extend(poly)
  samples.append(points)
 if all(samples):records.append({'z_range':[low,high],'clearance_lower_bound_m':min(v.x for v in samples[1])-max(v.x for v in samples[0])})
assert records
result={'evidence_class':'INERT','scope':'Conservative native X separation in exact source-vertex height slabs over the entire cornice Y span. A positive lower bound proves disjoint geometry; a negative bound is inconclusive without lateral refinement. Not runtime or played alley access proof.','source_sha256':before,'slabs':records,'minimum_clearance_lower_bound_m':min(v['clearance_lower_bound_m'] for v in records)}
(out/'neighbor_slices.json').write_text(json.dumps(result,indent=2)+'\n')
assert hashlib.sha256(asset.read_bytes()).hexdigest()==before
assert result['minimum_clearance_lower_bound_m']>0,result['minimum_clearance_lower_bound_m']
print('Native height-resolved lower-bound clearance',result['minimum_clearance_lower_bound_m'],'m')
