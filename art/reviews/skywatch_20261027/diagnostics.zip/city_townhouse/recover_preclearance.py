from pathlib import Path
import json,hashlib,struct,zlib
out=Path(__file__).parent;root=Path.cwd()
sha=lambda b:hashlib.sha256(b).hexdigest()
def chunks(raw):
 result={};at=12
 while at<len(raw):
  size,kind=struct.unpack_from('<II',raw,at);result[kind]=raw[at+8:at+8+size];at+=size+8
 return result
old=(out/'preclearance.glb').read_bytes();new=(root/'game/assets/props/city_elevations.glb').read_bytes();a=chunks(old);b=chunks(new);ad=json.loads(a[0x4e4f534a]);bd=json.loads(b[0x4e4f534a]);ab=a[0x004e4942];bb=b[0x004e4942]
lookup={}
for view in bd['bufferViews']:
 start=view.get('byteOffset',0);length=view['byteLength'];lookup[(length,sha(bb[start:start+length]))]=start
restored=bytearray(len(ab));covered=bytearray(len(ab));payload=bytearray();records=[]
for view in ad['bufferViews']:
 start=view.get('byteOffset',0);length=view['byteLength'];raw=ab[start:start+length];signature=(length,sha(raw));record={'old_offset':start,'length':length}
 if signature in lookup:
  source=lookup[signature];record['new_offset']=source;recovered=bb[source:source+length]
 else:
  record['payload_offset']=len(payload);payload.extend(raw);recovered=raw
 restored[start:start+length]=recovered;covered[start:start+length]=b'\1'*length;records.append(record)
unused=[(i,value) for i,value in enumerate(ab) if value and not covered[i]]
for i,value in unused:restored[i]=value
assert bytes(restored)==ab
json_name='preclearance_json.zlib';payload_name='preclearance_views.zlib'
(out/json_name).write_bytes(zlib.compress(a[0x4e4f534a],9));(out/payload_name).write_bytes(zlib.compress(bytes(payload),9))
meta={'evidence_class':'INERT','scope':'Exact original route GLB recovery. Copy unchanged views from the final canonical GLB, restore changed views and literal original JSON. No reauthored or repinned evidence.','old_sha256':sha(old),'new_sha256':sha(new),'old_header_hex':old[:12].hex(),'old_binary_length':len(ab),'json_file':json_name,'json_sha256':sha((out/json_name).read_bytes()),'payload_file':payload_name,'payload_sha256':sha((out/payload_name).read_bytes()),'views':records,'nonzero_unused_binary_bytes':unused,'recovery_verified':True,'external_native_blend_sha256':sha((out/'preclearance.blend').read_bytes())}
(out/'preclearance_structured_recovery.json').write_text(json.dumps(meta,indent=2)+'\n')
# Reconstruct a second time using only the serialized recovery metadata and
# files plus the final canonical asset, rather than the source old binary.
m=json.loads((out/'preclearance_structured_recovery.json').read_text());literal=zlib.decompress((out/m['payload_file']).read_bytes());binary=bytearray(m['old_binary_length'])
for record in m['views']:
 length=record['length'];source=bb if 'new_offset' in record else literal;at=record.get('new_offset',record.get('payload_offset'));binary[record['old_offset']:record['old_offset']+length]=source[at:at+length]
for i,value in m['nonzero_unused_binary_bytes']:binary[i]=value
json_raw=zlib.decompress((out/m['json_file']).read_bytes());recovered=bytes.fromhex(m['old_header_hex'])+struct.pack('<II',len(json_raw),0x4e4f534a)+json_raw+struct.pack('<II',len(binary),0x004e4942)+binary
assert sha(recovered)==m['old_sha256'] and recovered==old
print('Exact structured recovery bytes',sum((out/p).stat().st_size for p in [json_name,payload_name,'preclearance_structured_recovery.json']),'unchanged views',sum('new_offset' in r for r in records),'changed views',sum('payload_offset' in r for r in records))
