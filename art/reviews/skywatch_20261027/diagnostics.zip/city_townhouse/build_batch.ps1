$ErrorActionPreference='Stop'
Set-Location -LiteralPath C:/PleaseRemainOnTheLine
$env:CITY_ELEVATIONS_REVIEW_DIR='C:/ov/reports/city_townhouse_20261028/native_final'
foreach ($part in @('shells','masts','aerials','tanks','beacons','closure','elevations')) {
 & 'C:/Program Files/Blender Foundation/Blender 5.2/blender.exe' -b --python-exit-code 1 --python "art/blender/scripts/build_city_$part.py" *> "C:/ov/reports/city_townhouse_20261028/build_$part.log"
 if ($LASTEXITCODE -ne 0) {throw "$part failed: $LASTEXITCODE"}
}
