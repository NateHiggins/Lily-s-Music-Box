$ErrorActionPreference='Stop'
Set-Location -LiteralPath C:/PleaseRemainOnTheLine
Remove-Item Env:ORISON_SURFACE_CITY_ONLY,Env:ORISON_SURFACE_FIRE_ONLY,Env:ORISON_DEVELOPER_OVERLAYS,Env:AGENDA_QUERY_ONLY,Env:AGENDA_QUERY_PROFILE,Env:V2_PROFILE_RELEASES,Env:SKYWATCH_MIRAGE_PROFILE,Env:WEATHER_RESOURCE_SCOPE_CONTROL,Env:WEATHER_LIFECYCLE_REVIEW,Env:WEATHER_FALLOUT_RELOAD,Env:WEATHER_PRECIP_REVIEW,Env:SKY_LIBRARY_YEAR,Env:SKY_NATIVE_SAMPLING_PLAN,Env:SKY_REVIEW_SHADER_SOURCE,Env:SKYWATCH_OPTICAL_REVIEW,Env:WEATHER_SIMULATE,Env:WEATHER_FORMATION,Env:WEATHER_PHENOMENON,Env:DAYNIGHT_FORCE -ErrorAction SilentlyContinue
$env:SKYWATCH_CLOUD_PROFILE='1'
$env:ORISON_SURFACE_SKIP_FIRE_INTERACTION='1'
$env:GIT_OPTIONAL_LOCKS='0'
$nativeArgs=@('--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440')
$runs=@(
 @{scene='res://tests/V2WeatherRouteProfile.tscn';runner='long';timeout=700;windowed=$true;shot_dir='C:/ov/reports/city_townhouse_20261028/route_supported';log='C:/ov/reports/city_townhouse_20261028/route_supported.log';extra_args=$nativeArgs},
 @{scene='res://tests/OrisonV2SurfaceInventory.tscn';runner='long';timeout=1200;windowed=$true;shot_dir='C:/ov/reports/city_townhouse_20261028/surface_supported';log='C:/ov/reports/city_townhouse_20261028/surface_supported.log';extra_args=$nativeArgs},
 @{scene='res://tests/RoofWeatherPreviewTest.tscn';runner='long';timeout=650;windowed=$true;shot_dir='C:/ov/reports/city_townhouse_20261028/roof_supported';log='C:/ov/reports/city_townhouse_20261028/roof_supported.log';extra_args=$nativeArgs},
 @{scene='res://tests/V2CityElevationBench.tscn';runner='serial';timeout=175;windowed=$true;shot_dir='C:/ov/reports/city_townhouse_20261028/imported_supported';log='C:/ov/reports/city_townhouse_20261028/bench_supported.log';extra_args=$nativeArgs}
)
$runs | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath C:/ov/reports/city_townhouse_20261028/supported_batch.json -Encoding utf8
& ./tools/lane.ps1 batch -BatchFile C:/ov/reports/city_townhouse_20261028/supported_batch.json -WaitMinutes 15
exit $LASTEXITCODE
