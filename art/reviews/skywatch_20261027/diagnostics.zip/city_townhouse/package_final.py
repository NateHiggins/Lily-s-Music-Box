from pathlib import Path
import json,hashlib,zipfile,gzip,subprocess,io
from PIL import Image
root=Path('C:/PleaseRemainOnTheLine');out=Path(__file__).parent
dest=root/'art/reviews/skywatch_20261027';archive=dest/'diagnostics.zip';prefix='city_townhouse/'
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((dest/'manifest.json').read_text());assert sha(archive.read_bytes())==m['archive_sha256']
base='2467e7e65dfcf328257d6613500a5ef364d3e43a'
backup=out/'published_backup/previous_surface_packet';review=json.loads((backup/'visual_review.json').read_text())
names=['runtime_contract.json','surface-inventory.json','suite_run.receipt.json','suite_run.stdout.log.gz','suite_run.stderr.log.gz','visual_review.json']+[v['file'] for v in review['images']]
verified={}
for name in names:
 p=backup/(name+'.gz' if name=='surface-inventory.json' else name);raw=gzip.decompress(p.read_bytes()) if name=='surface-inventory.json' else p.read_bytes()
 old=subprocess.check_output(['git','show',base+':art/renders/orison_v2/surface_requirements_20261011/'+name],cwd=root);assert old==raw,name;verified[name]=sha(raw)
(out/'previous_packet_recovery.json').write_text(json.dumps({'commit':base,'byte_verified':verified},indent=2)+'\n')
reviews=out/'verified_review_images';reviews.mkdir(exist_ok=True);records=[]
for name,p in [('street_f8',out/'surface_verified/shot_001.png'),('native_front',out/'native_street_review/site_nw2.png')]:
 im=Image.open(p);target=reviews/(name+'.webp');im.save(target,'WEBP',lossless=True,method=6)
 assert Image.open(target).convert(im.mode).tobytes()==im.tobytes()
 records.append({'file':target.name,'original_png_sha256':sha(p.read_bytes()),'decoded_pixel_sha256':sha(im.tobytes()),'webp_sha256':sha(target.read_bytes()),'size':im.size,'pixel_exact':True,'external_original':str(p)})
(out/'verified_review_images.json').write_text(json.dumps({'evidence_class':'INERT','images':records},indent=2)+'\n')
excluded={'preclearance_recovery.json','preclearance_chunk_0.xor.zlib','preclearance_chunk_1.xor.zlib','write_docs.py','encode_evidence.py','prepare_surface_packet.py'}
files=[p for p in out.iterdir() if p.is_file() and p.name not in excluded and p.suffix in {'.py','.ps1','.json','.log','.stderr','.gd','.bin','.zip','.zlib'}]
files += [out/'main_baseline/board.json']
for folder in ['surface_verified','surface_supported','surface_bound','roof_verified','imported_verified','camera_flushed','camera_leased','camera_diagnostic','route','route_bound','route_street_a','route_street_b','route_supported']:
 files += sorted((out/folder).glob('*.json'))
files += sorted(reviews.glob('*.webp'))
files=list(dict.fromkeys(files));payload={prefix+p.relative_to(out).as_posix():p.read_bytes() for p in files}
# Preserve historical decoded images exactly via immutable Git recovery rather
# than keeping three nearly identical two-megabyte clock captures in every zip.
remove={f'city_sohmer/review_images/factory_clock_{angle}.webp' for angle in ['0000','0180','0735']}
base_zip=zipfile.ZipFile(io.BytesIO(subprocess.check_output(['git','show',base+':art/reviews/skywatch_20261027/diagnostics.zip'],cwd=root)))
recovery=[]
with zipfile.ZipFile(archive) as z:
 old={n:z.read(n) for n in z.namelist()};assert not any(n.startswith(prefix) for n in old)
 for n in sorted(remove):
  assert old[n]==base_zip.read(n)
  recovery.append({'member':n,'sha256':sha(old[n]),'commit':base,'archive_path':'art/reviews/skywatch_20261027/diagnostics.zip','bytes':len(old[n])})
 old={n:b for n,b in old.items() if n not in remove}
new=out/'diagnostics_final.zip'
with zipfile.ZipFile(new,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in {**old,**payload}.items():z.writestr(n,b)
assert new.stat().st_size<50*1024*1024,new.stat().st_size
with zipfile.ZipFile(new) as z:
 assert len(z.namelist())==len(set(z.namelist()));members={n:sha(z.read(n)) for n in z.namelist()}
 for n,b in old.items():assert members[n]==sha(b),n
archive.write_bytes(new.read_bytes())
contract=json.loads((out/'surface_verified/runtime_contract.json').read_text())
m['city_townhouse']={'evidence_class':'INERT','base':base,'scope':'Single narrow-front house and input-owned F8 inspection camera; not full city, save or human acceptance.','raw_prefix':prefix,'surface_checks':39291,'roof_checks':46,'loaded_checks':5405,'contracts':contract['contracts'],'comparison':json.loads((out/'supported_performance.json').read_text()),'previous_packet':json.loads((out/'previous_packet_recovery.json').read_text()),'review_images':records,'immutable_git_recovery':recovery,'discarded_terrace_commit':'197944bf','limits':['144 individual city studies remain.','Typical GPU and frame tails broadly unchanged; no FPS improvement claimed.','Original failed surface_supported contract retained; wrong-frontage surface_bound is not final qualification.','Save reconstruction NOT_EXECUTED; no human artistic acceptance.','Candidate verification pending.']}
m['members']=members;m['archive_sha256']=sha(archive.read_bytes());(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archived',len(files),'new files;',len(old),'old members exact;',len(recovery),'images exact Git recoverable; bytes',archive.stat().st_size)
