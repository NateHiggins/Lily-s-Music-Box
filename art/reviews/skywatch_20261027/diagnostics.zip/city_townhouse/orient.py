from pathlib import Path
import json
root=Path.cwd();out=Path(__file__).parent
p=root/'art/blender/scripts/build_city_elevations.py';s=p.read_text();(out/'first_builder.py').write_text(s)
s=s.replace("x,y,X,Y=rect;width=X-x;origin=Vector((X,y,0));u=Vector((-1,0,0));out=Vector((0,-1,0))", "x,y,X,Y=rect;depth=float(p['reveal_depth']);width=Y-y-2*depth\n    origin=Vector((X,Y-depth,0));u=Vector((0,-1,0));out=Vector((1,0,0))")
s=s.replace('positions=[.40+i*(width-.80)/3 for i in range(4)]', "terraces=int(p['architecture']['terraces']);unit=width/terraces\n    positions=[k*unit+.40+i*(unit-.80)/3 for k in range(terraces) for i in range(4)]")
s=s.replace("for left,right in zip(positions,positions[1:]):\n        local_box", "for left,right in zip(positions,positions[1:]):\n        if right-left<.9:continue\n        local_box")
s=s.replace('for i in range(28):\n        at=(i+.5)*width/28', 'for i in range(28*terraces):\n        at=(i+.5)*width/(28*terraces)')
s=s.replace('brackets=4,storeys=3','brackets=4*terraces,terraces=terraces,storeys=3')
s=s.replace("townhouse and side in [1,3]", "townhouse and side not in [int(p['architecture']['front_side']),(int(p['architecture']['front_side'])+2)%4]")
s=s.replace("bays=max(1,math.floor(length/p['bay_pitch']));pitch=length/bays", "bays=3*int(p['architecture']['terraces']) if townhouse else max(1,math.floor(length/p['bay_pitch']));pitch=length/bays")
s=s.replace("and bay==0)","and bay%3==0)")
# Keep every townhouse door cut through its own raised plinth; otherwise the
# decorative band would re-seal the lower entrance.
s=s.replace("local_box(name,'limestone',origin,u,out,(0,-.04,0),(width,.025,.53))\n    for z in [.18,.36]:\n        local_box(name,'limestone',origin,u,out,(0,.025,z),(width,.042,z+.025))", "pitch=width/(3*terraces);door_width=1.45\n    cursor=0.\n    for k in range(terraces):\n        center=(k*3+.5)*pitch\n        left=center-door_width*.5;right=center+door_width*.5\n        local_box(name,'limestone',origin,u,out,(cursor,-.04,0),(left,.025,.53))\n        for z in [.18,.36]:local_box(name,'limestone',origin,u,out,(cursor,.025,z),(left,.042,z+.025))\n        cursor=right\n    local_box(name,'limestone',origin,u,out,(cursor,-.04,0),(width,.025,.53))\n    for z in [.18,.36]:local_box(name,'limestone',origin,u,out,(cursor,.025,z),(width,.042,z+.025))")
p.write_text(s,encoding='utf-8',newline='\n')
p=root/'art/data/city_elevations/source_plan.json';j=json.loads(p.read_text());b=next(b for b in j['buildings'] if b['id']=='site_nw2');b['architecture'].update(front_side=1,terraces=3);b['description']='Three attached Hunters Point Italianate houses: brick over stone plinths, nine front bays, segmental hoods, three pedimented closed entries and separate four-bracket timber cornices'
b['precedent']['name']='21-09 through 21-17 45th Avenue, Root and Rust, 1871–72'
b['precedent']['adaptation']='Three-house terrace informed by the documented brick Italianate row and its four-bracket cornices, hoods and pediments. Authored proportions fit the existing 23.18 m frontage / 8 m deep reservation and preserve roof equipment. Street-level closed entries adapt the raised stoops. Not surveyed replicas or accessible interiors.'
p.write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8',newline='\n')
# Production-loader controls retain all existing factory and height tests.
p=root/'game/tests/v2_city_elevation_bench.gd';s=p.read_text()
s=s.replace('check(fixture.portals.size()==2,"two closed factory portals rather than ground-floor sashes everywhere")', '''check(fixture.portals.size()==5,"two factory portals and three individual terrace entrances")
	var factory_portals:=0
	var terrace_portals:=0'''.replace('+\t','\t'))
s=s.replace('check(str(portal.building)=="site_far_e","portal belongs to the adapted factory")', '''check(str(portal.building) in ["site_far_e","site_nw2"],"portal belongs to an explicitly adapted building")
		if str(portal.building)=="site_far_e":factory_portals+=1
		else:terrace_portals+=1'''.replace('+\t','\t'))
marker='\tfor study: Dictionary in factory_studies:'
assert marker in s
s=s.replace(marker,'''\tcheck(factory_portals==2 and terrace_portals==3,"original factory portals and all three terrace entrances remain nonempty")
\tvar terrace_details: Array=fixture.townhouse_details
\tcheck(terrace_details.size()==1,"one individual terrace study")
\tfor detail: Dictionary in terrace_details:
\t\tcheck(str(detail.building)=="site_nw2" and int(detail.brackets)==12 and int(detail.storeys)==3 and int(detail.terraces)==3,"three houses retain their own four-bracket cornice groups")
\t\tvar p: Array=detail.probe
\t\tvar n: Array=detail.normal
\t\tvar point:=city.to_global(Vector3(p[0],p[2],-p[1]))
\t\tvar normal:=Vector3(n[0],n[2],-n[1])
\t\tvar hit:=city.get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(point+normal*.1,point-normal*.4,1,exclude))
\t\tcheck(not hit.is_empty() and hit.position.distance_to(point)<.0001 and hit.normal.dot(normal)>.99
\t\t\t\tand str(shells.get(hit.collider.get_rid(),"")).ends_with("__"+str(detail.finish)),"real outward-facing terrace cornice, not a hidden or reversed facade")
'''.replace('+\t','\t')+marker)
s=s.replace('if not building.has("previous_roof_height"):continue\n\t\t\tvar top', 'if not building.has("previous_roof_height") and str(building.id)!="site_nw2":continue\n\t\t\tvar top')
p.write_text(s,encoding='utf-8',newline='\n')
print('Oriented the terrace to the actual inward frontage, preserved original assertions')
