$ErrorActionPreference='Stop'
Set-Location -LiteralPath C:/PleaseRemainOnTheLine
$env:GIT_OPTIONAL_LOCKS='0'
$arguments=@('--editor','--import')
& ./tools/lane.ps1 run -Runner serial -TimeoutSeconds 175 -LogPath C:/ov/reports/city_townhouse_20261028/import_final.log -ExtraArgs $arguments -WaitMinutes 15
if ($LASTEXITCODE -ne 0) {throw 'import failed'}
if (Select-String -Path C:/ov/reports/city_townhouse_20261028/import_final.log.stderr -Pattern 'SCRIPT ERROR|Parse Error|ERROR:') {throw 'import reported errors'}
$nativeArgs=@('--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440')
& ./tools/lane.ps1 run -Scene res://tests/V2CityElevationBench.tscn -Runner serial -TimeoutSeconds 175 -Windowed -ShotDir C:/ov/reports/city_townhouse_20261028/imported_final -LogPath C:/ov/reports/city_townhouse_20261028/bench_final.log -ExtraArgs $nativeArgs -WaitMinutes 15
exit $LASTEXITCODE
