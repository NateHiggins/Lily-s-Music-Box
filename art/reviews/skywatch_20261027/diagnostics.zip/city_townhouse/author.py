from pathlib import Path
import json
root=Path.cwd();path=root/'art/data/city_elevations/source_plan.json';j=json.loads(path.read_text())
p=next(p for p in j['buildings'] if p['id']=='site_nw2')
p.update(description='Three-storey Hunters Point Italianate adaptation: brick over a stone plinth, three front bays, segmental hoods, a pedimented closed entrance and four-bracket timber cornice',massing='straight_eave',floor_heights=[3.6,3.65,3.65],bay_pitch=2.66,window_width=1.30,window_height=2.15,wall_tint=[.78,.60,.48,1],detail_faces='all',architecture={'type':'hunters_point_italianate','front_side':0,'arch_rise_m':.18},precedent={'name':'21-13 45th Avenue, Root and Rust, 1871–72','source':'https://s-media.nyc.gov/agencies/lpc/lp/0450.pdf','pdf_pages':[3,4],'adaptation':'Authored three-storey brick Italianate frontage informed by the documented four-bracket cornice, hoods and pediment. Retain the existing 8 m reservation and roof equipment; a street-level closed entry adapts the raised stoop. Not a surveyed replica or accessible interior.'})
path.write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8',newline='\n')
path=root/'art/blender/scripts/build_city_elevations.py';s=path.read_text();(Path('C:/ov/reports/city_townhouse_20261028')/'before_builder.py').write_text(s)
def replace(a,b,count=1):
 global s
 assert s.count(a)==count,(a,s.count(a),count)
 s=s.replace(a,b)
replace('hand_origins={};clock_hands=[];architecture_checks=[];portal_rows=[]','hand_origins={};clock_hands=[];architecture_checks=[];portal_rows=[];townhouse_details=[]')
marker='def facade(name,p,rect,z0,z1):'
assert marker in s
s=s.replace(marker,'''def townhouse_cornice(name,p,rect,roof):
    x,y,X,Y=rect;width=X-x;origin=Vector((X,y,0));u=Vector((-1,0,0));out=Vector((0,-1,0))
    bottom=roof-.20
    # Four shaped bearing consoles join the timber fascia, with dentils and
    # raised panels between them. Closed stocks, not surface decals.
    positions=[.40+i*(width-.80)/3 for i in range(4)]
    for at in positions:
        profile_stock(name,'wood_dark',origin+u*at,out,u,[(-.03,bottom-.54),(.14,bottom-.54),(.18,bottom-.28),(.32,bottom-.09),(.42,bottom),(-.03,bottom)],-.095,.095)
    local_box(name,'wood_dark',origin,u,out,(0,-.03,bottom),(width,.43,roof+.27))
    local_box(name,'wood_dark',origin,u,out,(-.12,-.04,roof+.27),(width+.12,.52,roof+.41))
    for left,right in zip(positions,positions[1:]):
        local_box(name,'wood_dark',origin,u,out,(left+.22,.43,bottom+.09),(right-.22,.48,roof+.17))
    for i in range(28):
        at=(i+.5)*width/28
        local_box(name,'wood_dark',origin,u,out,(at-.05,.30,bottom-.06),(at+.05,.45,bottom))
    # A low, physically mapped masonry plinth; no six-metre concrete podium.
    local_box(name,'limestone',origin,u,out,(0,-.04,0),(width,.025,.53))
    for z in [.18,.36]:
        local_box(name,'limestone',origin,u,out,(0,.025,z),(width,.042,z+.025))
    point=origin+u*(width*.5)+out*.52+Vector((0,0,roof+.34))
    townhouse_details.append(dict(building=name,brackets=4,storeys=3,probe=list(point),normal=list(out),finish='wood_dark'))

'''+marker)
replace("    factory=p.get('architecture',{}).get('type')=='sohmer_factory'\n", "    factory=p.get('architecture',{}).get('type')=='sohmer_factory'\n    townhouse=p.get('architecture',{}).get('type')=='hunters_point_italianate'\n",3)
replace("        if p['detail_faces']=='inward' and out.dot(-origin)<=0:","        if (townhouse and side in [1,3]) or (p['detail_faces']=='inward' and out.dot(-origin)<=0):")
replace("                portal=factory and floor==0 and side in [0,3] and bay==bays//2", "                arched=factory or (townhouse and side==int(p['architecture']['front_side']))\n                portal=(factory and floor==0 and side in [0,3] and bay==bays//2) or (townhouse and floor==0 and side==int(p['architecture']['front_side']) and bay==0)")
replace("                if portal:w=min(2.0,pitch-.35);h=3.2", "                if portal:w=min(1.45 if townhouse else 2.0,pitch-.35);h=3.2")
replace("                if factory:\n                    rise=", "                if arched:\n                    rise=")
replace("                    arch_stock(name,p['wall_key'],origin,tangent,out,cx,spring,w/2,rise,.12,-.08,.035)", "                    arch_stock(name,'limestone' if townhouse else p['wall_key'],origin,tangent,out,cx,spring,w/2,rise,.12,-.08,.09 if townhouse else .035)\n                    if townhouse and not portal:\n                        # Projecting hood and two supporting corbels, with actual\n                        # contact at the hood spring rather than floating blocks.\n                        for edge in [wl-.10,wr+.10]:\n                            local_box(name,'limestone',origin,tangent,out,(edge-.055,-.03,spring-.19),(edge+.055,.16,spring+.005))")
replace("frame_top=high-float(p['architecture']['arch_rise_m']) if factory else high", "frame_top=high-float(p['architecture']['arch_rise_m']) if arched else high")
replace("                if not factory:local_box", "                if not arched:local_box")
replace("                    portal_rows.append(dict(building=name,side=side,point=list(point),front=-recess+.10))", "                    portal_rows.append(dict(building=name,side=side,point=list(point),front=-recess+.10))\n                    if townhouse:\n                        # Seated pilasters, console capitals and a closed triangular\n                        # pediment; the source's raised stoop is adapted to street level.\n                        for edge in [wl-.17,wr+.17]:\n                            local_box(name,'limestone',origin,tangent,out,(edge-.07,-.03,a),(edge+.07,.13,high+.12))\n                            local_box(name,'limestone',origin,tangent,out,(edge-.11,-.03,high+.04),(edge+.11,.23,high+.16))\n                        profile_stock(name,'limestone',origin,tangent,out,[(wl-.32,high+.16),(wr+.32,high+.16),(cx,high+.64)],-.03,.23)")
replace("if 'vertical_profile' in p and (suffix.startswith('base') or suffix=='bcorn'):continue", "if ('vertical_profile' in p or townhouse) and (suffix.startswith('base') or suffix=='bcorn'):continue")
replace("split=top if factory else last['z0'] if len(ss)>1 else top", "split=top if factory or townhouse else last['z0'] if len(ss)>1 else top")
replace("0. if 'vertical_profile' in p else ss[0]['z0']", "0. if 'vertical_profile' in p or townhouse else ss[0]['z0']")
replace("if len(ss)>1 and not factory:","if len(ss)>1 and not factory and not townhouse:")
replace("    stats.append(dict(id=name,old_setbacks=", "    if townhouse:townhouse_cornice(name,p,rect0,top+.26)\n    stats.append(dict(id=name,old_setbacks=")
replace("new_setbacks=0 if factory else", "new_setbacks=0 if factory or townhouse else")
replace("shaft_bottom=ss[0]['z0']", "shaft_bottom=0. if townhouse else ss[0]['z0']")
replace("assert not native_failures,native_failures[:12]", "for detail in townhouse_details:\n    point=Vector(detail['probe']);normal=Vector(detail['normal'])\n    hit,n,index,distance=bvh.ray_cast(point+normal*.1,-normal,.4)\n    if hit is None or (hit-point).length>.0001 or n.dot(normal)<.99 or not face_owners[index].endswith('__'+detail['finish']):native_failures.append(dict(kind='townhouse_cornice_front',detail=detail))\nassert not native_failures,native_failures[:12]")
replace("'architecture_checks':architecture_checks", "'architecture_checks':architecture_checks,'townhouse_details':townhouse_details") if "'architecture_checks':architecture_checks" in s else None
# The construction dictionary uses keyword arguments in this producer.
if 'townhouse_details=townhouse_details' not in s and "'townhouse_details':townhouse_details" not in s:
 replace('architecture_checks=architecture_checks','architecture_checks=architecture_checks,townhouse_details=townhouse_details')
path.write_text(s,encoding='utf-8',newline='\n')
print('Authored one townhouse, preserving the other 24 source profiles')
