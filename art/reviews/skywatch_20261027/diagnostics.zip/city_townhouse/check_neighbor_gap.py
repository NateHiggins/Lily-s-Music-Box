from pathlib import Path
import bpy,json,hashlib
from mathutils import Vector
root=Path.cwd();out=Path(__file__).parent;asset=root/'art/blender/city_elevations.blend';before=hashlib.sha256(asset.read_bytes()).hexdigest()
bpy.ops.wm.open_mainfile(filepath=str(asset))
draws=list(bpy.data.collections['V2CityElevations'].objects)
selected=[o for o in draws if o.name=='site_nw2__wood_dark']
assert len(selected)==1
# Restrict to the projecting cornice. Rear glazing backboards share the finish.
cornice=[selected[0].matrix_world@v.co for v in selected[0].data.vertices if (selected[0].matrix_world@v.co).z>10.4]
assert cornice
xmax=max(p.x for p in cornice);ymin=min(p.y for p in cornice);ymax=max(p.y for p in cornice);zmin=min(p.z for p in cornice);zmax=max(p.z for p in cornice)
def clip(poly,axis,edge,sign):
 result=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  da=sign*(a[axis]-edge);db=sign*(b[axis]-edge)
  if da>=0:result.append(a)
  if (da>=0)!=(db>=0):result.append(a+(b-a)*(da/(da-db)))
 return result
nearest=float('inf');parts=[]
for obj in draws:
 if not obj.name.startswith('site_nw1__'):continue
 found=False
 for face in obj.data.polygons:
  poly=[obj.matrix_world@obj.data.vertices[i].co for i in face.vertices]
  for axis,edge,sign in [(1,ymin,1),(1,ymax,-1),(2,zmin,1),(2,zmax,-1)]:
   if poly:poly=clip(poly,axis,edge,sign)
  if poly:nearest=min(nearest,min(p.x for p in poly));found=True
 if found:parts.append(obj.name)
assert nearest<float('inf') and nearest-xmax>0,(nearest,xmax)
assert hashlib.sha256(asset.read_bytes()).hexdigest()==before
(out/'neighbor_gap.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Conservative source-space X-axis separation over the cornice Y/Z slab, against actual clipped neighboring triangles. Native geometry only; not played alley access or runtime contact proof.','source_sha256':before,'cornice_max_x':xmax,'neighbor_min_x_in_slab':nearest,'clearance_m':nearest-xmax,'slab_yz':[ymin,ymax,zmin,zmax],'neighbor_parts':parts},indent=2)+'\n')
print('Native conservative cornice/neighbor clearance',nearest-xmax,'m')
