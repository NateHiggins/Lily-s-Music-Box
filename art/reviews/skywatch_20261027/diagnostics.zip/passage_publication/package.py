from pathlib import Path
import json,hashlib,zipfile,gzip,subprocess
root=Path.cwd();out=Path('C:/ov/reports/passage_publication_20261028');dest=root/'art/reviews/skywatch_20261027';archive=dest/'diagnostics.zip';prefix='passage_publication/'
m=json.loads((dest/'manifest.json').read_text(encoding='utf-8'));assert hashlib.sha256(archive.read_bytes()).hexdigest()==m['archive_sha256']
# Verify every backed-up canonical byte against the immutable integration base.
backup=out/'published_backup/previous_surface_packet';review=json.loads((backup/'visual_review.json').read_text(encoding='utf-8'));names=['runtime_contract.json','surface-inventory.json','suite_run.receipt.json','suite_run.stdout.log.gz','suite_run.stderr.log.gz','visual_review.json']+[v['file'] for v in review['images']]
verified={}
for name in names:
 p=backup/(name+'.gz' if name=='surface-inventory.json' else name);raw=gzip.decompress(p.read_bytes()) if name=='surface-inventory.json' else p.read_bytes();old=subprocess.check_output(['git','show','2ec518f2:art/renders/orison_v2/surface_requirements_20261011/'+name]);assert old==raw,name;verified[name]=hashlib.sha256(raw).hexdigest()
(out/'previous_packet_recovery.json').write_text(json.dumps({'commit':'2ec518f28aefe2c436f4426749e76eea2092dd93','byte_verified':verified},indent=2)+'\n')
files=[p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.ps1','.json','.log','.stderr','.gd'}]
files += [out/'main_baseline/board.json']
for folder in ['before','cleanup_attribution','after','after_physics','residency']:
 files += sorted((out/folder).glob('*.json'))
files += [out/'surface_final/runtime_contract.json']
files += [out/'after_physics/cloud_1_on_street.png',out/'residency/nave.png',out/'residency/last_position.png']
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
 assert not any(v.startswith(prefix) for v in z.namelist())
 for p in files:z.write(p,prefix+p.relative_to(out).as_posix())
m['passage_publication']={'evidence_class':'INERT','base':'2ec518f2','scope':'Per-cell hidden registration; measured publication-hitch reduction, not general FPS or whole-V2 acceptance.','raw_prefix':prefix,'comparison':json.loads((out/'comparison.json').read_text()),'residency':json.loads((out/'residency_summary.json').read_text()),'surface':{'checks':39207,'contracts':json.loads((out/'surface_final/runtime_contract.json').read_text())['contracts'],'wrapper_seconds':779,'stderr_empty':True,'captures':237,'individually_reviewed':7},'previous_packet':json.loads((out/'previous_packet_recovery.json').read_text()),'limits':['Historical short streaming diagnostic still fails its unchanged ten-second deadline.','Ordinary p95 about65 ms, cold/other101 ms spike and atomic fitting peaks about39 ms remain.','Deferred engine costs not fully attributed.','No save reconstruction, repeated unchanged hose controls, human artistic or full-year weather acceptance.','Candidate verification pending.']}
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()));m['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
m['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest();(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archived',len(files),'files; previous packet',len(verified),'exact bytes verified; archive',archive.stat().st_size)
