import json, pathlib, numpy as np
root=pathlib.Path(__file__).parent
for name in ('before','cleanup_attribution','after','after_physics'):
 p=root/name/'cloud_world_frames.json'
 if not p.exists(): continue
 d=json.loads(p.read_text(encoding='utf-8')); rows=d['samples']; r=d['passage_residency']
 print(name,'failures',d['failures'],'frames',len(rows),'wall percentiles',np.percentile([s[1] for s in rows],[50,95,99,100]).round(3).tolist(),'frames>100',sum(s[1]>100 for s in rows))
 print('activation',r.get('activation_records'))
 print('publication stages',len(r.get('publication_records',[])), 'max cell attachment',max((v['attach_ms'] for v in r.get('publication_records',[])),default=0))
 print('completion frames',[(e['sample_index'],rows[e['sample_index']][1]) for e in d['publication_events']])
 jumps=[]
 for i in range(1,len(rows)):
  key='OBJECT_NODE_COUNT'; delta=rows[i][7].get(key,0)-rows[i-1][7].get(key,0)
  if delta>100: jumps.append((i,round(rows[i][1],3),delta,rows[i][6]))
 print('largest node increases',sorted(jumps,key=lambda v:v[2],reverse=True)[:14])
