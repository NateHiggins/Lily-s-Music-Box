from pathlib import Path
import json
out=Path(__file__).parent;d=json.loads((out/'before/cloud_world_frames.json').read_text());r=d['passage_residency'];rows=d['samples'];events=[]
for event in d['publication_events']:
 i=event['sample_index'];events.append({**event,'nearby_frames':[s[:7] for s in rows[max(0,i-2):i+3]]})
summary={'evidence_class':'INERT','scope':'Measured existing publication/fitting peaks and adjacent sampled frames; no optimization or function attribution beyond those measured scopes.','failures':d['failures'],'frames':len(rows),'peak_activation_ms':r['peak_activation_ms'],'peak_stage_ms':r['peak_stage_ms'],'load_cycles':r['load_cycles'],'events':events,'slow_fits':sorted(r['fit_records'],key=lambda x:x['ms'],reverse=True)[:12],'slow_cells':sorted(r['stage_records'],key=lambda x:x['instantiate_ms']+x['fetch_ms'],reverse=True)[:8]}
(out/'before_attribution.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
