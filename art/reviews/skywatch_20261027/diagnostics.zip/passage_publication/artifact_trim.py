from pathlib import Path
import json,zipfile,hashlib,shutil,os
root=Path.cwd();out=Path('C:/ov/reports/passage_publication_20261028');dest=root/'art/reviews/skywatch_20261027';archive=dest/'diagnostics.zip';m=json.loads((dest/'manifest.json').read_text(encoding='utf-8'));assert hashlib.sha256(archive.read_bytes()).hexdigest()==m['archive_sha256']
shutil.copyfile(archive,out/'pre_trim_diagnostics.zip')
remove={'passage_publication/after_physics/cloud_1_on_street.png','passage_publication/residency/nave.png','passage_publication/residency/last_position.png'};recovery=[];target=out/'trimmed_diagnostics.zip'
with zipfile.ZipFile(archive) as old,zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as new:
 for info in old.infolist():
  raw=old.read(info.filename);assert hashlib.sha256(raw).hexdigest()==m['members'][info.filename]
  if info.filename in remove:
   recovery.append({'member':info.filename,'sha256':hashlib.sha256(raw).hexdigest(),'commit':'e5f44f82491e2f19cfce7a1b95b2ef63c83b8481','archive':'art/reviews/skywatch_20261027/diagnostics.zip'})
  else:new.writestr(info,raw,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
 for p in [out/'candidate/verification.json',out/'candidate/verification.md',out/'artifact_trim.py']:new.write(p,'passage_publication/'+p.relative_to(out).as_posix())
assert len(recovery)==3
with zipfile.ZipFile(target) as z:
 assert len(z.namelist())==len(set(z.namelist()));members={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
 for n,h in m['members'].items():
  if n not in remove:assert members[n]==h
assert target.stat().st_size<50*1024*1024
old_size=archive.stat().st_size;os.replace(target,archive);m['members']=members;m['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest();p=m['passage_publication'];p['render_recovery']=recovery;p['packaging']={'old_bytes':old_size,'new_bytes':archive.stat().st_size,'policy':'Only three new diagnostic stills move to exact immutable Git recovery. All source, samples, failures and logs remain in this archive; seven current reviewed qualification images remain in the canonical packet.'};p['candidate_verification']={'candidate':'e5f44f82491e2f19cfce7a1b95b2ef63c83b8481','gates':114,'regressions':0,'protected_unchanged':17,'selector':'v2','requirements_changed':[],'mode':'in-place --no-godot; separately executed source-bound Godot receipts','packaging_followup':'not yet verified'}
p['limits']=[v for v in p['limits'] if v!='Candidate verification pending.'];(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
p=root/'design/V2_COOPERATIVE_NATIVE_FITTING_2026-10-23.md';t=p.read_text(encoding='utf-8').replace('completion is granted. Candidate verification is the remaining integration step.','''completion is granted. Frozen candidate **e5f44f82** passed the **114-gate**
comparison with **zero regressions**, all **17 protected paths unchanged**, selector
**V2**, no lint errors and no changed requirement statuses. This is in-place
verification using the separate executed Godot receipts, not fresh-checkout
import/autocrlf qualification. Existing unrelated red gates remain red.

GitHub's archive-size warning prompted a packaging-only follow-up: recompress
retained payloads and keep three new diagnostic stills recoverable by exact
commit/member/hash at pushed **e5f44f82**. All samples, sources, original failures
and logs remain in the current archive; the seven reviewed qualification images
remain in the canonical packet. No runtime or test code changes in this follow-up.
Its frozen candidate comparison remains required before integration.''');p.write_text(t,encoding='utf-8',newline='\n')
print('Current archive',old_size,'->',archive.stat().st_size,'bytes; exact recovery for',len(recovery),'stills; every retained member byte-verified')
