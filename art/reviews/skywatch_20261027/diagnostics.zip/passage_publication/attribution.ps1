$ErrorActionPreference='Stop'
$env:GIT_OPTIONAL_LOCKS='0'
$nativeArgs=@('--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440')
& ./tools/lane.ps1 run -Scene res://tests/OrisonV2PassageStreamingProfileTest.tscn -Runner long -TimeoutSeconds 500 -Windowed -ShotDir C:/ov/reports/passage_publication_20261028/attribution -LogPath C:/ov/reports/passage_publication_20261028/attribution.log -ExtraArgs $nativeArgs -WaitMinutes 15
exit $LASTEXITCODE
