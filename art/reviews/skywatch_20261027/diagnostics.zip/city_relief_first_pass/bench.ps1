$ErrorActionPreference='Stop'
Set-Location -LiteralPath C:/PleaseRemainOnTheLine
$runs=@(
    @{scene='';runner='serial';timeout=175;windowed=$false;shot_dir='';log='C:/ov/reports/city_relief_20261028/import_corrected.log';extra_args=@('--editor','--import','--quit')},
    @{scene='res://tests/V2CityHorizonBench.tscn';runner='serial';timeout=175;windowed=$true;shot_dir='C:/ov/reports/city_relief_20261028/bench';log='C:/ov/reports/city_relief_20261028/bench.log';extra_args=@('--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440')}
)
$runs | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath C:/ov/reports/city_relief_20261028/bench.json -Encoding utf8
& ./tools/lane.ps1 batch -BatchFile C:/ov/reports/city_relief_20261028/bench.json -WaitMinutes 15
exit $LASTEXITCODE
