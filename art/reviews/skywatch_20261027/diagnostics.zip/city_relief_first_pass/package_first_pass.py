from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd(); here=Path(__file__).parent
dest=root/'art/reviews/skywatch_20261027'; archive=dest/'diagnostics.zip'; prefix='city_relief_first_pass/'
files=['bench.ps1','bench.json','qualification.ps1','qualification.json','defer_surface.ps1','surface_deferred_processes.json',
 'bench_final.log','bench_final.log.stderr','bench_final.log.receipt.json','route.log','route.log.stderr','route.log.receipt.json',
 'route/cloud_world_frames.json','route_comparison.json','surface.log','surface.log.stderr','surface.log.receipt.json',
 'import.log','import.log.stderr','import.log.receipt.json','malformed_import_cancel.json','import_corrected.log','import_corrected.log.stderr','import_corrected.log.receipt.json',
 'clean_import.py','import_cleanup.json','generated_import_churn.zip','orphan_index_lock.json','orphan_index.lock.bin',
 'native/build.log','native/build_optimized.log','native/build_coarse.log','native/build_final.log','native/review_final.log','native/final/review.json','native/final/relief_context.png','main_baseline/board.json','main_baseline/board.md']
files=[x for x in files if (here/x).is_file()]
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
 assert not any(n.startswith(prefix) for n in z.namelist())
 for name in files:z.write(here/name,prefix+name)
 z.write(Path(__file__),prefix+'package_first_pass.py')
m=json.loads((dest/'manifest.json').read_text())
m['city_relief_first_pass']={'evidence_class':'INERT','scope':'WIP terrain construction, native and installed bench plus occupied diagnostic. No full surface qualification or city acceptance; queued surface was cancelled for the owner-requested individual-building revision.',
 'parent_main':'04d72f3a47c233d0bc7ec786df5f33358f53577c','geometry':{'triangles':2692,'draws':14,'footprint_m':1000},
 'bench':'12510 checks / 0 failures; wrapper only, not runtime_contract', 'route':json.loads((here/'route_comparison.json').read_text()),
 'native_review':{f.name:{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'external_path':str(f),'inspected':True} for f in (here/'native/final').glob('*.png')},
 'occupied_view':{'file':'route/cloud_0_off_street.png','sha256':hashlib.sha256((here/'route/cloud_0_off_street.png').read_bytes()).hexdigest(),'inspected':True,'scope':'near-street presentation, not optical qualification of distant banks'},
 'limitations':['Native previews omit the retained centre/near-city assemblies.','Flat generic buildings need individual precedent-based refinement.','No full surface/runtime contract, quays, tracks, elevated station or bridge completion.','Original water-side orientation failure exists in tool transcript; no fabricated log.']}
with zipfile.ZipFile(archive) as z:m['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
m['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archived WIP terrain diagnostics, including retained cancellations:',archive.stat().st_size)
