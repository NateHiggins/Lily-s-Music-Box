$ErrorActionPreference='Stop'
$deadline=(Get-Date).AddMinutes(5)
while ((Get-Date) -lt $deadline) {
    $owner=Get-CimInstance Win32_Process -Filter 'ProcessId=26976'
    if ($null -eq $owner -or $owner.CommandLine -notmatch 'city_relief_20261028/qualification.ps1') { throw 'Qualification owner is no longer live' }
    $game=Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'godot.windows.editor.x86_64.llvm.exe' -and $_.CommandLine -match 'OrisonV2SurfaceInventory.tscn' }
    if ($null -ne $game) {
        $console=Get-CimInstance Win32_Process -Filter "ProcessId=$($game.ParentProcessId)"
        if ($console.ParentProcessId -ne 26976 -or $console.CommandLine -notmatch 'OrisonV2SurfaceInventory.tscn') { throw 'Surface run is not this task-owned child' }
        @($owner,$console,$game) | Select-Object ProcessId,ParentProcessId,CreationDate,CommandLine | ConvertTo-Json | Set-Content C:/ov/reports/city_relief_20261028/surface_deferred_processes.json
        if (-not (Test-Path -LiteralPath C:/ov/reports/city_relief_20261028/route.log.receipt.json)) { throw 'Route receipt not written' }
        Stop-Process -Id $game.ProcessId -Force
        Write-Output 'Deferred task-owned surface survey after route completion for owner-requested unique-building revision; original cancellation receipt retained.'
        exit 0
    }
    Start-Sleep -Milliseconds 350
}
throw 'No owned surface process observed before deadline'
