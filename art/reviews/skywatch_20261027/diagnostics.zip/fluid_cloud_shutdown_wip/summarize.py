from pathlib import Path
from PIL import Image,ImageDraw
import json,numpy as np
out=Path('C:/ov/reports/skywatch36')
before=json.loads((out/'cloud_before_diurnal/cloud_review.json').read_text())
after=json.loads((out/'final_V2SkySpectacleBench/cloud_review.json').read_text())
comparison=[]
sheet=Image.new('RGB',(1280,1500),'#18181b');draw=ImageDraw.Draw(sheet)
for i,(a,b) in enumerate(zip(before['rows'],after['rows'])):
 assert a['date']==b['date'] and a['state']==b['state']
 comparison.append({'genus':a['genus'],'date':a['date'],'before':{k:a['timing'][k] for k in ['p50','p95','p99','max']},'after':{k:b['timing'][k] for k in ['p50','p95','p99','max']}})
 for col,folder in enumerate(['cloud_before_diurnal','final_V2SkySpectacleBench']):
  image=Image.open(out/folder/(a['genus']+'_noon.png')).convert('RGB');image.thumbnail((640,268))
  x=col*640;y=i*300;sheet.paste(image,(x,y+30));draw.text((x+5,y+5),a['genus']+' '+a['date']+' '+('before' if col==0 else 'after'),fill='white')
sheet.save(out/'fluid_cloud_contact.jpg',quality=91)
(out/'distribution_comparison.json').write_text(json.dumps(comparison,indent=2))
print(json.dumps(comparison,indent=2))
for name in ['cloud_return_scoped','cloud_gap_fixed']:
 p=out/name
 a=np.asarray(Image.open(p/'Cu_return_start.png').convert('RGB').resize((160,90),Image.Resampling.LANCZOS),dtype=float)
 b=np.asarray(Image.open(p/'Cu_returned.png').convert('RGB').resize((160,90),Image.Resampling.LANCZOS),dtype=float)
 print(name,'return_mean_error',float(np.abs(a-b).mean()/255))
