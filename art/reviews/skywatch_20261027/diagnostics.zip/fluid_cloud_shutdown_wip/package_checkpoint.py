from pathlib import Path
import json,hashlib,zipfile,shutil
root=Path.cwd();out=Path('C:/ov/reports/skywatch36');folder=root/'art/reviews/skywatch_20261027'
archive=folder/'diagnostics.zip';prefix='fluid_cloud_shutdown_wip/'
manifest=json.loads((folder/'manifest.json').read_text())
paths=['game/scripts/building/WeatherManager.gd','game/scripts/building/living_sky.gd','game/scripts/building/weather_noise.gd','game/shaders/queens_weather_math.gdshaderinc','game/shaders/queens_weather_sky.gdshader','game/tests/skywatch_optical_review.gd','game/tests/v2_weather_route_profile.gd','game/export_presets.cfg','tools/build_weather_noise.py']
scope={'scope':'WIP flow optical diagnostics; occupied run interrupted for owner shutdown; no production or annual acceptance','source_lf_sha256':{},'stock_sha256':{},'captures':{}}
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
 assert not any(n.startswith(prefix) for n in z.namelist())
 for name in paths:
  b=(root/name).read_bytes();scope['source_lf_sha256'][name]=hashlib.sha256(b.replace(b'\r\n',b'\n')).hexdigest();z.writestr(prefix+'checkpoint_source/'+name,b)
 for f in sorted(out.iterdir()):
  if f.is_file() and ('.log' in f.name or f.suffix in ['.json','.py']):z.write(f,prefix+f.name)
  elif f.is_dir():
   for child in sorted(f.iterdir()):
    if child.is_file() and (child.suffix=='.json' or f.name=='cloud_before_sources'):z.write(child,prefix+f.name+'/'+child.name)
 for f in (out/'final_V2SkySpectacleBench').glob('*.png'):scope['captures'][str(f)]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size}
for name in ['perlin_worley_128.r8','cloud_curl_32.rgb8']:
 path=root/'game/assets/environment/weather'/name;scope['stock_sha256'][str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest()
shutil.copyfile(out/'fluid_cloud_contact.jpg',folder/'fluid_cloud_contact.jpg')
scope['contact_sha256']=hashlib.sha256((folder/'fluid_cloud_contact.jpg').read_bytes()).hexdigest();manifest['fluid_cloud_shutdown_wip']=scope
with zipfile.ZipFile(archive) as z:manifest['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
manifest['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
(folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Preserved archive bytes',archive.stat().st_size)
