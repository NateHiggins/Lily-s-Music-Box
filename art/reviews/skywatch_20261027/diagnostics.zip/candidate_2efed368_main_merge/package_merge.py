from pathlib import Path
import json,hashlib,zipfile,subprocess
r=Path.cwd();p=Path(__file__).parent;dest=r/'art/reviews/skywatch_20261027';archive=dest/'diagnostics.zip';prefix='candidate_2efed368_main_merge/'
d=json.loads((p/'candidate/verification.json').read_text())
assert not d['blocking'] and not d['accepted_regressions']['lines']
assert d['last_line']=='MERGE-CANDIDATE 2efed36838ed5521238f970839a5b33f050e24a4'
merge=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
assert merge=='7dc4ca40530cdf77a2208a3d8a48fdbe6891be7f'
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'])==subprocess.check_output(['git','rev-parse','2efed368^{tree}'])
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
 assert not any(n.startswith(prefix) for n in z.namelist())
 for f in (p/'candidate').rglob('*'):
  if f.is_file():z.write(f,prefix+'candidate/'+f.relative_to(p/'candidate').as_posix())
 for name in ['orphan_index_lock.json','orphan_index_lock.bin']:
  z.write(p/name,prefix+name)
 z.write(Path(__file__),prefix+'package_merge.py')
m=json.loads((dest/'manifest.json').read_text())
m['candidate_2efed368_main_merge']={'evidence_class':'INERT','tested_candidate':d['candidate'],'merge_commit':merge,'merged_tree_identical_to_tested_candidate':True,'regressions':0,'waivers':0,'protected_unchanged':17,'scope':'Clean canonical in-place complete gate comparison; no Godot invocation by verifier. Separately executed final-source native receipts bind on main. No fresh checkout, whole-V2 or human acceptance.'}
with zipfile.ZipFile(archive) as z:m['members']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
m['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest();(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Candidate verification and merge provenance archived; bytes',archive.stat().st_size)
