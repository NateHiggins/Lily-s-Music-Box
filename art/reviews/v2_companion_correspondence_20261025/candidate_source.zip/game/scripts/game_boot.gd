extends Node
## Autoload "GameBoot": registers input actions in code so the project file
## stays free of hand-serialized InputEvent blobs.

const ACTIONS := {
	"move_forward": KEY_W, "move_back": KEY_S,
	"move_left": KEY_A, "move_right": KEY_D,
	"run": KEY_SHIFT, "crouch": KEY_C, "jump": KEY_SPACE,
	"shot_capture": KEY_F,
	"capture_device_toggle": KEY_H,
	"door_key": KEY_K,
	"lamp_toggle": KEY_L, "radio_toggle": KEY_R,
	"music_player": KEY_M,
	"pause_services": KEY_ESCAPE,
	"noclip": KEY_V, "debug_panel": KEY_F1,
	"intro": KEY_F2,
	"release_mouse": KEY_QUOTELEFT,
	"teletype_read": KEY_E, "teletype_next": KEY_BRACKETRIGHT, "teletype_previous": KEY_BRACKETLEFT,
	"companion_type": KEY_ENTER,
	"teletype_closer": KEY_EQUAL, "teletype_farther": KEY_MINUS, "teletype_service": KEY_Y,
	"inspect_care": KEY_I, "pocket_ledger": KEY_P,
}

## Shoulder switches remain reachable while both thumbs steer and look. They
## feed the same named actions as keyboard and touch; PlayerController never
## branches on input device.
const JOYPAD_ACTIONS := {
	"interact": JOY_BUTTON_A,
	"door_key": JOY_BUTTON_DPAD_UP,
	"jump": JOY_BUTTON_Y,
	"crouch": JOY_BUTTON_LEFT_STICK,
	"lamp_toggle": JOY_BUTTON_LEFT_SHOULDER,
	"radio_toggle": JOY_BUTTON_RIGHT_SHOULDER,
	"teletype_read": JOY_BUTTON_DPAD_DOWN,
	"companion_type": JOY_BUTTON_A,
	"companion_cancel": JOY_BUTTON_B,
	"activity_adjust_left": JOY_BUTTON_DPAD_LEFT,
	"activity_adjust_right": JOY_BUTTON_DPAD_RIGHT,
	"activity_commit": JOY_BUTTON_A,
	"pause_services": JOY_BUTTON_START,
	"inspect_care": JOY_BUTTON_RIGHT_STICK,
	"pocket_ledger": JOY_BUTTON_BACK,
}

const JOYPAD_AXES := {
	"move_left": [JOY_AXIS_LEFT_X, -1.0],
	"move_right": [JOY_AXIS_LEFT_X, 1.0],
	"move_forward": [JOY_AXIS_LEFT_Y, -1.0],
	"move_back": [JOY_AXIS_LEFT_Y, 1.0],
	"look_left": [JOY_AXIS_RIGHT_X, -1.0],
	"look_right": [JOY_AXIS_RIGHT_X, 1.0],
	"look_up": [JOY_AXIS_RIGHT_Y, -1.0],
	"look_down": [JOY_AXIS_RIGHT_Y, 1.0],
	"run": [JOY_AXIS_TRIGGER_LEFT, 1.0],
}

const JOYPAD_EXTRA_BUTTONS := {
	"lamp_toggle": [JOY_BUTTON_X],
	"ui_cancel": [JOY_BUTTON_B],
}

## Maintenance panels consume meanings, never device keycodes. Keep commit
## separate from `interact`: PlayerController polls interact before call_locked
## can protect the newly opened panel, so sharing it can double-fire one press.
const ACTIVITY_KEY_ACTIONS := {
	"activity_adjust_left": [KEY_A, KEY_LEFT],
	"activity_adjust_right": [KEY_D, KEY_RIGHT],
	"activity_commit": [KEY_E, KEY_SPACE],
}

const SETTINGS_PATH := "user://orison_settings.cfg"
const BuildingSelector := preload("res://scripts/building/building_root_selector.gd")
var BUILDING_SCENE: String = BuildingSelector.scene_path()
const GAME_SCENE := "res://scenes/campaign/CampaignShell.tscn"

enum LaunchMode { CINEMATIC, DEBUG }

var launch_mode := LaunchMode.CINEMATIC
var _last_launch_result: Dictionary = {}
# Only the scene operation is replaceable in the button-handler fixture;
# campaign validation, archival, persistence and launch gates remain real.
var _scene_change_for_tests := Callable()
var settings := {
	"quality": 0, # 0 cinematic, 1 balanced
	"fullscreen": false,
	"master_volume": 0.82,
	"gameplay_volume": 1.0,
	"voice_volume": 1.0,
	"world_volume": 1.0,
	"music_volume": 1.0,
	"ui_volume": 1.0,
	"look_sensitivity": 1.0,
	"controller_look_sensitivity": 1.0,
	"controller_invert_y": false,
	"controller_look_deadzone": 0.18,
	"controller_look_curve": 1.65,
	"reduce_camera_roll": false,
	"reduce_flashing": false,
	# Privacy: network weather is a separate, explicit opt-in. When it is off,
	# no request is made. Local weather additionally sends player-authored city
	# or postal text to Open-Meteo; no IP geolocation or device sensor is used.
	"weather_network_enabled": false,
	"live_local_weather": false,
	"weather_location_query": "",
	# Accessibility: later case profiles may allow a sudden sleep attack, but
	# this forces the same legible gradual warning Mina teaches first.
	"always_warn_before_sleep": false,
	# Accessibility: writes each hazard tell on screen as its cue and one of
	# eight sectors relative to the player's facing. Never a distance or a
	# room name -- a caption player must get what the ear gets and no more,
	# or the light decision the dream is built on stops costing anything.
	# Off by default: the mix already carries this, and the dream's grammar
	# is listening.
	"dream_directional_captions": false,
	# Captions semantic gameplay cues with only the source class and relative
	# sector already available to a listener. No distance, room or case owner.
	"gameplay_sound_captions": false,
	# Measured once by the Songbook's clap check and kept for good.
	# _load_settings only reads keys that already exist here, so a
	# setting absent from this dict is a setting that never persists.
	"songbook_latency_ms": 0.0,
}


## Diagnostics must be deliberately requested. Debug engine builds are also
## used for production captures, so OS.is_debug_build() is not a presentation
## boundary and must never make labels leak into evidence or store media.
static func developer_overlays_enabled() -> bool:
	return OS.get_environment("ORISON_DEVELOPER_OVERLAYS") == "1"


func _ready() -> void:
	_load_settings()
	apply_user_settings()
	for action in ACTIONS:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		var key_event := InputEventKey.new()
		key_event.physical_keycode = ACTIONS[action]
		_ensure_action_event(action, key_event)
	for action in JOYPAD_ACTIONS:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		var button_event := InputEventJoypadButton.new()
		button_event.button_index = JOYPAD_ACTIONS[action]
		_ensure_action_event(action, button_event)
	for action in ACTIVITY_KEY_ACTIONS:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for keycode in ACTIVITY_KEY_ACTIONS[action]:
			var key_event := InputEventKey.new()
			key_event.physical_keycode = keycode
			_ensure_action_event(action, key_event)
	for action in JOYPAD_AXES:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		var axis_event := InputEventJoypadMotion.new()
		axis_event.axis = JOYPAD_AXES[action][0]
		axis_event.axis_value = JOYPAD_AXES[action][1]
		_ensure_action_event(action, axis_event)
	for action in JOYPAD_EXTRA_BUTTONS:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for button in JOYPAD_EXTRA_BUTTONS[action]:
			var button_event := InputEventJoypadButton.new()
			button_event.button_index = button
			_ensure_action_event(action, button_event)


func _ensure_action_event(action: StringName, event: InputEvent) -> void:
	if not InputMap.action_has_event(action, event):
		InputMap.action_add_event(action, event)


func begin_game(mode: LaunchMode, new_campaign := false,
		replace_existing := false) -> bool:
	_last_launch_result = {}
	if new_campaign:
		var status := RealityState.load_status()
		# Begin is only a fresh-profile action. The explicit title replacement
		# choice is the sole normal caller that sets replace_existing.
		if (bool(status.get("has_saved_campaign", true))
				or str(status.get("status", "protected")) != "missing") \
				and not replace_existing:
			return _refuse_launch("replacement_choice_required",
					"A saved night is already here. Choose New Campaign to start over.")
		if not RealityState.start_new_campaign():
			var save_result := RealityState.last_save_result()
			_last_launch_result = {
				"ok": false, "code": "new_campaign_failed",
				"message": ("The new night could not be saved. Your save files are protected; recovery is needed before continuing."
						if bool(save_result.get("protection_required", false)) else
						"The new night could not be saved. No campaign has been opened."),
				"save_result": save_result,
			}
			return false
	elif mode == LaunchMode.CINEMATIC and not RealityState.can_continue():
		return _refuse_launch("continue_unavailable",
				"This saved night cannot be continued. Your save has been kept.")
	# Debug never creates a new campaign implicitly. The storage/clock guards
	# still protect unsupported or invalid data; presentation mode is no bypass.
	var clock := CampaignClock.new()
	if not clock.bind_state():
		return _refuse_launch("invalid_calendar",
				"The saved night has an unreadable date. Your save has been kept.")
	var previous_mode := launch_mode
	launch_mode = mode
	apply_render_profile()
	var changed: Error = _scene_change_for_tests.call(GAME_SCENE) \
			if _scene_change_for_tests.is_valid() else get_tree().change_scene_to_file(GAME_SCENE)
	if changed != OK:
		launch_mode = previous_mode
		apply_render_profile()
		return _refuse_launch("scene_change_failed",
				"The night could not open. Your save is available; please try again.")
	_last_launch_result = {"ok": true, "code": "launched"}
	return true


func _refuse_launch(code: String, message: String) -> bool:
	_last_launch_result = {"ok": false, "code": code, "message": message}
	return false


func last_launch_result() -> Dictionary:
	return _last_launch_result.duplicate(true)


func set_scene_change_for_tests(operation: Callable) -> void:
	_scene_change_for_tests = operation


func apply_render_profile() -> void:
	var cinematic := launch_mode == LaunchMode.CINEMATIC \
			and int(settings.get("quality", 0)) == 0
	var atlas_size := 8192 if cinematic else 4096
	ProjectSettings.set_setting(
			"rendering/lights_and_shadows/positional_shadow/atlas_size", atlas_size)
	ProjectSettings.set_setting(
			"rendering/lights_and_shadows/directional_shadow/size", atlas_size)
	ProjectSettings.set_setting(
			"rendering/lights_and_shadows/positional_shadow/soft_shadow_filter_quality",
			3 if cinematic else 2)
	ProjectSettings.set_setting(
			"rendering/lights_and_shadows/directional_shadow/soft_shadow_filter_quality",
			3 if cinematic else 2)
	var viewport := get_tree().root
	viewport.positional_shadow_atlas_size = atlas_size
	RenderingServer.directional_shadow_atlas_set_size(atlas_size, true)


func apply_user_settings() -> void:
	var fullscreen := bool(settings.get("fullscreen", false))
	DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN
			if fullscreen else DisplayServer.WINDOW_MODE_WINDOWED)
	apply_audio_settings()


func apply_audio_settings(reapply_policy := true) -> void:
	for record in [
		["Master", "master_volume", 0.82],
		["Gameplay", "gameplay_volume", 1.0],
		["Voice", "voice_volume", 1.0],
		["World", "world_volume", 1.0],
		["Music", "music_volume", 1.0],
		["UI", "ui_volume", 1.0],
	]:
		var bus := AudioServer.get_bus_index(str(record[0]))
		if bus >= 0:
			AudioServer.set_bus_volume_db(bus, audio_bus_db(str(record[0])))
	if reapply_policy:
		var policy := get_node_or_null("/root/AudioPolicy")
		if policy != null and policy.has_method("reapply_mix"):
			policy.call("reapply_mix")


func audio_bus_db(bus_name: String) -> float:
	var keys := {
		"Master":"master_volume", "Gameplay":"gameplay_volume",
		"Voice":"voice_volume", "World":"world_volume",
		"Music":"music_volume", "UI":"ui_volume",
	}
	var defaults := {"Master":0.82, "Gameplay":1.0, "Voice":1.0,
		"World":1.0, "Music":1.0, "UI":1.0}
	if not keys.has(bus_name):
		return 0.0
	return linear_to_db(maxf(0.001, float(settings.get(
			keys[bus_name], defaults[bus_name]))))


func save_settings() -> void:
	var config := ConfigFile.new()
	for key in settings:
		config.set_value("display", key, settings[key])
	config.save(SETTINGS_PATH)
	apply_user_settings()


func _load_settings() -> void:
	var config := ConfigFile.new()
	if config.load(SETTINGS_PATH) != OK:
		return
	for key in settings:
		settings[key] = config.get_value("display", key, settings[key])


## Blender (Z-up, Y-north) -> Godot (Y-up, -Z north) via the glTF convention.
static func b2g(p: Array) -> Vector3:
	return Vector3(p[0], p[2], -p[1])
