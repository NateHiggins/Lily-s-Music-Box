extends "res://tests/v2_hose_idle_visual_profile.gd"
## INERT: actual installed union input before the inherited extraction route.
## Initial placement and later repaired-line staging remain explicit diagnostics.
func _idle_controls() -> void:
	var native: RefCounted=world.adapter.root.get_meta("v2_native_fire_service")
	var actor: Node3D=native.stations.F02_FIRE_LINE_STAIR.get_ref()
	var saved: Dictionary=actor.mechanism_snapshot()
	var hands: Node3D=preload("res://tests/v2_fire_hand_bench.gd").new()
	hands.set_meta("shared_world_validation",true);hands.player=player;add_child(hands)
	var hand: Node=preload("res://tests/fixed_gesture_patrol_hand.gd").new()
	hand.player=player;add_child(hand)
	var result: Dictionary={"evidence_class":"INERT","scope":"Actual installed F02 union grab/motion/release. Original initial mechanism restored afterward; inherited extraction route still stages the remaining assembled line.","before":saved}
	profile_phase="installed_union_open"
	var ok: bool=_check(await hand.operate(actor._door_pivot.to_global(Vector3(-.4,.1,.015)),1.78,actor),"actual installed cover opens before union maintenance")
	if ok:
		await hands.aim(actor._tag.to_global(Vector3(0,0,.0035)));hands.click();hands.key(KEY_SPACE)
		ok=_check(player.inspecting() and player.inspect_owner==actor,"actual installed tag grip enters supported maintenance inspection")
	if ok:
		profile_phase="installed_union_partial_unscrew"
		ok=_check(await hands.inspect_operate(hand,actor._joint_nut,actor._coupling.to_global(Vector3(0,-.012,.032)),.9),"actual installed union accepts a partial screw stroke")
		_check(not actor.coupling_made_up and not actor.gasket_seen,"partial unscrewing neither repairs nor counterfeits gasket inspection")
		result.partial=actor.mechanism_snapshot()
	if ok:
		profile_phase="installed_union_full_unscrew"
		ok=_check(await hands.inspect_operate(hand,actor._joint_nut,actor._coupling.to_global(Vector3(0,-.012,.032)),actor._maximum("joint")),"actual installed union follows the full retained screw travel")
	if ok:
		profile_phase="installed_union_yz_carry"
		var goal: Vector3=actor._loose_union.receiving()+Vector3(0,-.015,.015)
		ok=_check(await hands.carry_union(actor,goal),"actual mouse and depth input move the installed loose hose end on Y and Z")
		result.loose=actor.mechanism_snapshot()
		_check(not actor.coupling_made_up and not actor.gasket_seated and actor.valid_mechanism(result.loose),"loose installed union preserves maintenance faults and a valid saved pose")
	if ok:
		profile_phase="installed_union_return"
		ok=_check(await hands.carry_union(actor,actor._loose_union.receiving()),"actual installed loose hose end returns to its receiving thread")
	if ok:
		profile_phase="installed_union_retighten"
		ok=_check(await hands.inspect_operate(hand,actor._joint_nut,actor._coupling.to_global(Vector3(0,-.012,.032)),actor._minimum("joint")),"actual installed union retightens through mouse motion")
		_check(actor.coupling_made_up and not actor.line_made_up() and not actor.gasket_seated,"an empty tightened union retains the original gasket fault")
	if ok and OS.get_environment("V2_INSTALLED_GASKET_REVIEW")=="1":
		player.cancel_manipulation()
		if player.inspecting():hands.key(KEY_ESCAPE)
		profile_phase="installed_gasket_programme"
		await hands.exercise_gasket(actor,hand)
		result.gasket_checks=hands.observations.duplicate(true)
		result.gasket_failures=hands.failures.duplicate()
		ok=_check(hands.failures.is_empty() and actor.gasket_seated and actor.gasket_seen and actor.coupling_made_up,"installed physical washer programme retains actual fitting, inspection and original save checks")
	result.after=actor.mechanism_snapshot();result.completed=ok
	profile_phase="capture_excluded_union_review"
	await _picture("installed_union_review")
	player.cancel_manipulation()
	if player.inspecting():hands.key(KEY_ESCAPE)
	actor.restore_mechanism(saved)
	_check(actor.valid_mechanism(actor.mechanism_snapshot()),"original installed diagnostic precondition restores after union review")
	FileAccess.open(OS.get_environment("SHOT_DIR").path_join("installed_union.json"),FileAccess.WRITE).store_string(JSON.stringify(result,"\t"))
	hands.free();hand.free()
