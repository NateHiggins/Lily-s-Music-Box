extends RefCounted
const FitJob := preload("res://scripts/building/orison_v2_native_fit_job.gd")


# Residency prepares only wrappers whose preflight accepts a mounted result.
# Exact handoff matching in mount_records prevents recipe drift.
static func begin_streamed_fitting(kind: String, cell: Node3D, layout: Dictionary) -> RefCounted:
	match kind:
		"arcade_canopy":return begin_records(cell,layout,"res://data/orison_v2/arcade_canopy.json","ArcadeCanopy","F01_retail_arcade_","arcade_canopy_part")
		"arcade_throat":return begin_records(cell,layout,"res://data/orison_v2/arcade_throat.json","ArcadeThroat","F01_retail_arcade_","arcade_throat_part")
		"hardware_drawers":return begin_records(cell,layout,"res://data/orison_v2/hardware_drawers.json","HardwareDrawers","F01_retail_hardware_drawers_","hardware_drawer_part")
		"hardware_stock":return begin_records(cell,layout,"res://data/orison_v2/hardware_stock.json","HardwareStock","F01_retail_hardware_stock_","hardware_stock_part")
		"druggist_drawers":return begin_records(cell,layout,"res://data/orison_v2/druggist_drawers.json","DruggistDrawers","F01_retail_druggist_drawers_","druggist_drawer_part")
	return null

static func mount_arcade_canopy(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/arcade_canopy.json","ArcadeCanopy","F01_retail_arcade_","arcade_canopy_part")

static func mount_arcade_throat(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/arcade_throat.json","ArcadeThroat","F01_retail_arcade_","arcade_throat_part")

static func mount_arcade_lantern(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/arcade_lantern.json","ArcadeLantern","F01_retail_arcade_","arcade_lantern_part")

static func mount_arcade_clock(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/arcade_clock.json","ArcadeClock","F01_retail_arcade_clock_","arcade_clock_part")
## Native furniture replaces only identified source box boundaries. The
## imported shop, its other triangles and its physical actors remain owners.
static func mount_cell(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/shop_seating.json","ShopSeating","F01_retail_seating_","seating_part")

static func mount_laundry(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/laundry_fittings.json","LaundryFittings","F01_retail_laundry_","laundry_part")

static func mount_laundry_apparatus(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/laundry_apparatus.json","LaundryApparatus","F01_retail_laundry_apparatus_","laundry_apparatus_part")

static func mount_shop_clerestories(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/shop_clerestories.json","ShopClerestories","F01_retail_clerestories_","shop_clerestories_part")

static func mount_shop_joinery(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/shop_joinery.json","ShopJoinery","F01_retail_shop_joinery_","shop_joinery_part")

static func mount_photo_radio_fittings(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/photo_radio_fittings.json","PhotoRadioFittings","F01_retail_photo_radio_fittings_","photo_radio_fittings_part")

static func mount_laundry_trade(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/laundry_trade.json","LaundryTrade","F01_retail_laundry_trade_","laundry_trade_part")

static func mount_locksmith(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/locksmith_fittings.json","LocksmithFittings","F01_retail_locksmith_","locksmith_part")

static func mount_cobbler(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/cobbler_fittings.json","CobblerFittings","F01_retail_cobbler_","cobbler_part")

static func mount_news(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/news_fittings.json","NewsFittings","F01_retail_news_","news_part")

static func mount_hardware_drawers(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/hardware_drawers.json","HardwareDrawers","F01_retail_hardware_drawers_","hardware_drawer_part")

static func mount_hardware_apparatus(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/hardware_apparatus.json","HardwareApparatus","F01_retail_hardware_apparatus_","hardware_apparatus_part")

static func mount_hardware_stock(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/hardware_stock.json","HardwareStock","F01_retail_hardware_stock_","hardware_stock_part")

static func mount_hardware_tools(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/hardware_tools.json","HardwareTools","F01_retail_hardware_tools_","hardware_tools_part")

static func mount_photo_cameras(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/photo_cameras.json","PhotoCameras","F01_retail_photo_cameras_","photo_cameras_part")

static func mount_diner_counter(cell: Node3D, layout: Dictionary, borrowed_materials: Dictionary = {}) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/diner_counter.json","DinerCounter","F01_retail_diner_counter_","diner_counter_part","",borrowed_materials)
static func mount_diner_till(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/diner_till.json","DinerTill","F01_retail_diner_till_","diner_till_part")
static func mount_diner_backbar(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/diner_backbar.json","DinerBackbar","F01_retail_diner_backbar_","diner_backbar_part")
static func mount_diner_urns(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/diner_urns.json","DinerUrns","F01_retail_diner_urns_","diner_urns_part")
static func mount_diner_apparatus(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/diner_apparatus.json","DinerApparatus","F01_retail_diner_apparatus_","diner_apparatus_part")
static func mount_diner_overhead(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/diner_overhead.json","DinerOverhead","F01_retail_diner_overhead_","diner_overhead_part")
static func mount_pawn_fittings(cell: Node3D, layout: Dictionary, borrowed_materials: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/pawn_fittings.json","PawnFittings","F01_retail_pawn_fittings_","pawn_fittings_part","",borrowed_materials)

static func mount_pawn_display(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/pawn_display.json","PawnDisplay","F01_retail_pawn_display_","pawn_display_part")

static func mount_pawn_clocks(cell: Node3D, layout: Dictionary, borrowed_materials: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/pawn_clocks.json","PawnClocks","F01_retail_pawn_clocks_","pawn_clocks_part","",borrowed_materials)

static func mount_photo_counter(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/photo_counter.json","PhotoCounter","F01_retail_photo_counter_","photo_counter_part")

static func mount_photo_stock(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/photo_stock.json","PhotoStock","F01_retail_photo_stock_","photo_stock_part")

static func mount_photo_enlargers(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/photo_enlargers.json","PhotoEnlargers","F01_retail_photo_enlargers_","photo_enlargers_part")

static func mount_photo_process(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/photo_process.json","PhotoProcess","F01_retail_photo_process_","photo_process_part")

static func mount_photo_portraits(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/photo_portraits.json","PhotoPortraits","F01_retail_photo_portraits_","photo_portraits_part")

static func mount_photo_glazing(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/photo_glazing.json","PhotoGlazing","F01_retail_photo_glazing_","photo_glazing_part")

static func mount_druggist_drawers(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/druggist_drawers.json","DruggistDrawers","F01_retail_druggist_drawers_","druggist_drawer_part")

static func mount_druggist_counter(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/druggist_counter.json","DruggistCounter","F01_retail_druggist_counter_","druggist_counter_part")

static func mount_druggist_mortar(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/druggist_mortar.json","DruggistMortar","F01_retail_druggist_mortar_","druggist_mortar_part")

static func mount_druggist_dispensary(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/druggist_dispensary.json","DruggistDispensary","F01_retail_druggist_dispensary_","druggist_dispensary_part")

static func mount_druggist_cupboard(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/druggist_cupboard.json","DruggistCupboard","F01_retail_druggist_cupboard_","druggist_cupboard_part")

static func mount_radio_display(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/radio_display.json","RadioDisplay","F01_retail_radio_display_","radio_display_part")

static func mount_radio_wire(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/radio_wire.json","RadioWire","F01_retail_radio_wire_","radio_wire_part")

static func mount_radio_battery(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/radio_battery.json","RadioBattery","F01_retail_radio_battery_","radio_battery_part")

static func mount_radio_stock(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/radio_stock.json","RadioStock","F01_retail_radio_stock_","radio_stock_part")

static func mount_radio_apparatus(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/radio_apparatus.json","RadioApparatus","F01_retail_radio_apparatus_","radio_apparatus_part")

static func mount_radio_bench(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/radio_bench.json","RadioBench","F01_retail_radio_bench_","radio_bench_part")

static func mount_funeral_foliage(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/funeral_foliage.json","FuneralFoliage","F01_retail_funeral_foliage_","funeral_foliage_part")

static func mount_funeral_drapes(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/funeral_drapes.json","FuneralDrapes","F01_retail_funeral_drapes_","funeral_drape_part")

static func mount_funeral(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/funeral_fittings.json","FuneralFittings","F01_retail_funeral_","funeral_part")

static func mount_druggist_fountain(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/druggist_fountain.json","DruggistFountain","F01_retail_druggist_fountain_","druggist_fountain_part")

static func mount_druggist_carboys(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/druggist_carboys.json","DruggistCarboys","F01_retail_druggist_carboys_","druggist_carboys_part")

static func mount_bar_pool(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/bar_pool.json","BarPool","F01_retail_bar_pool_","bar_pool_part","shop_bar")

static func mount_bar_stage(cell: Node3D, layout: Dictionary) -> bool:
	return mount_records(cell,layout,"res://data/orison_v2/bar_stage.json","BarStage","F01_retail_bar_stage_","bar_stage_part","shop_bar")

# Immutable native scenes may be prefetched by the world. Instances duplicate
# selected meshes before assigning materials; no mesh/scene cache survives here.
const FITTING_DATA := [
	"res://data/orison_v2/arcade_canopy.json",
	"res://data/orison_v2/arcade_throat.json",
	"res://data/orison_v2/arcade_lantern.json",
	"res://data/orison_v2/arcade_clock.json",
	"res://data/orison_v2/shop_seating.json",
	"res://data/orison_v2/laundry_fittings.json",
	"res://data/orison_v2/laundry_apparatus.json",
	"res://data/orison_v2/shop_clerestories.json",
	"res://data/orison_v2/shop_joinery.json",
	"res://data/orison_v2/photo_radio_fittings.json",
	"res://data/orison_v2/laundry_trade.json",
	"res://data/orison_v2/locksmith_fittings.json",
	"res://data/orison_v2/cobbler_fittings.json",
	"res://data/orison_v2/news_fittings.json",
	"res://data/orison_v2/hardware_drawers.json",
	"res://data/orison_v2/hardware_apparatus.json",
	"res://data/orison_v2/hardware_stock.json",
	"res://data/orison_v2/hardware_tools.json",
	"res://data/orison_v2/photo_cameras.json",
	"res://data/orison_v2/diner_counter.json",
	"res://data/orison_v2/diner_till.json",
	"res://data/orison_v2/diner_backbar.json",
	"res://data/orison_v2/diner_urns.json",
	"res://data/orison_v2/diner_apparatus.json",
	"res://data/orison_v2/diner_overhead.json",
	"res://data/orison_v2/pawn_fittings.json",
	"res://data/orison_v2/pawn_display.json",
	"res://data/orison_v2/pawn_clocks.json",
	"res://data/orison_v2/photo_counter.json",
	"res://data/orison_v2/photo_stock.json",
	"res://data/orison_v2/photo_enlargers.json",
	"res://data/orison_v2/photo_process.json",
	"res://data/orison_v2/photo_portraits.json",
	"res://data/orison_v2/photo_glazing.json",
	"res://data/orison_v2/druggist_drawers.json",
	"res://data/orison_v2/druggist_counter.json",
	"res://data/orison_v2/druggist_mortar.json",
	"res://data/orison_v2/druggist_dispensary.json",
	"res://data/orison_v2/druggist_cupboard.json",
	"res://data/orison_v2/radio_display.json",
	"res://data/orison_v2/radio_wire.json",
	"res://data/orison_v2/radio_battery.json",
	"res://data/orison_v2/radio_stock.json",
	"res://data/orison_v2/radio_apparatus.json",
	"res://data/orison_v2/radio_bench.json",
	"res://data/orison_v2/funeral_foliage.json",
	"res://data/orison_v2/funeral_drapes.json",
	"res://data/orison_v2/funeral_fittings.json",
	"res://data/orison_v2/druggist_fountain.json",
	"res://data/orison_v2/druggist_carboys.json",
	"res://data/orison_v2/bar_pool.json",
	"res://data/orison_v2/bar_stage.json",
]

static func fitting_assets(cell_ids: Array = []) -> Array[String]:
	var assets: Array[String] = []
	for path: String in FITTING_DATA:
		var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
		if data is not Dictionary or data.get("asset") is not String: return []
		var used := cell_ids.is_empty()
		for record: Dictionary in data.cells:
			if str(record.id) in cell_ids: used=true
		if used and not assets.has(str(data.asset)): assets.append(str(data.asset))
	return assets

static func begin_records(cell: Node3D, layout: Dictionary, data_path: String, model_name: String, draw_prefix: String, part_meta: String, cell_identity: String = "", borrowed_materials: Dictionary = {}) -> RefCounted:
	return FitJob.new(_without_boxes,_copy_native_mesh,cell,layout,data_path,model_name,draw_prefix,part_meta,cell_identity,borrowed_materials)

static func mount_records(cell: Node3D, layout: Dictionary, data_path: String, model_name: String, draw_prefix: String, part_meta: String, cell_identity: String = "", borrowed_materials: Dictionary = {}) -> bool:
	# Residency may prepare this exact request incrementally. Consume its
	# one-use result before the original wrapper performs its optical finishing.
	var prepared: Variant=cell.get_meta("prepared_native_fit") if cell.has_meta("prepared_native_fit") else null
	if prepared!=null:
		cell.remove_meta("prepared_native_fit")
		if prepared is not RefCounted or prepared.get_script()!=FitJob:return false
		return prepared.matches(cell,layout,data_path,model_name,draw_prefix,part_meta,cell_identity,borrowed_materials)
	return begin_records(cell,layout,data_path,model_name,draw_prefix,part_meta,cell_identity,borrowed_materials).finish()


static func _without_boxes(draw: MeshInstance3D, boxes: Array[Dictionary], tolerance: float, counts: Dictionary, require_boundary := true) -> ArrayMesh:
	var result:=ArrayMesh.new()
	# These transforms and source bounds are invariant for the entire mesh.
	# Avoid inverting the same basis for every triangle corner on each reload.
	var normal_basis := draw.basis.inverse().transposed()
	var lows: Array[Vector3] = []
	var highs: Array[Vector3] = []
	for box: Dictionary in boxes:
		lows.append(_v(box.low)); highs.append(_v(box.high))
	# A source triangle contained by a replacement box has its centroid in
	# that box. Index candidate boxes by metre cell, preserving source order.
	# The exact original containment/boundary predicates still decide removal.
	var candidates := {}
	var indexed := boxes.size()>8
	var bucket_count := 0
	if indexed:
		for i in boxes.size():
			var low := Vector3i((lows[i]-Vector3.ONE*(tolerance+.00001)).floor())
			var high := Vector3i((highs[i]+Vector3.ONE*(tolerance+.00001)).floor())
			bucket_count += (high.x-low.x+1)*(high.y-low.y+1)*(high.z-low.z+1)
			if bucket_count>100000:
				indexed=false; candidates.clear(); break
			for x in range(low.x,high.x+1):
				for y in range(low.y,high.y+1):
					for z in range(low.z,high.z+1):
						var key := Vector3i(x,y,z)
						if not candidates.has(key): candidates[key]=[]
						candidates[key].append(i)
	var source_surfaces: Array=draw.mesh.get("_surfaces")
	var selected_surfaces: Array=[]
	for surface in draw.mesh.get_surface_count():
		var arrays:=draw.mesh.surface_get_arrays(surface)
		var vertices: PackedVector3Array=arrays[Mesh.ARRAY_VERTEX]
		var normals: PackedVector3Array=arrays[Mesh.ARRAY_NORMAL]
		if normals.size()!=vertices.size():return null
		var indices: PackedInt32Array=arrays[Mesh.ARRAY_INDEX]
		if indices.is_empty():
			for index in vertices.size():indices.append(index)
		var retained:=PackedInt32Array()
		for start in range(0,indices.size(),3):
			var p: Array[Vector3]=[];var n:=Vector3.ZERO
			for offset in 3:
				var index:=indices[start+offset];p.append(draw.transform*vertices[index]);n+=normal_basis*normals[index]
			if n.length_squared()<.5:return null
			n=n.normalized();var match_id:=""
			var triangle_low := p[0].min(p[1]).min(p[2])
			var triangle_high := p[0].max(p[1]).max(p[2])
			var selected: Variant = candidates.get(Vector3i(((p[0]+p[1]+p[2])/3.0).floor()),[]) if indexed else range(boxes.size())
			for box_index: int in selected:
				var box: Dictionary = boxes[box_index]
				var low := lows[box_index]; var high := highs[box_index]
				var within := triangle_low.x>=low.x-tolerance and triangle_low.y>=low.y-tolerance and triangle_low.z>=low.z-tolerance and triangle_high.x<=high.x+tolerance and triangle_high.y<=high.y+tolerance and triangle_high.z<=high.z+tolerance
				if not within:continue
				if not require_boundary:
					match_id=str(box.id);break
				var axis:=n.abs().max_axis_index()
				if absf(n[axis])<.999:continue
				var plane:=high[axis] if n[axis]>0. else low[axis]
				var boundary:=true
				for point: Vector3 in p:
					if absf(point[axis]-plane)>tolerance:boundary=false
				if not boundary:continue
				if not match_id.is_empty():return null
				match_id=str(box.id)
			if match_id.is_empty():
				for offset in 3:retained.append(indices[start+offset])
			else:counts[match_id]+=1
		if retained.is_empty():continue
		# Array reconstruction would quantize decoded normal/tangent values
		# again. Copy the serialized buffers and decoding metadata verbatim;
		# replace only their independently encoded triangle index selection.
		var packed: Dictionary=source_surfaces[surface].duplicate(true)
		var width: int=packed.index_data.size()/int(packed.index_count)
		if width!=2 and width!=4:return null
		var bytes:=PackedByteArray();bytes.resize(retained.size()*width)
		for index in retained.size():
			if width==2:bytes.encode_u16(index*width,retained[index])
			else:bytes.encode_u32(index*width,retained[index])
		packed.index_data=bytes;packed.index_count=retained.size()
		# Old generated LOD indices include the replaced boxes. The retained
		# surface therefore keeps its exact full-resolution triangles.
		packed.lods={};selected_surfaces.append(packed)
	if not selected_surfaces.is_empty():result.set("_surfaces",selected_surfaces)
	return result

static func _v(a: Array) -> Vector3:return Vector3(a[0],a[1],a[2])

static func _copy_native_mesh(source: ArrayMesh,surfaces: Array) -> ArrayMesh:
	var native_mesh_copy:=ArrayMesh.new()
	native_mesh_copy.blend_shape_mode=source.blend_shape_mode
	native_mesh_copy.custom_aabb=source.custom_aabb
	native_mesh_copy.lightmap_size_hint=source.lightmap_size_hint
	native_mesh_copy.shadow_mesh=source.shadow_mesh
	native_mesh_copy.resource_name=source.resource_name
	native_mesh_copy.resource_local_to_scene=source.resource_local_to_scene
	for metadata_key: StringName in source.get_meta_list():native_mesh_copy.set_meta(metadata_key,source.get_meta(metadata_key))
	native_mesh_copy.set("_surfaces",surfaces)
	return native_mesh_copy
