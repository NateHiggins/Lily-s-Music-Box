extends "res://tests/v2_golden_repair_profile.gd"
## INERT two actual street/passage round trips. No toggle/procurement proof.
var work_probe: Node
var residency_events: Array=[]
var cycles: Array=[]
var last_fit: Dictionary={}
var last_state: String=""
var owned_path: String
var old_path: String
var old_persistence:=false

func _init() -> void:route_label="V2 PLAYED STREAMING PROFILE"
func _ready() -> void:
	work_probe=preload("res://tests/v2_frame_work_probe.gd").new();work_probe.host=self;add_child(work_probe)
	super._ready()

func _process(delta: float) -> void:
	super._process(delta)
	if not profile_active or not is_instance_valid(world) or world.passage_region==null:return
	var residency: Node=world.passage_region.residency
	if residency.state!=last_state:
		residency_events.append({"kind":"state","usec":Time.get_ticks_usec(),"process_frame":Engine.get_process_frames(),"phase":profile_phase,"state":residency.state})
		last_state=residency.state
	var records: Array=residency.fit_records
	if records.is_empty() or is_same(records[-1],last_fit):return
	var first:=0
	for index in records.size():
		if is_same(records[index],last_fit):first=index+1;break
	for record: Dictionary in records.slice(first):
		residency_events.append({"kind":"fit_observed","usec":Time.get_ticks_usec(),"process_frame":Engine.get_process_frames(),"phase":profile_phase,"record":record.duplicate(true)})
	last_fit=records[-1]

func _play_route() -> void:
	old_path=RealityState.save_path;old_persistence=RealityState.persistence_enabled
	owned_path="user://v2_played_stream_%d.json"%Time.get_ticks_usec()
	RealityState.save_path=owned_path;RealityState.persistence_enabled=true
	world.household_state.profiling=true;player.profile_physics=true;player._grab.profiling=true
	for cycle in 2:
		profile_cycle="cycle_%d_"%cycle
		var before: Dictionary=world.passage_region.residency.snapshot()
		var started:=Time.get_ticks_usec()
		if not await _leave_front_entrance():break
		for point: Vector3 in [Vector3(0,0,3),Vector3(14,0,3),Vector3(14,0,4.2),Vector3(14,-.1,8),Vector3(14,-.1,13.6),Vector3(14,0,15)]:
			if not await _walk_world(point):break
		if not failures.is_empty():break
		var arrival: Dictionary=world.passage_region.residency.snapshot()
		_require(arrival.state=="RESIDENT","ordinary street approach completes passage reconstruction before gateway cycle "+str(cycle))
		profile_phase=profile_cycle+"gateway_wait"
		var wait_started:=Time.get_ticks_msec()
		while world.passage_region.residency.state=="LOADING" and Time.get_ticks_msec()-wait_started<180000:
			await get_tree().process_frame
		if not _require(world.passage_region.residency.state=="RESIDENT","passage eventually reaches resident state cycle "+str(cycle)):break
		for point: Vector3 in [Vector3(14,0,17.3),Vector3(14,0,20),Vector3(14,0,27.5),Vector3(14,0,32)]:
			if not await _walk_world(point):break
		if not failures.is_empty():break
		profile_phase=profile_cycle+"nave_turn"
		for turn in 16:
			var motion:=InputEventMouseMotion.new();motion.relative=Vector2(160,0)
			player._unhandled_input(motion)
			await get_tree().process_frame
		await _picture(profile_cycle+"nave")
		for point: Vector3 in [Vector3(14,0,27.5),Vector3(14,0,20),Vector3(14,0,17.3),Vector3(14,0,15),Vector3(14,-.1,13.6),Vector3(14,-.1,8),Vector3(14,0,4.2),Vector3(14,0,3),Vector3(0,0,3)]:
			if not await _walk_world(point):break
		if not failures.is_empty() or not await _enter_front_entrance():break
		if not await _walk(Vector3(1.925,0,-3.5)):break
		for frame in 4:await get_tree().process_frame
		var returned: Dictionary=world.passage_region.residency.snapshot()
		_require(returned.state=="DORMANT" and returned.pending_requests==0 and returned.retired_geometry_roots_alive==0 and returned.retired_mesh_resources_alive==0,"return retires imported passage roots and meshes cycle "+str(cycle))
		cycles.append({"cycle":cycle,"start_usec":started,"end_usec":Time.get_ticks_usec(),"before":before,"at_gateway":arrival,"returned":returned})
		if not failures.is_empty():break
	profile_active=false
	RealityState.flush_background_saves()
	work_probe.write(OS.get_environment("SHOT_DIR").path_join("work_trace.json"))
	FileAccess.open(OS.get_environment("SHOT_DIR").path_join("streaming.json"),FileAccess.WRITE).store_string(JSON.stringify({"evidence_class":"INERT","scope":"Actual primary-grab doors, standing walk and mouse turning over two street/passage residency cycles; no shop transaction, item manipulation, save reconstruction, runtime_contract or human acceptance.","cycles":cycles,"events":residency_events,"final_residency":world.passage_region.residency.snapshot(),"checks":interaction_checks,"failures":failures,"owned_path":owned_path,"save_result":RealityState.last_save_result()},"\t"))
	RealityState.persistence_enabled=old_persistence;RealityState.save_path=old_path
	var cleanup: Array=[]
	for suffix: String in ["",".bak",".tmp",".txn"]:
		var path:=ProjectSettings.globalize_path(owned_path+suffix)
		if FileAccess.file_exists(path):cleanup.append({"suffix":suffix,"error":DirAccess.remove_absolute(path)})
	FileAccess.open(OS.get_environment("SHOT_DIR").path_join("cleanup.json"),FileAccess.WRITE).store_string(JSON.stringify({"evidence_class":"INERT","cleanup":cleanup},"\t"))

func _picture(label: String) -> void:
	var previous:=profile_phase;profile_phase="capture_excluded_"+label
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(OS.get_environment("SHOT_DIR").path_join(label+".png"))
	await get_tree().process_frame;profile_phase=previous
