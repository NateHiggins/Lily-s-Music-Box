extends "res://tests/orison_v2_connected_exterior_route_test.gd"
## One player, street crossing, arcade doorway and actual hardware purchase.

func _init() -> void:
	route_label = "V2 PASSAGE ROUTE"

func _route() -> void:
	var passage := world.passage_region
	if not _require(passage != null and not passage.startup_failed
			and passage.cell_nodes.has("gateway") and passage.shop_service == world.shop_service,
			"arcade composes in the same production world"): return
	if not _require(world.shop_service.inventory == world.maintenance_inventory
			and world.shop_service.work_orders == world.work_orders
			and not world.shop_service.stock_record("carbon_transmitter_capsule").is_empty(),
			"hardware stock uses initialized shared authorities"): return
	# This route explicitly qualifies a reconstruction, not a brief core transit.
	await get_tree().create_timer(passage.residency.DORMANCY_GRACE_SECONDS+.1).timeout
	if not await _leave_front_entrance():return
	var outward := [Vector3(0, 0, 3), Vector3(14, 0, 3), Vector3(14, 0, 4.2),
		Vector3(14, -0.1, 8), Vector3(14, -0.1, 13.6), Vector3(14, 0, 15),
		Vector3(14, 0, 17.3), Vector3(14, 0, 20), Vector3(14, 0, 27.5),
		Vector3(14, 0, 32)]
	for point: Vector3 in outward:
		if not await _walk_world(point): return
	var residency: Dictionary = passage.residency.snapshot()
	print("RESIDENCY_AT_NAVE ", JSON.stringify(residency))
	if not _require(residency.state == "RESIDENT" and residency.load_cycles >= 1
			and residency.unload_cycles >= 1, "arcade geometry reloads asynchronously after leaving the core"): return
	await _capture("nave", passage.to_global(Vector3(14, 2.5, 63)))
	var door: DoorProp = passage.doors.get("SITE_SHOP_DOOR_HARDWARE_PAINT")
	if not _require(door != null, "authored hardware shop door exists"): return
	var door_center := door.to_global(Vector3(door.width*0.5, 0, 0))
	# Stand clear of the leaf's outward sweep into the arcade before grabbing it.
	for point in [Vector3(14, 0, door_center.z), Vector3(12.75, 0, door_center.z)]:
		if not await _walk_world(point): return
	if not await _use(door, door.to_global(Vector3(door.width*0.5, 1.15, 0)), "hardware_door"): return
	await get_tree().create_timer(0.6).timeout
	if not _require(door.open, "hardware door opens through ordinary input"): return
	if not await _walk_world(Vector3(10.8, 0, door_center.z)): return
	# Step through the source opening and close the leaf using its real
	# panel before turning north along the fitted customer counter aisle.
	if not await _walk_world(Vector3(9.7, 0, door_center.z)): return
	if not await _use(door, door._body.to_global(Vector3(door.width*0.5, 1.15, 0)), "hardware_door_close"): return
	await get_tree().create_timer(0.6).timeout
	if not _require(not door.open, "customer closes the inward leaf before passing the counter"): return
	var counter := world.shop_service.counter("hardware_paint")
	if not _require(counter != null, "actual source-anchored hardware counter exists"): return
	# The public end of the counter is accessible from the door's turning
	# space. Its long front is separated by the fitted display furniture.
	if not await _walk_world(Vector3(counter.global_position.x, 0, door_center.z-0.18)): return
	var counter_target := counter.global_position + Vector3(0, 0.12, 1.2)
	if not _prepare_procurement(): return
	if not _require(world.shop_service.pending_item("hardware_paint") == "carbon_transmitter_capsule",
			"right shop offers the awaited part"): return
	if not await _use(counter, counter_target, "hardware_counter"): return
	if not _require(not world.maintenance_inventory.item_state("carbon_transmitter_capsule").is_empty()
			and world.shop_service.pending_item("hardware_paint").is_empty(),
			"physical counter grants the part exactly once"): return
	var saved_items := var_to_bytes(RealityState.data.maintenance_items)
	if not _require(not world.shop_service.acquire("carbon_transmitter_capsule", "hardware_paint")
			and world.fire_maintenance_counter.terminals.carbon_transmitter_capsule.grip().is_empty(),
			"settled requisition refuses duplicates and retires the exact lever target"):return
	if not _require(var_to_bytes(RealityState.data.maintenance_items) == saved_items,
			"repeated counter input cannot duplicate the part"): return
	for point in [Vector3(9.7, 0, door_center.z)]:
		if not await _walk_world(point): return
	if not await _use(door, door._body.to_global(Vector3(door.width*0.5, 1.15, 0)), "hardware_door_exit"): return
	await get_tree().create_timer(0.6).timeout
	for point in [Vector3(10.8, 0, door_center.z), Vector3(12.8, 0, door_center.z), Vector3(14, 0, door_center.z)]:
		if not await _walk_world(point): return
	outward.reverse()
	for point: Vector3 in outward:
		if not await _walk_world(point): return
	# The slow closer can finish while the customer visits the hardware shop.
	# Reopen the real front leaf from its exterior stance before returning.
	if not await _walk(Vector3(0,0,-13.15)):return
	if not await _open_front_entrance():return
	for point in [Vector3(0, 0, -10.2), Vector3(0, 0, -8.5), Vector3(1.925, 0, -6.5)]:
		if not await _walk(point): return
	_require(var_to_bytes(RealityState.data.maintenance_items) == saved_items,
			"return indoors retains the physically acquired part")

func _capture(identity: String, target: Vector3) -> void:
	var output := OS.get_environment("SHOT_DIR")
	if output.is_empty(): return
	DirAccess.make_dir_recursive_absolute(output)
	player.camera.look_at(target)
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(output.path_join(identity+".png"))

func _prepare_procurement() -> bool:
	var job := "vantry_chirp_2a"
	var orders := world.work_orders
	return _require(orders.issue_job(job, "reported") and orders.acknowledge_job(job)
			and orders.diagnose_job(job) and orders.mark_job_awaiting_part(job),
			"maintenance job awaits authored capsule")

func _use(owner_node: Node3D,target: Vector3,label: String) -> bool:
	if owner_node is MaintenanceShopCounter:
		# V2 retains this semantic owner with collision disabled. The native
		# radio terminal lever owns actual input and delegates settlement.
		var terminal: Node3D=world.fire_maintenance_counter.terminals.carbon_transmitter_capsule
		if not world.service_set_carrier.radio_is_powered():
			Input.action_press("radio_toggle")
			await get_tree().physics_frame;await get_tree().physics_frame
			Input.action_release("radio_toggle")
			await get_tree().physics_frame
		if not _require(world.service_set_carrier.radio_is_powered(),"actual radio input powers the requisition carrier"):return false
		var hand:=RouteHand.new()
		add_child(hand);hand.player=player;player.set_mouse_released(false)
		var moved: bool=await hand.operate(terminal.lever.to_global(Vector3(0,.094,-.025)),terminal.TRAVEL,terminal)
		var follows: bool=hand.follows_cursor
		hand.free()
		return _require(moved and follows,"actual grab, mouse motion and release settle the native requisition lever: "+label)
	if owner_node is DoorProp:
		var door:=owner_node as DoorProp
		# Use the exposed original hinge stile from both sides of the native leaf.
		target=door._body.to_global(Vector3(.065,1.35,door._hinge_offset+.0275))
		var hand:=preload("res://tests/orison_v2_first_slice_contract_test.gd").PatrolHand.new()
		add_child(hand);hand.player=player;player.set_mouse_released(false)
		var moved: bool=await hand.operate(target,0.0 if door.open else door.motion_target_angle(true)*0.86,door)
		var follows: bool=hand.follows_cursor
		hand.free()
		return _require(moved and follows,"actual grab, mouse motion and release: "+label)
	return await super._use(owner_node,target,label)
