extends Node
## T8 contract proof: one authoritative weather clock, four production skies,
## bounded depth fog, deterministic layered rain, and building-owned exposure.

const WeatherServiceScript := preload(
		"res://scripts/building/live_weather_service.gd")
const WeatherFXScript := preload("res://scripts/building/weather_fx.gd")

var _fails := 0


func _check(label: String, ok: bool) -> void:
	print("  [%s] %s" % ["ok" if ok else "FAIL", label])
	if not ok:
		_fails += 1


func _ready() -> void:
	OS.set_environment("DAYNIGHT_FORCE", "night")
	OS.set_environment("WEATHER_SEED", "19280731")
	OS.set_environment("WEATHER_SIMULATE", "rain")
	RealityState.persistence_enabled = false
	RealityState.reset_campaign_for_tests()
	var root: Node3D = load(
			"res://scenes/building/orison_root.tscn").instantiate()
	add_child(root)
	await get_tree().create_timer(1.2).timeout

	var director: DayNightDirector = root.day_night_director
	var paths := director.state_texture_paths() if director else {}
	_check("the time owner exposes exactly four production sky states",
			paths.keys().size() == 4 and paths.has("morning")
			and paths.has("day") and paths.has("evening")
			and paths.has("night"))
	for state in ["morning", "day", "evening", "night"]:
		var resource_path: String = paths.get(state, "")
		_check("%s sky is a production 4K half-dome" % state,
				resource_path.get_basename().ends_with("_half_dome_4k")
				and resource_path.get_extension().to_lower() in ["png", "jpg"]
				and ResourceLoader.exists(resource_path))
		var source_path := ProjectSettings.globalize_path(resource_path)
		var image := Image.load_from_file(source_path)
		_check("%s sky source is 4096x2048 color" % state,
				image != null and image.get_width() == 4096
				and image.get_height() == 2048
				and image.get_format() in [Image.FORMAT_RGB8, Image.FORMAT_RGBA8])

	var world := root.get_node_or_null("WorldEnvironment") as WorldEnvironment
	var environment := world.environment if world else null
	var sky_key := root.get_node_or_null("ExteriorMoon") as DirectionalLight3D
	_check("DayNightDirector is the Environment absolute writer",
			environment != null and environment.get_meta("absolute_writer", "")
			== "DayNightDirector")
	_check("DayNightDirector is the exterior-key absolute writer",
			sky_key != null and sky_key.get_meta("absolute_writer", "")
			== "DayNightDirector")
	var weather_profile := director.resolved_profile()
	_check("reported cloud cover attenuates the matching exterior key",
			is_equal_approx(director._cloud_direct_transmission(0.0), 1.0)
			and director._cloud_direct_transmission(0.38) < 1.0
			and director._cloud_direct_transmission(0.38) > 0.12
			and is_equal_approx(director._cloud_direct_transmission(1.0), 0.12)
			and float(weather_profile.get("cloud_direct_transmission", 1.0))
					< 0.20
			and float(weather_profile.key_e) < float(weather_profile.ambient_e))
	_check("a dry cloud ceiling cannot silently become ground fog",
			director._weather_fog_multiplier(1.0, 0.0, 3) < 1.0
			and director._weather_fog_multiplier(1.0, 1.0, 95) > 1.0
			and director._weather_fog_multiplier(1.0, 0.0, 45) > 1.0
			and director._weather_fog_multiplier(0.0, 0.0, 0, 1.0)
					< director._weather_fog_multiplier(0.0, 0.0, 45, 0.7))
	_check("meteorological wind advects the same lower cloud deck",
			director._wind_direction_vector(0.0).is_equal_approx(Vector3.BACK)
			and director._wind_direction_vector(90.0).is_equal_approx(Vector3.LEFT))
	var high_only: Dictionary = director._cloud_strata(0.0, 0.0, 1.0)
	var mid_only: Dictionary = director._cloud_strata(0.0, 1.0, 0.0)
	_check("cloud strata cannot turn high cirrus into a low ceiling",
			is_zero_approx(float(high_only.lower_strength))
			and is_zero_approx(float(high_only.lower_coverage))
			and is_equal_approx(float(high_only.high_strength), 1.0)
			and float(mid_only.lower_coverage) < float(mid_only.high_strength))
	_check("equal stratum fractions retain unequal optical depth",
			director._cloud_direct_transmission_strata(0.0, 0.0, 1.0)
					> director._cloud_direct_transmission_strata(0.0, 1.0, 0.0)
			and director._cloud_direct_transmission_strata(0.0, 1.0, 0.0)
					> director._cloud_direct_transmission_strata(1.0, 0.0, 0.0))
	_check("the global storm uses bounded depth fog",
			environment != null and environment.fog_enabled
			and environment.fog_mode == Environment.FOG_MODE_DEPTH
			and environment.fog_depth_begin >= 12.0
			and environment.fog_depth_begin <= 16.0
			and environment.fog_depth_end >= 48.0
			and environment.fog_depth_end <= 58.0
			# 0.78-0.90 was the old band and it encoded a misunderstanding,
			# not a ruling. Godot depth fog is
			#   pow(smoothstep(begin, end, dist), curve) * density
			# so DENSITY IS THE ASYMPTOTIC CEILING, not a rate: at 0.86 every
			# surface in the world keeps 14% of its own contrast at infinite
			# distance, forever. That is why the pale backdrop slabs survived
			# a year of fog tuning -- no begin/end/curve triple can reach
			# extinction while the ceiling is below 1.0.
			#
			# Widened deliberately, owner-approved 2026-08-17, so rain can do
			# what it is for: hide the mid-ground. Near-field safety is
			# unaffected and still checked by begin, which stays in its band
			# -- the far kerb is 14 m from the near one and fogs 0.3%.
			and environment.fog_density >= 0.78
			and environment.fog_density <= 1.0)
	var directional := _descendants(root).filter(
			func(node): return node is DirectionalLight3D and node.get_world_3d()==root.get_world_3d())
	print("WEATHER EXTERIOR KEYS: ",directional.map(func(node):return str(node.get_path())))
	_check("isolated story tiles retain loaded mipmaps after compressed-atlas decoding",
			not StoryDecal._texture_cache.is_empty() and StoryDecal._texture_cache.values().all(
			func(texture):return texture.get_width()>0 and texture.get_image().has_mipmaps()))
	_check("the whole world owns one directional exterior key",
			directional.size() == 1 and directional[0] == sky_key)
	_check("WeatherFX adds no realtime lights",
			_descendants(root.weather).all(func(node): return node is not Light3D))
	var period_weather: Dictionary = root.period_reality.diagnostic_snapshot()
	_check("distant 1928 life consumes weather without another visual owner",
			float(period_weather.aircraft_contrast) < 1.0
			and float(period_weather.air_filter_hz) < 14500.0
			and int(period_weather.aircraft_collision_bodies) == 0)
	var neighbour_masses := root.get_node_or_null("PersistentNeighbourMasses")
	var neighbour_facades := root.get_node_or_null("PersistentNeighbourFacades")
	_check("neighbour envelopes survive coarse storey streaming",
			neighbour_masses is MultiMeshInstance3D
			and neighbour_facades is MultiMeshInstance3D
			and neighbour_masses.get_parent() == root
			and neighbour_facades.get_parent() == root)
	_check("persistent skyline contains authored mass and facade instances",
			neighbour_masses.multimesh.instance_count > 8
			and neighbour_facades.multimesh.instance_count > 0)
	var facade_material := neighbour_facades.multimesh.mesh.material \
			as ShaderMaterial
	var facade_code := facade_material.shader.code if facade_material else ""
	var exterior_source := FileAccess.get_file_as_string(
			"res://scripts/building/exterior_detail_pass.gd")
	var mass_material := neighbour_masses.multimesh.mesh.material \
			as ShaderMaterial
	var mass_code := mass_material.shader.code if mass_material else ""
	_check("one facade calculation owns both window recess and occupancy light",
			facade_code.contains("float window")
			and facade_code.contains("EMISSION = warm_room * occupied * window")
			and facade_code.contains("instance_seed")
			and facade_code.contains("instance_extent")
			and facade_code.contains("instance_tint")
			and facade_code.contains("instance_extent.x / 1.45")
			and facade_code.contains("reveal")
			and not facade_code.contains("floor(world_position.xz"))
	_check("oblique neighbour mass faces remain measured apartment elevations",
			mass_code.contains(
					"float along = abs(world_normal.x) > abs(world_normal.z)")
			and mass_code.contains("world_position.y / 2.70")
			and mass_code.contains("EMISSION = warm_room * occupied * window")
			and mass_code.contains("uniform float occupancy_gain"))
	_check("facade exposure follows daylight without inventing occupied rooms",
			director._neighbour_light_for_state("day")
					> director._neighbour_light_for_state("night")
			and director._neighbour_occupancy_for_state("day") == 0.0)
	var legacy_site_panes: Array[Node] = _descendants(root.window_glow).filter(
			func(node): return node.name.begins_with("SitePanes_"))
	_check("legacy site cards cannot independently overlight the facade",
			not legacy_site_panes.is_empty()
			and legacy_site_panes.all(func(node):
				var mat := node.material_override as StandardMaterial3D
				return not node.visible and mat != null \
						and mat.emission_energy_multiplier <= 0.02))

	var dome := root.get_node_or_null("NightSkyHalfDome") as MeshInstance3D
	var sky_material := dome.material_override as ShaderMaterial if dome else null
	var sky_code := sky_material.shader.code if sky_material else ""
	_check("one dome blends only two adjacent panoramas",
			dome != null and sky_code.count("uniform sampler2D panorama_") == 2)
	_check("the dynamic lower cloud deck lives in that same sky draw",
			sky_code.contains("lower_clouds")
			and sky_code.contains("lower_cloud_strength")
			and sky_code.contains("Direction-space waves")
			and sky_code.contains("cloud_relief")
			and sky_code.contains("cloud_relief * 0.82")
			and sky_code.contains("cloud_wind_direction")
			and sky_code.contains("cloud_wind_speed")
			and sky_code.contains("high_cloud_strength")
			and sky_code.contains("high_opacity")
			and sky_code.contains("high_cloud_strength * 0.18")
			and not sky_code.contains("cloud_noise_3d")
			and not sky_code.contains("float high_fold")
			and sky_code.contains("exp(-cloud_shape * lower_cloud_strength")
			and not sky_code.contains("float p = u * 2.0 * PI"))
	_check("the same sky draw projects the lunar terminator from the real Sun",
			sky_code.contains("moon_phase_enabled")
			and sky_code.contains("surface_normal")
			and sky_code.contains("dot(surface_normal, normalize(sun_direction))"))
	_check("the measured Milky Way shares the catalog stars' sidereal basis",
			sky_code.contains("equatorial_axis_x")
			and sky_code.contains("galactic_uv")
			and sky_code.contains("panorama_a_celestial"))
	_check("urban airglow grounds the skyline without reaching the zenith",
			sky_code.contains("urban_horizon_gain")
			and sky_code.contains("smoothstep(0.72, 1.0, v)")
			and sky_code.contains("lower_air")
			and director._urban_horizon_for_state("night")
					> director._urban_horizon_for_state("day"))
	_check("the projected Moon samples measured LROC near-side geography",
			sky_code.contains("moon_surface")
			and sky_code.contains("lunar_lon")
			and ResourceLoader.exists(
					"res://assets/environment/lroc_color_poles_1k.jpg"))
	_check("the dome, middle rain and roadway mist cast no shadows",
			dome.cast_shadow == GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			and root.weather.get_node("DrivingRainMiddle").cast_shadow
			== GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			and root.weather.get_node("RoadwayMist").cast_shadow
			== GeometryInstance3D.SHADOW_CASTING_SETTING_OFF)

	_check("north pavement is rain-exposed",
			root.weather_exposure_at(Vector3(0.0, 0.05, 12.1)))
	_check("south pavement is rain-exposed",
			root.weather_exposure_at(Vector3(0.0, 0.05, 26.1)))
	_check("roadway is rain-exposed",
			root.weather_exposure_at(Vector3(0.0, 0.05, 19.322)))
	_check("the open roof is rain-exposed",
			root.weather_exposure_at(Vector3(0.0, 19.3, 0.0)))
	_check("the lobby and atrium are dry",
			not root.weather_exposure_at(Vector3(0.0, 0.05, 0.0)))
	_check("an upper apartment is dry",
			not root.weather_exposure_at(Vector3(0.0, 9.65, 0.0)))
	_check("the Vantry Arcade is dry",
			not root.weather_exposure_at(Vector3(14.0, 0.05, 45.0)))
	_check("the basement is dry",
			not root.weather_exposure_at(Vector3(0.0, -2.75, 0.0)))

	root.player.global_position = Vector3(0.0, 0.05, 19.322)
	root.weather._process(0.2)
	var weather_state: Dictionary = root.weather.diagnostic_snapshot()
	_check("the weather seed and counts are deterministic",
			weather_state.seed == 19280731
			and weather_state.near_rain_mode == "procedural_close_shell"
			and weather_state.spatter_count == 72
			and weather_state.leaf_count == 8)
	_check("near and middle rain share one visible batch outdoors",
			root.weather.get_node("DrivingRainSpatter").emitting
			and root.weather.get_node("DrivingRainMiddle").visible)
	var rain_state: Dictionary = root.weather.diagnostic_snapshot()
	_check("observed rain magnitude reaches the existing visual owner",
			root.weather.get_node("DrivingRainSpatter").amount
					== roundi(WeatherFXScript.SPATTER_COUNT
					* float(rain_state.rain_intensity))
			and float(rain_state.rain_intensity) > 0.0)
	var snow_conditions: Dictionary = WeatherServiceScript.presentation(
			WeatherServiceScript.simulated_snapshot("snow"))
	snow_conditions.wind_speed_kmh = 36.0
	snow_conditions.wind_direction_degrees = 90.0
	root.weather.set_live_conditions(snow_conditions)
	root.weather._process(0.2)
	_check("frozen precipitation cannot silently retain the rain branch",
			root.weather.get_node("LiveSnow").emitting
			and not root.weather.get_node("DrivingRainSpatter").emitting
			and not root.weather.get_node("DrivingRainMiddle").visible
			and root.weather.get_node("LiveSnow").amount
					== roundi(WeatherFXScript.SNOW_COUNT
					* float(snow_conditions.snow_intensity)))
	_check("snow drifts downwind from the observed meteorological bearing",
			root.weather.get_node("LiveSnow").gravity.x < -1.0
			and absf(root.weather.get_node("LiveSnow").gravity.z) < 0.01
			and is_equal_approx(root.weather.get_node("LiveSnow").gravity.y, -0.42))
	root.weather._lightning_wait = 0.0
	root.weather._update_lightning(0.2)
	_check("snow cannot silently schedule a clear-sky lightning flash",
			root.weather._lightning_age < 0.0
			and not bool(root.weather.diagnostic_snapshot().lightning_enabled))
	var storm_conditions: Dictionary = WeatherServiceScript.presentation(
			WeatherServiceScript.simulated_snapshot("storm"))
	root.weather.set_live_conditions(storm_conditions)
	root.weather._lightning_wait = 0.0
	root.weather._update_lightning(0.2)
	_check("the observed thunderstorm code can schedule the existing flash",
			root.weather._lightning_age >= 0.0
			and bool(root.weather.diagnostic_snapshot().lightning_enabled))
	var hail_conditions: Dictionary = WeatherServiceScript.presentation(
			WeatherServiceScript.simulated_snapshot("hail_storm"))
	root.weather.set_live_conditions(hail_conditions)
	root.weather._process(0.2)
	_check("hail-bearing thunder mixes hard pellets with its rain branch",
			root.weather.get_node("LiveHail").emitting
			and root.weather.get_node("DrivingRainSpatter").emitting
			and root.weather.get_node("LiveHail").cast_shadow
					== GeometryInstance3D.SHADOW_CASTING_SETTING_OFF)
	var overcast_conditions: Dictionary = WeatherServiceScript.presentation(
			WeatherServiceScript.simulated_snapshot("overcast"))
	root.weather.set_live_conditions(overcast_conditions)
	root.weather._process(0.2)
	_check("a dry low cloud ceiling cannot invent roadway mist",
			not root.weather.get_node("RoadwayMist").visible)
	var fog_conditions: Dictionary = WeatherServiceScript.presentation(
			WeatherServiceScript.simulated_snapshot("fog"))
	root.weather.set_live_conditions(fog_conditions)
	root.weather._process(0.2)
	_check("the WMO fog branch reaches the existing roadway mist",
			root.weather.get_node("RoadwayMist").visible
			and bool(fog_conditions.foggy))
	root.player.global_position = Vector3(0.0, 0.05, 0.0)
	root.weather._process(0.2)
	_check("all player-following precipitation suppresses indoors",
			not root.weather.get_node("DrivingRainSpatter").emitting
			and not root.weather.get_node("DrivingRainMiddle").visible
			and not root.weather.get_node("LiveSnow").emitting
			and not root.weather.get_node("LiveHail").emitting)

	_check("traffic's crossing promise remains eight seconds",
			StreetTraffic.MAX_WAIT == 8.0)
	_check("traffic's authored safe gap remains 3.4 seconds",
			StreetTraffic.GAP_SECONDS == 3.4)
	_check("both ruled street-end weather owners survive",
			get_tree().get_nodes_in_group("street_end_weather").size() == 2)

	print("[WEATHER SKY TEST] RESULT: %s (%d failures)" % [
			"PASS" if _fails == 0 else "FAIL", _fails])
	_stop_audio(root)
	root.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	PropAudio.clear_cache()
	get_tree().quit(_fails)


func _descendants(parent: Node) -> Array[Node]:
	var found: Array[Node] = []
	var stack: Array[Node] = [parent]
	while not stack.is_empty():
		var node: Node = stack.pop_back()
		found.append(node)
		stack.append_array(node.get_children())
	return found


func _stop_audio(node: Node) -> void:
	if node is AudioStreamPlayer or node is AudioStreamPlayer3D:
		node.stop()
	for child in node.get_children():
		_stop_audio(child)
