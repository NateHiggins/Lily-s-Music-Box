# Candidate verification - a1d8aa461a2e

- candidate `a1d8aa461a2eaaac453fecd1a86665a05a86134c`
- base `e27606315052d157bc56eddf0abd49f7d25642ca`
- merge-base `e27606315052d157bc56eddf0abd49f7d25642ca`
- verified 2026-10-27T14:03:53Z from verifier `a1d8aa461a2e`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 8 regressions, 0 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 5 |

## Blocking reasons (8)

- regression: spatial: drift.new_reported 0 -> 1
- regression: spatial: new defect new_reported:0b1bca0fa32b8894
- regression: systemic: drift.new_review 29 -> 31
- regression: systemic: new defect new_review:2b210344cf53154b
- regression: systemic: new defect new_review:6a7a8efa2f0d276e
- regression: test:test_nook_readable_books: PASS -> FAIL (exit 0 -> 1)
- regression: test:test_nook_readable_books: failed 0 -> 1
- regression: test:test_nook_readable_books: new defect test_manufactured_outputs_bind_current_source (__main__.NookBooksTests.test_manufactured_outputs_bind_current_source)

## Needs human review (not blocking) (3)

- candidate changes 5 gate file(s); read those diffs before trusting the board
- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (8)

- spatial: drift.new_reported 0 -> 1
- spatial: new defect new_reported:0b1bca0fa32b8894
- systemic: drift.new_review 29 -> 31
- systemic: new defect new_review:2b210344cf53154b
- systemic: new defect new_review:6a7a8efa2f0d276e
- test:test_nook_readable_books: PASS -> FAIL (exit 0 -> 1)
- test:test_nook_readable_books: failed 0 -> 1
- test:test_nook_readable_books: new defect test_manufactured_outputs_bind_current_source (__main__.NookBooksTests.test_manufactured_outputs_bind_current_source)

## Accepted regressions (0)

- none

## Improvements (0)

- none

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (5)

- M tools/audit_period_dates.py
- M tools/audit_v2_surfaces.py
- M tools/orison_spatial_dependency_manifest.json
- M tools/tests/test_additive_material_bindings.py
- M tools/tests/test_v2_surface_requirements.py

BLOCKED regression: spatial: drift.new_reported 0 -> 1; regression: spatial: new defect new_reported:0b1bca0fa32b8894; regression: systemic: drift.new_review 29 -> 31 (+5 more)
