extends Node
var failures: Array[String]=[]
var samples: Array=[]
var previous:=0
var active:=false
var world: Node3D
func check(ok: bool,label: String) -> void:
 print("FRONT DIAGNOSTIC: ",ok," ",label)
 if not ok:failures.append(label)
func shot(label: String) -> void:
 await RenderingServer.frame_post_draw
 get_viewport().get_texture().get_image().save_png(OS.get_environment("SHOT_DIR").path_join(label+".png"))
func _process(_delta: float) -> void:
 var now:=Time.get_ticks_usec()
 if active and previous>0:
  samples.append([(now-previous)/1000.,Performance.get_monitor(Performance.TIME_PROCESS)*1000.,Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS)*1000.,RenderingServer.viewport_get_measured_render_time_cpu(get_viewport().get_viewport_rid()),RenderingServer.viewport_get_measured_render_time_gpu(get_viewport().get_viewport_rid()),world.player.velocity.length(),world.player.crouched,str(world.player.autopilot),Input.get_action_strength("move_forward")])
 previous=now
func run() -> void:
 RealityState.persistence_enabled=false
 RealityState.reset_campaign_for_tests()
 CampaignTime.set_frozen_for_tests(true)
 CampaignClock.new().configure_date(1928,10,15,750)
 GameBoot.launch_mode=GameBoot.LaunchMode.CINEMATIC
 world=load("res://scenes/building/orison_v2_runtime.tscn").instantiate()
 add_child(world)
 await get_tree().physics_frame
 world.player.set_physics_process(false)
 var review: Node=load("res://tests/v2_front_restoration_review.gd").new()
 add_child(review)
 RenderingServer.viewport_set_measure_render_time(get_viewport().get_viewport_rid(),true)
 active=true
 await review.run(world,self)
 active=false
 FileAccess.open(OS.get_environment("SHOT_DIR").path_join("front_diagnostic.json"),FileAccess.WRITE).store_string(JSON.stringify({"evidence_class":"INERT","scope":"Original front restoration route, native full-resolution input, diagnosis only","resolution":str(get_viewport().get_visible_rect().size),"time_scale":Engine.time_scale,"physics_hz":Engine.physics_ticks_per_second,"columns":["wall_ms","script_ms","physics_ms","render_cpu_ms","render_gpu_ms","speed","crouched","autopilot","forward_strength"],"samples":samples,"trace":review.trace,"failures":failures},"\t"))
 world.shutdown_for_tests();world.free()
 for i in 4:await RenderingServer.frame_post_draw
 get_tree().quit(0 if failures.is_empty() else 1)
func _ready() -> void:
 call_deferred("run")
