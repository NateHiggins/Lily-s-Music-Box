from pathlib import Path
import json,hashlib,subprocess,sys
j=json.loads(Path(sys.argv[1]).read_text());root=Path(j['root'])
paths=sorted(subprocess.check_output(['rg','--files','game','-g','*.gd','-g','*.tscn','-g','project.godot'],cwd=root,text=True).splitlines())
actual={p:hashlib.sha256((root/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in paths}
if actual!=j['files']:
 print('Source changed since the noncapturing scene audit; refusing launch.');sys.exit(1)
print('Noncapturing scene source guard: unchanged %d files'%len(paths))
