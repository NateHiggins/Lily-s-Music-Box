# Candidate verification - 1e472a7ec7ee

- candidate `1e472a7ec7eeb641eb3b91550c4369e896ca4c0b`
- base `2a7d21fb5e22cfe0f06a86be71809ac7d81dd172`
- merge-base `2a7d21fb5e22cfe0f06a86be71809ac7d81dd172`
- verified 2026-10-26T15:46:59Z from verifier `1e472a7ec7ee`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 0 regressions, 0 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 0 |
| godot (import) | exit 0 |
| godot (import) | exit 0 |
| godot res://tests/CampaignWeatherTest.tscn | exit 0, receipt binds |
| godot res://tests/WeatherSkyTest.tscn | exit 0, receipt binds |
| godot res://tests/SkyPhenomenaScheduleTest.tscn | exit 0, receipt binds |
| godot res://tests/WeatherFlashAccessibilityTest.tscn | exit 0, receipt binds |

## Blocking reasons (0)

- none

## Needs human review (not blocking) (1)

- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (0)

- none

## Accepted regressions (0)

- none

## Improvements (0)

- none

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (0)

- none

MERGE-CANDIDATE 1e472a7ec7eeb641eb3b91550c4369e896ca4c0b
