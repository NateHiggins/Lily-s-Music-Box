# Run the existing lane broker on a private, never-activated Windows desktop.
# Godot is still launched only by the shared serial/long wrappers. This avoids
# displaying noncapturing weather diagnostics on the owner's active desktop.
# Capture/confinement tests are NOT isolated by this launcher and are forbidden.
[CmdletBinding()]
param(
    [ValidateSet('run','batch')][string]$Command = 'run',
    [string]$Scene = '',
    [string]$ProjectPath = '',
    [Parameter(Mandatory=$true)][string]$LogPath,
    [ValidateSet('serial','long')][string]$Runner = 'serial',
    [int]$TimeoutSeconds = 180,
    [string[]]$ExtraArgs = @(),
    [switch]$Windowed,
    [string]$ShotDir = '',
    [string]$BatchFile = '',
    [double]$WaitMinutes = 30
)
$ErrorActionPreference = 'Stop'
$allowedScenes = @('res://tests/V2SkySpectacleBench.tscn','res://tests/SkyPhenomenaScheduleTest.tscn','res://tests/NewspaperTest.tscn','res://tests/CampaignWeatherTest.tscn','res://tests/WeatherSkyTest.tscn','res://tests/CampaignWeatherWorldReview.tscn','res://tests/WeatherFlashAccessibilityTest.tscn','res://tests/FirstShiftOpeningLiveTest.tscn')
if ($Command -eq 'run') {
    if ($Scene -notin $allowedScenes) { throw 'Scene is outside the explicitly audited noncapturing allowlist.' }
} else {
    $auditedRuns = @(Get-Content -Raw -LiteralPath $BatchFile | ConvertFrom-Json)
    if ($auditedRuns.Count -eq 0) { throw 'Empty audited batch.' }
    foreach ($run in $auditedRuns) {
        if ($run.scene -notin $allowedScenes -or $run.windowed -ne $true) { throw 'Every batch scene must be explicitly audited and windowed.' }
    }
}
& python 'C:/ov/reports/weather_world26/check_noncapturing_sources.py' 'C:\ov\reports\weather_lifecycle27\noncapturing_sources.json'
if ($LASTEXITCODE -ne 0) { throw 'Noncapturing source guard refused the run.' }
if (-not $IsWindows) { throw 'Private desktop runs require Windows.' }
$native = @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class OrisonPrivateDesktop {
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
    public struct Startup {
        public int cb; public string reserved, desktop, title;
        public int x,y,width,height,charsX,charsY,fill,flags;
        public short show,reservedBytes; public IntPtr reservedData,input,output,error;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct ProcessInfo { public IntPtr process,thread; public int pid,tid; }
    [StructLayout(LayoutKind.Sequential)]
    public struct Rect { public int left,top,right,bottom;
        public override string ToString() { return left+","+top+","+right+","+bottom; } }
    [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)]
    public static extern IntPtr CreateDesktopW(string name,IntPtr device,IntPtr mode,int flags,uint access,IntPtr security);
    [DllImport("user32.dll",CharSet=CharSet.Unicode,SetLastError=true)]
    public static extern IntPtr CreateWindowStationW(string name,int flags,uint access,IntPtr security);
    [DllImport("user32.dll")] public static extern IntPtr GetProcessWindowStation();
    [DllImport("user32.dll")] public static extern bool SetProcessWindowStation(IntPtr station);
    [DllImport("user32.dll")] public static extern bool CloseWindowStation(IntPtr station);
    [DllImport("user32.dll")] public static extern bool CloseDesktop(IntPtr desktop);
    [DllImport("user32.dll")] public static extern IntPtr GetThreadDesktop(uint thread);
    [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")] public static extern IntPtr OpenInputDesktop(int flags,bool inherit,uint access);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)]
    static extern bool GetUserObjectInformationW(IntPtr handle,int index,StringBuilder name,int bytes,out int needed);
    [DllImport("user32.dll")] public static extern bool GetClipCursor(out Rect rect);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]
    public static extern bool CreateProcessW(string app,StringBuilder args,IntPtr processSecurity,IntPtr threadSecurity,
        bool inherit,uint flags,IntPtr environment,string cwd,ref Startup startup,out ProcessInfo info);
    [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr handle);
    public delegate bool WindowVisitor(IntPtr window,IntPtr data);
    [DllImport("user32.dll")] static extern bool EnumDesktopWindows(IntPtr desktop,WindowVisitor visit,IntPtr data);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window,out uint pid);
    public static string Name(IntPtr handle) {
        int needed; var name=new StringBuilder(256);
        if (!GetUserObjectInformationW(handle,2,name,512,out needed)) throw new System.ComponentModel.Win32Exception();
        return name.ToString();
    }
    public static string InputDesktop() {
        var h=OpenInputDesktop(0,false,1);
        if(h==IntPtr.Zero) throw new System.ComponentModel.Win32Exception();
        try { return Name(h); } finally { CloseDesktop(h); }
    }
    public static string Clip() { Rect r; if(!GetClipCursor(out r)) throw new System.ComponentModel.Win32Exception(); return r.ToString(); }
    public static bool HasGodotWindow(IntPtr desktop) {
        bool found=false;
        EnumDesktopWindows(desktop,(window,data)=> {
            uint pid; GetWindowThreadProcessId(window,out pid);
            try { if(System.Diagnostics.Process.GetProcessById((int)pid).ProcessName.StartsWith("Godot")) found=true; } catch {}
            return true;
        },IntPtr.Zero);
        return found;
    }
}
'@
Add-Type -TypeDefinition $native
$LogPath = [IO.Path]::GetFullPath($LogPath)
$null=New-Item -ItemType Directory -Force -Path (Split-Path $LogPath -Parent)
$token=[Guid]::NewGuid().ToString('N')
$desktopName='OrisonTest_'+$token
$stationName='WinSta0'
$requestPath=Join-Path ([IO.Path]::GetTempPath()) ($desktopName+'.json')
$helperLog=$LogPath+'.isolated.log'
$spec=@{Scene=$Scene;ProjectPath=$ProjectPath;LogPath=$LogPath;Runner=$Runner;TimeoutSeconds=$TimeoutSeconds;
    ExtraArgs=$ExtraArgs;Windowed=[bool]$Windowed;ShotDir=$ShotDir;WaitMinutes=$WaitMinutes}
if ($Command -eq 'batch') { $spec=@{BatchFile=[IO.Path]::GetFullPath($BatchFile);WaitMinutes=$WaitMinutes} }
@{spec=$spec;command=$Command;broker='C:/ov/v2merge24/tools/lane.ps1';native=$native;
    desktop=$desktopName;station=$stationName;log=$helperLog} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $requestPath -Encoding utf8
# Only the generated request path is interpolated into code; all caller values
# travel as JSON data, preserving quotes, spaces, newlines and argument arrays.
$quotedRequest=$requestPath.Replace("'","''")
$script=@"
`$ErrorActionPreference='Stop'
`$request=Get-Content -LiteralPath '$quotedRequest' -Raw | ConvertFrom-Json -AsHashtable
Add-Type -TypeDefinition `$request.native
`$desktop=[OrisonPrivateDesktop]::Name([OrisonPrivateDesktop]::GetThreadDesktop([OrisonPrivateDesktop]::GetCurrentThreadId()))
if (`$desktop -ne `$request.desktop) { throw 'Private launcher attached to the wrong desktop; refusing Godot.' }
if ([OrisonPrivateDesktop]::Name([OrisonPrivateDesktop]::GetProcessWindowStation()) -ne `$request.station) { throw 'Private launcher attached to the wrong window station; refusing Godot.' }
`$argsToLane=`$request.spec
& `$request.broker `$request.command @argsToLane *> `$request.log
exit `$LASTEXITCODE
"@
$encoded=[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($script))
$powershell=(Get-Command pwsh -ErrorAction Stop).Source
$desktop=[IntPtr]::Zero;$station=[IntPtr]::Zero;$process=$null;$exitCode=1;$seen=$false
$inputBefore=[OrisonPrivateDesktop]::InputDesktop();$clipBefore=[OrisonPrivateDesktop]::Clip()
$inputChanged=$false;$clipChanged=$false
$lastClip=$clipBefore;$lastInput=$inputBefore
$observations=[Collections.Generic.List[object]]::new()
$observations.Add(@{utc=[DateTime]::UtcNow.ToString("o");clip=$lastClip;input_desktop=$lastInput;phase="initial"})
try {
    $desktop=[OrisonPrivateDesktop]::CreateDesktopW($desktopName,[IntPtr]::Zero,[IntPtr]::Zero,0,0x10000000,[IntPtr]::Zero)
    if ($desktop -eq [IntPtr]::Zero) { throw [ComponentModel.Win32Exception]::new() }
    $startup=[OrisonPrivateDesktop+Startup]::new();$startup.cb=[Runtime.InteropServices.Marshal]::SizeOf($startup)
    $startup.desktop=$stationName+'\'+$desktopName;$startup.flags=1;$startup.show=0
    $info=[OrisonPrivateDesktop+ProcessInfo]::new()
    $arguments=[Text.StringBuilder]::new('"'+$powershell+'" -NoProfile -NonInteractive -EncodedCommand '+$encoded)
    if (-not [OrisonPrivateDesktop]::CreateProcessW($powershell,$arguments,[IntPtr]::Zero,[IntPtr]::Zero,$false,
        0x08000000,[IntPtr]::Zero,'C:/ov/v2merge24',[ref]$startup,[ref]$info)) {
        throw [ComponentModel.Win32Exception]::new()
    }
    try { $process=Get-Process -Id $info.pid; $null=$process.Handle }
    finally { $null=[OrisonPrivateDesktop]::CloseHandle($info.thread);$null=[OrisonPrivateDesktop]::CloseHandle($info.process) }
    Write-Output "[ISOLATED LANE] private desktop $desktopName; broker pid $($process.Id)"
    # The broker/runners retain their own per-suite ceilings and lane ownership.
    # This outer supervisor never launches Godot or switches the input desktop.
    while (-not $process.WaitForExit(200)) {
        $seen=$seen -or [OrisonPrivateDesktop]::HasGodotWindow($desktop)
        $currentInput=[OrisonPrivateDesktop]::InputDesktop();$currentClip=[OrisonPrivateDesktop]::Clip()
        if ($currentInput -ne $lastInput -or $currentClip -ne $lastClip) {
            $observations.Add(@{utc=[DateTime]::UtcNow.ToString("o");clip=$currentClip;input_desktop=$currentInput;own_window_seen=$seen;phase="change"})
        }
        $lastClip=$currentClip;$lastInput=$currentInput
        $inputChanged=$inputChanged -or $currentInput -ne $inputBefore
        $clipChanged=$clipChanged -or $currentClip -ne $clipBefore
    }
    $exitCode=$process.ExitCode
    if (Test-Path -LiteralPath $helperLog) { Get-Content -LiteralPath $helperLog -Tail 8 }
}
finally {
    if ($process -and -not $process.HasExited) { $process.Kill($true);$process.WaitForExit() }
    if ($desktop -ne [IntPtr]::Zero) { $null=[OrisonPrivateDesktop]::CloseDesktop($desktop) }
    if ($station -ne [IntPtr]::Zero) { $null=[OrisonPrivateDesktop]::CloseWindowStation($station) }
    Remove-Item -LiteralPath $requestPath -Force -ErrorAction SilentlyContinue
    $observations.Add(@{utc=[DateTime]::UtcNow.ToString("o");clip=[OrisonPrivateDesktop]::Clip();input_desktop=[OrisonPrivateDesktop]::InputDesktop();phase="final"})
    $execution=$null
    if (Test-Path -LiteralPath ($LogPath+'.receipt.json')) { $execution=(Get-Content -Raw -LiteralPath ($LogPath+'.receipt.json') | ConvertFrom-Json).execution }
    @{observations=@($observations.ToArray());wrapper_execution=$execution;poll_ms=200;evidence_class='INERT';scope='Windows desktop isolation diagnostic; does not qualify gameplay or performance';
        desktop=$desktopName;window_station=$stationName;input_desktop_before=$inputBefore;input_desktop_after=[OrisonPrivateDesktop]::InputDesktop();
        observed_input_desktop_changed=$inputChanged;observed_cursor_clip_changed=$clipChanged;
        godot_window_observed_on_private_desktop=$seen;exit_code=$exitCode} |
        ConvertTo-Json -Depth 6 | Set-Content -LiteralPath ($LogPath+'.isolated.json') -Encoding utf8
}
exit $exitCode
