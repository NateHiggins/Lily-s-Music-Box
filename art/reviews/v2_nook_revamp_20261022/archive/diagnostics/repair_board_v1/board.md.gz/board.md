# Gate board - e9df01d2babb

- commit `e9df01d2babb6e751ebb302522fe9898fed8823d`
- tree `bc609524dc9a7b68a2c91772a3b38c92871f79b0`
- created 2026-10-22T17:22:18Z
- dirty paths: 2600

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| spatial | PASS | 0 | 5.12 | drift.new_reported 7 |
| reader | PASS | 0 | 3.44 | unread 1108; vs frozen baseline: new 0, resolved 200 |
| test:test_material_catalog_persistence | PASS | 0 | 0.17 | ran 1, failed 0 |
| test:test_nook_readable_books | PASS | 0 | 0.14 | ran 4, failed 0 |
| test:test_orison_spatial_dependencies | PASS | 0 | 6.0 | ran 59, failed 0 |
