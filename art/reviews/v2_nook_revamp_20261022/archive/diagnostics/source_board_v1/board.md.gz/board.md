# Gate board - e9df01d2babb

- commit `e9df01d2babb6e751ebb302522fe9898fed8823d`
- tree `bc609524dc9a7b68a2c91772a3b38c92871f79b0`
- created 2026-10-22T17:12:23Z
- dirty paths: 2875

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| physical_import_sources | PASS | 0 | 0.59 | no defects counted |
| spatial | PASS | 0 | 7.39 | drift.new_reported 10 |
| reader | PASS | 0 | 5.72 | unread 1108; vs frozen baseline: new 0, resolved 200 |
| test:test_additive_material_rebind | PASS | 0 | 0.2 | ran 8, failed 0 |
| test:test_material_relief | PASS | 0 | 0.67 | ran 5, failed 0 |
| test:test_nook_readable_books | PASS | 0 | 0.23 | ran 4, failed 0 |
