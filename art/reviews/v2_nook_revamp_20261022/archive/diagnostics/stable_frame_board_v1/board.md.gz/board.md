# Gate board - e9df01d2babb

- commit `e9df01d2babb6e751ebb302522fe9898fed8823d`
- tree `bc609524dc9a7b68a2c91772a3b38c92871f79b0`
- created 2026-10-22T17:30:36Z
- dirty paths: 2604

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| physical_import_sources | PASS | 0 | 0.33 | no defects counted |
| spatial | PASS | 0 | 5.19 | drift.new_reported 7 |
| reader | PASS | 0 | 3.42 | unread 1108; vs frozen baseline: new 0, resolved 200 |
| test:test_nook_readable_books | PASS | 0 | 0.14 | ran 4, failed 0 |
