# Gate board - e9df01d2babb

- commit `e9df01d2babb6e751ebb302522fe9898fed8823d`
- tree `bc609524dc9a7b68a2c91772a3b38c92871f79b0`
- created 2026-10-22T17:33:01Z
- dirty paths: 2604

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| physical_import_sources | PASS | 0 | 0.34 | no defects counted |
| spatial | PASS | 0 | 5.25 | drift.new_reported 7 |
| reader | PASS | 0 | 3.47 | unread 1108; vs frozen baseline: new 0, resolved 200 |
| test:test_nook_readable_books | PASS | 0 | 0.16 | ran 4, failed 0 |
