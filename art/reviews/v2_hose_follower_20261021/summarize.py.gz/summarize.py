"""INERT diagnostic summaries; no runtime or acceptance promotion."""
from pathlib import Path
import gzip,json,numpy as np
ROOT=Path(__file__).resolve().parents[3]
REVIEW=ROOT/'art/reviews/v2_hose_follower_20261021'
def read(path):
 path=Path(path)
 return json.loads(path.read_text() if path.exists() else gzip.decompress(Path(str(path)+'.gz').read_bytes()))
def distribution(values):
 values=np.asarray(values,dtype=float)
 return {'n':len(values),'p50':float(np.percentile(values,50)),'p95':float(np.percentile(values,95)),'p99':float(np.percentile(values,99)),'max':float(max(values)),'over_50ms':int(sum(values>50)),'over_100ms':int(sum(values>100)),'over_250ms':int(sum(values>250))}
report={'evidence_class':'INERT','scope':'Separate fixture solver work from actual played frame samples. Source diagnostics, never runtime qualification.','settling':{}}
for index in range(1,11):
 path=REVIEW/f'settling_v{index}/settling.json'
 if not path.exists():continue
 data=read(path);steps=data['steps']
 report['settling'][str(index)]={'step_cost_ms':distribution([r['solver_ms'] for r in steps]),'requested_simulated_seconds':len(steps)/120,'total_solver_ms':sum(r['solver_ms'] for r in steps),'all_accepted':all(r['accepted'] for r in steps),'follow_fallbacks':sum(r['follow_fallbacks'] for r in steps),'failures':data['failures'],'category_ms':{key:sum(row['profile_usec'].get(key,0) for row in steps)/1000 for key in {key for row in steps for key in row['profile_usec']}}}
path=REVIEW/'carrier_profile_v1/frames.json'
if path.exists():
 data=read(path);report['carrier_route']={'resolution':data['resolution'],'vsync':data['vsync'],'failures':data['failures'],'cycles':{}}
 for prefix in ['original_a_','reduced_carrier_b_','restored_a_']:
  rows=[r for r in data['samples'] if r[0].startswith(prefix) and 'excluded' not in r[0]]
  subsets={'all':rows,'movement_and_turn':[r for r in rows if 'inspection_' not in r[0] or 'inspection_approach_' in r[0]],'inspection':[r for r in rows if 'inspection_' in r[0] and 'inspection_approach_' not in r[0]]}
  cycle={}
  for name,selected in subsets.items():
   if selected:cycle[name]={key:distribution([r[column] for r in selected]) for key,column in [('wall_ms',1),('process_ms',2),('physics_ms',3),('render_cpu_ms',4),('render_gpu_ms',5)]}
  cycle['phases']={name:distribution([r[1] for r in rows if r[0]==name]) for name in sorted({r[0] for r in rows})}
  cycle['pipeline_deltas']={key:max(r[7][key] for r in rows)-min(r[7][key] for r in rows) for key in rows[0][7] if key.startswith('PIPELINE_')}
  cycle['primitives']=distribution([r[7]['primitives'] for r in rows])
  report['carrier_route']['cycles'][prefix]=cycle
(REVIEW/'diagnostic_summary.json').write_text(json.dumps(report,indent=2)+'\n',newline='\n')
print(json.dumps(report,indent=2))
