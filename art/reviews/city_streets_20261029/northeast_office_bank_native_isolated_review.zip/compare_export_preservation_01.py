from pathlib import Path
import json,struct,hashlib
r=Path('C:/ov/city');n=Path(__file__).parent; previous=n.parent
before=json.loads((n/'baseline.json').read_text(encoding='utf-8'))
def projection(path):
 raw=path.read_bytes();size=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+size]);binary=raw[28+size:]
 def accessor(i):
  a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];components={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];width={5120:1,5121:1,5122:2,5123:2,5125:4,5126:4}[a['componentType']]*components;stride=v.get('byteStride',width);offset=v.get('byteOffset',0)+a.get('byteOffset',0);data=b''.join(binary[offset+j*stride:offset+j*stride+width] for j in range(a['count']));return dict(count=a['count'],type=a['type'],componentType=a['componentType'],sha256=hashlib.sha256(data).hexdigest())
 return {node['name']:{'transform':{k:node[k] for k in ['translation','rotation','scale','matrix'] if k in node},'primitives':[dict(attributes={k:accessor(v) for k,v in p['attributes'].items()},indices=accessor(p['indices'])) for p in doc['meshes'][node['mesh']]['primitives']]} for node in doc['nodes'] if 'mesh'in node}
result=dict(evidence_class='INERT',scope='Final actual exported accessor and transform comparison, no runtime acceptance')
for family in ['city_elevations','city_elevations_lod1']:
 a=before['assets'][family]['parts'];b=projection(r/f'game/assets/props/{family}.glb');unchanged={k for k in a if not k.startswith(('site_ne3__','site_ne4__'))};fail=[k for k in unchanged if a[k]!=b.get(k)]
 result[family]=dict(before_parts=len(a),after_parts=len(b),unchanged_exact=len(unchanged)-len(fail),unexpected_changes=fail,added=sorted(b.keys()-a.keys()),removed=sorted(a.keys()-b.keys()),asset_sha256=hashlib.sha256((r/f'game/assets/props/{family}.glb').read_bytes()).hexdigest());assert not fail,fail
 print(family,result[family]['unchanged_exact'],'exact unchanged parts')
(n/'export_preservation_01.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
