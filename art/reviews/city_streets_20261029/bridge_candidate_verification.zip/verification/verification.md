# Candidate verification - d3693ceb9bf4

- candidate `d3693ceb9bf4a6add2602c291a87b01213408588`
- base `e145b1293a2f1892e76d74176f01b789a2249b40`
- merge-base `e145b1293a2f1892e76d74176f01b789a2249b40`
- verified 2026-10-31T00:41:59Z from verifier `d3693ceb9bf4`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 2 regressions, 4 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 2 |

## Blocking reasons (2)

- regression: spatial: drift.new_reported 0 -> 1
- regression: spatial: new defect new_reported:a8bf464e2a4cc7e5

## Needs human review (not blocking) (3)

- candidate changes 2 gate file(s); read those diffs before trusting the board
- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (2)

- spatial: drift.new_reported 0 -> 1
- spatial: new defect new_reported:a8bf464e2a4cc7e5

## Accepted regressions (0)

- none

## Improvements (4)

- v2_surface_qualification: FAIL -> PASS
- v2_surface_qualification: defects 2 -> 0
- v2_surface_qualification: resolved missing or stale rendered review
- v2_surface_qualification: resolved stale surface qualification: rendering inputs changed

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (2)

- M tools/lane_common.ps1
- M tools/tests/test_lane_queue.py

BLOCKED regression: spatial: drift.new_reported 0 -> 1; regression: spatial: new defect new_reported:a8bf464e2a4cc7e5
