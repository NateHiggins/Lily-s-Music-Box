from pathlib import Path
import json
root=Path.cwd();p=root/'tools/orison_spatial_dependency_manifest.json';raw=p.read_text(encoding='utf-8');m=json.loads(raw);a=json.loads(Path('C:/ov/reports/city_streets_20261029/canonical_bridge_01/spatial_after_intake.json').read_text(encoding='utf-8-sig'));rows=a['drift']['new_reported'];assert len(rows)==1;row=rows[0]
assert row['file']=='game/tests/v2_city_transport_bench.gd' and row['symbols']==['_bench_sources'] and row['token']=='res://assets/building/textures/' and row['authority']==['TEST_CONTRACT'] and not row['gameplay_binding'];assert (root/'game/assets/building/textures').is_dir();assert all(r['key']!=row['key'] for r in m['records'])
assert raw.endswith(' ]\n}\n'); raw=raw[:-len(' ]\n}\n')].rstrip() + ',\n' + '\n'.join('  '+line for line in json.dumps(row,indent=1,ensure_ascii=False).splitlines()) + '\n ]\n}\n'; p.write_text(raw,encoding='utf-8',newline='\n');print('Registered only audited existing texture-source prefix',row['key'],'; universe/other records unchanged')

