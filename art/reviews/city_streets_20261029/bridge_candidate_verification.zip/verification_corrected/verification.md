# Candidate verification - 74f29ebbb3b7

- candidate `74f29ebbb3b7a62a38eb7ac39d085f04739748d6`
- base `e145b1293a2f1892e76d74176f01b789a2249b40`
- merge-base `e145b1293a2f1892e76d74176f01b789a2249b40`
- verified 2026-10-31T00:51:16Z from verifier `74f29ebbb3b7`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 0 regressions, 4 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 3 |

## Blocking reasons (0)

- none

## Needs human review (not blocking) (3)

- candidate changes 3 gate file(s); read those diffs before trusting the board
- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (0)

- none

## Accepted regressions (0)

- none

## Improvements (4)

- v2_surface_qualification: FAIL -> PASS
- v2_surface_qualification: defects 2 -> 0
- v2_surface_qualification: resolved missing or stale rendered review
- v2_surface_qualification: resolved stale surface qualification: rendering inputs changed

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (3)

- M tools/lane_common.ps1
- M tools/orison_spatial_dependency_manifest.json
- M tools/tests/test_lane_queue.py

MERGE-CANDIDATE 74f29ebbb3b7a62a38eb7ac39d085f04739748d6
