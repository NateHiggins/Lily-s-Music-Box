import hashlib,json,os,re,subprocess,zipfile
from pathlib import Path
root=Path('C:/PleaseRemainOnTheLine');out=Path('C:/ov/reports/city_qualification_repair_20261101')
base='32f59b0a48e210d07fe21b50fe4530986081c121'
test=root/'game/tests/v2_city_horizon_bench.gd'
outcome=json.loads((out/'current_roof_after02/family_outcome.json').read_bytes())
assert outcome['evidence_class']=='INERT' and outcome['checks']==30041 and not outcome['failures']
assert outcome['test_sha256']==hashlib.sha256(test.read_bytes()).hexdigest()
assert len(outcome['roof_controls'])==4 and all(all(r[k] for k in ('displaced_rejected','missing_rejected','restored')) for r in outcome['roof_controls'])
assert len(outcome['derivative_controls'])==2 and all(all(r[k] for k in ('unchanged_source_accepted','opposite_handedness_rejected','collapsed_uv_rejected')) for r in outcome['derivative_controls'])
for case,failures in [('current_roof_before',33),('current_roof_after01',1),('current_roof_after02',0)]:
    receipt=json.loads((out/case/'run.log.receipt.json').read_bytes())
    assert receipt['execution']['completed'] and not receipt['execution']['timed_out']
    assert ('CITY HORIZON BENCH: PASS' if failures==0 else 'CITY HORIZON BENCH: FAIL') in (out/case/'run.log').read_text(encoding='utf-8')
    assert receipt['execution']['exit_code']==(0 if failures==0 else 1)
assert (out/'current_roof_after02/run.log.stderr').read_bytes()==b''
assert not re.search(r'(?m)^(ERROR:|SCRIPT ERROR:)',(out/'current_roof_after02/run.log').read_text(encoding='utf-8'))
assert json.loads((out/'unchanged_surface_qualification.json').read_bytes())['result']=='PASS'
assert all(g['severity']=='PASS' for g in json.loads((out/'roof_source_gates01/board.json').read_bytes())['gates'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
fixture=json.loads((root/'game/tests/fixtures/orison_city_horizon.json').read_bytes())
native={row['asset']:sha(root/row['asset']) for row in fixture['assets'].values()}
native.update({p:sha(root/p) for p in ['game/assets/props/orison_ground.glb','game/assets/props/city_ground_apron.glb']})
for p,digest in native.items():
    original=subprocess.check_output(['git','-C',str(root),'show',base+':'+p])
    assert hashlib.sha256(original).hexdigest()==digest,p
report={'evidence_class':'INERT','scope':'Loaded family diagnostic only; no new runtime_contract,production-route,artistic or performance acceptance',
 'base':base,'cases':{'before':{'checks':30011,'failures':33},'roof_only':{'checks':30034,'failures':1},'roof_and_double_derivatives':{'checks':30041,'failures':0}},
 'final_elapsed_s':json.loads((out/'current_roof_after02/run.log.receipt.json').read_bytes())['execution']['elapsed_s'],
 'original_ground_mesh_flags':['orison_ground_Court_soil_P34_N27','orison_ground_StreetCut_soil_P34_N4'],
 'roof_controls':outcome['roof_controls'],'derivative_controls':outcome['derivative_controls'],
 'unchanged_tolerances':{'roof_distance_m':.0001,'uv_determinant_min':1e-12,'tangent_dot_min':.999,'chart_edge_excess_m':.00005,'metric_deviation_max':.005},
 'byte_exact_native_assets':native,'existing_surface_qualification':'PASS0; unchanged rendering inputs','reader_new':0,'spatial':'PASS'}
(out/'roof_repair_comparison.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
members={}
for case in ['current_roof_before','current_roof_after01','current_roof_after02','roof_source_gates01']:
    for path in sorted((out/case).glob('*')):
        if path.is_file() and path.suffix in ['.json','.log','.stderr','.md']:members[path.relative_to(out).as_posix()]=path.read_bytes()
for name in ['current_roof_original.gd','current_roof_only.gd','current_roof_before.json','current_roof_after01.json','current_roof_after02.json','roof_repair_comparison.json','unchanged_surface_qualification.json','publish_roof_checkpoint.py']:
    members[name]=(out/name).read_bytes()
for p in ['game/tests/v2_city_horizon_bench.gd','game/tests/v2_city_western_street_review.gd','game/tests/orison_v2_roof_bulkhead_caps_test.gd']:
    members['sources/'+p]=(root/p).read_bytes()
manifest={'evidence_class':'INERT','base':base,'scope':report['scope'],'files':{k:hashlib.sha256(v).hexdigest() for k,v in members.items()}}
archive=root/'art/reviews/city_streets_20261029/legacy_roof_review_20261101.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for name,raw in members.items():z.writestr(name,raw)
    z.writestr('INDEX.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,raw in members.items():assert z.read(name)==raw
archive_hash=sha(archive);archive_bytes=archive.stat().st_size;archive_members=len(members)+1
def atomic(path,text,before):
    tmp=path.with_name(path.name+'.roof-record-tmp');assert not tmp.exists()
    tmp.write_bytes(text.encode());assert path.read_bytes()==before;os.replace(tmp,path)
path=root/'design/V2_CITY_CONTEXT_REPORT_2026-10-19.md';before=path.read_bytes();text=before.decode().replace('\r\n','\n')
text+=f'''
### November 1 — retained roof and ground-derivative diagnostic repair

Evidence class: **INERT**. Test repair,not composed gameplay or artistic proof.
Branch **codex/v2-city-qualification-20261101** starts at main **32f59b0a4**.
The clean actual main119-gate baseline is cached; no baseline metadata was repinned.
Current loaded-family reproduction retained30011checks/33failures:32 roof failures
and one aggregate ground-chart failure(two flagged meshes). The residential
expectation recognized only the old three styles. Installed **CivicRows** uses
the final floor plane for **stone_2129**,**narrow_2141** and**neogrec_2122**;
the old check incorrectly subtracted the last floor. All existing hit/part and
100-micrometre rules remain. Unknown roof styles remain refused. Real native
roof mutations on all four flat styles reject a10mm displacement and removed
collision,then restore exact poses/layers. Roof-only run passes every roof check,
retaining30034checks/one ground failure.

The two unchanged imported ground meshes are **orison_ground_Court_soil_P34_N27**
and **orison_ground_StreetCut_soil_P34_N4**. The legacy vector calculation rounds
thin-face subtraction/multiplication to float32. The already reviewed Western
checker performs those operations as scalar doubles. This bench now reuses that
implementation for ground only,retaining determinant1e-12,tangent dot.999,
edge excess50micrometres and metric deviation.005. Its detached helper instances
never enter the tree or start another world and are explicitly freed. Both
unchanged sources pass; reversed handedness and collapsed-UV copies are rejected.
The final loaded-family run passes30041/0 in74.60s with empty stderr and clean
shutdown. Source-bound **family_outcome.json** is explicitly INERT,not a schema2
production contract. No native mesh,material,physics or gameplay owner is edited.

Reader NEW0 and spatial PASS. Existing full physical qualification remains
PASS0 against the unchanged rendering projection; no repeat composed survey is
claimed. Remaining legacy full-programme window-count,main-wall continuity,
angled-pane and body-LOD assumptions are open. This does not close
**K-V2-CITY-LEGACY-QUAL** or any stutter,save,whole-city or artistic requirement.
Original failures,all three executed sources,controls and raw receipts are in
**art/reviews/city_streets_20261029/legacy_roof_review_20261101.zip**:
{archive_members}members/{archive_bytes:,}bytes/SHA256 **{archive_hash}**.
Complete candidate verification and merge remain pending.
'''
atomic(path,text,before)
path=root/'TASKS.md';before=path.read_bytes();lines=before.decode().replace('\r\n','\n').splitlines(keepends=True)
indices=[i for i,line in enumerate(lines) if line.startswith('- **K-V2-CITY-LEGACY-QUAL —')];assert len(indices)==1
lines[indices[0]]='- **K-V2-CITY-LEGACY-QUAL — Canonical Codex: finish reconciling old full-survey checks with current native construction.** Roof receiving planes and thin-ground derivative checks repaired in a loaded-family candidate:30011/33 →30034/1 →30041/0,with four actual roof-mutation pairs and two tangent/UV mutation pairs; unchanged tolerances/native assets,readerNEW0/spatialPASS,existing physical qualification stillPASS. Candidate verification/merge pending. Next trace the2500-window threshold against2489 authored rows,main-wall continuity/angled-pane predicates and body-LOD inventory/material assumptions to actual stock; add rejecting controls before replacement. No new geometry or whole-city acceptance. [Current evidence and original failures](design/V2_CITY_CONTEXT_REPORT_2026-10-19.md#november-1--retained-roof-and-ground-derivative-diagnostic-repair).\n'
text=''.join(lines).replace('modeler reports18 INERT deliveries','modeler reports19 INERT deliveries').replace('night-register rule and projector mechanism packets','night-register rule,projector mechanism and media AC-supply packets')
atomic(path,text,before)
path=root/'HANDOFF.md';before=path.read_bytes();text=before.decode().replace('\r\n','\n')
marker='---\n\n# Historical merged-range handoff';assert text.count(marker)==1;history=text[text.index(marker):]
header=f'''# Current handoff - November 1 city qualification repair

Evidence class: **INERT**. Continuity index,not production acceptance.

Canonical branch **codex/v2-city-qualification-20261101** starts at pushed main
**32f59b0a48e210d07fe21b50fe4530986081c121**. PR132 is merged; completed
intake evidence remains in the city ledger/current_main_intake archive.
Current change is test-only **v2_city_horizon_bench.gd**,plus records/archive;
no native mesh,material,physics or gameplay owner was changed.

- Actual family before30011/33; roof-only30034/1; final30041/0,74.60s,
  empty stderr/clean shutdown,native3440x1440 hidden desktop. Four actual roof
  displacement/removal pairs and two handedness/collapsed-UV pairs reject bad
  stock. Unknown styles refused; original distance/metric/tangent guards stay.
- Reuses existing scalar-double Western ground checker as detached,freed helpers;
  no second world. Source-bound family JSON is INERT,not runtime qualification.
- ReaderNEW0/spatialPASS; official physical qualification remainsPASS0 at the
  unchanged **0a9d049d29aa2de3cfe17880548062cfb61a8d1e5bca705f5e198b4dc4d83062**.
  No repeated full-world/hose routes. Whole-game baseline failures remain.
- Evidence **art/reviews/city_streets_20261029/legacy_roof_review_20261101.zip**:
  {archive_members}members/{archive_bytes:,}bytes/SHA256 **{archive_hash}**.
  External programme/logs: **C:/ov/reports/city_qualification_repair_20261101/**.
- Main32 complete119-gate clean baseline is actually cached in **C:/ov/boards/**;
  owned **C:/ov/c-ab46a508** is clean/detached at32f59b0a4. Baseline session75121
  and all roof diagnostic sessions are terminal. Reuse this checkout for candidate
  verification,then safely remove it; preserve other contributors' worktrees.

NEXT: commit/push this coherent candidate and complete clean verification before
main merge. **K-V2-CITY-LEGACY-QUAL** remains open: full-programme window count,
wall continuity/angled panes and body-LOD inventory/material assumptions still
need real-stock checks and rejecting controls. Then resume playable-world stutter
and existing hose/book/nook gaps. Keep the full V2 goal active/incomplete.
Architect **C:/ov/city** owns one isolated P1/P2 batch; avoid duplicate geometry.
Modeler reports19 external INERT packets in the existing NATIVE_INTAKE_INDEX;
new media AC supply is queued,not independently accepted or installed. Preserve
untracked UIDs/attachments and non-owned import edits. No new prototype intake.

'''
atomic(path,header+history,before)
(out/'roof_checkpoint_archive.json').write_text(json.dumps({'evidence_class':'INERT','archive':archive.relative_to(root).as_posix(),'members':archive_members,'bytes':archive_bytes,'sha256':archive_hash},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'archive_members':archive_members,'archive_bytes':archive_bytes,'archive_sha256':archive_hash}))
