# Candidate verification - 41aaffbdfc36

- candidate `41aaffbdfc360525c45e868d8284fe8369a99cba`
- base `3ea80715bd201738d5566dea18bc17d4353ca867`
- merge-base `3ea80715bd201738d5566dea18bc17d4353ca867`
- verified 2026-10-30T12:57:53Z from verifier `41aaffbdfc36`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 7 regressions, 0 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 3 |

## Blocking reasons (7)

- regression: spatial: drift.new_reported 0 -> 1
- regression: spatial: new defect new_reported:0bca6d3189b7048c
- regression: v2_surface_qualification: PASS -> FAIL (exit 0 -> 1)
- regression: v2_surface_qualification: defects 0 -> 3
- regression: v2_surface_qualification: new defect missing or stale rendered review
- regression: v2_surface_qualification: new defect runtime contract does not bind the current surface test
- regression: v2_surface_qualification: new defect stale surface qualification: rendering inputs changed

## Needs human review (not blocking) (3)

- candidate changes 3 gate file(s); read those diffs before trusting the board
- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (7)

- spatial: drift.new_reported 0 -> 1
- spatial: new defect new_reported:0bca6d3189b7048c
- v2_surface_qualification: PASS -> FAIL (exit 0 -> 1)
- v2_surface_qualification: defects 0 -> 3
- v2_surface_qualification: new defect missing or stale rendered review
- v2_surface_qualification: new defect runtime contract does not bind the current surface test
- v2_surface_qualification: new defect stale surface qualification: rendering inputs changed

## Accepted regressions (0)

- none

## Improvements (0)

- none

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (3)

- M tools/orison_spatial_dependency_manifest.json
- M tools/tests/test_city_ground_apron.py
- M tools/tests/test_v2_surface_requirements.py

BLOCKED regression: spatial: drift.new_reported 0 -> 1; regression: spatial: new defect new_reported:0bca6d3189b7048c; regression: v2_surface_qualification: PASS -> FAIL (exit 0 -> 1) (+4 more)
