from pathlib import Path
import json,hashlib,zipfile
root=Path('C:/ov/city');out=Path(__file__).parent
assert (out/'native_inspection_04.json').is_file()
dest=root/'art/reviews/city_streets_20261029/northern_houses_native_review.zip';assert not dest.exists()
stored={}
for p in sorted(out.rglob('*')):
    if p.is_file() and p.suffix in ['.py','.json','.log','.png'] and '__pycache__' not in p.parts:stored['execution/'+p.relative_to(out).as_posix()]=p.read_bytes()
for relative in ['art/blender/scripts/build_city_horizon.py','art/blender/scripts/city_residential_architecture.py','art/data/city_horizon/source_plan.json']:
    stored['final/'+relative]=(root/relative).read_bytes()
assets=['art/blender/city_horizon_near.blend','art/blender/city_horizon_far.blend','art/blender/city_horizon_lod1.blend','art/blender/city_horizon_construction.json','game/assets/props/city_horizon_near.glb','game/assets/props/city_horizon_far.glb','game/assets/props/city_horizon_lod1.glb','game/data/orison_v2/exterior/city_horizon.json','game/tests/fixtures/orison_city_horizon.json']
bindings={p:dict(bytes=(root/p).stat().st_size,sha256=hashlib.sha256((root/p).read_bytes()).hexdigest()) for p in assets}
scope='Native house geometry/PBR/UV/full-body LOD review and original failures;24 inspected PNGs. No loaded Godot/runtime,mipmap,collision/access,rendering-cost or artistic acceptance.'
index=dict(evidence_class='INERT',scope=scope,sourcebase='ed59c7a990ce1601662885fbb6a35ed83d15a06d',assets=bindings,members={k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in stored.items()})
stored['archive_index.json']=json.dumps(index,indent=2).encode('utf-8')
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
    for k,v in stored.items():z.writestr(k,v,compress_type=zipfile.ZIP_STORED if k.endswith('.png') else zipfile.ZIP_DEFLATED,compresslevel=1)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None and set(z.namelist())==set(stored)
    for k,v in stored.items():assert z.read(k)==v,k
record=dict(evidence_class='INERT',scope=scope,archive=dest.relative_to(root).as_posix(),bytes=dest.stat().st_size,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),member_count=len(stored),asset_bindings=bindings)
manifest_path=root/'art/reviews/city_streets_20261029/manifest.json';manifest=json.loads(manifest_path.read_text());assert 'northern_houses_native_archive' not in manifest
manifest['northern_houses_native_archive']=record;manifest_path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'archive_record_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
path=root/'design/V2_CITY_CONTEXT_REPORT_2026-10-19.md';text=path.read_text(encoding='utf-8');text+='\n\nFrozen northern native packet: **'+record['archive']+'**, '+str(record['member_count'])+'members/'+str(record['bytes'])+'bytes/SHA256 **'+record['sha256']+'**. CRC/every stored member verified;no blend/glTF/reference-photo duplicate is stored. Prior eastern street,row andindustrial archives remain unchanged. This native checkpoint does not promote runtime or artistic status.\n';path.write_text(text,encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in record.items() if k!='asset_bindings'}),flush=True)
