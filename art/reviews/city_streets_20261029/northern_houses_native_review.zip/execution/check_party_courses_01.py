from pathlib import Path
import sys,json,importlib.util
root=Path('C:/ov/city');out=Path(__file__).parent
sys.path.insert(0,str(root/'art/blender/scripts'))
plan=json.loads((root/'art/data/city_horizon/source_plan.json').read_text());results=[]
for label,path in [('original',out/'executed_05_city_residential_architecture.py'),('repaired',root/'art/blender/scripts/city_residential_architecture.py')]:
    spec=importlib.util.spec_from_file_location('courses_'+label,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    bounds=[]
    for i in [1,2]:
        row=next(r.copy() for r in plan['buildings'] if r['id']==f'HORIZON_NEAR_0_1_P0R{i}');row['grade_datum_m']=0.;eave=sum(row['architecture']['floor_heights_m'][:-1]);candidates=[]
        def emit(owner,key,vertices,faces):
            if key=='door_paint' and len(vertices)==16 and abs(min(v[2] for v in vertices)-(eave-.16))<1e-5 and abs(max(v[2] for v in vertices)-(eave+.10))<1e-5:candidates.append(vertices)
        module.ResidentialHouses(row,emit,[r for r in plan['buildings'] if r['id']!=row['id']],lower=True).build()
        assert len(candidates)==1
        vertices=candidates[0];bounds.append([min(v[0] for v in vertices),max(v[0] for v in vertices)])
    overlap=min(b[1] for b in bounds)-max(b[0] for b in bounds)
    if label=='original':assert overlap>.50
    else:assert abs(overlap)<.00002
    results.append(dict(source=label,actual_course_x_bounds=bounds,overlap_m=overlap))
path=out/'party_courses_01.json';assert not path.exists();path.write_text(json.dumps(dict(evidence_class='INERT',scope='Actual closed eave-course stock projection at the shared parcel plane. Original overlapping-course control retained;not rendering/flicker or structural rating.',results=results),indent=2),encoding='utf-8',newline='\n');print(results)
