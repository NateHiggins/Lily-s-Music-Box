from pathlib import Path
import ast,json,struct,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent
reader=out.parent/'bodega_frontage_reconciliation_01/check_preservation_01.py'
tree=ast.parse(reader.read_text(encoding='utf-8-sig'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(reader),'exec'))
plan_path=root/'art/data/city_horizon/source_plan.json';raw=plan_path.read_bytes();plan=json.loads(raw)
targets=[f'HORIZON_NEAR_0_1_P0R{i}' for i in range(3)]
assert not (out/'baseline_01.json').exists()
families=['city_horizon_near','city_horizon_far','city_horizon_lod1']
others=['city_elevations','city_elevations_lod1','city_streets','city_streets_lod1','city_transport','city_transport_lod1','city_ground_apron','orison_ground','front_pavement','bodega_receiving']
baseline=dict(evidence_class='INERT',sourcebase='ed59c7a990ce1601662885fbb6a35ed83d15a06d',targets=targets,parts={f:projection((root/f'game/assets/props/{f}.glb').read_bytes()) for f in families},other_assets={f'game/assets/props/{f}.glb':hashlib.sha256((root/f'game/assets/props/{f}.glb').read_bytes()).hexdigest() for f in others},profiles=plan['buildings'])
(out/'baseline_01.json').write_text(json.dumps(baseline,indent=2),encoding='utf-8',newline='\n')
(out/'source_plan_before_01.json').write_bytes(raw)
specs=[('italianate_2109','21-09 45th Avenue;1871–72 Root/Rust brick Italianate with stuccoed basement','arcade_brick_bond',[.75,.61,.48,1]),
       ('mansard_2153','21-53 45th Avenue;1880s brick French Second Empire,slate mansard,two dormers','arcade_brick_bond',[.72,.60,.49,1]),
       ('gable_2136','21-36 45th Avenue;1890 timber Queen Anne,simplified coupled windows andsteep gable','door_paint',[.47,.53,.43,1])]
for target,(style,precedent,key,tint) in zip(targets,specs):
    row=next(r for r in plan['buildings'] if r['id']==target)
    assert 'architecture' not in row
    a,b,c,d=row['rect']
    row.update(wall_key=key,wall_tint=tint,architecture=dict(type='residential_front',style=style,precedent=precedent,source='https://s-media.nyc.gov/agencies/lpc/lp/0450.pdf',source_pages=[3,4,5],floor_heights_m=[.9,3.15,3.,3.],front_inset_m=1.6,outline_m=[[c,d-1.6],[a,d-1.6],[a,b],[c,b]],scope='AU dimensional adaptation within retained6.667×20m parcel,not measured replica. 21-36 painted timber cladding is authored:1968 asbestos finish is not1928 proof. No occupied interior or new authority.'))
plan_path.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
print('BASELINE preserved;three source profiles authored;no generated products changed')
