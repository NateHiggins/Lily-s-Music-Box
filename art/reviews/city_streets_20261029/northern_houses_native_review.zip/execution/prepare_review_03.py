from pathlib import Path
out=Path(__file__).parent
source=(out/'review_native_02.py').read_text(encoding='utf-8').replace("/'native_review_02'","/'native_review_03'")
source=source.replace('    for identity in chosen:\n','    for identity in chosen:\n        if identity!=IDS[2]:continue\n')
position=source.index('for path,expected in bindings.items():')
context='''    visible=list(imported.values())
    for obj in visible:obj.hide_render=False
    camera.location=(-35.,120.,20.);camera.rotation_euler=(Vector((-56.,158.,5.))-camera.location).to_track_quat('-Z','Y').to_euler()
    camera.data.type='ORTHO';camera.data.ortho_scale=36.;scene.render.resolution_x=1400;scene.render.resolution_y=900
    for attempt in range(24):
        bpy.context.view_layer.update();points=[world_to_camera_view(scene,camera,obj.matrix_world@Vector(corner)) for obj in visible for corner in obj.bound_box]
        framed=all(p.z>0 and .035<=p.x<=.965 and .035<=p.y<=.965 for p in points)
        if framed:break
        camera.data.ortho_scale*=1.12
    assert framed,'row context framing'
    path=OUT/(family+'_row_context.png');scene.render.filepath=str(path);bpy.ops.render.render(write_still=True)
    captures.append(dict(path=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),family=family,building='ROW_CONTEXT',whole_body_framed=True,intentional_detail_crop=False))
'''
source=source[:position]+context+source[position:]
source=source.replace('len(captures)==10','len(captures)==5')
path=out/'review_native_03.py';assert not path.exists();path.write_text(source,encoding='utf-8',newline='\n')
source=(out/'run_native_review_02.py').read_text(encoding='utf-8').replace('_02','_03')
path=out/'run_native_review_03.py';assert not path.exists();path.write_text(source,encoding='utf-8',newline='\n')
