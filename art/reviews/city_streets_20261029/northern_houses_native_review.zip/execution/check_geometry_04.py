from pathlib import Path
import sys,json,collections,hashlib
import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree
root=Path('C:/ov/city');out=Path(__file__).parent
sys.path.insert(0,str(root/'art/blender/scripts'))
from city_residential_architecture import ResidentialHouses
plan=json.loads((root/'art/data/city_horizon/source_plan.json').read_text())
styles=['italianate_2109','mansard_2153','gable_2136'];results=[]
for i,style in enumerate(styles):
    row=next(r.copy() for r in plan['buildings'] if r['id']==f'HORIZON_NEAR_0_1_P0R{i}')
    row.update(grade_datum_m=0.,wall_key='door_paint' if i==2 else 'arcade_brick_bond',architecture=dict(style=style,floor_heights_m=[.9,3.15,3.,3.],front_inset_m=1.6,side_bays=[3,6,3,6]))
    levels=[]
    for lower in [False,True]:
        buf=collections.defaultdict(lambda:([],[]))
        def emit(owner,key,vertices,faces):
            vv,ff=buf[key];start=len(vv);vv.extend(vertices);ff.extend(tuple(start+j for j in f) for f in faces)
        result=ResidentialHouses(row,emit,[r for r in plan['buildings'] if r['id']!=row['id']],lower).build()
        vertices=[];faces=[];owners=[]
        for key,(vv,ff) in buf.items():
            start=len(vertices);vertices.extend(vv);faces.extend(tuple(start+j for j in f) for f in ff);owners.extend([key]*len(ff))
        bvh=BVHTree.FromPolygons(vertices,faces,all_triangles=False)
        for w in result['windows']:
            p=Vector(w['point']);n=Vector(w['normal']);hit,normal,index,d=bvh.ray_cast(p+n*.05,-n,.30)
            assert hit is not None and owners[index]=='mirror_aged' and (hit-(p-n*.17)).length<.0001,(row['id'],lower,w,owners[index] if index is not None else None)
        vv,ff=buf['galvanized_roof'];roof=BVHTree.FromPolygons(vv,ff,all_triangles=False)
        for seat in result['bearings']:
            p=Vector(seat['point']);hit,n,index,d=roof.ray_cast(p+Vector((0,0,.02)),Vector((0,0,-1)),.04)
            assert hit is not None and (hit-p).length<.0001,(row['id'],lower,'roof',seat)
            p=Vector(seat['outside_probe']);hit,n,index,d=roof.ray_cast(p+Vector((0,0,.02)),Vector((0,0,-1)),.04)
            assert hit is None,(row['id'],lower,'outside',seat)
        levels.append(dict(lower=lower,triangles=sum(len(f)-2 for f in faces),stocks=result['closed_stocks'],panes=len(result['windows']),roof_seats=len(result['bearings']),entries=result['entries'],parts=sorted(buf)))
    assert levels[1]['triangles']<levels[0]['triangles'] and levels[0]['panes']==levels[1]['panes'] and levels[0]['entries']==levels[1]['entries']
    results.append(dict(id=row['id'],style=style,levels=levels))
record=dict(evidence_class='INERT',scope='Unsaved native construction diagnostics only. No source plan/product replacement,export,UV,render,Godot or artistic acceptance.',blender=bpy.app.version_string,results=results,failures=[])
path=out/'geometry_04.json';assert not path.exists();path.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n');print(json.dumps(record),flush=True)
