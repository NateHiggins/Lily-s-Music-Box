from pathlib import Path
out=Path(__file__).parent
source=(out/'run_native_build_04.py').read_text(encoding='utf-8').replace('_04','_05')
path=out/'run_native_build_05.py';assert not path.exists();path.write_text(source,encoding='utf-8',newline='\n')
for name in ['verify_export_uv_04.py','check_preservation_04.py']:
    source=(out/name).read_text(encoding='utf-8').replace('uv_audit_04','uv_audit_05').replace('uv_source_binding_04','uv_source_binding_05').replace('preservation_04.json','preservation_05.json')
    path=out/name.replace('_04','_05');assert not path.exists();path.write_text(source,encoding='utf-8',newline='\n')
