from pathlib import Path
import ast,json,struct,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent
reader=out.parent/'bodega_frontage_reconciliation_01/check_preservation_01.py'
tree=ast.parse(reader.read_text(encoding='utf-8-sig'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(reader),'exec'))
baseline=json.loads((out/'baseline_01.json').read_text());report=dict(evidence_class='INERT',parts={},other_assets={},failures=[])
for family,old in baseline['parts'].items():
    new=projection((root/f'game/assets/props/{family}.glb').read_bytes())
    keep={k:v for k,v in old.items() if k.split('__')[0] not in baseline['targets']}
    changed=[k for k,v in keep.items() if new.get(k)!=v]
    added=sorted(set(new)-set(old));removed=sorted(set(old)-set(new))
    report['parts'][family]=dict(preserved=len(keep)-len(changed),changed=changed,added=added,removed=removed)
    report['failures'].extend(changed)
for path,expected in baseline['other_assets'].items():
    actual=hashlib.sha256((root/path).read_bytes()).hexdigest();report['other_assets'][path]=actual
    if actual!=expected:report['failures'].append(path)
plan=json.loads((root/'art/data/city_horizon/source_plan.json').read_text())
old={r['id']:r for r in baseline['profiles']};new={r['id']:r for r in plan['buildings']}
assert set(new)==set(old)
assert all(new[k]['rect']==v['rect'] for k,v in old.items())
assert all(new[k]==v for k,v in old.items() if k not in baseline['targets'])
report['preserved_other_profiles']=len(old)-3;report['preserved_parcel_rectangles']=len(old)
path=out/'preservation_05.json';assert not path.exists();path.write_text(json.dumps(report,indent=2),encoding='utf-8',newline='\n');print(json.dumps(report));assert not report['failures']
