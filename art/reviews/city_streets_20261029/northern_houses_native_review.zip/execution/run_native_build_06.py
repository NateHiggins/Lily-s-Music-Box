from pathlib import Path
import subprocess,os,json,time,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent
env=os.environ.copy()
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:env[key]='2'
paths=['art/blender/scripts/build_city_horizon.py','art/blender/scripts/city_residential_architecture.py','art/blender/scripts/city_industrial_architecture.py','art/data/city_horizon/source_plan.json']
bindings={p:hashlib.sha256((root/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in paths}
for p in paths:(out/('executed_06_'+Path(p).name)).write_bytes((root/p).read_bytes())
assert not (out/'native_build_06.json').exists()
started=time.time();timed_out=False
with (out/'build_city_horizon_06.log').open('xb') as log:
    process=subprocess.Popen(['C:/Program Files/Blender Foundation/Blender 5.2/blender.exe','-b','-t','2','--python-exit-code','1','-P',str(root/paths[0])],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    (out/'native_process_06.json').write_text(json.dumps(dict(pid=process.pid,started_epoch=started,ceiling_s=240),indent=2),encoding='utf-8',newline='\n');print('OWNED BLENDER PID',process.pid,flush=True)
    try:code=process.wait(timeout=240)
    except subprocess.TimeoutExpired:
        timed_out=True;process.terminate();process.wait(timeout=15);code=124
record=dict(evidence_class='INERT',scope='Native generation/export only;no rendering,Godot or artistic acceptance.',pid=process.pid,exit_code=code,timed_out=timed_out,seconds=time.time()-started,source_sha256=bindings)
(out/'native_build_06.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n');print(record,flush=True);raise SystemExit(code)
