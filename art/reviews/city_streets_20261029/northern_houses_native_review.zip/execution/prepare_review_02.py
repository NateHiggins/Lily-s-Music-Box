from pathlib import Path
out=Path(__file__).parent
for name in ['review_native_01.py','run_native_review_01.py']:
    source=(out/name).read_text(encoding='utf-8').replace('_01','_02')
    path=out/name.replace('_01','_02');assert not path.exists();path.write_text(source,encoding='utf-8',newline='\n')
for name in ['verify_export_uv_01.py','check_preservation_01.py']:
    source=(out/name).read_text(encoding='utf-8').replace('uv_audit_01','uv_audit_04').replace('uv_source_binding_01','uv_source_binding_04').replace('preservation_01.json','preservation_04.json')
    path=out/name.replace('_01','_04');assert not path.exists();path.write_text(source,encoding='utf-8',newline='\n')
