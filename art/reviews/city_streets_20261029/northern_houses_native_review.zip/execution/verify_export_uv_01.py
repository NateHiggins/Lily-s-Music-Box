from pathlib import Path
import subprocess,json,hashlib,time
root=Path('C:/ov/city');out=Path(__file__).parent
paths=[f'game/assets/props/{name}.glb' for name in ['city_horizon_near','city_horizon_far','city_horizon_lod1']]
before={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths};started=time.time()
target=out/'uv_audit_01.json';assert not target.exists()
result=subprocess.run(['python','tools/audit_glb_surface_uvs.py',*paths,'--out',str(target)],cwd=root,capture_output=True,text=True)
after={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths};assert before==after
(out/'uv_audit_01.log').write_text(result.stdout+result.stderr,encoding='utf-8',newline='\n')
audit=json.loads(target.read_text());assert result.returncode==0 and not any(a['failures'] for a in audit['assets'])
(out/'uv_source_binding_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Read-only source GLB UV audit;not loaded Godot precision or optical acceptance.',elapsed_s=time.time()-started,exit_code=result.returncode,asset_sha256=before,audit_sha256=hashlib.sha256(target.read_bytes()).hexdigest()),indent=2),encoding='utf-8',newline='\n')
print(result.stdout,flush=True)
