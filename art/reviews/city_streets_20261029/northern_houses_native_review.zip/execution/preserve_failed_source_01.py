from pathlib import Path
import json,hashlib
out=Path(__file__).parent;root=Path('C:/ov/city')
path=root/'art/blender/scripts/city_residential_architecture.py'
text=path.read_text(encoding='utf-8').replace("self.profile('timber',O,U,N,[(l,z),(r,z),(r,Z),(l,Z)],back,front)","self.stock('timber',O,U,N,lo,hi,0)")
data=text.encode('utf-8');expected=json.loads((out/'native_build_01.json').read_text())['source_sha256']['art/blender/scripts/city_residential_architecture.py']
assert hashlib.sha256(data).hexdigest()==expected
target=out/'failed_build_01_exact_reconstruction.py';assert not target.exists();target.write_bytes(data)
note=dict(evidence_class='INERT',scope='First build execution snapshot was overwritten by wrapper02. This helper is reconstructed by reverting the single panel fix and verified exactly against the original execution LF SHA256;not claimed an original saved snapshot.',sha256=expected)
(out/'failed_source_recovery_01.json').write_text(json.dumps(note,indent=2),encoding='utf-8',newline='\n')
