from pathlib import Path
out=Path(__file__).parent
for name in ['run_native_build_05.py','verify_export_uv_05.py','check_preservation_05.py']:
    source=(out/name).read_text(encoding='utf-8').replace('_05','_06')
    path=out/name.replace('_05','_06');assert not path.exists();path.write_text(source,encoding='utf-8',newline='\n')
source=(out/'review_native_03.py').read_text(encoding='utf-8').replace("/'native_review_03'","/'native_review_04'")
source=source.replace('        if identity!=IDS[2]:continue','        continue')
source=source.replace('len(captures)==5','len(captures)==2')
path=out/'review_native_04.py';assert not path.exists();path.write_text(source,encoding='utf-8',newline='\n')
source=(out/'run_native_review_03.py').read_text(encoding='utf-8').replace('_03','_04')
path=out/'run_native_review_04.py';assert not path.exists();path.write_text(source,encoding='utf-8',newline='\n')
