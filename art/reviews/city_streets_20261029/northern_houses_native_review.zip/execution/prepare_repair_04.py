from pathlib import Path
import json
out=Path(__file__).parent;root=Path('C:/ov/city')
path=root/'art/data/city_horizon/source_plan.json';plan=json.loads(path.read_text())
for i in range(3):
    row=next(r for r in plan['buildings'] if r['id']==f'HORIZON_NEAR_0_1_P0R{i}')
    row['architecture']['side_bays']=[3,6,3,6]
    row['joinery_tint']=[.23,.26,.20,1] if i!=2 else [.47,.53,.43,1]
path.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
source=(out/'run_native_build_03.py').read_text(encoding='utf-8').replace('_03','_04')
path=out/'run_native_build_04.py';assert not path.exists();path.write_text(source,encoding='utf-8',newline='\n')
source=(out/'check_geometry_02.py').read_text(encoding='utf-8').replace('geometry_02.json','geometry_04.json').replace("front_inset_m=1.6)","front_inset_m=1.6,side_bays=[3,6,3,6])")
path=out/'check_geometry_04.py';assert not path.exists();path.write_text(source,encoding='utf-8',newline='\n')
