from pathlib import Path
out=Path(__file__).parent
for name in ['build_city_horizon.py','city_residential_architecture.py','city_industrial_architecture.py','source_plan.json']:
    original=out/('executed_'+name);target=out/('executed_02_'+name);assert not target.exists();target.write_bytes(original.read_bytes())
source=(out/'run_native_build_01.py').read_text(encoding='utf-8').replace('_01','_03').replace("'executed_'+Path(p).name","'executed_03_'+Path(p).name")
path=out/'run_native_build_03.py';assert not path.exists();path.write_text(source,encoding='utf-8',newline='\n')
