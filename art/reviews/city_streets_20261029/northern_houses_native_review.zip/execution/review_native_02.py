"""Read-only native/export roundtrips and bounded CPU-only architectural views."""
from pathlib import Path
import bpy,collections,json,hashlib,os
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from bpy_extras.object_utils import world_to_camera_view
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent/'native_review_02';OUT.mkdir(exist_ok=False)
IDS=['HORIZON_NEAR_0_1_P0R0','HORIZON_NEAR_0_1_P0R1','HORIZON_NEAR_0_1_P0R2']
profiles={r['id']:r for r in json.loads((ROOT/'art/data/city_horizon/source_plan.json').read_text())['buildings']}
construction=json.loads((ROOT/'art/blender/city_horizon_construction.json').read_text())
captures=[];roundtrips=[];bindings={};contacts=[]
def triangles(obj):
    obj.data.calc_loop_triangles()
    return collections.Counter(tuple(sorted(tuple(float(c) for c in obj.matrix_world@obj.data.vertices[i].co) for i in t.vertices)) for t in obj.data.loop_triangles)
for family,collection,chosen in [('city_horizon_near','CityHorizon_near',IDS),('city_horizon_lod1','CityHorizonReplacementBodies',IDS)]:
    native=ROOT/f'art/blender/{family}.blend';bindings[native.relative_to(ROOT).as_posix()]=hashlib.sha256(native.read_bytes()).hexdigest();bpy.ops.wm.open_mainfile(filepath=str(native))
    original=[o for o in bpy.data.collections[collection].objects if o.name.split('__')[0] in chosen]
    expected={o.name:triangles(o) for o in original};mats={o.name:o.data.materials[0] for o in original}
    for obj in bpy.context.scene.objects:
        if obj.type=='MESH':obj.hide_render=True
    asset=ROOT/f'game/assets/props/{family}.glb';bindings[asset.relative_to(ROOT).as_posix()]=hashlib.sha256(asset.read_bytes()).hexdigest()
    before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(asset));bpy.context.view_layer.update();imported={}
    for obj in [o for o in bpy.data.objects if o not in before and o.type=='MESH']:
        name=obj.name.split('.')[0];obj.hide_render=name not in expected
        if obj.hide_render:continue
        assert triangles(obj)==expected[name],(family,name,'native/export positions differ')
        assert len(obj.data.uv_layers)==1
        obj.data.materials.clear();obj.data.materials.append(mats[name]);imported[name]=obj
        roundtrips.append(dict(family=family,part=name,triangles=sum(expected[name].values()),exact_float32_positions=True))
    assert imported.keys()==expected.keys()
    if family=='city_horizon_lod1':
        trees={name:BVHTree.FromPolygons([obj.matrix_world@v.co for v in obj.data.vertices],[tuple(f.vertices) for f in obj.data.polygons],all_triangles=True) for name,obj in imported.items()}
        for row in construction['parapet_contacts']:
            if row['building'] not in IDS:continue
            name=row['building'];p=Vector(row['point']);roof=trees[name+'__galvanized_roof'];stock=trees[name+'__'+row['wall_key']]
            hit,n,index,distance=roof.ray_cast(p+Vector((0,0,.02)),Vector((0,0,-1)),.04)
            assert hit is not None and (hit-p).length<.0001,('lower roof seat',row)
            profile=profiles[name];eave=sum(profile['architecture']['floor_heights_m'][:-1]) if profile['architecture']['style']!='italianate_2109' else profile['height_m']
            support=Vector((p.x,p.y,eave+next(r['assembly_datum_m'] for r in construction['grade_seats'] if r['building']==name)))
            hit,n,index,distance=stock.ray_cast(support+Vector((0,0,.02)),Vector((0,0,-1)),.04)
            assert hit is not None and (hit-support).length<.0001,('lower actual wall bearing top',row)
            outside=Vector(row['outside_probe']);hit,n,index,distance=roof.ray_cast(outside+Vector((0,0,.02)),Vector((0,0,-1)),.04)
            assert hit is None,('lower outside control',row)
            contacts.append(row)
    for image in bpy.data.images:
        if image.source!='FILE' or image.packed_file:continue
        path=ROOT/'game/assets/building/textures'/Path(image.filepath).name;assert path.is_file(),path
        image.filepath=str(path);image.reload();assert min(image.size)>0
    scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.cycles.use_denoising=True;scene.cycles.max_bounces=4
    scene.render.threads_mode='FIXED';scene.render.threads=2;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX';scene.render.resolution_percentage=100
    world=bpy.data.worlds.new('Eastern block review');world.use_nodes=True;scene.world=world;world.node_tree.nodes['Background'].inputs[0].default_value=(.18,.21,.27,1);world.node_tree.nodes['Background'].inputs[1].default_value=.7
    sun=bpy.data.objects.new('Review key',bpy.data.lights.new('Review key','SUN'));scene.collection.objects.link(sun);sun.rotation_euler=Vector((-1.,.35,-.9)).to_track_quat('-Z','Y').to_euler();sun.data.energy=2.5;sun.data.angle=.15
    camera=bpy.data.objects.new('Native review camera',bpy.data.cameras.new('Native review camera'));scene.collection.objects.link(camera);scene.camera=camera;camera.data.clip_start=.02
    for identity in chosen:
        row=profiles[identity];a,b,c,d=row['rect'];x=(a+c)*.5;y=-(b+d)*.5;h=row['height_m']
        views=[('whole',(x+18,-d-24,h*.95),(x,y,h*.48),max(h+4,d-b),(1100,850),False)]
        if family!='city_horizon_lod1':
            views.append(('facade',(x+1,-d-16,h*.57),(x,-d+1.6,h*.48),h+2.5,(1100,900),True))
            if identity==IDS[1]:views.append(('mansard_dormers',(x+6,-d-8,11.0),(x,-d+2.6,8.5),8.,(1100,950),True))
        visible=[obj for name,obj in imported.items() if name.startswith(identity+'__')]
        for name,obj in imported.items():obj.hide_render=obj not in visible
        for label,eye,aim,scale,res,detail in views:
            camera.location=eye;camera.rotation_euler=(Vector(aim)-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO';camera.data.ortho_scale=scale
            scene.render.resolution_x,scene.render.resolution_y=res;framed=None
            if not detail:
                for attempt in range(24):
                    bpy.context.view_layer.update();points=[world_to_camera_view(scene,camera,obj.matrix_world@Vector(corner)) for obj in visible for corner in obj.bound_box]
                    framed=all(p.z>0 and .035<=p.x<=.965 and .035<=p.y<=.965 for p in points)
                    if framed:break
                    camera.data.ortho_scale*=1.12
                assert framed,(family,identity,'whole framing')
            path=OUT/(identity+'_'+family+'_'+label+'.png');scene.render.filepath=str(path);bpy.ops.render.render(write_still=True)
            captures.append(dict(path=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),family=family,building=identity,whole_body_framed=framed,intentional_detail_crop=detail))
for path,expected in bindings.items():assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==expected,path
assert len(roundtrips)==56 and len(contacts)==8 and len(captures)==10,(len(roundtrips),len(contacts),len(captures))
(OUT/'review.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Read-only native geometry/UV/PBR/whole replacement-body presentation. Not loaded Godot surfaces,street support,played access,performance or artistic acceptance.',sources_unchanged=bindings,roundtrips=roundtrips,lower_roof_and_actual_bearing_controls=contacts,captures=captures),indent=2),encoding='utf-8',newline='\n')
print('EASTERN NATIVE REVIEW COMPLETE',len(roundtrips),'roundtrips',len(contacts),'roof/bearing/outside controls',len(captures),'images',flush=True)
