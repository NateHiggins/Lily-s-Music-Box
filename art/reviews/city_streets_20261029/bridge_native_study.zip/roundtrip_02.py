import bpy,json,math
from pathlib import Path
from mathutils import Vector
p=Path("C:/ov/asset-prototypes/queensboro-bridge-20261030")
r=json.loads((p/"art/blender/city_bridge_construction.json").read_text())
rows=[]
for lod,name in enumerate(["city_bridge.glb","city_bridge_lod1.glb"]):
 bpy.ops.wm.read_factory_settings(use_empty=True)
 bpy.ops.import_scene.gltf(filepath=str(p/"game/assets/props"/name))
 objects=[o for o in bpy.context.scene.objects if o.type=="MESH"]
 points=[o.matrix_world@v.co for o in objects for v in o.data.vertices]
 for o in objects:o.data.calc_loop_triangles()
 triangles=sum(len(o.data.loop_triangles) for o in objects)
 assert triangles==r["exports"][lod]["triangles"],(name,triangles,r["exports"][lod])
 bounds=[min(v[i] for v in points) for i in range(3)]+[max(v[i] for v in points) for i in range(3)]
 stocks=[v["bounds"] for v in r["stocks"] if v["lod"]==lod]
 expected=[min(b[i] for b in stocks) for i in range(3)]+[max(b[i] for b in stocks) for i in range(3,6)]
 error=max(abs(a-b) for a,b in zip(bounds,expected));assert error<.001,(name,bounds,expected,error)
 assert all(math.isfinite(v) for b in [bounds,expected] for v in b)
 rows.append(dict(file=name,parts=len(objects),triangles=triangles,bounds=bounds,expected_stock_bounds=expected,max_bound_error_m=error))
Path("C:/ov/reports/city_streets_20261029/bridge_native_01/roundtrip_02.json").write_text(json.dumps(dict(evidence_class="INERT",scope="Actual Blender glTF reimport; total triangles and engineering-frame extent. Not loaded Godot material, seating, siting, access or artistic acceptance.",rows=rows,failures=[]),indent=2)+"\n")
print("BRIDGE REIMPORT PASS",rows,flush=True)
