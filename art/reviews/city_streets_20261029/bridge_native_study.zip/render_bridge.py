import bpy,json,math
from pathlib import Path
from mathutils import Vector
root=Path("C:/ov/asset-prototypes/queensboro-bridge-20261030")
out=Path("C:/ov/reports/city_streets_20261029/bridge_native_01/previews");out.mkdir(exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(root/"art/blender/city_bridge.blend"))
scene=bpy.context.scene;scene.render.engine="CYCLES";scene.cycles.device="CPU";scene.cycles.samples=12
scene.render.threads_mode="FIXED";scene.render.threads=2
scene.render.resolution_x=1600;scene.render.resolution_y=900;scene.render.resolution_percentage=100
scene.world=bpy.data.worlds.new("NeutralReview");scene.world.use_nodes=True
scene.world.node_tree.nodes["Background"].inputs[0].default_value=(.55,.63,.7,1)
scene.world.node_tree.nodes["Background"].inputs[1].default_value=.6
light=bpy.data.lights.new("ReviewSun","SUN");light.energy=3.;light.angle=.08
obj=bpy.data.objects.new("ReviewSun",light);scene.collection.objects.link(obj);obj.rotation_euler=(.5,-.3,-.7)
camdata=bpy.data.cameras.new("ReviewCamera");cam=bpy.data.objects.new("ReviewCamera",camdata);scene.collection.objects.link(cam);scene.camera=cam;camdata.clip_end=5000.
shots=[("whole_oblique",(1420,-1050,300),(567,0,40),36.,0),("whole_elevation",(567,-1500,115),(567,0,40),40.,0),("queens_tower",(1040,-85,95),(995.3244,0,60),40.,0),("queens_tower_lower",(1040,-85,95),(995.3244,0,60),40.,1)]
for name,eye,target,lens,lod in shots:
 bpy.data.collections["BridgeExports_LOD0"].hide_render=lod!=0
 bpy.data.collections["BridgeExports_LOD1"].hide_render=lod!=1
 cam.location=eye;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat("-Z","Y").to_euler();camdata.lens=lens
 scene.render.filepath=str(out/(name+".png"));bpy.ops.render.render(write_still=True)
print("BRIDGE CPU PREVIEWS COMPLETE; neutral native diagnostic only",flush=True)
