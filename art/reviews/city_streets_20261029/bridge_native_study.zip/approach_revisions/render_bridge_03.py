import bpy,json,math
from pathlib import Path
from mathutils import Vector
root=Path("C:/ov/asset-prototypes/queensboro-bridge-20261030")
out=Path("C:/ov/reports/city_streets_20261029/bridge_native_01/previews_03");out.mkdir(exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(root/"art/blender/city_bridge.blend"))
scene=bpy.context.scene;scene.render.engine="CYCLES";scene.cycles.device="CPU";scene.cycles.samples=12
scene.render.threads_mode="FIXED";scene.render.threads=2
scene.render.resolution_x=1600;scene.render.resolution_y=900;scene.render.resolution_percentage=100
scene.world=bpy.data.worlds.new("NeutralReview");scene.world.use_nodes=True
scene.world.node_tree.nodes["Background"].inputs[0].default_value=(.55,.63,.7,1)
scene.world.node_tree.nodes["Background"].inputs[1].default_value=.6
light=bpy.data.lights.new("ReviewSun","SUN");light.energy=3.;light.angle=.08
obj=bpy.data.objects.new("ReviewSun",light);scene.collection.objects.link(obj);obj.rotation_euler=(.5,-.3,-.7)
camdata=bpy.data.cameras.new("ReviewCamera");cam=bpy.data.objects.new("ReviewCamera",camdata);scene.collection.objects.link(cam);scene.camera=cam;camdata.clip_end=5000.
shots=[("whole_supported",(2650,-1950,900),(1030,160,20),38.,0),("approach_structure",(1460,-210,110),(1350,0,30),34.,0),("curved_continuation",(2150,70,75),(1920,210,18),34.,0),("approach_lower",(1460,-210,110),(1350,0,30),34.,1)]
for name,eye,target,lens,lod in shots:
 bpy.data.collections["BridgeExports_LOD0"].hide_render=lod!=0
 bpy.data.collections["BridgeExports_LOD1"].hide_render=lod!=1
 cam.location=eye;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat("-Z","Y").to_euler();camdata.lens=lens
 scene.render.filepath=str(out/(name+".png"));bpy.ops.render.render(write_still=True)
print("BRIDGE CPU PREVIEWS COMPLETE; neutral native diagnostic only",flush=True)
