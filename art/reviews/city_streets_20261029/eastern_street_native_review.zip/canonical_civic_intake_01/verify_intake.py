from pathlib import Path
import hashlib,io,json,subprocess,zipfile
R=Path('C:/PleaseRemainOnTheLine');O=Path(__file__).parent;REV='81d2988e'
def old(p):return subprocess.check_output(['git','show',REV+':'+p],cwd=R,stderr=subprocess.PIPE)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
raw=old('art/reviews/city_streets_20261029/eastern_civic_review.zip');assert len(raw)==57717402 and sha(raw)=='8c532f59d24ac76da6f8792c5a6274056d3392f72fb288b02d85e6c762311028'
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 assert len(z.namelist())==254 and z.testzip() is None
 index=json.loads(z.read('archive_index.json'))
 for name,row in index['members'].items():
  value=z.read(name);assert len(value)==row['bytes'] and sha(value)==row['sha256'],name
 for alias,row in index['byte_exact_reused_image_aliases'].items():assert sha(z.read(row['retained_member']))==row['sha256'],alias
 for p,row in index['assets'].items():
  value=old(p);assert len(value)==row['bytes'] and sha(value)==row['sha256'],p
 runtime_current_drift=[];external=[]
 for p,row in index['runtime_sources'].items():
  if (R/p).is_file():
   value=(R/p).read_bytes();current=sha(value.replace(b'\r\n',b'\n') if row['lf_normalized'] else value)
   if current==row['test_sha256']:continue
   runtime_current_drift.append(p)
  try:value=old(p)
  except subprocess.CalledProcessError:
   value=z.read('final/'+p);external.append(p)
  if row['lf_normalized']:value=value.replace(b'\r\n',b'\n')
  assert sha(value)==row['test_sha256'],p
 for name,expected in index['prior_unchanged_archives'].items():
  path='art/reviews/city_streets_20261029/'+name
  assert sha(old(path))==expected,name
  assert sha(subprocess.check_output(['git','show','05f5df70:'+path],cwd=R))==expected,name
 original_failures={}
 for name,count in [('execution/bench_01/civic_loaded.runtime.json',2),('execution/access_01/civic_access.runtime.json',10)]:
  d=json.loads(z.read(name));assert len(d['failures'])==count and d['evidence_kind']=='runtime_contract'
  original_failures[name]={'checks':d['checks'],'failures':len(d['failures']),'scope':d['scope']}
 contracts={}
 for name in ['execution/bench_02/civic_loaded.runtime.json','execution/access_02/civic_access.runtime.json']:
  d=json.loads(z.read(name));assert d['evidence_kind']=='runtime_contract' and d['schema_version']==2 and d['execution']['completed'] and d['execution']['exit_code']==0 and not d['execution']['timed_out'] and not d['failures']
  (O/Path(name).name).write_text(json.dumps(d,indent=2));contracts[name]={'checks':d['checks'],'scope':d['scope'],'execution':d['execution']}
 print('native images',[n for n in z.namelist() if n.endswith('.png') and 'native_review_01/' in n]);print('access images',[n for n in z.namelist() if n.endswith('.png') and '/access_02/' in n]);print('loaded image sample',[n for n in z.namelist() if n.endswith('.png') and '/bench_02/' in n][:10])
 record={'evidence_class':'INERT','checkpoint':REV,'archive_sha256':sha(raw),'members_verified':len(index['members']),'aliases_verified':len(index['byte_exact_reused_image_aliases']),'asset_bindings_verified':len(index['assets']),'runtime_source_bindings_verified':len(index['runtime_sources']),'canonical_drift_before_intake':runtime_current_drift,'external_test_sources':external,'original_contracts':contracts,'retained_failed_contracts':original_failures,'prior_archives_verified':len(index['prior_unchanged_archives']),'scope':'Frozen source/packet integrity audit; incoming isolated receipts retain original execution scope, not composed acceptance.'}
 (O/'intake_verification.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
