from pathlib import Path
import hashlib,json,re,subprocess
R=Path('C:/PleaseRemainOnTheLine');O=Path(__file__).parent;REV='81d2988e'
def git(rev,p):return subprocess.check_output(['git','show',rev+':'+p],cwd=R)
base=subprocess.check_output(['git','merge-base','HEAD',REV],cwd=R,text=True).strip()
paths=['.gitattributes','TASKS.md','art/blender/city_horizon_construction.json','art/reviews/city_streets_20261029/manifest.json','design/V2_CITY_CONTEXT_REPORT_2026-10-19.md','game/tests/fixtures/orison_city_horizon.json']
record={'evidence_class':'INERT','ours':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'theirs':REV,'base':base,'resolutions':{}}
for p in paths:
 raw=(R/p).read_bytes();(O/('conflict_'+p.replace('/','_'))).write_bytes(raw)
 if p.endswith('city_horizon_construction.json') or p.endswith('orison_city_horizon.json'):
  value=git(REV,p);method='Incoming new native records; ground source closure will be re-proven separately.'
 elif p.endswith('/manifest.json'):
  old,ours,theirs=[json.loads(git(rev,p)) for rev in [base,'HEAD',REV]]
  merged=dict(ours)
  for k,v in theirs.items():
   if k not in ours or ours[k]==old.get(k):merged[k]=v
   elif v!=old.get(k):assert v==ours[k],('Both changed manifest key',k)
  assert all(merged[k]==v for k,v in ours.items() if v!=old.get(k))
  value=(json.dumps(merged,indent=2)+'\n').encode();method='Keywise three-way union, no differing concurrent key allowed; preserve all canonical append records.'
 else:
  text=raw.decode('utf-8');pattern=re.compile(r'^<<<<<<< HEAD\r?\n(.*?)^=======\r?\n(.*?)^>>>>>>> [^\n]+\r?\n?',re.S|re.M);count=0
  def resolve(m):
   global count
   count+=1
   return m.group(1) if p=='TASKS.md' else m.group(1)+'\n'+m.group(2)
  text=pattern.sub(resolve,text);assert count==1,(p,count);assert not re.search(r'^(<<<<<<<|=======|>>>>>>>)',text,re.M)
  if p=='TASKS.md':
   needle='The next five-body architect cohort remains isolated and still needs accepted access/optical evidence.'
   assert text.count(needle)==1
   text=text.replace(needle,'Frozen civic delivery81d2988e now retains isolated3716/0 body and141/0 connected access contracts, with original3717/2 and139/10 failures preserved. Its400mm whole-capsule query is geometric support, not continuous floor contact on stairs. Canonical intake/source reconciliation remains separate from composed qualification. Detailed incoming queue history remains at81d2988e:TASKS.md; block sharding is next before further geometry.')
  value=text.encode();method='Keep current focused queue plus court gaps/source history; concatenate all report conflict paragraphs preserving both histories.'
 (R/p).write_bytes(value);record['resolutions'][p]={'sha256':hashlib.sha256(value).hexdigest(),'method':method}
(O/'merge_resolution.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
