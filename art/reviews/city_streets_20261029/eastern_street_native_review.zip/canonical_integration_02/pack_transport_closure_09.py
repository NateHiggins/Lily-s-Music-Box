from pathlib import Path
import hashlib,json,zipfile
R=Path('C:/PleaseRemainOnTheLine');O=Path(__file__).parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
p=R/'art/reviews/city_streets_20261029/eastern_street_native_review.zip';assert sha(p.read_bytes())=='e084279cfdbbf73b670b15a357c029cebb2f396d2b6ea7264cf3066550907ab1'
with zipfile.ZipFile(p) as z:old={n:sha(z.read(n)) for n in z.namelist()};assert len(old)==275 and z.testzip() is None
files=['close_transport_projection_08.py','transport_projection_reconciliation_08.json','all_surface_fixture_preflight_08.log','all_surface_fixture_preflight_09.log','pack_transport_closure_09.py'];added={}
with zipfile.ZipFile(p,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in files:
  n='canonical_integration_02/'+name;assert n not in old;raw=(O/name).read_bytes();z.writestr(n,raw);added[n]={'bytes':len(raw),'sha256':sha(raw)}
 z.writestr('canonical_integration_02/transport_closure_index_09.json',json.dumps({'evidence_class':'INERT','members':added},indent=2)+'\n')
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,h in old.items():assert sha(z.read(n))==h,n
 for n,row in added.items():assert sha(z.read(n))==row['sha256'],n
 count=len(z.namelist())
record={'evidence_class':'INERT','archive':p.relative_to(R).as_posix(),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'member_count':count,'preserved_prior_members':275,'scope':'All13 declared surface fixtures now pass source preflight. Transport original pure helper AST and complete107-road topology identical; other bindings/GLBs exact. Source closure only, no runtime renewal. Original refusal retained.','members':added}
m=R/'art/reviews/city_streets_20261029/manifest.json';d=json.loads(m.read_text());assert 'transport_projection_closure' not in d;d['transport_projection_closure']=record;m.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n');(O/'packed_transport_closure_09.json').write_text(json.dumps(record,indent=2));print(json.dumps({k:v for k,v in record.items() if k!='members'},indent=2))
