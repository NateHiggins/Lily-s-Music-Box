from pathlib import Path
import hashlib,json,subprocess,zipfile
R=Path('C:/PleaseRemainOnTheLine');O=Path(__file__).parent;Q=O/'runtime_01'
sha=lambda b:hashlib.sha256(b).hexdigest()
c=json.loads((Q/'route/eastern_frontage_contract.json').read_text())
assert c['execution']=={'completed':True,'exit_code':0,'timed_out':False} and c['checks']==47 and len(c['trace'])==16 and not c['failures']
assert sha((Q/'executed_route_source.gd').read_bytes())==c['source']['test_sha256']
for prefix in ['import','compile','route']:
 rec=json.loads((Q/(prefix+'.log.receipt.json')).read_text());assert rec['execution']['completed'] and rec['execution']['exit_code']==0 and not rec['execution']['timed_out']
 assert (Q/(prefix+'.log.stderr')).read_bytes()==b''
original=subprocess.check_output(['git','show','1e994d7d:game/tests/v2_city_horizon_bench.gd'],cwd=R)
(Q/'original_failed_loaded_bench.gd').write_bytes(original)
board=O/'baseline_a880/board.json';b=json.loads(board.read_text());assert b['commit']=='a8801fc218216f075a70460bf3eaef92d1fcef68' and not b['dirty_paths'] and len(b['gates'])==117
archive=R/'art/reviews/city_streets_20261029/eastern_street_native_review.zip'
assert sha(archive.read_bytes())=='6359bf1394e47d0c324bb7185f99009f994e62ce3320fe01416a09896dac957e'
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 old={n:sha(z.read(n)) for n in z.namelist()}
assert len(old)==231
files=[Q/n for n in ['batch.json','frozen_inputs.json','route_analysis.json','executed_route_source.gd','original_failed_loaded_bench.gd','loaded_batch.json']]
files.extend(Q/(prefix+suffix) for prefix in ['import','compile','route','loaded'] for suffix in ['.log','.log.stderr','.log.receipt.json'])
files.extend(sorted((Q/'route').iterdir()));files.extend([board,Path(__file__)])
added={}
with zipfile.ZipFile(archive,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:
  name='canonical_integration_02/'+p.relative_to(O).as_posix();assert name not in old
  raw=p.read_bytes();z.writestr(name,raw);added[name]={'bytes':len(raw),'sha256':sha(raw)}
 index={'evidence_class':'INERT','members':added,'scope':'Actual eastern controller47/16/0 and8inspected frames; wrapper import/compiler passes; original loaded diagnostic27477/8 failures; exactmain117gate baseline with5failed tools gates. Only embedded test-written runtime_contract grants its named scope. No continuous city/stair ascent/material-family/fullcity/saves/artistic acceptance.'}
 z.writestr('canonical_integration_02/runtime_index_06.json',json.dumps(index,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in old.items():assert sha(z.read(n))==h,n
 for n,row in added.items():assert sha(z.read(n))==row['sha256'],n
 count=len(z.namelist())
record={'evidence_class':'INERT','archive':archive.relative_to(R).as_posix(),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'member_count':count,'preserved_prior_members':len(old),'scope':index['scope'],'members':added}
m=R/'art/reviews/city_streets_20261029/manifest.json';data=json.loads(m.read_text());assert 'eastern_controller_review' not in data;data['eastern_controller_review']=record;m.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
(O/'packed_runtime_06.json').write_text(json.dumps(record,indent=2))
print(json.dumps({k:v for k,v in record.items() if k!='members'},indent=2))
