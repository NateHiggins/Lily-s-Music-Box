"""Renew only proven consumed projections; retain isolated receipt drift."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
R=Path('C:/PleaseRemainOnTheLine');O=Path(__file__).parent
def digest(raw):return hashlib.sha256(raw.replace(b'\r\n',b'\n')).hexdigest()
def old(rev,p):return subprocess.check_output(['git','show',rev+':'+p],cwd=R)
plan='art/data/city_horizon/source_plan.json'
before=old('d3ad45dd',plan);after=(R/plan).read_bytes()
projection=lambda raw:sorted((b['id'],b['rect']) for b in json.loads(raw)['buildings'])
assert projection(before)==projection(after)
apaths=['art/blender/city_ground_apron_construction.json','game/tests/fixtures/orison_city_ground_apron.json']
hpaths=['art/blender/city_horizon_construction.json','game/tests/fixtures/orison_city_horizon.json']
snap={p:(R/p).read_bytes() for p in apaths+hpaths}
assert snap[apaths[0]]==snap[apaths[1]] and snap[hpaths[0]]==snap[hpaths[1]]
a=json.loads(snap[apaths[0]]);h=json.loads(snap[hpaths[0]])
assert a['source_bindings'][plan]==digest(before)
for p,expected in a['source_bindings'].items():
 if p!=plan:
  raw=(R/p).read_bytes()
  actual=digest(raw) if Path(p).suffix in ['.json','.py','.gd'] else hashlib.sha256(raw).hexdigest()
  assert actual==expected,p
assert h['source_bindings'][apaths[0]]==digest(snap[apaths[0]])
record={'evidence_class':'INERT','baseline':'d3ad45dd','consumed_projection':'124 building rectangles used only to exclude exposed sample points; all identical including ids/order-independent comparison','before':digest(before),'after':digest(after),'rows':len(projection(after)),'projection_sha256':digest(json.dumps(projection(after),sort_keys=True).encode()),'scope':'Metadata closure only; native geometry and runtime proof unchanged.'}
a['source_bindings'][plan]=digest(after);a['horizon_plan_reconciliation']=record
encoded=(json.dumps(a,indent=2)+'\n').encode()
h['source_bindings'][apaths[0]]=digest(encoded)
h['source_ground_reconciliation']['apron_plan_closure']=record
for p in apaths:(O/('before_03_'+Path(p).parent.name+'_'+Path(p).name)).write_bytes(snap[p])
for p in apaths:(R/p).write_bytes(encoded)
for p in hpaths:(R/p).write_bytes((json.dumps(h,indent=2)+'\n').encode())
(O/'apron_plan_reconciliation_03.json').write_text(json.dumps(record,indent=2))
runtime=json.loads((O/'expected_e3_runtime_bindings.json').read_text());exact=[];drift=[]
with zipfile.ZipFile(R/'art/reviews/city_streets_20261029/eastern_houses_review.zip') as z:
 for p,row in runtime.items():
  raw=(R/p).read_bytes() if (R/p).is_file() else z.read('final/'+p)
  if not (R/p).is_file():assert raw==z.read('execution/bench_02_executed_source.gd')
  actual=hashlib.sha256(raw.replace(b'\r\n',b'\n') if row['lf_normalized'] else raw).hexdigest()
  (exact if actual==row['test_sha256'] else drift).append(p)
assert drift==['game/tests/fixtures/orison_city_horizon.json'],drift
result={'evidence_class':'INERT','inputs':len(runtime),'exact':len(exact),'changed':drift,'external_test_source':'Original archived bench equals executed source byte-for-byte','scope':'100 canonical production inputs and one archived bench unchanged. One fixture deliberately renewed with explicit projection proof. Original 2254/0 contract retains its original source scope; NOT current composed qualification.'}
(O/'post_merge_runtime_bindings_03.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'apron':record,'runtime':result},indent=2))
