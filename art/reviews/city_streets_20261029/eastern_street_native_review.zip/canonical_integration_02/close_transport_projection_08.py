from pathlib import Path
import ast,hashlib,json,subprocess
R=Path('C:/PleaseRemainOnTheLine');O=Path(__file__).parent
def sha(raw,text=True):return hashlib.sha256(raw.replace(b'\r\n',b'\n') if text else raw).hexdigest()
paths=['art/blender/city_transport_construction.json','game/tests/fixtures/orison_city_transport.json']
raw=[(R/p).read_bytes() for p in paths];assert raw[0]==raw[1]
d=json.loads(raw[0]);keys=['art/data/city_streets/source_plan.json','art/blender/scripts/city_street_geometry.py'];original={};revisions={}
for p in keys:
 for revision in ['6931a0a9','6e5e9a7a']:
  source=subprocess.check_output(['git','show',revision+':'+p],cwd=R)
  if sha(source)==d['source_bindings'][p]:original[p]=source;revisions[p]=revision;break
 assert p in original,('Original source pin not recovered',p)
for p,expected in d['source_bindings'].items():
 if p not in keys:assert sha((R/p).read_bytes(),Path(p).suffix not in ['.blend','.glb'])==expected,p
for p,expected in d['asset_sha256'].items():assert sha((R/p).read_bytes(),False)==expected,p
f=lambda raw:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)}
before=f(original[keys[1]]);after=f((R/keys[1]).read_bytes())
assert all(after[name]==value for name,value in before.items()),'Existing pure helper changed'
# Evaluate both pure implementations, not only selected plan fields.
old_ns={};new_ns={};exec(compile(original[keys[1]],'original_street_helper','exec'),old_ns);exec(compile((R/keys[1]).read_bytes(),'current_street_helper','exec'),new_ns)
read=lambda p:json.loads((R/p).read_text())
args=[read(p) for p in ['game/data/orison_v2/exterior/street_traffic.json','game/data/orison_v2/exterior/street_frame.json','art/data/city_transport/source_plan.json']]
previous=old_ns['topology'](json.loads(original[keys[0]]),*args);current=new_ns['topology'](read(keys[0]),*args)
assert previous==current,'Actual consumed topology changed'
builder=(R/'art/blender/scripts/build_city_transport.py').read_text()
assert builder.count('street_plan[')==0 and builder.count('street_shape[')==1 and "street_shape['road']" in builder
record={'evidence_class':'INERT','original_sources':revisions,'unchanged_old_functions':sorted(before),'topology_sha256':sha(json.dumps(current,sort_keys=True).encode()),'road_polygons':len(current['road']),'scope':'Every prior pure helper AST and complete evaluated topology remain exact. Transport uses only topology road for paving subtraction; every other bound input and both GLBs remain exact. Context binding renewal only, no runtime acceptance.','bindings':{p:{'before':d['source_bindings'][p],'after':sha((R/p).read_bytes())} for p in keys}}
for p in keys:d['source_bindings'][p]=record['bindings'][p]['after']
d['street_projection_reconciliation']=record
for p in paths:(R/p).write_bytes((json.dumps(d,indent=2)+'\n').encode())
(O/'transport_projection_reconciliation_08.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
