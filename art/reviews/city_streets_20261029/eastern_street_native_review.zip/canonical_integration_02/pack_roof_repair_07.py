from pathlib import Path
import hashlib,json,zipfile
R=Path('C:/PleaseRemainOnTheLine');O=Path(__file__).parent;Q=O/'runtime_01'
sha=lambda b:hashlib.sha256(b).hexdigest()
source=(R/'game/tests/v2_city_horizon_bench.gd').read_bytes()
assert source==(Q/'loaded_repair_source.gd').read_bytes()
for prefix in ['loaded_repair_compile','loaded_repair']:
 r=json.loads((Q/(prefix+'.log.receipt.json')).read_text());assert r['execution']['completed'] and r['execution']['exit_code']==0 and not r['execution']['timed_out']
 assert (Q/(prefix+'.log.stderr')).read_bytes()==b''
assert 'CITY HORIZON BENCH: PASS; 27493 checks; 0 failures' in (Q/'loaded_repair.log').read_text()
record={'evidence_class':'INERT','checks':27493,'failures':0,'test_sha256':sha(source),'scope':'Existing loaded horizon/ground bench, not a runtime_contract. Original generic parapet/top/outside controls retained. Three known residential roof styles additionally check real receiving wall and sheet underside at same XY/front-face/.1mm tolerances. No geometry/material/fixture/authority change. Original27477/8 retained. Compiler1/0 and both shutdown stderr empty. Cancelled label-only replay never launched Godot; forfeited queue position before corrected run.'}
(Q/'loaded_repair_analysis.json').write_text(json.dumps(record,indent=2))
archive=R/'art/reviews/city_streets_20261029/eastern_street_native_review.zip';assert sha(archive.read_bytes())=='d91b93ecfce7bd57b95b17350de842dafbe072fba31bdfda91fbe992e7388f31'
with zipfile.ZipFile(archive) as z:old={n:sha(z.read(n)) for n in z.namelist()};assert len(old)==261 and z.testzip() is None
files=[Q/n for n in ['loaded_repair_source.gd','loaded_repair_batch.json','loaded_repair_analysis.json','loaded_diagnostic_source.gd','loaded_diagnostic_batch.json','queued_diagnostic_cancellation.json']]
files.extend(Q/(prefix+suffix) for prefix in ['loaded_repair_compile','loaded_repair'] for suffix in ['.log','.log.stderr','.log.receipt.json']);files.append(Path(__file__))
added={}
with zipfile.ZipFile(archive,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:
  n='canonical_integration_02/'+p.relative_to(O).as_posix();assert n not in old;raw=p.read_bytes();z.writestr(n,raw);added[n]={'bytes':len(raw),'sha256':sha(raw)}
 z.writestr('canonical_integration_02/roof_repair_index_07.json',json.dumps({'evidence_class':'INERT','scope':record['scope'],'members':added},indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in old.items():assert sha(z.read(n))==h,n
 for n,row in added.items():assert sha(z.read(n))==row['sha256'],n
 count=len(z.namelist())
summary={'evidence_class':'INERT','archive':archive.relative_to(R).as_posix(),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'member_count':count,'preserved_prior_members':len(old),'scope':record['scope'],'members':added}
m=R/'art/reviews/city_streets_20261029/manifest.json';d=json.loads(m.read_text());assert 'northern_roof_bearing_repair' not in d;d['northern_roof_bearing_repair']=summary;m.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n');(O/'packed_roof_repair_07.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='members'},indent=2))
