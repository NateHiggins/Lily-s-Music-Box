from pathlib import Path
import hashlib,json,zipfile
R=Path('C:/PleaseRemainOnTheLine');O=Path(__file__).parent
archive=R/'art/reviews/city_streets_20261029/eastern_street_native_review.zip'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(archive.read_bytes())=='351dfb0c5d605b926168eed55ee8247eaebdfd5f7939bccdf801f268ea5dda99'
names=['verify_house_intake_01.py','house_intake_01.json','expected_e3_runtime_bindings.json','post_merge_runtime_bindings_01.json','post_merge_runtime_bindings_03.json','reconcile_horizon_ground_01.py','horizon_ground_reconciliation_01.json','failed_binary_normalization_03.py','close_bindings_03.py','apron_plan_reconciliation_03.json','close_street_context_04.py','street_context_reconciliation_04.json','merge_resolution_01.json','TASKS.md.merge_conflict.txt','V2_CITY_CONTEXT_REPORT_2026-10-19.md.merge_conflict.txt','line_endings_before_merge.json','line_endings_before_merge.zip','pack_closure_05.py']
note={'evidence_class':'INERT','prior_checkpoint':'5d9b4e52','original_failures':['Original runtime audit: 101 exact canonical files, missing ignored external bench. Archived bench subsequently found exact; after explicit fixture renewal, 100 canonical files plus bench remain exact and the fixture is declared changed.','Initial closure normalizes binary GLB bytes and fails hash guard; preserved failed script. Corrected text/binary digest policy matches repository preflight.','Preflight called on scripts without SOURCES and a ground record using another schema refuses by design; not gameplay failures.','Affected apron plan and three street context dependencies were stale after merge; now proven and renewed.'],'scope':'Source closure and frozen-delivery intake, not new runtime qualification.'}
(O/'diagnostic_dispositions_05.json').write_text(json.dumps(note,indent=2));names.append('diagnostic_dispositions_05.json')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 old={n:sha(z.read(n)) for n in z.namelist()}
assert len(old)==211
added={}
with zipfile.ZipFile(archive,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in names:
  target='canonical_integration_02/'+name;assert target not in old
  raw=(O/name).read_bytes();z.writestr(target,raw);added[target]={'bytes':len(raw),'sha256':sha(raw)}
 index={'evidence_class':'INERT','preserved_members':len(old),'added':added,'scope':note['scope']}
 z.writestr('canonical_integration_02/index.json',json.dumps(index,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in old.items():assert sha(z.read(n))==h,n
 for n,row in added.items():assert sha(z.read(n))==row['sha256'],n
 count=len(z.namelist())
record={'evidence_class':'INERT','archive':archive.relative_to(R).as_posix(),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'member_count':count,'preserved_prior_members':len(old),'new_members':len(added)+1,'intake_commit':'5d9b4e52','scope':note['scope'],'members':added}
m=R/'art/reviews/city_streets_20261029/manifest.json';data=json.loads(m.read_text());assert 'eastern_canonical_ground_closure' not in data
data['eastern_canonical_ground_closure']=record;m.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
(O/'packed_closure_05.json').write_text(json.dumps(record,indent=2))
print(json.dumps({k:v for k,v in record.items() if k!='members'},indent=2))
