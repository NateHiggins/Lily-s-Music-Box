from pathlib import Path
import ast,hashlib,json,subprocess
R=Path('C:/PleaseRemainOnTheLine');O=Path(__file__).parent
def sha(raw,text=True):return hashlib.sha256(raw.replace(b'\r\n',b'\n') if text else raw).hexdigest()
paths=['art/blender/city_streets_construction.json','game/tests/fixtures/orison_city_streets.json']
raw=[(R/p).read_bytes() for p in paths];assert raw[0]==raw[1]
d=json.loads(raw[0]);keys=['art/data/city_horizon/source_plan.json','art/blender/city_horizon_construction.json','art/blender/scripts/city_industrial_architecture.py']
builder=(R/'art/blender/scripts/build_city_streets.py').read_text()
tree=ast.parse(builder)
# Each affected source is a declared context binding, not a geometry read/import.
lists=[n for n in ast.walk(tree) if isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Name) and n.target.id=='paths' and isinstance(n.value,ast.List)]
assert len(lists)==1
declared=[n.value for n in lists[0].value.elts if isinstance(n,ast.Constant)]
for key in keys:
 assert key in declared and builder.count(key)==1,key
 original=subprocess.check_output(['git','show','d3ad45dd:'+key],cwd=R)
 assert sha(original)==d['source_bindings'][key],key
for p,expected in d['source_bindings'].items():
 if p in keys:continue
 assert sha((R/p).read_bytes(),Path(p).suffix not in ['.blend','.glb'])==expected,p
for p,expected in d['asset_sha256'].items():assert sha((R/p).read_bytes(),False)==expected,p
record={'evidence_class':'INERT','baseline':'d3ad45dd','scope':'Three horizon context bindings occur only in paths metadata list in unchanged street builder, never in geometry reads/imports. Every other bound input and both generated GLBs remain exact. No geometry, fixture assertions or runtime proof changed.','bindings':{p:{'before':d['source_bindings'][p],'after':sha((R/p).read_bytes())} for p in keys}}
for p in keys:d['source_bindings'][p]=record['bindings'][p]['after']
d['horizon_context_reconciliation']=record
for p,previous in zip(paths,raw):
 (O/('before_04_'+Path(p).parent.name+'_'+Path(p).name)).write_bytes(previous)
 (R/p).write_bytes((json.dumps(d,indent=2)+'\n').encode())
(O/'street_context_reconciliation_04.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
