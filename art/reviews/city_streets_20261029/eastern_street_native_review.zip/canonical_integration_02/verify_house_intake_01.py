from pathlib import Path
import hashlib,zipfile,json,subprocess
ROOT=Path('C:/PleaseRemainOnTheLine');OUT=Path(__file__).parent
PACKETS=[('northern_houses_native_review','ef1c06a3e6a061aa1c3ff7e2cb53544540f44e39',151,'127f7c8e50a84d6b65c5a1f85059cddb0a2f5042a5c34ac8ad37ee3149bf7bd6'),('houses_loaded_review','77c54028e72f6fff1c52386a8df5a8d8a9363f61',335,'e9eb5a9568e0101c8d59c877e7faf5fa9420f66caba4e889bceae9868f4fdf9f'),('eastern_houses_review','e3ccd6bd5f3dd308b2132eef0d76e603d6f1c5de',235,'263697148f8d5d5c6291ba916c1d4c4a8319ddd41cba7f4499229ad8a550b4f0')]
def git_sha(commit,relative):
    proc=subprocess.Popen(['git','show',commit+':'+relative],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    h=hashlib.sha256();length=0
    for raw in iter(lambda:proc.stdout.read(1024*1024),b''):h.update(raw);length+=len(raw)
    error=proc.stderr.read();assert proc.wait()==0,error
    return length,h.hexdigest()
records=[]
for family,commit,count,digest in PACKETS:
    path=Path('C:/ov/city/art/reviews/city_streets_20261029')/(family+'.zip')
    assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
    with zipfile.ZipFile(path) as z:
        assert len(z.namelist())==count and z.testzip() is None
        index=json.loads(z.read('archive_index.json'))
        for member,row in index['members'].items():
            raw=z.read(member);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],member
        for relative,row in index['assets'].items():
            length,actual=git_sha(commit,relative)
            assert length==row['bytes'] and actual==row['sha256'],(commit,relative,actual,row['sha256'])
        if family=='eastern_houses_review':
            (OUT/'expected_e3_runtime_bindings.json').write_text(json.dumps(index['runtime_sources'],indent=2))
        views={
            'houses_loaded_review':['execution/native_review_08/city_horizon_near_eastern_party_cornice.png','execution/native_review_08/city_horizon_near_northern_pair.png'],
            'eastern_houses_review':['execution/native_review_01/city_horizon_near_row_pair.png','execution/bench_02/HORIZON_NEAR_2_2_P0R0_natural_before.png','execution/bench_02/HORIZON_NEAR_2_2_P0R1_natural_before.png','execution/bench_02/HORIZON_NEAR_2_2_P0R2_natural_before.png']}.get(family,[])
        directory=OUT/'intake_views';directory.mkdir(exist_ok=True)
        for member in views:(directory/(family+'_'+Path(member).name)).write_bytes(z.read(member))
        contracts=[]
        for member in z.namelist():
            if member.endswith('/houses_loaded.runtime.json') and ('bench_05/' in member or 'bench_02/' in member):
                value=json.loads(z.read(member));(OUT/(family+'_runtime.json')).write_text(json.dumps(value,indent=2));contracts.append({'member':member,'keys':list(value)})
        records.append({'archive':str(path),'sha256':digest,'members':count,'verified_members':len(index['members']),'asset_commit':commit,'asset_bindings':len(index['assets']),'runtime_contracts':contracts,'extracted_views':views})
    print('VERIFIED',family,count,'members;9 exact delivered assets',flush=True)
(OUT/'house_intake_01.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Frozen delivered archives/members/assets verified against their exact Git checkpoints; not current combined runtime qualification.','packets':records},indent=2))
