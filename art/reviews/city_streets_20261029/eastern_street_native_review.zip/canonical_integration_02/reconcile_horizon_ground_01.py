from pathlib import Path
import hashlib,json,subprocess,ast,sys,zipfile
ROOT=Path('C:/PleaseRemainOnTheLine');OUT=Path(__file__).parent
SHA='e3ccd6bd5f3dd308b2132eef0d76e603d6f1c5de'
def old(relative):return subprocess.check_output(['git','show',SHA+':'+relative],cwd=ROOT)
def digest(raw):return hashlib.sha256(raw.replace(b'\r\n',b'\n')).hexdigest()
metadata_paths=[ROOT/'art/blender/city_horizon_construction.json',ROOT/'game/tests/fixtures/orison_city_horizon.json']
raw=[p.read_bytes() for p in metadata_paths];assert raw[0]==raw[1]
data=json.loads(raw[0]);keys=['art/blender/city_ground_apron_construction.json','art/blender/scripts/city_ground_apron_geometry.py']
for key in keys:assert data['source_bindings'][key]==digest(old(key)),('Original delivered binding mismatch',key)
before=json.loads(old(keys[0]));after=json.loads((ROOT/keys[0]).read_text())
projection=lambda d:{k:d[k] for k in ['retained_ground_bounds','relief']}
assert projection(before)==projection(after),'Consumed grade or envelope changed'
def functions(raw):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw.decode('utf-8')).body if isinstance(n,ast.FunctionDef)}
f,g=functions(old(keys[1])),functions((ROOT/keys[1]).read_bytes())
for name in ['exported_bounds','relief_height','profile_height']:assert f[name]==g[name],('Consumed helper changed',name)
for relative,expected in data['source_bindings'].items():
    if relative in keys:continue
    value=(ROOT/relative).read_bytes()
    actual=hashlib.sha256(value.replace(b'\r\n',b'\n') if Path(relative).suffix in ['.json','.py','.gd'] else value).hexdigest()
    assert actual==expected,('Other input changed',relative)
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_horizon_geometry import building_outline,validate_plan
from city_ground_apron_geometry import relief_height
plan=json.loads((ROOT/'art/data/city_horizon/source_plan.json').read_text());validate_plan(plan,after['retained_ground_bounds'])
seats={r['building']:r for r in data['grade_seats']};checked=[]
for row in plan['buildings']:
    outline=building_outline(row);samples=[(x,-y) for x,y in outline]
    for p,q in zip(outline,outline[1:]+outline[:1]):
        if abs(q[0]-p[0])<1e-12:continue
        for x,_ in after['relief']['west_profile']:
            t=(x-p[0])/(q[0]-p[0])
            if 0<t<1:samples.append((x,-(p[1]+t*(q[1]-p[1]))))
    heights=[relief_height(x,z,-.02,after['relief']) for x,z in samples]
    seat=seats[row['id']]
    assert seat['assembly_datum_m']==max(heights)+.02 and seat['soil_low_m']==min(heights),(row['id'],seat,heights)
    checked.append(row['id'])
record={'evidence_class':'INERT','scope':'Only source-ground envelope/relief and the three consumed pure helper functions are unchanged; every delivered horizon grade datum and every other bound input verified. No native geometry, runtime contract or artistic status renewed.','source_commit':SHA,'grade_records':len(checked),'projection_sha256':digest(json.dumps(projection(after),sort_keys=True).encode()),'consumed_functions':['exported_bounds','relief_height','profile_height'],'bindings':{key:{'before':data['source_bindings'][key],'after':digest((ROOT/key).read_bytes())} for key in keys}}
for key in keys:data['source_bindings'][key]=record['bindings'][key]['after']
data['source_ground_reconciliation']=record
encoded=(json.dumps(data,indent=2)+'\n').encode()
try:
    for p in metadata_paths:p.write_bytes(encoded)
except Exception:
    for p,previous in zip(metadata_paths,raw):p.write_bytes(previous)
    raise
(OUT/'horizon_ground_reconciliation_01.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))

runtime=json.loads((OUT/'expected_e3_runtime_bindings.json').read_text());checked_files=[]
with zipfile.ZipFile(ROOT/'art/reviews/city_streets_20261029/eastern_houses_review.zip') as z:
    for relative,row in runtime.items():
        path=ROOT/relative
        if path.is_file():value=path.read_bytes();where='canonical file'
        else:
            assert relative=='game/tmp/city_eastern_houses_20261031/bench.gd',relative
            value=z.read('final/'+relative);where='archived original test-only source'
            assert value==z.read('execution/bench_02_executed_source.gd')
        if row['lf_normalized']:value=value.replace(b'\r\n',b'\n')
        assert hashlib.sha256(value).hexdigest()==row['test_sha256'],relative
        checked_files.append({'path':relative,'source':where})
(OUT/'post_merge_runtime_bindings_02.json').write_text(json.dumps({'evidence_class':'INERT','checked':len(checked_files),'files':checked_files,'scope':'101 production inputs and the original external test-only source; no new composed qualification.'},indent=2))
print('Verified102 incoming bindings:101 canonical production inputs plus archived original test.')
