from pathlib import Path
import ast,hashlib,json,subprocess,sys
R=Path('C:/PleaseRemainOnTheLine');O=Path(__file__).parent;OLD='95d4506e';NEW='05f5df70'
def git(rev,p):return subprocess.check_output(['git','show',rev+':'+p],cwd=R)
def sha(raw,text=True):return hashlib.sha256(raw.replace(b'\r\n',b'\n') if text else raw).hexdigest()
plan='art/data/city_horizon/source_plan.json';helper='art/blender/scripts/city_ground_apron_geometry.py';ap='art/blender/city_ground_apron_construction.json';hp='art/blender/city_horizon_construction.json';sp='art/blender/city_streets_construction.json'
pairs={ap:'game/tests/fixtures/orison_city_ground_apron.json',hp:'game/tests/fixtures/orison_city_horizon.json',sp:'game/tests/fixtures/orison_city_streets.json'}
raw={p:(R/p).read_bytes() for pair in pairs.items() for p in pair}
for p,q in pairs.items():assert raw[p]==raw[q],p
a,h,s=[json.loads(raw[p]) for p in [ap,hp,sp]]
old_plan=json.loads(git(OLD,plan));new_plan=json.loads((R/plan).read_text())
rects=lambda d:sorted((b['id'],b['rect']) for b in d['buildings'])
assert rects(old_plan)==rects(new_plan) and len(rects(new_plan))==124
assert a['source_bindings'][plan]==sha(git(OLD,plan))
for p,expected in a['source_bindings'].items():
 if p!=plan:assert sha((R/p).read_bytes(),Path(p).suffix not in ['.blend','.glb'])==expected,p
a['source_bindings'][plan]=sha((R/plan).read_bytes())
a['court_plan_reconciliation']={'evidence_class':'INERT','old_source':OLD,'new_source':NEW,'scope':'All124 ids/footprint rectangles used by exposed-sample exclusion remain exact. Native apron unchanged.','projection_sha256':sha(json.dumps(rects(new_plan),sort_keys=True).encode())}
encoded_a=(json.dumps(a,indent=2)+'\n').encode()
old_apron=json.loads(git(NEW,ap));projection=lambda d:{k:d[k] for k in ['retained_ground_bounds','relief']}
assert projection(old_apron)==projection(a)
functions=lambda text:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
f,g=functions(git(NEW,helper)),functions((R/helper).read_bytes())
for name in ['exported_bounds','relief_height','profile_height']:assert f[name]==g[name],name
for p in [ap,helper]:assert h['source_bindings'][p]==sha(git(NEW,p)),p
for p,expected in h['source_bindings'].items():
 if p not in [ap,helper]:assert sha((R/p).read_bytes(),Path(p).suffix not in ['.blend','.glb'])==expected,p
sys.path.insert(0,str(R/'art/blender/scripts'))
from city_horizon_geometry import building_outline,validate_plan
from city_ground_apron_geometry import relief_height
validate_plan(new_plan,a['retained_ground_bounds']);seats={r['building']:r for r in h['grade_seats']}
for row in new_plan['buildings']:
 outline=building_outline(row);samples=[(x,-y) for x,y in outline]
 for p,q in zip(outline,outline[1:]+outline[:1]):
  if abs(q[0]-p[0])<1e-12:continue
  for x,_ in a['relief']['west_profile']:
   t=(x-p[0])/(q[0]-p[0])
   if 0<t<1:samples.append((x,-(p[1]+t*(q[1]-p[1]))))
 heights=[relief_height(x,z,-.02,a['relief']) for x,z in samples];seat=seats[row['id']]
 assert seat['assembly_datum_m']==max(heights)+.02 and seat['soil_low_m']==min(heights),row['id']
h['source_bindings'][ap]=sha(encoded_a);h['source_bindings'][helper]=sha((R/helper).read_bytes())
h['source_ground_reconciliation']={'evidence_class':'INERT','source':NEW,'scope':'Apron envelope/relief and three consumed helper ASTs unchanged; all124 new-outline grade seats recomputed. No runtime renewal.','grade_records':len(seats),'consumed_functions':['exported_bounds','relief_height','profile_height']}
encoded_h=(json.dumps(h,indent=2)+'\n').encode()
for p in [plan,hp]:assert s['source_bindings'][p]==sha(git(OLD,p)),p
for p,expected in s['source_bindings'].items():
 if p not in [plan,hp]:assert sha((R/p).read_bytes(),Path(p).suffix not in ['.blend','.glb'])==expected,p
builder=(R/'art/blender/scripts/build_city_streets.py').read_text();tree=ast.parse(builder)
declarations=[n for n in ast.walk(tree) if isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Name) and n.target.id=='paths']
assert len(declarations)==1
declared=[n.value for n in declarations[0].value.elts if isinstance(n,ast.Constant)]
for p in [plan,hp]:assert p in declared and builder.count(p)==1,p
for p,expected in s['asset_sha256'].items():assert sha((R/p).read_bytes(),False)==expected,p
s['source_bindings'][plan]=sha((R/plan).read_bytes());s['source_bindings'][hp]=sha(encoded_h)
s['court_context_reconciliation']={'evidence_class':'INERT','source':NEW,'scope':'Two horizon context references occur only in the unchanged metadata list, not street geometry reads. Allother inputs and both street GLBs exact.'}
encoded_s=(json.dumps(s,indent=2)+'\n').encode()
try:
 for p,encoded in [(ap,encoded_a),(hp,encoded_h),(sp,encoded_s)]:
  for q in [p,pairs[p]]:(R/q).write_bytes(encoded)
except Exception:
 for p,value in raw.items():(R/p).write_bytes(value)
 raise
record={'evidence_class':'INERT','source':NEW,'apron':a['court_plan_reconciliation'],'horizon':h['source_ground_reconciliation'],'streets':s['court_context_reconciliation'],'scope':'Exact consumed-projection reconciliation only; incoming runtime contracts retain old source/ground/bench scope.','updated':{p:sha((R/p).read_bytes()) for p in raw}}
(O/'projection_reconciliation.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
