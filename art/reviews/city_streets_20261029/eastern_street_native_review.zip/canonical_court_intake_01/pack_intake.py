from pathlib import Path
import hashlib,json,zipfile
R=Path('C:/PleaseRemainOnTheLine');O=Path(__file__).parent;sha=lambda raw:hashlib.sha256(raw).hexdigest()
archive=R/'art/reviews/city_streets_20261029/eastern_street_native_review.zip';assert sha(archive.read_bytes())=='bacef4372df46cd68cc72550ff87dfa6ee819821f0e08e35dd0cc1d18907c581'
with zipfile.ZipFile(archive) as z:old={n:sha(z.read(n)) for n in z.namelist()};assert len(old)==281 and z.testzip() is None
index=json.loads((O/'incoming_index.json').read_text());images={p.name:sha(p.read_bytes()) for p in (O/'views').glob('*.png')};assert len(images)==8
for name,h in images.items():assert any(Path(k).name==name and row['sha256']==h for k,row in index['members'].items()),name
(O/'optical_intake.json').write_text(json.dumps({'evidence_class':'INERT','original_archive':'eastern_courts_review.zip','images_actually_inspected':images,'scope':'Two native context frames,four isolated actual loaded near views,two standing courtyard views. No duplicate pixels stored; original immutable archive retains each image. Not composed lighting or artistic acceptance.','notes':'Distinct C/T/H open courts and architecture visible. Cedar narrow wings with small tiled hips; factory upper north wall exposed. Willow stone basement retained. Neutral/isolated lighting; street-level materials and depth require composed review.'},indent=2))
files=['verify_intake.py','intake_verification.json','resolve_merge.py','merge_resolution.json','renew_projections.py','failed_binary_digest_projection.py','projection_reconciliation.json','surface_fixture_preflight.log','optical_intake.json','pack_intake.py'];added={}
with zipfile.ZipFile(archive,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in files:
  n='canonical_court_intake_01/'+name;assert n not in old;raw=(O/name).read_bytes();z.writestr(n,raw);added[n]={'bytes':len(raw),'sha256':sha(raw)}
 z.writestr('canonical_court_intake_01/index.json',json.dumps({'evidence_class':'INERT','members':added},indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,h in old.items():assert sha(z.read(n))==h,n
 for n,row in added.items():assert sha(z.read(n))==row['sha256'],n
 count=len(z.namelist())
record={'evidence_class':'INERT','archive':archive.relative_to(R).as_posix(),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'member_count':count,'preserved_prior_members':281,'incoming_commit':'05f5df70d6b0e3f8488653e1fb99e5b79ec16093','incoming_archive_sha256':'260a7d2a51e6e1f7c27987483a6f8d644065eb1abeb3cbfae900d20ab6ae4201','scope':'Frozen283-member court delivery intake:282 indexed hashes,5 exact imagealiases,9 assets,135 original runtimebindings verified. Eight existing images inspected without duplication. Reconciled source projections andall13preflights; no newruntime acceptance.','members':added}
p=R/'art/reviews/city_streets_20261029/manifest.json';d=json.loads(p.read_text());assert 'canonical_court_intake' not in d;d['canonical_court_intake']=record;p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n');(O/'packed_intake.json').write_text(json.dumps(record,indent=2));print(json.dumps({k:v for k,v in record.items() if k!='members'},indent=2))
