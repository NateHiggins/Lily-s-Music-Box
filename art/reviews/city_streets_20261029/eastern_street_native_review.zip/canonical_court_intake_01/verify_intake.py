from pathlib import Path
import hashlib,io,json,subprocess,zipfile
R=Path('C:/PleaseRemainOnTheLine');O=Path(__file__).parent;REV='05f5df70d6b0e3f8488653e1fb99e5b79ec16093'
def old(p):return subprocess.check_output(['git','show',REV+':'+p],cwd=R,stderr=subprocess.PIPE)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
raw=old('art/reviews/city_streets_20261029/eastern_courts_review.zip');assert len(raw)==99765684 and sha(raw)=='260a7d2a51e6e1f7c27987483a6f8d644065eb1abeb3cbfae900d20ab6ae4201'
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 assert len(z.namelist())==283 and z.testzip() is None
 index=json.loads(z.read('archive_index.json'))
 for name,row in index['members'].items():
  value=z.read(name);assert len(value)==row['bytes'] and sha(value)==row['sha256'],name
 for alias,row in index['byte_exact_reused_image_aliases'].items():assert sha(z.read(row['retained_member']))==row['sha256'],alias
 for p,row in index['assets'].items():
  value=old(p);assert len(value)==row['bytes'] and sha(value)==row['sha256'],p
 runtime_current_drift=[];external=[]
 for p,row in index['runtime_sources'].items():
  if (R/p).is_file():
   value=(R/p).read_bytes();current=sha(value.replace(b'\r\n',b'\n') if row['lf_normalized'] else value)
   if current==row['test_sha256']:continue
   runtime_current_drift.append(p)
  try:value=old(p)
  except subprocess.CalledProcessError:
   value=z.read('final/'+p);external.append(p)
  if row['lf_normalized']:value=value.replace(b'\r\n',b'\n')
  assert sha(value)==row['test_sha256'],p
 contracts={}
 for name in ['execution/bench_01/courts_loaded.runtime.json','execution/access_02/courts_access.runtime.json']:
  d=json.loads(z.read(name));assert d['evidence_kind']=='runtime_contract' and d['schema_version']==2 and d['execution']['completed'] and d['execution']['exit_code']==0 and not d['execution']['timed_out'] and not d['failures']
  (O/Path(name).name).write_text(json.dumps(d,indent=2));contracts[name]={'checks':d['checks'],'scope':d['scope'],'execution':d['execution']}
 print('native images',[n for n in z.namelist() if n.endswith('.png') and 'native_review_03/' in n]);print('access images',[n for n in z.namelist() if n.endswith('.png') and '/access_02/' in n]);print('loaded image sample',[n for n in z.namelist() if n.endswith('.png') and '/bench_01/' in n][:10])
 record={'evidence_class':'INERT','checkpoint':REV,'archive_sha256':sha(raw),'members_verified':len(index['members']),'aliases_verified':len(index['byte_exact_reused_image_aliases']),'asset_bindings_verified':len(index['assets']),'runtime_source_bindings_verified':len(index['runtime_sources']),'canonical_drift_before_intake':runtime_current_drift,'external_test_sources':external,'original_contracts':contracts,'scope':'Frozen source/packet integrity audit; incoming isolated receipts retain original execution scope, not composed acceptance.'}
 (O/'intake_verification.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
