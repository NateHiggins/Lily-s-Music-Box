from pathlib import Path
import hashlib,json,re,subprocess
R=Path('C:/PleaseRemainOnTheLine');O=Path(__file__).parent;REV='05f5df70d6b0e3f8488653e1fb99e5b79ec16093'
def git(rev,p):return subprocess.check_output(['git','show',rev+':'+p],cwd=R)
base=subprocess.check_output(['git','merge-base','HEAD',REV],cwd=R,text=True).strip()
paths=['TASKS.md','art/blender/city_horizon_construction.json','art/reviews/city_streets_20261029/manifest.json','design/V2_CITY_CONTEXT_REPORT_2026-10-19.md','game/tests/fixtures/orison_city_horizon.json']
record={'evidence_class':'INERT','ours':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'theirs':REV,'base':base,'resolutions':{}}
for p in paths:
 raw=(R/p).read_bytes();(O/('conflict_'+p.replace('/','_'))).write_bytes(raw)
 if p.endswith('city_horizon_construction.json') or p.endswith('orison_city_horizon.json'):
  value=git(REV,p);method='Incoming new native records; ground source closure will be re-proven separately.'
 elif p.endswith('/manifest.json'):
  old,ours,theirs=[json.loads(git(rev,p)) for rev in [base,'HEAD',REV]]
  merged=dict(ours)
  for k,v in theirs.items():
   if k not in ours or ours[k]==old.get(k):merged[k]=v
   elif v!=old.get(k):assert v==ours[k],('Both changed manifest key',k)
  assert all(merged[k]==v for k,v in ours.items() if v!=old.get(k))
  value=(json.dumps(merged,indent=2)+'\n').encode();method='Keywise three-way union, no differing concurrent key allowed; preserve all canonical append records.'
 else:
  text=raw.decode('utf-8');pattern=re.compile(r'^<<<<<<< HEAD\r?\n(.*?)^=======\r?\n(.*?)^>>>>>>> [^\n]+\r?\n?',re.S|re.M);count=0
  def resolve(m):
   global count
   count+=1
   return m.group(1) if p=='TASKS.md' else m.group(1)+'\n\n'+m.group(2)
  text=pattern.sub(resolve,text);assert count==1,(p,count);assert not re.search(r'^(<<<<<<<|=======|>>>>>>>)',text,re.M)
  if p=='TASKS.md':
   needle='Current main a8801fc2 and frozen native c1f1fb68/ed59c7a9 plus 77c54028/e3ccd6bd are reconciled on the canonical branch, not jointly qualified or published.'
   assert text.count(needle)==1
   text=text.replace(needle,needle+' Court delivery05f5df70 adds three distinct open court bodies and renews the adjoining factory; its original isolated3263/0 and court/factory98/0 retain their executed-source scope. Incoming detailed task history is preserved at05f5df70:TASKS.md and in the ledger. No main publication or composed acceptance follows from intake.')
  value=text.encode();method='Keep current focused queue plus court gaps/source history; concatenate all report conflict paragraphs preserving both histories.'
 (R/p).write_bytes(value);record['resolutions'][p]={'sha256':hashlib.sha256(value).hexdigest(),'method':method}
(O/'merge_resolution.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
