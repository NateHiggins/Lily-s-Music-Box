from pathlib import Path
import ast,json,struct,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent
reader=out.parent/'bodega_frontage_reconciliation_01/check_preservation_01.py';tree=ast.parse(reader.read_text(encoding='utf-8-sig'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(reader),'exec'))
baseline=json.loads((out/'baseline_01.json').read_text());report=dict(evidence_class='INERT',scope='Exact old street node/attribute/index projections andten retained asset hashes. Not rendering cost,loaded collision,ground support or runtime acceptance.',parts={},other_assets={},failures=[])
for family,old in baseline['parts'].items():
    new=projection((root/f'game/assets/props/{family}.glb').read_bytes())
    changed=[name for name in old if old[name]!=new.get(name)]
    added=sorted(set(new)-set(old));report['parts'][family]=dict(existing_exact=len(old)-len(changed),changed=changed,added=added)
    assert len(old)==51 and len(added)==147
    report['failures'].extend(changed)
for path,expected in baseline['other_assets'].items():
    actual=hashlib.sha256((root/path).read_bytes()).hexdigest();report['other_assets'][path]=actual
    if actual!=expected:report['failures'].append(path)
for relative in ['game/data/orison_v2/exterior/street_traffic.json','game/scripts/building/orison_v2_street_traffic.gd','game/scripts/building/orison_v2_city_streets.gd']:
    import subprocess
    raw=subprocess.check_output(['git','show','HEAD:'+relative],cwd=root)
    assert raw.replace(b'\r\n',b'\n')==(root/relative).read_bytes().replace(b'\r\n',b'\n'),relative
    report.setdefault('unchanged_runtime_authority_sha256',{})[relative]=hashlib.sha256(raw.replace(b'\r\n',b'\n')).hexdigest()
report['new_export_sha256']={f'game/assets/props/{f}.glb':hashlib.sha256((root/f'game/assets/props/{f}.glb').read_bytes()).hexdigest() for f in baseline['parts']}
path=out/'preservation_01.json';assert not path.exists();path.write_text(json.dumps(report,indent=2),encoding='utf-8',newline='\n')
print('51+51 old streetparts exact;147new perLOD;tenotherassets exact;failures',len(report['failures']))
assert not report['failures'],report['failures']
