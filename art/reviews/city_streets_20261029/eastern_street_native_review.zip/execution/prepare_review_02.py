from pathlib import Path
out=Path(__file__).parent
source=(out/'review_native_01.py').read_text(encoding='utf-8')
source=source.replace("/'native_review_01'","/'native_review_02'")
start=source.index('views=[')
end=source.index('\ncaptures=[]',start)
source=source[:start]+'''views=[('near_row',(137,-130,3.0),(152,-138,3.2),False,25.,0,False),
       ('preserved_corner',(137,-137,3.0),(144,-149,2.0),False,25.,0,False),
       ('connector',(183,9,3.0),(208,16,4.0),False,25.,0,False),
       ('far_row',(190,38,4.0),(208,38,6.0),False,23.,0,False)]
'''+source[end:]
path=out/'review_native_02.py';assert not path.exists();path.write_text(source,encoding='utf-8',newline='\n')
runner=(out/'run_native_review_01.py').read_text(encoding='utf-8').replace('_01','_02')
path=out/'run_native_review_02.py';assert not path.exists();path.write_text(runner,encoding='utf-8',newline='\n')
