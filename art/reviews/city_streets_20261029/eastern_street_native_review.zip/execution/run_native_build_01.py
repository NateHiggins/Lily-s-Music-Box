from pathlib import Path
import subprocess,os,json,time,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent
engine='C:/Program Files/Blender Foundation/Blender 5.2/blender.exe'
env=os.environ.copy()
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:env[key]='2'
paths=['art/blender/scripts/build_city_streets.py','art/blender/scripts/city_street_geometry.py','art/data/city_streets/source_plan.json']
bindings={p:hashlib.sha256((root/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in paths}
for path in paths:(out/('executed_'+Path(path).name)).write_bytes((root/path).read_bytes())
started=time.time();timed_out=False
with (out/'build_city_streets_01.log').open('xb') as log:
    process=subprocess.Popen([engine,'-b','-t','2','--python-exit-code','1','-P',str(root/paths[0])],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    (out/'native_process_01.json').write_text(json.dumps(dict(evidence_class='INERT',pid=process.pid,started_epoch=started,ceiling_s=180,scope='Owned CPU2 native build process,not runtime proof.'),indent=2),encoding='utf-8',newline='\n')
    print('OWNED BLENDER PID',process.pid,flush=True)
    try:code=process.wait(timeout=180)
    except subprocess.TimeoutExpired:
        timed_out=True;process.terminate()
        try:process.wait(timeout=10)
        except subprocess.TimeoutExpired:process.kill();process.wait()
        code=124
record=dict(evidence_class='INERT',scope='Native street generation/export only;no render,ground cut,Godot or artistic acceptance.',pid=process.pid,exit_code=code,timed_out=timed_out,seconds=time.time()-started,source_sha256=bindings)
(out/'native_build_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n');print(record,flush=True)
raise SystemExit(code)
