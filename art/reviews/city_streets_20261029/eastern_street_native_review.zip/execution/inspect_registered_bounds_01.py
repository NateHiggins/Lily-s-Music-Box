from pathlib import Path
import bpy,json
from mathutils import Matrix,Vector
root=Path('C:/ov/city');out=Path(__file__).parent
bpy.ops.wm.read_factory_settings(use_empty=True)
rows=[]
for family in ['near','far']:
    with bpy.data.libraries.load(str(root/f'art/blender/city_horizon_{family}.blend'),link=False) as (available,loaded):
        loaded.objects=[n for n in available.objects if n.split('__')[0] in ['HORIZON_NEAR_2_0_P0R0','HORIZON_NEAR_0_0_P0R0','HORIZON_FAR_2_1_P0']]
    for obj in loaded.objects:
        bpy.context.scene.collection.objects.link(obj)
        obj.matrix_world=Matrix.Translation((0,1.855,0))@Matrix.Diagonal((-1.,-1.,1.,1.))@obj.matrix_world
        bpy.context.view_layer.update()
        points=[obj.matrix_world@v.co for v in obj.data.vertices]
        rows.append(dict(name=obj.name,lo=[min(p[i] for p in points) for i in range(3)],hi=[max(p[i] for p in points) for i in range(3)],hide_render=obj.hide_render,hide_viewport=obj.hide_viewport))
path=out/'registered_bounds_01.json';assert not path.exists();path.write_text(json.dumps(rows,indent=2),encoding='utf-8',newline='\n')
print(json.dumps(rows),flush=True)
