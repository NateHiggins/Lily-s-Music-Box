from pathlib import Path
out=Path(__file__).parent
source=(out/'review_native_02.py').read_text(encoding='utf-8').replace("/'native_review_02'","/'native_review_03'")
source=source.replace("        if transform is not None:obj.matrix_world=transform@obj.matrix_world\n    bpy.context.view_layer.update();return list(collection.objects)","    bpy.context.view_layer.update()\n    if transform is not None:\n        for obj in collection.objects:obj.matrix_world=transform@obj.matrix_world\n    bpy.context.view_layer.update();return list(collection.objects)")
assert 'for obj in collection.objects:obj.matrix_world' in source
source=source.replace("views=[('near_row'","views=[('registered_overview',(275,40,170),(160,-35,0),True,310.,0,False),\n       ('registered_uncut_ground',(275,40,170),(160,-35,0),True,310.,0,True),\n       ('near_row'")
source=source.replace("captures=[]", "bounds={}\nfor prefix in ['HORIZON_NEAR_2_0_P0R0','HORIZON_NEAR_0_0_P0R0','HORIZON_FAR_2_1_P0']:\n    points=[obj.matrix_world@v.co for obj in scene.objects if obj.type=='MESH' and obj.name.startswith(prefix+'__') for v in obj.data.vertices]\n    bounds[prefix]=dict(lo=[min(p[i] for p in points) for i in range(3)],hi=[max(p[i] for p in points) for i in range(3)])\nassert bounds['HORIZON_NEAR_2_0_P0R0']['lo'][0]>149\nassert bounds['HORIZON_NEAR_2_0_P0R0']['hi'][1]<-139\nassert bounds['HORIZON_FAR_2_1_P0']['lo'][0]>206\n(OUT/'registered_bounds.json').write_text(json.dumps(bounds,indent=2),encoding='utf-8',newline='\\n')\ncaptures=[]")
path=out/'review_native_03.py';assert not path.exists();path.write_text(source,encoding='utf-8',newline='\n')
runner=(out/'run_native_review_01.py').read_text(encoding='utf-8').replace('_01','_03')
path=out/'run_native_review_03.py';assert not path.exists();path.write_text(runner,encoding='utf-8',newline='\n')
