from pathlib import Path
import subprocess,os,json,time,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent
env=os.environ.copy()
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:env[key]='2'
script=out/'review_native_01.py';started=time.time();timed_out=False
with (out/'native_review_01.log').open('xb') as log:
    process=subprocess.Popen(['C:/Program Files/Blender Foundation/Blender 5.2/blender.exe','-b','-t','2','--python-exit-code','1','-P',str(script)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    (out/'review_process_01.json').write_text(json.dumps(dict(evidence_class='INERT',pid=process.pid,started_epoch=started,ceiling_s=600,scope='Owned sequential CPU2/Cycles12spp review,not runtime proof.'),indent=2),encoding='utf-8',newline='\n');print('OWNED REVIEW BLENDER PID',process.pid,flush=True)
    try:code=process.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timed_out=True;process.terminate()
        try:process.wait(timeout=10)
        except subprocess.TimeoutExpired:process.kill();process.wait()
        code=124
record=dict(evidence_class='INERT',scope='Native proposal/retained context/uncut-ground control only. No support/access/Godot/artistic acceptance.',pid=process.pid,exit_code=code,timed_out=timed_out,seconds=time.time()-started,review_script_sha256=hashlib.sha256(script.read_bytes()).hexdigest())
(out/'native_review_execution_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n');print(record,flush=True);raise SystemExit(code)
