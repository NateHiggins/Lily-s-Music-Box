from pathlib import Path
import json,hashlib,zipfile
root=Path('C:/ov/city');out=Path(__file__).parent
assert (out/'native_inspection_03.json').is_file()
dest=root/'art/reviews/city_streets_20261029/eastern_street_native_review.zip';assert not dest.exists()
stored={}
for p in sorted(out.rglob('*')):
    if p.is_file() and p.suffix in ['.py','.json','.log','.png'] and '__pycache__' not in p.parts:
        stored['execution/'+p.relative_to(out).as_posix()]=p.read_bytes()
for relative in ['art/blender/scripts/build_city_streets.py','art/blender/scripts/city_street_geometry.py','art/data/city_streets/source_plan.json','tools/tests/test_city_street_geometry.py']:
    stored['final/'+relative]=(root/relative).read_bytes()
asset_paths=['art/blender/city_streets.blend','art/blender/city_streets_construction.json','game/assets/props/city_streets.glb','game/assets/props/city_streets_lod1.glb','game/data/orison_v2/exterior/city_streets.json','game/tests/fixtures/orison_city_streets.json']
bindings={p:dict(bytes=(root/p).stat().st_size,sha256=hashlib.sha256((root/p).read_bytes()).hexdigest()) for p in asset_paths}
scope='Native paving geometry/export/UV/context review; original failed library registration controls preserved. Ground cut unimplemented;no loaded runtime,collision/access,mipmap,rendering-cost or artistic acceptance.'
index=dict(evidence_class='INERT',scope=scope,sourcebase='c1f1fb68385dc671e813dedc0b41e16f58a7134b',assets=bindings,members={k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in stored.items()})
stored['archive_index.json']=json.dumps(index,indent=2).encode('utf-8')
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
    for k,v in stored.items():z.writestr(k,v,compress_type=zipfile.ZIP_STORED if k.endswith('.png') else zipfile.ZIP_DEFLATED,compresslevel=1)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None and set(z.namelist())==set(stored)
    for k,v in stored.items():assert z.read(k)==v,k
record=dict(evidence_class='INERT',scope=scope,archive=dest.relative_to(root).as_posix(),bytes=dest.stat().st_size,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),member_count=len(stored),asset_bindings=bindings)
manifest_path=root/'art/reviews/city_streets_20261029/manifest.json';manifest=json.loads(manifest_path.read_text());assert 'eastern_street_native_archive' not in manifest
manifest['eastern_street_native_archive']=record;manifest_path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'archive_record_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print(json.dumps(record),flush=True)
