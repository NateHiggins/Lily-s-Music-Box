from pathlib import Path
import json,hashlib
out=Path(__file__).parent;root=Path('C:/ov/city')
review=json.loads((out/'native_review_01/review.json').read_text())
record=dict(evidence_class='INERT',scope='Actual inspection of all eight native review01 PNGs. No ground,access,runtime or artistic acceptance.',
 findings={'proposal_overview':'Whole paving visible; continuous rounded roadway and footway geometry. Existing ground deliberately excluded.',
 'uncut_ground_conflict':'Original apron visibly occludes the new road; retained negative control confirms need for coordinated dual-provider ground cuts.',
 'main_connection':'Road/curb returns and metre-scale paving texture visible; no loaded collision qualification.',
 'near_row':'Intended architecture absent; invalid entrance-context framing.',
 'preserved_corner':'Notched paving visible but intended stoop/railings absent; invalid context framing.',
 'connector':'Curved return and paving visible, intended architecture absent.',
 'far_row':'Intended factory absent; invalid entrance-context framing.',
 'lower_proposal_overview':'Whole replacement body visible; no conspicuous overview silhouette change. Not a loaded LOD transition test.'},
 captures=review['captures'],ground_cut_implemented=False)
path=out/'native_inspection_01.json';assert not path.exists();path.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
p=json.loads((out/'ground_cut_handoff_01.json').read_text());bindings={k:hashlib.sha256((root/k).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for k in p['source_sha256']}
assert bindings==p['source_sha256']
path=out/'handoff_binding_check_01.json';assert not path.exists();path.write_text(json.dumps(dict(evidence_class='INERT',normalization='LF, as original handoff producer',all_exact=True,source_sha256=bindings),indent=2),encoding='utf-8',newline='\n')
