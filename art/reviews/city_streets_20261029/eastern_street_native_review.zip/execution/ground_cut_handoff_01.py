from pathlib import Path
import json,sys,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent
sys.path.insert(0,str(root/'art/blender/scripts'))
from city_street_geometry import district_topology,rectangle,intersection,cut,area,clean
plan=json.loads((root/'art/data/city_streets/source_plan.json').read_text());district=plan['districts'][0]
frame=json.loads((root/'game/data/orison_v2/exterior/street_frame.json').read_text());layout=json.loads((root/'game/data/orison_v2_blockout.json').read_text())
door=next(r for r in layout['doors'] if r['id']=='F01_DOOR_06');offset=door['center'][1]+frame['source_threshold_z'];assert abs(offset+1.855)<1e-9
ground=json.loads((root/'art/blender/city_ground_apron_construction.json').read_text());b=ground['retained_ground_bounds'];retained=rectangle([b[0],b[2],b[3],b[5]])
rows=[]
for lod,segments in enumerate([12,8]):
    result=district_topology(district,segments,plan['curb_width_m'],plan['curb_cap_overhang_m'])
    regions=[clean([(-x,y+offset) for x,y in p]) for p in result['road']+result['curb_caps']]
    retained_pieces=[];apron_pieces=[]
    for p in regions:
        inside=intersection(p,retained)
        if inside:retained_pieces.append(inside)
        apron_pieces.extend(cut(p,[retained]))
    rows.append(dict(lod=lod,ground_frame_cut_regions=regions,retained_ground_intersections=retained_pieces,apron_intersections=apron_pieces,subgrade_profile_m=sorted([[-x,h] for x,h in district['ground_cut_profile_m']]),padding_m=plan['lod_error_m']+plan['joint_m']))
assert all(r['retained_ground_intersections'] and r['apron_intersections'] for r in rows)
record=dict(evidence_class='INERT',scope='Native ground integration request derived from authored paving. No ground/grade file or mesh was changed;not implemented support,collision,visual or runtime acceptance.',frame='ORISON_V2_BUILDING_FRAME_XZ',winding='CCW after normalization in X/Z',conversion=dict(street_native_xy_to_ground_xz='(-x,y+source_threshold_z+door_center_z)',source_threshold_z=frame['source_threshold_z'],door_center_z=door['center'][1],offset_z=offset),required_owners=['orison_ground','city_ground_apron'],ground_cut_implemented=False,lods=rows,notes=['Both ground providers are affected;cutting only the outer apron leaves the first25m of main extension covered.','Regions include native road and cap surfaces. Reconcile the near/lower union to avoid exposed soil between different curve samplings.','Padding is Euclidean union clearance,not unrestricted mitres around narrow triangulation ears. Preserve open street-continuation planes.','Roadtop is-.1m at streetX115 and-.1525m atX135+;uncut apron roof-.02m would cover it. Do not call a buried road finished.','Curbs/footways do not create a new player boundary. Existing450m temporary limit andallshop/access/traffic authorities remain.'],source_sha256={p:hashlib.sha256((root/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in ['art/data/city_streets/source_plan.json','art/blender/scripts/city_street_geometry.py','art/blender/city_ground_apron_construction.json','game/data/orison_v2/exterior/street_frame.json','game/data/orison_v2_blockout.json']})
path=out/'ground_cut_handoff_01.json';assert not path.exists();path.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print([(r['lod'],len(r['retained_ground_intersections']),len(r['apron_intersections'])) for r in rows])
