from pathlib import Path
import ast,json,struct,hashlib,subprocess
root=Path('C:/ov/city');out=Path(__file__).parent
reader=out.parent/'bodega_frontage_reconciliation_01/check_preservation_01.py'
tree=ast.parse(reader.read_text(encoding='utf-8-sig'));exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(reader),'exec'))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
record=dict(evidence_class='INERT',scope='Exact old street export projections and other asset hashes before new native generation. No asset duplicates.',commit=head,parts={},other_assets={})
for family in ['city_streets','city_streets_lod1']:
    path=f'game/assets/props/{family}.glb'
    expected=subprocess.check_output(['git','rev-parse','HEAD:'+path],cwd=root,text=True).strip();actual=subprocess.check_output(['git','hash-object',path],cwd=root,text=True).strip();assert actual==expected
    record['parts'][family]=projection((root/path).read_bytes())
previous=json.loads((out.parent/'eastern_row_01/baseline_01.json').read_text())
paths=[p for p in previous['retained_assets'] if 'city_streets' not in p]
paths += [f'game/assets/props/{name}.glb' for name in ['city_horizon_near','city_horizon_far','city_horizon_lod1']]
for path in paths:record['other_assets'][path]=hashlib.sha256((root/path).read_bytes()).hexdigest()
path=out/'baseline_01.json';assert not path.exists();path.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
for relative in ['art/blender/scripts/build_city_streets.py','art/blender/scripts/city_street_geometry.py','art/data/city_streets/source_plan.json']:
    (out/Path(relative).name).write_text((root/relative).read_text(),encoding='utf-8',newline='\n')
print('Baseline',head,'street rosters',[len(v) for v in record['parts'].values()],'other assets',len(record['other_assets']))
