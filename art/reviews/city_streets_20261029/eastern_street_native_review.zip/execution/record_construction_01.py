from pathlib import Path
import json
root=Path('C:/ov/city');out=Path(__file__).parent
record=dict(evidence_class='INERT',scope='Correction to review01/02 context claims; originals remain untouched.',
 cause='Library objects were linked but matrix_world registration ran before dependency-graph evaluation. Source object placement was lost; meshes rendered near origin.',
 withdrawn=['review01/02 architecture placement','review01 uncut-ground context interpretation in native_inspection_01.json','entrance and corner context from review01/02'],
 retained=['294 exact native/export part roundtrips per execution','Source hashes unchanged','Road/curb/footway shape-only views'],
 repair='Review03 evaluates linked objects before registration and asserts actual near/far envelope coordinates before rendering.',
 acceptance='No ground/access/runtime/artistic acceptance; review03 inspection pending.')
path=out/'context_review_correction_01.json';assert not path.exists();path.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
path=root/'design/V2_CITY_CONTEXT_REPORT_2026-10-19.md'
text=path.read_text(encoding='utf-8')
text+='''

### Eastern street construction and native review, 2026-10-31

Evidence class: **INERT**. Five-form checkpoint **c1f1fb68385dc671e813dedc0b41e16f58a7134b** is committed/pushed; the following street work is a separate construction checkpoint. Existing native street producer now builds connected road, rounded curb/cap returns and continuous footways from worldX115 to eastern frontsX150/207. The original corner stoop/railings and eight scenic/raised entrances have reserved masks. Main connection and far continuation remain open, with no new player wall or traffic authority change. Lower replacement paving retains all road/curb/walk bodies with coarser slab joints and curve sampling; measured source sagitta0.005353/0.012038m is within existing0.025m LOD allowance.

Owned CPU2 generation completes13.025074s/exit0:7,508 closed native stocks,198 exported parts per level and62,828→22,664 triangles. Exact preservation retains51 old parts per level,ten other assets and street-loader/traffic authorities. Both exports have zero failing UV surfaces; source approach/open-end/reserved-step controls pass three tests. These counts are not loaded collision, rendering cost or performance results. Original ground still covers the new road: both retained ground and apron require coordinated cuts before delivery as playable pavement. Ground integration remains canonical-owned. Original handoff01 still matches all five LF-normalized source bindings; no source topology change is concealed.

Native review01 completes143.822133s with294 exact new-part float32 native/export roundtrips andeight frames; all eight viewed. Detail views miss intended architecture. Camera-only repeat02 completes72.067624s, but its first inspected frame still misses context. A2.39s bounds diagnostic identifies the external review-harness defect: library objects were transformed before dependency-graph evaluation initialized their source placement. **Review01/02 architecture and actual-ground context claims are withdrawn**, including the original negative-control interpretation in native_inspection_01.json. Original frames, scripts and diagnosis remain intact. Shape-only paving and exact export comparisons remain useful; no entrance/ground acceptance follows. Corrected03 evaluates linked objects before registration and asserts near/far source envelopes before six context renders; inspection pending. Working evidence: **C:/ov/reports/city_streets_20261029/eastern_street_01/**. No Godot run, loaded mipmap/LOD, actual-controller route or artistic acceptance is added.
'''
path.write_text(text,encoding='utf-8',newline='\n')
path=root/'TASKS.md';text=path.read_text(encoding='utf-8')
old='No new Godot/play/render-cost acceptance;native street/ground reservation proposal andloaded qualification still required.'
new='Five-form checkpoint c1f1fb68 is pushed. Connected eastern road/curbs/footways are generated separately:62,828→22,664 triangles,zero UV failures,51 old parts perLOD/ten assets exact. Native review context-harness failure is preserved; corrected dependency-graph registration review is pending. Both ground providers still require canonical-owned cuts. No new Godot/play/render-cost acceptance;street context review,ground integration andloaded qualification remain required.'
assert text.count(old)==1;text=text.replace(old,new);path.write_text(text,encoding='utf-8',newline='\n')
