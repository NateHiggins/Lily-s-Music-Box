from pathlib import Path
import json,hashlib
out=Path(__file__).parent;root=Path('C:/ov/city')
review=json.loads((out/'native_review_03/review.json').read_text())
record=dict(evidence_class='INERT',scope='All six corrected context PNGs actually inspected; native shape/context only, no integrated support/collision/runtime/artistic acceptance.',
 sources_unchanged=review['sources_unchanged'],captures=review['captures'],
 findings={'registered_overview':'Expected eastern buildings now sit beside authored roadway and footways, with rounded connected returns.',
 'registered_uncut_ground':'Correctly registered original apron visibly covers new road stretches, establishing the outstanding integration conflict.',
 'near_row':'Tinshop and raised-basement houses with approaches/stoops visible. No conspicuous curb crossing a door; actual controller clearance remains untested.',
 'preserved_corner':'Original stoop and iron railings remain visible with walk route in front. Reserved mask leaves an exposed patch beside stair when ground is hidden; reconcile support/appearance in combined ground review.',
 'connector':'Rounded connector curb, footways and adjacent mill corner visible with distinct paving/road surfaces.',
 'far_row':'Factory scenic entrance and continuous front walk visible. Shadow is dark; this staging render is not a lighting/artistic acceptance.'},
 unresolved=['Both ground providers need coordinated cuts','Combined support at reserved entrance masks','Loaded materials,UV,mipmaps and LOD transitions','Actual controller access and measured rendering cost','Dark context lighting/artistic review'])
path=out/'native_inspection_03.json';assert not path.exists();path.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
bindings={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ['game/assets/props/city_streets.glb','game/assets/props/city_streets_lod1.glb','art/blender/scripts/build_city_streets.py','art/blender/scripts/city_street_geometry.py','art/data/city_streets/source_plan.json']}
path=out/'uv_source_binding_01.json';assert not path.exists();path.write_text(json.dumps(dict(evidence_class='INERT',audit='uv_audit_01.json',audit_sha256=hashlib.sha256((out/'uv_audit_01.json').read_bytes()).hexdigest(),raw_source_sha256=bindings,scope='Unchanged generated exports/source since UV audit; no loaded UV/mipmap grant.'),indent=2),encoding='utf-8',newline='\n')
path=root/'design/V2_CITY_CONTEXT_REPORT_2026-10-19.md';text=path.read_text(encoding='utf-8')
text+='''

Corrected native review03 is terminal155.857818s/exit0/no timeout:294 exact float32 native/export roundtrips andsix corrected context frames,all actually inspected. Registered bounds now match the near tinshop,old corner andfar mill; overview shows buildings along the authored streets. Original apron visibly conceals road stretches in the corrected same-pose negative control. Detail views show the two raised entries,tinshop front,retained corner stoop/railings,connector andfar mill entrance beside the new walk. The reserved corner mask exposes a patch beside the stair when ground is hidden; combined support/appearance there remains an explicit integration check. Native staging shadows are dark and do not establish lighting/artistic acceptance. Original01/02 context failures remain withdrawn and preserved separately. Three street source tests pass in0.895s;reader NEW0;design lint clean. No own Blender process remains. No new Godot run or runtime claim. Ground handoff01 source bindings remain exact with their declared LF normalization;no corrected topology handoff is needed.
'''
path.write_text(text,encoding='utf-8',newline='\n')
path=root/'TASKS.md';text=path.read_text(encoding='utf-8');old='Native review context-harness failure is preserved; corrected dependency-graph registration review is pending.';new='Native context-harness failure is preserved; corrected six-frame review is inspected,294 roundtrips exact. Reserved corner-mask support/appearance anddark staging shadows remain explicit combined-review items.';assert text.count(old)==1;path.write_text(text.replace(old,new),encoding='utf-8',newline='\n')
