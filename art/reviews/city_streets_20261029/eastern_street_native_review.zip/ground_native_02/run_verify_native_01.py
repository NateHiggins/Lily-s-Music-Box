from pathlib import Path
import json,hashlib,subprocess,datetime,os
ROOT=Path('C:/PleaseRemainOnTheLine');OUT=Path(__file__).parent/'native_verification_01'
OUT.mkdir(exist_ok=False)
scripts=[ROOT/'art/blender/scripts/inspect_orison_ground.py',Path(__file__).with_name('review_cut_01.py')]
inputs=[ROOT/p for p in ['art/blender/orison_ground.blend','game/assets/props/orison_ground.glb','art/blender/orison_ground_construction.json','art/blender/city_ground_apron.blend','game/assets/props/city_ground_apron.glb','art/blender/city_ground_apron_construction.json']]+scripts
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p):sha(p) for p in inputs}
env=os.environ.copy();env['ORISON_GROUND_REVIEW_DIR']=str(OUT/'base_geometry');env['ORISON_GROUND_VERIFY_ONLY']='1'
cmd=['C:/Program Files/Blender Foundation/Blender 5.2/blender.exe','--background','--factory-startup','--threads','2','--python-exit-code','1']
for p in scripts:cmd+=['--python',str(p)]
record={'evidence_class':'INERT','started_utc':datetime.datetime.now(datetime.UTC).isoformat(),'command':cmd,'source_hashes':before,'timeout_seconds':600}
with (OUT/'blender.log').open('w',encoding='utf-8') as log:
 process=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT);record['pid']=process.pid
 (OUT/'execution.json').write_text(json.dumps(record,indent=2))
 try:record['exit_code']=process.wait(timeout=600)
 except subprocess.TimeoutExpired:process.kill();process.wait();record['exit_code']=124;record['owned_timeout']=True
record['finished_utc']=datetime.datetime.now(datetime.UTC).isoformat();record['changed_inputs']=[str(p) for p in inputs if sha(p)!=before[str(p)]]
(OUT/'execution.json').write_text(json.dumps(record,indent=2));print(json.dumps({k:v for k,v in record.items() if k not in ['command','source_hashes']},indent=2),flush=True)
raise SystemExit(record['exit_code'])
