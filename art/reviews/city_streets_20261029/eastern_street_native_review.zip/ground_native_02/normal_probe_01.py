from pathlib import Path
import bpy,json,sys,numpy as np
ROOT=Path('C:/PleaseRemainOnTheLine');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from fabrication_normals import stock_corner_normals
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'art/blender/city_ground_apron.blend'))
obj=bpy.data.objects['Horizon_north__soil'];m=obj.data
normals=np.asarray([n.vector[:] for n in m.corner_normals],dtype=float);expected=np.asarray(stock_corner_normals(m));records=[];bad=[]
for f in m.polygons:
    p=np.asarray([m.vertices[i].co[:] for i in f.vertices],dtype=float)
    n=np.cross(p[1]-p[0],p[2]-p[0]);n/=np.linalg.norm(n)
    ids=list(f.loop_indices)
    if np.min(normals[ids]@n)<.7:
        records.append({'face':f.index,'native_normal':list(f.normal),'geometric_normal':n.tolist(),'current_corners':normals[ids].tolist(),'authored_corners':expected[ids].tolist()});bad+=ids
for i in bad:expected[i]=0.
m.normals_split_custom_set(expected.tolist());m.update();bpy.context.view_layer.update()
for row in records:
    f=m.polygons[row['face']];row['auto_corners']=[list(m.corner_normals[i].vector) for i in f.loop_indices]
print(json.dumps(records,indent=2),flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps({'evidence_class':'INERT','failures':records},indent=2))
