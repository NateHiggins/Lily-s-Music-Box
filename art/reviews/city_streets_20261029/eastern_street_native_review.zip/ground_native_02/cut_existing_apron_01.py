from pathlib import Path
import json,sys,time,hashlib
import bpy,bmesh
from mathutils import Matrix,Vector
ROOT=Path('C:/PleaseRemainOnTheLine');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_ground_apron_geometry import street_cut_footprints,exported_bounds,apron_boxes
from ground_closed_union import apply_soil_cuts
path=ROOT/'art/blender/city_ground_apron.blend';source_sha=hashlib.sha256(path.read_bytes()).hexdigest()
bpy.ops.wm.open_mainfile(filepath=str(path))
collection=bpy.data.collections['EditableReliefStocks'];obj=collection.objects['west_ground']
metadata=json.loads((ROOT/'art/blender/city_ground_apron_construction.json').read_text())
plan=json.loads((ROOT/'art/data/city_ground_apron/source_plan.json').read_text())
old=next(r for r in metadata['boxes'] if r['id']=='west')
new=apron_boxes(exported_bounds((ROOT/'game/assets/props/orison_ground.glb').read_bytes()),plan['outer_rect'],plan['slab_depth'])[0]
assert all(old['bounds'][i]==new['bounds'][i] for i in [0,2,3,4,5]),(old,new)
bpy.context.view_layer.update();frame=[list(row) for row in obj.matrix_world]
def volume():
    bm=bmesh.new();bm.from_mesh(obj.data);result=bm.calc_volume(signed=True);bm.free();return result
before=volume();obj.data.transform(obj.matrix_world);obj.matrix_world=Matrix.Identity(4);bpy.context.view_layer.update()
after=volume();assert abs(before-after)<.001,('world bake changed source volume',before,after)
spec=street_cut_footprints(*[json.loads((ROOT/p).read_text()) for p in ['art/data/city_streets/source_plan.json','game/data/orison_v2/exterior/street_frame.json','game/data/orison_v2_blockout.json']])
start=time.monotonic();faces,proof=apply_soil_cuts(obj,collection,spec,1166.0072215507666)
assert hashlib.sha256(path.read_bytes()).hexdigest()==source_sha
record={'evidence_class':'INERT','scope':'Read-only existing west-apron closed stock; same source envelope as failed build04,translation baked before native CSG. Not export/runtime acceptance.','seconds':time.monotonic()-start,'native_source_sha256':source_sha,'original_frame':frame,'bake_volume_error_m3':abs(before-after),'proof':proof}
(OUT/'cut_existing_apron_01.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2),flush=True)
