from pathlib import Path
import json,sys,collections,math
import bpy,bmesh
from mathutils import Vector
ROOT=Path('C:/PleaseRemainOnTheLine');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_ground_apron_geometry import soil_cut_prisms,street_cut_footprints,convex_union_boundaries,_area_xmoment
from city_street_geometry import overlap
bpy.ops.wm.read_factory_settings(use_empty=True)
spec=street_cut_footprints(*[json.loads((ROOT/p).read_text()) for p in ['art/data/city_streets/source_plan.json','game/data/orison_v2/exterior/street_frame.json','game/data/orison_v2_blockout.json']])
groups=collections.defaultdict(list)
for p in soil_cut_prisms(spec):
    if overlap([-140,-108,140,76],p['bounds']):groups[(p['slope'],p['intercept'])].append(p['polygon'])
rows=[]
for (slope,intercept),polygons in groups.items():
 for p in convex_union_boundaries(polygons):
    n=len(p);vertices=[(x,-z,slope*x+intercept) for x,z in p]+[(x,-z,1.) for x,z in p]
    faces=[tuple(range(n)),tuple(reversed(range(n,2*n)))]+[(j,i,i+n,j+n) for i in range(n) for j in [(i+1)%n]]
    mesh=bpy.data.meshes.new('Cut');mesh.from_pydata(vertices,[],faces);mesh.update()
    bm=bmesh.new();bm.from_mesh(mesh);bm.normal_update();bm.faces.ensure_lookup_table()
    area,moment=_area_xmoment(p);expected=area*(1.-intercept)-slope*moment
    row={'points':n,'unique_float32_points':len(set(tuple(v.co) for v in bm.verts)),'zero_faces':sum(f.calc_area()<1e-12 for f in bm.faces),'zero_edges':sum(e.calc_length()<1e-9 for e in bm.edges),'volume':bm.calc_volume(signed=True),'expected':expected,'nonmanifold':sum(not e.is_manifold for e in bm.edges),'cap_normals':[tuple(bm.faces[i].normal) for i in range(2)]}
    bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-8)
    bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=1e-8)
    bmesh.ops.triangulate(bm,faces=list(bm.faces))
    bm.normal_update();row['cleaned']={'vertices':len(bm.verts),'zero_faces':sum(f.calc_area()<1e-12 for f in bm.faces),'volume':bm.calc_volume(signed=True),'nonmanifold':sum(not e.is_manifold for e in bm.edges)}
    bm.free();rows.append(row)
(OUT/'operand_probe_02.json').write_text(json.dumps({'evidence_class':'INERT','operands':rows},indent=2));print(json.dumps(rows,indent=2),flush=True)
