from pathlib import Path
import bpy,hashlib,json,sys,numpy as np,time
ROOT=Path('C:/PleaseRemainOnTheLine');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from ground_closed_union import apply_soil_cuts
from city_ground_apron_geometry import street_cut_footprints
def mesh_hash(obj):
    from collections import Counter
    mesh=obj.data;mesh.calc_loop_triangles();counts=Counter()
    for tri in mesh.loop_triangles:
        p=tuple(tuple(float(c) for c in mesh.vertices[i].co) for i in tri.vertices)
        oriented=min(p,p[1:]+p[:1],p[2:]+p[:2])
        counts[(mesh.polygons[tri.polygon_index].material_index,oriented)]+=1
    return hashlib.sha256(json.dumps(sorted(counts.items()),separators=(',',':')).encode()).hexdigest()
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'art/blender/orison_ground.blend'))
expected=mesh_hash(bpy.data.objects['OrisonGroundClosedUnion'])
base_frame=[list(r) for r in bpy.data.objects['OrisonGroundClosedUnion'].matrix_world]
original=OUT/'precut_original_01.blend';assert original.is_file()
bpy.ops.wm.open_mainfile(filepath=str(original))
obj=bpy.data.objects['OrisonGroundClosedUnion'];collection=bpy.data.collections['OrisonGroundConstruction']
spec=street_cut_footprints(*[json.loads((ROOT/p).read_text()) for p in ['art/data/city_streets/source_plan.json','game/data/orison_v2/exterior/street_frame.json','game/data/orison_v2_blockout.json']])
start=time.monotonic();faces,proof=apply_soil_cuts(obj,collection,spec,185.15557345828478)
actual=mesh_hash(obj);assert actual==expected,('Native source geometry changed',actual,expected)
record={'evidence_class':'INERT','scope':'Full-size native cut replay from exact pre-cut Git stock with corrected hidden-pose evaluation; exact oriented float32 triangle coordinates and original/new face material categories (index ordering excluded) match already-exported base. Supports only helper binding renewal; no runtime acceptance.','seconds':time.monotonic()-start,'original_native_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'base_frame':base_frame,'exact_closed_source_projection_sha256':actual,'helper_sha256':hashlib.sha256((ROOT/'art/blender/scripts/ground_closed_union.py').read_bytes()).hexdigest(),'proof':proof}
paths=[ROOT/'art/blender/orison_ground_construction.json',ROOT/'game/tests/fixtures/orison_ground_construction.json']
raw=[p.read_bytes() for p in paths];assert raw[0]==raw[1]
data=json.loads(raw[0]);key='art/blender/scripts/ground_closed_union.py'
import zipfile
with zipfile.ZipFile(OUT/'native_build_04/executed_sources.zip') as z:
    old=hashlib.sha256(z.read(key)).hexdigest()
assert data['source_plan']['bindings'][key]==old
for relative,digest in data['source_plan']['bindings'].items():
    if relative==key:continue
    value=(ROOT/relative).read_bytes()
    if Path(relative).suffix not in ['.blend','.glb','.bin']:value=value.replace(b'\r\n',b'\n')
    assert hashlib.sha256(value).hexdigest()==digest,('Unexpected different binding',relative)
data['source_plan']['bindings'][key]=record['helper_sha256']
data['street_soil_cut']['helper_binding_renewal']={'previous_sha256':old,'current_sha256':record['helper_sha256'],'exact_closed_source_projection_sha256':actual,'method':record['scope']}
encoded=(json.dumps(data,indent=2)+'\n').encode()
try:
    for p in paths:p.write_bytes(encoded)
except Exception:
    for p,value in zip(paths,raw):p.write_bytes(value)
    raise
record['renewed_metadata_sha256']=hashlib.sha256(encoded).hexdigest()
(OUT/'base_binding_projection_02.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2),flush=True)
