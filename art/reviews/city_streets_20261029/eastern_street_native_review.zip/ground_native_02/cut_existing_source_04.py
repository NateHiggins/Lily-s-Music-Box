from pathlib import Path
import json,sys,time,hashlib
import bpy,bmesh
ROOT=Path('C:/PleaseRemainOnTheLine');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_ground_apron_geometry import street_cut_footprints
from ground_closed_union import apply_soil_cuts
source=ROOT/'art/blender/orison_ground.blend';before=hashlib.sha256(source.read_bytes()).hexdigest()
bpy.ops.wm.open_mainfile(filepath=str(source))
obj=bpy.data.objects['OrisonGroundClosedUnion'];collection=bpy.data.collections['OrisonGroundConstruction']
metadata=json.loads((ROOT/'art/blender/orison_ground_construction.json').read_text())
bm=bmesh.new();bm.from_mesh(obj.data);volume=bm.calc_volume(signed=True);bm.free()
assert abs(volume-181580.20113449477)<1e-7,volume
assert abs(metadata['exterior_roof_cut']['expected_remaining_volume_m3']-181580.2010832379)<1e-9
spec=street_cut_footprints(*[json.loads((ROOT/p).read_text()) for p in ['art/data/city_streets/source_plan.json','game/data/orison_v2/exterior/street_frame.json','game/data/orison_v2_blockout.json']])
start=time.monotonic()
try:faces,proof=apply_soil_cuts(obj,collection,spec,185.15557345828478)
except Exception:
    bm=bmesh.new();bm.from_mesh(obj.data)
    bad=[e for e in bm.edges if not e.is_manifold]
    record={'evidence_class':'INERT','seconds':time.monotonic()-start,'faces':len(bm.faces),'vertices':len(bm.verts),'volume':bm.calc_volume(signed=True),'nonmanifold_edges':len(bad),'bad_edges':[{'points':[list(v.co) for v in e.verts],'faces':len(e.link_faces)} for e in bad[:100]]}
    (OUT/'cut_existing_source_04_failure.json').write_text(json.dumps(record,indent=2));bm.free()
    bpy.data.libraries.write(str(OUT/'cut_existing_source_04_failed_INERT.blend'),{obj},compress=True)
    print(json.dumps(record),flush=True)
    raise
assert hashlib.sha256(source.read_bytes()).hexdigest()==before
record={'evidence_class':'INERT','scope':'Read-only existing full-size closed native stock,exact same pre-cut volume as build03; actual compact cut control. No export/UV/runtime acceptance.','seconds':time.monotonic()-start,'native_source_sha256':before,'proof':proof}
(OUT/'cut_existing_source_04.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2),flush=True)
