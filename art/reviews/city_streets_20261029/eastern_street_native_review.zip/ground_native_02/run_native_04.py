from pathlib import Path
import datetime, hashlib, json, subprocess, zipfile

ROOT=Path('C:/PleaseRemainOnTheLine')
OUT=Path(__file__).parent/'native_build_04'
OUT.mkdir(exist_ok=False)
def sha(raw): return hashlib.sha256(raw).hexdigest()
paths=subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).splitlines()
imports=[p for p in paths if p.endswith('.import')]
if imports:
    records=[]
    with zipfile.ZipFile(OUT/'import_lineendings.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
        for relative in imports:
            raw=(ROOT/relative).read_bytes()
            original=subprocess.check_output(['git','show','HEAD:'+relative],cwd=ROOT)
            assert raw.replace(b'\r\n',b'\n')==original.replace(b'\r\n',b'\n'),relative
            archive.writestr(relative,raw)
            records.append({'path':relative,'sha256':sha(raw)})
    with zipfile.ZipFile(OUT/'import_lineendings.zip') as archive:
        assert all(sha(archive.read(r['path']))==r['sha256'] for r in records)
    subprocess.run(['git','restore','--',*imports],cwd=ROOT,check=True)
    (OUT/'import_lineendings.json').write_text(json.dumps(records,indent=2))
builders=['art/blender/scripts/build_orison_ground.py','art/blender/scripts/build_city_ground_apron.py']
sources=sorted(set(paths+builders+['art/blender/scripts/ground_closed_union.py','art/blender/scripts/city_ground_apron_geometry.py','art/blender/scripts/fabrication_native_batch.py','art/blender/scripts/fabrication_chart_batch.py','art/data/city_streets/source_plan.json','game/data/orison_v2/exterior/street_frame.json','game/data/orison_v2_blockout.json']))
records=[]
with zipfile.ZipFile(OUT/'executed_sources.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
    for relative in sources:
        raw=(ROOT/relative).read_bytes()
        archive.writestr(relative,raw)
        records.append({'path':relative,'sha256':sha(raw)})
cmd=['C:/Program Files/Blender Foundation/Blender 5.2/blender.exe','--background','--factory-startup','--threads','2','--python-exit-code','1']
cmd+=['--python',str(Path(__file__).with_name('closed_cut_control_03.py'))]
for relative in builders:cmd+=['--python',str(ROOT/relative)]
record={'evidence_class':'INERT','started_utc':datetime.datetime.now(datetime.UTC).isoformat(),'command':cmd,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'sources':records,'timeout_seconds':900}
(OUT/'execution.json').write_text(json.dumps(record,indent=2))
print('START',str(OUT),flush=True)
with (OUT/'blender.log').open('w',encoding='utf-8') as log:
    try:
        process=subprocess.Popen(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        record['pid']=process.pid
        (OUT/'execution.json').write_text(json.dumps(record,indent=2))
        record['exit_code']=process.wait(timeout=900)
    except subprocess.TimeoutExpired:
        process.kill();process.wait();record['exit_code']=124;record['owned_timeout']=True
record['finished_utc']=datetime.datetime.now(datetime.UTC).isoformat()
record['source_changed_during_run']=[r['path'] for r in records if sha((ROOT/r['path']).read_bytes())!=r['sha256']]
(OUT/'execution.json').write_text(json.dumps(record,indent=2))
print(json.dumps({k:v for k,v in record.items() if k not in ['sources','command']},indent=2),flush=True)
raise SystemExit(record['exit_code'])
