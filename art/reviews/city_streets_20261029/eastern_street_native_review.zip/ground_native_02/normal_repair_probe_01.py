from pathlib import Path
import bpy,bmesh,json,sys,ast,numpy as np
from mathutils import Matrix,Vector
ROOT=Path('C:/PleaseRemainOnTheLine');OUT=Path(__file__).parent/'normal_repair_probe_01'
OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from fabrication_native_batch import partition,export
from fabrication_uvs import chart_for_triangle
source=ROOT/'art/blender/scripts/build_city_ground_apron.py';tree=ast.parse(source.read_text())
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(source),'exec'))
collapsed_skinny_edges=0;max_skinny_shift_m=0.;phase_recharts=0;phase_local_fallbacks=0
catalog=json.loads((ROOT/'game/data/runtime_material_sets.json').read_text())['materials']
finish=json.loads((ROOT/'art/data/city_ground_apron/source_plan.json').read_text())['relief']['finishes']['soil']
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'art/blender/city_ground_apron.blend'))
obj=bpy.data.objects['Horizon_north__soil'];matrix=obj.matrix_world.copy()
bm=bmesh.new();bm.from_mesh(obj.data);zero=triangulate_cut_draw(bm);bm.to_mesh(obj.data);bm.free();obj.data.update()
collection=bpy.data.collections.new('Probe');bpy.context.scene.collection.children.link(collection)
part=partition(collection,'Horizon_north__soil_repaired',[obj],finish,obj.data.materials[0],matrix,catalog)
horizontal_phase(part,matrix.translation,'soil')
assert all(n.vector.length>.9 for n in part.data.corner_normals),'Zero native corner normal remains'
(OUT/'art/blender').mkdir(parents=True);(OUT/'game/assets/props').mkdir(parents=True)
proof=export(OUT,'normal_repair',collection)
record={'evidence_class':'INERT','scope':'One saved failing north-soil draw repaired/recharted through the actual native exporter and unchanged strict derivative guard. Not full apron/loaded/artistic acceptance.','zero_triangles':zero,'single_ulp_edges':collapsed_skinny_edges,'max_vertex_shift_m':max_skinny_shift_m,'proof':proof}
(OUT/'result.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2),flush=True)
