from pathlib import Path
import bpy,json
from mathutils import Vector
bpy.ops.wm.read_factory_settings(use_empty=True)
c=bpy.data.collections.new('HiddenSource');bpy.context.scene.collection.children.link(c);c.hide_viewport=True
m=bpy.data.meshes.new('Stock');m.from_pydata([(-180,-500,-10),(180,500,-.02)],[],[]);m.update()
o=bpy.data.objects.new('Stock',m);c.objects.link(o);o.location=(-320,0,0)
bpy.context.view_layer.update();before=[list(r) for r in o.matrix_world]
c.hide_viewport=False;bpy.context.view_layer.update();after=[list(r) for r in o.matrix_world]
record={'evidence_class':'INERT','hidden_source_matrix_after_update':before,'visible_source_matrix_after_update':after,'source_location':list(o.location)}
Path(__file__).with_suffix('.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
