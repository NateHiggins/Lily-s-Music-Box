"""Narrow native-source refresh after actual owner/old-mask equivalence checks."""
from pathlib import Path
import collections,hashlib,json,re,sys
ROOT=Path('C:/PleaseRemainOnTheLine');HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from run_receipt import runtime_inputs_sha256
from grade_source_snapshot import validate
PLAN='art/data/orison_ground/retained_grade_source.json'
SURVEY='art/data/orison_ground/discovery/runtime_survey.json'
FOUND='art/blender/city_foundations_construction.json'
FIXTURE='game/tests/fixtures/orison_city_foundations_construction.json'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def digest(path):
    raw=path.read_bytes()
    return sha(raw if path.suffix in ['.blend','.glb'] else raw.replace(b'\r\n',b'\n'))
original={p:(ROOT/p).read_bytes() for p in [PLAN,SURVEY,FOUND,FIXTURE]}
plan=json.loads(original[PLAN]);old=json.loads(original[SURVEY])
new_path=HERE/'grade_discovery_01/frames/grade_owners.json';new=json.loads(new_path.read_bytes())
native=json.loads((HERE/'native_classification_01.json').read_bytes())
assert new['evidence_class']=='INERT' and new['failures']==0
assert new['source']['runtime_inputs_sha256']==runtime_inputs_sha256(ROOT)
assert old['poses']==new['poses']
normalize=lambda p:re.sub(r'(@[A-Za-z0-9_]+)@\d+',r'\1',p)
def groups(data):
    result=collections.defaultdict(list)
    for r in data['records']:result[(normalize(r['owner']),normalize(r['shape_owner']),r['shape_type'],r['aligned'])].append(tuple(r['bounds']))
    return result
a,b=groups(old),groups(new)
assert set(a)==set(b) and len(old['records'])==len(new['records'])==573
assert all(len(a[k])==len(b[k]) for k in a)
maximum=max(abs(x-y) for k in a for u,v in zip(sorted(a[k]),sorted(b[k])) for x,y in zip(u,v))
assert maximum==0.,maximum
lookup={(r['owner'],r['id']):r for r in native['records']};checked=0
for category in ['retained_solids','occupation_reservations','surface_exclusions']:
    for row in plan[category]:
        if row['owner'] not in ['CityTransport','CityStreets','CityStreetsAirClearance']:continue
        actual=lookup[(row['owner'],row['id'])]
        assert actual['kind']==row['kind'] and max(abs(x-y) for x,y in zip(actual['bounds'],row['bounds']))<.00003
        checked+=1
assert checked==7729
for row in plan['retained_solids']:
    if row['kind']!='actual_axis_aligned_box':continue
    matches=[r for r in new['records'] if r['owner']==row['owner'] and r['aligned'] and max(abs(x-y) for x,y in zip(r['bounds'],row['bounds']))<.00003]
    assert len(matches)==1,row['owner']
allowed={'art/blender/city_transport_construction.json','art/blender/city_streets_construction.json',
         'art/blender/city_streets.blend','art/data/city_streets/source_plan.json',
         'art/blender/scripts/build_city_streets.py','art/blender/scripts/city_street_geometry.py',
         'game/assets/props/city_streets.glb','game/assets/props/city_streets_lod1.glb'}
changes={k for k,v in plan['bindings'].items() if k in native['bindings'] and v!=native['bindings'][k]}
assert changes==allowed,changes
for p,h in native['bindings'].items():assert digest(ROOT/p)==h,p
for p,h in plan['bindings'].items():
    if p not in allowed:assert digest(ROOT/p)==h,p
mask_keys=['retained_solids','occupation_reservations','surface_exclusions']
before_masks=sha(json.dumps({k:plan[k] for k in mask_keys},sort_keys=True,separators=(',',':')).encode())
for p in allowed:plan['bindings'][p]=native['bindings'][p]
plan['bindings'][SURVEY]=sha(new_path.read_bytes().replace(b'\r\n',b'\n'))
plan['method']+=' Eastern intake refresh: actual573 aligned-static survey geometry/registration is unchanged; all7729 existing transport/street mask projections are verified against current editable native stock. Retain every original mask; the new district uses a separate source-derived polygon cut, never its mesh AABB as a solid. Previous survey/map remain recoverable at69b57512.'
after_masks=sha(json.dumps({k:plan[k] for k in mask_keys},sort_keys=True,separators=(',',':')).encode())
assert before_masks==after_masks
plan_raw=(json.dumps(plan,indent=2)+'\n').encode()
foundation=json.loads(original[FOUND])
for p,h in foundation['bindings'].items():
    if p!=PLAN:assert digest(ROOT/p)==h,p
foundation['bindings'][PLAN]=sha(plan_raw)
foundation_raw=(json.dumps(foundation,indent=2)+'\n').encode()
try:
    (ROOT/SURVEY).write_bytes(new_path.read_bytes())
    (ROOT/PLAN).write_bytes(plan_raw)
    validate(plan,ROOT)
    (ROOT/FOUND).write_bytes(foundation_raw);(ROOT/FIXTURE).write_bytes(foundation_raw)
except BaseException:
    for p,raw in original.items():(ROOT/p).write_bytes(raw)
    raise
report={'evidence_class':'INERT','method':'Actual discovery and exact consumed-projection reconciliation; no new native geometry or runtime qualification.',
        'original_snapshot_commit':'69b57512','runtime_boxes':573,'maximum_runtime_bound_delta_m':maximum,
        'existing_native_mask_records':checked,'mask_payload_unchanged_sha256':before_masks,
        'allowed_changed_native_bindings':sorted(allowed),'updated_paths':{p:{'before_raw_sha256':sha(original[p]),'after_raw_sha256':sha((ROOT/p).read_bytes())} for p in original}}
(HERE/'grade_source_reconciliation_01.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('GRADE SOURCE RECONCILIATION: 573 actual owners/7729 native records unchanged; original masks byte-equivalent; fresh survey validates.')
