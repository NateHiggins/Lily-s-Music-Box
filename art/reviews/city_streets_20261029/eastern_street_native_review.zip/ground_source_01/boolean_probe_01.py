from pathlib import Path
import json,time
import bpy,bmesh
from mathutils import Vector

OUT=Path(__file__).resolve().parent
bpy.ops.wm.read_factory_settings(use_empty=True)
def box(name,lower,upper,collection=None):
    bpy.ops.mesh.primitive_cube_add(size=1)
    obj=bpy.context.object;obj.name=name
    obj.location=(Vector(lower)+Vector(upper))*.5
    obj.scale=Vector(upper)-Vector(lower)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    if collection is not None:
        for owner in list(obj.users_collection):owner.objects.unlink(obj)
        collection.objects.link(obj)
    return obj
def volume(obj):
    bm=bmesh.new();bm.from_mesh(obj.data);bm.normal_update()
    assert all(e.is_manifold for e in bm.edges)
    result=bm.calc_volume(signed=True);bm.free();return result
def subtract(obj,collection):
    mod=obj.modifiers.new('SoilCut','BOOLEAN');mod.operation='DIFFERENCE'
    mod.operand_type='COLLECTION';mod.collection=collection;mod.solver='EXACT';mod.use_self=True
    bpy.context.view_layer.objects.active=obj
    bpy.context.view_layer.update()
    bpy.ops.object.modifier_apply(modifier=mod.name)

started=time.perf_counter()
soil=box('Soil',(0,0,-1),(10,10,0))
original=bpy.data.collections.new('OriginalReservations');bpy.context.scene.collection.children.link(original)
box('ExistingPavingVoid',(2,2,-.4),(3,6,1),original)
subtract(soil,original)
before=volume(soil);assert abs(before-98.4)<.0001,before
cutters=bpy.data.collections.new('StreetCut');bpy.context.scene.collection.children.link(cutters)
box('FirstStock',(2,2,-.5),(6,6,1),cutters)
box('OverlappingStock',(4,2,-.5),(8,6,1),cutters)
subtract(soil,cutters)
after=volume(soil);assert abs(after-88.)<.0001,after
rna=bpy.types.BooleanModifier.bl_rna.properties
report={'evidence_class':'INERT','scope':'Blender collection Boolean API and closed-source overlap/retained-void diagnostic only. No game asset, support, UV or runtime acceptance.',
        'blender':bpy.app.version_string,'seconds':time.perf_counter()-started,
        'source_volume_m3':before,'result_volume_m3':after,'removed_m3':before-after,
        'expected_result_m3':88.,'closed':True,
        'api':{name:rna[name].description for name in ['operand_type','solver','use_self']}}
(OUT/'boolean_probe_01.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('BOOLEAN SOIL API PROBE:',json.dumps(report),flush=True)
