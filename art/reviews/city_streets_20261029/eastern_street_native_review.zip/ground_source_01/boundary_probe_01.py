import math,json,sys,time
from pathlib import Path
ROOT=Path('C:/PleaseRemainOnTheLine');sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_street_geometry import bounds,area

def union_boundaries(polygons):
    """Visible directed edges of convex stocks; no interior arrangement mesh."""
    boxes=[bounds(p) for p in polygons];segments=[]
    for i,p in enumerate(polygons):
        for a,b in zip(p,p[1:]+p[:1]):
            vx,vy=b[0]-a[0],b[1]-a[1]
            if math.hypot(vx,vy)<1e-9:continue
            box=[min(a[0],b[0]),min(a[1],b[1]),max(a[0],b[0]),max(a[1],b[1])]
            hidden=[]
            for j,q in enumerate(polygons):
                if i==j:continue
                B=boxes[j]
                if box[0]>B[2]+1e-8 or box[2]<B[0]-1e-8 or box[1]>B[3]+1e-8 or box[3]<B[1]-1e-8:continue
                lo,hi=0.,1.;same=False
                for u,v in zip(q,q[1:]+q[:1]):
                    dx,dy=v[0]-u[0],v[1]-u[1];length=math.hypot(dx,dy)
                    c=(dx*(a[1]-u[1])-dy*(a[0]-u[0]))/length
                    d=(dx*vy-dy*vx)/length
                    if abs(d)<1e-10:
                        if c < -1e-8:hi=-1.;break
                        if abs(c)<1e-8 and dx*vx+dy*vy>0:same=True
                    elif d>0:lo=max(lo,-c/d)
                    else:hi=min(hi,-c/d)
                    if hi<=lo:break
                if hi>lo+1e-12 and not (same and i<j):hidden.append((max(0.,lo),min(1.,hi)))
            start=0.
            for lo,hi in sorted(hidden):
                if hi<=start:continue
                if lo>start+1e-11:segments.append(((a[0]+start*vx,a[1]+start*vy),(a[0]+lo*vx,a[1]+lo*vy)))
                start=max(start,hi)
            if start<1.-1e-11:segments.append(((a[0]+start*vx,a[1]+start*vy),b))
    def key(p):return tuple(round(v,7) for v in p)
    edges={};incoming={}
    for a,b in segments:
        a,b=key(a),key(b)
        if a==b:continue
        assert a not in edges,('branch',a,edges.get(a),b)
        edges[a]=b;incoming[b]=incoming.get(b,0)+1
    assert set(edges)==set(incoming) and all(n==1 for n in incoming.values()),('open',len(edges),len(incoming),list(set(edges)-set(incoming))[:5],list(set(incoming)-set(edges))[:5])
    loops=[]
    while edges:
        first=next(iter(edges));p=[];at=first
        while True:
            p.append(at);at=edges.pop(at)
            if at==first:break
        assert area(p)>0,('hole',area(p))
        loops.append(p)
    return loops

if __name__=='__main__':
    from city_ground_apron_geometry import street_cut_footprints,soil_cut_prisms
    from city_street_geometry import rectangle
    for polygons,expected in [([rectangle([0,0,2,2]),rectangle([1,1,3,3])],7.),([rectangle([0,0,1,1]),rectangle([1,0,2,1])],2.),([rectangle([0,0,2,2])]*2,4.)]:
        loops=union_boundaries(polygons);assert abs(sum(area(p) for p in loops)-expected)<1e-7
    spec=street_cut_footprints(*[json.loads((ROOT/p).read_text()) for p in ['art/data/city_streets/source_plan.json','game/data/orison_v2/exterior/street_frame.json','game/data/orison_v2_blockout.json']])
    prisms=soil_cut_prisms(spec);groups={}
    for p in prisms:groups.setdefault((p['slope'],p['intercept']),[]).append(p['polygon'])
    started=time.monotonic();result=[]
    for profile,polygons in groups.items():
        loops=union_boundaries(polygons)
        result.append({'profile':profile,'source':len(polygons),'loops':loops,'area':sum(area(p) for p in loops)})
        print(profile,len(polygons),len(loops),[len(p) for p in loops],flush=True)
    out={'evidence_class':'INERT','seconds':time.monotonic()-started,'groups':result}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print('PASS',out['seconds'],flush=True)
