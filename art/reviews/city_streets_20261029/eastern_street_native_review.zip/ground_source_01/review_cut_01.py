"""Read-only street construction presentation; uncropped ground conflict retained."""
from pathlib import Path
import bpy,json,hashlib,collections,math
from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree
from bpy_extras.object_utils import world_to_camera_view
ROOT=Path('C:/PleaseRemainOnTheLine');OUT=Path(__file__).parent/'native_review_cut_01';OUT.mkdir(exist_ok=False)
files=['art/blender/city_streets.blend','game/assets/props/city_streets.glb','game/assets/props/city_streets_lod1.glb','art/blender/city_horizon_near.blend','art/blender/city_horizon_far.blend','art/blender/city_elevations.blend','art/blender/city_ground_apron.blend','art/blender/orison_ground.blend']
bindings={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files}
frame=json.loads((ROOT/'game/data/orison_v2/exterior/street_frame.json').read_text());layout=json.loads((ROOT/'game/data/orison_v2_blockout.json').read_text());door=next(r for r in layout['doors'] if r['id']=='F01_DOOR_06')
shift=-(door['center'][1]+frame['source_threshold_z']);registered=Matrix.Translation((0,shift,0))@Matrix.Diagonal((-1.,-1.,1.,1.))
def triangles(obj):
    obj.data.calc_loop_triangles()
    return collections.Counter(tuple(sorted(tuple(float(c) for c in obj.matrix_world@obj.data.vertices[i].co) for i in face.vertices)) for face in obj.data.loop_triangles)
def library(relative,predicate,label,transform=None,offsets=None):
    with bpy.data.libraries.load(str(ROOT/relative),link=False) as (available,loaded):loaded.objects=[name for name in available.objects if predicate(name)]
    assert loaded.objects,(relative,label)
    collection=bpy.data.collections.new(label);bpy.context.scene.collection.children.link(collection)
    for obj in loaded.objects:
        assert obj.type=='MESH' and obj.parent is None,(label,obj.name)
        collection.objects.link(obj);obj.hide_render=False;obj.hide_set(False)
        if offsets:
            key=obj.name.split('__')[0];assert key in offsets,key
            obj.location+=Vector(offsets[key])
    bpy.context.view_layer.update()
    if transform is not None:
        for obj in collection.objects:obj.matrix_world=transform@obj.matrix_world
    bpy.context.view_layer.update();return list(collection.objects)
bpy.ops.wm.open_mainfile(filepath=str(ROOT/files[0]));scene=bpy.context.scene
for obj in scene.objects:
    if obj.type=='MESH':obj.hide_render=True
street={};roundtrips=[]
for lod,path in enumerate(files[1:3]):
    collection=bpy.data.collections['StreetExports_LOD'+str(lod)]
    originals={obj.name:obj for obj in collection.objects};expected={name:triangles(obj) for name,obj in originals.items() if name.startswith('Street_Eastern')}
    materials={name:obj.data.materials[0] for name,obj in originals.items()};before=set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=str(ROOT/path));bpy.context.view_layer.update();imported={}
    for obj in [o for o in bpy.data.objects if o not in before and o.type=='MESH']:
        name=obj.name.split('.')[0];obj.hide_render=bool(lod);assert name in originals,name
        obj.data.materials.clear();obj.data.materials.append(materials[name]);imported[name]=obj
        if name in expected:
            assert triangles(obj)==expected[name],(lod,name,'native/export triangle mismatch')
            assert len(obj.data.uv_layers)==1
            roundtrips.append(dict(lod=lod,part=name,triangles=sum(expected[name].values()),exact_float32_positions=True))
    assert len(imported)==198 and len(expected)==147
    street[lod]=list(imported.values())
    collection.hide_render=True
chosen={'HORIZON_NEAR_2_0_P0R0','HORIZON_NEAR_2_0_P0R1','HORIZON_NEAR_2_0_P0R2','HORIZON_NEAR_2_0_P1','HORIZON_NEAR_2_0_P2','HORIZON_NEAR_2_1_P0R2','HORIZON_NEAR_2_1_P1','HORIZON_NEAR_2_1_P2','HORIZON_NEAR_0_0_P0R0','HORIZON_NEAR_0_0_P0R1','HORIZON_FAR_2_1_P0','HORIZON_FAR_2_1_P1'}
for relative in files[3:5]:library(relative,lambda name:name.split('__')[0] in chosen,'RegisteredHorizon',registered)
profiles=json.loads((ROOT/'art/data/city_elevations/source_plan.json').read_text())['buildings'];offsets={r['id']:r.get('assembly_translation_m',[0,0,0]) for r in profiles}
library(files[5],lambda name:'__' in name and name.split('__')[0] in offsets,'RetainedCity',offsets=offsets)
ground=library(files[6],lambda name:name.startswith('Horizon_') and '__' in name,'ActualCutApron',registered)
ground += library(files[7],lambda name:name.startswith(('Court_','Seat_','StreetCut_','GradeCut_')),'ActualCutRetainedGround',registered)
for obj in ground:obj.hide_render=False
for image in bpy.data.images:
    if image.source!='FILE' or image.packed_file:continue
    path=ROOT/'game/assets/building/textures'/Path(image.filepath).name;assert path.is_file(),path
    image.filepath=str(path);image.reload();assert min(image.size)>0
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.cycles.use_denoising=True;scene.cycles.max_bounces=4
scene.render.threads_mode='FIXED';scene.render.threads=2;scene.render.image_settings.file_format='PNG';scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX'
world=bpy.data.worlds.new('Native street review sky');world.use_nodes=True;scene.world=world;world.node_tree.nodes['Background'].inputs[0].default_value=(.18,.21,.27,1);world.node_tree.nodes['Background'].inputs[1].default_value=.7
sun=bpy.data.objects.new('Review sun',bpy.data.lights.new('Review sun','SUN'));scene.collection.objects.link(sun);sun.rotation_euler=Vector((-1.,.35,-.9)).to_track_quat('-Z','Y').to_euler();sun.data.energy=2.5;sun.data.angle=.15
camera=bpy.data.objects.new('Street review camera',bpy.data.cameras.new('Street review camera'));scene.collection.objects.link(camera);scene.camera=camera;camera.data.clip_start=.02;camera.data.clip_end=2000.
views=[('cut_overview',(275,40,170),(160,-35,0),True,310.,0,True),
       ('cut_near_row',(137,-130,3.0),(152,-138,3.2),False,25.,0,True),
       ('cut_preserved_corner',(137,-137,3.0),(144,-149,2.0),False,25.,0,True)]

bounds={}
for prefix in ['HORIZON_NEAR_2_0_P0R0','HORIZON_NEAR_0_0_P0R0','HORIZON_FAR_2_1_P0']:
    points=[obj.matrix_world@v.co for obj in scene.objects if obj.type=='MESH' and obj.name.startswith(prefix+'__') for v in obj.data.vertices]
    bounds[prefix]=dict(lo=[min(p[i] for p in points) for i in range(3)],hi=[max(p[i] for p in points) for i in range(3)])
assert bounds['HORIZON_NEAR_2_0_P0R0']['lo'][0]>149
assert bounds['HORIZON_NEAR_2_0_P0R0']['hi'][1]<-139
assert bounds['HORIZON_FAR_2_1_P0']['lo'][0]>206
(OUT/'registered_bounds.json').write_text(json.dumps(bounds,indent=2),encoding='utf-8',newline='\n')
captures=[]
for label,eye,aim,ortho,scale,lod,show_ground in views:
    for level,objects in street.items():
        for obj in objects:obj.hide_render=level!=lod
    for obj in ground:obj.hide_render=not show_ground
    camera.location=eye;camera.rotation_euler=(Vector(aim)-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO' if ortho else 'PERSP'
    camera.data.ortho_scale=scale;camera.data.lens=scale;scene.render.resolution_x=1400 if ortho else 1200;scene.render.resolution_y=1000
    framed=None
    if ortho:
        for attempt in range(24):
            bpy.context.view_layer.update();points=[world_to_camera_view(scene,camera,obj.matrix_world@Vector(c)) for obj in street[lod] if obj.name.startswith('Street_Eastern') for c in obj.bound_box]
            framed=all(p.z>0 and .035<=p.x<=.965 and .035<=p.y<=.965 for p in points)
            if framed:break
            camera.data.ortho_scale*=1.12
        assert framed,(label,'proposal framing')
    path=OUT/(label+'.png');scene.render.filepath=str(path);bpy.ops.render.render(write_still=True)
    captures.append(dict(path=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),lod=lod,actual_cut_ground_visible=show_ground,whole_proposal_framed=framed,scope='Actual regenerated native ground/apron and retained paving/architecture; optical study,not controller access'))
assert len(roundtrips)==294
for path,expected in bindings.items():assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==expected,path
(OUT/'review.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Actual cut native ground/apron and registered retained paving/architecture. No actual movement,Godot,mipmap,rendering-cost or artistic acceptance.',ground_cut_implemented=True,sources_unchanged=bindings,roundtrips=roundtrips,captures=captures,root_to_street_blender_transform=[list(row) for row in registered]),indent=2),encoding='utf-8',newline='\n')
print('NATIVE STREET REVIEW',len(roundtrips),'newpart roundtrips',len(captures),'frames;ACTUAL NATIVE CUTS SHOWN',flush=True)
