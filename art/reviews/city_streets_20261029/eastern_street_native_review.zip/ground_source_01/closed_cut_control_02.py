from pathlib import Path
import json,sys,time
import bpy,bmesh
from mathutils import Vector
ROOT=Path('C:/PleaseRemainOnTheLine');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from ground_closed_union import apply_soil_cuts
from city_ground_apron_geometry import removed_flat_soil_volume
from city_street_geometry import rectangle
bpy.ops.wm.read_factory_settings(use_empty=True)
def box(name,lower,upper,collection):
    bpy.ops.mesh.primitive_cube_add(size=1)
    obj=bpy.context.object;obj.name=name
    obj.location=(Vector(lower)+Vector(upper))*.5;obj.scale=Vector(upper)-Vector(lower)
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    for owner in list(obj.users_collection):owner.objects.unlink(obj)
    collection.objects.link(obj);return obj
source=bpy.data.collections.new('Source');bpy.context.scene.collection.children.link(source)
soil=box('Soil',(0,0,-1),(10,10,0),source)
void=box('OriginalVoid',(2,2,-.4),(3,6,1),source)
bpy.context.view_layer.objects.active=soil;bpy.context.view_layer.update()
mod=soil.modifiers.new('OriginalVoid','BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=void
bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(void,do_unlink=True)
source.hide_viewport=True
spec=[{'polygons':[rectangle([2,-6,6,-2]),rectangle([4,-6,8,-2])], 'subgrade_profile_m':[[0,-.5],[10,-.5]]}]
expected=removed_flat_soil_volume(spec,[0,-10,10,0],0.,[{'bounds':[2,-.4,-6,3,1,-2]}])
assert abs(expected-10.4)<1e-8,expected
started=time.perf_counter();faces,proof=apply_soil_cuts(soil,source,spec,expected)
assert source.hide_viewport and not soil.hide_get()
assert faces and abs(proof['after_m3']-88.)<.001
floor=[p for p in faces if all(abs(v[1]+.5)<1e-6 for v in p)]
assert floor and all((Vector(p[1])-Vector(p[0])).cross(Vector(p[2])-Vector(p[0])).y>0 for p in floor)
report={'evidence_class':'INERT','scope':'Actual shared native cutter on closed toy soil with overlapping footprints and existing void; not a game asset/runtime/UV acceptance.',
        'blender':bpy.app.version_string,'elapsed_s':time.perf_counter()-started,'hidden_owner_restored':True,'new_floor_triangles':len(floor),'proof':proof}
(OUT/'closed_cut_control_02.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('SHARED CLOSED SOIL CUT CONTROL:',json.dumps(report),flush=True)
