# Candidate verification - f14307a7cc66

- candidate `f14307a7cc66ea0ba6db6afa8f19da1db8a0098f`
- base `fb6851f29beeef44ac4aa3b346940ed809053467`
- merge-base `fb6851f29beeef44ac4aa3b346940ed809053467`
- verified 2026-10-30T21:57:35Z from verifier `f14307a7cc66`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 0 regressions, 4 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 0 |

## Blocking reasons (0)

- none

## Needs human review (not blocking) (2)

- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (0)

- none

## Accepted regressions (0)

- none

## Improvements (4)

- v2_surface_qualification: FAIL -> PASS
- v2_surface_qualification: defects 2 -> 0
- v2_surface_qualification: resolved missing or stale rendered review
- v2_surface_qualification: resolved stale surface qualification: rendering inputs changed

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (0)

- none

MERGE-CANDIDATE f14307a7cc66ea0ba6db6afa8f19da1db8a0098f
