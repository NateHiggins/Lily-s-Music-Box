from pathlib import Path
import ast,sys,json,hashlib,copy,types
root=Path('C:/PleaseRemainOnTheLine');out=Path(__file__).parent;sys.path.insert(0,str(root/'art/blender/scripts'))
from city_residential_architecture import ResidentialHouses
from city_industrial_architecture import PianoFactory
from city_residential_architecture import WesternStreetHouses
oldtree=ast.parse((out/'baseline_owner.py').read_text(encoding='utf-8'));fn=next(n for n in oldtree.body if isinstance(n,ast.FunctionDef) and n.name=='occluding_neighbours');ns={'PianoFactory':PianoFactory,'WesternStreetHouses':WesternStreetHouses};exec(compile(ast.Module(body=[fn],type_ignores=[]),'baseline selector','exec'),ns)
baseline=json.loads((out/'baseline_fixture.json').read_bytes());identity='HORIZON_NEAR_0_1_P0R2';rows=[r for r in baseline['buildings'] if 'NEAR' in r['id']];context=ns['occluding_neighbours'](rows,identity);row=next(r for r in rows if r['id']==identity);found={};queries=[]
for lower in [False,True]:
 stock=ResidentialHouses(copy.deepcopy(row),lambda *args:None,context,lower);original=stock.covered
 def covered(self,O,U,N,l,r,z,extra):
  answer=original(O,U,N,l,r,z,extra);saved=self.neighbours
  try:
   for neighbour in saved:
    self.neighbours=[neighbour]
    if original(O,U,N,l,r,z,[]):
     mini={k:neighbour[k] for k in ['id','rect','height_m','grade_datum_m'] if k in neighbour};found[json.dumps(mini,sort_keys=True)]=mini
  finally:self.neighbours=saved
  queries.append(dict(lower=lower,covered=answer));return answer
 stock.covered=types.MethodType(covered,stock);proof=stock.build();print('GABLE',lower,len(proof['windows']),flush=True)
(out/'GABLE_CONTEXT_QUERY.json').write_text(json.dumps({'evidence_class':'INERT','identity':identity,'construction_neighbours':list(found.values()),'queries':len(queries),'baseline_fixture_sha256':hashlib.sha256((out/'baseline_fixture.json').read_bytes()).hexdigest()},indent=2)+'\n');print('GABLE BLOCKERS',len(found),flush=True)
