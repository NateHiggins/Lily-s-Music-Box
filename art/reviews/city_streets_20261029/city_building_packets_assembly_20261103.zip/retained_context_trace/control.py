from pathlib import Path
import ast,copy,sys,json,collections,hashlib
root=Path('C:/PleaseRemainOnTheLine');out=Path(__file__).parent
sys.path.insert(0,str(root/'art/blender/scripts'))
import bpy
import city_horizon_geometry as geo
original_party=geo.party_wall_overlap
active={'id':None};seen=collections.defaultdict(dict);query_rows=[]
def logged_party(first,last,height,neighbours):
 answer=original_party(first,last,height,neighbours)
 hits=[]
 if answer:
  for row in neighbours:
   if original_party(first,last,height,[row]):
    selected={k:row[k] for k in ['id','rect','height_m','grade_datum_m'] if k in row};hits.append(selected)
    if 'id' in selected:seen[active['id']][json.dumps(selected,sort_keys=True)]=selected
 query_rows.append(dict(building=active['id'],first=list(first),last=list(last),height=height,covered=answer,hits=hits))
 return answer
geo.party_wall_overlap=logged_party
owner=root/'art/blender/scripts/build_city_horizon.py';tree=ast.parse(owner.read_text(encoding='utf-8'));oldtree=ast.parse((out/'baseline_owner.py').read_text(encoding='utf-8'))
ns={'ROOT':root,'__file__':str(owner)}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom))],type_ignores=[]),str(owner),'exec'),ns)
from fabrication_native_batch import export
from types import SimpleNamespace
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='occluding_neighbours');oldfn=next(n for n in oldtree.body if isinstance(n,ast.FunctionDef) and n.name=='occluding_neighbours')
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(owner),'exec'),ns);current_selector=ns['occluding_neighbours']
exec(compile(ast.Module(body=[oldfn],type_ignores=[]),'baseline_owner.py','exec'),ns);old_selector=ns['occluding_neighbours']
family=next(n for n in tree.body if isinstance(n,ast.For) and ast.unparse(n.target)=='family')
prefix=copy.deepcopy(family.body[:18])
for n in prefix:
 if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='row' and isinstance(n.iter,ast.Name) and n.iter.id=='rows':
  n.iter=ast.Name(id='_selected_rows',ctx=ast.Load())
  n.body.insert(0,ast.parse("_active['id']=row['id']").body[0])
prefix_code=compile(ast.fix_missing_locations(ast.Module(body=prefix,type_ignores=[])),str(owner),'exec')
idx=tree.body.index(family);lower_code=compile(ast.Module(body=copy.deepcopy(tree.body[idx+1:idx+8]),type_ignores=[]),str(owner),'exec')
current=json.loads((root/'art/blender/city_horizon_construction.json').read_bytes());baseline=json.loads((out/'baseline_fixture.json').read_bytes());plan=json.loads((root/'art/data/city_horizon/source_plan.json').read_bytes());ids={'HORIZON_NEAR_0_0_P0R1','HORIZON_NEAR_0_0_P2','HORIZON_NEAR_0_1_P0R2','HORIZON_FAR_2_1_P1'}
records={};contexts={}
for mode in ['baseline','current','pruned']:
 ns.update(plan=dict(plan,buildings=copy.deepcopy(current['buildings'])),catalog=json.loads((root/'game/data/runtime_material_sets.json').read_bytes())['materials'],replacement_buffers=collections.defaultdict(lambda:([],[])),industrial_checks=[],grade_seats=[],_active=active)
 if mode=='baseline':
  def selector(rows,identity):return old_selector([r for r in baseline['buildings'] if ('NEAR' in r['id'])==('NEAR' in identity)],identity)
 elif mode=='current':selector=current_selector
 else:
  def selector(rows,identity):return contexts[identity]
 ns['occluding_neighbours']=selector;all_rows=[];all_windows=[];assets=[]
 for fam in ['near','far']:
  selected=[r for r in ns['plan']['buildings'] if r['id'] in ids and ('NEAR' in r['id'])==(fam=='near')]
  ns.update(family=fam,_selected_rows=selected);exec(prefix_code,ns);all_rows+=selected;all_windows+=copy.deepcopy(ns['windows'])
  fake=out/mode; (fake/'game/assets/props').mkdir(parents=True,exist_ok=True);(fake/'art/blender').mkdir(parents=True,exist_ok=True)
  export(fake,fam,SimpleNamespace(objects=ns['draws']),staged_output=False,save_native=False);assets.append(dict(role='base',path=str(fake/'game/assets/props'/(fam+'.glb'))))
 ns['all_rows']=all_rows;exec(lower_code,ns)
 export(fake,'lower',SimpleNamespace(objects=ns['lower_draws']),staged_output=False,save_native=False);assets.append(dict(role='lower',path=str(fake/'game/assets/props/lower.glb')))
 records[mode]=dict(assets=assets,windows=all_windows)
 if mode=='baseline':contexts={identity:list(seen[identity].values()) for identity in ids}
 print('CONTROL',mode,len(all_windows),'panes',flush=True)
result=dict(evidence_class='INERT',scope='Four retained profiles only, actual owner AST geometry/grade/chart/partition statements; old/current/pruned source construction contexts. No render,runtime or acceptance.',owner_sha256=hashlib.sha256(owner.read_bytes()).hexdigest(),baseline_owner_sha256=hashlib.sha256((out/'baseline_owner.py').read_bytes()).hexdigest(),contexts=contexts,cases=records)
(out/'CONTROL.json').write_text(json.dumps(result,indent=2)+'\n')
