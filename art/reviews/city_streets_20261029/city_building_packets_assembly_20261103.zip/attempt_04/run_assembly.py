from pathlib import Path
import json,hashlib,subprocess,datetime,sys,traceback
root=Path('C:/PleaseRemainOnTheLine');out=Path(__file__).parent;spec=json.loads((out/'build_inputs.json').read_bytes())
def sha(p):
 b=p.read_bytes();return hashlib.sha256(b.replace(b'\r\n',b'\n') if p.suffix in ['.py','.json','.gd'] else b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
result=dict(evidence_class='INERT',driver_sha256=sha(Path(__file__)),start=now(),phases=[],scope='Preserve original39 authored buildings while integrating85 replacements; native/source checks only, no runtime/artistic acceptance.')
def save():(out/'assembly_01.result.json').write_text(json.dumps(result,indent=2)+'\n')
def run(name,cmd):
 phase=dict(name=name,command=cmd,start=now());result['phases'].append(phase);save();print('START',name,phase['start'],flush=True)
 with (out/(name+'.log')).open('w',encoding='utf-8') as log:rc=subprocess.call(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 phase.update(exit_code=rc,end=now());save();print('END',name,rc,flush=True)
 if rc:raise RuntimeError(f'{name} failed: {rc}')
try:
 result['input_guard_before']={p:sha(root/p)==v for p,v in spec['inputs'].items()};save();assert all(result['input_guard_before'].values())
 prior=json.loads(Path(spec['reused_owner_phases']).read_bytes());assert all(p['exit_code']==0 for p in prior['phases'][:2]) and all(prior['retained_ground_street_outputs'].values())
 result['reused_street_owner']=spec['reused_owner_phases']
 assert all(sha(root/p)==v for p,v in spec['preserved_outputs'].items())
 base=['C:/Program Files/Blender Foundation/Blender 5.2/blender.exe','--background','--threads','4','--python-exit-code','1','--python']
 run('ground_owner',base+[str(root/'art/blender/scripts/build_city_ground_apron.py')])
 result['retained_ground_street_outputs']={p:sha(root/p)==v for p,v in spec['preserved_outputs'].items()};save();assert all(result['retained_ground_street_outputs'].values())
 run('assembly_01',base+[str(root/'art/blender/scripts/build_city_horizon.py')])
 result['base_export_identity']={p:sha(root/'game'/p.removeprefix('res://'))==v for p,v in spec['first_failure_base_assets'].items()};save()
 changed={p for p,ok in result['base_export_identity'].items() if not ok};assert changed==set(spec['restored_base_blocks']),changed
 run('native_partition',base+[str(out/'verify_native_partition.py')])
 result['input_guard_after']={p:sha(root/p)==v for p,v in spec['inputs'].items() if p not in spec['generated_dependencies']};save();assert all(result['input_guard_after'].values())
 result['regenerated_dependencies']={p:sha(root/p) for p in spec['generated_dependencies']}
 run('assembly_comparison',[sys.executable,str(out/'compare_assembly.py'),'after'])
 plan=json.loads((root/'art/data/city_horizon/source_plan.json').read_bytes());retained={r['id'] for r in plan['buildings'] if r.get('architecture',{}).get('type')!='packet_front'};assert len(retained)==39
 baseline_path=out.parent/'retained_context_trace/baseline_fixture.json';fixture_path=root/'game/tests/fixtures/orison_city_horizon.json'
 baseline=json.loads(baseline_path.read_bytes());fixture=json.loads(fixture_path.read_bytes())
 before=[r for r in baseline['window_rows'] if r['building'] in retained];after=[r for r in fixture['window_rows'] if r['building'] in retained]
 result['retained_pane_witnesses']=dict(baseline_sha256=sha(baseline_path),current_fixture_sha256=sha(fixture_path),profiles=len(retained),before=len(before),after=len(after),identical=before==after,total=len(fixture['window_rows']));save()
 assert len(before)==2678 and before==after and len(fixture['window_rows'])==17180,result['retained_pane_witnesses']
 names=['orison_bodega_frontage.json','orison_city_closure.json','orison_city_frontage.json','orison_city_elevations.json','orison_city_elevations_lod1.json','orison_city_transport.json','orison_city_streets.json','orison_city_ground_apron.json','orison_city_horizon.json','orison_front_pavement_construction.json','orison_front_pavement_review.json','orison_street_paving_details.json','passage_shop_leaves.json'];cmd=[sys.executable,'tools/preflight_spatial_test_bindings.py']
 for n in names:cmd+=['--fixture','game/tests/fixtures/'+n]
 run('postassembly_fixture_preflight',cmd)
 run('postassembly_static_tests',[sys.executable,'-m','unittest','tools.tests.test_city_horizon','tools.tests.test_city_horizon_shards','-v'])
 result.update(end=now(),exit_code=0);save();print('CITY RETAINED FACADE PRESERVATION COMPLETE',flush=True)
except Exception:
 result.update(end=now(),exit_code=1,error=traceback.format_exc());save();raise
