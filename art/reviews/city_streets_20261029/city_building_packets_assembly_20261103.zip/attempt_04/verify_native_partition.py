from pathlib import Path
import bpy,json,hashlib,numpy as np
root=Path('C:/PleaseRemainOnTheLine');out=Path(__file__).parent
original=out.parent/'failure_01/city_horizon_far_unpartitioned.blend'
fixture=json.loads((root/'art/blender/city_horizon_construction.json').read_bytes())
def fingerprint(path,collection=None):
 bpy.ops.wm.open_mainfile(filepath=str(path))
 populated=[s for s in bpy.data.scenes if any(o.type=='MESH' for o in s.objects)]
 assert len(populated)==1,(str(path),'one usable editable scene',len(populated))
 assert bpy.context.scene==populated[0],(str(path),'file must open directly into its populated editable scene')
 for c in bpy.data.collections:c.hide_viewport=False
 for o in populated[0].objects:o.hide_viewport=False
 bpy.context.view_layer.update();objects={o.name:o for o in populated[0].objects if o.type=='MESH'}
 if collection:assert collection in bpy.data.collections and {o.name for o in bpy.data.collections[collection].objects if o.type=='MESH'}==set(objects)
 result={}
 for name,obj in objects.items():
  m=obj.data;assert len(m.corner_normals)==len(m.loops)>0,(name,'complete corner normal coverage')
  h=hashlib.sha256();h.update(np.asarray(obj.matrix_world,dtype='<f8').tobytes())
  for data,prop,width,dtype in [(m.vertices,'co',3,'<f4'),(m.loops,'vertex_index',1,'<i4'),(m.polygons,'loop_start',1,'<i4'),(m.polygons,'loop_total',1,'<i4'),(m.corner_normals,'vector',3,'<f4')]:
   a=np.empty(len(data)*width,dtype=dtype);data.foreach_get(prop,a);h.update(a.tobytes())
  assert len(m.uv_layers)==1 and '_tangent_guide' in m.attributes,name
  assert len(m.uv_layers.active.data)==len(m.loops) and len(m.attributes['_tangent_guide'].data)==len(m.loops),name
  for data,prop,width in [(m.uv_layers.active.data,'uv',2),(m.attributes['_tangent_guide'].data,'vector',3)]:
   a=np.empty(len(data)*width,dtype='<f4');data.foreach_get(prop,a);h.update(a.tobytes())
  result[name]=dict(vertices=len(m.vertices),polygons=len(m.polygons),array_sha256=h.hexdigest())
 return result
before=fingerprint(original);spec=json.loads((out/'build_inputs.json').read_bytes());old_native=Path(spec['retained_native_far_source']['path']);assert hashlib.sha256(old_native.read_bytes()).hexdigest()==spec['retained_native_far_source']['sha256']
plan=json.loads((root/'art/data/city_horizon/source_plan.json').read_bytes());retained={r['id'] for r in plan['buildings'] if r.get('architecture',{}).get('type')!='packet_front'}
original_retained={n:v for n,v in fingerprint(old_native).items() if n.split('__')[0] in retained};assert set(original_retained)=={n for n in before if n.split('__')[0] in retained}
before.update(original_retained);after={};files=[]
for suffix in ['far','street_end']:
 rel='art/blender/city_horizon_'+suffix+'.blend';path=root/rel
 assert path.stat().st_size<95*1024*1024,(rel,path.stat().st_size)
 expected={p['name'] for a in fixture['assets'].values() if a['native']==rel for p in a['parts']};assert expected,rel
 current=fingerprint(path,'CityHorizon_'+suffix);assert set(current)==expected,(rel,'complete scene mesh coverage')
 assert not set(after)&set(current);after.update(current)
 maps={}
 for image in bpy.data.images:
  if image.source!='FILE':continue
  mapped=Path(bpy.path.abspath(image.filepath)).resolve();assert mapped.is_relative_to(root/'game/assets/building/textures') and mapped.is_file(),(rel,image.filepath,str(mapped))
  key=mapped.relative_to(root).as_posix();digest=hashlib.sha256(mapped.read_bytes()).hexdigest();assert fixture['source_bindings'].get(key)==digest,(rel,key,'native map provenance')
  maps[key]=digest
 assert maps,(rel,'native PBR maps')
 files.append(dict(native=rel,maps=maps,bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),parts=len(current)))
assert set(after)==set(before),(set(before)-set(after),set(after)-set(before))
failures=[n for n in before if before[n]!=after[n]]
result=dict(evidence_class='INERT',verification_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),construction_sha256=hashlib.sha256((root/'art/blender/city_horizon_construction.json').read_bytes()).hexdigest(),scope='Separate editable Scene coverage and exact raw matrix/vertex/index/normal/UV/tangent-guide arrays against preserved new-packet far source plus original pre-intake retained far stocks. No render,mipmap,runtime,access or artistic acceptance.',original_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),retained_preintake_native_sha256=spec['retained_native_far_source']['sha256'],retained_source_parts=len(original_retained),files=files,parts=len(before),failures=failures)
(out/'native_partition_verification.json').write_text(json.dumps(result,indent=2)+'\n');assert not failures,failures
print('NATIVE PARTITION PASS',len(before),'parts;two editable scenes,all arrays unchanged',flush=True)
