from pathlib import Path
import json,struct,hashlib,sys,time
import numpy as np
ROOT=Path('C:/PleaseRemainOnTheLine');OUT=Path(__file__).parent;DELIVERY=Path('C:/ov/asset-prototypes/city-building-packets-20261103')
def fingerprints(path):
 raw=path.read_bytes();size,kind=struct.unpack_from('<II',raw,12);doc=json.loads(raw[20:20+size]);off=20+size;length,kind=struct.unpack_from('<II',raw,off);binary=memoryview(raw)[off+8:off+8+length]
 def array(i):
  a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dt=np.dtype({5121:'u1',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']]);w={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
  return np.ndarray((a['count'],w),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',w*dt.itemsize),dt.itemsize))
 result={}
 for node in doc['nodes']:
  if 'mesh' not in node:continue
  assert not node.get('children') and 'matrix' not in node and node.get('scale',[1,1,1])==[1,1,1] and node.get('rotation',[0,0,0,1])==[0,0,0,1],node
  primitives=doc['meshes'][node['mesh']]['primitives'];assert len(primitives)==1
  p=primitives[0];attrs=p['attributes'];idx=array(p['indices']).astype(np.int64).reshape(-1,3)
  values=[]
  for key in ['POSITION','NORMAL','TEXCOORD_0','TANGENT']:
   a=array(attrs[key]).astype('<f8');
   if key=='POSITION':a+=node.get('translation',[0,0,0])
   values.append(a)
  corners=np.concatenate(values,axis=1)[idx];corners[corners==0]=0 # canonical signed zero
  # Canonical cyclic corner start; preserve orientation and every corner attribute.
  cv=np.ascontiguousarray(corners).view(np.dtype((np.void,corners.shape[2]*8))).reshape(-1,3)
  first=np.argsort(cv,axis=1)[:,0];order=(first[:,None]+np.arange(3))%3
  canonical=corners[np.arange(len(corners))[:,None],order]
  rows=np.ascontiguousarray(canonical).reshape(len(corners),-1).view(np.dtype((np.void,canonical.shape[1]*canonical.shape[2]*8))).reshape(-1)
  rows.sort();name=node['name'];assert name not in result
  result[name]={'triangles':len(idx),'oriented_world_corner_attributes_sha256':hashlib.sha256(rows.tobytes()).hexdigest()}
 return {'asset':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'parts':result}
def installed():
 manifest=json.loads((ROOT/'game/data/orison_v2/exterior/city_horizon.json').read_bytes());result={}
 for role,entries in [('base',manifest['assets']),('lower',manifest['body_lod']['assets'])]:
  result[role]={}
  for e in entries:
   r=fingerprints(ROOT/'game'/e['asset'].removeprefix('res://'))
   for name,v in r['parts'].items():
    assert name not in result[role];result[role][name]=dict(v,asset=r['asset'],asset_sha256=r['sha256'])
 return result
mode=sys.argv[1];start=time.monotonic();index=json.loads((DELIVERY/'packet_index.json').read_bytes());changed=set(index['changed'])
if mode=='before':
 data=installed();retained={role:{n:v for n,v in parts.items() if n.split('__')[0] not in changed} for role,parts in data.items()}
 expected={'base':{},'lower':{}}
 for p in DELIVERY.glob('*/manifest.json'):
  m=json.loads(p.read_bytes())
  for record in m['records']:
   role='base' if record['level']=='near' else 'lower';r=fingerprints(p.parent/record['asset']);assert r['sha256']==record['sha256']
   for name,v in r['parts'].items():assert name not in expected[role];expected[role][name]=v
 assert len({n.split('__')[0] for n in expected['base']})==85
 result=dict(evidence_class='INERT',mode=mode,scope='Exact oriented world triangle corner POSITION/NORMAL/UV/TANGENT hashes; not runtime proof.',retained=retained,replacements=expected,elapsed_s=time.monotonic()-start)
 (OUT/'assembly_baseline.json').write_text(json.dumps(result,indent=2)+'\n')
 print('BASELINE', {k:len(v) for k,v in retained.items()},'REPLACEMENTS',{k:len(v) for k,v in expected.items()},flush=True)
else:
 before=json.loads((OUT/'assembly_baseline.json').read_bytes());now=installed();checks=[];failures=[]
 for kind in ['retained','replacements']:
  for role,parts in before[kind].items():
   actual={n:v for n,v in now[role].items() if (n.split('__')[0] in changed)==(kind=='replacements')}
   if set(actual)!=set(parts):failures.append([kind,role,'roster',sorted(set(parts)-set(actual)),sorted(set(actual)-set(parts))])
   for n,expected in parts.items():
    observed=actual.get(n,{});ok=all(observed.get(k)==expected[k] for k in ['triangles','oriented_world_corner_attributes_sha256']);checks.append([kind,role,n,ok])
    if not ok:failures.append([kind,role,n,expected,observed])
 result=dict(evidence_class='INERT',mode=mode,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),baseline_sha256=hashlib.sha256((OUT/'assembly_baseline.json').read_bytes()).hexdigest(),asset_sha256={v['asset']:v['asset_sha256'] for parts in now.values() for v in parts.values()},checks=checks,failures=failures,elapsed_s=time.monotonic()-start)
 (OUT/'assembly_comparison.json').write_text(json.dumps(result,indent=2)+'\n');print('ASSEMBLY',len(checks),'checks',len(failures),'failures',flush=True)
 sys.exit(bool(failures))
