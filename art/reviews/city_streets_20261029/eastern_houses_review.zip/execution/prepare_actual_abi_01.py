from pathlib import Path
root=Path('C:/ov/city');out=Path(__file__).parent;path=root/'game/tmp/city_eastern_houses_20261031/bench.gd';code=path.read_text()
code=code.replace('var maps:Dictionary={}','var maps:Dictionary={}\nvar actual_materials:Dictionary={}')
old='    var material_rows=_industrial_materials(horizon)'
new='    actual_materials=_actual_visible_abi(horizon,catalog)\n    var material_rows=_industrial_materials(horizon)'
assert code.count(old)==1;code=code.replace(old,new)
code=code.replace('"loaded_materials":maps,','"loaded_materials":maps,"actual_visible_materials":actual_materials,')
code=code.replace('"contracts":{"production_family_loader"','"contracts":{"actual_visible_material_abi":{"executed":actual_materials.size()==118,"passed":failures.is_empty()},"production_family_loader"')
code=code.replace('Three isolated production-loader building bodies:','Three isolated production-loader building bodies plus final visible material ABI on all14 complete-body horizon buildings/118partitions:')
old='    return result\n\nfunc _counters'
new='''    for path:String in ["res://data/orison_v2/owner_finish_profiles.json","res://scripts/building/surface_pass.gd","res://shaders/orison_surface.gdshader","res://shaders/orison_surface.gdshaderinc","res://shaders/dream_corruption_layers.gdshaderinc","res://shaders/queens_surface_wetness.gdshaderinc"]:result[path]=_profile_sha(path)
    for draw:MeshInstance3D in owner.find_children("*","MeshInstance3D",true,false):
        if not draw.get_meta("v2_city_horizon_body_lod",false):continue
        if draw.material_override is ShaderMaterial:
            for parameter:String in ["albedo_tex","rough_tex","normal_tex"]:
                var texture:Texture2D=draw.material_override.get_shader_parameter(parameter)
                if texture!=null:
                    result[texture.resource_path]=_profile_sha(texture.resource_path)
                    result[texture.resource_path+".import"]=_profile_sha(texture.resource_path+".import")
    return result

func _counters'''
assert code.count(old)==1;code=code.replace(old,new)
code+='''
func _actual_visible_abi(horizon:Node3D,catalog:Dictionary)->Dictionary:
    var result:Dictionary={};var roof_recipes:Dictionary={}
    var profiles:Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://data/orison_v2/owner_finish_profiles.json"))
    for group:Dictionary in profiles.groups:
        if str(group.id)=="roof":
            for recipe:Dictionary in group.recipes:roof_recipes[str(recipe.source_key)]=recipe
    for draw:MeshInstance3D in horizon.find_children("*","MeshInstance3D",true,false):
        if not draw.get_meta("v2_city_horizon_body_lod",false):continue
        var identity=str(draw.name);var source_key=identity.split("__")[-1];var expected_key=source_key
        var normal_expected=.12 if source_key=="mirror_aged" else .55
        if source_key=="galvanized_roof":
            var recipe:Dictionary=roof_recipes.get(source_key,{})
            expected_key=str(recipe.get("catalog",source_key));normal_expected=float(recipe.get("normal",normal_expected))
        var material:Material=draw.material_override;var textures:Dictionary={};var scale=Vector2.ZERO;var actual_normal=0.;var shader=""
        if material is StandardMaterial3D:
            check(not material.uv1_triplanar,"actual visible material uses mesh UV "+identity)
            check(material.normal_enabled,"actual visible normal enabled "+identity)
            check(material.texture_filter==BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC,"actual visible mip-capable filter "+identity)
            scale=Vector2(material.uv1_scale.x,material.uv1_scale.y);actual_normal=material.normal_scale
            textures={"albedo":material.albedo_texture,"roughness":material.roughness_texture,"normal":material.normal_texture}
        elif material is ShaderMaterial:
            shader=material.shader.resource_path
            check(shader=="res://shaders/orison_surface.gdshader","actual visible shared roof shader "+identity)
            check(int(material.get_shader_parameter("uv_mode"))==0,"actual visible roof mesh UV "+identity)
            check(bool(material.get_shader_parameter("has_normal_tex")) and bool(material.get_shader_parameter("has_rough_tex")),"actual visible shader data maps enabled "+identity)
            scale=material.get_shader_parameter("mesh_uv_scale");actual_normal=float(material.get_shader_parameter("normal_scale"))
            textures={"albedo":material.get_shader_parameter("albedo_tex"),"roughness":material.get_shader_parameter("rough_tex"),"normal":material.get_shader_parameter("normal_tex")}
        else:check(false,"actual visible material type supported "+identity);continue
        var registered:Dictionary=catalog.materials[expected_key];var expected_scale=Vector2.ONE/float(registered.meters_per_tile)
        check(scale.distance_to(expected_scale)<.000001,"actual visible physical texture scale "+identity)
        check(abs(actual_normal-normal_expected)<.000001,"actual visible declared normal strength "+identity)
        var maps_record:Dictionary={}
        for index in 3:
            var channel:String=["albedo","roughness","normal"][index];var texture:Texture2D=textures[channel]
            check(texture!=null,"actual visible registered texture exists "+identity+"/"+channel)
            if texture==null:continue
            check(texture.resource_path=="res://assets/building/textures/"+str(registered.files[index]),"actual visible registered texture identity "+identity+"/"+channel)
            var pixels=texture.get_image();var required=int(floor(log(float(maxi(pixels.get_width(),pixels.get_height())))/log(2.)))
            check(pixels.has_mipmaps() and pixels.get_mipmap_count()==required,"actual visible complete loaded mips "+identity+"/"+channel)
            maps_record[channel]={"path":texture.resource_path,"dimensions":[pixels.get_width(),pixels.get_height()],"has_mipmaps":pixels.has_mipmaps(),"mipmap_count":pixels.get_mipmap_count()}
        result[identity]={"source_key":source_key,"actual_catalog_key":expected_key,"material_class":material.get_class(),"shader":shader,"uv_scale":[scale.x,scale.y],"meters_per_tile":registered.meters_per_tile,"normal_scale":actual_normal,"maps":maps_record}
    check(result.size()==118,"all14 complete-body buildings/118 final material partitions inspected")
    return result
'''
path.write_text(code,encoding='utf-8',newline='\n');(out/'bench_01_executed_source.gd').write_bytes(path.read_bytes())
print('Prepared actual-visible118 material ABI andsource-bound shader/finish dependencies;noGodot launch')
