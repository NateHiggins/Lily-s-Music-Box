from pathlib import Path
import subprocess,json,hashlib,zipfile
root=Path('C:/ov/city').resolve();out=Path(__file__).parent
raw=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root)
names=[s.decode() for s in raw.split(b'\0') if s];paths=[p for p in names if p.endswith('.uid')]
assert len(paths)==638,('unexpected UID census;no deletions performed',len(paths))
tracked={s.decode() for s in subprocess.check_output(['git','ls-files','-z'],cwd=root).split(b'\0') if s}
backup=out/'generated_uid_backup_01.zip';assert not backup.exists();rows=[]
with zipfile.ZipFile(backup,'x',zipfile.ZIP_DEFLATED) as z:
    for name in paths:
        path=(root/name).resolve();assert path.is_relative_to(root) and path.suffix=='.uid' and name not in tracked
        data=path.read_bytes();z.writestr(name,data);rows.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(backup) as z:
    assert z.testzip() is None
    for r in rows:assert hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256']
for r in rows:
    path=(root/r['path']).resolve();assert path.is_relative_to(root) and hashlib.sha256(path.read_bytes()).hexdigest()==r['sha256'];path.unlink()
(out/'generated_uid_cleanup_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='638 untracked UID files generatedby ownimport removed onlyinside isolatedcitytree afterownengineterminal;verified externalbytebackup retained;no trackedUID/canonicalindex touched.',backup=backup.name,backup_sha256=hashlib.sha256(backup.read_bytes()).hexdigest(),removed=rows),indent=2),encoding='utf-8',newline='\n');print('Backedup andremoved',len(rows),'untracked importUIDs')
