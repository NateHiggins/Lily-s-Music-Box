from pathlib import Path
import json
root=Path('C:/ov/city');out=Path(__file__).parent;p=root/'game/tmp/city_eastern_houses_20261031/bench.gd';code=p.read_text()
old='stock.texture_filter==BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC'
new='int(stock.texture_filter) in [BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS,BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC]'
assert code.count(old)==1;code=code.replace(old,new)
old='            check(int(shader_material.get_shader_parameter("uv_mode"))==0,"actual visible roof mesh UV "+identity)'
new='''            var uv_mode:Variant=shader_material.get_shader_parameter("uv_mode")
            var explicit_uv_mode=uv_mode!=null
            if uv_mode==null:uv_mode=RenderingServer.shader_get_parameter_default(shader_material.shader.get_rid(),"uv_mode")
            check(uv_mode!=null,"actual renderer supplies effective roof UV mode "+identity)
            if uv_mode==null:continue
            check(int(uv_mode)==0,"actual visible roof mesh UV "+identity)
            material.set_meta("test_observed_effective_uv_mode",int(uv_mode))
            material.set_meta("test_observed_uv_mode_was_explicit",explicit_uv_mode)'''
assert code.count(old)==1;code=code.replace(old,new)
# Observations stay in the receipt;do not mutate production material metadata.
code=code.replace('var actual_normal=0.;var shader=""','var actual_normal=0.;var shader="";var effective_uv_mode=0;var explicit_uv=false')
code=code.replace('            material.set_meta("test_observed_effective_uv_mode",int(uv_mode))\n            material.set_meta("test_observed_uv_mode_was_explicit",explicit_uv_mode)','            effective_uv_mode=int(uv_mode);explicit_uv=explicit_uv_mode')
code=code.replace('"shader":shader,"uv_scale":','"shader":shader,"effective_uv_mode":effective_uv_mode,"uv_mode_was_explicit":explicit_uv,"texture_filter":(material as StandardMaterial3D).texture_filter if material is StandardMaterial3D else "bound shader sampler hints","uv_scale":')
p.write_text(code,encoding='utf-8',newline='\n');(out/'bench_02_executed_source.gd').write_bytes(p.read_bytes())
batch=json.loads((out/'batch_01.json').read_text())[1:]
for row in batch:
    for key in ['log','shot_dir']:
        if key in row:row[key]=row[key].replace('_01.log','_02.log').replace('bench_01','bench_02')
(out/'batch_02.json').write_text(json.dumps(batch,indent=2),encoding='utf-8',newline='\n')
