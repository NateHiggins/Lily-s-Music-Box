from pathlib import Path
import json
out=Path(__file__).parent;prior=out.parent/'houses_loaded_01'
runner=(prior/'run_native_build_07.py').read_text().replace('_07','_01')
(out/'run_native_build_01.py').write_text(runner,encoding='utf-8',newline='\n')
uv=(prior/'verify_export_uv_07.py').read_text().replace('_07','_01')
(out/'verify_export_uv_01.py').write_text(uv,encoding='utf-8',newline='\n')
preserve=(prior/'check_preservation_07.py').read_text().replace("/'repair_baseline_01.json'","/'baseline_01.json'").replace('preservation_07','preservation_01')
(out/'check_preservation_01.py').write_text(preserve,encoding='utf-8',newline='\n')
code=(prior/'review_native_08.py').read_text().replace('native_review_08','native_review_01')
start=code.index('IDS=');end=code.index('\nprofiles=',start)
code=code[:start]+"IDS=[f'HORIZON_NEAR_2_2_P0R{i}' for i in range(3)]"+code[end:]
start=code.index('    views=[');end=code.index('    for label,identities',start)
code=code[:start]+'''    views=[]
    for identity in IDS:
        row=profiles[identity];a,b,c,d=row['rect'];height=row['height_m'];center=(b+d)/2
        views.append((identity,[identity],(c+18,-center-15,height*.95),((a+c)/2,-center,height*.48),24.,(1100,850)))
        if family=='city_horizon_near':
            views.append((identity+'_detail',[identity],(c+9,-center-2,height*.65),(c-1.8,-center,height*.50),height+2.,(1000,900)))
    views.append(('row_pair',IDS,(-128.,-8.,18.),(-159.,-23.,5.),36.,(1400,900)))
''' +code[end:]
code=code.replace("detail='pair' not in label;framed=None","detail=label.endswith('_detail');framed=None")
code=code.replace('len(contacts)==42 and len(captures)==8','len(contacts)==32 and len(captures)==11')
(out/'review_native_01.py').write_text(code,encoding='utf-8',newline='\n')
runner=(prior/'run_native_review_08.py').read_text().replace('_08','_01')
(out/'run_native_review_01.py').write_text(runner,encoding='utf-8',newline='\n')
# Prepare,but do not launch,the focused loaded programme. Native review first.
root=Path('C:/ov/city');folder=root/'game/tmp/city_eastern_houses_20261031';folder.mkdir(exist_ok=False)
code=(prior/'bench_05_executed_source.gd').read_text()
start=code.index('const IDS=');end=code.index('\nvar view_direction',start)
code=code[:start]+'const IDS=["HORIZON_NEAR_2_2_P0R0","HORIZON_NEAR_2_2_P0R1","HORIZON_NEAR_2_2_P0R2"]'+code[end:]
for old,new in [('selected==67','selected==28'),('bounds.size()==8','bounds.size()==3'),('maps.size()==67','maps.size()==28'),('transitions.size()==8','transitions.size()==3'),('observations.size()==40','observations.size()==15'),('pane_samples==418','pane_samples==74'),('roof_controls==37','roof_controls==16'),('panes==418','panes==74'),('roofs==37','roofs==16'),('Eight isolated','Three isolated'),('all eight','all three'),('eight requested buildings and67','three requested buildings and28'),('8 buildings;67 parts','3 buildings;28 parts'),('exact418 pane/37roof','exact74 pane/16roof')]:code=code.replace(old,new)
(folder/'bench.gd').write_text(code,encoding='utf-8',newline='\n');(out/'bench_01_prepared_source.gd').write_text(code,encoding='utf-8',newline='\n')
scene='[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://tmp/city_eastern_houses_20261031/bench.gd" id="1"]\n\n[node name="EasternHousesBench" type="Node3D"]\nscript = ExtResource("1")\n'
(folder/'Bench.tscn').write_text(scene,encoding='utf-8',newline='\n')
batch=json.loads((prior/'batch_import_and_05.json').read_text())
for row in batch:
    for key in ['log','shot_dir']:
        if key in row:row[key]=str(out/Path(row[key]).name.replace('_05','_01'))
    row['scene']=row['scene'].replace('city_houses_20261031','city_eastern_houses_20261031')
(out/'batch_01.json').write_text(json.dumps(batch,indent=2),encoding='utf-8',newline='\n')
print('Native/export/visual/loaded programmes prepared;no native orGodot started')
