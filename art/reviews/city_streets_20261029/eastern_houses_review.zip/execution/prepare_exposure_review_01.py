from pathlib import Path
out=Path(__file__).parent
code=(out/'review_native_01.py').read_text().replace("/'native_review_01'","/'exposure_native_review_01'")
code=code.replace("IDS=[f'HORIZON_NEAR_2_2_P0R{i}' for i in range(3)]","IDS=[f'HORIZON_NEAR_2_2_P0R{i}' for i in range(3)]+['HORIZON_NEAR_2_2_P1']")
code=code.replace("[('city_horizon_near','CityHorizon_near',IDS),('city_horizon_lod1','CityHorizonReplacementBodies',IDS)]","[('city_horizon_near','CityHorizon_near',IDS)]")
code=code.replace("if row['building'] not in IDS:continue","if row['building'] not in IDS[:3]:continue")
start=code.index('    views=[]');end=code.index('    for label,identities',start)
code=code[:start]+"    views=[('exposed_party_wall_context',IDS,(-128.,-4.,22.),(-159.,-33.,8.),55.,(1400,950))]\n"+code[end:]
code=code.replace('len(contacts)==32 and len(captures)==11','len(contacts)==16 and len(captures)==1')
(out/'review_exposure_01.py').write_text(code,encoding='utf-8',newline='\n')
runner=(out/'run_native_review_01.py').read_text().replace("'review_native_01.py'","'review_exposure_01.py'").replace("'native_review_01.log'","'exposure_native_review_01.log'").replace("'native_review_execution_01.json'","'exposure_native_execution_01.json'")
(out/'run_exposure_review_01.py').write_text(runner,encoding='utf-8',newline='\n')
