from pathlib import Path
root=Path('C:/ov/city');out=Path(__file__).parent;p=root/'game/tmp/city_eastern_houses_20261031/bench.gd';s=p.read_text()
s=s.replace('        if draw.material_override is ShaderMaterial:\n            for parameter:', '        var actual_shader=draw.material_override as ShaderMaterial\n        if actual_shader!=null:\n            for parameter:').replace('draw.material_override.get_shader_parameter(parameter)','actual_shader.get_shader_parameter(parameter)')
start=s.index('func _actual_visible_abi')
before=s[:start];code=s[start:]
code=code.replace('        if material is StandardMaterial3D:\n','        if material is StandardMaterial3D:\n            var stock=material as StandardMaterial3D\n')
for key in ['uv1_triplanar','normal_enabled','texture_filter','uv1_scale','normal_scale','albedo_texture','roughness_texture','normal_texture']:code=code.replace('material.'+key,'stock.'+key)
code=code.replace('        elif material is ShaderMaterial:\n','        elif material is ShaderMaterial:\n            var shader_material=material as ShaderMaterial\n').replace('material.shader.resource_path','shader_material.shader.resource_path').replace('material.get_shader_parameter','shader_material.get_shader_parameter')
p.write_text(before+code,encoding='utf-8',newline='\n');(out/'bench_01_executed_source.gd').write_bytes(p.read_bytes())
