from pathlib import Path
import json,struct,subprocess,collections,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent;part='HORIZON_NEAR_2_2_P1'
def triangles(raw):
    size=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+size]);binary=raw[28+size:]
    def acc(i):
        a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];count={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];fmt={5123:'H',5125:'I',5126:'f'}[a['componentType']];width=struct.calcsize('<'+fmt*count);stride=v.get('byteStride',width);offset=v.get('byteOffset',0)+a.get('byteOffset',0)
        return [struct.unpack_from('<'+fmt*count,binary,offset+j*stride) for j in range(a['count'])]
    result={}
    for node in d['nodes']:
        if not node.get('name','').startswith(part+'__') or 'mesh' not in node:continue
        assert not any(k in node for k in ['rotation','scale','matrix']);t=node.get('translation',[0,0,0]);counter=collections.Counter()
        for primitive in d['meshes'][node['mesh']]['primitives']:
            p=[tuple(a+b for a,b in zip(v,t)) for v in acc(primitive['attributes']['POSITION'])];indices=[v[0] for v in acc(primitive['indices'])]
            for at in range(0,len(indices),3):counter[tuple(sorted(p[indices[at+j]] for j in range(3)))]+=1
        result[node['name']]=counter
    return result
old=triangles(subprocess.check_output(['git','show','77c54028:game/assets/props/city_horizon_near.glb'],cwd=root));new=triangles((root/'game/assets/props/city_horizon_near.glb').read_bytes())
report=json.loads((out/'preservation_01.json').read_text());expected=[part+'__'+k for k in ['arcade_brick_bond','door_paint','mirror_aged']]
assert set(report['failures'])==set(expected),report['failures']
rows=[]
for name in expected:
    removed=list((old[name]-new[name]).elements());added=list((new[name]-old[name]).elements());points=[p for tri in removed+added for p in tri]
    bounds=[min(p[i] for p in points) for i in range(3)]+[max(p[i] for p in points) for i in range(3)]
    # Only the newly exposed north party-wall floor may change. Other faces,
    # lower wall, roof,extent and material partitions remain byte/triangle exact.
    assert all(9.59<=p[1]<=12.81 and 33.59<=p[2]<=33.87 for p in points),(name,bounds)
    rows.append(dict(part=name,removed_triangles=len(removed),added_triangles=len(added),delta_bounds=bounds,outside_changed_floor_triangles_exact=True))
record=dict(evidence_class='INERT',scope='Exact source-derived reconciliation of anticipated generic neighbour exposure only;not a fourth individual study orrender/access acceptance.',original_strict_failure_retained='preservation_01.json',expected_changed_parts=rows,preserved_near_parts=446,preserved_far_parts=241,preserved_lower_parts=90,preserved_other_profiles=121,preserved_rectangles=124,other_assets_exact=10,new_glb_sha256=hashlib.sha256((root/'game/assets/props/city_horizon_near.glb').read_bytes()).hexdigest())
target=out/'exposure_reconciliation_01.json';assert not target.exists();target.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n');print(json.dumps(record))
