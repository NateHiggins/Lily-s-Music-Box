from pathlib import Path
out=Path(__file__).parent
code=(out.parent/'houses_loaded_01/analyse_and_contact_05.py').read_text().replace('bench_05','bench_02').replace('loaded_05','loaded_02').replace('family05','family02').replace("data['checks']==1660","data['checks']==2254")
code=code.replace('(1600,800)','(1200,400)').replace('i%4*400','i%3*400').replace('i//4*200','i//3*200').replace('(2000,1760)','(2000,660)')
code=code.replace('80 original full-resolution captures','30 original full-resolution captures')
(out/'analyse_and_contact_02.py').write_text(code,encoding='utf-8',newline='\n')
