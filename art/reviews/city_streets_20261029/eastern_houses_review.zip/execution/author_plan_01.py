from pathlib import Path
import json,hashlib,ast,struct,subprocess
root=Path('C:/ov/city');out=Path(__file__).parent
ids=[f'HORIZON_NEAR_2_2_P0R{i}' for i in range(3)]
reader=out.parent/'bodega_frontage_reconciliation_01/check_preservation_01.py';tree=ast.parse(reader.read_text(encoding='utf-8-sig'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(reader),'exec'))
p=root/'art/data/city_horizon/source_plan.json';raw=p.read_bytes();plan=json.loads(raw)
baseline=dict(evidence_class='INERT',sourcebase=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),targets=ids,source_plan_sha256=hashlib.sha256(raw).hexdigest(),profiles=plan['buildings'],parts={f:projection((root/f'game/assets/props/{f}.glb').read_bytes()) for f in ['city_horizon_near','city_horizon_far','city_horizon_lod1']},other_assets={f'game/assets/props/{f}.glb':hashlib.sha256((root/f'game/assets/props/{f}.glb').read_bytes()).hexdigest() for f in ['city_elevations','city_elevations_lod1','city_streets','city_streets_lod1','city_transport','city_transport_lod1','city_ground_apron','orison_ground','front_pavement','bodega_receiving']})
target=out/'baseline_01.json';assert not target.exists();target.write_text(json.dumps(baseline,indent=2),encoding='utf-8',newline='\n')
styles=[('bow_4470',[.9,3.25,3.15],'arcade_brick_bond',[.69,.43,.30,1.],'44-70 23rd Street,1887:two-storey+fullbasement modified Romanesque house,three-window frontage withtwo windows in shallowbow,three vertically joined terracotta relief plaques andsheetmetal cornice.'),('yellow_2148',[.9,3.25,3.10,3.05],'city_grey_brick',[.88,.78,.55,1.],'21-48 45th Avenue,1889:yellowbrick apartment house,three stories+basement,bracketed cornice andsimple windowlintels. Altered firstfloor is not copied as1928 proof.'),('frame_2134',[.9,3.25,3.10],'door_paint',[.76,.74,.65,1.],'21-34 45th Avenue,1887 Burnell house:two timber stories over lowbrick basement,clapboards andvertical/horizontal framing,paired centre windows,single sidebays anddiagonal incised spandrelboarding.')]
for identity,(style,heights,key,tint,precedent) in zip(ids,styles):
    row=next(r for r in plan['buildings'] if r['id']==identity);a,b,c,d=row['rect'];front=c-2.1
    outline=[[front,d],[a,d],[a,b],[front,b]];counts=[6,3,6,3];entry_side=3
    if style=='bow_4470':
        outline.extend([[front,b+2.70],[front+.8,b+3.35],[front+.8,b+6.30],[front,b+6.95]])
        counts=[6,3,6,1,1,2,1,1]
    row.update(height_m=sum(heights),wall_key=key,wall_tint=tint,joinery_tint=[.32,.35,.29,1.],window_width_m=1.02,window_height_m=2.0)
    row['architecture']=dict(type='eastern_row',style=style,precedent=precedent,source='https://s-media.nyc.gov/agencies/lpc/lp/0450.pdf',source_pdf_pages=[5],adaptation='Specific facade/floor/roof forms adapted toexisting7.222mfrontage/20mdepth reservations. Dimensions,colors and1928placement areAU decisions,not surveyed replicas. Front setback2.1m seats realstoops wholly inparcel. Lowbasements haveauthored0.9m floorheight. Scenic leaves add nooccupied interiors orshop/accessauthority. Referencepixels never enter maps.',floor_heights_m=heights,front_side=entry_side,cornice_key='door_paint',outline_m=outline,side_bays=counts)
p.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Source plan authored for',ids,';nativeassets unchanged')
