from pathlib import Path
out=Path(__file__).parent
code=(out.parent/'houses_loaded_01/source_checks_05.py').read_text().replace('_05','_01')
(out/'source_checks_01.py').write_text(code,encoding='utf-8',newline='\n')
