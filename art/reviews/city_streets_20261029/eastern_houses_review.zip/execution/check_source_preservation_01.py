from pathlib import Path
import json,ast,subprocess,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent;base=json.loads((out/'baseline_01.json').read_text());plan=json.loads((root/'art/data/city_horizon/source_plan.json').read_text())
old={r['id']:r for r in base['profiles']};new={r['id']:r for r in plan['buildings']};assert old.keys()==new.keys()
assert all(old[k]['rect']==new[k]['rect'] for k in old)
assert all(new[k]==v for k,v in old.items() if k not in base['targets'])
path='art/blender/scripts/city_residential_architecture.py';before=ast.parse(subprocess.check_output(['git','show','HEAD:'+path],cwd=root,text=True));after=ast.parse((root/path).read_text())
def existing_class(tree):return next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ResidentialHouses')
assert ast.dump(existing_class(before))==ast.dump(existing_class(after))
for family in ['city_horizon_near','city_horizon_far','city_horizon_lod1']:
    raw=subprocess.check_output(['git','show','HEAD:game/assets/props/'+family+'.glb'],cwd=root)
    assert hashlib.sha256(raw).hexdigest()==hashlib.sha256((root/f'game/assets/props/{family}.glb').read_bytes()).hexdigest()
record=dict(evidence_class='INERT',scope='Before-export source preservation only;not native export/render/runtime acceptance.',unchanged_other_profiles=121,unchanged_rectangles=124,original_residential_class_ast_unchanged=True,old_three_glbs_unchanged=True,expected_generic_exposure_dependency='HORIZON_NEAR_2_2_P1:its neighbouring timber house changes9.6→7.25m,so formerly occluded upper party-wall openings may become visible. This remains generic stock,not a fourth completed architecture study.')
path=out/'source_preservation_01.json';assert not path.exists();path.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n');print(record)
