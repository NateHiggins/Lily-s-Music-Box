from pathlib import Path
import json
p=Path('C:/ov/city/art/data/city_horizon/source_plan.json');plan=json.loads(p.read_text())
for row in plan['buildings']:
    if row['id'] in [f'HORIZON_NEAR_2_2_P0R{i}' for i in range(3)]:
        assert row['architecture']['type']=='residential_front';row['architecture']['type']='eastern_row'
p.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
