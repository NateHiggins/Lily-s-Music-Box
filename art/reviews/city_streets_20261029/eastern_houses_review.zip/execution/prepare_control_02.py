from pathlib import Path
out=Path(__file__).parent
code=(out/'check_geometry_01.py').read_text().replace('geometry_01.json','geometry_02.json')
old="            hit,n,index,d=bvh.ray_cast(p-Vector((0,0,.025)),Vector((0,0,1)),.05)\n            assert hit is not None and owners[index]==seat['wall_key'] and (hit-p).length<.0001,(identity,lower,'actual receiving underside',seat,owners[index] if index is not None else None)"
new="""            candidates=[]
            for key,(vv,ff) in buf.items():
                tree=BVHTree.FromPolygons(vv,ff,all_triangles=False)
                hit,n,index,d=tree.ray_cast(p-Vector((0,0,.025)),Vector((0,0,1)),.05)
                if hit is not None and n.z<0:candidates.append((d,key,hit))
            assert candidates,(identity,lower,'no front-facing receiver',seat)
            d,key,hit=min(candidates,key=lambda r:r[0])
            assert key==seat['wall_key'] and (hit-p).length<.0001,(identity,lower,'actual front-facing receiving underside',seat,key,list(hit))"""
assert code.count(old)==1
(out/'check_geometry_02.py').write_text(code.replace(old,new),encoding='utf-8',newline='\n')
runner=(out/'run_geometry_01.py').read_text().replace('_01','_02')
(out/'run_geometry_02.py').write_text(runner,encoding='utf-8',newline='\n')
