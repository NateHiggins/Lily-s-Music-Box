from pathlib import Path
import hashlib,json,subprocess
root=Path('C:/PleaseRemainOnTheLine');out=Path('C:/ov/reports/city_streets_20261029/southern_pair_01')
sha=lambda b:hashlib.sha256(b).hexdigest()
def normalized(path,data):
    return data.replace(b'\r\n',b'\n') if Path(path).suffix in ['.gd','.json','.gdshader','.gdshaderinc','.import'] else data
rows=[]
for filename in ['city_elevation_profile.json','city_entry_diagnostic.json']:
    data=json.loads((out/'bench_01'/filename).read_text())
    assert not data['failures'],filename
    matches=[]
    for uri,expected in data['source_hashes'].items():
        assert uri.startswith('res://')
        relative='game/'+uri[6:]
        frozen=(out/'bench_01_frozen_source.gd').read_bytes() if relative=='game/tests/v2_city_elevation_bench.gd' else subprocess.check_output(['git','-C',str(root),'show','92093219:'+relative])
        assert sha(normalized(relative,frozen))==expected,relative
        current_equal=sha(normalized(relative,(root/relative).read_bytes()))==expected
        assert current_equal or relative=='game/tests/v2_city_elevation_bench.gd',relative
        matches.append({'path':relative,'sha256':expected,'canonical_same':current_equal})
    rows.append({'file':filename,'checks':data['checks'],'failures':data['failures'],'bound_inputs':matches})
images=[];known={}
for f in sorted((out/'bench_01').glob('*.png')):
    h=sha(f.read_bytes());alias=known.get(h);known.setdefault(h,f.name)
    images.append({'file':f.name,'sha256':h,'inspected':True,'byte_identical_alias_of':alias})
assert len(images)==16 and len(known)==14
record={'evidence_class':'INERT','production_source':'92093219','test_source':'bench_01_frozen_source.gd; same passed uncommitted driver, awaiting author checkpoint','scope':'Independent source verification and actual image inspection of isolated loaded body/LOD and SE2 normal-controller diagnostic. Natural optical captures each isolate a single material partition, not whole-building appearance. Two exact return aliases inspected through identical before bytes. Not composed access, matched performance, full saves or artistic acceptance.','records':rows,'images':images}
(out/'canonical_loaded_review_01.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Verified loaded inputs',[(r['file'],len(r['bound_inputs'])) for r in rows],';16 captures/14 unique images inspected.')
