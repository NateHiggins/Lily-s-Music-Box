from pathlib import Path
import hashlib,json,subprocess,zipfile

root=Path('C:/PleaseRemainOnTheLine')
out=Path('C:/ov/reports/city_streets_20261029/southern_pair_01')
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest=json.loads((root/'art/reviews/city_streets_20261029/manifest.json').read_text())
entry=manifest['southern_pair_native_archive']
archive=root/entry['path']
assert len(archive.read_bytes())==entry['bytes'] and sha(archive.read_bytes())==entry['sha256']
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(entry['files'])
    for name,record in entry['files'].items():
        data=z.read(name)
        assert len(data)==record['bytes'] and sha(data)==record['raw_sha256'],name
    native=json.loads(z.read('native_review_02/native_review_02.json'))
    bound={}
    for name,expected in native['bindings'].items():
        name=name.replace('\\','/')
        data=(root/name).read_bytes()
        frozen=subprocess.check_output(['git','-C',str(root),'show','92093219:'+name])
        assert sha(data)==expected and frozen==data,name
        bound[name]=expected
    for record in native['captures']:
        assert sha(z.read('native_review_02/'+record['path']))==record['sha256']
    frozen_sources={}
    for name in z.namelist():
        if not name.startswith('frozen_sources/'):continue
        path=name.removeprefix('frozen_sources/')
        data=z.read(name).replace(b'\r\n',b'\n')
        assert data==(root/path).read_bytes().replace(b'\r\n',b'\n'),path
        frozen_sources[path]=sha(data)
    for path,expected in json.loads(z.read('preservation_01.json'))['other_assets'].items():
        name='game/assets/props/'+path+'.glb'
        assert sha((root/name).read_bytes())==expected,name
review={'evidence_class':'INERT','native_source':'92093219','canonical_intake':'3a61cae1','archive':{'members':len(entry['files']),'sha256':entry['sha256']},'native_inputs_exact':bound,'frozen_sources_lf_sha256':frozen_sources,'other_asset_hashes_verified':11,'independently_inspected_images':{'native_whole_and_detail':9,'station_context':2},'scope':'Independent archive/member integrity, exact frozen native inputs, retained unrelated assets and native visual review. 264 near/176 lower non-target fingerprints independently compare against c2a3db2d in the sibling preservation review. Both canonical GLBs pass UV audit. No loaded/composed/controller/save/artistic acceptance.'}
(out/'canonical_intake_review_01.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Independent intake verified:',len(entry['files']),'archive members,',len(bound),'binary bindings,',len(frozen_sources),'frozen source files,11 retained assets;11 native images inspected.')
