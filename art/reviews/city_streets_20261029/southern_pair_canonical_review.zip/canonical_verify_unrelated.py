from pathlib import Path
import json,subprocess,struct,hashlib,numpy as np
p=Path('C:/ov/reports/city_streets_20261029/southern_pair_01');types={5120:'i1',5121:'u1',5122:'<i2',5123:'<u2',5125:'<u4',5126:'<f4'};widths={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
def parts(raw):
 doc=None;binary=None;at=12
 while at<len(raw):
  size,kind=struct.unpack_from('<II',raw,at);at+=8;block=raw[at:at+size];at+=size
  if kind==0x4e4f534a:doc=json.loads(block)
  elif kind==0x004e4942:binary=block
 def array(i):
  a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dt=np.dtype(types[a['componentType']]);w=widths[a['type']];data=np.ndarray((a['count'],w),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',w*dt.itemsize),dt.itemsize));return {'count':a['count'],'type':a['type'],'componentType':a['componentType'],'normalized':a.get('normalized',False),'sha256':hashlib.sha256(data.tobytes()).hexdigest()}
 out={}
 for n in doc['nodes']:
  if 'mesh' not in n:continue
  name=n['name']
  if name.startswith(('site_nbr_s2__','site_se2__')):continue
  assert name not in out,name
  prim=[]
  for pr in doc['meshes'][n['mesh']]['primitives']:
   prim.append({'mode':pr.get('mode',4),'attributes':{k:array(v) for k,v in pr['attributes'].items()},'indices':array(pr['indices']) if 'indices' in pr else None,'material':doc.get('materials',[])[pr['material']] if 'material' in pr else None})
  out[name]={'transform':{k:n[k] for k in ['translation','rotation','scale','matrix'] if k in n},'primitives':prim}
 return out
rows=[]
for name in ['city_elevations','city_elevations_lod1']:
 rel='game/assets/props/'+name+'.glb';old=parts(subprocess.check_output(['git','show','c2a3db2d:'+rel]));new=parts((Path('C:/ov/city')/rel).read_bytes());assert set(old)==set(new),(name,len(old),len(new));bad=[k for k in old if old[k]!=new[k]];assert not bad,(name,bad);rows.append({'asset':rel,'unrelated_named_meshes':len(old),'all_attribute_index_material_transform_fingerprints_exact':True,'fingerprints':{k:hashlib.sha256(json.dumps(v,sort_keys=True).encode()).hexdigest() for k,v in new.items()}})
(p/'canonical_southern_unrelated_review.json').write_text(json.dumps({'evidence_class':'INERT','base':'c2a3db2d','candidate':'uncommitted donor native snapshot; recheck at freeze','scope':'Every non-southern-target semantic mesh attribute/index/material and local transform, exact comparison; not target geometry or world access.','assets':rows},indent=2)+'\n');print([(r['asset'],r['unrelated_named_meshes']) for r in rows])

