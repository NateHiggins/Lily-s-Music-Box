# Candidate verification - 402b4f6c7b89

- candidate `402b4f6c7b896c0a689fd1f7a30b4731b39ed0e0`
- base `4c913975cb0ceaf7e27623da5b06c45914ead15c`
- merge-base `4c913975cb0ceaf7e27623da5b06c45914ead15c`
- verified 2026-10-31T12:50:36Z from verifier `402b4f6c7b89`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 0 regressions, 0 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 4 |

## Blocking reasons (0)

- none

## Needs human review (not blocking) (3)

- candidate changes 4 gate file(s); read those diffs before trusting the board
- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (0)

- none

## Accepted regressions (0)

- none

## Improvements (0)

- none

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (4)

- M tools/interaction_implementor_manifest.json
- M tools/orison_spatial_dependency_manifest.json
- M tools/tests/test_city_ground_apron.py
- A tools/tests/test_city_street_geometry.py

MERGE-CANDIDATE 402b4f6c7b896c0a689fd1f7a30b4731b39ed0e0
