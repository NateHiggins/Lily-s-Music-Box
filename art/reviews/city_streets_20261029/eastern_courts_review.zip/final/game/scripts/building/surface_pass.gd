class_name SurfacePass
extends RefCounted
## MX-4 — the layered surface in production (TASKS.md §MX, owner direction
## 2026-08-21). After the floor scenes load, the surface classes in CLASSES
## trade their shipping StandardMaterial3D for `orison_surface.gdshader`
## (or the cutout variant where the shipping material scissors) carrying
## the SAME maps and scalars, plus the layers the class's recipe names:
## the height tier calibrated in millimetres, the self-detail tier, and any
## standing mask states. One ShaderMaterial per (shipping material, recipe),
## cached: the glTF shares one material per `M_<key>` per storey file, so
## this is hundreds of materials, not thousands of surfaces, and no draw is
## added.
##
## `SURFACE=0` in the environment leaves the shipping materials in place —
## the A of every A/B. `SURFACE_BUDGET=0.5` scales the parallax governor.
##
## Frames and costs that chose the recipes: art/renders/orison_surface_mx1/.
## The proof harness (game/tests/SurfaceShot.tscn) builds its options through
## `surface_for`, so what it photographs is what ships.

const OPAQUE := preload("res://shaders/orison_surface.gdshader")
const CUTOUT := preload("res://shaders/orison_surface_cutout.gdshader")
const HEIGHT_DIR := "res://assets/building/textures/height/"
const MASK_DIR := "res://assets/building/textures/masks/"
## MX-3: the ship tool (art/tools/ship_surface_tables.py) writes every
## height map stretched to 0..1 and this table of relief_mm / tile_m per key.
const CALIBRATION := preload("res://scripts/generated/surface_calibration.gd").CALIBRATION

## Millimetres of relief spanned by a set's height map (0..1). Mortar is the
## deepest thing on the building; a board seam is barely anything. MX-3
## moves these into the generated set table with the tile size.
const RELIEF_MM := {
	"face_brick": 10.0, "common_brick": 9.0, "brick": 9.0, "brick_patched": 9.0,
	"concrete": 3.0, "slab": 3.0, "limestone": 4.0, "subway_tile": 3.0,
	"ceramic": 2.5, "terrazzo": 0.6, "stair": 3.0, "landing": 2.0,
	"floor_oak": 1.5, "wainscot": 6.0, "tin_ceiling": 6.0, "cast_iron": 2.0,
	"sidewalk_haunted": 5.0, "asphalt": 5.0, "wet_asphalt": 4.0,
}
## Metres of world per texture tile, as the ingest recorded them
## (art/textures/ai_materials/<key>/material.json) and the builder baked them.
const TILE_M := {
	"arcade_terrazzo": .4, "arcade_terrazzo_dark": .4,
	"arcade_brick_face": .25, "arcade_lime_mortar": .25, "arcade_brick_bond": 1.2,
	"face_brick": 2.2, "common_brick": 1.2, "brick": 1.5, "brick_patched": 1.2,
	"concrete": 2.8, "slab": 2.8, "limestone": 1.6, "plaster": 1.8,
	"plaster_stained": 1.8, "subway_tile": 0.67, "ceramic": 0.65, "terrazzo": 4.0,
	"stair": 1.2, "floor_oak": 2.7, "wainscot": 0.72, "tin_ceiling": 1.2,
	"cast_iron": 0.4, "sidewalk_haunted": 1.52, "asphalt": 2.5, "wet_asphalt": 2.5,
	"trim": 1.1, "marble_lobby": 1.5,
}

## Surface classes by buffer-name substring, in rollout order, each with its
## standing recipe (shader parameters applied over the shipping material).
## Only the classes listed are touched; the census (MX-0) chose the order.
## Relief ships at 2.5x the calibrated millimetres: owner ruling 2026-08-21
## on the MX-1 frames ("exaggeration is cool").
const RELIEF_EXAGGERATION := 2.5

const CLASSES := [
	# The standing age (MX-3): grime settling in the joints, a little damp
	# low on the wall, wear on the crests -- from the packed wall_age library
	# (one fetch), never the procedural fields. Amounts are the quiet kind:
	# they modulate the authored albedo, they do not replace it.
	{"key": "walls", "match": "_walls",
			"recipe": {"parallax_mode": 2, "pom_steps_min": 6, "pom_steps_max": 14,
					"relief_mul": RELIEF_EXAGGERATION,
					"has_detail": true, "detail_albedo_strength": 0.18,
					"detail_normal_strength": 0.45,
					"mask": "wall_age", "mask_tile_m": 3.2,
					"mask_amount": Vector4(0.0, 0.30, 0.16, 0.18),
					"mask_threshold": Vector4(0.60, 0.35, 0.45, 0.40),
					"mask_softness": Vector4(0.15, 0.40, 0.35, 0.35)}},
	{"key": "finish", "match": "_finish_",
			"recipe": {"has_detail": true, "detail_albedo_strength": 0.12,
					"detail_normal_strength": 0.35,
					"mask": "wall_age", "mask_tile_m": 3.2,
					"mask_amount": Vector4(0.0, 0.24, 0.14, 0.0),
					"mask_threshold": Vector4(0.60, 0.35, 0.45, 0.40),
					"mask_softness": Vector4(0.15, 0.40, 0.35, 0.35)}},
	# Floors: M-COVER's anti-repetition rule per set (the coverage recipe is
	# resolved from the albedo's file name by COVERAGE_RULES) plus the height
	# tier and self-detail. Supersedes FloorCoveragePass.
	{"key": "floors", "match": "_floors_",
			"recipe": {"coverage_rule": true, "parallax_mode": 2, "pom_steps_min": 4,
					"pom_steps_max": 10, "relief_mul": RELIEF_EXAGGERATION,
					"has_detail": true, "detail_albedo_strength": 0.15,
					"detail_normal_strength": 0.4,
					"mask": "wall_age", "mask_tile_m": 4.0,
					"mask_amount": Vector4(0.0, 0.22, 0.0, 0.20),
					"mask_threshold": Vector4(0.60, 0.35, 0.45, 0.40),
					"mask_softness": Vector4(0.15, 0.40, 0.35, 0.35)}},
	# The third class of the census order: relief where the set has a height
	# map (wainscot beadboard, tin ceiling, stair and landing stone, slabs,
	# limestone trim), self-detail everywhere. Painted trim and sash have no
	# height map and get the normal tier only. `_stone_trim` is listed before
	# `_trim` so the substring match lands on the right class.
	{"key": "wainscot", "match": "_wainscot",
			"recipe": {"parallax_mode": 2, "pom_steps_min": 4, "pom_steps_max": 10,
					"relief_mul": RELIEF_EXAGGERATION, "has_detail": true,
					"detail_albedo_strength": 0.12, "detail_normal_strength": 0.4}},
	{"key": "ceiling", "match": "_ceiling",
			"recipe": {"parallax_mode": 1, "relief_mul": RELIEF_EXAGGERATION,
					"has_detail": true, "detail_albedo_strength": 0.12,
					"detail_normal_strength": 0.35}},
	{"key": "stairs", "match": "_stairs",
			"recipe": {"parallax_mode": 1, "relief_mul": RELIEF_EXAGGERATION,
					"has_detail": true, "detail_albedo_strength": 0.15,
					"detail_normal_strength": 0.4}},
	{"key": "slabs", "match": "_slabs",
			"recipe": {"parallax_mode": 1, "relief_mul": RELIEF_EXAGGERATION,
					"has_detail": true, "detail_albedo_strength": 0.15,
					"detail_normal_strength": 0.4}},
	{"key": "stone_trim", "match": "_stone_trim",
			"recipe": {"parallax_mode": 1, "relief_mul": RELIEF_EXAGGERATION,
					"has_detail": true, "detail_albedo_strength": 0.12,
					"detail_normal_strength": 0.4}},
	{"key": "trim", "match": "_trim",
			"recipe": {"has_detail": true, "detail_albedo_strength": 0.10,
					"detail_normal_strength": 0.35}},
	{"key": "sash", "match": "_sash",
			"recipe": {"has_detail": true, "detail_albedo_strength": 0.10,
					"detail_normal_strength": 0.35}},
	# The glTF furnishing (built-in furniture, retail fit-outs, transit
	# shelters): the normal tier only — no parallax, no detail; the census
	# put the per-pixel budget on the architecture (self-detail here cost
	# +1.2 ms at a flat stand). Two-sided and blended surfaces are left alone
	# by _eligible. Being on the one surface is what lets a state (grime,
	# moisture, corruption) reach them later without a second shader.
	{"key": "furnish", "match": "_furnish_", "recipe": {}, "draw_heavy": true},
	{"key": "furniture", "match": "_furniture_", "recipe": {}, "draw_heavy": true},
	{"key": "retail", "match": "_retail", "recipe": {}, "draw_heavy": true},
	{"key": "transit", "match": "_transit", "recipe": {}, "draw_heavy": true},
]

## The draw-heavy tiers — the glTF furnishing classes above and the batched
## props — are ON by owner ruling 2026-08-21 ("it should reach the props"):
## the states (grime, moisture, corruption) must be able to reach a prop.
## Measured at the 4B stand: furnishing +0.9 ms for 1,004 surfaces, props
## +1.1 ms for 4,274 draws (a ShaderMaterial draw costs more than a
## StandardMaterial3D draw on Compatibility; props are 87 % of draws). The
## governor pays for it: with the parallax budget already at zero and the
## frame still over target it drops the prop tier, and brings it back with
## headroom. `SURFACE_PROPS=0` keeps the tiers off for an A/B.
static func draw_heavy_enabled() -> bool:
	return OS.get_environment("SURFACE_PROPS") != "0"

## M-COVER's per-set coverage rule, keyed by the substring of the albedo
## file name (longest key wins). `cells` is the divider grid per tile
## counted on the albedo (terrazzo, _b, _d: 3x3; _c: 2x2); oak seams run
## along V, so rows step across U. Frames: art/renders/material_coverage_m/.
const COVERAGE_RULES := {
	"terrazzo_b": {"coverage": 2, "lattice_cells": 3.0},
	"terrazzo_c": {"coverage": 2, "lattice_cells": 2.0},
	"terrazzo_d": {"coverage": 2, "lattice_cells": 3.0},
	"terrazzo": {"coverage": 2, "lattice_cells": 3.0},
	"floor_oak": {"coverage": 3, "rows_per_tile": 14.0, "grain_along_u": false},
	"ceramic": {"coverage": 1, "hex_scale": 1.0},
	"concrete": {"coverage": 1, "hex_scale": 1.0},
}


static func coverage_rule_for(texture_path: String) -> Dictionary:
	var file := texture_path.get_file()
	var keys: Array = COVERAGE_RULES.keys()
	keys.sort_custom(func(a: String, b: String) -> bool: return a.length() > b.length())
	for key in keys:
		if file.contains("_%s_" % key):
			return COVERAGE_RULES[key]
	return {}

var swapped := 0
var materials := 0
var _cache := {}
## Layered architecture materials are cached by shipping-material identity and
## class.  Keep weak per-surface users as well so an independently unloadable
## provider can relinquish only its entries without disturbing another floor
## that legitimately shares the same cached material.
var _cache_users := {}

## ---- MX-2: the parallax governor ------------------------------------------
## The probe measures, the material obeys. Every GOVERN_INTERVAL seconds the
## building reports the viewport's measured GPU frame time; over the target
## the budget steps down (POM marches fewer steps and flattens, then stops
## marching at 0), under the target with headroom it steps back up. Pushed to
## every layered material as `parallax_budget`. SURFACE_TARGET_MS overrides
## the target (a low value is the way to watch it act); SURFACE_BUDGET pins
## the budget and disables the loop.
const GOVERN_INTERVAL := 0.5
const GOVERN_TARGET_MS := 14.0
const GOVERN_HEADROOM_MS := 3.0
const GOVERN_STEP := 0.25

var budget := 1.0
var governed_steps := 0
var _govern_clock := 0.0
var _govern_pinned := false
var _govern_target := GOVERN_TARGET_MS
## The second lever: the prop tier, dropped when the budget is spent.
var props_tier_on := true
var _props_root: Node = null
## Called (with no arguments) after the prop sweep lands or the lever
## re-applies the tier, so whoever layers states onto props can re-reach.
var on_props_applied: Callable = Callable()
var _over_streak := 0
var _under_streak := 0
## Flipping 4,000 material overrides in one frame read as a 900 ms hitch;
## the lever works through a queue, this many draws per physics frame.
const LEVER_CHUNK := 160
var _lever_queue: Array = []


func govern_setup() -> void:
	_govern_pinned = not OS.get_environment("SURFACE_BUDGET").is_empty()
	var target_env := OS.get_environment("SURFACE_TARGET_MS")
	if not target_env.is_empty():
		_govern_target = maxf(0.1, float(target_env))


## Call every physics frame with the delta and the viewport's measured GPU
## time (0 when measurement is unavailable: headless, or the dummy driver).
func govern(delta: float, gpu_ms: float) -> void:
	if _govern_pinned or gpu_ms <= 0.0:
		return
	_drain_lever()
	_govern_clock += delta
	if _govern_clock < GOVERN_INTERVAL:
		return
	_govern_clock = 0.0
	var next := budget
	if gpu_ms > _govern_target:
		next = maxf(0.0, budget - GOVERN_STEP)
		_over_streak += 1
		_under_streak = 0
	elif gpu_ms < _govern_target - GOVERN_HEADROOM_MS:
		next = minf(1.0, budget + GOVERN_STEP)
		_under_streak += 1
		_over_streak = 0
	else:
		_over_streak = 0
		_under_streak = 0
	# The prop tier: the last thing to go and the last to come back.
	if props_tier_on and budget <= 0.0 and _over_streak >= 3 and _props_root != null 			and _lever_queue.is_empty():
		props_tier_on = false
		for entry in _prop_swaps:
			_lever_queue.append([entry[0], entry[1]])
		_prop_swaps.clear()
		props_swapped = 0
		print("[SURFACE] governor: gpu %.1f ms with no parallax left -> prop tier OFF (%d draws queued)"
				% [gpu_ms, _lever_queue.size()])
	elif not props_tier_on and budget >= 1.0 and _under_streak >= 6 and _props_root != null 			and _lever_queue.is_empty():
		props_tier_on = true
		_queue_apply_props(_props_root)
		print("[SURFACE] governor: gpu %.1f ms with headroom -> prop tier ON (%d draws queued)"
				% [gpu_ms, _lever_queue.size()])
	if is_equal_approx(next, budget):
		return
	budget = next
	governed_steps += 1
	for m in _cache.values():
		(m as ShaderMaterial).set_shader_parameter("parallax_budget", budget)
	print("[SURFACE] governor: gpu %.1f ms vs %.1f target -> parallax budget %.2f"
			% [gpu_ms, _govern_target, budget])


## Returns the number of surfaces swapped. Idempotent per surface.
## A streaming owner may retain only the numeric texture measurements from
## its current world. This avoids GPU readback when the same immutable imported
## textures return, without retaining meshes, textures or shader materials.
var texture_statistics: Dictionary = {}

func apply(floor_nodes: Dictionary) -> int:
	if OS.get_environment("SURFACE") == "0":
		return 0
	govern_setup()
	var budget_env := OS.get_environment("SURFACE_BUDGET")
	if not budget_env.is_empty():
		budget = clampf(float(budget_env), 0.0, 1.0)
	for fid in floor_nodes:
		var floor_node: Node = floor_nodes[fid]
		for node in floor_node.find_children("*", "MeshInstance3D", true, false):
			var mi := node as MeshInstance3D
			if mi.mesh == null:
				continue
			var cls := _class_for(mi.name)
			if cls.is_empty():
				continue
			if bool(cls.get("draw_heavy", false)) and not draw_heavy_enabled():
				continue
			for s in mi.mesh.get_surface_count():
				if mi.get_surface_override_material(s) != null:
					continue
				var original := mi.mesh.surface_get_material(s) as BaseMaterial3D
				if not _eligible(original):
					continue
				var recipe: Dictionary = (cls.recipe as Dictionary).duplicate()
				recipe["parallax_budget"] = budget
				var cache_key := _surface_cache_key(original, str(cls.key))
				mi.set_surface_override_material(s, surface_for(
						original, recipe, str(cls.key), _cache,
						texture_statistics.get(texture_source_key(original), {})))
				_track_cache_user(cache_key, mi, s)
				swapped += 1
	materials = _cache.size()
	print("[SURFACE] %d surfaces layered (%d materials)" % [swapped, materials])
	return swapped


## The script-built props, AFTER they have been batched: every
## MeshInstance3D outside the glTF whose `material_override` (what the
## batcher and the prop builders set) is a textured, triplanar
## StandardMaterial3D — a MatLib material — takes the layered surface in
## triplanar mode with the same maps, tint, scale, roughness and metallic.
## One layered material per MatLib material, so the batcher's groups stay
## one draw each. Colour-only standards (no albedo map) and blended ones are
## left alone; so are props built after this sweep (spawned later).
## `restore_props` undoes it, for the harness.
## Normal tier only (the census put the per-pixel budget on the
## architecture): with self-detail the props cost +1.1 ms at a flat stand.
const PROPS_RECIPE := {"uv_mode": 1}

var props_swapped := 0
var _prop_swaps: Array = []


func apply_props(root: Node) -> int:
	if OS.get_environment("SURFACE") == "0" or not draw_heavy_enabled():
		return 0
	_props_root = root
	if not props_tier_on:
		return 0
	var recipe := PROPS_RECIPE.duplicate()
	recipe["parallax_budget"] = budget
	for node in root.find_children("*", "MeshInstance3D", true, false):
		var mi := node as MeshInstance3D
		if mi.mesh == null or not (mi.material_override is StandardMaterial3D):
			continue
		if _is_imported(mi):
			continue
		var original := mi.material_override as StandardMaterial3D
		if not original.uv1_triplanar or not _eligible(original):
			continue
		var layered := surface_for(original, recipe, "props", _cache)
		_prop_swaps.append([mi, original])
		mi.material_override = layered
		props_swapped += 1
	materials = _cache.size()
	print("[SURFACE] %d prop draws layered in triplanar mode (%d materials)"
			% [props_swapped, materials])
	if props_swapped > 0 and on_props_applied.is_valid():
		on_props_applied.call()
	return props_swapped


## Queue the prop sweep instead of doing it at once (the governor's lever).
func _queue_apply_props(root: Node) -> void:
	var recipe := PROPS_RECIPE.duplicate()
	recipe["parallax_budget"] = budget
	for node in root.find_children("*", "MeshInstance3D", true, false):
		var mi := node as MeshInstance3D
		if mi.mesh == null or not (mi.material_override is StandardMaterial3D):
			continue
		if _is_imported(mi):
			continue
		var original := mi.material_override as StandardMaterial3D
		if not original.uv1_triplanar or not _eligible(original):
			continue
		_lever_queue.append([mi, surface_for(original, recipe, "props", _cache), original])


func _drain_lever() -> void:
	if _lever_queue.is_empty():
		return
	var n := mini(LEVER_CHUNK, _lever_queue.size())
	var applied := false
	for _i in n:
		var entry: Array = _lever_queue.pop_front()
		var mi := entry[0] as MeshInstance3D
		if not is_instance_valid(mi):
			continue
		mi.material_override = entry[1]
		if entry.size() > 2:
			_prop_swaps.append([mi, entry[2]])
			props_swapped += 1
			applied = true
	if _lever_queue.is_empty() and applied and on_props_applied.is_valid():
		on_props_applied.call()


func restore_props() -> void:
	for entry in _prop_swaps:
		(entry[0] as MeshInstance3D).material_override = entry[1]
	_prop_swaps.clear()
	props_swapped = 0


## Release only layered materials applied to geometry below `geometry_root`.
##
## SurfacePass outlives an independently unloadable F01 provider because it is
## also the standing material authority for F02..ROOF and for script-built
## props.  Its cache therefore cannot simply be cleared during an F01 unload.
## This boundary uses the weak ownership recorded when each override was
## applied, removes users below the retiring provider, and erases an entry only
## when no living user remains.  Materials still used by another floor or by a
## persistent gameplay prop remain untouched, even if another presentation pass
## has since replaced one of the retiring provider's current overrides.
func release_geometry(geometry_root: Node) -> Dictionary:
	if geometry_root == null or not is_instance_valid(geometry_root):
		return {
			"ok": false,
			"reason": "geometry root is missing",
			"cleared_surface_overrides": 0,
			"released_cache_entries": 0,
			"remaining_cache_entries": _cache.size(),
		}
	var cleared := 0
	var released_keys := 0
	var released_materials := 0
	var shared_entries_preserved := 0
	for raw_key: Variant in _cache_users.keys().duplicate():
		var cached := _cache.get(raw_key) as ShaderMaterial
		var surviving_users: Array[Dictionary] = []
		var released_here := false
		for raw_user: Variant in _cache_users.get(raw_key, []):
			var user := raw_user as Dictionary
			var user_ref := user.get("node") as WeakRef
			var node := user_ref.get_ref() as MeshInstance3D \
					if user_ref != null else null
			if not is_instance_valid(node):
				continue
			if not _is_within(node, geometry_root):
				surviving_users.append(user)
				continue
			released_here = true
			var surface_index := int(user.get("surface", -1))
			if surface_index >= 0 \
					and surface_index < node.get_surface_override_material_count() \
					and node.get_surface_override_material(surface_index) == cached:
				node.set_surface_override_material(surface_index, null)
				cleared += 1
		if not released_here:
			# Prune dead weak users without claiming another provider's entry.
			if surviving_users.is_empty():
				_cache_users.erase(raw_key)
				_cache.erase(raw_key)
			else:
				_cache_users[raw_key] = surviving_users
			continue
		if not surviving_users.is_empty():
			_cache_users[raw_key] = surviving_users
			shared_entries_preserved += 1
			continue
		_cache_users.erase(raw_key)
		if cached != null:
			released_materials += 1
		if _cache.erase(raw_key):
			released_keys += 1
	materials = _cache.size()
	return {
		"ok": true,
		"cleared_surface_overrides": cleared,
		"released_cache_entries": released_keys,
		"released_materials": released_materials,
		"shared_cache_entries_preserved": shared_entries_preserved,
		"remaining_cache_entries": _cache.size(),
	}


func _track_cache_user(cache_key: String, node: MeshInstance3D,
		surface_index: int) -> void:
	if not _cache_users.has(cache_key):
		_cache_users[cache_key] = []
	var users := _cache_users[cache_key] as Array
	var node_id := node.get_instance_id()
	for raw_user: Variant in users:
		var user := raw_user as Dictionary
		if int(user.get("node_id", 0)) == node_id \
				and int(user.get("surface", -1)) == surface_index:
			return
	users.append({
		"node": weakref(node),
		"node_id": node_id,
		"surface": surface_index,
	})


static func _is_within(node: Node, boundary: Node) -> bool:
	var cursor := node
	while cursor != null:
		if cursor == boundary:
			return true
		cursor = cursor.get_parent()
	return false


## glTF geometry is owned by its imported scene; a prop's mesh is not.
static func _is_imported(node: Node) -> bool:
	var cursor: Node = node
	while cursor != null:
		var ext := cursor.scene_file_path.get_extension()
		if ext == "gltf" or ext == "glb":
			return node.owner == cursor
		cursor = cursor.get_parent()
	return false


static func _class_for(node_name: String) -> Dictionary:
	for cls in CLASSES:
		if node_name.contains(str(cls.match)):
			return cls
	return {}


## Textured, back-culled, opaque or scissored: what the layered surface can
## stand in for without changing how the surface sorts or faces.
static func _eligible(original: BaseMaterial3D) -> bool:
	if original == null or original.albedo_texture == null:
		return false
	if original.cull_mode != BaseMaterial3D.CULL_BACK:
		return false
	return original.transparency == BaseMaterial3D.TRANSPARENCY_DISABLED \
			or original.transparency == BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR


static func catalog_key(original: BaseMaterial3D) -> String:
	var key := String(original.resource_name)
	if key.begins_with("M_"):
		key = key.substr(2)
	return key

## Explicit exterior-owner adapter. Reuses maps/UVs in one opaque draw and
## never changes a catalogue material or a dry interior sharing its stock.
static func weather_surface(original: Material,cache: Dictionary) -> Material:
	if original==null:return null
	var identity:=original.get_instance_id()
	if cache.has(identity):return cache[identity]
	var result: ShaderMaterial
	if original is ShaderMaterial:
		if original.shader==null or original.shader.resource_path not in ["res://shaders/orison_surface.gdshader","res://shaders/orison_owner_component.gdshader"]:return original
		result=original.duplicate() as ShaderMaterial
	elif original is StandardMaterial3D and _eligible(original):
		var stock:=original.duplicate() as StandardMaterial3D
		stock.uv1_triplanar=false
		result=surface_for(stock,{"uv_mode":0,"relief_mul":0.0})
	else:return original
	result.set_shader_parameter("weather_exposure",1.0)
	result.set_meta("v2_weather_source",original)
	cache[identity]=result
	return result


## A family variant (`face_brick_c`) shares its base key's relief and tile
## size; its own height map ships under the full key.
static func base_key(key: String) -> String:
	for suffix in ["_b", "_c", "_d"]:
		if key.ends_with(suffix):
			return key.substr(0, key.length() - 2)
	return key


## One layered material for a shipping material and a recipe, carrying the
## shipping maps and scalars; `recipe` entries are shader parameters, except
## `relief_mul`, which scales the calibrated relief. `cache` (optional) is
## keyed by (material id, cache_key).
static func surface_for(original: BaseMaterial3D, recipe: Dictionary,
		cache_key: String = "", cache: Dictionary = {}, measured_stats: Dictionary = {}) -> ShaderMaterial:
	var ck := _surface_cache_key(original, cache_key)
	if not cache_key.is_empty() and cache.has(ck):
		return cache[ck]
	var key := catalog_key(original)
	var cutout := original.transparency == BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	var m := ShaderMaterial.new()
	m.shader = CUTOUT if cutout else OPAQUE
	m.set_shader_parameter("albedo_tex", original.albedo_texture)
	m.set_shader_parameter("albedo_color", original.albedo_color)
	if original.normal_texture != null and original.normal_enabled:
		m.set_shader_parameter("normal_tex", original.normal_texture)
		m.set_shader_parameter("normal_scale", original.normal_scale)
		m.set_shader_parameter("has_normal_tex", true)
	else:
		m.set_shader_parameter("has_normal_tex", false)
	if original.roughness_texture != null:
		m.set_shader_parameter("rough_tex", original.roughness_texture)
		m.set_shader_parameter("has_rough_tex", true)
		m.set_shader_parameter("rough_channel",
				1 if original.roughness_texture_channel == BaseMaterial3D.TEXTURE_CHANNEL_GREEN else 0)
	else:
		m.set_shader_parameter("has_rough_tex", false)
	m.set_shader_parameter("roughness_mul", original.roughness)
	m.set_shader_parameter("metallic", original.metallic)
	m.set_shader_parameter("mesh_uv_scale", Vector2(original.uv1_scale.x, original.uv1_scale.y))
	m.set_shader_parameter("mesh_uv_offset", Vector2(original.uv1_offset.x, original.uv1_offset.y))
	var base := base_key(key)
	if base in ["asphalt","wet_asphalt","sidewalk_haunted"]:
		m.set_shader_parameter("weather_exposure",1.0)
	var calibrated: Dictionary = CALIBRATION.get(key, CALIBRATION.get(base, {}))
	m.set_shader_parameter("tile_m", float(calibrated.get("tile_m", TILE_M.get(base, 1.0))))
	if original.uv1_triplanar:
		# MatLib: uv1_scale = 1 / (metres per tile x scale_mult).
		var repeats := maxf(0.001, original.uv1_scale.x)
		m.set_shader_parameter("uv_scale", repeats)
		m.set_shader_parameter("tile_m", 1.0 / repeats)
		m.set_shader_parameter("uv_mode", 1)
	var height: Texture2D = original.heightmap_texture if original.heightmap_enabled else null
	if height == null and ResourceLoader.exists(HEIGHT_DIR + key + ".png"):
		height = load(HEIGHT_DIR + key + ".png")
	var relief := float(calibrated.get("relief_mm", RELIEF_MM.get(base, 0.0)))
	if height != null and relief > 0.0:
		m.set_shader_parameter("height_tex", height)
		m.set_shader_parameter("has_height", true)
		m.set_shader_parameter("height_relief_mm", relief)
		# Shipped maps are stretched to 0..1 at ship time; only a map the
		# tool has not seen (HeightmapPass's own binding of an unlisted key)
		# is still measured.
		m.set_shader_parameter("height_range",
				Vector2(0.0, 1.0) if CALIBRATION.has(key) else height_range(height))
	var stats := measured_stats if _valid_texture_stats(measured_stats) else texture_stats(original)
	m.set_shader_parameter("albedo_mean", stats.albedo_mean)
	m.set_shader_parameter("rough_mean", stats.rough_mean)
	if cutout:
		m.set_shader_parameter("cutout_mode", 1)
		m.set_shader_parameter("cutout_threshold", original.alpha_scissor_threshold)
	for p in recipe:
		if p == "relief_mul":
			if height != null and relief > 0.0:
				m.set_shader_parameter("height_relief_mm", relief * float(recipe[p]))
			continue
		if p == "coverage_rule":
			if bool(recipe[p]):
				var rule := coverage_rule_for(original.albedo_texture.resource_path)
				for rk in rule:
					m.set_shader_parameter(rk, rule[rk])
			continue
		if p == "mask":
			var mask_path := MASK_DIR + str(recipe[p]) + ".png"
			if ResourceLoader.exists(mask_path):
				m.set_shader_parameter("mask_tex", load(mask_path))
				m.set_shader_parameter("has_mask_tex", true)
			continue
		m.set_shader_parameter(p, recipe[p])
	if not cache_key.is_empty():
		cache[ck] = m
	return m


static func _surface_cache_key(original: BaseMaterial3D,
		cache_key: String) -> String:
	return "%d|%s" % [original.get_instance_id(), cache_key]


## The working range of a height map — its 5th and 95th percentiles from a
## 128x128 resample. The ingest's band-passed heights never reach 0 or 1
## (face brick spans 0.39..0.65, concrete 0.45..0.54), so the millimetres of
## relief are mapped onto the range the map actually uses. Cached per texture.
static var _range_cache := {}
static func height_range(height: Texture2D) -> Vector2:
	var id := height.get_instance_id()
	if _range_cache.has(id):
		return _range_cache[id]
	var out := Vector2(0.0, 1.0)
	var img := height.get_image()
	if img != null:
		if img.is_compressed():
			img.decompress()
		img.resize(128, 128, Image.INTERPOLATE_BILINEAR)
		var values: Array[float] = []
		values.resize(128 * 128)
		for y in 128:
			for x in 128:
				values[y * 128 + x] = img.get_pixel(x, y).r
		values.sort()
		out = Vector2(values[int(values.size() * 0.05)], values[int(values.size() * 0.95)])
		if out.y - out.x < 0.05:
			out = Vector2(out.x, out.x + 0.05)
	_range_cache[id] = out
	return out


## Means of the albedo and roughness maps from a 32x32 resample — the
## variance-preserving coverage blend and the self-detail overlay both need
## to know what "average" is. Textures are shared across storeys and material
## variants, so cache by the actual texture pair rather than recomputing the
## same decompression/resample once per material.
static func texture_source_key(original: BaseMaterial3D) -> String:
	if original.albedo_texture == null or original.albedo_texture.resource_path.is_empty():
		return ""
	var rough_path := original.roughness_texture.resource_path if original.roughness_texture != null else ""
	if original.roughness_texture != null and rough_path.is_empty(): return ""
	return "%s|%s|%d" % [original.albedo_texture.resource_path, rough_path, original.roughness_texture_channel]

static func _valid_texture_stats(value: Dictionary) -> bool:
	if value.get("albedo_mean") is not Vector3 or typeof(value.get("rough_mean")) not in [TYPE_FLOAT, TYPE_INT]: return false
	var mean: Vector3 = value.albedo_mean
	var rough := float(value.rough_mean)
	return mean.is_finite() and mean.x >= 0.0 and mean.x <= 1.0 and mean.y >= 0.0 and mean.y <= 1.0 \
			and mean.z >= 0.0 and mean.z <= 1.0 and is_finite(rough) and rough >= 0.0 and rough <= 1.0

static var _stats_cache := {}
static func texture_stats(original: BaseMaterial3D) -> Dictionary:
	var rough_id := original.roughness_texture.get_instance_id() \
			if original.roughness_texture != null else 0
	var cache_key := "%d|%d|%d" % [original.albedo_texture.get_instance_id(),
			rough_id, int(original.roughness_texture_channel)]
	var use_cache := OS.get_environment("SURFACE_STATS_CACHE") != "0"
	if use_cache and _stats_cache.has(cache_key):
		return _stats_cache[cache_key]
	var out := {"albedo_mean": Vector3(0.5, 0.5, 0.5), "rough_mean": 0.5}
	var img := original.albedo_texture.get_image()
	if img != null:
		if img.is_compressed():
			img.decompress()
		img.resize(32, 32, Image.INTERPOLATE_BILINEAR)
		var sum := Vector3.ZERO
		for y in 32:
			for x in 32:
				# source_color samplers deliver linear RGB to the shader. The
				# image readback is sRGB; mixing its encoded mean with a linear
				# texel darkened self-detail and biased stochastic coverage.
				var c := img.get_pixel(x, y).srgb_to_linear()
				sum += Vector3(c.r, c.g, c.b)
		out.albedo_mean = sum / 1024.0
	if original.roughness_texture != null:
		var rimg := original.roughness_texture.get_image()
		if rimg != null:
			if rimg.is_compressed():
				rimg.decompress()
			rimg.resize(32, 32, Image.INTERPOLATE_BILINEAR)
			var rsum := 0.0
			var green := original.roughness_texture_channel == BaseMaterial3D.TEXTURE_CHANNEL_GREEN
			for y in 32:
				for x in 32:
					var c := rimg.get_pixel(x, y)
					rsum += c.g if green else c.r
			out.rough_mean = rsum / 1024.0
	if use_cache:
		_stats_cache[cache_key] = out
	return out
