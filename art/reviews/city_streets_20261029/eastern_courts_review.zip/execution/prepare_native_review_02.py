from pathlib import Path
out=Path(__file__).parent
code=(out/'review_native_01.py').read_text().replace("/'native_review_01'","/'native_review_02'")
start=code.index('    views=[]');end=code.index('    for label,identities',start)
code=code[:start]+'''    views=[]
    for identity in IDS:
        row=profiles[identity];a,b,c,d=row['rect'];height=row['height_m'];middle=(b+d)/2
        if family=='city_horizon_lod1' or identity!=IDS[3]:
            views.append((identity,[identity],(c+22,-middle-18,height*1.15),((a+c)/2,-middle,height*.48),32.,(1100,900)))
        if family=='city_horizon_near' and identity!=IDS[3]:
            if identity==IDS[0]:eye=(c+8,-b-7,height+6);aim=(c-3,-b-3,height+.6);scale=13.
            elif identity==IDS[1]:eye=(c+9,-middle-4,3.7);aim=(c-3,-middle,2.0);scale=14.
            else:eye=(c+8,-middle-10,height+5);aim=(c-2,-middle,height+.9);scale=15.
            views.append((identity+'_detail',[identity],eye,aim,scale,(1100,900)))
    if family=='city_horizon_near':
        views.append(('cedar_factory_context',[IDS[0],IDS[3]],(-126.,58.,29.),(-160.,26.,8.),52.,(1400,950)))
        views.append(('plymouth_willow_context',IDS[1:3],(-125.,-22.,28.),(-160.,-55.,8.),58.,(1400,950)))
''' +code[end:]
code=code.replace('len(captures)==16','len(captures)==12')
(out/'review_native_02.py').write_text(code,encoding='utf-8',newline='\n')
runner=(out/'run_native_review_01.py').read_text().replace('_01','_02')
(out/'run_native_review_02.py').write_text(runner,encoding='utf-8',newline='\n')
