from pathlib import Path
out=Path(__file__).parent;code=(out/'reconcile_factory_exposure_01.py').read_text().replace('import json,struct,subprocess,collections,hashlib','import json,struct,subprocess,collections,hashlib,math,itertools')
start=code.index('rows=[]')
helper='''def reconcile(a,b,epsilon=.0001):
    # Adding a north-facing frame changes a part's origin. Export float32
    # recentering shifts other represented vertices by a few micrometres.
    # Keep the raw equality failure;independently match at existing native
    # precision,then localize every truly removed/added triangle.
    old=list((a-b).elements());new=list((b-a).elements());buckets=collections.defaultdict(list)
    def cell(t):return tuple(math.floor(sum(p[i] for p in t)/3/epsilon) for i in range(3))
    for i,t in enumerate(new):buckets[cell(t)].append(i)
    used=set();removed=[];matched=0;maximum=0.
    for t in old:
        c=cell(t);choice=None;error=math.inf
        for shift in itertools.product([-1,0,1],repeat=3):
            for index in buckets.get(tuple(c[i]+shift[i] for i in range(3)),[]):
                if index in used:continue
                candidate=new[index]
                distance=min(max(math.dist(p,q) for p,q in zip(t,order)) for order in itertools.permutations(candidate))
                if distance<=epsilon and distance<error:choice=index;error=distance
        if choice is None:removed.append(t)
        else:used.add(choice);matched+=1;maximum=max(maximum,error)
    return removed,[t for i,t in enumerate(new) if i not in used],matched,maximum

'''
code=code[:start]+helper+code[start:]
old="        removed=list((old[name]-new[name]).elements());added=list((new[name]-old[name]).elements());points=[p for tri in removed+added for p in tri]"
new="        removed,added,matched,maximum=reconcile(old[name],new[name]);points=[p for tri in removed+added for p in tri]"
assert code.count(old)==1;code=code.replace(old,new).replace('all_other_triangles_exact=True','other_triangles_matched_at_original_native_precision=matched,max_represented_recenter_error_m=maximum,tolerance_m=.0001')
code=code.replace("/'factory_exposure_reconciliation_01.json'","/'factory_exposure_reconciliation_02.json'")
(out/'reconcile_factory_exposure_02.py').write_text(code,encoding='utf-8',newline='\n')
