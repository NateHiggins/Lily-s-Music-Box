from pathlib import Path
import json,ast,struct,hashlib,subprocess
root=Path('C:/ov/city');out=Path(__file__).parent;ids=['HORIZON_NEAR_2_1_P1','HORIZON_NEAR_2_2_P1','HORIZON_NEAR_2_2_P2']
reader=out.parent/'bodega_frontage_reconciliation_01/check_preservation_01.py';tree=ast.parse(reader.read_text(encoding='utf-8-sig'));exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(reader),'exec'))
p=root/'art/data/city_horizon/source_plan.json';raw=p.read_bytes();plan=json.loads(raw)
baseline=dict(evidence_class='INERT',sourcebase=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),targets=ids,source_plan_sha256=hashlib.sha256(raw).hexdigest(),profiles=plan['buildings'],parts={f:projection((root/f'game/assets/props/{f}.glb').read_bytes()) for f in ['city_horizon_near','city_horizon_far','city_horizon_lod1']},other_assets={f'game/assets/props/{f}.glb':hashlib.sha256((root/f'game/assets/props/{f}.glb').read_bytes()).hexdigest() for f in ['city_elevations','city_elevations_lod1','city_streets','city_streets_lod1','city_transport','city_transport_lod1','city_ground_apron','orison_ground','front_pavement','bodega_receiving']})
target=out/'baseline_01.json';assert not target.exists();target.write_text(json.dumps(baseline,indent=2),encoding='utf-8',newline='\n')
styles=[('cedar_8301',[.9,3.5,3.3,3.3,3.3],'arcade_brick_bond',[.64,.43,.31,1.],'Cedar Court,83-01 to83-09 35thAvenue,AndrewJ.Thomas,1924-25:fourmainstories+basement,Cplan openingtogarden,stairhalltowers,open top-story loggias andSpanish-clay roofs.',[95]),('plymouth_3516',[.9,3.35,3.2,3.2,3.2,3.15],'arcade_brick_bond',[.68,.55,.43,1.],'Plymouth Apartments,35-16 82ndStreet,GeorgeH.Wells,1916:five mainstories+basement,modifiedT/pavilionplan withside lightcourts,rusticated banding,Doriccolumned porch andparapet swags.',[29,30,58,59,169]),('willow_3535',[.9,3.3,3.15,3.15,3.15,3.05],'city_grey_brick',[.78,.65,.47,1.],'Willow Court,35-35 82ndStreet,GeorgeH.Wells,1915:five mainstories+basement,Hplan withtwo openlightcourts,brickabove stonebase,keyedupperenframements,pedimented entry andarcadedparapet.',[30,60,164,165])]
for identity,(style,heights,key,tint,precedent,pages) in zip(ids,styles):
    row=next(r for r in plan['buildings'] if r['id']==identity);a,b,c,d=row['rect']
    if style=='cedar_8301':
        F=c-1.9;outline=[[F,d],[a,d],[a,b],[F,b],[F,b+6],[F-7.5,b+6],[F-7.5,d-6],[F,d-6]]
        counts=[6,6,6,3,3,3,3,3];entries=[4,5,6]
        courts=[[F-7.5,b+6,F,d-6],[F,b,c,d]]
    elif style=='plymouth_3516':
        F=c-2.8;outline=[[F,d],[F-6.5,d],[F-6.5,d-4.8],[a,d-4.8],[a,b+4.8],[F-6.5,b+4.8],[F-6.5,b],[F,b],[F,b+4.5],[F-.30,b+4.5],[F-.30,d-4.5],[F,d-4.5]]
        counts=[2,1,3,4,3,1,2,2,1,5,1,2];entries=[9]
        courts=[[a,b,F-6.5,b+4.8],[a,d-4.8,F-6.5,d],[F,b,c,d],[F-.30,b+4.5,F,d-4.5]]
    else:
        F=c-1.2;outline=[[F,d],[a,d],[a,d-6],[a+7.2,d-6],[a+7.2,b+6],[a,b+6],[a,b],[F,b],[F,b+6],[a+11.6,b+6],[a+11.6,d-6],[F,d-6]]
        counts=[6,2,2,3,2,2,6,2,2,3,2,2];entries=[9]
        courts=[[a,b+6,a+7.2,d-6],[a+11.6,b+6,F,d-6],[F,b,c,d]]
    row.update(height_m=sum(heights),wall_key=key,wall_tint=tint,joinery_tint=[.32,.35,.29,1.],typology='walkup',window_width_m=1.35,window_height_m=2.0)
    row['architecture']=dict(type='eastern_row',style=style,precedent=precedent,source='https://s-media.nyc.gov/agencies/lpc/lp/1831.pdf',source_pdf_pages=pages,adaptation='AU individual study inexisting20m-deep/20to21.667m-frontage reservation. C/T/Hsilhouettes followLPCtext andactual1916plans;dimensions,colors,courtpaving,storeyheights andgeographicplacement areauthored,not surveyedreplicas. ModernPlymouthphotograph informsformonly;no moderncars/alterations copied. Exteriorcourts stayopen. Scenic leaves addnooccupiedapartment interiors ornewaccessauthority. No referencepixels inassets.',floor_heights_m=heights,front_side=entries[0],entry_sides=entries,court_paving_m=courts,cornice_key='door_paint',outline_m=outline,side_bays=counts)
p.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n');print('Authored3court plans;all oldassets stillfrozen')
