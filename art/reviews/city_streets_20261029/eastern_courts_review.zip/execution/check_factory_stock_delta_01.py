from pathlib import Path
import json,sys,subprocess,collections,hashlib,bpy
root=Path('C:/ov/city');out=Path(__file__).parent;sys.path.insert(0,str(root/'art/blender/scripts'))
from city_industrial_architecture import IndustrialBuildings
before=json.loads(subprocess.check_output(['git','show','e3ccd6bd:game/tests/fixtures/orison_city_horizon.json'],cwd=root));after=json.loads((root/'game/tests/fixtures/orison_city_horizon.json').read_text());identity='HORIZON_NEAR_2_1_P2';records=[]
for lower in [False,True]:
    versions=[]
    for data in [before,after]:
        rows=[r for r in data['buildings'] if 'NEAR' in r['id']];row=next(r for r in rows if r['id']==identity);stocks=collections.Counter()
        def emit(owner,key,vertices,faces):stocks[(key,tuple(tuple(p) for p in vertices),tuple(tuple(f) for f in faces))]+=1
        result=IndustrialBuildings(row,emit,[r for r in rows if r['id']!=identity],lower).build();versions.append((stocks,result))
    old,new=versions;removed=list((old[0]-new[0]).elements());added=list((new[0]-old[0]).elements());points=[(x,z,-y) for stock in removed+added for x,y,z in stock[1]]
    bounds=[min(p[i] for p in points) for i in range(3)]+[max(p[i] for p in points) for i in range(3)]
    assert all(15.04<=p[1]<=18.75 and -26.10<=p[2]<=-25.55 for p in points),(lower,bounds)
    records.append(dict(lower=lower,unchanged_closed_stocks=sum((old[0]&new[0]).values()),removed_closed_stocks=len(removed),added_closed_stocks=len(added),changed_stock_bounds=bounds,pane_count_before=len(old[1]['windows']),pane_count_after=len(new[1]['windows']),entries_unchanged=old[1]['entries']==new[1]['entries'],all_other_source_stocks_exact=True))
    assert old[1]['entries']==new[1]['entries']
record=dict(evidence_class='INERT',scope='Source closed-stock delta independent ofexporttriangulation:onlynewlyexposednorthupperfloor designchanges. Exportraw/triangle equality failures remain;affectedfinishedfactorybody stillrequiresrenewal.',records=records,industrial_source_sha256=hashlib.sha256((root/'art/blender/scripts/city_industrial_architecture.py').read_bytes()).hexdigest(),old_factory_receipt_not_promoted=True)
path=out/'factory_stock_delta_01.json';assert not path.exists();path.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n');print(json.dumps(record))
