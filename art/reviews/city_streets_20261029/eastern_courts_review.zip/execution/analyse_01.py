from pathlib import Path
import json,hashlib,math,statistics
from PIL import Image,ImageDraw,ImageChops
out=Path(__file__).parent
data=json.loads((out/'bench_01/courts_loaded.runtime.json').read_text(encoding='utf-8'))
access=json.loads((out/'access_02/courts_access.runtime.json').read_text(encoding='utf-8'))
assert not data['failures'] and not access['failures']
assert len(data['observations'])==20 and len(access['routes'])==5
def summary(rows):
    result={}
    for key in ['wall_ms','viewport_cpu_ms','viewport_gpu_ms']:
        values=sorted(float(x[key]) for x in rows)
        result[key]={k:values[min(len(values)-1,max(0,math.ceil(len(values)*v)-1))] for k,v in [('p95',.95),('p99',.99),('max',1.)]}
        result[key]['median']=statistics.median(values)
    return dict(frames=len(rows),metrics=result)
warm=[x for r in data['observations'] for x in r['samples']]
transition=[x for r in data['observations'] for x in r['warmup_samples']]
record=dict(evidence_class='INERT',scope='Analysis of exact isolated runtime receipts. Startup excluded; raw transition spikes retained. No matched gain,composed-world performance budget or artistic acceptance.',checks=data['checks'],access_checks=access['checks'],warmed=summary(warm),transitions=summary(transition),profiles=[dict(building=r['building'],id=r['id'],counters=r['counters']) for r in data['observations']],controller_routes=[dict(building=r['building'],court=r['court'],samples=len(r['movement_samples']),bad_floor=r['bad_floor_samples'],bad_lateral=r['bad_lateral_samples']) for r in access['routes']])
(out/'loaded_analysis_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
groups=[('whole',list((out/'bench_01').glob('*_profile_*.png')),2),('access',list((out/'access_02').glob('*.png')),2)]
for name,paths,cols in groups:
    paths=sorted(paths);rows=math.ceil(len(paths)/cols);assert paths
    thumb=(600,252);cell=(600,278);canvas=Image.new('RGB',(cell[0]*cols,cell[1]*rows),'#282c30');draw=ImageDraw.Draw(canvas)
    for i,path in enumerate(paths):
        with Image.open(path) as im:
            copy=im.convert('RGB');copy.thumbnail(thumb)
            x=i%cols*cell[0];y=i//cols*cell[1];canvas.paste(copy,(x,y))
            draw.text((x+4,y+254),path.stem,fill='white')
    canvas.save(out/(name+'_contact_01.png'))
sheet=Image.new('RGB',(2000,880),(35,35,35));draw=ImageDraw.Draw(sheet);bounds=[]
for row,identity in enumerate(sorted(data['natural_transitions'])):
    for col,phase in enumerate(['before','after','narrow','return']):
        target=out/'bench_01'/(identity+'_natural_'+phase+'.png')
        background=target.with_name(target.stem+'_background.png')
        a=Image.open(target).convert('RGB');b=Image.open(background).convert('RGB')
        diff=ImageChops.difference(a,b).convert('L').point(lambda v:255 if v>5 else 0)
        box=diff.getbbox();assert box,(identity,phase)
        box=(max(0,box[0]-8),max(0,box[1]-8),min(a.width,box[2]+8),min(a.height,box[3]+8))
        bounds.append(dict(target=target.name,background=background.name,crop=box))
        for offset,img in enumerate([a,b]):
            crop=img.crop(box);crop.thumbnail((245,190));x=col*500+offset*250;y=row*220
            sheet.paste(crop,(x+(250-crop.width)//2,y));draw.text((x+3,y+193),identity.replace('HORIZON_','')+' '+phase+(' hidden' if offset else ''),fill='white')
sheet.save(out/'natural_contact_01.png')
(out/'natural_contact_crops_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Derived diagnostic crops;original full-resolution frames unchanged.',records=bounds),indent=2),encoding='utf-8',newline='\n')
print(json.dumps(record))
