"""Read-only native/export roundtrips and bounded CPU-only architectural views."""
from pathlib import Path
import bpy,collections,json,hashlib,os
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from bpy_extras.object_utils import world_to_camera_view
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent/'native_review_01';OUT.mkdir(exist_ok=False)
IDS=['HORIZON_NEAR_2_1_P1','HORIZON_NEAR_2_2_P1','HORIZON_NEAR_2_2_P2','HORIZON_NEAR_2_1_P2']
profiles={r['id']:r for r in json.loads((ROOT/'art/data/city_horizon/source_plan.json').read_text())['buildings']}
construction=json.loads((ROOT/'art/blender/city_horizon_construction.json').read_text())
captures=[];roundtrips=[];bindings={};contacts=[]
def triangles(obj):
    obj.data.calc_loop_triangles()
    return collections.Counter(tuple(sorted(tuple(float(c) for c in obj.matrix_world@obj.data.vertices[i].co) for i in t.vertices)) for t in obj.data.loop_triangles)
for family,collection,chosen in [('city_horizon_near','CityHorizon_near',IDS),('city_horizon_lod1','CityHorizonReplacementBodies',IDS)]:
    native=ROOT/f'art/blender/{family}.blend';bindings[native.relative_to(ROOT).as_posix()]=hashlib.sha256(native.read_bytes()).hexdigest();bpy.ops.wm.open_mainfile(filepath=str(native))
    original=[o for o in bpy.data.collections[collection].objects if o.name.split('__')[0] in chosen]
    expected={o.name:triangles(o) for o in original};mats={o.name:o.data.materials[0] for o in original}
    for obj in bpy.context.scene.objects:
        if obj.type=='MESH':obj.hide_render=True
    asset=ROOT/f'game/assets/props/{family}.glb';bindings[asset.relative_to(ROOT).as_posix()]=hashlib.sha256(asset.read_bytes()).hexdigest()
    before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(asset));bpy.context.view_layer.update();imported={}
    for obj in [o for o in bpy.data.objects if o not in before and o.type=='MESH']:
        name=obj.name.split('.')[0];obj.hide_render=name not in expected
        if obj.hide_render:continue
        assert triangles(obj)==expected[name],(family,name,'native/export positions differ')
        assert len(obj.data.uv_layers)==1
        obj.data.materials.clear();obj.data.materials.append(mats[name]);imported[name]=obj
        roundtrips.append(dict(family=family,part=name,triangles=sum(expected[name].values()),exact_float32_positions=True))
    assert imported.keys()==expected.keys()
    trees={name:BVHTree.FromPolygons([obj.matrix_world@v.co for v in obj.data.vertices],[tuple(f.vertices) for f in obj.data.polygons],all_triangles=True) for name,obj in imported.items()}
    for row in construction['parapet_contacts']:
        if row['building'] not in IDS:continue
        identity=row['building'];p=Vector(row['point']);profile=profiles[identity]
        residential=profile['architecture']['type']=='residential_front'
        support=p.copy()
        if residential:
            heights=profile['architecture']['floor_heights_m']
            support.z=sum(heights if profile['architecture']['style']=='italianate_2109' else heights[:-1])+next(r['grade_datum_m'] for r in construction['buildings'] if r['id']==identity)
        direction=Vector((0,0,-1 if residential else 1))
        expected=identity+'__'+row['wall_key']
        hits=[]
        for name,tree in trees.items():
            hit,normal,index,distance=tree.ray_cast(support-direction*.025,direction,.05)
            if hit is not None and normal.dot(direction)<0:hits.append((distance,name,hit))
        assert hits,('no unfiltered receiver',family,row)
        distance,name,hit=min(hits,key=lambda h:h[0])
        assert name==expected and (hit-support).length<.0001,('actual first receiving stock',family,row,name,list(hit),list(support))
        roof=trees[identity+'__galvanized_roof']
        hit,normal,index,distance=roof.ray_cast(p+Vector((0,0,.025)),Vector((0,0,-1)),.05)
        assert hit is not None and (hit-p).length<.0001,('roof top',family,row)
        outside=Vector(row['outside_probe']);hit,normal,index,distance=roof.ray_cast(outside+Vector((0,0,.025)),Vector((0,0,-1)),.05)
        assert hit is None,('outside roof control',family,row)
        contacts.append(dict(family=family,contact=row,first_receiving_part=name,error_m=(support-(min(hits,key=lambda h:h[0])[2])).length))
    for image in bpy.data.images:
        if image.source!='FILE' or image.packed_file:continue
        path=ROOT/'game/assets/building/textures'/Path(image.filepath).name;assert path.is_file(),path
        image.filepath=str(path);image.reload();assert min(image.size)>0
    scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.cycles.use_denoising=True;scene.cycles.max_bounces=4
    scene.render.threads_mode='FIXED';scene.render.threads=2;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX';scene.render.resolution_percentage=100
    world=bpy.data.worlds.new('Eastern block review');world.use_nodes=True;scene.world=world;world.node_tree.nodes['Background'].inputs[0].default_value=(.18,.21,.27,1);world.node_tree.nodes['Background'].inputs[1].default_value=.7
    sun=bpy.data.objects.new('Review key',bpy.data.lights.new('Review key','SUN'));scene.collection.objects.link(sun);sun.rotation_euler=Vector((-1.,.35,-.9)).to_track_quat('-Z','Y').to_euler();sun.data.energy=2.5;sun.data.angle=.15
    camera=bpy.data.objects.new('Native review camera',bpy.data.cameras.new('Native review camera'));scene.collection.objects.link(camera);scene.camera=camera;camera.data.clip_start=.02
    views=[]
    for identity in IDS:
        row=profiles[identity];a,b,c,d=row['rect'];height=row['height_m'];middle=(b+d)/2
        views.append((identity,[identity],(c+22,-middle-18,height*1.15),((a+c)/2,-middle,height*.48),32.,(1100,900)))
        if family=='city_horizon_near':
            if identity==IDS[0]:eye=(c-2.6,-middle,1.7);aim=(c-9.0,-middle,2.0)
            elif identity==IDS[1]:eye=(a+.7,-b-2.4,1.7);aim=(c-9.5,-b-2.4,2.0)
            elif identity==IDS[2]:eye=(c-1.7,-middle,1.7);aim=(a+12.0,-middle,2.0)
            else:eye=(c+11,-b+9,18.5);aim=((a+c)/2,-b,16.5)
            label=identity+('_court' if identity!=IDS[3] else '_detail')
            views.append((label,[identity],eye,aim,14.,(1100,900)))
    views.append(('cedar_factory_context',[IDS[0],IDS[3]],(-126.,58.,29.),(-160.,26.,8.),52.,(1400,950)))
    views.append(('plymouth_willow_context',IDS[1:3],(-125.,-22.,28.),(-160.,-55.,8.),58.,(1400,950)))
    for label,identities,eye,aim,scale,res in views:
        visible=[]
        for name,obj in imported.items():
            obj.hide_render=name.split('__')[0] not in identities
            if not obj.hide_render:visible.append(obj)
        camera.location=eye;camera.rotation_euler=(Vector(aim)-camera.location).to_track_quat('-Z','Y').to_euler()
        camera.data.type='PERSP' if label.endswith('_court') else 'ORTHO';camera.data.lens=22.;camera.data.ortho_scale=scale;scene.render.resolution_x,scene.render.resolution_y=res
        detail=label.endswith('_detail') or label.endswith('_court');framed=None
        if not detail:
            for attempt in range(24):
                bpy.context.view_layer.update();points=[world_to_camera_view(scene,camera,obj.matrix_world@Vector(corner)) for obj in visible for corner in obj.bound_box]
                framed=all(p.z>0 and .035<=p.x<=.965 and .035<=p.y<=.965 for p in points)
                if framed:break
                camera.data.ortho_scale*=1.12
            assert framed,(family,label,'whole framing')
        path=OUT/(family+'_'+label+'.png');scene.render.filepath=str(path);bpy.ops.render.render(write_still=True)
        captures.append(dict(path=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),family=family,buildings=identities,whole_body_framed=framed,intentional_detail_crop=detail))
for path,expected in bindings.items():assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==expected,path
assert len(roundtrips)>0 and len(contacts)==82 and len(captures)==16,(len(roundtrips),len(contacts),len(captures))
(OUT/'review.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Read-only native geometry/UV/PBR/whole replacement-body presentation. Not loaded Godot surfaces,street support,played access,performance or artistic acceptance.',sources_unchanged=bindings,roundtrips=roundtrips,near_and_lower_unfiltered_bearing_controls=contacts,captures=captures),indent=2),encoding='utf-8',newline='\n')
print('EASTERN NATIVE REVIEW COMPLETE',len(roundtrips),'roundtrips',len(contacts),'roof/bearing/outside controls',len(captures),'images',flush=True)
