from pathlib import Path
out=Path(__file__).parent;prior=out.parent/'eastern_houses_01'
for name in ['run_native_build_01.py','verify_export_uv_01.py','check_preservation_01.py']:
    (out/name).write_text((prior/name).read_text(),encoding='utf-8',newline='\n')
