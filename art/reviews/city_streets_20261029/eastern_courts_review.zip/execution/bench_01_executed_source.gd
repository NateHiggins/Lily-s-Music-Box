extends "res://tests/v2_city_horizon_bench.gd"
## Isolated production-loader programme; no world/ground/access claim.
const IDS=["HORIZON_NEAR_2_1_P1","HORIZON_NEAR_2_2_P1","HORIZON_NEAR_2_2_P2","HORIZON_NEAR_2_1_P2"]
var view_direction:Vector3=Vector3(1.,.12,.18).normalized()
var observations:Array[Dictionary]=[]
var transitions:Dictionary={}
var maps:Dictionary={}
var actual_materials:Dictionary={}

func _ready()->void:call_deferred("run_family")

func _sources(owner:Node3D)->Dictionary:
    var result=_industrial_sources(owner)
    for path:String in [get_script().resource_path,"res://tests/orison_v2_domestic_native_test.gd","res://tests/orison_v2_roof_bulkhead_caps_test.gd"]:result[path]=_profile_sha(path)
    for path:String in ["res://data/orison_v2/owner_finish_profiles.json","res://scripts/building/surface_pass.gd","res://shaders/orison_surface.gdshader","res://shaders/orison_surface.gdshaderinc","res://shaders/dream_corruption_layers.gdshaderinc","res://shaders/queens_surface_wetness.gdshaderinc"]:result[path]=_profile_sha(path)
    for draw:MeshInstance3D in owner.find_children("*","MeshInstance3D",true,false):
        if not draw.get_meta("v2_city_horizon_body_lod",false):continue
        var actual_shader=draw.material_override as ShaderMaterial
        if actual_shader!=null:
            for parameter:String in ["albedo_tex","rough_tex","normal_tex"]:
                var texture:Texture2D=actual_shader.get_shader_parameter(parameter)
                if texture!=null:
                    result[texture.resource_path]=_profile_sha(texture.resource_path)
                    result[texture.resource_path+".import"]=_profile_sha(texture.resource_path+".import")
    return result

func _counters()->Dictionary:
    var rid=get_viewport().get_viewport_rid()
    return {"visible_draws":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_VISIBLE,RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME),"visible_primitives":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_VISIBLE,RenderingServer.VIEWPORT_RENDER_INFO_PRIMITIVES_IN_FRAME),"shadow_draws":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_SHADOW,RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME),"shadow_primitives":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_SHADOW,RenderingServer.VIEWPORT_RENDER_INFO_PRIMITIVES_IN_FRAME),"aggregate_draws":Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME),"aggregate_primitives":Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME)}

func run_family()->void:
    RealityState.persistence_enabled=false;RealityState.reset_campaign_for_tests();CampaignTime.set_frozen_for_tests(true)
    var directory=OS.get_environment("SHOT_DIR")
    check(not directory.is_empty() and DisplayServer.get_name()!="headless","graphical output directory supplied")
    if directory.is_empty() or DisplayServer.get_name()=="headless":get_tree().quit(1);return
    DirAccess.make_dir_recursive_absolute(directory)
    var fixture:Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://tests/fixtures/orison_city_horizon.json"))
    for asset:Dictionary in fixture.assets.values():check(FileAccess.get_sha256("res://"+str(asset.asset).trim_prefix("game/"))==str(asset.sha256),"asset matches native fixture")
    var horizon=Horizon.new();add_child(horizon)
    await get_tree().physics_frame;await get_tree().physics_frame
    var sources=_sources(horizon)
    var metrics=preload("res://tests/orison_v2_domestic_native_test.gd").new()
    var lower=(load("res://assets/props/city_horizon_lod1.glb") as PackedScene).instantiate()
    var low_counts:Dictionary={};var expected_parts:Dictionary={}
    for part:Dictionary in fixture.assets.body_lod.parts:
        if str(part.name).split("__")[0] in IDS:expected_parts[str(part.name)]=int(part.triangles)
    for part:MeshInstance3D in lower.find_children("*","MeshInstance3D",true,false):
        if not expected_parts.has(str(part.name)):continue
        metrics._check_cap_mapping(part.mesh,true)
        low_counts[str(part.name)]=part.mesh.surface_get_array_index_len(0)/3
        check(int(low_counts[str(part.name)])==int(expected_parts[str(part.name)]),"complete imported replacement part "+str(part.name))
    lower.free()
    var draws:Array=horizon.find_children("*","MeshInstance3D",true,false)
    var bounds:Dictionary={};var selected=0
    for draw:MeshInstance3D in draws:
        var identity=str(draw.get_meta("v2_city_horizon_building"));draw.visible=identity in IDS
        if not draw.visible:continue
        selected+=1
        check(draw.get_meta("v2_city_horizon_body_lod",false),"production complete-body replacement mounted")
        check(low_counts.has(str(draw.name)),"selected production part in replacement roster")
        metrics._check_cap_mapping(draw.mesh,true)
        var box=draw.global_transform*draw.get_aabb()
        bounds[identity]=(bounds[identity] as AABB).merge(box) if bounds.has(identity) else box
        var surface:Dictionary=RenderingServer.mesh_get_surface(draw.mesh.get_rid(),0)
        var lods:Array=surface.get("lods",[])
        var reduces=int(low_counts[str(draw.name)])*3<draw.mesh.surface_get_array_index_len(0)
        check(lods.size()==1 if reduces else lods.is_empty(),"source-authored replacement without automatic tail")
    check(selected==36 and selected==low_counts.size() and bounds.size()==4,"four requested buildings and36 production partitions execute")
    check(metrics.failures.is_empty(),"loaded native and replacement UVs/basis/derivatives pass original tolerances")
    var metric_failures=metrics.failures.duplicate();metrics.free()
    var seat_result=_check_seats(fixture,horizon)
    var catalog:Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://data/runtime_material_sets.json"))
    actual_materials=_actual_visible_abi(horizon,catalog)
    var material_rows=_industrial_materials(horizon)
    for name:String in material_rows:
        if name.split("__")[0] not in IDS:continue
        var row:Dictionary=material_rows[name];maps[name]=row
        check(not row.triplanar and row.maps.size()==3,"registered authored UV PBR binding "+name)
        check(int(row.texture_filter) in [BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS,BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC],"actual mip-capable filter "+name)
        var registered:Dictionary=catalog.materials[name.split("__")[-1]]
        for index in 3:
            var channel:String=["albedo","roughness","normal"][index]
            check(str(row.maps[channel].path)=="res://assets/building/textures/"+str(registered.files[index]),"loaded map is exact registered substance "+name+"/"+channel)
        for channel:String in ["albedo","roughness","normal"]:
            var texture:Dictionary=row.maps[channel]
            var dimensions:Array=texture.dimensions
            var required=int(floor(log(float(maxi(int(dimensions[0]),int(dimensions[1]))))/log(2.)))
            check(bool(texture.has_mipmaps) and int(texture.mipmap_count)==required,"complete actual loaded "+channel+" mip chain "+name)
    check(maps.size()==36,"all selected materials inspected")
    var environment=WorldEnvironment.new();var settings=Environment.new()
    settings.background_mode=Environment.BG_COLOR;settings.background_color=Color(.32,.38,.44)
    settings.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;settings.ambient_light_color=Color(.62,.72,.8);settings.ambient_light_energy=.7
    environment.environment=settings;add_child(environment)
    var sun=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-40,-25,0);sun.light_energy=2.8;sun.shadow_enabled=true;add_child(sun)
    var camera=Camera3D.new();camera.far=20000.;add_child(camera);camera.make_current()
    await RenderingServer.frame_post_draw
    var viewport=get_viewport();var threshold=viewport.mesh_lod_threshold;var taa=viewport.use_taa;var vsync=DisplayServer.window_get_vsync_mode();var cap=Engine.max_fps
    check(viewport.get_visible_rect().size==Vector2(3440,1440),"fullscreen native3440x1440 viewport")
    viewport.use_taa=false;DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED);Engine.max_fps=0
    RenderingServer.viewport_set_measure_render_time(viewport.get_viewport_rid(),true)
    for profile:Dictionary in fixture.buildings:
        var identity=str(profile.id)
        if identity not in IDS:continue
        for draw:MeshInstance3D in draws:draw.visible=str(draw.name).begins_with(identity+"__")
        view_direction=Vector3(.18,.12,1.).normalized() if str(profile.architecture.get("type",""))=="residential_front" else Vector3(1.,.12,.18).normalized()
        var box:AABB=bounds[identity];var center=box.get_center();camera.fov=75.
        camera.global_position=center+view_direction*box.size.length()*.5/sin(deg_to_rad(37.5))*1.25;camera.look_at(center)
        var family_rows:Array[Dictionary]=[]
        for spec:Dictionary in [{"id":"near","threshold":0.},{"id":"far","threshold":10000.},{"id":"natural","threshold":1.},{"id":"far_repeat","threshold":10000.},{"id":"near_repeat","threshold":0.}]:
            viewport.mesh_lod_threshold=float(spec.threshold)
            var warmup:Array[Dictionary]=[];var transition_previous=Time.get_ticks_usec()
            for frame in 12:
                await RenderingServer.frame_post_draw
                var transition_now=Time.get_ticks_usec();var transition_sample=_counters()
                transition_sample.merge({"wall_ms":(transition_now-transition_previous)/1000.,"viewport_cpu_ms":RenderingServer.viewport_get_measured_render_time_cpu(viewport.get_viewport_rid()),"viewport_gpu_ms":RenderingServer.viewport_get_measured_render_time_gpu(viewport.get_viewport_rid())})
                warmup.append(transition_sample);transition_previous=transition_now
            var samples:Array[Dictionary]=[];var previous=Time.get_ticks_usec()
            for frame in 90:
                await RenderingServer.frame_post_draw
                var now=Time.get_ticks_usec()
                var sample=_counters()
                sample.merge({"wall_ms":(now-previous)/1000.,"viewport_cpu_ms":RenderingServer.viewport_get_measured_render_time_cpu(viewport.get_viewport_rid()),"viewport_gpu_ms":RenderingServer.viewport_get_measured_render_time_gpu(viewport.get_viewport_rid())})
                samples.append(sample);previous=now
            var row:Dictionary={"building":identity,"id":spec.id,"threshold":spec.threshold,"warmup_samples":warmup,"samples":samples,"counters":_counters()}
            family_rows.append(row);observations.append(row)
            if str(spec.id) in ["near","far"]:check(viewport.get_texture().get_image().save_png(directory.path_join(identity+"_profile_"+str(spec.id)+".png"))==OK,"full-body image saved")
        check(int(family_rows[1].counters.visible_primitives)<int(family_rows[0].counters.visible_primitives),"visible full-body LOD index reduction "+identity)
        var natural_key=str(profile.wall_key);var primary_reduces=false;var alternative="";var alternative_indices=0
        for draw:MeshInstance3D in draws:
            if not str(draw.name).begins_with(identity+"__"):continue
            var part_surface:Dictionary=RenderingServer.mesh_get_surface(draw.mesh.get_rid(),0)
            if (part_surface.get("lods",[]) as Array).size()!=1:continue
            var key=str(draw.name).split("__")[-1]
            if key==natural_key:primary_reduces=true
            if draw.mesh.surface_get_array_index_len(0)>alternative_indices:
                alternative=key;alternative_indices=draw.mesh.surface_get_array_index_len(0)
        if not primary_reduces:natural_key=alternative
        check(not natural_key.is_empty(),"natural control selects an actually reducing production material part")
        transitions[identity]=await _profile_natural(horizon,camera,draws,identity,natural_key,directory)
        transitions[identity]["selection"]={"requested_wall_key":profile.wall_key,"actual_key":natural_key,"primary_material_reduces":primary_reduces,"reason":"Whole-building forced LOD already measured. Stable wall quads have no authored index reduction;natural material control selects an actual reducing body part."}
    check(transitions.size()==4,"all four natural material-body transitions execute")
    viewport.mesh_lod_threshold=threshold;viewport.use_taa=taa;DisplayServer.window_set_vsync_mode(vsync);Engine.max_fps=cap
    check(sources==_sources(horizon),"all imported rendering/test sources frozen")
    var viewport_settings={"resolution":str(viewport.get_visible_rect().size),"timed_taa":false,"timed_vsync":"disabled","timed_max_fps":0,"msaa":viewport.msaa_3d,"lighting":"fixed isolated bench;not composed campaign light"}
    var retired=weakref(horizon);horizon.free();camera.free();sun.free();environment.free();await get_tree().physics_frame
    check(retired.get_ref()==null,"production passive family retires")
    var record:Dictionary={"schema_version":2,"evidence_kind":"runtime_contract","selector":"v2","production_runtime":true,"scope":"Four isolated production-loader building bodies plus final visible material ABI on all17 complete-body horizon buildings/147partitions:imported UV/basis/derivatives,registered loaded PBR/mips,full-body forced LOD rendering andone material-body natural/narrow/return control each. No composed ground,player access,actors,saves,wholecity performance or artistic acceptance.","execution":{"completed":true,"exit_code":0 if failures.is_empty() else 1,"timed_out":false},"source":{"test_path":"game/"+get_script().resource_path.trim_prefix("res://"),"test_sha256":FileAccess.get_sha256(get_script().resource_path),"runtime_inputs_sha256":JSON.stringify(sources).sha256_text()},"contracts":{"actual_visible_material_abi":{"executed":actual_materials.size()==147,"passed":failures.is_empty()},"production_family_loader":{"executed":true,"passed":selected==36 and bounds.size()==4},"loaded_surface_mapping":{"executed":true,"passed":metric_failures.is_empty()},"loaded_pbr_mipmaps":{"executed":maps.size()==36,"passed":failures.is_empty()},"rendered_replacement_lods":{"executed":observations.size()==20,"passed":failures.is_empty()},"natural_material_transitions":{"executed":transitions.size()==4,"passed":failures.is_empty()},"collision_pane_and_roof_seats":{"executed":seat_result.pane_samples==462 and seat_result.roof_controls==41,"passed":failures.is_empty()}},"checks":checks,"failures":failures,"mapping_failures":metric_failures,"collision_seats":seat_result,"source_hashes":sources,"loaded_materials":maps,"actual_visible_materials":actual_materials,"observations":observations,"natural_transitions":transitions,"settings":viewport_settings}
    var file=FileAccess.open(directory.path_join("courts_loaded.runtime.json"),FileAccess.WRITE)
    if file==null:push_error("Cannot write family receipt");get_tree().quit(1);return
    file.store_string(JSON.stringify(record,"\t")+"\n");file.close()
    print("HOUSES LOADED FAMILY: ",checks," checks; ",failures.size()," failures;4 buildings;36 parts")
    get_tree().quit(0 if failures.is_empty() else 1)

func _seat_part(hit:Dictionary)->String:
    if hit.is_empty():return ""
    var draw=hit.collider.get_parent() as MeshInstance3D
    return str(draw.name) if draw!=null else ""

func _check_seats(fixture:Dictionary,horizon:Node3D)->Dictionary:
    var space=horizon.get_world_3d().direct_space_state;var panes=0;var roofs=0;var profiles:Dictionary={}
    for row:Dictionary in fixture.buildings:profiles[str(row.id)]=row
    for row:Dictionary in fixture.window_rows:
        if str(row.building) not in IDS:continue
        panes+=1;var p:Array=row.point;var n:Array=row.normal
        var point=Vector3(p[0],p[2],-p[1]);var normal=Vector3(n[0],n[2],-n[1]);var expected=point-normal*float(row.recess_m)
        var hit=space.intersect_ray(PhysicsRayQueryParameters3D.create(point+normal*.03,point-normal*.25,1))
        check(_seat_part(hit)==str(row.building)+"__mirror_aged" and hit.position.distance_to(expected)<.0001,"actual first-hit pane seating "+str(row.building))
    for row:Dictionary in fixture.parapet_contacts:
        if str(row.building) not in IDS:continue
        roofs+=1;var p:Array=row.point;var point=Vector3(p[0],p[2],-p[1])
        var query=PhysicsRayQueryParameters3D.create(point+Vector3.UP*.025,point-Vector3.UP*.025,1);query.hit_back_faces=false
        var hit=space.intersect_ray(query)
        check(_seat_part(hit)==str(row.building)+"__galvanized_roof" and hit.position.distance_to(point)<.0001,"actual roof top seating "+str(row))
        var profile:Dictionary=profiles[str(row.building)]
        if str(profile.architecture.type)=="residential_front":
            var support=point;support.y=float(profile.grade_datum_m)
            var heights:Array=profile.architecture.floor_heights_m
            for index in (heights.size() if str(profile.architecture.style)=="italianate_2109" else heights.size()-1):support.y+=float(heights[index])
            query=PhysicsRayQueryParameters3D.create(support+Vector3.UP*.025,support-Vector3.UP*.025,1);query.hit_back_faces=false;hit=space.intersect_ray(query)
            check(_seat_part(hit)==str(row.building)+"__"+str(row.wall_key) and hit.position.distance_to(support)<.0001,"actual receiving wall/sheathing below roof sheet "+str(row))
        else:
            query=PhysicsRayQueryParameters3D.create(point-Vector3.UP*.025,point+Vector3.UP*.025,1);query.hit_back_faces=false;hit=space.intersect_ray(query)
            check(_seat_part(hit)==str(row.building)+"__"+str(row.wall_key) and hit.position.distance_to(point)<.0001,"actual parapet/post underside meets roof "+str(row))
        var a:Array=row.outside_probe;var outside=Vector3(a[0],a[2],-a[1])
        query=PhysicsRayQueryParameters3D.create(outside+Vector3.UP*.025,outside-Vector3.UP*.025,1);query.hit_back_faces=false;hit=space.intersect_ray(query)
        check(_seat_part(hit)!=str(row.building)+"__galvanized_roof","outside control is not own structural roof seat")
    check(panes==462 and roofs==41,"nonempty exact462 pane/41roof controls for four buildings")
    return {"pane_samples":panes,"roof_controls":roofs,"frame":"actual unfiltered isolated production Horizon physics;no ground/player access claim"}

func _profile_natural(_city: Node3D,camera: Camera3D,draws: Array,identity: String,key: String,directory: String) -> Dictionary:
    var focus: MeshInstance3D=null
    for draw: MeshInstance3D in draws:
        draw.visible=str(draw.name)==identity+"__"+key
        if draw.visible:focus=draw
    check(focus!=null,"industrial body material exists for natural LOD: "+identity)
    if focus==null:return {}
    var arrays: Array=focus.mesh.surface_get_arrays(0)
    var points: PackedVector3Array=arrays[Mesh.ARRAY_VERTEX]
    var normals: PackedVector3Array=arrays[Mesh.ARRAY_NORMAL]
    var indices: PackedInt32Array=arrays[Mesh.ARRAY_INDEX]
    var direction:=view_direction
    var bounds:=focus.get_aabb()
    var center:=focus.global_transform*bounds.get_center()
    var best:=INF
    for i in range(0,indices.size(),3):
        var a: int=indices[i];var b: int=indices[i+1];var c: int=indices[i+2]
        var area: float=(points[b]-points[a]).cross(points[c]-points[a]).length()*.5
        var normal: Vector3=(focus.global_basis*(normals[a]+normals[b]+normals[c])).normalized()
        if area<.2 or normal.dot(direction)<.5:continue
        var local_point: Vector3=(points[a]+points[b]+points[c])/3.
        var distance_sq: float=local_point.distance_squared_to(bounds.get_center())
        if distance_sq<best:
            best=distance_sq
            center=focus.global_transform*local_point
    check(is_finite(best),"natural LOD aims at broad actual surface stock: "+identity)
    var radius:=0.
    for corner in 8:radius=maxf(radius,center.distance_to(focus.global_transform*bounds.get_endpoint(corner)))
    camera.fov=75.;get_viewport().mesh_lod_threshold=1.
    var start:=maxf(2.,radius/sin(deg_to_rad(camera.fov*.5))*1.25)
    var probes: Array[Dictionary]=[]
    var before: Dictionary={};var after: Dictionary={}
    for i in 12:
        var row:=await _profile_probe(camera,center,direction,start*pow(1.5,i))
        probes.append(row)
        check(int(row.draws)==1 and int(row.primitives)>0,"natural probe retains complete isolated body part: "+identity)
        if not before.is_empty() and int(row.primitives)<int(before.primitives):after=row;break
        before=row
    check(not after.is_empty(),"actual distance selects a replacement body LOD: "+identity)
    var images: Array[Dictionary]=[]
    var controls: Array[Dictionary]=[]
    if not after.is_empty():
        for i in 12:
            var row:=await _profile_probe(camera,center,direction,(float(before.distance_m)+float(after.distance_m))*.5)
            if int(row.primitives)==int(before.primitives):before=row
            else:after=row
        check(int(after.primitives)<int(before.primitives),"bisected natural bracket retains an actual index reduction: "+identity)
        for spec: Dictionary in [{"id":"before","distance":before.distance_m,"fov":75.,"minimum":before.primitives},{"id":"after","distance":after.distance_m,"fov":75.,"minimum":after.primitives},{"id":"narrow","distance":after.distance_m,"fov":5.,"minimum":before.primitives},{"id":"return","distance":before.distance_m,"fov":75.,"minimum":before.primitives}]:
            camera.fov=float(spec.fov)
            var row:=await _profile_probe(camera,center,direction,float(spec.distance))
            var expected:=int(row.primitives)>=int(spec.minimum) if str(spec.id)=="narrow" else int(row.primitives)==int(spec.minimum)
            check(int(row.draws)==1 and expected,"natural transition, narrow optical recovery and inward return: "+identity+"/"+str(spec.id))
            var frame:=get_viewport().get_texture().get_image()
            var pose:=camera.global_transform;var fov:=camera.fov;var optics:=_industrial_optics()
            focus.visible=false
            for tick in 4:await RenderingServer.frame_post_draw
            var negative:=get_viewport().get_texture().get_image()
            check(camera.global_transform.is_equal_approx(pose) and is_equal_approx(camera.fov,fov),"hidden-target optical control retains the same camera pose and FOV")
            check(optics==_industrial_optics(),"hidden-target optical control retains the same campaign clock and fixed bench lighting")
            var background:=negative.get_pixel(negative.get_width()/2,negative.get_height()/2)
            var corner:=negative.get_pixel(0,0)
            check(Vector3(background.r-corner.r,background.g-corner.g,background.b-corner.b).length()<.00001,"hidden-target optical control contains uniform fixed bench background")
            var control_file:=identity+"_natural_"+str(spec.id)+"_background.png"
            check(negative.save_png(directory.path_join(control_file))==OK,"same-pose hidden-target background control saved")
            controls.append({"id":spec.id,"file":control_file,"distance_m":spec.distance,"fov":fov,"background_rgb":[background.r,background.g,background.b],"optics":optics})
            focus.visible=true
            var pixel:=frame.get_pixel(frame.get_width()/2,frame.get_height()/2)
            var contrast:=Vector3(pixel.r-background.r,pixel.g-background.g,pixel.b-background.b).length()
            check(contrast>.02,"physical structural stock remains at image center: "+identity+"/"+str(spec.id))
            row["file"]=identity+"_natural_"+str(spec.id)+".png";row["fov"]=camera.fov;row["center_contrast"]=contrast
            check(frame.save_png(directory.path_join(str(row.file)))==OK,"natural industrial image saved")
            images.append(row)
    return {"part":str(focus.name),"scope":"One whole material body part, default pixel threshold1, bisected first observed distance reduction, narrow-FOV recovery and inward return. Same-pose hidden-target background controls use fixed bench lighting with no weather or campaign clock. Not a whole-building/world LOD or artistic acceptance.","before":before,"after":after,"probes":probes,"images":images,"hidden_target_controls":controls}

func _actual_visible_abi(horizon:Node3D,catalog:Dictionary)->Dictionary:
    var result:Dictionary={};var roof_recipes:Dictionary={}
    var profiles:Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://data/orison_v2/owner_finish_profiles.json"))
    for group:Dictionary in profiles.groups:
        if str(group.id)=="roof":
            for recipe:Dictionary in group.recipes:roof_recipes[str(recipe.source_key)]=recipe
    for draw:MeshInstance3D in horizon.find_children("*","MeshInstance3D",true,false):
        if not draw.get_meta("v2_city_horizon_body_lod",false):continue
        var identity=str(draw.name);var source_key=identity.split("__")[-1];var expected_key=source_key
        var normal_expected=.12 if source_key=="mirror_aged" else .55
        if source_key=="galvanized_roof":
            var recipe:Dictionary=roof_recipes.get(source_key,{})
            expected_key=str(recipe.get("catalog",source_key));normal_expected=float(recipe.get("normal",normal_expected))
        var material:Material=draw.material_override;var textures:Dictionary={};var scale=Vector2.ZERO;var actual_normal=0.;var shader="";var effective_uv_mode=0;var explicit_uv=false
        if material is StandardMaterial3D:
            var stock=material as StandardMaterial3D
            check(not stock.uv1_triplanar,"actual visible material uses mesh UV "+identity)
            check(stock.normal_enabled,"actual visible normal enabled "+identity)
            check(int(stock.texture_filter) in [BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS,BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC],"actual visible mip-capable filter "+identity)
            scale=Vector2(stock.uv1_scale.x,stock.uv1_scale.y);actual_normal=stock.normal_scale
            textures={"albedo":stock.albedo_texture,"roughness":stock.roughness_texture,"normal":stock.normal_texture}
        elif material is ShaderMaterial:
            var shader_material=material as ShaderMaterial
            shader=shader_material.shader.resource_path
            check(shader=="res://shaders/orison_surface.gdshader","actual visible shared roof shader "+identity)
            var uv_mode:Variant=shader_material.get_shader_parameter("uv_mode")
            var explicit_uv_mode=uv_mode!=null
            if uv_mode==null:uv_mode=RenderingServer.shader_get_parameter_default(shader_material.shader.get_rid(),"uv_mode")
            check(uv_mode!=null,"actual renderer supplies effective roof UV mode "+identity)
            if uv_mode==null:continue
            check(int(uv_mode)==0,"actual visible roof mesh UV "+identity)
            effective_uv_mode=int(uv_mode);explicit_uv=explicit_uv_mode
            check(bool(shader_material.get_shader_parameter("has_normal_tex")) and bool(shader_material.get_shader_parameter("has_rough_tex")),"actual visible shader data maps enabled "+identity)
            scale=shader_material.get_shader_parameter("mesh_uv_scale");actual_normal=float(shader_material.get_shader_parameter("normal_scale"))
            textures={"albedo":shader_material.get_shader_parameter("albedo_tex"),"roughness":shader_material.get_shader_parameter("rough_tex"),"normal":shader_material.get_shader_parameter("normal_tex")}
        else:check(false,"actual visible material type supported "+identity);continue
        var registered:Dictionary=catalog.materials[expected_key];var expected_scale=Vector2.ONE/float(registered.meters_per_tile)
        check(scale.distance_to(expected_scale)<.000001,"actual visible physical texture scale "+identity)
        check(abs(actual_normal-normal_expected)<.000001,"actual visible declared normal strength "+identity)
        var maps_record:Dictionary={}
        for index in 3:
            var channel:String=["albedo","roughness","normal"][index];var texture:Texture2D=textures[channel]
            check(texture!=null,"actual visible registered texture exists "+identity+"/"+channel)
            if texture==null:continue
            check(texture.resource_path=="res://assets/building/textures/"+str(registered.files[index]),"actual visible registered texture identity "+identity+"/"+channel)
            var pixels=texture.get_image();var required=int(floor(log(float(maxi(pixels.get_width(),pixels.get_height())))/log(2.)))
            check(pixels.has_mipmaps() and pixels.get_mipmap_count()==required,"actual visible complete loaded mips "+identity+"/"+channel)
            maps_record[channel]={"path":texture.resource_path,"dimensions":[pixels.get_width(),pixels.get_height()],"has_mipmaps":pixels.has_mipmaps(),"mipmap_count":pixels.get_mipmap_count()}
        result[identity]={"source_key":source_key,"actual_catalog_key":expected_key,"material_class":material.get_class(),"shader":shader,"effective_uv_mode":effective_uv_mode,"uv_mode_was_explicit":explicit_uv,"texture_filter":(material as StandardMaterial3D).texture_filter if material is StandardMaterial3D else "bound shader sampler hints","uv_scale":[scale.x,scale.y],"meters_per_tile":registered.meters_per_tile,"normal_scale":actual_normal,"maps":maps_record}
    check(result.size()==147,"all17 complete-body buildings/147 final material partitions inspected")
    return result
