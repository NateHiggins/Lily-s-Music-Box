from pathlib import Path
out=Path(__file__).parent
for old,new in [('run_native_build_01.py','run_native_build_02.py'),('verify_export_uv_01.py','verify_export_uv_02.py'),('run_geometry_01.py','run_geometry_02.py'),('check_geometry_01.py','check_geometry_02.py')]:
    code=(out/old).read_text().replace('_01','_02')
    (out/new).write_text(code,encoding='utf-8',newline='\n')
# The newassertion must reject the original basement head,not onlypass itself.
ceiling=.9;head=ceiling-.17
assert head+.245>ceiling and abs(head+.245-ceiling-.075)<1e-9
assert head+.145<=ceiling-.015
print('Originalbasement75mmoverrun reproduced;new25mmbedseat fits')
