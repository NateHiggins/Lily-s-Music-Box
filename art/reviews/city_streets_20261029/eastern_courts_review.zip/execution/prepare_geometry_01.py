from pathlib import Path
out=Path(__file__).parent;prior=out.parent/'eastern_houses_01'
code=(prior/'check_geometry_02.py').read_text().replace('from city_residential_architecture import EasternHouses','from city_residential_architecture import CourtApartments').replace('EasternHouses(row,','CourtApartments(row,').replace('geometry_02.json','geometry_01.json')
code=code.replace("ids=[f'HORIZON_NEAR_2_2_P0R{i}' for i in range(3)]","ids=['HORIZON_NEAR_2_1_P1','HORIZON_NEAR_2_2_P1','HORIZON_NEAR_2_2_P2']")
marker="        levels.append(dict(lower=lower,"
insert='''        # Clear exterior courts must have their own pavement and no roof
        # across the void. The short facade apron isnot a courtyard probe.
        paving=[]
        for x,y,X,Y in row['architecture']['court_paving_m']:
            if X-x<3.0 or Y-y<3.0:continue
            p=Vector(((x+X)/2,-(y+Y)/2,0.))
            hit,n,index,d=bvh.ray_cast(p+Vector((0,0,.15)),Vector((0,0,-1)),.30)
            assert hit is not None and abs(hit.z)<.0001 and owners[index]=='concrete',(identity,lower,'court pavement',list(p),owners[index] if index is not None else None)
            hit,n,index,d=roof.ray_cast(p+Vector((0,0,row['height_m']+.5)),Vector((0,0,-1)),row['height_m']+1.)
            assert hit is None,(identity,lower,'roof covers court',list(p))
            paving.append(list(p))
        assert paving,(identity,'nonempty actual court controls')
'''
assert code.count(marker)==1;code=code.replace(marker,insert+marker).replace("parts=sorted(buf)))","parts=sorted(buf),court_controls=paving))")
(out/'check_geometry_01.py').write_text(code,encoding='utf-8',newline='\n')
runner=(prior/'run_geometry_02.py').read_text().replace('_02','_01').replace('timeout=60','timeout=120')
(out/'run_geometry_01.py').write_text(runner,encoding='utf-8',newline='\n')
