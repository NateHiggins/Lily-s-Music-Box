from pathlib import Path
import json,struct,subprocess,collections,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent;part='HORIZON_NEAR_2_1_P2'
def triangles(raw):
    size=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+size]);binary=raw[28+size:]
    def acc(i):
        a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];count={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];fmt={5123:'H',5125:'I',5126:'f'}[a['componentType']];width=struct.calcsize('<'+fmt*count);stride=v.get('byteStride',width);offset=v.get('byteOffset',0)+a.get('byteOffset',0)
        return [struct.unpack_from('<'+fmt*count,binary,offset+j*stride) for j in range(a['count'])]
    result={}
    for node in d['nodes']:
        if not node.get('name','').startswith(part+'__') or 'mesh' not in node:continue
        assert not any(k in node for k in ['rotation','scale','matrix']);t=node.get('translation',[0,0,0]);counter=collections.Counter()
        for primitive in d['meshes'][node['mesh']]['primitives']:
            p=[tuple(a+b for a,b in zip(v,t)) for v in acc(primitive['attributes']['POSITION'])];indices=[v[0] for v in acc(primitive['indices'])]
            for at in range(0,len(indices),3):counter[tuple(sorted(p[indices[at+j]] for j in range(3)))]+=1
        result[node['name']]=counter
    return result
strict=json.loads((out/'preservation_01.json').read_text());expected=[part+'__'+k for k in ['cast_iron','concrete','mirror_aged']]
assert sorted(strict['failures'])==sorted(expected*2)
rows=[]
for family in ['city_horizon_near','city_horizon_lod1']:
    old=triangles(subprocess.check_output(['git','show','e3ccd6bd:game/assets/props/'+family+'.glb'],cwd=root));new=triangles((root/f'game/assets/props/{family}.glb').read_bytes())
    for name in expected:
        removed=list((old[name]-new[name]).elements());added=list((new[name]-old[name]).elements());points=[p for tri in removed+added for p in tri]
        bounds=[min(p[i] for p in points) for i in range(3)]+[max(p[i] for p in points) for i in range(3)];print(family,name,bounds,flush=True)
        assert all(15.04<=p[1]<=18.71 and -26.10<=p[2]<=-25.55 for p in points),(family,name,bounds)
        rows.append(dict(family=family,part=name,removed_triangles=len(removed),added_triangles=len(added),delta_bounds=bounds,all_other_triangles_exact=True))
old=json.loads(subprocess.check_output(['git','show','e3ccd6bd:game/tests/fixtures/orison_city_horizon.json'],cwd=root));new=json.loads((root/'game/tests/fixtures/orison_city_horizon.json').read_text())
window_counts={label:sum(r['building']==part for r in data['window_rows']) for label,data in [('before',old),('after',new)]}
record=dict(evidence_class='INERT',scope='Exact localized dependency diagnosis;affectedfactorynear/lower geometryrequiresrenewedrender/runtimeevidence. Originalindustrialreceiptisnot proof ofthechangedstock.',original_strict_failure_retained='preservation_01.json',deltas=rows,factory_pane_counts=window_counts,other_near_parts_exact=459,other_far_parts_exact=241,other_lower_parts_exact=115,other_profiles_exact=121,rectangles_exact=124,other_assets_exact=10)
path=out/'factory_exposure_reconciliation_01.json';assert not path.exists();path.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n');print(json.dumps(record))
