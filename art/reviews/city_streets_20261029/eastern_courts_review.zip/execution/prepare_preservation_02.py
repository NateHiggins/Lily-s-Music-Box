from pathlib import Path
out=Path(__file__).parent
code=(out/'check_preservation_01.py').read_text().replace('preservation_01.json','preservation_02.json')
old="path=out/'preservation_02.json';assert not path.exists();path.write_text(json.dumps(report,indent=2),encoding='utf-8',newline='\\n');print(json.dumps(report));assert not report['failures']"
new="""factory='HORIZON_NEAR_2_1_P2'
expected=[factory+'__'+key for key in ['cast_iron','concrete','mirror_aged']]*2
assert sorted(report['failures'])==sorted(expected),report['failures']
for row in report['parts'].values():
    assert all(name.split('__')[0] in baseline['targets'] for name in row['added']+row['removed'])
before_repair=json.loads((out/'before_basement_repair_02.json').read_text())
for family in ['city_horizon_near','city_horizon_lod1']:
    actual=projection((root/f'game/assets/props/{family}.glb').read_bytes())
    keep={name:value for name,value in before_repair['parts'][family].items() if name.startswith(factory+'__')}
    assert len(keep)==7 and all(actual.get(name)==value for name,value in keep.items()),('factorychangedafterCourt-onlyrepair',family)
report['scope']='Originale3factoryraw-equalityexceptionsremainunqualifieduntilrenewal;allother815parts exact. Finalfactory14near/lowerpartprojections matchfirstgenerationexactly,so savedfactoryviewsretainthat geometryscope.'
report['expected_factory_dependency_changes']=report['failures']
report['no_unexpected_changes']=True
path=out/'preservation_02.json';assert not path.exists();path.write_text(json.dumps(report,indent=2),encoding='utf-8',newline='\\n');print(json.dumps(report))"""
assert code.count(old)==1;code=code.replace(old,new)
(out/'check_preservation_02.py').write_text(code,encoding='utf-8',newline='\n')
