from pathlib import Path
import json,hashlib,ast,struct
root=Path('C:/ov/city');out=Path(__file__).parent
reader=out.parent/'bodega_frontage_reconciliation_01/check_preservation_01.py';tree=ast.parse(reader.read_text(encoding='utf-8-sig'));exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(reader),'exec'))
record=dict(evidence_class='INERT',scope='Frozen first-generation fingerprints beforeboundedbasementrepair;not acceptance.',parts={f:projection((root/f'game/assets/props/{f}.glb').read_bytes()) for f in ['city_horizon_near','city_horizon_far','city_horizon_lod1']},sources={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ['art/blender/scripts/build_city_horizon.py','art/blender/scripts/city_residential_architecture.py','art/data/city_horizon/source_plan.json']},saved_images={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (out/'native_review_01').glob('*.png')},assets={f'game/assets/props/{f}.glb':hashlib.sha256((root/f'game/assets/props/{f}.glb').read_bytes()).hexdigest() for f in ['city_horizon_near','city_horizon_far','city_horizon_lod1']})
path=out/'before_basement_repair_02.json';assert not path.exists();path.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print('First-generation sources/fingerprints/savedimages retained beforeanyproductreplacement')
