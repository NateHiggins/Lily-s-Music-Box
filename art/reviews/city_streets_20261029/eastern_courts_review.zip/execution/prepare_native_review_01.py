from pathlib import Path
out=Path(__file__).parent;prior=out.parent/'eastern_houses_01'
code=(prior/'review_native_01.py').read_text()
start=code.index('IDS=');end=code.index('\nprofiles=',start)
code=code[:start]+"IDS=['HORIZON_NEAR_2_1_P1','HORIZON_NEAR_2_2_P1','HORIZON_NEAR_2_2_P2','HORIZON_NEAR_2_1_P2']"+code[end:]
start=code.index('    views=[]');end=code.index('    for label,identities',start)
code=code[:start]+'''    views=[]
    for identity in IDS:
        row=profiles[identity];a,b,c,d=row['rect'];height=row['height_m'];middle=(b+d)/2
        views.append((identity,[identity],(c+22,-middle-18,height*1.15),((a+c)/2,-middle,height*.48),32.,(1100,900)))
        if family=='city_horizon_near':
            if identity==IDS[0]:eye=(c-2.6,-middle,1.7);aim=(c-9.0,-middle,2.0)
            elif identity==IDS[1]:eye=(a+.7,-b-2.4,1.7);aim=(c-9.5,-b-2.4,2.0)
            elif identity==IDS[2]:eye=(c-1.7,-middle,1.7);aim=(a+12.0,-middle,2.0)
            else:eye=(c+11,-b+9,18.5);aim=((a+c)/2,-b,16.5)
            label=identity+('_court' if identity!=IDS[3] else '_detail')
            views.append((label,[identity],eye,aim,14.,(1100,900)))
    views.append(('cedar_factory_context',[IDS[0],IDS[3]],(-126.,58.,29.),(-160.,26.,8.),52.,(1400,950)))
    views.append(('plymouth_willow_context',IDS[1:3],(-125.,-22.,28.),(-160.,-55.,8.),58.,(1400,950)))
''' +code[end:]
code=code.replace("detail=label.endswith('_detail');framed=None","detail=label.endswith('_detail') or label.endswith('_court');framed=None")
code=code.replace("camera.data.type='ORTHO';camera.data.ortho_scale=scale;scene.render.resolution_x,scene.render.resolution_y=res","camera.data.type='PERSP' if label.endswith('_court') else 'ORTHO';camera.data.lens=22.;camera.data.ortho_scale=scale;scene.render.resolution_x,scene.render.resolution_y=res")
code=code.replace('len(contacts)==32 and len(captures)==11','len(contacts)==82 and len(captures)==16')
(out/'review_native_01.py').write_text(code,encoding='utf-8',newline='\n')
(out/'run_native_review_01.py').write_text((prior/'run_native_review_01.py').read_text(),encoding='utf-8',newline='\n')
