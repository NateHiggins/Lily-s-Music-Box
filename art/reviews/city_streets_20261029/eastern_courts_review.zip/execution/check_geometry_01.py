from pathlib import Path
import sys,json,collections,hashlib,bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree
root=Path('C:/ov/city');out=Path(__file__).parent;sys.path.insert(0,str(root/'art/blender/scripts'))
from city_residential_architecture import CourtApartments
plan=json.loads((root/'art/data/city_horizon/source_plan.json').read_text());ids=['HORIZON_NEAR_2_1_P1','HORIZON_NEAR_2_2_P1','HORIZON_NEAR_2_2_P2'];results=[]
for identity in ids:
    row=next(r.copy() for r in plan['buildings'] if r['id']==identity);row['grade_datum_m']=0.;levels=[]
    for lower in [False,True]:
        buf=collections.defaultdict(lambda:([],[]))
        def emit(owner,key,vertices,faces):
            vv,ff=buf[key];start=len(vv);vv.extend(vertices);ff.extend(tuple(start+i for i in face) for face in faces)
        result=CourtApartments(row,emit,[r for r in plan['buildings'] if r['id']!=identity],lower).build()
        vertices=[];faces=[];owners=[]
        for key,(vv,ff) in buf.items():
            start=len(vertices);vertices.extend(vv);faces.extend(tuple(start+i for i in face) for face in ff);owners.extend([key]*len(ff))
        bvh=BVHTree.FromPolygons(vertices,faces,all_triangles=False)
        for w in result['windows']:
            p=Vector(w['point']);n=Vector(w['normal']);hit,normal,index,d=bvh.ray_cast(p+n*.05,-n,.30)
            assert hit is not None and owners[index]=='mirror_aged' and (hit-(p-n*.17)).length<.0001,(identity,lower,w,owners[index] if index is not None else None)
        vv,ff=buf['galvanized_roof'];roof=BVHTree.FromPolygons(vv,ff,all_triangles=False)
        for seat in result['bearings']:
            p=Vector(seat['point']);hit,n,index,d=roof.ray_cast(p+Vector((0,0,.025)),Vector((0,0,-1)),.05)
            assert hit is not None and (hit-p).length<.0001,(identity,lower,'roof',seat)
            candidates=[]
            for key,(vv,ff) in buf.items():
                tree=BVHTree.FromPolygons(vv,ff,all_triangles=False)
                hit,n,index,d=tree.ray_cast(p-Vector((0,0,.025)),Vector((0,0,1)),.05)
                if hit is not None and n.z<0:candidates.append((d,key,hit))
            assert candidates,(identity,lower,'no front-facing receiver',seat)
            d,key,hit=min(candidates,key=lambda r:r[0])
            assert key==seat['wall_key'] and (hit-p).length<.0001,(identity,lower,'actual front-facing receiving underside',seat,key,list(hit))
            p=Vector(seat['outside_probe']);hit,n,index,d=roof.ray_cast(p+Vector((0,0,.025)),Vector((0,0,-1)),.05)
            assert hit is None,(identity,lower,'outside',seat)
        # Clear exterior courts must have their own pavement and no roof
        # across the void. The short facade apron isnot a courtyard probe.
        paving=[]
        for x,y,X,Y in row['architecture']['court_paving_m']:
            if X-x<3.0 or Y-y<3.0:continue
            p=Vector(((x+X)/2,-(y+Y)/2,0.))
            hit,n,index,d=bvh.ray_cast(p+Vector((0,0,.15)),Vector((0,0,-1)),.30)
            assert hit is not None and abs(hit.z)<.0001 and owners[index]=='concrete',(identity,lower,'court pavement',list(p),owners[index] if index is not None else None)
            hit,n,index,d=roof.ray_cast(p+Vector((0,0,row['height_m']+.5)),Vector((0,0,-1)),row['height_m']+1.)
            assert hit is None,(identity,lower,'roof covers court',list(p))
            paving.append(list(p))
        assert paving,(identity,'nonempty actual court controls')
        levels.append(dict(lower=lower,triangles=sum(len(f)-2 for f in faces),stocks=result['closed_stocks'],panes=len(result['windows']),roof_seats=len(result['bearings']),entries=result['entries'],parts=sorted(buf),court_controls=paving))
    assert levels[1]['triangles']<levels[0]['triangles'] and levels[0]['panes']==levels[1]['panes'] and levels[0]['entries']==levels[1]['entries']
    results.append(dict(id=identity,style=row['architecture']['style'],levels=levels))
path=out/'geometry_01.json';assert not path.exists();path.write_text(json.dumps(dict(evidence_class='INERT',scope='Unsaved native source geometry/pane/roof/first receiving controls only;not final export,UV,rendered review,Godot/access orartistic acceptance.',results=results,source_bindings={p:hashlib.sha256((root/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in ['art/blender/scripts/city_residential_architecture.py','art/blender/scripts/city_industrial_architecture.py','art/data/city_horizon/source_plan.json']}),indent=2),encoding='utf-8',newline='\n');print(json.dumps(results),flush=True)
