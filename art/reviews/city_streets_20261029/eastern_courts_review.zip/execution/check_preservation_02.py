from pathlib import Path
import ast,json,struct,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent
reader=out.parent/'bodega_frontage_reconciliation_01/check_preservation_01.py'
tree=ast.parse(reader.read_text(encoding='utf-8-sig'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(reader),'exec'))
baseline=json.loads((out/'baseline_01.json').read_text());report=dict(evidence_class='INERT',parts={},other_assets={},failures=[])
for family,old in baseline['parts'].items():
    new=projection((root/f'game/assets/props/{family}.glb').read_bytes())
    keep={k:v for k,v in old.items() if k.split('__')[0] not in baseline['targets']}
    changed=[k for k,v in keep.items() if new.get(k)!=v]
    added=sorted(set(new)-set(old));removed=sorted(set(old)-set(new))
    report.setdefault('changed_target_parts',{})[family]=[k for k,v in old.items() if new.get(k)!=v]
    report['parts'][family]=dict(preserved=len(keep)-len(changed),changed=changed,added=added,removed=removed)
    report['failures'].extend(changed)
for path,expected in baseline['other_assets'].items():
    actual=hashlib.sha256((root/path).read_bytes()).hexdigest();report['other_assets'][path]=actual
    if actual!=expected:report['failures'].append(path)
plan=json.loads((root/'art/data/city_horizon/source_plan.json').read_text())
old={r['id']:r for r in baseline['profiles']};new={r['id']:r for r in plan['buildings']}
assert set(new)==set(old)
assert all(new[k]['rect']==v['rect'] for k,v in old.items())
assert all(new[k]==v for k,v in old.items() if k not in baseline['targets'])
report['preserved_other_profiles']=len(old)-len(baseline['targets']);report['preserved_parcel_rectangles']=len(old)
factory='HORIZON_NEAR_2_1_P2'
expected=[factory+'__'+key for key in ['cast_iron','concrete','mirror_aged']]*2
assert sorted(report['failures'])==sorted(expected),report['failures']
for row in report['parts'].values():
    assert all(name.split('__')[0] in baseline['targets'] for name in row['added']+row['removed'])
before_repair=json.loads((out/'before_basement_repair_02.json').read_text())
for family in ['city_horizon_near','city_horizon_lod1']:
    actual=projection((root/f'game/assets/props/{family}.glb').read_bytes())
    keep={name:value for name,value in before_repair['parts'][family].items() if name.startswith(factory+'__')}
    assert len(keep)==7 and all(actual.get(name)==value for name,value in keep.items()),('factorychangedafterCourt-onlyrepair',family)
report['scope']='Originale3factoryraw-equalityexceptionsremainunqualifieduntilrenewal;allother815parts exact. Finalfactory14near/lowerpartprojections matchfirstgenerationexactly,so savedfactoryviewsretainthat geometryscope.'
report['expected_factory_dependency_changes']=report['failures']
report['no_unexpected_changes']=True
path=out/'preservation_02.json';assert not path.exists();path.write_text(json.dumps(report,indent=2),encoding='utf-8',newline='\n');print(json.dumps(report))
