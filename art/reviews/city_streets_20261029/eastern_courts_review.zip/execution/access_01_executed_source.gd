extends "res://tests/v2_city_horizon_bench.gd"
## Production capsule and normal input; independent court starts avoid long travel.
var routes:Array[Dictionary]=[]

func _ready()->void:call_deferred("run_access")

func run_access()->void:
    RealityState.persistence_enabled=false
    RealityState.reset_campaign_for_tests()
    CampaignTime.set_frozen_for_tests(true)
    var directory=OS.get_environment("SHOT_DIR")
    check(not directory.is_empty() and DisplayServer.get_name()!="headless","graphical output supplied")
    if directory.is_empty() or DisplayServer.get_name()=="headless":get_tree().quit(1);return
    DirAccess.make_dir_recursive_absolute(directory)
    var fixture:Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://tests/fixtures/orison_city_horizon.json"))
    var horizon=Horizon.new();add_child(horizon)
    var ground=preload("res://scripts/building/orison_v2_ground.gd").new();add_child(ground)
    var environment=WorldEnvironment.new();var settings=Environment.new()
    settings.background_mode=Environment.BG_COLOR;settings.background_color=Color(.32,.38,.44)
    settings.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;settings.ambient_light_color=Color(.62,.72,.8);settings.ambient_light_energy=.7
    environment.environment=settings;add_child(environment)
    var sun=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-40,-25,0);sun.light_energy=2.8;sun.shadow_enabled=true;add_child(sun)
    await get_tree().physics_frame;await get_tree().physics_frame
    check(get_viewport().get_visible_rect().size==Vector2(3440,1440),"native fullscreen viewport")
    var sources=_industrial_entry_sources(horizon,ground)
    sources[get_script().resource_path]=_profile_sha(get_script().resource_path)
    var profiles:Dictionary={}
    for row:Dictionary in fixture.buildings:profiles[str(row.id)]=row
    for identity:String in ["HORIZON_NEAR_2_1_P1","HORIZON_NEAR_2_2_P1","HORIZON_NEAR_2_2_P2"]:
        var row:Dictionary=profiles[identity];var style=str(row.architecture.style);var datum=float(row.grade_datum_m)
        var index=0
        for paving:Array in row.architecture.court_paving_m:
            var lo=float(paving[0]);var bottom=float(paving[1]);var hi=float(paving[2]);var top=float(paving[3])
            if hi-lo<3. or top-bottom<3.:continue
            var front_court=style=="cedar_8301" or (style=="willow_3535" and lo>-165.)
            var start=hi+.8 if front_court else lo+.45
            var finish=lo+2.6 if front_court else hi-.65
            var corridor_z=(bottom+top)*.5
            await _court_roundtrip(horizon,identity,index,start,finish,corridor_z,datum,directory)
            index+=1
    var passage_first=failures.size();var passage_checks=checks
    await _industrial_passage(horizon,ground,fixture,directory)
    var passage={"executed":true,"checks":checks-passage_checks,"passed":failures.size()==passage_first}
    var final_sources=_industrial_entry_sources(horizon,ground)
    final_sources[get_script().resource_path]=_profile_sha(get_script().resource_path)
    check(sources==final_sources,"all production inputs remain frozen")
    check(routes.size()==5,"all five independent courts execute normal-input roundtrips")
    var record={"schema_version":2,"evidence_kind":"runtime_contract","selector":"v2","production_runtime":true,"scope":"Five independently placed exterior court roundtrips plus renewed factory passage using actual production Horizon/Ground/PlayerController, standing capsule, gravity and both step guards. Normal input after each independent start, no rescue or synthetic floor. Fixed diagnostic lighting. Not a continuous campaign route, composed actors/traffic/save test, performance qualification or artistic acceptance.","execution":{"completed":true,"exit_code":0 if failures.is_empty() else 1,"timed_out":false},"source":{"test_path":"game/"+get_script().resource_path.trim_prefix("res://"),"test_sha256":FileAccess.get_sha256(get_script().resource_path),"runtime_inputs_sha256":JSON.stringify(sources).sha256_text()},"contracts":{"court_controller_roundtrips":{"executed":routes.size()==5,"passed":failures.is_empty()},"renewed_factory_passage":passage},"checks":checks,"failures":failures,"routes":routes,"source_hashes":sources}
    var file=FileAccess.open(directory.path_join("courts_access.runtime.json"),FileAccess.WRITE)
    check(file!=null,"access receipt opens")
    if file!=null:file.store_string(JSON.stringify(record,"\t")+"\n");file.close()
    print("COURTS ACCESS: ",checks," checks; ",failures.size()," failures;5 courts + factory passage")
    get_tree().quit(0 if failures.is_empty() else 1)

func _court_roundtrip(horizon:Node3D,identity:String,index:int,start:float,finish:float,corridor_z:float,datum:float,directory:String)->void:
    var first=failures.size();var samples:Array=[];var stages:Array=[]
    var player=PlayerController.new();player.position=Vector3(start,datum+.03,corridor_z);add_child(player)
    player.look_at(player.position+Vector3(signf(finish-start),0,0),Vector3.UP)
    player.set_lamp_enabled(false);player.camera.make_current()
    for frame in 30:await get_tree().physics_frame
    check(player.is_on_floor() and absf(player.position.y-datum)<.002,"court start physically settles on authored paving")
    check(is_equal_approx(player._capsule.height,1.524) and is_equal_approx(player._capsule.radius,.33) and is_equal_approx(player.camera.position.y,1.41),"unmodified standing capsule and eye")
    for target:float in [finish,start]:
        await _drive_industrial(player,target,samples)
        check(player.is_on_floor() and absf(player.position.y-datum)<.002,"court endpoint actual floor support")
        check(absf(player.position.z-corridor_z)<.01,"court full capsule stays on intended centerline")
        var query=PhysicsRayQueryParameters3D.create(player.global_position+Vector3.UP*.05,player.global_position-Vector3.UP*.15,1)
        query.exclude=[player.get_rid()]
        var hit=horizon.get_world_3d().direct_space_state.intersect_ray(query)
        check(_seat_part(hit)==identity+"__concrete","actual first receiving surface is own court paving")
        for frame in 2:await RenderingServer.frame_post_draw
        var image=identity+"_court_"+str(index)+"_"+str(stages.size())+".png"
        check(get_viewport().get_texture().get_image().save_png(directory.path_join(image))==OK,"actual standing court eye saved")
        stages.append({"position":[player.position.x,player.position.y,player.position.z],"file":image})
    var bad_floor=0;var bad_lateral=0;var used_noclip=false
    for sample:Dictionary in samples:
        if not bool(sample.on_floor) or absf(float(sample.position[1])-datum)>.002:bad_floor+=1
        if absf(float(sample.position[2])-corridor_z)>.01:bad_lateral+=1
        used_noclip=used_noclip or bool(sample.noclip)
    check(not samples.is_empty() and bad_floor==0,"all court movement samples retain continuous actual support")
    check(bad_lateral==0 and not used_noclip,"court movement preserves corridor and collision")
    check(not player.noclip and not player._profile_disable_step_guard and not player._profile_disable_step_up,"court retains production gravity and both step guards")
    routes.append({"building":identity,"court":index,"scope":"One initial placement, normal forward/back input thereafter.","stages":stages,"movement_samples":samples,"bad_floor_samples":bad_floor,"bad_lateral_samples":bad_lateral,"passed":failures.size()==first})
    player.free()
