from pathlib import Path
import json,hashlib,zipfile
root=Path('C:/ov/city');out=Path(__file__).parent
records={}
for name in ['bench','access']:
    path=out/(f'{name}_01' if name=='bench' else 'access_02')/('courts_loaded.runtime.json' if name=='bench' else 'courts_access.runtime.json')
    record=json.loads(path.read_text(encoding='utf-8'))
    assert record['schema_version']==2 and record['evidence_kind']=='runtime_contract'
    assert record['execution']==dict(completed=True,exit_code=0,timed_out=False) and not record['failures']
    assert all(c['executed'] and c['passed'] for c in record['contracts'].values())
    records[name]=record
assert len(records['bench']['actual_visible_materials'])==147
assert len(records['bench']['observations'])==20 and len(records['access']['routes'])==5
assert (out/'loaded_inspection_01.json').is_file() and (out/'native_inspection_03.json').is_file()
stored={};runtime_bindings={}
for p in sorted(out.rglob('*')):
    if p.is_file() and p.suffix in ['.py','.json','.log','.stderr','.png','.gd','.tscn','.txt'] and '__pycache__' not in p.parts:
        stored['execution/'+p.relative_to(out).as_posix()]=p.read_bytes()
for record in records.values():
    for resource,expected in record['source_hashes'].items():
        relative='game/'+resource.removeprefix('res://');p=root/relative;raw=p.read_bytes()
        normal=p.suffix in ['.gd','.json','.gdshader','.gdshaderinc','.import']
        check=raw.replace(b'\r\n',b'\n') if normal else raw
        assert hashlib.sha256(check).hexdigest()==expected,relative
        binding=dict(bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),test_sha256=expected,lf_normalized=normal)
        assert relative not in runtime_bindings or runtime_bindings[relative]==binding
        runtime_bindings[relative]=binding
        if p.suffix not in ['.png','.glb']:stored['final/'+relative]=raw
for relative in ['art/blender/scripts/build_city_horizon.py','art/blender/scripts/city_residential_architecture.py','art/blender/scripts/city_industrial_architecture.py','art/data/city_horizon/source_plan.json','game/tmp/city_courts_01/Bench01.tscn','game/tmp/city_courts_01/Access02.tscn']:
    stored['final/'+relative]=(root/relative).read_bytes()
assets=['art/blender/city_horizon_near.blend','art/blender/city_horizon_far.blend','art/blender/city_horizon_lod1.blend','art/blender/city_horizon_construction.json','game/assets/props/city_horizon_near.glb','game/assets/props/city_horizon_far.glb','game/assets/props/city_horizon_lod1.glb','game/data/orison_v2/exterior/city_horizon.json','game/tests/fixtures/orison_city_horizon.json']
bindings={p:dict(bytes=(root/p).stat().st_size,sha256=hashlib.sha256((root/p).read_bytes()).hexdigest()) for p in assets}
prior={'eastern_industrial_native_review.zip':'8062f3e7d1b108d8435eb0d1ff978d8713b7fc294e6da0a75c0731f8bc5a8cb3','eastern_row_native_review.zip':'dbd65f964c99e311be59c657f1f103098fdb73a9506e92843a4224817d2b1055','eastern_street_native_review.zip':'9f95d8aaa564cc83066d1f345b4ecde8148ff3efd64a7948061bde4cdd0622fb','northern_houses_native_review.zip':'127f7c8e50a84d6b65c5a1f85059cddb0a2f5042a5c34ac8ad37ee3149bf7bd6','houses_loaded_review.zip':'e9eb5a9568e0101c8d59c877e7faf5fa9420f66caba4e889bceae9868f4fdf9f','eastern_houses_review.zip':'263697148f8d5d5c6291ba916c1d4c4a8319ddd41cba7f4499229ad8a550b4f0'}
dest=root/'art/reviews/city_streets_20261029/eastern_courts_review.zip';assert not dest.exists()
for name,sha in prior.items():assert hashlib.sha256((dest.parent/name).read_bytes()).hexdigest()==sha,name
scope='Three apartment-court adaptations and renewed adjoining factory. Native72roundtrips/82receivingcontrols/12current inspectedviews plus2factorynear exactreuse. Embedded schema2 contracts only qualify their declared loaded geometry/material/LOD and independent controller-route scopes. Original strict preservation/localization failures and stopped native jobs retained. Archive/index INERT. Not continuous campaign/traffic/save,matched performance or artistic acceptance.'
index=dict(evidence_class='INERT',scope=scope,sourcebase='e3ccd6bd5f3dd308b2132eef0d76e603d6f1c5de',assets=bindings,runtime_sources=runtime_bindings,prior_unchanged_archives=prior,members={k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in stored.items()})
stored['archive_index.json']=json.dumps(index,indent=2).encode('utf-8')
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
    for k,v in stored.items():z.writestr(k,v,compress_type=zipfile.ZIP_STORED if k.endswith('.png') else zipfile.ZIP_DEFLATED,compresslevel=1)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None and set(z.namelist())==set(stored)
    for k,v in stored.items():assert z.read(k)==v,k
record=dict(evidence_class='INERT',scope=scope,archive=dest.relative_to(root).as_posix(),bytes=dest.stat().st_size,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),member_count=len(stored),runtime_source_count=len(runtime_bindings),runtime_contracts={name:dict(member=('execution/bench_01/' if name=='bench' else 'execution/access_02/')+('courts_loaded.runtime.json' if name=='bench' else 'courts_access.runtime.json'),checks=r['checks']) for name,r in records.items()},asset_bindings=bindings)
p=root/'art/reviews/city_streets_20261029/manifest.json';manifest=json.loads(p.read_text(encoding='utf-8'));assert 'eastern_courts_archive' not in manifest;manifest['eastern_courts_archive']=record;p.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'archive_record_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in record.items() if k!='asset_bindings'}))
