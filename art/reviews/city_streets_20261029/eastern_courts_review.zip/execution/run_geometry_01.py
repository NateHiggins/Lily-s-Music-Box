from pathlib import Path
import subprocess,os,time,json,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent;script=out/'check_geometry_01.py'
for p in ['art/blender/scripts/city_residential_architecture.py','art/blender/scripts/city_industrial_architecture.py','art/data/city_horizon/source_plan.json']:
    (out/('executed_geometry_01_'+Path(p).name)).write_bytes((root/p).read_bytes())
env=os.environ.copy()
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:env[key]='2'
started=time.time()
with (out/'geometry_01.log').open('xb') as log:
    result=subprocess.run(['C:/Program Files/Blender Foundation/Blender 5.2/blender.exe','-b','-t','2','--python-exit-code','1','-P',str(script)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
record=dict(evidence_class='INERT',scope='Native source control only;no savedasset orrender acceptance.',exit_code=result.returncode,seconds=time.time()-started,script_sha256=hashlib.sha256(script.read_bytes()).hexdigest())
(out/'geometry_execution_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n');print(record);raise SystemExit(result.returncode)
