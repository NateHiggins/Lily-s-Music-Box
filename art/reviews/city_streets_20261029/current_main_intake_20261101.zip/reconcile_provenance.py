"""Bounded authoring-metadata repair; no runtime receipt or geometry rewrite."""
import ast
import copy
import hashlib
import json
import re
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path('C:/PleaseRemainOnTheLine')
OUT = Path('C:/ov/reports/city_integration_20261101')
PRODUCER = 'art/blender/scripts/build_city_streets.py'
PLAN = 'art/data/city_horizon/source_plan.json'
CONSTRUCTION = 'art/blender/city_horizon_construction.json'
DOCS = [
    'art/blender/city_streets_construction.json', 'game/tests/fixtures/orison_city_streets.json',
    'art/data/orison_ground/discovery/native_sources.json', 'art/data/orison_ground/retained_grade_source.json',
    'art/blender/city_foundations_construction.json', 'game/tests/fixtures/orison_city_foundations_construction.json',
    'art/blender/orison_ground_construction.json', 'game/tests/fixtures/orison_ground_construction.json',
    'art/blender/city_ground_apron_construction.json', 'game/tests/fixtures/orison_city_ground_apron.json',
    CONSTRUCTION, 'game/tests/fixtures/orison_city_horizon.json',
]
HEX = re.compile(r'[a-f0-9]{64}')
HISTORICAL = {'art/blender/orison_ground_construction.json', 'game/tests/fixtures/orison_ground_construction.json'}
ACTIVE_DOCS = [p for p in DOCS if p not in HISTORICAL]
sys.path.insert(0, str(ROOT / 'tools'))
from preflight_spatial_test_bindings import TEXT_SUFFIXES
raw = {p: (ROOT / p).read_bytes() for p in DOCS + [PRODUCER]}
data = {p: json.loads(raw[p]) for p in DOCS}

def digest(value, path=None):
    if path is None or Path(path).suffix in TEXT_SUFFIXES:
        value = value.replace(b'\r\n', b'\n')
    return hashlib.sha256(value).hexdigest()

def maps(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key in ('bindings', 'source_bindings') and isinstance(child, dict) and child and all(isinstance(v, str) and HEX.fullmatch(v) for v in child.values()):
                yield child
            else:
                yield from maps(child)
    elif isinstance(value, list):
        for child in value:
            yield from maps(child)

def payload(value):
    value = copy.deepcopy(value)
    for binding in maps(value):
        binding.clear()
    return value

old_plan_raw = subprocess.check_output(['git', '-C', str(ROOT), 'show', 'b7acf6190:' + PLAN])
assert digest(old_plan_raw) == '8d6a19497384be7398caeeb71000e0db76f8296b0fca939abcc428024eccdd14'
old_plan = json.loads(old_plan_raw)
new_plan = json.loads((ROOT / PLAN).read_bytes())
projection = lambda d: [[r['id'], r['rect']] for r in d['buildings']]
assert len(projection(old_plan)) == 124 and projection(old_plan) == projection(new_plan)
assert json.dumps(projection(old_plan), separators=(',', ':')) == json.dumps(projection(new_plan), separators=(',', ':'))
wrong = copy.deepcopy(new_plan)
wrong['buildings'][0]['rect'][0] += .01
assert projection(wrong) != projection(old_plan), 'Changed-rectangle negative control'

assets = ['game/assets/props/city_streets.glb', 'game/assets/props/city_streets_lod1.glb', 'game/assets/props/city_ground_apron.glb']
for p in assets:
    assert subprocess.check_output(['git', '-C', str(ROOT), 'show', 'b7acf6190:' + p]) == (ROOT / p).read_bytes()
for p in [PRODUCER, 'art/blender/scripts/city_street_geometry.py', 'art/blender/scripts/build_city_ground_apron.py', 'art/blender/scripts/city_ground_apron_geometry.py']:
    assert subprocess.check_output(['git', '-C', str(ROOT), 'show', 'b7acf6190:' + p]).replace(b'\r\n', b'\n') == (ROOT / p).read_bytes().replace(b'\r\n', b'\n')

old_source = raw[PRODUCER].decode('utf-8')
needle = "'art/data/city_horizon/source_plan.json','art/blender/city_horizon_construction.json',"
assert old_source.count(needle) == 1
new_source = old_source.replace(needle, '')
old_tree, new_tree = ast.parse(old_source), ast.parse(new_source)
def provenance_statement(node):
    return (isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'paths' for t in node.targets)) or (isinstance(node, ast.If) and any(isinstance(n, ast.AugAssign) and isinstance(n.target, ast.Name) and n.target.id == 'paths' for n in ast.walk(node)))
def geometry_ast(tree):
    return ast.dump(ast.Module(body=[n for n in tree.body if not provenance_statement(n)], type_ignores=[]), include_attributes=False)
assert geometry_ast(old_tree) == geometry_ast(new_tree), 'Every geometry/export/runtime-output statement stays exact'
context = {'plan_path': 'art/data/city_streets/source_plan.json', 'provider_path': 'game/data/orison_v2/exterior/exterior_geometry.json', 'district_records': data[DOCS[0]]['districts']}
exec(compile(ast.Module(body=[n for n in new_tree.body if provenance_statement(n)], type_ignores=[]), '<actual-producer-provenance>', 'exec'), context)
assert set(context['paths']) == set(data[DOCS[0]]['source_bindings']) - {PLAN, CONSTRUCTION}

allowed_stale = {(p, k) for p in DOCS[:2] for k in (PLAN, CONSTRUCTION)} | {(p, PLAN) for p in DOCS[8:10]}
observed_stale = set()
for p in ACTIVE_DOCS:
    for binding in maps(data[p]):
        for key, expected in binding.items():
            assert (ROOT / key).is_file(), (p, 'missing', key)
            if digest((ROOT / key).read_bytes(), key) != expected:
                observed_stale.add((p, key))
assert observed_stale == allowed_stale, sorted(observed_stale - allowed_stale)

updated = copy.deepcopy(data)
for p in DOCS[:2]:
    for key in (PLAN, CONSTRUCTION):
        del updated[p]['source_bindings'][key]
graph = {p: {key for binding in maps(updated[p]) for key in binding if key in ACTIVE_DOCS} for p in ACTIVE_DOCS}
order, active, done = [], set(), set()
def visit(p):
    assert p not in active, ('remaining provenance cycle', p)
    if p in done:
        return
    active.add(p)
    for dependency in sorted(graph[p]):
        visit(dependency)
    active.remove(p)
    done.add(p)
    order.append(p)
for p in ACTIVE_DOCS:
    visit(p)

outputs = {PRODUCER: new_source.encode('utf-8')}
for p in order:
    for binding in maps(updated[p]):
        for key in list(binding):
            binding[key] = digest(outputs[key] if key in outputs else (ROOT / key).read_bytes(), key)
    assert payload(updated[p]) == payload(data[p]), ('changed geometry/mask payload', p)
    text = raw[p].decode('utf-8')
    if p in DOCS[:2]:
        for key in (PLAN, CONSTRUCTION):
            pattern = r'^\s*"' + re.escape(key) + r'": "' + data[p]['source_bindings'][key] + r'",\r?\n'
            text, count = re.subn(pattern, '', text, flags=re.M)
            assert count == 1
    for old_map, new_map in zip(maps(data[p]), maps(updated[p])):
        for key, new_hash in new_map.items():
            old_hash = old_map[key]
            if old_hash == new_hash:
                continue
            pattern = r'("' + re.escape(key) + r'"\s*:\s*")' + old_hash + r'(")'
            text, count = re.subn(pattern, lambda m: m[1] + new_hash + m[2], text)
            assert count > 0, (p, key)
    assert json.loads(text) == updated[p], ('unintended metadata rewrite', p)
    outputs[p] = text.encode('utf-8')
for a, b in [(DOCS[0], DOCS[1]), (DOCS[4], DOCS[5]), (DOCS[6], DOCS[7]), (DOCS[8], DOCS[9]), (DOCS[10], DOCS[11])]:
    assert updated[a] == updated[b], ('producer/fixture mismatch', a, b)

changed = {p: value for p, value in outputs.items() if value != raw[p]}
report = {'evidence_class': 'INERT', 'scope': 'Provenance-only producer/metadata repair; no runtime or artistic proof',
          'removed_unused_street_bindings': [PLAN, CONSTRUCTION], 'acyclic_order': order,
          'geometry_export_ast_unchanged': True, 'ordered_building_rectangles_exact': 124,
          'changed_rectangle_negative_control': True, 'byte_exact_exports': assets,
          'geometry_mask_payloads_unchanged': len(ACTIVE_DOCS), 'changed_paths': list(changed),
          'historical_ground_snapshots_preserved': sorted(HISTORICAL),
          'graph_scope': 'Live authoring bindings only; frozen historical ground source_plan is not a current-validation edge',
          'observed_original_stale_entries': sorted(observed_stale)}
if '--apply' not in sys.argv:
    (OUT / 'provenance_repair_dry_run.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps(report, indent=2))
    raise SystemExit(0)
backup = OUT / 'pre_provenance_repair.zip'
assert not backup.exists(), 'Do not overwrite original proof'
with zipfile.ZipFile(backup, 'w', zipfile.ZIP_DEFLATED) as z:
    for p, value in raw.items():
        z.writestr(p, value)
try:
    for p, value in changed.items():
        assert (ROOT / p).read_bytes() == raw[p], ('concurrent edit', p)
        (ROOT / p).write_bytes(value)
    sys.path.insert(0, str(ROOT / 'tools'))
    from grade_source_snapshot import validate
    validate(updated[DOCS[3]], ROOT)
    from preflight_spatial_test_bindings import check_fixture
    for p in (DOCS[1], DOCS[9], DOCS[11]):
        errors = check_fixture(ROOT / p, ROOT)
        assert not errors, (p, errors)
    for p in ACTIVE_DOCS:
        for binding in maps(updated[p]):
            assert all(digest((ROOT / k).read_bytes(), k) == v for k, v in binding.items()), p
    assert all((ROOT / p).read_bytes() == raw[p] for p in HISTORICAL)
except BaseException:
    for p in changed:
        assert (ROOT / p).read_bytes() in (raw[p], changed[p]), ('concurrent edit; preserve', p)
        (ROOT / p).write_bytes(raw[p])
    raise
report['strict_retained_grade_validation'] = 'PASS'
report['strict_native_fixture_validation'] = 'PASS'
report['all_metadata_bindings_current'] = True
(OUT / 'provenance_repair.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(report, indent=2))
