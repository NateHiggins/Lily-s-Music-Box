import hashlib,json,re,struct
from pathlib import Path
root=Path('C:/ov/reports/city_integration_20261101');run=root/'frontage02'
contract=json.loads((run/'western_frontage_composed.runtime.json').read_bytes())
receipt=json.loads((run/'run.log.receipt.json').read_bytes())
assert contract['execution']['completed'] and contract['execution']['exit_code']==0 and contract['failures']==0
assert receipt['execution']['completed'] and receipt['execution']['exit_code']==0 and receipt['log']['script_error_count']==receipt['log']['fail_count']==0
assert (run/'run.log.stderr').read_bytes()==b''
assert not re.search(r'(?m)^(ERROR:|SCRIPT ERROR:)',(run/'run.log').read_text(encoding='utf-8'))
observations={
 'western_row_public_context.png':'Three distinct heights/frontage rhythms, brick/timber surfaces, stoops and railings appear together. Strong shadow suppresses material relief and the sky remains soft. This is a separate static optical camera, not another walked stance.',
 'western_HORIZON_NEAR_3_2_P0R0_row_landing.png':'Actual landing view approaches the closed scenic door; visible frame, metal pulls, adjacent brick and companion. Door is heavily shadowed; this does not establish scenic-door operability.',
 'western_HORIZON_NEAR_3_2_P0R1_row_landing.png':'Actual landing view retains door pulls, frame and companion against a heavily shadowed face. Close framing limits assessment of the whole frontage.',
 'western_HORIZON_NEAR_3_2_P0R2_row_landing.png':'Timber-front landing shows the closed leaf, surround and adjacent cladding with the companion. Bright local lamp pool and deep surrounding shadow remain artistic limitations.',
 'western_HORIZON_NEAR_3_2_P0R2_lane_end.png':'Actual lane endpoint shows resolved brick/grout relief and a partial neighboring facade. The frame is close to the wall; it is not an establishing cityscape view.'}
images=[]
for name,observation in observations.items():
    raw=(run/name).read_bytes();assert struct.unpack('>II',raw[16:24])==(3440,1440)
    images.append({'file':name,'sha256':hashlib.sha256(raw).hexdigest(),'observation':observation,'individually_inspected':True})
p=contract['programme']
report={'evidence_class':'INERT','status':'REVIEWED','scope':'Five actual native-resolution captures, independently inspected. No artistic, scenic door, save, full-city or performance acceptance.',
 'runtime_contract_sha256':hashlib.sha256((run/'western_frontage_composed.runtime.json').read_bytes()).hexdigest(),
 'checks':contract['checks'],'failures':contract['failures'],'legs':len(p['legs']),'endpoints':len(p['endpoints']),
 'samples':sum(len(x['samples']) for x in p['legs']),'route_rescues':p['route_rescues'],'startup_ms':contract['startup_ms'],'images':images}
(root/'frontage02/visual_review.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in report.items() if k!='images'},indent=2))
