import gzip,hashlib,json,re,shutil,struct,sys,zipfile
from pathlib import Path
ROOT=Path('C:/PleaseRemainOnTheLine');OUT=Path('C:/ov/reports/city_integration_20261101')
source=OUT/'surface01';packet=ROOT/'art/renders/orison_v2/surface_requirements_20261011'
contract=json.loads((source/'runtime_contract.json').read_bytes());suite=json.loads((source/'run.log.receipt.json').read_bytes())
assert contract['execution']['completed'] and contract['execution']['exit_code']==0 and contract['checks']==655 and not contract['failures']
assert contract['qualification_mode']=='physical_surfaces_only'
assert suite['execution']['completed'] and suite['execution']['exit_code']==0 and suite['log']['script_error_count']==suite['log']['fail_count']==0
for channel in ('stdout','stderr'):
    raw=(source/('run.log'+('.stderr' if channel=='stderr' else ''))).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==suite['log'][channel+'_sha256']
    assert not re.search(rb'(?m)^(ERROR:|SCRIPT ERROR:)',raw)
assert (source/'run.log.stderr').read_bytes()==b''
frontage=json.loads((OUT/'frontage02/grade_owners.json').read_bytes())
assert frontage['source']['surface_inputs_sha256']==contract['surface_inputs_sha256']
sys.path.insert(0,str(ROOT/'tools'))
from v2_surface_evidence import inputs
assert inputs(ROOT)['sha256']==contract['surface_inputs_sha256']
observations={
 'bookcase.png':'Wood grain, glazed cabinet, separated books, floorboards and door render without missing surfaces. Sparse shelf/room dressing remains artistic debt.',
 'F03_B_BATH_reflection_repair.png':'Curtain weave, tile grout, toilet hardware and carried companion render. Strong circular lamp pool remains; bathroom lighting and companion framing are not artistically accepted.',
 'signal_terminal.png':'Loaded glass, local emission, wood floor, furniture and shadows render. This static frame does not prove terminal interaction or accept room dressing.',
 'roof_tank_uv.png':'Tank, service ironwork, parapet and city silhouettes render. Flat-looking bright cloud shapes and dark city material relief remain artistic concerns.',
 'city_context_HORIZON_NEAR_3_2_P0R0.png':'Fixture-derived static camera shows adjoining taller generic/rear facades, occupied-window variation and dark ground. It does not frame the remodeled street-facing side.',
 'city_context_HORIZON_NEAR_3_2_P0R1.png':'A second neighboring/rear context shows lit/unlit panes and simple furnished-room silhouettes. This camera does not establish frontal appearance of the new row.',
 'city_context_HORIZON_NEAR_3_2_P0R2.png':'Third static context shows neighboring rear/generic stock with varied window light. Strong shadow, repeated forms and low cloud relief remain; no city-completion claim.',
 'western_row_public_context.png':'Separate current-world frontage review shows all three remodeled street fronts, stoops and railings under actual lighting. Strong shadows suppress detail. Its clean discovery records the identical surface fingerprint; no artistic acceptance.'}
replacements={name:(source/name).read_bytes() for name in ['runtime_contract.json','surface-inventory.json']}
replacements.update({p.name:p.read_bytes() for p in source.glob('*.png')})
replacements['western_row_public_context.png']=(OUT/'frontage02/western_row_public_context.png').read_bytes()
replacements['suite_run.receipt.json']=(source/'run.log.receipt.json').read_bytes()
for channel in ('stdout','stderr'):
    raw=(source/('run.log'+('.stderr' if channel=='stderr' else ''))).read_bytes()
    replacements['suite_run.'+channel+'.log.gz']=gzip.compress(raw,mtime=0)
images=[]
for name,observation in observations.items():
    raw=replacements[name];assert struct.unpack('>II',raw[16:24])==(3440,1440)
    images.append({'file':name,'sha256':hashlib.sha256(raw).hexdigest(),'observation':observation,
      'origin':('frontage02' if name.startswith('western_') else 'surface01')+' actual pinned Vulkan hidden-desktop3440x1440 capture; individually inspected'})
review={'evidence_class':'INERT','status':'PASS','scope':'Technical rendered inspection only. All physical draws surveyed; separate interaction/save programmes not executed. Five frontage frames separately reviewed; no artistic, performance or whole-game acceptance.',
        'surface_inputs_sha256':contract['surface_inputs_sha256'],'images':images}
replacements['visual_review.json']=(json.dumps(review,indent=2)+'\n').encode()
backup=OUT/'before_surface_renewal_delta.zip';assert not backup.exists()
with zipfile.ZipFile(backup,'w',zipfile.ZIP_DEFLATED) as z:
    for name in replacements:
        if (packet/name).exists():z.writestr(name,(packet/name).read_bytes())
for name,raw in replacements.items():(packet/name).write_bytes(raw)
report={'evidence_class':'INERT','published_files':list(replacements),'reviewed_images':len(images),
 'surface_inputs_sha256':contract['surface_inputs_sha256'],'prior_delta_archive_sha256':hashlib.sha256(backup.read_bytes()).hexdigest()}
(OUT/'surface_publication.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report,indent=2))
