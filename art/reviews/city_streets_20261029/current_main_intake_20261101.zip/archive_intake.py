import hashlib,json,zipfile
from pathlib import Path
root=Path('C:/PleaseRemainOnTheLine');out=Path('C:/ov/reports/city_integration_20261101')
target=root/'art/reviews/city_streets_20261029/current_main_intake_20261101.zip'
assert not target.exists()
files=[]
for path in sorted(out.rglob('*')):
    if not path.is_file():continue
    relative=path.relative_to(out)
    if relative.parts[0]=='surface01' and path.name=='surface-inventory.json':continue
    if relative.parts[0]=='surface01' and path.suffix=='.png':continue
    if path.name in ('before_surface_renewal_delta.zip','intake_archive.json'):continue
    if path.suffix.lower() not in {'.json','.py','.log','.stderr','.stdout','.png','.zip','.md'}:continue
    files.append((relative.as_posix(),path.read_bytes()))
manifest={'evidence_class':'INERT','scope':'Original failures, exact metadata/projection controls and current-main diagnostics; schema2 runtime proof remains only in test-written contracts. Surface inventory and captures are in the qualification packet, not duplicated here.',
          'source_checkpoint':'d211123cfbc6e9be033673e3e3f8e81eb6189c3a',
          'files':{name:hashlib.sha256(raw).hexdigest() for name,raw in files}}
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for name,raw in files:z.writestr(name,raw)
    z.writestr('INDEX.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for name,raw in files:assert z.read(name)==raw
report={'evidence_class':'INERT','file':target.relative_to(root).as_posix(),'members':len(files)+1,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
(out/'intake_archive.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report,indent=2))
