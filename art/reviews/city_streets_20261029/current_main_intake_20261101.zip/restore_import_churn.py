import io,json,os,subprocess,zipfile
from pathlib import Path
root=Path('C:/PleaseRemainOnTheLine');out=Path('C:/ov/reports/city_integration_20261101')
def git(*args):return subprocess.run(['git','-C',str(root),*args],capture_output=True,check=True).stdout
all_paths=git('diff','--name-only','-z').decode().split('\0')
real=set(git('diff','--ignore-cr-at-eol','--name-only','-z').decode().split('\0'))
paths=[p for p in all_paths if p.endswith('.import') and p not in real]
batch=git('cat-file','--batch') if not paths else subprocess.run(['git','-C',str(root),'cat-file','--batch'],input=('\n'.join('HEAD:'+p for p in paths)+'\n').encode(),capture_output=True,check=True).stdout
stream=io.BytesIO(batch);originals={};current={}
for p in paths:
    header=stream.readline().split();assert header[1]==b'blob',(p,header)
    value=stream.read(int(header[2]));assert stream.read(1)==b'\n'
    raw=(root/p).read_bytes();assert raw.replace(b'\r\n',b'\n')==value.replace(b'\r\n',b'\n'),p
    originals[p]=value;current[p]=raw
backup=out/'import_churn_before_restore.zip';assert not backup.exists()
with zipfile.ZipFile(backup,'w',zipfile.ZIP_DEFLATED) as z:
    for p,raw in current.items():z.writestr(p,raw)
for p,value in originals.items():
    path=root/p;assert path.read_bytes()==current[p],('concurrent edit',p)
    tmp=path.with_name(path.name+'.churn-tmp');assert not tmp.exists()
    tmp.write_bytes(value);os.replace(tmp,path)
(out/'import_churn_restored.json').write_text(json.dumps({'evidence_class':'INERT','exact_LF_normalized_matches_only':paths,'count':len(paths)},indent=2)+'\n',encoding='utf-8',newline='\n')
print('Restored',len(paths),'proven line-ending-only import paths; originals archived')
