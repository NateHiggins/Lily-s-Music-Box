# Gate board - 3ae86bf0e343

- commit `3ae86bf0e343fe5a817de2f5724eb1d0cc19b5cc`
- tree `da0bafd3b1b11a51c4dc1da7c479afb4fd062795`
- created 2026-11-01T17:52:05Z
- dirty paths: 1175

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| physical_import_sources | PASS | 0 | 0.59 | no defects counted |
| v2_recipe_projections | PASS | 0 | 0.86 | no defects counted |
| spatial | PASS | 0 | 21.25 | no defects counted |
| reader | PASS | 0 | 6.47 | unread 1060; vs frozen baseline: new 0, resolved 248 |
| test:test_city_ground_apron | PASS | 0 | 3.05 | ran 25, failed 0 |
| test:test_runtime_source_projections | PASS | 0 | 0.47 | ran 4, failed 0 |
| test:test_v2_test_dependency_literals | PASS | 0 | 0.14 | ran 2, failed 0 |
