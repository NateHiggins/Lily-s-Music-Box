import hashlib
import json
import re
import subprocess
import zipfile
from pathlib import Path

root = Path('C:/PleaseRemainOnTheLine')
out = Path('C:/ov/reports/city_integration_20261101')
paths = ['.gitattributes', 'HANDOFF.md', 'design/V2_CITY_CONTEXT_REPORT_2026-10-19.md', 'tools/orison_spatial_dependency_manifest.json']
stages = {}
for path in paths:
    stages[path] = {stage: subprocess.check_output(['git', '-C', str(root), 'show', f':{stage}:{path}']) for stage in (1, 2, 3)}
archive = out / 'original_conflict_stages.zip'
if archive.exists():
    with zipfile.ZipFile(archive) as z:
        assert all(z.read(f'stage{stage}/{path}') == raw for path, versions in stages.items() for stage, raw in versions.items())
else:
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for path, versions in stages.items():
            for stage, raw in versions.items():
                z.writestr(f'stage{stage}/{path}', raw)

conflict = re.compile(r'^<<<<<<< .*\n(.*?)^=======\n(.*?)^>>>>>>> .*\n?', re.M | re.S)
for path in ('.gitattributes', 'design/V2_CITY_CONTEXT_REPORT_2026-10-19.md'):
    text = (root / path).read_text(encoding='utf-8')
    text, count = conflict.subn(lambda m: m[1].rstrip() + '\n\n' + m[2].lstrip(), text)
    assert count in (0, 1) and '<<<<<<<' not in text
    (root / path).write_text(text, encoding='utf-8', newline='\n')

prior = stages['HANDOFF.md'][2].decode('utf-8')
assert prior.startswith('# Current handoff')
prior = prior.replace('# Current handoff', '# Historical merged-range handoff', 1)
header = '''# Current handoff - November 1 city intake in progress

Evidence class: **INERT**. Merge custody, not runtime acceptance.

Canonical branch **codex/v2-city-intake-20261101**, from main **3ae86bf0e**.
The published architect branch **0bcb475f6** is being merged, preserving its
Cedar Court, Western street and Western frontage checkpoints. No new native
construction has begun. The range repair is already merged through PR127.

Four conflicts are resolved: preserve both attribute additions, both appended
city-report histories, this canonical handoff and the sole reviewed city
camera record. All 11,097 canonical manifest records are retained exactly;
the resulting manifest has 11,098 records. Original stages are archived at
**C:/ov/reports/city_integration_20261101/original_conflict_stages.zip**.
The architect's original handoff remains in its published commit and archive.

NEXT: run the affected source-fixture preflights and spatial/reader checks before
an expensive Godot startup. Inspect actual consumed dependencies; do not blindly
renew old classification or runtime receipts. Current main's complete clean
baseline is running in own **C:/ov/c-ab46a508** (job **48708**, output
**C:/ov/reports/gas_range_integration_20261101/clean_main_3ae86b/**).
Do not switch that checkout while its job is live. Reuse it for final candidate
verification after the baseline completes; remove it safely when finished.

No combined-current-main city runtime, performance or artistic acceptance yet.
Existing source/render review is in the city report and preserved external
packets. The architect remains frozen pending this intake. The full V2 goal,
93 generic profiles, city lighting, stutter, controls, hose/book/nook and native
delivery qualification remain open. Preserve all current gameplay/save owners.

---

'''
(root / 'HANDOFF.md').write_text(header + prior, encoding='utf-8', newline='\n')

path = 'tools/orison_spatial_dependency_manifest.json'
base, ours, city = (json.loads(stages[path][i]) for i in (1, 2, 3))
base_rows = {r['key']: r for r in base['records']}
ours_rows = {r['key']: r for r in ours['records']}
city_rows = {r['key']: r for r in city['records']}
assert all(city_rows.get(k) == r for k, r in base_rows.items())
assert {k: v for k, v in city.items() if k != 'records'} == {k: v for k, v in base.items() if k != 'records'}
added = [r for k, r in city_rows.items() if k not in base_rows]
assert len(added) == 1 and added[0]['key'] == 'cc77c4890e51fcde'
assert added[0]['key'] not in ours_rows
assert len(ours['records']) == 11097
ours_raw_text = stages[path][2].decode('utf-8')
ending = '\r\n' if '\r\n' in ours_raw_text else '\n'
ours_text = ours_raw_text.replace('\r\n', '\n')
city_text = stages[path][3].decode('utf-8').replace('\r\n', '\n')
at = city_text.index('"key": "cc77c4890e51fcde"')
start = city_text.rfind('\n  {', 0, at) + 1
end = city_text.index('\n  }', at) + len('\n  }')
record_text = city_text[start:end]
assert json.loads(record_text) == added[0]
suffix = '\n ]\n}\n'
assert ours_text.endswith(suffix)
merged_text = ours_text[:-len(suffix)] + ',\n' + record_text + suffix
merged = json.loads(merged_text)
assert merged['records'][:-1] == ours['records'] and merged['records'][-1] == added[0]
assert {k: v for k, v in merged.items() if k != 'records'} == {k: v for k, v in ours.items() if k != 'records'}
(root / path).write_bytes(merged_text.replace('\n', ending).encode('utf-8'))
report = {'evidence_class': 'INERT', 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
          'canonical_parent': '3ae86bf0e343fe5a817de2f5724eb1d0cc19b5cc',
          'city_head': '0bcb475f6a172cb409254ea6da1ade09528d0577', 'resolved_paths': paths,
          'canonical_records_retained_exactly': len(ours['records']), 'added_records': [added[0]['key']],
          'merged_records': len(merged['records']), 'retained_manifest_line_ending': repr(ending),
          'initial_refusal': 'CRLF manifest detected before JSON write/staging; original stages preserved', 'runtime_proof': False}
(out / 'merge_resolution.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
subprocess.run(['git', '-C', str(root), 'add', '--', *paths], check=True, stdout=subprocess.DEVNULL, stderr=(out / 'resolution_staging.stderr').open('w', encoding='utf-8'))
print(json.dumps(report, indent=2))
