"""Compare fresh actual discovery to consumed construction masks; read-only."""
import collections, hashlib, json, re, sys
from pathlib import Path
ROOT=Path('C:/PleaseRemainOnTheLine')
OUT=Path('C:/ov/reports/city_integration_20261101')
RUN=OUT/'grade02'
sys.path.insert(0,str(ROOT/'tools'))
from run_receipt import runtime_inputs_sha256
from preflight_spatial_test_bindings import TEXT_SUFFIXES
def digest(path):
    raw=path.read_bytes()
    return hashlib.sha256(raw.replace(b'\r\n',b'\n') if path.suffix in TEXT_SUFFIXES else raw).hexdigest()
def read(p):return json.loads(p.read_bytes())
plan=read(ROOT/'art/data/orison_ground/retained_grade_source.json')
old=read(ROOT/plan['runtime_survey'])
receipt=read(RUN/'run.log.receipt.json')
assert receipt['execution']['completed'] and receipt['execution']['exit_code']==0 and not receipt['execution']['timed_out'],receipt['execution']
assert receipt['log']['script_error_count']==0,receipt['log']
assert (RUN/'run.log.stderr').read_bytes()==b'', 'Preserve engine errors; discovery alone is insufficient'
log=(RUN/'run.log').read_text(encoding='utf-8')
assert 'V2 GRADE OWNER SURVEY: PASS' in log
assert not re.search(r'(?m)^(?:SCRIPT ERROR:|ERROR:)',log), 'Retain startup/teardown failures'
fresh=read(RUN/'grade_owners.json')
native=read(ROOT/'art/data/orison_ground/discovery/native_sources.json')
assert fresh['evidence_class']=='INERT' and fresh['failures']==0
assert fresh['source']['runtime_inputs_sha256']==runtime_inputs_sha256(ROOT)
for relative,expected in fresh['source']['test_dependencies'].items():
    assert digest(ROOT/relative)==expected,relative
assert old['poses']==fresh['poses'], 'Registration changed; inspect before reconstruction'
normalize=lambda p:re.sub(r'(@[A-Za-z0-9_]+)@\d+',r'\1',p)
def groups(data):
    result=collections.defaultdict(list)
    for row in data['records']:
        result[(normalize(row['owner']),normalize(row['shape_owner']),row['shape_type'],row['aligned'])].append(tuple(row['bounds']))
    return {repr(key):sorted(value) for key,value in result.items()}
before,after=groups(old),groups(fresh)
deltas={key:{'before':before.get(key,[]),'after':after.get(key,[])} for key in before.keys()|after.keys() if before.get(key)!=after.get(key)}
lookup={(r['owner'],r['id']):r for r in native['records']}
checked=derived=runtime=0
for category in ('retained_solids','occupation_reservations','surface_exclusions'):
    for row in plan[category]:
        actual=lookup.get((row['owner'],row.get('id')))
        if actual:
            if category=='surface_exclusions' and row['owner']=='ServiceAlley' and row['kind']=='retained_paving_envelope':
                assert actual['kind']=='retained_continuous_paving_substrate'
                assert all(row['bounds'][i]==actual['bounds'][i] for i in (0,2,3,5))
                assert row['bounds'][1]==plan['soil_bottom'] and row['bounds'][4]==.05
                derived+=1
            else:assert row['kind']==actual['kind'] and row['bounds']==actual['bounds'],(category,row)
            checked+=1
        elif row['kind']=='actual_axis_aligned_box':
            matches=[r for r in fresh['records'] if r['owner']==row['owner'] and r['aligned'] and max(abs(a-b) for a,b in zip(r['bounds'],row['bounds']))<.00003]
            assert len(matches)==1,('changed consumed box',category,row)
            runtime+=1
assert (checked,derived,runtime)==(9601,6,66),(checked,derived,runtime)
stale_native={p:{'stored':h,'actual':digest(ROOT/p)} for p,h in native['bindings'].items() if digest(ROOT/p)!=h}
assert not stale_native,stale_native
mask_keys=['retained_solids','occupation_reservations','surface_exclusions','region','soil_bottom','asphalt_y','open']
mask_raw=(json.dumps({k:plan[k] for k in mask_keys},indent=2,ensure_ascii=True)+'\n').encode()
report={'evidence_class':'INERT','scope':'Current actual grade discovery compared against every consumed retained mask; not runtime or artistic acceptance',
        'runtime_inputs_sha256':fresh['source']['runtime_inputs_sha256'], 'before_box_count':len(old['records']),
        'current_box_count':len(fresh['records']), 'registration_poses_exact':True, 'changed_groups':deltas,
        'consumed_native_rows_exact':checked,'derived_paving_envelopes_exact':derived,'consumed_actual_boxes_exact':runtime,
        'native_input_bindings_exact':len(native['bindings']), 'native_classifications_preserved':len(native['records']),
        'mask_payload_sha256':hashlib.sha256(mask_raw).hexdigest()}
(RUN/'consumed_projection.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report,indent=2))
