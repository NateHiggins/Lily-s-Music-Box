import hashlib, json, os, subprocess, zipfile
from pathlib import Path

root = Path('C:/PleaseRemainOnTheLine')
out = Path('C:/ov/reports/city_integration_20261101')
with zipfile.ZipFile(out / 'pre_provenance_repair.zip') as z:
    originals = {name: z.read(name) for name in z.namelist()}
for name, value in originals.items():
    head = subprocess.run(['git', '-C', str(root), 'show', 'HEAD:' + name], capture_output=True, check=True).stdout
    assert head.replace(b'\r\n', b'\n') == value.replace(b'\r\n', b'\n'), name

real_read = Path.read_bytes
lookup = {str((root / name).resolve()).lower(): value for name, value in originals.items()}
def virtual_read(path):
    key = str(path.resolve()).lower()
    return lookup[key] if key in lookup else real_read(path)
source = (out / 'reconcile_provenance.py').read_text(encoding='utf-8').split("if '--apply' not in sys.argv:")[0]
namespace = {}
try:
    Path.read_bytes = virtual_read
    exec(compile(source, '<reconstruct-original-proposal>', 'exec'), namespace)
finally:
    Path.read_bytes = real_read

changed = namespace['changed']
pending = {}
for name, expected in changed.items():
    current = (root / name).read_bytes()
    assert current in (originals[name], expected), ('foreign/concurrent edit; preserve', name)
    if current != originals[name]:
        pending[name] = current
backup = out / 'partial_rollback_preserved.zip'
assert not backup.exists()
with zipfile.ZipFile(backup, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, value in pending.items():
        z.writestr(name, value)
for name, value in pending.items():
    path = root / name
    assert path.read_bytes() == value
    temporary = path.with_name(path.name + '.city-rollback-tmp')
    assert not temporary.exists()
    temporary.write_bytes(originals[name])
    os.replace(temporary, path)
assert all((root / name).read_bytes() == value for name, value in originals.items())
report = {'evidence_class': 'INERT', 'restored_only_exact_failed_proposal': list(pending),
          'all_original_bytes_restored': True, 'archive_sha256': hashlib.sha256(backup.read_bytes()).hexdigest()}
(out / 'rollback_recovery.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(report, indent=2))
