"""Renew only a proven unchanged transport projection and its live metadata closure."""
import copy, hashlib, importlib.util, json, os, re, subprocess, sys, zipfile
from pathlib import Path
ROOT=Path('C:/PleaseRemainOnTheLine'); OUT=Path('C:/ov/reports/city_integration_20261101')
sys.path.insert(0,str(ROOT/'tools'))
from preflight_spatial_test_bindings import TEXT_SUFFIXES,check_fixture
from grade_source_snapshot import validate
PLAN='art/data/city_streets/source_plan.json'
REPORTS=['art/blender/city_transport_construction.json','game/tests/fixtures/orison_city_transport.json']
DOCS=REPORTS+['art/blender/city_streets_construction.json','game/tests/fixtures/orison_city_streets.json',
 'art/data/orison_ground/discovery/native_sources.json','art/data/orison_ground/retained_grade_source.json',
 'art/blender/city_foundations_construction.json','game/tests/fixtures/orison_city_foundations_construction.json',
 'art/blender/city_ground_apron_construction.json','game/tests/fixtures/orison_city_ground_apron.json',
 'art/blender/city_horizon_construction.json','game/tests/fixtures/orison_city_horizon.json']
def digest(value,path):return hashlib.sha256(value.replace(b'\r\n',b'\n') if Path(path).suffix in TEXT_SUFFIXES else value).hexdigest()
def git(path):return subprocess.check_output(['git','-C',str(ROOT),'show','ed59c7a99:'+path])
raw={p:(ROOT/p).read_bytes() for p in DOCS}; data={p:json.loads(v) for p,v in raw.items()}
old_plan=git(PLAN); assert digest(old_plan,PLAN)==data[REPORTS[0]]['source_bindings'][PLAN]
spec=importlib.util.spec_from_file_location('street_geometry',ROOT/'art/blender/scripts/city_street_geometry.py')
geometry=importlib.util.module_from_spec(spec);spec.loader.exec_module(geometry)
inputs=[json.loads((ROOT/p).read_bytes()) for p in ['game/data/orison_v2/exterior/street_traffic.json','game/data/orison_v2/exterior/street_frame.json','art/data/city_transport/source_plan.json']]
current_plan=json.loads((ROOT/PLAN).read_bytes())
old_shape=geometry.topology(json.loads(old_plan),*inputs);new_shape=geometry.topology(current_plan,*inputs)
encoded=lambda value:json.dumps(value,sort_keys=True,separators=(',',':')).encode()
assert encoded(old_shape)==encoded(new_shape),'Changed consumed topology; rebuild required'
wrong=copy.deepcopy(current_plan);wrong['carriageway_width_m']+=.1
assert encoded(geometry.topology(wrong,*inputs))!=encoded(old_shape),'Negative control must detect changed road'
producer=(ROOT/'art/blender/scripts/build_city_transport.py').read_text(encoding='utf-8')
assert producer.count("street_shape['road']")==1 and producer.count('street_shape')==2
hex64=re.compile('[a-f0-9]{64}')
def maps(value):
    if isinstance(value,dict):
        for key,child in value.items():
            if key in ('bindings','source_bindings') and isinstance(child,dict) and child and all(isinstance(v,str) and hex64.fullmatch(v) for v in child.values()):yield child
            else:yield from maps(child)
    elif isinstance(value,list):
        for child in value:yield from maps(child)
def payload(value):
    value=copy.deepcopy(value)
    for binding in maps(value):binding.clear()
    return value
stale={(p,k) for p in DOCS for binding in maps(data[p]) for k,v in binding.items() if digest((ROOT/k).read_bytes(),k)!=v}
assert stale=={(p,PLAN) for p in REPORTS},stale
assets=data[REPORTS[0]]['asset_sha256']
for p,expected in assets.items():assert digest((ROOT/p).read_bytes(),p)==expected
assert raw[REPORTS[0]]==raw[REPORTS[1]]
order=[];done=set();visiting=set()
def visit(p):
    assert p not in visiting,p
    if p in done:return
    visiting.add(p)
    for key in sorted({k for m in maps(data[p]) for k in m if k in DOCS}):visit(key)
    visiting.remove(p);done.add(p);order.append(p)
for p in DOCS:visit(p)
outputs={}
for p in order:
    updated=copy.deepcopy(data[p]);text=raw[p].decode('utf-8')
    for binding in maps(updated):
        for key,old_hash in list(binding.items()):
            new_hash=digest(outputs[key] if key in outputs else (ROOT/key).read_bytes(),key)
            if new_hash!=old_hash:
                text,count=re.subn(r'("'+re.escape(key)+r'"\s*:\s*")'+old_hash+r'(")',lambda m:m[1]+new_hash+m[2],text)
                assert count>0,(p,key)
                binding[key]=new_hash
    assert payload(updated)==payload(data[p])
    assert json.loads(text)==updated
    outputs[p]=text.encode('utf-8')
changed={p:v for p,v in outputs.items() if v!=raw[p]}
report={'evidence_class':'INERT','scope':'Exact evaluated transport topology, export hashes and metadata-only live closure; no runtime acceptance',
 'old_plan_commit':'ed59c7a99','complete_topology_sha256':hashlib.sha256(encoded(old_shape)).hexdigest(),
 'road_polygons':len(old_shape['road']),'road_mutation_negative_control':True,'unchanged_asset_hashes':assets,
 'unchanged_geometry_mask_payloads':len(DOCS),'changed_paths':list(changed),'ordered_closure':order}
if '--apply' not in sys.argv:
    (OUT/'transport_closure_dry_run.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(report,indent=2));raise SystemExit(0)
backup=OUT/'before_transport_closure.zip';assert not backup.exists()
with zipfile.ZipFile(backup,'w',zipfile.ZIP_DEFLATED) as z:
    for p,v in raw.items():z.writestr(p,v)
def atomic_write(path,value):
    tmp=path.with_name(path.name+'.transport-closure-tmp');assert not tmp.exists()
    tmp.write_bytes(value);os.replace(tmp,path)
try:
    for p,v in changed.items():
        assert (ROOT/p).read_bytes()==raw[p],('concurrent edit',p)
        atomic_write(ROOT/p,v)
    validate(json.loads(outputs['art/data/orison_ground/retained_grade_source.json']),ROOT)
    for p in DOCS:
        for binding in maps(json.loads(outputs[p])):
            assert all(digest((ROOT/k).read_bytes(),k)==v for k,v in binding.items()),p
    for p in [p for p in DOCS if p.startswith('game/tests/') and 'source_bindings' in json.loads(outputs[p])]:assert not check_fixture(ROOT/p,ROOT),p
except BaseException:
    for p,v in changed.items():
        assert (ROOT/p).read_bytes() in (raw[p],v),('concurrent edit',p)
        atomic_write(ROOT/p,raw[p])
    raise
report['strict_owner_and_fixture_validation']='PASS'
(OUT/'transport_closure.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report,indent=2))
