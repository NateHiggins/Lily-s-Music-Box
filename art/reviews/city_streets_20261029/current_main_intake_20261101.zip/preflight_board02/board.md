# Gate board - fef74f5d62fb

- commit `fef74f5d62fbe09cd164632ce96012c8e1349678`
- tree `c8cae2b64743d3e02fdf40bdb90b2590a5a2f3e3`
- created 2026-11-01T18:35:31Z
- dirty paths: 1137

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| physical_import_sources | PASS | 0 | 0.41 | no defects counted |
| v2_recipe_projections | PASS | 0 | 0.69 | no defects counted |
| spatial | PASS | 0 | 8.75 | no defects counted |
| reader | PASS | 0 | 5.05 | unread 1060; vs frozen baseline: new 0, resolved 248 |
| test:test_city_ground_apron | PASS | 0 | 2.95 | ran 25, failed 0 |
| test:test_runtime_source_projections | PASS | 0 | 0.14 | ran 4, failed 0 |
| test:test_v2_test_dependency_literals | PASS | 0 | 0.23 | ran 2, failed 0 |
