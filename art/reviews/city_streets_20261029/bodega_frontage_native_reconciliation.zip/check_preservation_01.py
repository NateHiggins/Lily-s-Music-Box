from pathlib import Path
import subprocess,json,struct,hashlib,sys
root=Path('C:/ov/city');out=Path(__file__).parent
# Preserve baseline accessor bytes directly from git; no duplicate mesh assets.
def projection(raw):
 size=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+size]);binary=raw[28+size:]
 def acc(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];c={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];w={5120:1,5121:1,5122:2,5123:2,5125:4,5126:4}[a['componentType']]*c;stride=v.get('byteStride',w);offset=v.get('byteOffset',0)+a.get('byteOffset',0)
  return hashlib.sha256(b''.join(binary[offset+j*stride:offset+j*stride+w] for j in range(a['count']))).hexdigest()
 return {n['name']:{'transform':{k:n[k] for k in ['translation','rotation','scale','matrix'] if k in n},'primitives':[dict(attributes={k:acc(v) for k,v in p['attributes'].items()},indices=acc(p['indices'])) for p in d['meshes'][n['mesh']]['primitives']]} for n in d['nodes'] if 'mesh' in n}
result={'evidence_class':'INERT','parts':{}}
for family in ['city_elevations','city_elevations_lod1']:
 path='game/assets/props/'+family+'.glb';a=projection(subprocess.run(['git','show','HEAD:'+path],cwd=root,capture_output=True,check=True).stdout);b=projection((root/path).read_bytes());unchanged=[k for k in a if not k.startswith('site_nbr_e__')];fail=[k for k in unchanged if a[k]!=b.get(k)]
 result['parts'][family]={'unaffected_exact':len(unchanged)-len(fail),'failures':fail,'removed':sorted(a.keys()-b.keys()),'added':sorted(b.keys()-a.keys())};assert not fail,fail
(out/'export_preservation_01.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(result)
