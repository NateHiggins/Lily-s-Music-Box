from pathlib import Path
import bpy,json,collections,math,hashlib
from mathutils import Vector
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent;captures=[]
geometry=json.loads((ROOT/'game/data/orison_v2/exterior/exterior_geometry.json').read_text(encoding='utf-8'))
boxes=next(t for t in geometry['templates'] if t['id']=='TEMPLATE_BODEGA_CELL_V1')['boxes']
def clip(poly,axis,bound,sign):
 result=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  da=sign*(a[axis]-bound);db=sign*(b[axis]-bound)
  if da>=0:result.append(a)
  if (da>=0)!=(db>=0):result.append(a+(b-a)*(da/(da-db)))
 return result

def intersects(tri,lo,hi):
 if any(max(v[i] for v in tri)<lo[i] or min(v[i] for v in tri)>hi[i] for i in range(3)):return False
 p=tri
 for i in range(3):
  for at,sign in [(lo[i],1),(hi[i],-1)]:
   p=clip(p,i,at,sign)
   if len(p)<3:return False
 return sum((p[i]-p[0]).cross(p[i+1]-p[0]).length for i in range(1,len(p)-1))>1e-12
checks=[];sources={};all_captures=[]
for family in ['city_elevations','city_elevations_lod1']:
 bpy.ops.wm.open_mainfile(filepath=str(ROOT/f'art/blender/{family}.blend'))
 native=[o for o in bpy.context.scene.objects if o.type=='MESH' and o.name.startswith('site_nbr_e__') and not o.hide_render]
 assert len(native)==13,(family,len(native))
 def triangles(o):
  o.data.calc_loop_triangles()
  return [tuple(o.matrix_world@o.data.vertices[i].co for i in t.vertices) for t in o.data.loop_triangles]
 tris=[(o.name,t) for o in native for t in triangles(o)]
 # Open reservations eroded by0.1mm: boundary bearing contacts are allowed explicitly.
 bands=[('shop_and_receiving',[16.415,-12.07,-.14],[20.895,.78,3.25]),('taller_frontage',[16.415,-12.07,-.14],[20.895,-11.77,3.55])]
 for label,lo,hi in bands:
  lo=[v+.0001 for v in lo];hi=[v-.0001 for v in hi];failed=[name for name,t in tris if intersects(list(t),lo,hi)]
  checks.append(dict(family=family,kind=label,triangles=len(tris),intrusions=failed));assert not failed,(family,label,failed[:8])
 # Check every actual retained box, including visible trim; no blanket exemption.
 for b in boxes:
  assert b.get('yaw_degrees',0)==0
  p=b['position_m'];s=b['size_m'];lo=[18.655+p[0]-s[0]/2,-11.92-p[2]-s[2]/2,p[1]-s[1]/2];hi=[18.655+p[0]+s[0]/2,-11.92-p[2]+s[2]/2,p[1]+s[1]/2]
  failed=[name for name,t in tris if intersects(list(t),[v+.0001 for v in lo],[v-.0001 for v in hi])]
  checks.append(dict(family=family,kind='actual_box',id=b['id'],intrusions=failed));assert not failed,(family,b['id'],failed[:8])
 # Exact native-to-export positions and active UV layer.
 expected={o.name:collections.Counter(tuple(sorted(tuple(v) for v in t)) for t in triangles(o)) for o in native}
 before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(ROOT/f'game/assets/props/{family}.glb'));bpy.context.view_layer.update()
 imported=[o for o in bpy.data.objects if o not in before and o.type=='MESH']
 for o in imported:
  if o.name.startswith('site_nbr_e__'):
   assert collections.Counter(tuple(sorted(tuple(v) for v in t)) for t in triangles(o))==expected[o.name.split('.')[0]],o.name
   assert len(o.data.uv_layers)==1
 for o in bpy.context.scene.objects:
  if o.type=='MESH':o.hide_render=o not in native
 # Actual fixed native shop frame in the measured shop transform.
 with bpy.data.libraries.load(str(ROOT/'art/blender/bodega_frontage.blend'),link=False) as (available,loaded):loaded.objects=[n for n in available.objects if n.startswith('Frontage__')]
 for o in loaded.objects:
  bpy.context.scene.collection.objects.link(o);o.location+=Vector((18.655,-11.92,0));o.hide_render=False
 # Actual retained native receiving room, in its existing shop frame.
 with bpy.data.libraries.load(str(ROOT/'art/blender/bodega_receiving.blend'),link=False) as (available,loaded):loaded.objects=list(available.objects)
 for o in loaded.objects:
  if o.type!='MESH':continue
  bpy.context.scene.collection.objects.link(o);o.location+=Vector((18.655,-11.92,0));o.hide_render=False
  lo=[min((o.matrix_world@Vector(c))[i] for c in o.bound_box) for i in range(3)];hi=[max((o.matrix_world@Vector(c))[i] for c in o.bound_box) for i in range(3)]
  failed=[name for name,t in tris if intersects(list(t),[v+.0001 for v in lo],[v-.0001 for v in hi])]
  checks.append(dict(family=family,kind='receiving_native_bounds',id=o.name,lo=lo,hi=hi,intrusions=failed));assert not failed,(o.name,failed[:8])
 # Beam seats on actual piers: require native concrete at measured top contact.
 from mathutils.bvhtree import BVHTree
 concrete=next(o for o in native if o.name.endswith('__concrete'));ct=triangles(concrete);vv=[v for t in ct for v in t];bv=BVHTree.FromPolygons(vv,[tuple(range(i,i+3)) for i in range(0,len(vv),3)],all_triangles=True)
 for b in [b for b in boxes if b['id'] in ['facade_left_pier','facade_right_pier']]:
  p=b['position_m'];size=b['size_m'];top=p[1]+size[1]/2
  for dx in [-.07,.07]:
   for yy in [-11.85,-11.79]:
    point=Vector((18.655+p[0]+dx,yy,top));hit,normal,index,distance=bv.ray_cast(point-Vector((0,0,.02)),Vector((0,0,1)),.04)
    assert hit is not None and (hit-point).length<.0001,(family,b['id'],list(point),hit)
    checks.append(dict(family=family,kind='concrete_pier_seat',id=b['id'],point=list(point),distance_m=(hit-point).length))
 # Source box context is deliberately neutral diagnostic; no appearance acceptance.
 diag=bpy.data.materials.new('Retained source boxes DIAGNOSTIC');diag.diffuse_color=(.36,.34,.29,1)
 for b in boxes:
  if not b.get('visible',True):continue
  p=b['position_m'];s=b['size_m'];bpy.ops.mesh.primitive_cube_add(size=1,location=(18.655+p[0],-11.92-p[2],p[1]));o=bpy.context.object;o.name='SourceOwner__'+b['id'];o.dimensions=(s[0],s[2],s[1]);o.data.materials.append(diag)
 # Door silhouette in closed pose, solely a diagnostic position marker.
 bpy.ops.mesh.primitive_cube_add(size=1,location=(18.655,-11.92,1.05));o=bpy.context.object;o.name='DIAGNOSTIC retained leaf position';o.dimensions=(.95,.04,2.1);o.data.materials.append(diag)
 for im in bpy.data.images:
  if im.source=='FILE' and not im.packed_file:
   p=ROOT/'game/assets/building/textures'/Path(im.filepath).name
   assert p.is_file(),p
   im.filepath=str(p);im.reload()
 scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.cycles.use_denoising=True;scene.render.threads_mode='FIXED';scene.render.threads=2
 scene.render.resolution_x=1000;scene.render.resolution_y=1000;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX'
 world=bpy.data.worlds.new('Context world');scene.world=world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.18,.2,.24,1);world.node_tree.nodes['Background'].inputs[1].default_value=.65
 sun=bpy.data.objects.new('Review sunlight',bpy.data.lights.new('Review sunlight','SUN'));scene.collection.objects.link(sun);sun.rotation_euler=Vector((.4,.7,-1)).to_track_quat('-Z','Y').to_euler();sun.data.energy=2.5;sun.data.angle=.15
 camera=bpy.data.objects.new('Review camera',bpy.data.cameras.new('Review camera'));scene.collection.objects.link(camera);scene.camera=camera;camera.data.type='ORTHO'
 for label,at,target,scale in [('full_front',(26,-30,12),(18.655,-1,6.2),21)]:
  camera.location=at;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=scale;
  from bpy_extras.object_utils import world_to_camera_view
  for attempt in range(20):
   bpy.context.view_layer.update()
   projected=[world_to_camera_view(scene,camera,o.matrix_world@Vector(c)) for o in scene.objects if o.type=='MESH' and not o.hide_render for c in o.bound_box]
   framed=all(p.z>0 and .035<=p.x<=.965 and .035<=p.y<=.965 for p in projected)
   if framed:break
   camera.data.ortho_scale*=1.15
  assert framed
  path=OUT/(family+'_'+label+'_03.png');scene.render.filepath=str(path);bpy.ops.render.render(write_still=True);all_captures.append(str(path))
 sources[family]=hashlib.sha256((ROOT/f'game/assets/props/{family}.glb').read_bytes()).hexdigest()
(OUT/'native_clearance_review_03.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Actual city native and float32 mesh clearance; retained source boxes/door marker diagnostic, fixed Bodega frame native. No capsule, runtime, optical or artistic acceptance.',checks=checks,sources=sources,captures=all_captures,failures=[]),indent=2),encoding='utf-8')
print('NATIVE_SHOP_CLEARANCE',len(checks),'checks',len(all_captures),'views',flush=True)
