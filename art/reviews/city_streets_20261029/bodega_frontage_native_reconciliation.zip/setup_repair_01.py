from pathlib import Path
import json,subprocess,sys
root=Path('C:/ov/city');out=Path('C:/ov/reports/city_streets_20261029/bodega_frontage_reconciliation_01')
p=root/'art/blender/scripts/city_commercial_architecture.py';s=p.read_text();s=s.replace("'left_facade_pier','right_facade_pier'","'facade_left_pier','facade_right_pier'");p.write_text(s,encoding='utf-8',newline='\n')
p=root/'art/data/city_elevations/source_plan.json';d=json.loads(p.read_text());b=next(b for b in d['buildings'] if b['id']=='site_nbr_e');b['floor_heights']=[3.55,3.25,3.0,3.0];a=b['architecture'];a['retained_shop_id']='SHOP_BODEGA';a['precedent']=a['precedent'].split(' Recessed scenic')[0]+' Ground floor is the installed Bodega conversion: its centred operable entrance, frontage, occupied room and receiving area remain exclusive shop authorities. Hayden upper floors, cornice and retained roof remain city-owned.';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
p=root/'TASKS.md';s=p.read_text();needle='- **K-V2-CITY-REVAMP';start=s.index(needle);end=s.index('\n',start);s=s[:end]+' **2026-10-30 composed correction:** east narrow-house approach FAILED against retained Bodega bulkhead (234 checks/6 legs/2 failures); west ascent/descent passed. Repair takes precedence: remove duplicate city ground frontage/slab/lower sidewalls from actual shop/receiving reservation while retaining Hayden upper house. SW2 carriagehouse native WIP is preserved on city branch at28834fea; no runtime qualification. Temporary repair branch codex/v2-city-bodega-fix-20261030 startsfe4899a5 in the same worktree. Tally remains21/149.'+s[end:];p.write_text(s,encoding='utf-8',newline='\n')
p=root/'design/V2_CITY_CONTEXT_REPORT_2026-10-19.md';s=p.read_text();s+='''
REPORT - K-V2-CITY-REVAMP - 2026-10-30

Evidence class: **INERT**. Bodega reconciliation in progress; no acceptance.

The actual composed controller run preserved234 checks/6 legs/2 failures.
West four-step ascent/descent passed. East footway passed but the scenic
left-entry approach contacted **SHOP_BODEGA/Collision** at world
(17.60919,.76,2.235). The isolated city bench did not mount this shop and
cannot establish retained-shop access. Keep the original failure receipts.

Read-only source survey **bodega_frontage_reconciliation_01/authority_survey_01.json**
measures shop world origin(18.655,0,2.125), city threshold(18.655,-11.92,0),
physical bounds X16.415..20.895/sourceY-12.07..+.78 and ceiling3.25/front3.55.
The installed template equals canonical exactly; receiving remains the same
shop instance. Preferred repair removes new city ground frontage and reserves
shop/receiving volume, preserving all shop boxes, entrance, counter and doors.
Hayden upper floors/12.8m body and roof stay fixed; profile3.55/3.25/3/3
preserves upper floor tops. Native review and actual controller rerun remain open.

SW2 native carriagehouse WIP is preserved/pushed at **28834fea** on the original
city branch; no SW2 Godot qualification. The same worktree now uses isolated
**codex/v2-city-bodega-fix-20261030**, from **fe4899a5**, for this urgent repair.
Published tally remains **21/149,128 remaining**. No authority bypass or new
acceptance claim. Shared Project tracker editor has been sent these facts.
''';p.write_text(s,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'tools/lint_design_doc.py','design/V2_CITY_CONTEXT_REPORT_2026-10-19.md'],cwd=root,check=True)
