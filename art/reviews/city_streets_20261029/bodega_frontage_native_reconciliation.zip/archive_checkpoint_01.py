from pathlib import Path
import json,hashlib,zipfile,subprocess,sys
root=Path('C:/ov/city');out=Path(__file__).parent
checks=json.loads((out/'native_clearance_review_03.json').read_text(encoding='utf-8'))
inspection={'evidence_class':'INERT','scope':'Human-visible native diagnostic review, no runtime/artistic acceptance','inspected_images':[],'findings':['Initial two full-front views cropped roof; retained and superseded by automatically framed02/03 views.','Native fixed Bodega frame and receiving room displayed in actual measured shop transform. Template boxes and closed-leaf marker remain neutral diagnostic context, not loaded shop appearance.','No new ground-front door or panes. Upper Hayden body remains distinct; roof silhouette retained.','246 native checks pass:186 reservation/template-box checks,44 receiving-native-bound checks,16 actual concrete/pier contact rays. Interior tolerance0.1mm; exact boundary bearing contacts allowed, no volume waiver.','No body/controller, loaded mipmap, LOD transition, current frame timing or artistic acceptance from this checkpoint. Original234/6/2 composed failure remains canonical-owned.'],'static_checks':{'fixtures':4,'fixture_failures':0,'tools_tests':14,'tools_test_failures':0,'reader_new':0,'uv_assets':2,'uv_surface_failures':0,'protected_unchanged':17}}
for p in sorted(out.glob('*.png')):inspection['inspected_images'].append({'path':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
assert len(inspection['inspected_images'])==10
(out/'actual_inspection_01.json').write_text(json.dumps(inspection,indent=2),encoding='utf-8',newline='\n')
(out/'setup_failures_01.json').write_text(json.dumps({'evidence_class':'INERT','failures':['setup_repair_01.py stopped reading TASKS.md under default cp1252 with UnicodeDecodeError before documentation writes; source/helper/plan edits had completed. Retried only remaining document steps with explicit UTF-8.','First inline retry had PowerShell quoting SyntaxError before execution. Literal here-string retry succeeded.','Initial apply_patch attempts matched partial long lines and made no changes.','Preflight was accidentally sampled during producer rebuild and correctly showed transient stale closure/helper bindings; final frozen four-fixture preflight passes.']},indent=2),encoding='utf-8')
files={p.name:p.read_bytes() for p in out.iterdir() if p.is_file() and p.suffix in ['.json','.png','.py','.log']}
for rel in ['art/blender/scripts/city_commercial_architecture.py','art/blender/scripts/build_city_elevations.py','art/blender/scripts/build_city_elevation_lods.py','art/data/city_elevations/source_plan.json','game/data/orison_v2/exterior/regions.json','game/data/orison_v2/exterior/exterior_geometry.json','game/tests/v2_city_elevation_bench.gd']:
 files['frozen_sources/'+rel]=(root/rel).read_bytes()
ziprel='art/reviews/city_streets_20261029/bodega_frontage_native_reconciliation.zip';zpath=root/ziprel
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 assert all(z.read(name)==data for name,data in files.items())
mp=root/'art/reviews/city_streets_20261029/manifest.json';manifest=json.loads(mp.read_text(encoding='utf-8'));entry={'path':ziprel,'sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'bytes':zpath.stat().st_size,'members':len(files),'evidence_class':'INERT','scope':'E-only native shop reservation repair;246 native checks,10 inspected views including original framing defects. No runtime or artistic acceptance.','files':{k:{'bytes':len(v),'raw_sha256':hashlib.sha256(v).hexdigest()} for k,v in sorted(files.items())}};manifest['bodega_frontage_native_reconciliation']=entry;mp.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
p=root/'design/V2_CITY_CONTEXT_REPORT_2026-10-19.md';s=p.read_text(encoding='utf-8');s+='''
Native repair checkpoint: E-only city geometry now reserves the retained shop
and receiving room, derived from actual registered sources; unsupported frame
drift fails the producer. No shop source, collision, location, leaf, counter or
back-room authority changed. Both near and replacement lower bodies reserve
this volume; the near body retains collision authority. New front beam starts
at3.55m and seats on actual retained piers. Upper side walls start3.25m; actual
3.26m cornice is included in the retained-box checks, not silently exempted.

Final native checks: **246/0** across near/lower:186 reservation/template-box
checks (91 actual boxes per body),44 actual receiving-native-bound checks and
16 concrete/pier contact rays. Open masks erode0.1mm to distinguish intended
boundary bearings; no volume waiver. Ten actual native views inspected; two
initial whole-body crops retained, superseded by bounded complete framing.
The existing fixed shop frame and receiving native meshes are included;
primitive retained-box/leaf context is neutral DIAGNOSTIC, not runtime appearance.
Near621 narrow-house stocks are closed/positive. Complete lower9809 stocks,
520 bearings and542 panes pass. Near106 roof/12 return/1205 bearing/2572 pane
samples pass. Four source preflights,14 tools tests and2-asset UV audit pass;
reader NEW0 and17 protected paths remain unchanged from the repair base.
261 near and130 lower unrelated parts (including west house) preserve exact
exported attributes,indices and transforms. Both E bodies retain13 material
parts; E pane count14 and scenic portal count0, family542 panes/24 portals.
No new runtime, loaded mipmap, LOD, frame-time, controller or artistic claim.
Canonical owner will run the short actual central Bodega door/inside/outside
route and isolated loaded checks after native intake; lane currently imagegen.
Archive: **bodega_frontage_native_reconciliation.zip**, indexed in the existing
review manifest with every member hash and CRC checked. Original failed composed
route stays canonical-owned and is not replaced by these native diagnostics.
''';p.write_text(s,encoding='utf-8',newline='\n')
p=root/'TASKS.md';s=p.read_text(encoding='utf-8');s=s.replace('Tally remains21/149.','Tally remains21/149. Native repair now passes246/0 clearance/contact checks,10 inspected views,4 preflights,14 tools tests and2-asset UV audit; actual Bodega door/controller and loaded/LOD checks remain open.');p.write_text(s,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'tools/lint_design_doc.py','design/V2_CITY_CONTEXT_REPORT_2026-10-19.md'],cwd=root,check=True)
print('ARCHIVE',entry['members'],entry['bytes'],entry['sha256'])
paths=['TASKS.md','design/V2_CITY_CONTEXT_REPORT_2026-10-19.md','art/blender/city_closure.blend','art/blender/city_closure_construction.json','art/blender/city_elevations.blend','art/blender/city_elevations_construction.json','art/blender/city_elevations_lod1.blend','art/blender/city_elevations_lod1_construction.json','art/blender/city_streets.blend','art/blender/city_streets_construction.json','art/blender/scripts/build_city_elevations.py','art/blender/scripts/build_city_elevation_lods.py','art/blender/scripts/city_commercial_architecture.py','art/data/city_elevations/source_plan.json','game/assets/props/city_elevations.glb','game/assets/props/city_elevations_lod1.glb','game/tests/fixtures/orison_city_closure.json','game/tests/fixtures/orison_city_elevations.json','game/tests/fixtures/orison_city_elevations_lod1.json','game/tests/fixtures/orison_city_streets.json','game/tests/v2_city_elevation_bench.gd',ziprel,'art/reviews/city_streets_20261029/manifest.json']
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--']+paths,cwd=root,check=True)
subprocess.run(['git','commit','-m','Fit Hayden city house around retained Bodega frontage and receiving room'],cwd=root,check=True)
subprocess.run(['git','push','-u','origin','codex/v2-city-bodega-fix-20261030'],cwd=root,check=True)
