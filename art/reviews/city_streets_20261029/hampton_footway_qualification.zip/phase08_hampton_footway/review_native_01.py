"""Independent native surface/soil controls and targeted near/lower renders."""
from pathlib import Path
import bpy,bmesh,json,hashlib,collections,math
from mathutils import Matrix,Vector
from mathutils.bvhtree import BVHTree
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent/'native_review_01';OUT.mkdir(exist_ok=False)
read=lambda p:json.loads((ROOT/p).read_text(encoding='utf-8'))
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'art/blender/city_streets.blend'))
for o in bpy.context.scene.objects:o.hide_render=True
near=list(bpy.data.collections['StreetExports_LOD0'].objects)
lower=list(bpy.data.collections['StreetExports_LOD1'].objects)
for i in range(2):bpy.data.collections['StreetClosed_LOD'+str(i)].hide_render=True
bpy.data.collections['StreetExports_LOD0'].hide_render=False
bpy.data.collections['StreetExports_LOD1'].hide_render=True
for o in near+lower:o.hide_set(False);o.hide_viewport=False;o.hide_render=False
def append(path,names,transform=Matrix.Identity(4)):
    with bpy.data.libraries.load(str(ROOT/path),link=False) as (available,loaded):
        assert set(names)<=set(available.objects);loaded.objects=names
    for o in loaded.objects:bpy.context.scene.collection.objects.link(o)
    bpy.context.view_layer.update()
    for o in loaded.objects:
        assert o.parent is None,o.name
        o.matrix_world=transform@o.matrix_world;o.hide_render=False;o.hide_set(False)
    bpy.context.view_layer.update();return loaded.objects
f=read('game/tests/fixtures/orison_city_elevations.json')
hampton=append('art/blender/city_elevations.blend',[r['name'] for r in f['parts'] if r['name'].startswith('site_far_nw__')])
door=next(r for r in read('game/data/orison_v2_blockout.json')['doors'] if r['id']=='F01_DOOR_06')
frame=read('game/data/orison_v2/exterior/street_frame.json')
transform=Matrix.Translation((0,-(door['center'][1]+frame['source_threshold_z']),0))@Matrix.Diagonal((-1,-1,1,1))
context=[]
for asset,fixture in [('orison_ground','orison_ground_construction'),('city_foundations','orison_city_foundations_construction')]:
    context+=append('art/blender/'+asset+'.blend',[r['id'] for r in read('game/tests/fixtures/'+fixture+'.json')['parts']],transform)
def tree(objects):
    vertices=[];faces=[];names=[]
    for o in objects:
        offset=len(vertices);vertices.extend(o.matrix_world@v.co for v in o.data.vertices)
        faces.extend(tuple(offset+i for i in p.vertices) for p in o.data.polygons);names.extend([o.name]*len(o.data.polygons))
    return BVHTree.FromPolygons(vertices,faces),names
street,names=tree(near);substrate,substrate_names=tree(context)
checks=[];failures=[]
def check(ok,label,**detail):
    r=dict(passed=bool(ok),label=label,**detail);checks.append(r)
    if not ok:failures.append(r)
for lod in range(2):
    for o in bpy.data.collections['StreetClosed_LOD'+str(lod)].objects:
        if 'Hampton' not in o.name:continue
        bm=bmesh.new();bm.from_mesh(o.data)
        check(all(e.is_manifold for e in bm.edges) and bm.calc_volume(signed=True)>0.,'reopened new closed positive stock',id=o.name);bm.free()
# Independent fixed stations, away from intentional four-millimetre joints.
for x,y,expected in [(-75.4,24.8,-.7365),(-75.4,25.2,-.7365),(-75.4,26.6,-.7365),(-93.7,26.6,-1.011),(-80.3,26.6,-.81),(-65.,26.6,-.5805)]:
    hit,n,index,d=street.ray_cast(Vector((x,y,1.)),Vector((0,0,-1)),4.)
    check(hit is not None and abs(hit.z-expected)<.0001 and n.z>.99,'actual connected graded public paving',xy=[x,y],expected=expected,actual=list(hit) if hit else None,owner=names[index] if hit else None)
for y,expected in [(27.74,-.67125),(28.02,-.537),(28.30,-.40275),(28.58,-.2685),(28.86,-.13425),(29.5,0.)]:
    hit,n,index,d=street.ray_cast(Vector((-80.,y,1.)),Vector((0,0,-1)),4.)
    check(hit is not None and abs(hit.z-expected)<.0001 and n.z>.999,'actual level stair tread or retained-floor landing',y=y,expected=expected,actual=list(hit) if hit else None,owner=names[index] if hit else None)
for x,y,z in [(-75.4,25.2,-1.1365),(-93.7,26.6,-1.411),(-65.,26.6,-.9805),(-80.,28.,-1.2235),(-80.,29.5,-1.2235)]:
    # A buried base is inside genuine closed soil/foundation mesh, not its AABB.
    up,un,ui,ud=substrate.ray_cast(Vector((x,y,z)),Vector((0,0,1)),5.)
    down,dn,di,dd=substrate.ray_cast(Vector((x,y,z)),Vector((0,0,-1)),5.)
    check(up is not None and down is not None and un.z>.9 and dn.z<-.9,'buried base lies inside actual native substrate',xyz=[x,y,z],upper=substrate_names[ui] if up else None,lower=substrate_names[di] if down else None)
(OUT/'native_controls.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Executed native geometric controls; no runtime or artistic acceptance.','checks':checks,'failures':failures},indent=2)+'\n')
assert not failures,failures
for image in bpy.data.images:
    if image.source=='FILE' and not image.packed_file:
        p=ROOT/'game/assets/building/textures'/Path(image.filepath).name
        assert p.is_file(),p;image.filepath=str(p);image.reload()
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.cycles.use_denoising=True
scene.render.threads_mode='FIXED';scene.render.threads=2
scene.render.resolution_x=1400;scene.render.resolution_y=900;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG'
scene.view_settings.view_transform='AgX';scene.world=bpy.data.worlds.new('Footway native review');scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.38,.45,.55,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.7
sun=bpy.data.objects.new('Review sun',bpy.data.lights.new('Review sun','SUN'));scene.collection.objects.link(sun)
sun.data.energy=2.5;sun.rotation_euler=Vector((.3,.5,-1)).to_track_quat('-Z','Y').to_euler()
camera=bpy.data.objects.new('Footway camera',bpy.data.cameras.new('Footway camera'));scene.collection.objects.link(camera);scene.camera=camera;camera.data.lens=32
renders=[]
for level in [0,1]:
    bpy.data.collections['StreetExports_LOD0'].hide_render=bool(level);bpy.data.collections['StreetExports_LOD1'].hide_render=not bool(level)
    for name,at,target in [('overview',(-105,12,14),(-80,28,1)),('stoop',(-83,24.2,2.2),(-80,28.8,-.1))]:
        camera.location=at;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
        p=OUT/(name+'_L'+str(level)+'.png');scene.render.filepath=str(p);bpy.ops.render.render(write_still=True)
        renders.append({'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'camera':list(at),'target':list(target),'scope':'Footway/stoop detail with actual retained native ground,foundation and Hampton context; whole building framing not asserted.'})
(OUT/'native_review.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Native review ready; images await actual inspection. Ground context retains its saved native preview. Runtime maps/LOD/collision/access and art acceptance pending.','checks':len(checks),'failures':failures,'renders':renders},indent=2)+'\n')
print('HAMPTON FOOTWAY NATIVE REVIEW:',len(checks),'checks;',len(failures),'failures;',len(renders),'renders')
