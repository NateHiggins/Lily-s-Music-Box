from pathlib import Path
__file__='C:\\ov\\city\\art\\blender\\scripts\\review_city_streets.py'
"""Reopen street, station and retained context; inspect physical supports."""
from pathlib import Path
import hashlib,json,math,os,sys
import bpy,bmesh
from mathutils import Matrix,Vector
from mathutils.bvhtree import BVHTree
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'game/project.godot').is_file());OUT=Path(os.environ['CITY_STREET_REVIEW']);OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(Path(__file__).parent))
from city_street_geometry import area,bounds,intersection,rectangle,grade_at

def read(p):return json.loads((ROOT/p).read_text())
def sha(p):
    raw=(ROOT/p).read_bytes();return hashlib.sha256(raw if Path(p).suffix in ['.blend','.glb'] else raw.replace(b'\r\n',b'\n')).hexdigest()
paths=['art/blender/city_streets.blend','art/blender/city_streets_construction.json','art/data/city_streets/source_plan.json','art/blender/city_transport.blend','art/blender/city_transport_construction.json','art/blender/scripts/review_city_streets.py','art/blender/scripts/city_street_geometry.py']
hashes={p:sha(p) for p in paths};meta=read(paths[1]);plan=read(paths[2]);station=read(paths[4]);checks=[];failures=[]
def check(ok,label,**detail):
    row=dict(passed=bool(ok),label=label,**detail);checks.append(row)
    if not ok:failures.append(row)
bpy.ops.wm.open_mainfile(filepath=str(ROOT/paths[0]))
for lod in range(2):
    source=bpy.data.collections['StreetClosed_LOD'+str(lod)];source.hide_render=True
    for obj in source.objects:
        bm=bmesh.new();bm.from_mesh(obj.data);check(all(e.is_manifold for e in bm.edges) and bm.calc_volume(signed=True)>0,'closed native street stock',id=obj.name);bm.free()
    bpy.data.collections['StreetExports_LOD'+str(lod)].hide_render=bool(lod)
near=list(bpy.data.collections['StreetExports_LOD0'].objects)

def load(relative,names,label,transform=Matrix.Identity(4)):
    with bpy.data.libraries.load(str(ROOT/relative),link=False) as (available,loaded):
        assert set(names)<=set(available.objects),(relative,set(names)-set(available.objects));loaded.objects=names
    col=bpy.data.collections.new(label);bpy.context.scene.collection.children.link(col)
    saved={obj.name:obj.location.copy() for obj in loaded.objects}
    for obj in loaded.objects:col.objects.link(obj)
    bpy.context.view_layer.update()
    for obj in loaded.objects:
        assert obj.parent is None and (obj.matrix_world.translation-saved[obj.name]).length<1e-7,(relative,obj.name)
        obj.matrix_world=transform@obj.matrix_world;obj.hide_render=False;obj.hide_set(False)
    bpy.context.view_layer.update();hashes[relative]=sha(relative)
    return list(col.objects)
# The separately reopened station geometry review owns closed-stock/stair
# checks. Its actual saved export partitions supply this composed PBR/BVH view.
station_exports=load('art/blender/city_transport.blend',list(read('game/data/orison_v2/exterior/city_transport.json')['parts']),'StationExportsContext')
layout=read('game/data/orison_v2_blockout.json');door=next(r for r in layout['doors'] if r['id']=='F01_DOOR_06');frame=read('game/data/orison_v2/exterior/street_frame.json');shift=-(door['center'][1]+frame['source_threshold_z'])
root_to_city=Matrix.Translation((0,shift,0))@Matrix.Diagonal((-1,-1,1,1))
front=read('game/tests/fixtures/orison_front_pavement_construction.json')
front_objects=load('art/blender/front_pavement.blend',[r['id'] for r in front['parts']],'RetainedFrontPaving',root_to_city)
paving_path='game/tests/fixtures/orison_street_paving_details.json'
paving=read(paving_path);hashes[paving_path]=sha(paving_path)
opposite_objects=load('art/blender/street_paving_details.blend',[r['id'] for r in paving['parts'] if r['kind']=='panel'],'RetainedOppositePaving',Matrix.Translation((0,-float(frame['source_threshold_z']),0)))

def tree(objects):
    verts=[];faces=[];names=[]
    for obj in objects:
        n=len(verts);verts.extend(obj.matrix_world@v.co for v in obj.data.vertices);faces.extend(tuple(n+i for i in p.vertices) for p in obj.data.polygons);names.extend([obj.name]*len(obj.data.polygons))
    return BVHTree.FromPolygons(verts,faces),names
ground_objects=[o for o in near if o.name.endswith(('__road','__walk'))]+[o for o in station_exports if o.name.endswith('__paving')]+front_objects+opposite_objects
ground,names=tree(ground_objects);road,_=tree([o for o in near if o.name.endswith('__road')]);all_geometry,all_names=tree(near+station_exports)
curb_tree,curb_names=tree([o for o in near if o.name.endswith('__curb')])
provider_samples=0
for row in paving['contacts']:
    if not str(row['owner']).startswith('passage_pavement_slab_'):continue
    p=row['point'];at=Vector((p[0],-p[2]-float(frame['source_threshold_z']),p[1]))
    hit,n,index,d=ground.ray_cast(at+Vector((0,0,.03)),Vector((0,0,-1)),.06)
    check(hit is not None and abs(hit.z-at.z)<.00003 and n.z>.99 and names[index]==row['owner'],'retained native pavement owns its original bearing sample',id=row['id'],point=list(at),actual_owner=names[index] if hit is not None else None)
    provider_samples+=1
check(provider_samples>0,'nonempty independent retained pavement contact roster',samples=provider_samples)
physical_seen=set()
stoop_samples=0
for row in meta['stocks']:
    if row['lod']!=0 or row['finish'] not in ['curb','cap']:continue
    if row['physical_id'] in physical_seen:continue
    physical_seen.add(row['physical_id'])
    p=row['physical_polygon'];center=Vector((sum(x for x,y in p)/len(p),sum(y for x,y in p)/len(p),0))
    if row['physical_id'].startswith('Stoop_'):
        # These are level stair stocks using the registered limestone finish,
        # not grade-relative curb courses seated on paving slabs.
        center.z=row['top_m']
        hit,n,index,d=all_geometry.ray_cast(center+Vector((0,0,.03)),Vector((0,0,-1)),.06)
        check(hit is not None and abs(hit.z-center.z)<.0001 and n.z>.999 and all_names[index].endswith('__curb'),'actual level public stair tread or landing',id=row['id'],point=list(center),owner=all_names[index] if hit is not None else None)
        stoop_samples+=1
        continue
    # A stone can bridge the authored four-millimetre slab joints. Test
    # distributed actual bearing points, not its outside rectangular AABB.
    probes=[center]+[center.lerp(Vector((x,y,0)),.55) for x,y in p]
    hits=[]
    for at in probes:
        at.z=row['bottom_m']+grade_at(at.x,plan['grade_profile_m'])
        support_tree,support_names=(ground,names) if row['finish']=='curb' else (curb_tree,curb_names)
        hit,n,index,d=support_tree.ray_cast(at+Vector((0,0,.015)),Vector((0,0,-1)),.04)
        if hit is not None and abs(hit.z-at.z)<.0001 and n.z>.99:hits.append(support_names[index])
    check(len(hits)>=min(3,len(probes)),'actual buried curb or cap bearing',id=row['id'],supports=sorted(set(hits)),samples=len(probes),supported=len(hits))
check(stoop_samples==sum(int(r['stoop_risers']) for r in plan.get('public_footways',[])),'complete public stair tread and landing roster',samples=stoop_samples)
for x in [-85,-76,-60,-44,-24,24,40,60,80,100,112]:
    for y in [-22.0,-19.3,-17.0]:
        grade=grade_at(x,plan['grade_profile_m'])
        hit,n,index,d=road.ray_cast(Vector((x,y,grade+.03)),Vector((0,0,-1)),.2)
        check(hit is not None and abs(hit.z+.1-grade)<.0001 and n.z>.99,'actual graded main road surface',x=x,y=y)
for x in meta['topology']['junction_x']:
    for y in [-35,-30,-26,-12,-6,0,8,16,23]:
        for dx in [-1.5,1.5]:
            grade=grade_at(x+dx,plan['grade_profile_m'])
            hit,n,index,d=road.ray_cast(Vector((x+dx,y,grade+.03)),Vector((0,0,-1)),.2)
            check(hit is not None and abs(hit.z+.1-grade)<.0001,'retained traffic lane supported through graded junction',x=x+dx,y=y)
for rect in meta['topology']['islands']:
    a,b,c,d=rect
    overlap_area=sum(area(intersection(p,rectangle(rect))) for p in meta['topology']['road'])
    check(overlap_area<1e-8,'road does not cut through protected pier footprint',rect=rect,overlap_m2=overlap_area)
# Independent source reservation checks: the entire near street body must
# have no positive polygon overlap with the fixed road or retained slab masks.
for row in meta['stocks']:
    if row['lod']==0 and row['finish']=='walk':
        overlaps=sum(area(intersection(row['polygon'],rectangle(r))) for r in meta['retained_footprints'])
        check(overlaps<1e-7,'new sidewalk respects retained occupied/paving footprint',id=row['id'],overlap_m2=overlaps)
    if row['lod']==0 and row['physical_id'].startswith(('Road_','Walk_')):
        variation=row['surface_high_m']-row['surface_low_m']
        check(row['top_m']-row['bottom_m']>variation+.02,'native paving body bridges bounded soil-air clearance with embedment',id=row['id'],grade_variation_m=variation,body_depth_m=row['top_m']-row['bottom_m'])
(OUT/'native_geometry_checks.json').write_text(json.dumps(dict(evidence_class='INERT',source_hashes=hashes,checks=checks,failures=failures),indent=2)+'\n')
assert not failures,failures[:12]


print('COMMON STREET NATIVE CONTROLS:',len(checks),'checks;',len(failures),'failures')
