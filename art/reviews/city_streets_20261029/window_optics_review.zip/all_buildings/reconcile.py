from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('C:/PleaseRemainOnTheLine');O=Path(__file__).parent;BASE='12aac6d7'
sys.path.insert(0,str(R/'tools'))
from preflight_spatial_test_bindings import check_fixture
def sha(b):return hashlib.sha256(b.replace(b'\r\n',b'\n')).hexdigest()
def old(p):return subprocess.check_output(['git','show',BASE+':'+p],cwd=R)
paths=[]
for folder in ['art/blender','game/tests/fixtures']:
    for path in (R/folder).glob('*.json'):
        data=json.loads(path.read_text(encoding='utf-8'))
        if isinstance(data,dict) and isinstance(data.get('source_bindings'),dict):paths.append(path)
fixtures=[p for p in paths if p.is_relative_to(R/'game/tests/fixtures')]
before={p.relative_to(R).as_posix():check_fixture(p,R) for p in fixtures}
changed={'game/scripts/building/orison_v2_city_shells.gd'};versions={};updates=[]
for _ in range(12):
    progressed=False
    for p in paths:
        data=json.loads(p.read_text(encoding='utf-8'));dirty=False
        for dep,value in data['source_bindings'].items():
            if dep not in changed:continue
            baseline=sha(old(dep));current=sha((R/dep).read_bytes())
            if value==current:continue
            if value not in {baseline,*versions.get(dep,set())}:continue # Keep pre-existing debt.
            updates.append({'record':p.relative_to(R).as_posix(),'dependency':dep,'before':value,'after':current})
            data['source_bindings'][dep]=current;dirty=True
        if dirty:
            rel=p.relative_to(R).as_posix();versions.setdefault(rel,set()).add(sha(p.read_bytes()))
            p.write_bytes((json.dumps(data,indent=2)+'\n').encode());changed.add(rel);progressed=True
    if not progressed:break
else:raise AssertionError('metadata closure did not converge')
after={p.relative_to(R).as_posix():check_fixture(p,R) for p in fixtures}
new={p:sorted(set(v)-set(before[p])) for p,v in after.items() if set(v)-set(before[p])}
assert not new,new
asset_proof={}
for rel in ['game/assets/props/city_elevations.glb','game/assets/props/city_elevations_lod1.glb']:
    current=(R/rel).read_bytes();assert hashlib.sha256(current).digest()==hashlib.sha256(old(rel)).digest();asset_proof[rel]=hashlib.sha256(current).hexdigest()
record={'evidence_class':'INERT','base':BASE,'changes':updates,'unchanged_native_assets':asset_proof,'fixture_count':len(fixtures),'new_errors':new,'original_errors':{p:e for p,e in before.items() if e},'remaining_errors':{p:e for p,e in after.items() if e}}
(O/'source_reconciliation.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(len(updates),'metadata bindings;',len(fixtures),'fixture checks;',len(new),'new errors; two native assets byte-exact')
