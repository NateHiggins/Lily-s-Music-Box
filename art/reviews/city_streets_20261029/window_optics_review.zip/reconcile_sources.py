from pathlib import Path
import ast, hashlib, json, subprocess, sys
R=Path('C:/PleaseRemainOnTheLine'); O=Path(__file__).parent
BASE='1d62881e0cbe5eeab4d9c3f0878cd64a5282b6ae'
sys.path.insert(0,str(R/'tools'))
from preflight_spatial_test_bindings import check_fixture
def old(p): return subprocess.check_output(['git','show',BASE+':'+p],cwd=R)
def read(p): return (R/p).read_bytes()
def sha(b): return hashlib.sha256(b.replace(b'\r\n',b'\n')).hexdigest()
def parse(p): return json.loads(read(p))
runtime='game/data/orison_v2/exterior/city_horizon.json'
builder='art/blender/scripts/build_city_horizon.py'
loader='game/scripts/building/orison_v2_city_horizon.gd'
before=json.loads(old(runtime)); now=parse(runtime)
stripped=json.loads(json.dumps(now))
for row in stripped['buildings']: row.pop('window_typology')
assert stripped==before
tree=ast.parse(read(builder)); removed=0
for node in ast.walk(tree):
    for field,value in ast.iter_fields(node):
        if not isinstance(value,list):continue
        for child in list(value):
            if isinstance(child,ast.Assign) and len(child.targets)==1 and isinstance(child.targets[0],ast.Subscript):
                t=child.targets[0]
                if isinstance(t.value,ast.Name) and t.value.id=='profile' and isinstance(t.slice,ast.Constant) and t.slice.value=='window_typology':
                    value.remove(child);removed+=1
assert removed==1 and ast.dump(tree)==ast.dump(ast.parse(old(builder)))
lines=iter(read(loader).decode().splitlines())
for line in old(loader).decode().splitlines(): assert any(candidate==line for candidate in lines),line
assert read('art/data/city_horizon/source_plan.json').replace(b'\r\n',b'\n')==old('art/data/city_horizon/source_plan.json').replace(b'\r\n',b'\n')
fixture=parse('game/tests/fixtures/orison_city_horizon.json')
assets=[]
for asset in fixture['assets'].values():
    path=asset['asset']; digest=hashlib.sha256(read(path)).hexdigest()
    assert digest==asset['sha256'],path
    assets.append({'path':path,'sha256':digest})
fixtures=[p for p in (R/'game/tests/fixtures').glob('*.json') if isinstance(json.loads(p.read_text(encoding='utf-8')),dict) and json.loads(p.read_text(encoding='utf-8')).get('source_bindings')]
original={p.relative_to(R).as_posix():check_fixture(p,R) for p in fixtures}
changes=[]
for path in ['art/blender/city_horizon_construction.json','game/tests/fixtures/orison_city_horizon.json']:
    data=parse(path); baseline=json.loads(old(path)); assert data==baseline
    for dependency in [runtime,builder,loader]:
        previous=data['source_bindings'][dependency]; value=sha(read(dependency))
        data['source_bindings'][dependency]=value
        changes.append({'record':path,'dependency':dependency,'before':previous,'after':value})
    (R/path).write_bytes((json.dumps(data,indent=2)+'\n').encode())
# The street builder's horizon reference only declares source metadata. Its
# code, native outputs, every consumed horizon fact and all other inputs stay exact.
assert read('art/blender/scripts/build_city_streets.py').replace(b'\r\n',b'\n')==old('art/blender/scripts/build_city_streets.py').replace(b'\r\n',b'\n')
for path in ['art/blender/city_streets_construction.json','game/tests/fixtures/orison_city_streets.json']:
    data=parse(path); assert data==json.loads(old(path))
    key='art/blender/city_horizon_construction.json'; previous=data['source_bindings'][key]
    data['source_bindings'][key]=sha(read(key));changes.append({'record':path,'dependency':key,'before':previous,'after':data['source_bindings'][key]})
    (R/path).write_bytes((json.dumps(data,indent=2)+'\n').encode())
after={p.relative_to(R).as_posix():check_fixture(p,R) for p in fixtures}
new={p:sorted(set(errors)-set(original[p])) for p,errors in after.items() if set(errors)-set(original[p])}
record={'evidence_class':'INERT','base':BASE,'scope':'native-geometry consumed projection and metadata bindings only; no runtime receipt renewal','assets_unchanged':assets,'changes':changes,'preflight_before':{p:e for p,e in original.items() if e},'preflight_after':{p:e for p,e in after.items() if e},'new_errors':new}
(O/'source_reconciliation.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
assert not new,new
print('source projection retained;',len(assets),'native assets;',len(changes),'declared bindings;',len(fixtures),'fixture preflights; no new errors')
