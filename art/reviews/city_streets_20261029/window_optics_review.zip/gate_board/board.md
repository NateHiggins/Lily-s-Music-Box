# Gate board - b8b465576082

- commit `b8b4655760823e132df9b1e5f6d8ae4839c9b458`
- tree `d81596d63d195c183b2cbb4e2a8f0b904dfa66b5`
- created 2026-10-31T15:10:04Z
- dirty paths: 684

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| physical_import_sources | PASS | 0 | 1.8 | no defects counted |
| v2_recipe_projections | PASS | 0 | 0.66 | no defects counted |
| v2_surface_qualification | FAIL | 1 | 25.28 | defects 3 |
| v2_mesh_uv_imports | PASS | 0 | 0.26 | no defects counted |
| v2_surface_imports | PASS | 0 | 6.33 | no defects counted |
| ledger | INCOMPLETE | 2 | 61.25 | blockers 7 / 8 / 110 / 42 / 134 / 136; requirements 240 |
| spatial | PASS | 0 | 14.53 | drift.new_reported 3 |
| systemic | PASS | 0 | 14.0 | drift.new_review 29 |
| period | PASS | 0 | 1.94 | no defects counted |
| reader | PASS | 0 | 4.58 | unread 1060; vs frozen baseline: new 0, resolved 248 |
| carriers | PASS | 0 | 0.98 | ambiguous_dynamic 2 |
| rulings | PASS | 0 | 125.44 | no defects counted |
| test:test_additive_material_bindings | PASS | 0 | 0.8 | ran 7, failed 0 |
| test:test_additive_material_rebind | PASS | 0 | 0.2 | ran 13, failed 0 |
| test:test_arcade_canopy_shells | PASS | 0 | 0.47 | ran 3, failed 0 |
| test:test_arcade_clock | PASS | 0 | 0.56 | ran 4, failed 0 |
| test:test_arcade_lantern | PASS | 0 | 0.42 | ran 4, failed 0 |
| test:test_astra_packet | PASS | 0 | 2.91 | ran 10, failed 0 |
| test:test_audio_emitters | PASS | 0 | 6.7 | ran 6, failed 0 |
| test:test_audit_newspapers | PASS | 0 | 0.5 | ran 13, failed 0 |
| test:test_binding_relief | PASS | 0 | 1.72 | ran 3, failed 0 |
| test:test_campaign_weather | PASS | 0 | 0.22 | ran 7, failed 0 |
| test:test_check_mystery_dialogue | PASS | 0 | 0.95 | ran 10, failed 0 |
| test:test_check_rulings | PASS | 0 | 1.56 | ran 8, failed 0 |
| test:test_city_closure_source | PASS | 0 | 0.97 | ran 5, failed 0 |
| test:test_city_ground_apron | PASS | 0 | 3.3 | ran 14, failed 0 |
| test:test_city_horizon | PASS | 0 | 0.36 | ran 4, failed 0 |
| test:test_city_horizon_shards | PASS | 0 | 0.22 | ran 8, failed 0 |
| test:test_city_street_geometry | PASS | 0 | 1.33 | ran 3, failed 0 |
| test:test_construction_shed_plan | PASS | 0 | 0.22 | ran 4, failed 0 |
| test:test_construction_shed_uv | PASS | 0 | 0.42 | ran 5, failed 0 |
| test:test_data_consumption | PASS | 0 | 20.55 | ran 29, failed 0 |
| test:test_domestic_objects_bounded_preflight | PASS | 0 | 0.38 | ran 5, failed 0 |
| test:test_gate_board | PASS | 0 | 0.83 | ran 17, failed 0 |
| test:test_godot_engine_selection | PASS | 0 | 1.23 | ran 1, failed 0 |
| test:test_grade_source_snapshot | PASS | 0 | 0.27 | ran 3, failed 0 |
| test:test_heating_pipe_fittings | PASS | 0 | 0.12 | ran 3, failed 0 |
| test:test_honed_stone_maps | PASS | 0 | 0.86 | ran 4, failed 0 |
| test:test_house_switchboard_native | PASS | 0 | 0.17 | ran 5, failed 0 |
| test:test_ingest_retirement | PASS | 0 | 0.56 | ran 3, failed 0 |
| test:test_interaction_implementors | FAIL | 1 | 1.08 | ran 31, failed 1 |
| test:test_interaction_prompt_carriers | FAIL | 1 | 1.23 | ran 28, failed 1 |
| test:test_lane_queue | PASS | 0 | 20.19 | ran 5, failed 0 |
| test:test_lanes | PASS | 0 | 9.19 | ran 6, failed 0 |
| test:test_lint_design_doc | PASS | 0 | 0.5 | ran 9, failed 0 |
| test:test_m11c0_floor01_harness_contract | PASS | 0 | 0.41 | ran 5, failed 0 |
| test:test_m11c1_floor01_source_ownership | FAIL | 1 | 2.62 | ran 11, failed 11 |
| test:test_m11c1_owner_first_export | PASS | 0 | 0.39 | ran 11, failed 0 |
| test:test_m11c1_runtime_rehearsal | PASS | 0 | 26.91 | ran 19, failed 0 |
| test:test_m11c1_scanner_consumer_adapter | PASS | 0 | 0.34 | ran 7, failed 0 |
| test:test_m11c2_floor01_production_export | FAIL | 1 | 8.84 | ran 11, failed 1 |
| test:test_m11c2_production_harness_contract | PASS | 0 | 0.59 | ran 22, failed 0 |
| test:test_material_catalog_persistence | PASS | 0 | 1.0 | ran 1, failed 0 |
| test:test_material_relief | PASS | 0 | 0.7 | ran 5, failed 0 |
| test:test_nook_readable_books | PASS | 0 | 0.28 | ran 4, failed 0 |
| test:test_orison_floor01_source_ownership | PASS | 0 | 0.42 | ran 13, failed 0 |
| test:test_orison_spatial_dependencies | PASS | 0 | 12.12 | ran 59, failed 0 |
| test:test_orison_v2_completeness | FAIL | 1 | 80.86 | ran 109, failed 2 |
| test:test_period_dates | PASS | 0 | 0.73 | ran 5, failed 0 |
| test:test_physical_import_sources | PASS | 0 | 1.66 | ran 6, failed 0 |
| test:test_prop_reference | PASS | 0 | 0.66 | ran 23, failed 0 |
| test:test_prop_review | PASS | 0 | 0.36 | ran 4, failed 0 |
| test:test_readable_library | PASS | 0 | 0.94 | ran 4, failed 0 |
| test:test_rehearse_orison_floor01_partition | PASS | 0 | 0.44 | ran 5, failed 0 |
| test:test_room_checkpoint_linter | PASS | 0 | 2.78 | ran 29, failed 0 |
| test:test_room_checkpoint_reconciler | PASS | 0 | 0.91 | ran 38, failed 0 |
| test:test_room_evidence_verifier | PASS | 0 | 12.8 | ran 34, failed 0 |
| test:test_room_gate_hook | PASS | 0 | 69.14 | ran 24, failed 0 |
| test:test_room_layout_workbench | PASS | 0 | 11.02 | ran 35, failed 0 |
| test:test_room_reconstruction_gate | PASS | 0 | 56.7 | ran 26, failed 0 |
| test:test_room_reconstruction_progress | PASS | 0 | 35.97 | ran 24, failed 0 |
| test:test_run_receipt | PASS | 0 | 1.7 | ran 11, failed 0 |
| test:test_runtime_source_projections | PASS | 0 | 0.22 | ran 4, failed 0 |
| test:test_site_softwood_maps | PASS | 0 | 0.8 | ran 2, failed 0 |
| test:test_spatial_access_evidence | PASS | 0 | 0.47 | ran 9, failed 0 |
| test:test_spatial_binding_preflight | PASS | 0 | 0.41 | ran 13, failed 0 |
| test:test_spatial_connection_evidence | PASS | 0 | 0.53 | ran 14, failed 0 |
| test:test_spatial_region_evidence | PASS | 0 | 3.51 | ran 19, failed 0 |
| test:test_systemic_situation_authority | PASS | 0 | 9.58 | ran 63, failed 0 |
| test:test_upper_daylight_contract | PASS | 0 | 0.19 | ran 1, failed 0 |
| test:test_v2_acoustic_flue | PASS | 0 | 0.39 | ran 10, failed 0 |
| test:test_v2_acoustic_heating | PASS | 0 | 0.39 | ran 10, failed 0 |
| test:test_v2_acoustic_ownership | PASS | 0 | 0.17 | ran 15, failed 0 |
| test:test_v2_acoustic_ventilation | PASS | 0 | 0.25 | ran 8, failed 0 |
| test:test_v2_audit_digest_snapshot | PASS | 0 | 0.44 | ran 10, failed 0 |
| test:test_v2_authoring_projection | PASS | 0 | 1.44 | ran 8, failed 0 |
| test:test_v2_boiler_inlet_projection | PASS | 0 | 0.41 | ran 3, failed 0 |
| test:test_v2_c_stove_stack_plan | PASS | 0 | 0.25 | ran 10, failed 0 |
| test:test_v2_completion_projection | PASS | 0 | 0.44 | ran 4, failed 0 |
| test:test_v2_door_frame_mitres | PASS | 0 | 0.14 | ran 3, failed 0 |
| test:test_v2_exterior_source | PASS | 0 | 0.14 | ran 10, failed 0 |
| test:test_v2_fabrication_batch | PASS | 0 | 0.39 | ran 6, failed 0 |
| test:test_v2_flue_airway_plan | PASS | 0 | 0.17 | ran 5, failed 0 |
| test:test_v2_flue_native_evidence | PASS | 0 | 25.86 | ran 1, failed 0 |
| test:test_v2_front_lighting_plan | PASS | 0 | 0.23 | ran 9, failed 0 |
| test:test_v2_front_lighting_projection | PASS | 0 | 0.55 | ran 7, failed 0 |
| test:test_v2_front_trim | PASS | 0 | 0.69 | ran 5, failed 0 |
| test:test_v2_ground_probe_updates | PASS | 0 | 0.17 | ran 3, failed 0 |
| test:test_v2_heating_branch_supports | PASS | 0 | 0.14 | ran 3, failed 0 |
| test:test_v2_heating_envelopes | PASS | 0 | 0.23 | ran 8, failed 0 |
| test:test_v2_heating_interfaces | PASS | 0 | 0.17 | ran 10, failed 0 |
| test:test_v2_heating_refit_projection | PASS | 0 | 0.34 | ran 10, failed 0 |
| test:test_v2_heating_routes | PASS | 0 | 0.2 | ran 8, failed 0 |
| test:test_v2_heating_takeoff | PASS | 0 | 0.28 | ran 7, failed 0 |
| test:test_v2_physical_inputs | PASS | 0 | 1.81 | ran 11, failed 0 |
| test:test_v2_public_landing_footprints | PASS | 0 | 0.28 | ran 8, failed 0 |
| test:test_v2_public_landing_programmes | PASS | 0 | 0.52 | ran 11, failed 0 |
| test:test_v2_public_regions | PASS | 0 | 0.41 | ran 7, failed 0 |
| test:test_v2_radiator_vent_thread | PASS | 0 | 0.19 | ran 2, failed 0 |
| test:test_v2_recipe_projections | PASS | 0 | 0.17 | ran 5, failed 0 |
| test:test_v2_retained_grade_plan | PASS | 0 | 0.41 | ran 9, failed 0 |
| test:test_v2_roof | PASS | 0 | 0.58 | ran 4, failed 0 |
| test:test_v2_service_entries | PASS | 0 | 0.47 | ran 7, failed 0 |
| test:test_v2_spatial_publication | PASS | 0 | 0.66 | ran 11, failed 0 |
| test:test_v2_surface_publication | PASS | 0 | 0.34 | ran 6, failed 0 |
| test:test_v2_surface_requirements | PASS | 0 | 233.44 | ran 42, failed 0 |
| test:test_v2_test_dependency_literals | PASS | 0 | 0.23 | ran 2, failed 0 |
| test:test_v2_ventilation_fabric_projection | PASS | 0 | 0.34 | ran 3, failed 0 |
| test:test_verify_candidate | PASS | 0 | 3.27 | ran 19, failed 0 |

## Against 1d62881e0cbe

Verdict: **REGRESSED**

requirements_changed: []

### Regressions (6)

- spatial: drift.new_reported 0 -> 3
- spatial: new defect new_reported:34a8b9e61652d8f4
- spatial: new defect new_reported:35d3d9b4b7879d5a
- spatial: new defect new_reported:aa6382cddc43a972
- v2_surface_qualification: defects 2 -> 3
- v2_surface_qualification: new defect runtime contract does not bind the current surface test

### Improvements (0)

- none

### Other changes (0)

- none

