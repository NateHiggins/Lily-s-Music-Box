$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'C:/ov/city'
$env:ORISON_SCRIPT_CHECK = '["res://scripts/building/orison_v2_city_horizon.gd","res://tests/v2_city_horizon_bench.gd"]'
$env:CITY_STUDY_CAPTURE = '1'
$env:CITY_STUDY_IDS = 'HORIZON_NEAR_2_0_P1,HORIZON_NEAR_2_1_P2,HORIZON_FAR_2_1_P1'
$env:CITY_INDUSTRIAL_PROFILE = '1'
$env:CITY_INDUSTRIAL_ENTRY = '1'
& pwsh -File tools/lane.ps1 batch -BatchFile C:/ov/reports/city_streets_20261029/east_industrial_01/loaded_batch_01.json -WaitMinutes 30
exit $LASTEXITCODE
