from pathlib import Path
import ast,subprocess,struct,json,numpy as np,collections,itertools
root=Path.cwd();out=Path('C:/ov/reports/city_streets_20261029/east_industrial_01');identity='HORIZON_FAR_2_1_P0';s=Path('C:/ov/reports/city_streets_20261029/rear_apartment_01/check_preservation_02.py').read_text(encoding='utf-8').replace('site_back_w',identity);t=ast.parse(s);exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='triangles'],type_ignores=[]),'<actual independent float32 triangle reader>','exec'))
a=triangles(subprocess.run(['git','show','28e3446b:game/assets/props/city_horizon_far.glb'],capture_output=True,check=True).stdout);b=triangles((root/'game/assets/props/city_horizon_far.glb').read_bytes());catalog=[];cells=collections.defaultdict(list);tol=.0001;shifts=list(itertools.product([-1,0,1],repeat=3));max_error=0.
def vertex(v):
 global max_error
 cell=tuple(np.floor(v/tol).astype(int));best=None;error=tol
 for shift in shifts:
  for j in cells.get(tuple(cell[i]+shift[i] for i in range(3)),[]):
   e=float(np.abs(v-catalog[j]).max())
   if e<error:best=j;error=e
 if best is not None:max_error=max(max_error,error);return best
 j=len(catalog);catalog.append(v);cells[cell].append(j);return j
rows=[]
for name in sorted(a):
 aa=collections.Counter(tuple(sorted(vertex(v) for v in tri)) for tri in a[name]);bb=collections.Counter(tuple(sorted(vertex(v) for v in tri)) for tri in b[name]);old=aa-bb;new=bb-aa;changed=list(old)+list(new)
 for key in changed:
  tri=np.array([catalog[i] for i in key]);assert tri[:,1].min()>=-60.762-tol and tri[:,1].max()<=-60.57+tol and tri[:,2].min()>=16-tol and tri[:,2].max()<=19.2+tol,(name,tri.tolist())
 rows.append({'part':name,'matched_triangles':sum((aa&bb).values()),'removed_triangles':sum(old.values()),'added_triangles':sum(new.values()),'all_changes_confined_to_original_top_storey_party_face':True})
r={'evidence_class':'INERT','scope':'Only dependent generic neighbour change: taller Walters-derived body closes the old exposed top-storey party-face windows. Exact source profile unchanged;all other old/new world triangles match within original0.1mm tolerance. Face envelope nativeY−60.762..−60.57,Z16..19.2. Not visual/runtime acceptance.','rows':rows,'max_vertex_recentring_m':max_error};(out/'dependent_party_wall_01.json').write_text(json.dumps(r,indent=2),encoding='utf-8',newline='\n');print('Dependent party-wall delta scoped:',rows,'maxrecenter',max_error)
