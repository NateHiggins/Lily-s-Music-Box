from pathlib import Path
import bpy,json,hashlib,collections,math
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
ROOT=Path("C:/ov/city");OUT=Path(__file__).parent/"native_controls_03";OUT.mkdir(exist_ok=False)
IDS=["HORIZON_NEAR_2_0_P1","HORIZON_NEAR_2_1_P2","HORIZON_FAR_2_1_P1"]
NEIGHBOUR="HORIZON_FAR_2_1_P0"
profiles={r["id"]:r for r in json.loads((ROOT/"art/data/city_horizon/source_plan.json").read_text(encoding="utf-8"))["buildings"]}
bindings={};roundtrips=[];captures=[]
def triangles(o):
 o.data.calc_loop_triangles()
 return collections.Counter(tuple(sorted(tuple(float(c) for c in o.matrix_world@o.data.vertices[i].co) for i in t.vertices)) for t in o.data.loop_triangles)
for family,collection,chosen in [("city_horizon_near","CityHorizon_near",IDS[:2]),("city_horizon_far","CityHorizon_far",[IDS[2],NEIGHBOUR]),("city_horizon_lod1","CityHorizonReplacementBodies",IDS)]:
 native=ROOT/f"art/blender/{family}.blend";bindings[native.relative_to(ROOT).as_posix()]=hashlib.sha256(native.read_bytes()).hexdigest();bpy.ops.wm.open_mainfile(filepath=str(native))
 original=[o for o in bpy.data.collections[collection].objects if o.name.split("__")[0] in chosen]
 expected={o.name:triangles(o) for o in original};mats={o.name:o.data.materials[0] for o in original}
 for o in bpy.context.scene.objects:
  if o.type=="MESH":o.hide_render=True
 asset=ROOT/f"game/assets/props/{family}.glb";bindings[asset.relative_to(ROOT).as_posix()]=hashlib.sha256(asset.read_bytes()).hexdigest();before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(asset));bpy.context.view_layer.update();imported=[]
 for o in [o for o in bpy.data.objects if o not in before and o.type=="MESH"]:
  name=o.name.split(".")[0];o.hide_render=name not in expected
  if o.hide_render:continue
  assert triangles(o)==expected[name],(family,name,"roundtrip mismatch")
  assert len(o.data.uv_layers)==1;o.data.uv_layers.active.name="Metres";o.data.materials.clear();o.data.materials.append(mats[name]);imported.append((name,o))
  roundtrips.append(dict(family=family,part=name,exact_float32_triangle_positions=True,triangles=sum(expected[name].values())))
 assert len(imported)==len(expected)
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
construction=json.loads((ROOT/'art/blender/city_horizon_construction.json').read_text(encoding='utf-8'))
vertices=[];faces=[];owners=[]
for name,o in imported:
 start=len(vertices);vertices.extend(o.matrix_world@v.co for v in o.data.vertices)
 o.data.calc_loop_triangles();faces.extend(tuple(start+i for i in f.vertices) for f in o.data.loop_triangles);owners.extend([name]*len(o.data.loop_triangles))
tree=BVHTree.FromPolygons(vertices,faces,all_triangles=True);panes=0;roof_controls=0;seam_controls=0;combined_contacts=[]
for row in construction['window_rows']:
 if row['building'] not in IDS:continue
 point=Vector(row['point']);normal=Vector(row['normal']);hit,n,index,distance=tree.ray_cast(point+normal*.05,-normal,.3)
 assert hit is not None and (hit-(point-normal*row['recess_m'])).length<.0001 and owners[index]==row['building']+'__mirror_aged',('lower pane',row)
 panes+=1
for row in construction['parapet_contacts']:
 if row['building'] not in IDS:continue
 roof=next(o for name,o in imported if name==row['building']+'__galvanized_roof');roof.data.calc_loop_triangles();roof_tree=BVHTree.FromPolygons([roof.matrix_world@v.co for v in roof.data.vertices],[tuple(f.vertices) for f in roof.data.loop_triangles],all_triangles=True)
 point=Vector(row['point']);hit,n,index,distance=roof_tree.ray_cast(point+Vector((0,0,.02)),Vector((0,0,-1)),.04)
 assert hit is not None and (hit-point).length<.0001,('lower roof support',row)
 combined,normal,face,distance=tree.ray_cast(point+Vector((0,0,.02)),Vector((0,0,-1)),.04)
 combined_contacts.append(dict(building=row['building'],point=list(point),first_owner=owners[face] if combined is not None else None,first_error_m=(combined-point).length if combined is not None else None))
 wall=next(o for name,o in imported if name==row['building']+'__'+row['wall_key']);wall.data.calc_loop_triangles();wall_tree=BVHTree.FromPolygons([wall.matrix_world@v.co for v in wall.data.vertices],[tuple(f.vertices) for f in wall.data.loop_triangles],all_triangles=True)
 hit,normal,index,distance=wall_tree.ray_cast(point-Vector((0,0,.02)),Vector((0,0,1)),.04)
 assert hit is not None and (hit-point).length<.0001,('lower bearing underside',row)
 outside=Vector(row['outside_probe']);hit,n,index,distance=roof_tree.ray_cast(outside+Vector((0,0,.02)),Vector((0,0,-1)),.04)
 assert hit is None,('lower outside control',row)
 roof_controls+=1
for study in construction['industrial_checks']:
 obj=next(o for name,o in imported if name==study['building']+'__cast_iron');kd=KDTree(len(obj.data.vertices))
 for i,v in enumerate(obj.data.vertices):kd.insert(obj.matrix_world@v.co,i)
 kd.balance()
 for seam in study['mitre_seams']:
  for points in seam['interfaces'].values():
   for point in points:
    co,index,distance=kd.find(Vector(point));assert distance<.00002,('lower mitre interface',study['building'],point,distance);seam_controls+=1
(OUT/'lower_controls_03.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Actual imported replacement mesh BVH pane first hits, separate roof top and bearing underside contacts/outside controls, and exported full-depth mitre interface vertices;not runtime or artistic acceptance.',panes=panes,roof_seats=roof_controls,bearing_undersides=roof_controls,outside_controls=roof_controls,mitre_interface_points=seam_controls,combined_contact_diagnostics=combined_contacts,failures=[]),indent=2),encoding='utf-8',newline='\n')
assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in bindings.items())
(OUT/"native_controls_03.json").write_text(json.dumps(dict(evidence_class="INERT",scope="Actual native/export float32 triangle roundtrips and lower replacement controls,without rendering. Images retained separately from native_review_02. Not runtime or artistic acceptance.",bindings=bindings,roundtrip=roundtrips,captures=captures),indent=2),encoding="utf-8",newline="\n")
print("INDUSTRIAL_NATIVE_REVIEW",len(captures),len(roundtrips),flush=True)
