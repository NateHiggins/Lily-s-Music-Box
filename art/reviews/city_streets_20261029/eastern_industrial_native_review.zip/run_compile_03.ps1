$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'C:/ov/city'
$env:ORISON_SCRIPT_CHECK = '["res://tests/v2_city_horizon_bench.gd"]'
& pwsh -File tools/lane.ps1 run -Scene res://tests/CompileChangedScripts.tscn -Runner serial -LogPath C:/ov/reports/city_streets_20261029/east_industrial_01/parser_03.log -TimeoutSeconds 120 -WaitMinutes 30
exit $LASTEXITCODE
