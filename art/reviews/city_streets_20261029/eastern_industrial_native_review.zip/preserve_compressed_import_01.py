from pathlib import Path
import json,hashlib,re,datetime
root=Path('C:/ov/city');e=Path(__file__).parent
original=e/'city_horizon_lod1_before_compression_01.import'
s=original.read_text(encoding='utf-8');assert 'meshes/force_disable_compression=false' in s
relative=re.search(r'^path="res://(.+)"$',s,re.M)[1]
source=root/'game'/relative;target=e/'compressed_import_01.scn'
assert source.is_file() and not target.exists()
receipt=json.loads((e/'bench_01.log.receipt.json').read_text(encoding='utf-8'))
finish=datetime.datetime.fromisoformat(receipt['execution']['finished_utc'].replace('Z','+00:00')).timestamp()
assert source.stat().st_mtime<finish,('cache already reimported',source.stat().st_mtime,finish)
data=source.read_bytes();target.write_bytes(data)
r=dict(evidence_class='INERT',scope='Original Godot compressed PackedScene,containing the imported arrays that failed bench_01;preserved before new import. No runtime promotion.',source=source.as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),mtime_utc=datetime.datetime.fromtimestamp(source.stat().st_mtime,datetime.timezone.utc).isoformat(),first_run_finished_utc=receipt['execution']['finished_utc'],glb_sha256=hashlib.sha256((root/'game/assets/props/city_horizon_lod1.glb').read_bytes()).hexdigest(),original_sidecar_sha256=hashlib.sha256(original.read_bytes()).hexdigest())
(e/'compressed_import_01.json').write_text(json.dumps(r,indent=2),encoding='utf-8',newline='\n')
print(r)
