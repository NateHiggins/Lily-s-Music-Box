from pathlib import Path
import json,hashlib,re,difflib,subprocess
root=Path('C:/ov/city');e=Path(__file__).parent;p=root/'game/tests/v2_city_horizon_bench.gd'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
before=p.read_text(encoding='utf-8');bound=json.loads((e/'loaded_inspection_02.json').read_text(encoding='utf-8'))['frozen_inputs']['game/tests/v2_city_horizon_bench.gd'];assert hashlib.sha256(p.read_bytes()).hexdigest()==bound
body=before.split('func _industrial_passage(',1)[1].split('\nfunc _industrial_entry_sources',1)[0]
assert len(re.findall(r'\bstarted\b',body))==2 and body.count('"elapsed_s"')==1
old_start='var started:=Time.get_ticks_usec();var first_check:=checks;var first_failure:=failures.size()'
new_start='var first_check:=checks;var first_failure:=failures.size()'
old_field='"elapsed_s":(Time.get_ticks_usec()-started)/1000000.,'
assert before.count(old_start)==before.count(old_field)==1
after=before.replace(old_start,new_start,1).replace(old_field,'',1)
new_body=after.split('func _industrial_passage(',1)[1].split('\nfunc _industrial_entry_sources',1)[0]
assert not re.search(r'\bstarted\b|"elapsed_s"|Time\.get_ticks_usec',new_body)
assert before.split('func _profile_industrial',1)[1].split('\nfunc _industrial_passage',1)[0]==after.split('func _profile_industrial',1)[1].split('\nfunc _industrial_passage',1)[0]
snapshot=e/'bench_02_executed_source.gd';assert not snapshot.exists();snapshot.write_bytes(p.read_bytes())
p.write_text(after,encoding='utf-8',newline='\n')
record=dict(evidence_class='INERT',scope='Coordinated diagnostic metadata cleanup only. Removes unused host start counter and optional elapsed_s JSONfield;does not change1350 actualrender frame timings,normalcontroller movement/collision checks,thresholds,body meshes,loader/import/sourceplan or old receipts. No new optics/played/runtime qualification claimed. Original23.363073s remains in the original executed-source/receipt packet.',source_before_sha256=bound,source_after_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),removed_counter_uses_before=2,removed_counter_uses_after=0,old_source_snapshot=snapshot.name,original_profile_timing_and_drive_source_unchanged=True,exact_allowed_delta=[dict(old=old_start,new=new_start),dict(old=old_field,new='')],unified_diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='executed962',tofile='metadata_cleanup03')))
(e/'metadata_cleanup_delta_03.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print('Onlyunused passage started/elapsed_s removed;allrender/drive/check source unchanged;originalsource preserved.')
