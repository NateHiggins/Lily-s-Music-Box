from pathlib import Path
import bpy,json,hashlib,collections,math
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
ROOT=Path("C:/ov/city");OUT=Path(__file__).parent/"native_review_02";OUT.mkdir(exist_ok=False)
IDS=["HORIZON_NEAR_2_0_P1","HORIZON_NEAR_2_1_P2","HORIZON_FAR_2_1_P1"]
NEIGHBOUR="HORIZON_FAR_2_1_P0"
profiles={r["id"]:r for r in json.loads((ROOT/"art/data/city_horizon/source_plan.json").read_text(encoding="utf-8"))["buildings"]}
bindings={};roundtrips=[];captures=[]
def triangles(o):
 o.data.calc_loop_triangles()
 return collections.Counter(tuple(sorted(tuple(float(c) for c in o.matrix_world@o.data.vertices[i].co) for i in t.vertices)) for t in o.data.loop_triangles)
for family,collection,chosen in [("city_horizon_near","CityHorizon_near",IDS[:2]),("city_horizon_far","CityHorizon_far",[IDS[2],NEIGHBOUR]),("city_horizon_lod1","CityHorizonReplacementBodies",IDS)]:
 native=ROOT/f"art/blender/{family}.blend";bindings[native.relative_to(ROOT).as_posix()]=hashlib.sha256(native.read_bytes()).hexdigest();bpy.ops.wm.open_mainfile(filepath=str(native))
 original=[o for o in bpy.data.collections[collection].objects if o.name.split("__")[0] in chosen]
 expected={o.name:triangles(o) for o in original};mats={o.name:o.data.materials[0] for o in original}
 for o in bpy.context.scene.objects:
  if o.type=="MESH":o.hide_render=True
 asset=ROOT/f"game/assets/props/{family}.glb";bindings[asset.relative_to(ROOT).as_posix()]=hashlib.sha256(asset.read_bytes()).hexdigest();before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(asset));bpy.context.view_layer.update();imported=[]
 for o in [o for o in bpy.data.objects if o not in before and o.type=="MESH"]:
  name=o.name.split(".")[0];o.hide_render=name not in expected
  if o.hide_render:continue
  assert triangles(o)==expected[name],(family,name,"roundtrip mismatch")
  assert len(o.data.uv_layers)==1;o.data.uv_layers.active.name="Metres";o.data.materials.clear();o.data.materials.append(mats[name]);imported.append((name,o))
  roundtrips.append(dict(family=family,part=name,exact_float32_triangle_positions=True,triangles=sum(expected[name].values())))
 assert len(imported)==len(expected)
 for image in bpy.data.images:
  if image.source!="FILE" or image.packed_file:continue
  q=ROOT/"game/assets/building/textures"/Path(image.filepath).name;assert q.is_file(),q;image.filepath=str(q);image.reload();assert min(image.size)>0
 scene=bpy.context.scene;scene.render.engine="CYCLES";scene.cycles.device="CPU";scene.cycles.samples=12;scene.cycles.use_denoising=True;scene.cycles.max_bounces=4;scene.render.threads_mode="FIXED";scene.render.threads=2;scene.render.image_settings.file_format="PNG";scene.view_settings.view_transform="AgX";scene.render.resolution_percentage=100
 world=bpy.data.worlds.new("Industrial native review");world.use_nodes=True;scene.world=world;world.node_tree.nodes["Background"].inputs[0].default_value=(.18,.21,.27,1);world.node_tree.nodes["Background"].inputs[1].default_value=.7
 sun=bpy.data.objects.new("Review key",bpy.data.lights.new("Review key","SUN"));scene.collection.objects.link(sun);sun.rotation_euler=Vector((-1.,.35,-.9)).to_track_quat("-Z","Y").to_euler();sun.data.energy=2.5;sun.data.angle=.15
 camera=bpy.data.objects.new("Industrial camera",bpy.data.cameras.new("Industrial camera"));scene.collection.objects.link(camera);scene.camera=camera;camera.data.clip_start=.02
 for identity in chosen:
  if identity==NEIGHBOUR:continue
  a,b,c,d=profiles[identity]["rect"];x=(a+c)*.5;y=-(b+d)*.5;h=profiles[identity]["height_m"]
  views=[("whole",(x+38,y-15,h*.78),(x,y,h*.52),max(h+5,(d-b)*.7),(1400,1100),False,False)]
  if family!="city_horizon_lod1":views.append(("facade",(c+9,y-2,h*.60),(c,y,h*.55),min(15.,d-b),(1300,1100),True,False))
  if identity==IDS[1] and family=="city_horizon_near":views.append(("passage",(c+3.5,-d+1.3,1.52),(a-1.,-d+1.3,1.52),6.,(1300,1000),True,True))
  if identity==IDS[2] and family=="city_horizon_far":views.append(("party_context",(c+37,-60.75-13,18.),(x,-60.75,11.),57.,(1500,1100),True,False))
  for label,eye,aim,scale,res,detail,perspective in views:
   visible=[o for name,o in imported if name.startswith(identity+"__") or (label=="party_context" and name.startswith(NEIGHBOUR+"__"))]
   for name,o in imported:o.hide_render=o not in visible
   camera.location=eye;camera.rotation_euler=(Vector(aim)-camera.location).to_track_quat("-Z","Y").to_euler();camera.data.type="PERSP" if perspective else "ORTHO";camera.data.lens=22.;camera.data.ortho_scale=scale;scene.render.resolution_x,scene.render.resolution_y=res;framed=None
   if not detail:
    for attempt in range(24):
     bpy.context.view_layer.update();points=[world_to_camera_view(scene,camera,o.matrix_world@Vector(c)) for o in visible for c in o.bound_box];framed=all(p.z>0 and .035<=p.x<=.965 and .035<=p.y<=.965 for p in points)
     if framed:break
     camera.data.ortho_scale*=1.12
    assert framed,(family,identity)
   q=OUT/(identity+"_"+family+"_"+label+".png");scene.render.filepath=str(q);bpy.ops.render.render(write_still=True);captures.append(dict(path=q.name,sha256=hashlib.sha256(q.read_bytes()).hexdigest(),family=family,building=identity,whole_body_framed=framed,intentional_detail_or_context_crop=detail))
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
construction=json.loads((ROOT/'art/blender/city_horizon_construction.json').read_text(encoding='utf-8'))
vertices=[];faces=[];owners=[]
for name,o in imported:
 start=len(vertices);vertices.extend(o.matrix_world@v.co for v in o.data.vertices)
 o.data.calc_loop_triangles();faces.extend(tuple(start+i for i in f.vertices) for f in o.data.loop_triangles);owners.extend([name]*len(o.data.loop_triangles))
tree=BVHTree.FromPolygons(vertices,faces,all_triangles=True);panes=0;roof_controls=0;seam_controls=0
for row in construction['window_rows']:
 if row['building'] not in IDS:continue
 point=Vector(row['point']);normal=Vector(row['normal']);hit,n,index,distance=tree.ray_cast(point+normal*.05,-normal,.3)
 assert hit is not None and (hit-(point-normal*row['recess_m'])).length<.0001 and owners[index]==row['building']+'__mirror_aged',('lower pane',row)
 panes+=1
for row in construction['parapet_contacts']:
 if row['building'] not in IDS:continue
 point=Vector(row['point']);hit,n,index,distance=tree.ray_cast(point+Vector((0,0,.02)),Vector((0,0,-1)),.04)
 assert hit is not None and (hit-point).length<.0001 and owners[index]==row['building']+'__galvanized_roof',('lower roof support',row)
 outside=Vector(row['outside_probe']);hit,n,index,distance=tree.ray_cast(outside+Vector((0,0,.02)),Vector((0,0,-1)),.04)
 assert hit is None,('lower outside control',row)
 roof_controls+=1
for study in construction['industrial_checks']:
 obj=next(o for name,o in imported if name==study['building']+'__cast_iron');kd=KDTree(len(obj.data.vertices))
 for i,v in enumerate(obj.data.vertices):kd.insert(obj.matrix_world@v.co,i)
 kd.balance()
 for seam in study['mitre_seams']:
  for points in seam['interfaces'].values():
   for point in points:
    co,index,distance=kd.find(Vector(point));assert distance<.00002,('lower mitre interface',study['building'],point,distance);seam_controls+=1
(OUT/'lower_controls_02.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Actual imported replacement mesh BVH first hits, roof seats/outside controls and exported full-depth mitre interface vertices;not runtime or artistic acceptance.',panes=panes,roof_seats=roof_controls,outside_controls=roof_controls,mitre_interface_points=seam_controls,failures=[]),indent=2),encoding='utf-8',newline='\n')
assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in bindings.items())
(OUT/"native_review_02.json").write_text(json.dumps(dict(evidence_class="INERT",scope="Actual saved native and exact-float32 export roundtrips of three industrial bodies and lower replacements;actual dependent neighbour in context. Registered PBR source maps,no invented ground or rooms. Not loaded/runtime/actor/composed/artistic acceptance.",bindings=bindings,roundtrip=roundtrips,captures=captures),indent=2),encoding="utf-8",newline="\n")
print("INDUSTRIAL_NATIVE_REVIEW",len(captures),len(roundtrips),flush=True)
