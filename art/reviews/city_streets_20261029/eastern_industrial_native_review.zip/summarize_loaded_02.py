from pathlib import Path
import json,hashlib,math,statistics,re
root=Path('C:/ov/city');e=Path(__file__).parent
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def percentile(values,q):
 s=sorted(values);at=(len(s)-1)*q;a=math.floor(at);b=math.ceil(at);return s[a]+(s[b]-s[a])*(at-a)
profile=read(e/'bench_02/city_industrial_profile.json');entry=read(e/'bench_02/industrial_passage_diagnostic.json')
assert not profile['failures'] and not entry['failures']
receipts={}
for stage in ['import','parser','bench']:
 receipts[stage]=read(e/(stage+'_02.log.receipt.json'));assert receipts[stage]['execution']['completed'] and receipts[stage]['execution']['exit_code']==0 and not receipts[stage]['execution']['timed_out']
 assert not (e/(stage+'_02.log.stderr')).read_bytes(),stage
bindings={}
for label,record in [('profile',profile),('entry',entry)]:
 for path,expected in record['source_hashes'].items():
  p=root/'game'/path.removeprefix('res://');b=p.read_bytes()
  if p.suffix in ['.gd','.json','.gdshader','.gdshaderinc','.import']:b=b.replace(b'\r\n',b'\n')
  assert hashlib.sha256(b).hexdigest()==expected,path
 bindings[label]=len(record['source_hashes'])
first=read(e/'loaded_inspection_01.json');reviewed={r['sha256']:r['path'] for r in first['images']}
seen={};images=[];new=0;reused=0
for p in sorted((e/'bench_02').glob('*.png')):
 h=sha(p);row=dict(path=p.relative_to(e).as_posix(),bytes=p.stat().st_size,sha256=h)
 if h in seen:row['byte_alias_of']=seen[h]
 elif h in reviewed:row['actual_review_reused_from']=reviewed[h];reused+=1
 else:row['new_unique_image_actually_inspected']=True;new+=1
 seen[h]=row['path'];images.append(row)
assert len(images)==36 and len(seen)==22 and new==7 and reused==15
rows=[]
for case in profile['observations']:
 samples=case['frame_samples'];assert len(samples)==90
 r={k:case[k] for k in ['building','id','draws','primitives']}
 for key in ['wall_ms','viewport_cpu_ms','viewport_gpu_ms']:
  values=[s[key] for s in samples];r[key]=dict(median=statistics.median(values),p95=percentile(values,.95),p99=percentile(values,.99),maximum=max(values))
 r['wall_over_16_667ms']=sum(s['wall_ms']>16.667 for s in samples);rows.append(r)
for material in profile['loaded_materials'].values():
 assert material['texture_filter']==3 and not material['triplanar'] and len(material['maps'])==3
 for texture in material['maps'].values():assert texture['has_mipmaps'] and texture['mipmap_count']==math.floor(math.log2(max(texture['dimensions'])))
lower=[]
for line in (e/'bench_02.log').read_text(encoding='utf-8').splitlines():
 if 'CAP MAPPING: mesh=city_horizon_lod1_' in line:lower.append(dict(re.findall(r'(mesh|valid_basis|max_uv_excess|widest|derivatives|bad_derivatives|worst_dot)=([^ ]+)',line)))
assert len(lower)==23 and all(r['valid_basis']=='true' and r['derivatives']=='true' and r['bad_derivatives']=='0' for r in lower)
assert 'CITY HORIZON BENCH: PASS; 25852 checks; 0 failures' in (e/'bench_02.log').read_text(encoding='utf-8')
r=dict(evidence_class='INERT',scope='Loaded/rendered isolated diagnostic,not a runtime_contract or composed-world/actor/save/artistic qualification. Original failed first run retained. Fixed source GLBs/native bodies unchanged;one default-compressed import repaired through the existing precision policy. No threshold relaxation. Seven new unique captures actually viewed;15 byte-identical prior unique reviews reused;14 exact aliases checked.',receipts=receipts,source_hashes_verified=bindings,lower_chart_measurements=lower,loaded_materials=profile['loaded_materials'],profile_settings=profile['settings'],warm_frames=1350,performance=rows,natural_transitions=profile['natural_transitions'],passage={k:v for k,v in entry.items() if k not in ['movement_samples','source_hashes']},images=images,frozen_inputs={p:sha(root/p) for p in ['game/tests/v2_city_horizon_bench.gd','game/assets/props/city_horizon_lod1.glb.import','art/tools/fix_v2_mesh_imports.py']})
q=e/'loaded_inspection_02.json';assert not q.exists();q.write_text(json.dumps(r,indent=2),encoding='utf-8',newline='\n')
print(dict(source_hashes_verified=bindings,frames=len(images),new_actual_images=new,prior_unique_reviews_reused=reused,aliases=len(images)-len(seen),material_partitions=len(profile['loaded_materials']),lower_chart_parts=len(lower),maximum_wall_ms=max(v['wall_ms']['maximum'] for v in rows),all_stderr_empty=True))
