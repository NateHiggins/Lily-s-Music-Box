from pathlib import Path
import json,hashlib,math,statistics,sys,collections,re
root=Path('C:/ov/city');e=Path(__file__).parent
sys.path.insert(0,str(root/'tools'));import gate_board
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
profile=read(e/'bench_01/city_industrial_profile.json');entry=read(e/'bench_01/industrial_passage_diagnostic.json')
overrides={'res://tests/v2_city_horizon_bench.gd':e/'bench_01_executed_source.gd','res://assets/props/city_horizon_lod1.glb.import':e/'city_horizon_lod1_before_compression_01.import'}
def verify(record):
 for path,expected in record['source_hashes'].items():
  p=overrides.get(path,root/'game'/path.removeprefix('res://'));data=p.read_bytes()
  if p.suffix in ['.gd','.json','.gdshader','.gdshaderinc','.import']:data=data.replace(b'\r\n',b'\n')
  assert hashlib.sha256(data).hexdigest()==expected,path
 return len(record['source_hashes'])
bindings=dict(profile=verify(profile),entry=verify(entry))
images=[];seen={}
for p in sorted((e/'bench_01').glob('*.png')):
 h=sha(p);row=dict(path=p.relative_to(e).as_posix(),bytes=p.stat().st_size,sha256=h)
 if h in seen:row['byte_alias_of']=seen[h]
 else:row['actual_unique_image_inspected']=True;seen[h]=row['path']
 images.append(row)
assert len(images)==24 and len(seen)==21
def percentile(values,q):
 s=sorted(values);at=(len(s)-1)*q;a=math.floor(at);b=math.ceil(at);return s[a]+(s[b]-s[a])*(at-a)
rows=[]
for case in profile['observations']:
 samples=case['frame_samples'];assert len(samples)==90
 r={k:case[k] for k in ['building','id','draws','primitives']}
 for key in ['wall_ms','viewport_cpu_ms','viewport_gpu_ms']:
  values=[s[key] for s in samples];r[key]=dict(median=statistics.median(values),p95=percentile(values,.95),p99=percentile(values,.99),maximum=max(values))
 r['wall_over_16_667ms']=sum(s['wall_ms']>16.667 for s in samples);rows.append(r)
board=read(e/'static_01/board.json');old=read(e.parent/'southern_pair_01/static_01/board.json')
comparison=gate_board.compare(old,board)
result=dict(evidence_class='INERT',scope='Failed first loaded diagnostic,not partial acceptance. All24 saved files inspected through21 unique actual images plus3 exact byte aliases. Actual source hashes checked against preserved executed bench/default import where the pending repair differs. Static comparison uses an earlier dirty city board,not an exact clean merge-base qualification.',wrapper=read(e/'bench_01.log.receipt.json'),source_hashes_verified=bindings,profile_failures=profile['failures'],passage={k:v for k,v in entry.items() if k not in ['movement_samples','source_hashes']},profile_settings=profile['settings'],warm_frames=1350,performance=rows,images=images,static_board=dict(commit=board['commit'],gates=len(board['gates']),severity=dict(collections.Counter(g['severity'] for g in board['gates'])),dirty_paths_count=len(board['dirty_paths']),dirty_paths_scope='638 generated untracked UIDs at completion; native/import benchmark overlapped board end.',timeouts=sum(g['timed_out'] for g in board['gates']),non_pass=[dict(id=g['id'],severity=g['severity'],counts=g['counts'],defects=g['defects']) for g in board['gates'] if g['severity']!='PASS']),diagnostic_previous_board_comparison=comparison)
q=e/'loaded_inspection_01.json';assert not q.exists();q.write_text(json.dumps(result,indent=2),encoding='utf-8',newline='\n')
print(dict(source_hashes_verified=bindings,images=len(images),unique=len(seen),profile_failures=profile['failures'],passage_checks=entry['checks'],passage_failures=entry['failures'],static_severity=result['static_board']['severity'],diagnostic_regressions=comparison['regressions'],maximum_wall_ms=max(r['wall_ms']['maximum'] for r in rows)))
