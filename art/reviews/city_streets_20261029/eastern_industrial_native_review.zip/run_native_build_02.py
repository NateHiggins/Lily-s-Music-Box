from pathlib import Path
import subprocess,os,json,time
root=Path("C:/ov/city");out=Path(__file__).parent
engine="C:/Program Files/Blender Foundation/Blender 5.2/blender.exe"
env=os.environ.copy()
for key in ["OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS"]:env[key]="2"
started=time.time()
with (out/"build_city_horizon_02.log").open("wb") as log:
 result=subprocess.run([engine,"-b","-t","2","--python-exit-code","1","-P",str(root/"art/blender/scripts/build_city_horizon.py")],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
r={"evidence_class":"INERT","scope":"Native generation only,no render or runtime acceptance.","builder":"art/blender/scripts/build_city_horizon.py","exit_code":result.returncode,"seconds":time.time()-started}
(out/"native_build_02.json").write_text(json.dumps(r,indent=2),encoding="utf-8",newline="\n")
print(r,flush=True)
raise SystemExit(result.returncode)
