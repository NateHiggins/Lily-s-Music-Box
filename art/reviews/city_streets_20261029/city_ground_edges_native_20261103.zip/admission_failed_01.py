"""Read-only conservative separation survey; no engine/native producer invocation."""
import pathlib,json,hashlib,struct,sys,math,itertools,subprocess
import numpy as np
ROOT=pathlib.Path('C:/PleaseRemainOnTheLine');OUT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_ground_apron_geometry import relief_height
def read(p):return json.loads((ROOT/p).read_bytes())
bindings={}
def bind(p):
 p=pathlib.Path(p);bindings[str(p.relative_to(ROOT)).replace('\\','/')]=hashlib.sha256(p.read_bytes()).hexdigest()
def corners(b):return np.array(list(itertools.product(*zip(b[:3],b[3:]))))
def transformed(b,m):
 v=(m@np.column_stack([corners(b),np.ones(8)]).T).T[:,:3];return list(v.min(0))+list(v.max(0))
def node_matrix(n):
 if 'matrix' in n:return np.array(n['matrix']).reshape(4,4).T
 x,y,z,w=n.get('rotation',[0,0,0,1]);m=np.eye(4);m[:3,:3]=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])@np.diag(n.get('scale',[1,1,1]));m[:3,3]=n.get('translation',[0,0,0]);return m
def stocks(p,root,offsets=None):
 bind(p);raw=p.read_bytes();assert raw[:4]==b'glTF';size=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+size]);binary=memoryview(raw)[28+size:];result=[]
 def visit(i,parent):
  n=d['nodes'][i];m=parent@node_matrix(n)
  if 'mesh' in n:
   if offsets:
    for identity,offset in offsets.items():
     if n.get('name','').startswith(identity):m=m.copy();m[:3,3]+=np.array([offset[0],offset[2],-offset[1]]);break
   for j,primitive in enumerate(d['meshes'][n['mesh']]['primitives']):
    a=d['accessors'][primitive['attributes']['POSITION']];v=d['bufferViews'][a['bufferView']];assert a['componentType']==5126 and a['type']=='VEC3'
    arr=np.ndarray((a['count'],3),dtype='<f4',buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',12),4));b=list(arr.min(0).astype(float))+list(arr.max(0).astype(float));assert np.isfinite(b).all()
    result.append(dict(asset=str(p.relative_to(ROOT)).replace('\\','/'),part=n.get('name',str(i)),primitive=j,bounds=transformed(b,m)))
  for child in n.get('children',[]):visit(child,m)
 for n in d['scenes'][d.get('scene',0)]['nodes']:visit(n,root)
 return result
envelope=[-326.,-4.1,-16.,-312.,.2,16.]
def separation(b):return max(envelope[i]-b[i+3] for i in range(3)) if False else max([envelope[i]-b[i+3] for i in range(3)]+[b[i]-envelope[i+3] for i in range(3)])
def check(rows,label):
 overlap=[r for r in rows if separation(r['bounds'])<.025]
 assert not overlap,(label,overlap[:5]);return dict(scope=label,count=len(rows),minimum_axis_separation_m=min(separation(r['bounds']) for r in rows))
identity=np.eye(4);city=np.eye(4);city[2,3]=-float(read('game/data/orison_v2/exterior/street_frame.json')['source_threshold_z'])
sources=['art/data/city_horizon/source_plan.json','art/data/city_elevations/source_plan.json','art/data/city_ground_apron/source_plan.json','art/blender/city_ground_apron_construction.json','art/data/orison_ground/retained_grade_source.json','art/data/orison_ground/discovery/runtime_survey.json','art/blender/alley_groundworks_reservations.json','game/data/orison_v2/exterior/city_bridge.json','game/data/orison_v2/exterior/city_elevations.json','game/data/orison_v2/exterior/street_traffic.json','game/data/orison_v2/exterior/street_frame.json','game/scripts/building/orison_v2_runtime_root.gd','game/scripts/building/orison_v2_city_bridge.gd','game/scripts/building/orison_v2_city_shells.gd','game/scripts/building/orison_v2_city_placement.gd','game/scripts/building/orison_v2_street_boundaries.gd','art/blender/scripts/city_ground_apron_geometry.py']
for p in sources:bind(ROOT/p)
plan=read('art/data/city_horizon/source_plan.json');reserved=[dict(part=r['id'],bounds=[r['rect'][0],-10,r['rect'][1],r['rect'][2],60,r['rect'][3]]) for r in plan['buildings']];checks=[check(reserved,'All124 source reservations (39retained+85replacement)')]
offsets={r['id']:r.get('assembly_translation_m',[0,0,0]) for r in read('game/data/orison_v2/exterior/city_elevations.json')['buildings']};assert len(offsets)==25
physical=[]
for name in ['city_elevations','city_elevations_lod1','city_masts','city_aerials','city_tanks','city_beacons','city_transport','city_transport_lod1','city_streets','city_streets_lod1']:
 p=ROOT/'game/assets/props'/(name+'.glb');physical+=stocks(p,city,offsets if name.startswith('city_elevations') else None)
for name in ['city_foundations','orison_foundations','front_pavement','service_alley','construction_shed']:
 p=ROOT/'game/assets/props'/(name+'.glb')
 if p.exists():physical+=stocks(p,identity)
manifest=read('game/data/orison_v2/exterior/city_horizon.json');bind(ROOT/'game/data/orison_v2/exterior/city_horizon.json')
for row in manifest['assets']+manifest['body_lod']['assets']:physical+=stocks(ROOT/'game'/row['asset'].removeprefix('res://'),identity)
bridge=read('game/data/orison_v2/exterior/city_bridge.json');az=math.radians(bridge['eastbound_azimuth_deg']);d=np.array([math.sin(az),0,-math.cos(az)]);m=np.eye(4);m[:3,:3]=np.column_stack([d,[0,1,0],np.cross(d,[0,1,0])]);q=bridge['queens_source_xy_m'];m[:3,3]=np.array([q[0],bridge['water_scene_y_m'],-q[1]])-d*bridge['main_length_m']
for name in ['city_bridge','city_bridge_lod1']:physical+=stocks(ROOT/'game/assets/props'/(name+'.glb'),city@m)
checks.append(check(physical,'Actual scenegraph-composed near/lower native stock bounds;conservative AABB separation only,never solid substitution'))
ground=read('art/data/orison_ground/retained_grade_source.json')
for key in ['retained_solids','occupation_reservations','surface_exclusions']:checks.append(check(ground[key],'Underground/retained-grade '+key))
runtime=read('art/data/orison_ground/discovery/runtime_survey.json');checks.append(check([r for r in runtime['records'] if 'bounds'in r],'Recorded aligned runtime static providers;historical source custody,not new runtime proof'))
relief=read('art/data/city_ground_apron/source_plan.json')['relief'];grade=[dict(x=x,z=z,y=relief_height(x,z,-.02,relief)) for x in [-326,-322,-320.5,-320,-319.5,-318,-316,-312] for z in [-16,0,16]]
bound=max(math.hypot(x,z-11.65) for x in [envelope[0],envelope[3]] for z in [envelope[2],envelope[5]]);assert bound<450*math.cos(math.pi/256)-.5
result=dict(evidence_class='INERT',scope='Source/native admission checks only;not installed,played access or artistic acceptance',canonical_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),provisional_envelope_building_xyz=envelope,checks=checks,receiving_grade_samples=grade,temporary_boundary=dict(maximum_radius_m=bound,inscribed_wall_radius_m=450*math.cos(math.pi/256)),stock_bounds=physical,source_bindings=bindings,limitations=['Conservative separation establishes no intersection only for enumerated stocks;receiving ground intentionally overlaps and requires native contact witnesses.','Historical aligned runtime survey is not a fresh live-scene census.','Existing near25source and static-family arrays checked;new runtime composition remains integration-owner scope.'])
(OUT/'ADMISSION_01.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k not in ['stock_bounds','source_bindings']},indent=2))
