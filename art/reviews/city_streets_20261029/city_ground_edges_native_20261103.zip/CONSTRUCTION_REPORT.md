# REPORT - V2-CITY-GROUND-EDGES - 2026-11-03

Evidence class: **INERT**. Completed external native delivery; installation, runtime qualification and Lily's artistic acceptance remain open.

Branch / starting HEAD / origin/main / merge-base: canonical read-only codex/v2-first-view-preparation-20261102 / 2fecf543bd76aa66a84a01e96e13b05a4df1fde1 / last supplied fb3167942 / not recomputed for this external delivery. Developer later advanced tooling/camera records to ae3ffbfb6; all106 admission bindings remain exact. No canonical edits, index mutation, main merge or Godot run by this chat.
Worktree clean at end: external delivery, no owned Git edits. Two-source patch passed git apply --check before intake. At final packaging,the integration owner had already created the two canonical paths;the new-file patch now correctly refuses existing paths. This chat applied no patch. See INTEGRATION_OWNER_OBSERVED.json for exact copied-file hashes.
Protected17/17: no protected files edited; independent candidate verification NOT_EXECUTED. Selector unchanged.
Ledger before -> after: not rerun; requirements_changed: []. Native evidence promotes no runtime/design acceptance.

First bounded target: EasternCutToe32, one32m low concrete retaining-toe slice at the existing eastern rail cut. Agreed authored paths only:

- art/data/city_ground_edges/source_plan.json
- art/blender/scripts/build_city_ground_edges.py

Both are delivered externally here, with integration.patch. Native outputs are art/blender/city_ground_edges.blend and game/assets/props/city_ground_edges.glb / city_ground_edges_lod1.glb. New stock uses only the existing registered concrete recipe and its three external maps; no catalogue additions or duplicated maps.

Native broker57480/session8457 is TERMINAL exit0. The original tool session returned [LANE] exit=0; native_01.log ends in both PASS messages and Blender quit. This generic native/GPU lane stage supplies a raw log rather than a Godot suite_run/runtime_contract receipt. Test-written NATIVE_CONSTRUCTION.json and NATIVE_REVIEW.json, hashes and actual images establish native scope only. Executed source is SOURCE_FREEZE_03; prelaunch1/2 were never executed and remain preserved. Producer SHA256605190112529bd3fe1f15b3d4bf046c401674e40bff39916cc21145500f014b2.

| Measured native level | Triangles | GLB bytes | Partitions | Complete closed stocks |
|---|---:|---:|---:|---:|
| Near | 6,216 | 850,528 | 1 | 36 |
| Lower | 1,200 | 151,008 | 1 | 36 |

Editable native:478,399bytes, SHA256b0b3d6dcccd93e9b9806fe79c4a354a409cab923dd9234365035ede0644b53ae. All3native/GLB files are below95MiB. Build phase14.4736644s; this excludes FIFO wait and is not gameplay performance. Blender5.2.0LTS fbe6228777e7,explicit CyclesCPU1render thread,8samples,1000x640. Six images individually inspected at full resolution. One World.use_nodes deprecation warning; no traceback/error headers. Both exported derivative checks pass; both imported GLBs reproduce every native triangle and per-corner UV within4float32ULP. Actual max UV drift2.9802322387695312e-8m. Native source file remains unchanged after review.

Physical native checks:68actual receiving-ground BVH rays and68wrong-height controls;16carrier rays plus16outside negatives perlevel;32footing-corner burial records and4tapered-end contacts perlevel. Minimum burial0.28m,maximum exposed terminal reveal0.026460m. All36stocks perlevel are closed with positive volumes. Footings,stems,copings andall12fragment masses remain in the lower body. No whole body is dropped as an LOD shortcut.

The original provisional envelope is X[-326,-312],Y[-4.1,.2],Z[-16,16] in ORISON_V2_BUILDING_FRAME;it is not a new world reservation. All124protected lots have at least40m conservative separation. ADMISSION_02.json surveys5,823native stocks and retained sources including5,465solids,57occupied reservations,4,243exclusions,14,947classified provider records,30alley service reservations and571recorded aligned-runtime providers. Historical records are not a fresh runtime census. Maximum envelope radius327.170m remains inside the449.966m inscribed temporary boundary.

Registration refinement: the initial stock survey used static/root poses for rooftop hardware and an overbroad prefix match for9near-city parts. REGISTRATION_REFINEMENT_01.json applies the actual delimiter-aware current placement translations to9body+367roof parts;no intersection appears. Its162core template-native checks use a deliberately conservative100mregistration allowance,with8currentfire anchors/electricalaxis records;these are not exact installed actor or moving-part poses. Current runtime contact/access still belongs to the integration owner. Native producer,original admission and SOURCE_FREEZE_03 were not edited by this supplementary proof. FINAL_DELIVERY_AUDIT.json verifies130bound-input comparisons across the three evidence corpora (not130unique inputs).

The original broadphase refusal remains in admission_failed_01.py and ADMISSION_01_FAILURE.json (original tool chunk5325ef exited1). Four rotated bridge backing-soil AABBs overlap the envelope. Actual triangle/25mm-expanded-box tests have zero hits and center signed winding near3e-19,so the box is not enclosed. Enclosing-cube,crossing-triangle and outside-cube controls pass. No giant mesh AABB became a world solid. Actual current ground GLB matches24recipe stations with max drift3.576281493167244e-10m; native later checks68actual hits.

Current relief rises3.48m over10m. A tall vertical wall would require excavation or a new retained backing. This slice instead supplies eight4m low toe panels,buried sectional footings,jointed copings and4m tapered ends,leaving the existing broad embankment. All dimensions are AU adaptation,not a surveyed1928structure. Near-period P856c1929 and G06/G08 research inform edge hierarchy only;no photograph pixels enter assets. No grade masks,ballast,tracks,train actors,drainage simulation,new district or additional canal/street batch.

Three old discovery bindings remain stale. Active consumers are export_retained_grade_sources.py and tools/v2_surface_evidence.py;these paths are not dismissed as historical-only. Their old discovery entries remain historical provenance. Current street/transport GLB and receiving-surface checks are independent. The developer's separate queued replay has since reported14,947identical physical records and exactly3binding changes;that report is owned separately and is not repinned into this delivery.

| Active path | Old expected SHA256 | Current raw SHA256 |
|---|---|---|
| art/blender/city_transport_construction.json | 67bcf2b787ee9514a2494c6211bffc49f19e86677009f682ccbdae8b3a4d0f34 | 863e35920e5668f7ba5bd7d20029e5a0668898a0997eccc3f43ba7f112214391 |
| art/blender/city_streets_construction.json | 003b629052a8887e3e5122ba0b9c68ff88302e179128a0b91d4fe1e7e8288275 | 33d18a1874366f8f8c1f80986ca2f91705c1744a2155a96ab95332bacc540611 |
| art/blender/city_streets.blend | 1b8ed784dc55e01de45b9e46ab401d2fba2bd8de0cc4a56acd6ab2df8514c451 | ddbcd6bce3de93223b4922203884a2e262bd89e18f38ed03163f6c682633c7aa |

Gates: source AST/JSON and two-path patch checks pass. Shared strict native UV/tangent export checks and reopened mesh checks pass. No fullboard/candidate/Godot suite was run by this chat. No new materials,render shader,interior,shop,traffic,clock/weather,companion,narrative or save authority. No foreign process/ticket touched.

Artistic review: low toe/cap thickness,joints,buried base and end tapers read coherently in all six CPU views. The small concrete fragments have regular octagonal/square shapes and fairly regular spacing;they can read as markers rather than broken debris. This is recorded for Lily's composed review,not hidden as acceptance. Plain surrounding ground remains existing unfinished city work. Sources stay frozen after developer intake checks;no speculative reauthoring or another family starts here.

Integration: mount in the existing building/ground frame. GLB node translations already encode anchor[-320,-3.5,0] after glTF axis conversion;do not apply the anchor or b2g again. If mounted below CityShells,derive the same blockout-relative transform used by CityHorizon. Keep current ground as the receiver,not a duplicate floor. Register the two hash-bound source files as -text (or explicitly LF-normalize text hashes) at intake. Orison Developer Sol6.1 owns mounting/discovery,binding reconciliation,current loaded PBR/mips,actual contact/access/LOD/entry optics,combined surface renewal and measured CPU/GPU/frame spikes.

Open findings: no runtime or played access proof for this new stock,no loaded mip chain/installed lighting/distance-LOD or actual rendering-cost result,no save or whole-city/artistic acceptance. Geometry counts/file sizes are not rendering budgets. Current markers/plain ground are artistic limitations. No main merge here.
Decision needed from owner: none within agreed scope.

BLOCKED runtime integration candidate pending coordinated actual-world qualification; native delivery ready.
