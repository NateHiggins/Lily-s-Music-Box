"""Read-only conservative separation survey; no engine/native producer invocation."""
import pathlib,json,hashlib,struct,sys,math,itertools,subprocess
import numpy as np
sys.dont_write_bytecode=True
ROOT=pathlib.Path('C:/PleaseRemainOnTheLine');OUT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_ground_apron_geometry import relief_height
def read(p):return json.loads((ROOT/p).read_bytes())
bindings={}
refinements=[];receiver_tris=[]
def triangle_box_hits(tris,box):
 center=(np.array(box[:3])+box[3:])/2;half=(np.array(box[3:])-box[:3])/2;v=tris-center
 keep=np.ones(len(v),dtype=bool);edges=np.roll(v,-1,axis=1)-v
 axes=[np.broadcast_to(a,(len(v),3)) for a in np.eye(3)]+[np.cross(edges[:,0],edges[:,1])]+[np.cross(edges[:,i],a) for i in range(3) for a in np.eye(3)]
 for axis in axes:
  dot=np.einsum('nki,ni->nk',v,axis);radius=np.abs(axis)@half
  keep&=(dot.min(1)<=radius+1e-9)&(dot.max(1)>=-radius-1e-9)
 return int(keep.sum())
def winding(tris,p):
 a,b,c=(tris-np.array(p))[:,0],(tris-np.array(p))[:,1],(tris-np.array(p))[:,2]
 la,lb,lc=np.linalg.norm(a,axis=1),np.linalg.norm(b,axis=1),np.linalg.norm(c,axis=1)
 return float(np.sum(2*np.arctan2(np.einsum('ni,ni->n',a,np.cross(b,c)),la*lb*lc+np.einsum('ni,ni->n',a,b)*lc+np.einsum('ni,ni->n',b,c)*la+np.einsum('ni,ni->n',c,a)*lb))/(4*np.pi))
def bind(p):
 p=pathlib.Path(p);bindings[str(p.relative_to(ROOT)).replace('\\','/')]=hashlib.sha256(p.read_bytes()).hexdigest()
def corners(b):return np.array(list(itertools.product(*zip(b[:3],b[3:]))))
def transformed(b,m):
 v=(m@np.column_stack([corners(b),np.ones(8)]).T).T[:,:3];return list(v.min(0))+list(v.max(0))
def node_matrix(n):
 if 'matrix' in n:return np.array(n['matrix']).reshape(4,4).T
 x,y,z,w=n.get('rotation',[0,0,0,1]);m=np.eye(4);m[:3,:3]=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])@np.diag(n.get('scale',[1,1,1]));m[:3,3]=n.get('translation',[0,0,0]);return m
def stocks(p,root,offsets=None,receiver=False):
 bind(p);raw=p.read_bytes();assert raw[:4]==b'glTF';size=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+size]);binary=memoryview(raw)[28+size:];result=[]
 def visit(i,parent):
  n=d['nodes'][i];m=parent@node_matrix(n)
  if 'mesh' in n:
   if offsets:
    for identity,offset in offsets.items():
     if n.get('name','').startswith(identity):m=m.copy();m[:3,3]+=np.array([offset[0],offset[2],-offset[1]]);break
   for j,primitive in enumerate(d['meshes'][n['mesh']]['primitives']):
    a=d['accessors'][primitive['attributes']['POSITION']];v=d['bufferViews'][a['bufferView']];assert a['componentType']==5126 and a['type']=='VEC3'
    arr=np.ndarray((a['count'],3),dtype='<f4',buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',12),4));b=list(arr.min(0).astype(float))+list(arr.max(0).astype(float));assert np.isfinite(b).all()
    stock=dict(asset=str(p.relative_to(ROOT)).replace('\\','/'),part=n.get('name',str(i)),primitive=j,bounds=transformed(b,m))
    if receiver or separation(stock['bounds'])<.025:
     idx=d['accessors'][primitive['indices']];view=d['bufferViews'][idx['bufferView']];indices=np.frombuffer(binary,dtype={5121:'u1',5123:'<u2',5125:'<u4'}[idx['componentType']],count=idx['count'],offset=view.get('byteOffset',0)+idx.get('byteOffset',0));assert len(indices)%3==0
     verts=(m@np.column_stack([arr,np.ones(len(arr))]).T).T[:,:3];tris=verts[indices].reshape(-1,3,3)
     if receiver:receiver_tris.extend(tris)
     else:
      expanded=[v-.025 for v in envelope[:3]]+[v+.025 for v in envelope[3:]];hits=triangle_box_hits(tris,expanded);w=winding(tris,(np.array(expanded[:3])+expanded[3:])/2)
      stock['exact_refinement']=dict(triangles_tested=len(tris),triangle_box_hits=hits,center_signed_winding=w,precision_m=1e-9,clearance_expansion_m=.025)
      refinements.append(stock);assert hits==0 and abs(w)<1e-5,(stock,'actual intersection or containment')
    result.append(stock)
  for child in n.get('children',[]):visit(child,m)
 for n in d['scenes'][d.get('scene',0)]['nodes']:visit(n,root)
 return result
envelope=[-326.,-4.1,-16.,-312.,.2,16.]
def separation(b):return max(envelope[i]-b[i+3] for i in range(3)) if False else max([envelope[i]-b[i+3] for i in range(3)]+[b[i]-envelope[i+3] for i in range(3)])
def check(rows,label):
 overlap=[r for r in rows if separation(r['bounds'])<.025 and 'exact_refinement'not in r]
 assert not overlap,(label,overlap[:5]);return dict(scope=label,count=len(rows),minimum_broadphase_axis_separation_m=min(separation(r['bounds']) for r in rows),actual_triangle_refinements=sum('exact_refinement'in r for r in rows))
identity=np.eye(4);city=np.eye(4);city[2,3]=-float(read('game/data/orison_v2/exterior/street_frame.json')['source_threshold_z'])
sources=['art/data/city_horizon/source_plan.json','art/data/city_elevations/source_plan.json','art/data/city_ground_apron/source_plan.json','art/blender/city_ground_apron_construction.json','art/data/orison_ground/retained_grade_source.json','art/data/orison_ground/discovery/runtime_survey.json','art/blender/alley_groundworks_reservations.json','game/data/orison_v2/exterior/city_bridge.json','game/data/orison_v2/exterior/city_elevations.json','game/data/orison_v2/exterior/street_traffic.json','game/data/orison_v2/exterior/street_frame.json','game/scripts/building/orison_v2_runtime_root.gd','game/scripts/building/orison_v2_city_bridge.gd','game/scripts/building/orison_v2_city_shells.gd','game/scripts/building/orison_v2_city_placement.gd','game/scripts/building/orison_v2_street_boundaries.gd','art/blender/scripts/city_ground_apron_geometry.py']
for p in sources:bind(ROOT/p)
plan=read('art/data/city_horizon/source_plan.json');reserved=[dict(part=r['id'],bounds=[r['rect'][0],-10,r['rect'][1],r['rect'][2],60,r['rect'][3]]) for r in plan['buildings']];checks=[check(reserved,'All124 source reservations (39retained+85replacement)')]
offsets={r['id']:r.get('assembly_translation_m',[0,0,0]) for r in read('game/data/orison_v2/exterior/city_elevations.json')['buildings']};assert len(offsets)==25
physical=[]
for name in ['city_elevations','city_elevations_lod1','city_masts','city_aerials','city_tanks','city_beacons','city_transport','city_transport_lod1','city_streets','city_streets_lod1']:
 p=ROOT/'game/assets/props'/(name+'.glb');physical+=stocks(p,city,offsets if name.startswith('city_elevations') else None)
for name in ['city_foundations','orison_foundations','front_pavement','service_alley','construction_shed']:
 p=ROOT/'game/assets/props'/(name+'.glb')
 if p.exists():physical+=stocks(p,identity)
for relative in ['game/data/orison_v2/fire_service.json','game/data/orison_v2/electrical_service.json']:
 bind(ROOT/relative);physical+=stocks(ROOT/'game'/read(relative)['asset'].removeprefix('res://'),identity)
physical+=stocks(ROOT/'game/assets/props/heating_distribution.glb',identity)
physical+=stocks(ROOT/'game/assets/props/v2_entry_vestibule.glb',identity)
for relative in ['game/data/orison_v2/gas_service.json','game/scripts/building/orison_v2_gas_service.gd','game/scripts/building/orison_v2_native_fire_service.gd','game/scripts/building/orison_v2_native_electrical_service.gd','game/scripts/building/orison_v2_heating_distribution.gd','game/data/orison_v2/exterior/public_region_programmes.json','game/data/orison_v2/exterior/regions.json']:bind(ROOT/relative)
manifest=read('game/data/orison_v2/exterior/city_horizon.json');bind(ROOT/'game/data/orison_v2/exterior/city_horizon.json')
for row in manifest['assets']+manifest['body_lod']['assets']:physical+=stocks(ROOT/'game'/row['asset'].removeprefix('res://'),identity)
bridge=read('game/data/orison_v2/exterior/city_bridge.json');az=math.radians(bridge['eastbound_azimuth_deg']);d=np.array([math.sin(az),0,-math.cos(az)]);m=np.eye(4);m[:3,:3]=np.column_stack([d,[0,1,0],np.cross(d,[0,1,0])]);q=bridge['queens_source_xy_m'];m[:3,3]=np.array([q[0],bridge['water_scene_y_m'],-q[1]])-d*bridge['main_length_m']
for name in ['city_bridge','city_bridge_lod1']:physical+=stocks(ROOT/'game/assets/props'/(name+'.glb'),city@m)
checks.append(check(physical,'Actual scenegraph-composed near/lower native stock bounds;conservative AABB separation only,never solid substitution'))
ground=read('art/data/orison_ground/retained_grade_source.json')
for key in ['retained_solids','occupation_reservations','surface_exclusions']:checks.append(check(ground[key],'Underground/retained-grade '+key))
native=read('art/data/orison_ground/discovery/native_sources.json');bind(ROOT/'art/data/orison_ground/discovery/native_sources.json');native_binding_match=[];native_binding_stale=[]
for name,expected in native['bindings'].items():
 data=(ROOT/name).read_bytes();matched=expected in [hashlib.sha256(data).hexdigest(),hashlib.sha256(data.replace(b'\r\n',b'\n')).hexdigest()]
 (native_binding_match if matched else native_binding_stale).append(name)
checks.append(check(native['records'],'14947classified native ground/provider/clearance records;37binding inputs current,3stale metadata retained;current street/transport GLB arrays independently surveyed'))
checks.append(check(read('art/blender/alley_groundworks_reservations.json')['reservations'],'Current alley underground and service air/collector reservations'))
runtime=read('art/data/orison_ground/discovery/runtime_survey.json');checks.append(check([r for r in runtime['records'] if 'bounds'in r],'Recorded aligned runtime static providers;historical source custody,not new runtime proof'))
relief=read('art/data/city_ground_apron/source_plan.json')['relief'];grade=[dict(x=x,z=z,y=relief_height(x,z,-.02,relief)) for x in [-326,-322,-320.5,-320,-319.5,-318,-316,-312] for z in [-16,0,16]]
stocks(ROOT/'game/assets/props/city_ground_apron.glb',identity,receiver=True);tris=np.array(receiver_tris)
def cross2(a,b):return a[...,0]*b[...,1]-a[...,1]*b[...,0]
for sample in grade:
 a=tris[:,0][:,[0,2]];u=tris[:,1][:,[0,2]]-a;v=tris[:,2][:,[0,2]]-a;w=np.array([sample['x'],sample['z']])-a;det=cross2(u,v);valid=np.abs(det)>1e-10
 s=np.zeros(len(tris));t=s.copy();s[valid]=cross2(w[valid],v[valid])/det[valid];t[valid]=cross2(u[valid],w[valid])/det[valid]
 hits=valid&(s>=-1e-7)&(t>=-1e-7)&(s+t<=1+1e-7);assert hits.any();ys=tris[:,0,1]+s*(tris[:,1,1]-tris[:,0,1])+t*(tris[:,2,1]-tris[:,0,1]);h=float(ys[hits].max());sample['actual_exported_ground_y_m']=h;sample['drift_m']=h-sample['y'];assert abs(h-sample['y'])<.0001,sample
# Meaningful wrong controls: a closed enclosing stock has no surface/box hit
# yet must be rejected by containment; a deliberately crossing triangle must hit.
verts=corners([-2,-2,-2,2,2,2]);faces=[[0,1,3,2],[4,6,7,5],[0,4,5,1],[2,3,7,6],[0,2,6,4],[1,5,7,3]];cube=np.array([[verts[f[0]],verts[f[j]],verts[f[j+1]]] for f in faces for j in [1,2]])
assert abs(abs(winding(cube,[0,0,0]))-1)<1e-8 and triangle_box_hits(cube,[-1,-1,-1,1,1,1])==0
assert triangle_box_hits(np.array([[[-2,0,0],[2,0,0],[0,2,0]]]),[-1,-1,-1,1,1,1])==1 and abs(winding(cube,[8,8,8]))<1e-8
bound=max(math.hypot(x,z-11.65) for x in [envelope[0],envelope[3]] for z in [envelope[2],envelope[5]]);assert bound<450*math.cos(math.pi/256)-.5
result=dict(evidence_class='INERT',scope='Source/native admission checks only;not installed,played access or artistic acceptance',canonical_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),provisional_envelope_building_xyz=envelope,checks=checks,receiving_grade_samples=grade,temporary_boundary=dict(maximum_radius_m=bound,inscribed_wall_radius_m=450*math.cos(math.pi/256)),stock_bounds=physical,source_bindings=bindings,refinements=refinements,limitations=['Conservative separation establishes no intersection only for enumerated stocks;receiving ground intentionally overlaps and requires native contact witnesses.','Historical aligned runtime survey is not a fresh live-scene census.','Existing near25source and static-family arrays checked;new runtime composition remains integration-owner scope.'])
result['negative_controls']={'enclosing_cube_surface_hits':0,'enclosing_cube_winding_abs':abs(winding(cube,[0,0,0])),'crossing_triangle_hits':1,'outside_cube_winding_abs':abs(winding(cube,[8,8,8]))}
result['native_discovery_snapshot']={'matched_bindings':len(native_binding_match),'stale_bindings':[{'path':name,'expected_sha256':native['bindings'][name],'current_raw_sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),'current_lf_sha256':None if pathlib.Path(name).suffix in ['.blend','.glb','.png'] else hashlib.sha256((ROOT/name).read_bytes().replace(b'\r\n',b'\n')).hexdigest(),'consumer':'Active retained-grade source producer export_retained_grade_sources.py and strict surface input discovery tools/v2_surface_evidence.py;old discovery entry is historical provenance,not renewed. CurrentGLB geometry independently surveyed.'} for name in native_binding_stale]}
(OUT/'ADMISSION_02.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k not in ['stock_bounds','source_bindings','receiving_grade_samples','refinements']},indent=2))
