from pathlib import Path
import json,hashlib,math,re
P=Path(__file__).parent;f=P/'exterior_route_07/city_exterior_contract.json';d=json.loads(f.read_text(encoding='utf8'));o=d['observations'];cols=o['placement_cost_control']['columns']
def q(v,p):
 v=sorted(v);i=(len(v)-1)*p;a=math.floor(i);b=math.ceil(i);return v[a]+(v[b]-v[a])*(i-a)
def stats(v):return dict(samples=len(v),p50=q(v,.5),p95=q(v,.95),p99=q(v,.99),maximum=max(v))
blocks=[]
for b in o['placement_cost_control']['blocks']:
 rows=b['samples'];blocks.append(dict(placed=b['placed'],columns={c:stats([r[i] for r in rows]) for i,c in enumerate(cols)}))
r=dict(evidence_class='INERT',scope='Statistics from original failed route07. Warmed same-process ABBA placement diagnostic on current geometry, uncontrolled NPC/traffic/caches, no matched construction before/after or causal cost attribution. The five grade assertion failures remain failures.',source_contract_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),resolution=o['resolution'],msaa=o['msaa'],taa=o['taa'],startup_settle_wall_ms=stats(o['startup_settle_wall_ms']),placement_blocks=blocks,failures=d['failures'])
(P/'route07_frame_summary.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8',newline='\n')
print('Cold settle',r['startup_settle_wall_ms'])
for b in blocks: print('placed',b['placed'],'wall',b['columns']['wall_ms'],'GPU',b['columns']['main_render_gpu_ms'],'draws',b['columns']['engine_draws']['p50'])
