from pathlib import Path
import json,hashlib
R=Path('C:/ov/city');P=Path(__file__).parent;p=R/'art/blender/city_streets_construction.json';d=json.loads(p.read_text());rows=[]
for x in [-20.6,-26.5,-35.2,-45.25,-56.25]:
 for y,expected in [(-10,False),(-10.1,True)]:
  matches=[]
  for r in d['stocks']:
   if r['lod']!=0 or r['finish']!='walk' or not r['id'].startswith('Walk_'):continue
   q=r['polygon'];inside=all((b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0])>=-1e-9 for a,b in zip(q,q[1:]+q[:1]))
   if inside:matches.append(r['id'])
  assert bool(matches)==expected,(x,y,matches)
  rows.append({'source':[x,y],'expected_sidewalk_field':expected,'actual_closed_stocks':matches})
result={'evidence_class':'INERT','scope':'Authored closed-stock polygon classification of original joint rays and added field rays; imported/composed checks remain separate. No geometry edit.','source_sha256':hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest(),'asset_sha256':d['asset_sha256'],'rows':rows,'status':'PASS'}
(P/'street_joint_probe_control_01.json').write_text(json.dumps(result,indent=2)+'\n')
print('All five original rays are in open joints; all five adjacent field rays are inside native sidewalk stocks')
