# Gate board - f734a173610d

- commit `f734a173610df6fabc439e43d8bedb425c50d934`
- tree `08a238ece82952a3c4a582a8837ff11e1cc65e8d`
- created 2026-10-30T03:13:39Z
- dirty paths: 2357

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| spatial | PASS | 0 | 16.05 | no defects counted |
| reader | PASS | 0 | 4.41 | unread 1091; vs frozen baseline: new 0, resolved 217 |
| test:test_city_ground_apron | PASS | 0 | 1.03 | ran 5, failed 0 |
