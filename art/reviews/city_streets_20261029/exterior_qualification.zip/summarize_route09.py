from pathlib import Path
import json,hashlib,math,re
P=Path(__file__).parent;f=P/'exterior_route_09/city_exterior_contract.json';d=json.loads(f.read_text(encoding='utf8'));o=d['observations']
def q(v,p):
 v=sorted(v);i=(len(v)-1)*p;a=math.floor(i);b=math.ceil(i);return v[a]+(v[b]-v[a])*(i-a)
def stats(v):return dict(samples=len(v),p50=q(v,.5),p95=q(v,.95),p99=q(v,.99),maximum=max(v))
r=dict(evidence_class='INERT',scope='Statistics from unmodified passing route09 contract. Live NPC/traffic/caches uncontrolled; captures excluded from walking samples; viewport GPU excludes private viewports; engine counters global. No matched before/after, causal spike attribution, full-city or artistic acceptance.',source_contract_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),resolution=o['resolution'],msaa=o['msaa'],taa=o['taa'],startup_settle_wall_ms=stats(o['startup_settle_wall_ms']),programmes={})
cols=['wall_ms','main_render_cpu_ms','main_render_gpu_ms','engine_draws','engine_primitives']
for k in ['street_block','wider_street']:
 b=o[k];rows=b['samples'];r['programmes'][k]=dict(waypoints=b['waypoints'],columns={c:stats([v[i] for v in rows]) for i,c in enumerate(cols)},worst_wall_samples=sorted([dict(index=i,wall_ms=v[0],cpu_ms=v[1],gpu_ms=v[2]) for i,v in enumerate(rows)],key=lambda v:v['wall_ms'],reverse=True)[:10],wall_above_33_333=sum(v[0]>1000/30 for v in rows),wall_above_66_667=sum(v[0]>1000/15 for v in rows))
r['placement_blocks']=[dict(placed=b['placed'],columns={c:stats([v[i] for v in b['samples']]) for i,c in enumerate(o['placement_cost_control']['columns'])}) for b in o['placement_cost_control']['blocks']]
r['radius_limit']=o['radius_limit'];r['station_route']=o['station_route']
(P/'route09_frame_summary.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8',newline='\n')
print('startup settle',r['startup_settle_wall_ms'])
for k,v in r['programmes'].items():print(k,'points',v['waypoints'],'wall',v['columns']['wall_ms'],'GPU',v['columns']['main_render_gpu_ms'],'draws',v['columns']['engine_draws']['p50'],'max prims',v['columns']['engine_primitives']['maximum'])
print('radius',r['radius_limit'])
