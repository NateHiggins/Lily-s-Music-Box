$ErrorActionPreference='Stop'
Set-Location C:/PleaseRemainOnTheLine
@{pid=$PID;created_utc=(Get-Process -Id $PID).StartTime.ToUniversalTime().ToString('o');batch="$PSScriptRoot/batch.json"} | ConvertTo-Json | Set-Content -Encoding utf8 -LiteralPath "$PSScriptRoot/broker.json"
& C:/PleaseRemainOnTheLine/tools/lane.ps1 batch -BatchFile "$PSScriptRoot/batch.json" -WaitMinutes 240
exit $LASTEXITCODE
