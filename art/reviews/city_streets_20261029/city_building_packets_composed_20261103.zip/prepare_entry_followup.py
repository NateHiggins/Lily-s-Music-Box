"""Prepare existing city entry/optical/matched routes after composed review; never autoqueue."""
from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys

ROOT = Path('C:/PleaseRemainOnTheLine')
OUT = Path(__file__).parent
sys.path.insert(0, str(ROOT / 'tools'))
from v2_surface_evidence import file_hash, test_dependency_paths


def digest():
    return subprocess.check_output([sys.executable, 'tools/run_receipt.py', 'digest', '--root', str(ROOT)], cwd=ROOT, text=True).strip()


def sources():
    starts = {ROOT / p for p in [
        'game/tests/TitleContinueActualLaunchTest.tscn',
        'game/tests/title_continue_actual_launch_test.gd',
        'game/tests/V2CityTransportRoute.tscn',
        'game/tests/v2_city_transport_route.gd',
        'game/tests/native_debug_window.gd',
    ]}
    return {p.relative_to(ROOT).as_posix(): file_hash(p)
            for p in sorted(test_dependency_paths(ROOT, starts)) if p.is_file()}


def checked_receipt(run, name):
    r = json.loads((run / (name + '.log.receipt.json')).read_text(encoding='utf-8-sig'))
    e, log = r['execution'], r['log']
    assert e['completed'] and e['exit_code'] == 0 and not e['timed_out'], (name, e)
    assert not log['script_error_count'] and not log['fail_count'], (name, log)
    for stream in ['stdout', 'stderr']:
        assert hashlib.sha256(Path(log[stream]).read_bytes()).hexdigest() == log[stream + '_sha256']
    return r


def check_run(run, after):
    frozen = json.loads((run / 'SOURCE_FREEZE.json').read_bytes())
    assert digest() == frozen['runtime_inputs_sha256'], 'production source changed'
    assert sources() == frozen['files'], 'consumed test source changed'
    if after:
        for name in ['title_begin', 'optical', 'baseline', 'entry']:
            checked_receipt(run, name)
        title = json.loads((run / 'title_begin.json').read_bytes())
        assert title['checks'] and all(title['checks'].values())
        prep = title['entry_render_preparation']
        assert prep['completed'] and prep['render_calls'] == 10 and prep['node_pose_unchanged']
        optical = json.loads((run / 'optical/preparation_views.json').read_bytes())
        assert optical['checks'] > 0 and not optical['failures']
        assert len(optical['views']) == 4 and optical['source_before'] == optical['source_after'] == frozen['runtime_inputs_sha256']
        assert len(list((run / 'optical').glob('preparation_*.png'))) == 5
        pair = {}
        for name in ['baseline', 'entry']:
            row = json.loads((run / name / 'stutter_probe.json').read_bytes())
            assert not row['failures'] and len(row['legs']) == len(row['trace']) == 6
            assert all(leg['reached'] and leg['sample_count'] > 0 for leg in row['legs'])
            assert row['source_before'] == row['source_after'] == frozen['runtime_inputs_sha256']
            pair[name] = row
        ignored = {'render_preparation_diagnostic_only', 'render_preparation_mode'}
        settings = [{k: v for k, v in pair[name]['settings'].items() if k not in ignored}
                    for name in ['baseline', 'entry']]
        assert settings[0] == settings[1], 'matched route settings differ'
        assert pair['baseline']['settings']['render_preparation_mode'] == ''
        assert pair['entry']['settings']['render_preparation_mode'] == 'entry'
    print('ENTRY FOLLOWUP SOURCE/EXECUTION GUARD PASS; inspect actual images and measure distributions separately; no frame-budget or artistic acceptance')


if len(sys.argv) > 1:
    if sys.argv[1] == '--check-prerequisites':
        required = [OUT / 'composed_02/surface/runtime_contract.json', OUT / 'composed_02/REVIEW.json']
        missing = [str(p) for p in required if not p.is_file()]
        print(json.dumps({'ready': not missing, 'missing': missing}))
        sys.exit(2 if missing else 0)
    check_run(Path(sys.argv[1]), len(sys.argv) > 2 and sys.argv[2] == 'after')
else:
    subprocess.run([sys.executable, str(OUT / 'prepare_composed_02.py'),
                    str(OUT / 'composed_02'), 'after'], cwd=ROOT, check=True)
    review = json.loads((OUT / 'composed_02/REVIEW.json').read_bytes())
    assert review.get('technical_followup_ready') is True and review.get('images')
    for image in review['images']:
        assert image.get('inspected') is True
        assert hashlib.sha256(Path(image['path']).read_bytes()).hexdigest() == image['sha256']
    source = json.loads(Path('C:/ov/reports/entry_render_preparation_20261102/footprint_16/batch.json').read_bytes())
    wanted = ['title_begin', 'baseline', 'entry']
    originals = {name: next(j for j in source if Path(j['log']).name == name + '.log') for name in wanted}
    run = OUT / 'entry_followup_01'
    run.mkdir(exist_ok=False)
    (run / 'SOURCE_FREEZE.json').write_text(json.dumps(dict(runtime_inputs_sha256=digest(), files=sources()), indent=2) + '\n', encoding='utf-8')
    jobs = []
    def guard(name, mode):
        jobs.append(dict(gpu=[sys.executable, str(Path(__file__)), str(run), mode],
                         scene='City entry ' + name + ' source guard', log=str(run / (name + '.log')), timeout=180))
    guard('before', 'before')
    title = copy.deepcopy(originals['title_begin'])
    title['log'] = str(run / 'title_begin.log')
    title['shot_dir'] = str(run / 'title_begin')
    title['environment']['TITLE_ACTUAL_RECEIPT'] = str(run / 'title_begin.json')
    jobs.append(title)
    optical = copy.deepcopy(originals['entry'])
    optical['log'] = str(run / 'optical.log')
    optical['shot_dir'] = str(run / 'optical')
    optical['environment']['ORISON_CITY_CAPTURE_PREPARATION'] = '1'
    jobs.append(optical)
    for name in ['baseline', 'entry']:
        job = copy.deepcopy(originals[name])
        job['log'] = str(run / (name + '.log'))
        job['shot_dir'] = str(run / name)
        job['environment']['ORISON_CITY_CAPTURE_PREPARATION'] = None
        jobs.append(job)
    guard('after', 'after')
    assert len(jobs) == 6 and all('footprint_16' not in json.dumps(j) for j in jobs)
    (run / 'batch.json').write_text(json.dumps(jobs, indent=2) + '\n', encoding='utf-8')
    (run / 'run_batch.ps1').write_bytes((OUT / 'composed_02/run_batch.ps1').read_bytes())
    print('PREPARED ONLY:', run / 'batch.json', '; no automatic queue or performance claim')
