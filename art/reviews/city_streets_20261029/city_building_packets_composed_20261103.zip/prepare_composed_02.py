"""Prepare one composed physical/city run after inspected loaded diagnostics; never autoqueue."""
from pathlib import Path
import json,hashlib,subprocess,sys
root=Path('C:/PleaseRemainOnTheLine');out=Path(__file__).parent
sys.path.insert(0,str(root/'tools'))
from v2_surface_evidence import file_hash,test_dependency_paths

def digest():return subprocess.check_output([sys.executable,'tools/run_receipt.py','digest','--root',str(root)],cwd=root,text=True).strip()
def sources():
 starts={root/p for p in ['game/tests/OrisonV2SurfaceInventory.tscn','game/tests/orison_v2_surface_inventory.gd','game/tests/CompileChangedScripts.tscn','game/tests/compile_changed_scripts.gd','game/tests/native_debug_window.gd','game/tests/MaterialLibraryTest.tscn','game/tests/material_library_test.gd']}
 return {p.relative_to(root).as_posix():file_hash(p) for p in sorted(test_dependency_paths(root,starts)) if p.is_file()}

if len(sys.argv)>1:
 run=Path(sys.argv[1]);freeze=json.loads((run/'SOURCE_FREEZE.json').read_bytes())
 assert digest()==freeze['runtime_inputs_sha256'],'production changed since preparation'
 assert sources()==freeze['files'],'consumed survey diagnostics changed'
 if len(sys.argv)>2 and sys.argv[2]=='after':
  for name in ['compile','material','surface']:
   receipt=json.loads((run/(name+'.log.receipt.json')).read_text(encoding='utf-8-sig'));e=receipt['execution'];log=receipt['log']
   assert e['completed'] and e['exit_code']==0 and not e['timed_out'] and not log['script_error_count'] and not log['fail_count'],(name,e)
   for stream in ['stdout','stderr']:assert hashlib.sha256(Path(log[stream]).read_bytes()).hexdigest()==log[stream+'_sha256'],(name,stream)
  assert b'SCRIPT COMPILATION: PASS; 3 scripts; 0 failures; no composed world' in (run/'compile.log').read_bytes()
  assert b'MATERIAL LIBRARY TEST: PASS' in (run/'material.log').read_bytes()
  contract=json.loads((run/'surface/runtime_contract.json').read_bytes())
  assert contract['schema_version']==2 and contract['evidence_kind']=='runtime_contract'
  assert contract['execution']['completed'] and contract['execution']['exit_code']==0 and not contract['execution']['timed_out'] and contract['checks']>0 and not contract['failures']
  assert all(contract['contracts'][key]['executed'] and contract['contracts'][key]['status']=='PASS' for key in ['production_composition','surface_requirements','teardown'])
  assert contract['qualification_mode']=='physical_surfaces_only' and contract['city_geometry_diagnostic']['executed']
  assert contract['city_geometry_diagnostic']['failures']==0 and contract['source']['runtime_inputs_sha256']==freeze['runtime_inputs_sha256']
  assert contract['source']['test_sha256']==hashlib.sha256((root/contract['source']['test_path']).read_bytes()).hexdigest()
  assert not contract['interaction_programmes']['fire_service']['executed'] and not contract['interaction_programmes']['other_family_programmes']['executed']
 print('SOURCE/RECEIPT GUARD PASS; inspect all actual frames and complete stderr separately')
else:
 result=json.loads((out/'assembly_01.result.json').read_bytes());assert result.get('exit_code')==0 and all(p['exit_code']==0 for p in result['phases'])
 comparison=json.loads((out/'assembly_comparison.json').read_bytes());assert len(comparison['checks'])==2203 and not comparison['failures']
 subprocess.run([sys.executable,str(out/'loaded_04/guard_family.py')],check=True,cwd=root)
 review=json.loads((out/'loaded_04/REVIEW.json').read_bytes());assert review.get('technical_followup_ready') is True and review.get('images'),'Actual loaded images must be inspected first'
 for image in review['images']:
  assert image.get('inspected') is True and hashlib.sha256(Path(image['path']).read_bytes()).hexdigest()==image['sha256']
 run=out/'composed_02';run.mkdir(exist_ok=False)
 (run/'SOURCE_FREEZE.json').write_text(json.dumps(dict(runtime_inputs_sha256=digest(),files=sources()),indent=2)+'\n')
 python=sys.executable;jobs=[]
 def cpu(name,mode):jobs.append(dict(gpu=[python,str(Path(__file__)),str(run),mode],scene='City composed '+name+' source guard',log=str(run/(name+'.log')),timeout=180))
 cpu('before','before')
 jobs.append(dict(project=str(root/'game'),scene='res://tests/CompileChangedScripts.tscn',runner='serial',timeout=180,log=str(run/'compile.log'),environment={'ORISON_SCRIPT_CHECK':json.dumps(['res://tests/v2_city_horizon_review.gd','res://tests/v2_control_finish_review.gd','res://tests/material_library_test.gd'])}))
 jobs.append(dict(project=str(root/'game'),scene='res://tests/MaterialLibraryTest.tscn',runner='serial',timeout=180,log=str(run/'material.log')))
 jobs.append(dict(project=str(root/'game'),scene='res://tests/OrisonV2SurfaceInventory.tscn',runner='long',timeout=1500,log=str(run/'surface.log'),shot_dir=str(run/'surface'),windowed=True,extra_args=['--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440'],environment={'ORISON_SURFACE_PHYSICAL_ONLY':'1','ORISON_SURFACE_CITY_REVIEW':'1','ORISON_SURFACE_CITY_ONLY':None,'ORISON_SURFACE_FIRE_ONLY':None,'ORISON_SURFACE_CITY_CONSTRUCTION':None,'ORISON_SURFACE_CITY_CIVIC_ACCESS':None,'ORISON_SURFACE_PREVIEW_PROBE':None,'ORISON_VISIBLE_GODOT':None}))
 cpu('after','after')
 (run/'batch.json').write_text(json.dumps(jobs,indent=2)+'\n')
 print('PREPARED ONLY:',run/'batch.json','; no gameplay, save/reload, performance or artistic acceptance inferred')
