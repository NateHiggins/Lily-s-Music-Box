from pathlib import Path
import sys,json,subprocess,re,hashlib
sys.path.insert(0,'C:/ov/tools/sky_video')
import imageio_ffmpeg
r=Path(__file__).parent
c=json.loads((r/'capture/capture.json').read_bytes())
assert not c['failures'] and c['frames']==300 and c['duration_seconds']==10
frames=sorted((r/'capture/frames').glob('frame_*.png'));assert len(frames)==300
ffmpeg=imageio_ffmpeg.get_ffmpeg_exe();out=r/'Orison_24_Hours_in_10_Seconds.mp4'
subprocess.run([ffmpeg,'-hide_banner','-y','-framerate','30','-i',str(r/'capture/frames/frame_%04d.png'),'-frames:v','300','-c:v','libx264','-preset','medium','-crf','17','-pix_fmt','yuv420p','-movflags','+faststart','-an',str(out)],check=True)
p=subprocess.run([ffmpeg,'-hide_banner','-i',str(out),'-f','null','-'],capture_output=True,text=True,check=True)
(r/'decode_verification.txt').write_text(p.stderr,encoding='utf-8')
assert 'Duration: 00:00:10.00' in p.stderr and re.search(r'frame=\s*300',p.stderr)
(r/'VIDEO_RESULT.json').write_text(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'duration_seconds':10,'frames':300,'fps':30,'decoded_all_frames':True,'visual_review':'PENDING'},indent=2)+'\n',encoding='utf-8')
print('VIDEO ENCODED AND FULLY DECODED:',out)
