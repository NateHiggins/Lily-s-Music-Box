class_name OrisonV2RuntimeRoot
extends Node3D
## Production-service composition over the v2 collision construction.
## Domain behavior remains in the existing production classes below.

const BLOCKOUT := preload("res://scenes/building/orison_v2_blockout.tscn")
const CUES := preload("res://scripts/building/orison_v2_readability_cues.gd")
const Adapter := preload("res://scripts/building/orison_v2_anchor_adapter.gd")
const FrameContract := preload("res://scripts/building/orison_v2_frame_contract.gd")
const LineageRegistry := preload("res://scripts/reality/corruption_lineage_registry.gd")
const WorldConnection := preload("res://scripts/building/orison_v2_world_connection.gd")
const ExteriorResolver := preload("res://scripts/building/orison_v2_exterior_spatial_resolver.gd")
const ExteriorCell := preload("res://scripts/building/orison_v2_exterior_cell.gd")
const ShopSimulation := preload("res://scripts/building/orison_v2_shop_simulation.gd")
const Atmosphere := preload("res://scripts/building/orison_v2_atmosphere.gd")
const DomesticFittings := preload("res://scripts/building/orison_v2_domestic_fittings.gd")
const DomesticFurniture := preload("res://scripts/building/orison_v2_domestic_furniture.gd")
const RoomLighting := preload("res://scripts/building/orison_v2_room_lighting.gd")
const DomesticDoors := preload("res://scripts/building/orison_v2_domestic_doors.gd")
const PassageRegion := preload("res://scripts/building/orison_v2_passage_region.gd")
const BarRegion := preload("res://scripts/building/orison_v2_bar_region.gd")
const StreetBoundaries := preload("res://scripts/building/orison_v2_street_boundaries.gd")
const HouseholdState := preload("res://scripts/building/orison_v2_household_state.gd")
const Wayfinding := preload("res://scripts/building/orison_v2_wayfinding.gd")

var layout: Dictionary = {}
var acoustic_topology
var floor_nodes: Dictionary = {}
var player: PlayerController
var player_avatar: Node3D
var objective_tracker: ObjectiveTracker
var work_orders: WorkOrders
var maintenance_inventory: MaintenanceInventory
var vantry_points: VantryPointNetwork
var chirp_hunt: ChirpHunt
var call_interface: CallInterface
var virus_director: VirusSoundDirector
var mina_gameplay: MinaCaseGameplay
var core_loop: CoreLoopDirector
var safety_net: SafetyNet
var service_set_carrier: ServiceSetCarrier
var first_shift_director: FirstShiftDirector
var prologue_director: Node
var _opening_retry: Timer
var _opening_starting := false
var _opening_placed := false
var service_round: ServiceRoundDirector
var conversations: ResidentConversations
var newspapers: NewspaperCatalog
## The kept papers live on the player's own bookshelf in 4B (V2 furniture
## anchor), at a reachable shelf height above its base.
const PLAYER_SHELF_ANCHOR := "4B_shelf"
const SHELF_PAPERS_HEIGHT := 1.0
const COOKBOOK_TABLE := "KitchenPrep_4B"
const COOKBOOK_AT := Vector3(0.33, 0.9, -0.13)
var boiler_tend: BoilerTend
var heat_balance: HeatBalance
var mirror_renderer: PlanarMirrorRenderer
var bathroom_moisture: Node
var household_state: HouseholdState
var wayfinding: Wayfinding
var open_shift_ecosystem: Node
var observation_ledger: NpcObservationLedger
var resident_presence: ScheduleDirector
## Where residents actually go and why: the timetable bent by needs, weather,
## story and the player (design/ORISON_RESIDENT_AGENDA_2026-10-24.md).
var resident_agenda: ResidentAgenda
var _iceboxes: Array[Node] = []
var _pantries: Dictionary = {}
var mina_routine: Node3D
const ResidentRoute := preload("res://scripts/characters/orison_v2_resident_route.gd")
## The other walking residents' route owners, by resident id.
var resident_routes: Dictionary = {}
var campaign_clock: CampaignClock
var corruption_lineages: CorruptionLineageRegistry
var watch_station_network: WatchStationNetwork
## Patrol station anchor -> WatchStationProp.STATIONS id, one box per floor.
const PATROL_STATIONS := {
	"B1_WATCH_STATION": "B1_STATION_BOILER",
	"F02_WATCH_STATION": "F02_STATION_CORE",
	"F03_WATCH_STATION": "F03_STATION_CORE",
	"F04_WATCH_STATION": "F04_STATION_CORE",
	"F05_WATCH_STATION": "F05_STATION_CORE",
	"F06_WATCH_STATION": "F06_STATION_CORE",
	"F01_WATCH_STATION": "F01_STATION_LOBBY",
}
var street_traffic: Node = null
## Period traffic on the V2 carriageway. Deliberately not `street_traffic`:
## that name still selects V1's sleep-gate probes in the dream boundary test.
var period_traffic: Node3D = null
var elevator: Node = null
var startup_failed := false
var startup_failure_reason := ""
var startup_ms := 0.0
var _contact_precision:=preload("res://scripts/building/v2_contact_precision.gd").new()
var adapter
var _blockout: Node3D
var frame_contract: OrisonV2FrameContract
var exterior_cell: OrisonV2ExteriorCell
var passage_region: OrisonV2PassageRegion
var bar_region: OrisonV2BarRegion
var shop_service: MaintenanceShopService
var fire_maintenance_counter: Node3D
var shop_simulation: Node
var day_night_director: DayNightDirector
var light_rig: LightRig
var service_light_visibility: Node
var touch: TouchControls
var shots: ShotCapture
var warehouse: PropWarehouse
var view_override: Camera3D
var building_debug: BuildingDebug
var mina_infestation: Node3D
var _infestation_revision := 0
var _exterior_resolver: Variant
var public_regions: Variant
var public_landings: Variant
var _connection: Dictionary = {}

func _read_street_frame() -> Dictionary:
	return preload("res://scripts/building/orison_v2_street_frame.gd").load_default()

func _ready() -> void:
	if not _contact_precision.bind(get_world_3d()):
		startup_failed=true;startup_failure_reason="V2 native contact precision unavailable";return
	# Refuse the source boundary before creating campaign services, imported
	# geometry or any actor. Child _ready errors cannot close startup for us.
	if not preload("res://scripts/building/orison_v2_street_frame.gd").valid_source_header(_read_street_frame()):
		startup_failed = true
		startup_failure_reason = "missing or invalid street coordinate frame"
		return
	var started := Time.get_ticks_usec()
	var contact_precision := preload("res://scripts/building/orison_v2_contact_precision.gd").new()
	contact_precision.name="V2ContactPrecision"
	add_child(contact_precision)
	campaign_clock = CampaignClock.new()
	if not campaign_clock.bind_state():
		startup_failed = true
		push_error("ORISON V2 RUNTIME: valid campaign calendar required")
		return
	frame_contract = FrameContract.load_default()
	if not frame_contract.errors.is_empty():
		startup_failed = true
		push_error("ORISON V2 RUNTIME: invalid shared-frame contract: %s" %
				[frame_contract.errors])
		return
	corruption_lineages = LineageRegistry.new()
	if not corruption_lineages.load_registry():
		startup_failed = true
		push_error("ORISON V2 RUNTIME: invalid corruption lineage registry")
		return
	add_to_group("building_root")
	add_to_group("orison_v2_runtime")
	var atmosphere := Atmosphere.new()
	atmosphere.name = "WakingAtmosphere"
	add_child(atmosphere)
	day_night_director = atmosphere.director
	_blockout = BLOCKOUT.instantiate()
	_blockout.show_clearance_anchors = false
	_blockout.show_reservation_volumes = false
	_blockout.production_materials = true
	_exterior_resolver = ExteriorResolver.load_default()
	_connection = WorldConnection.prepare(
			WorldConnection.read_object(_blockout.layout_path),
			WorldConnection.read_object(ExteriorCell.GEOMETRY_PATH),
			_exterior_resolver, WorldConnection.read_object(WorldConnection.CONFIG_PATH))
	if _connection.is_empty():
		_blockout.free()
		_blockout = null
		startup_failed = true
		push_error("ORISON V2 RUNTIME: front-door world connection refused")
		return
	_blockout.transform = _connection.interior_transform
	_blockout.space_geometry_exclusions.assign([_connection.excluded_space, "F01_REAR_APRON"])
	add_child(_blockout)
	if not _blockout.failures.is_empty():
		startup_failed = true
		return
	layout = _blockout.layout
	var service_alley := preload("res://scripts/building/orison_v2_service_alley.gd").new()
	service_alley.name = "ServiceAlley"
	_blockout.add_child(service_alley)
	for level: Dictionary in layout.get("levels", []):
		floor_nodes[str(level.id)] = _blockout
	adapter = Adapter.new(_blockout)
	if not adapter.resolves_required_uniquely():
		startup_failed = true
		push_error("ORISON V2 RUNTIME: unresolved or duplicate required anchor")
		return
	var cues := CUES.new()
	cues.show_bed_context = false
	cues.show_terminal_context = false
	cues.show_floor_context = false
	cues.show_portal_masses = false
	cues.show_route_bands = false
	cues.show_light_pools = false  # Accord 15: every lumen has a fixture; the cue pools are development aids
	_blockout.add_child(cues)
	wayfinding = Wayfinding.new()
	wayfinding.name = "Wayfinding"
	_blockout.add_child(wayfinding)
	if not wayfinding.mount(_blockout.layout):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: incomplete stair wayfinding")
		return
	acoustic_topology=preload("res://scripts/building/orison_v2_acoustic_topology.gd").new()
	if not acoustic_topology.mount(adapter,layout):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: acoustic binding failed: "+str(acoustic_topology.errors))
		return
	await _compose_authorities()
	if startup_failed:
		return
	elevator = preload("res://scripts/building/orison_v2_elevator.gd").new().mount(adapter, layout)
	if elevator == null:
		startup_failed = true
		push_error("V2 passenger lift could not be composed")
		return
	var lift_drive := preload("res://scripts/building/orison_v2_lift_drive.gd").new()
	var porter_board := adapter.resolve("LobbyPorterBoard") as OtisProp
	if porter_board==null or not porter_board.bind_native_lift(elevator as OrisonElevator):
		startup_failed=true
		push_error("V2 porter dispatch could not bind the passenger lift")
		return
	if not lift_drive.configure(elevator as OrisonElevator) or not adapter.mount_consumer("ROOF_LIFT_DRIVE",lift_drive):
		lift_drive.free()
		startup_failed = true
		push_error("V2 guarded lift drive could not be composed")
		return
	if not preload("res://scripts/building/orison_v2_ventilation.gd").new().mount(adapter,layout):
		startup_failed = true
		push_error("V2 shared ventilation could not be composed")
		return
	if not acoustic_topology.physical_owners_valid(adapter):
		startup_failed=true
		push_error("V2 acoustic route disagrees with its physical owner: "+str(acoustic_topology.errors))
		return
	var roof_drainage:=preload("res://scripts/building/orison_v2_roof_drainage.gd").new()
	if not roof_drainage.mount(self):
		startup_failed=true
		push_error("ORISON V2 RUNTIME: roof drainage refused: %s" % [roof_drainage.errors])
		return
	var fixed_lighting := preload("res://scripts/building/orison_v2_native_fixed_lighting.gd").new()
	if not fixed_lighting.mount(self):
		startup_failed = true
		push_error("V2 native fixed lighting refused: %s" % [fixed_lighting.errors])
		return
	adapter.root.set_meta("v2_native_fixed_lighting_factory", fixed_lighting)
	var front_lighting := preload("res://scripts/building/orison_v2_native_front_lighting.gd").new()
	if not front_lighting.mount(self):
		startup_failed = true
		push_error("V2 front lighting refused: %s" % [front_lighting.errors])
		return
	adapter.root.set_meta("v2_native_front_lighting_factory",front_lighting)
	var work_lights := preload("res://scripts/building/orison_v2_native_service_work_lights.gd").new()
	if not work_lights.mount(self,fixed_lighting,adapter.root.get_meta("v2_native_service_instruments")):
		startup_failed=true
		push_error("V2 service work lights refused: %s" % [work_lights.errors])
		return
	adapter.root.set_meta("v2_native_service_work_lights",work_lights)
	var cage_apertures := preload("res://scripts/building/orison_v2_cage_light_apertures.gd").new()
	if not cage_apertures.setup(self,light_rig):
		startup_failed=true
		push_error("V2 native cage-light aperture refused: %s" % [cage_apertures.errors])
		return
	adapter.root.set_meta("v2_cage_light_apertures",cage_apertures)
	var lamp_air := preload("res://scripts/building/orison_v2_lamp_atmosphere.gd").new()
	lamp_air.name = "LampAtmosphere"
	add_child(lamp_air)
	if not lamp_air.setup(player, atmosphere.environment):
		startup_failed = true
		push_error("V2 lamp optical state could not be restored")
		return
	preload("res://scripts/building/orison_v2_owner_building_finishes.gd").new().apply(self)
	preload("res://scripts/building/v2_legacy_material_stock.gd").apply(self)
	var embedded_stock := preload("res://scripts/building/v2_embedded_surface_stock.gd").new()
	embedded_stock.name = "V2EmbeddedSurfaceStock"; add_child(embedded_stock)
	var uv_policy := preload("res://scripts/building/orison_v2_uv_material_policy.gd").new()
	uv_policy.name = "V2UVMaterialPolicy"; add_child(uv_policy)
	uv_policy.setup(self)
	atmosphere.bind_weather(self)
	bathroom_moisture=preload("res://scripts/building/v2_bathroom_moisture.gd").new()
	bathroom_moisture.name="BathroomMoisture";add_child(bathroom_moisture)
	if not bathroom_moisture.configure(self):
		startup_failed=true;push_error("V2 bathroom moisture bindings refused");return
	_compose_debug_controls()
	get_node("CaretakerNotebook").debug = building_debug
	var room_reflections := preload("res://scripts/building/orison_v2_room_reflections.gd").new()
	room_reflections.name="V2RoomReflections"
	add_child(room_reflections)
	if not room_reflections.setup(self):
		startup_failed=true
		push_error("V2 room reflection layout could not be composed")
		return
	var structural_occlusion := preload("res://scripts/building/orison_v2_structural_occlusion.gd").new()
	structural_occlusion.name="V2StructuralOcclusion"
	add_child(structural_occlusion)
	structural_occlusion.setup(_blockout)
	startup_ms = float(Time.get_ticks_usec() - started) / 1000.0
	print("[ORISON V2 RUNTIME] ready startup_ms=%.3f" % startup_ms)

## Called by the existing onboarding owner. Returning true reserves startup
## even while composition/input is busy; never fall back to the old curb spawn.
func request_prologue_entry() -> bool:
	var shell := get_tree().get_first_node_in_group("campaign_shell") as CampaignShell
	if shell == null or shell.active_world != self or not shell.uses_prologue_entry():
		return false
	if not is_instance_valid(_opening_retry):
		_opening_retry = Timer.new()
		_opening_retry.wait_time = 0.2
		_opening_retry.timeout.connect(_try_prologue_entry)
		add_child(_opening_retry)
		_opening_retry.start()
	return true


func _try_prologue_entry() -> void:
	if startup_failed:
		_opening_retry.stop()
		var failed_shell := get_tree().get_first_node_in_group("campaign_shell") as CampaignShell
		if failed_shell != null:failed_shell.release_opening_veil(self)
		return
	if _opening_starting or startup_ms <= 0.0 \
			or get_tree().paused or RealityState.save_write_blocked:
		return
	var shell := get_tree().get_first_node_in_group("campaign_shell") as CampaignShell
	if shell == null or shell.active_world != self or not shell.uses_prologue_entry():
		_opening_retry.stop()
		return
	if player.protected_input_active() or player.text_input_owner != null or not player.camera.is_current():
		return
	_opening_starting = true
	# Support-wall rays need a registered physics world, not merely a finished
	# asynchronous _ready. Recheck ownership after the yield before moving anyone.
	await get_tree().physics_frame
	_opening_starting = false
	if not is_inside_tree() or shell.active_world != self or get_tree().paused \
			or RealityState.save_write_blocked or not shell.uses_prologue_entry():
		return
	if player.protected_input_active() or player.text_input_owner != null or not player.camera.is_current():
		return
	if not _opening_placed:
		if not core_loop.return_player_to_safe_anchor():
			_opening_retry.stop()
			startup_failed = true
			startup_failure_reason = "Production prologue bedside anchor unavailable"
			push_error(startup_failure_reason)
			shell.release_opening_veil(self)
			return
		_opening_placed = true
	if not is_instance_valid(prologue_director):
		prologue_director = preload("res://scripts/game/prologue_director.gd").new()
		prologue_director.name = "PrologueDirector"
		add_child(prologue_director)
		if not prologue_director.configure(self):
			_opening_retry.stop()
			prologue_director.shutdown()
			startup_failed = true
			startup_failure_reason = "Production prologue binding failed"
			# Do not hide diagnostic/pause UI behind a failed loading presentation.
			shell.release_opening_veil(self)
			return
		prologue_director.phase_changed.connect(_on_prologue_phase_changed)
	if prologue_director.resume_opening(preload("res://assets/props/prologue_wake_cover.glb")):
		_opening_retry.stop()
		# The retired title used a free pointer. Capture only after our own
		# presentation is accepted; never steal a deliberately released pointer.
		if not player.mouse_released and not player.protected_input_active():
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		shell.release_opening_veil(self)
		_on_prologue_phase_changed(str(prologue_director.state.phase))
	elif not prologue_director.errors.is_empty():
		_opening_retry.stop()
		prologue_director.shutdown()
		startup_failed = true
		startup_failure_reason = "Production prologue presentation failed"
		shell.release_opening_veil(self)


func _on_prologue_phase_changed(phase: String) -> void:
	if phase == "prologue_complete":
		first_shift_director.acknowledge_replacement_intro()


func _compose_authorities() -> void:
	objective_tracker = ObjectiveTracker.new()
	objective_tracker.name = "ObjectiveTracker"
	objective_tracker.presentation_enabled = false
	add_child(objective_tracker)
	work_orders = WorkOrders.new()
	work_orders.name = "WorkOrders"
	work_orders.setup(objective_tracker)
	work_orders.bind_job_library(MaintenanceJobLibrary.load_default())
	add_child(work_orders)
	maintenance_inventory = MaintenanceInventory.new()
	maintenance_inventory.name = "MaintenanceInventory"
	maintenance_inventory.setup()
	add_child(maintenance_inventory)
	_compose_vantry()
	var mail_bank := MailBankProp.new()
	mail_bank.set_meta("v2_mail_bank_visuals", true)
	mail_bank.inventory = maintenance_inventory
	_mount("LobbyMailBank", mail_bank)
	if not mail_bank.get_meta("v2_native_mail_bank", false):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: native mail bank mount failed")
		return
	_mount("LobbyPorterBoard", OtisProp.new())
	var tank_ballcock := RoofTankBallcockProp.new()
	tank_ballcock.prop_type = "tank_ballcock"
	_mount("ROOF_TANK_BALLCOCK", tank_ballcock)
	_compose_service_round_props()
	if startup_failed: return
	if not DomesticDoors.new().mount(adapter, layout):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: domestic door mounting refused")
		return
	if not preload("res://scripts/building/orison_v2_upper_floor_doors.gd").new().mount(adapter, layout):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: upper floor door mounting refused")
		return
	preload("res://scripts/building/orison_v2_bathroom_finishes.gd").build(_blockout,layout,_blockout.level_y,_blockout.architectural_materials,preload("res://scripts/building/orison_v2_millwork.gd").collect_wall_stock(_blockout))
	var fittings := DomesticFittings.new()
	if not fittings.mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: domestic fittings refused: %s" % [fittings.errors])
		return
	var completion := preload("res://scripts/building/orison_v2_completion_interiors.gd").new()
	if not completion.mount(adapter,layout,self):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: remaining interiors refused: %s" % [completion.errors])
		return
	preload("res://scripts/building/orison_v2_reading_furniture.gd").mount(adapter,layout)
	preload("res://scripts/building/orison_v2_public_furnishings.gd").mount(adapter,layout)
	if not preload("res://scripts/building/orison_v2_door_casings.gd").mount(adapter,layout):
		startup_failed=true
		push_error("ORISON V2 RUNTIME: native mitered door casings refused")
		return
	preload("res://scripts/building/orison_v2_window_joinery.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_exterior_masonry.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_front_restoration.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_fire_repairs.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_roof_edge_support.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_roof_bulkhead_caps.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_roof_service_weathering.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_light_court_structure.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_light_court_skylight.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_court_roof_bridge.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_roof_public_weathering.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_roof_base_flashings.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_roof_membrane.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_front_court_roof.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_foundations.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_ceiling_top_closures.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_ground_core_transfer.gd").mount(_blockout)
	# Dossier slice 52: positional wear decals in the baths and halls.
	if not preload("res://scripts/building/orison_v2_positional_wear.gd").mount(_blockout):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: positional wear refused")
	preload("res://scripts/building/orison_v2_rear_wing_a_support.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_rear_wing_c_support.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_first_upper_hall_seats.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_upper_wall_seats.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_remaining_upper_transfers.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_house_tank.gd").mount(_blockout)
	preload("res://scripts/building/orison_v2_roof_coping.gd").mount(_blockout)
	if not preload("res://scripts/building/orison_v2_basement.gd").new().mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: basement services refused")
		return
	if not _compose_hot_water():
		return
	var furniture := DomesticFurniture.new()
	if not preload("res://scripts/building/orison_v2_laundry.gd").new().mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: laundry mounting refused")
		return
	if not furniture.mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: furniture refused: %s" % [furniture.errors])
		return
	# All replacement fittings/furniture now exist. Standalone gray-box scenes
	# retain their masses; the playable apartment has one physical owner per use.
	for identity in ["F02_B_FABRIC_TABLE_MASS", "F02_B_KITCHEN_RUN_MASS",
			"F02_B_BED_MASS", "F02_B_STORAGE_MASS", "F02_B_BATH_MASS"]:
		_retire_blockout_fixture(identity)
	if startup_failed:
		return
	var lighting := RoomLighting.new()
	if not lighting.mount(adapter, self):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: room lighting refused: %s" % [lighting.errors])
		return
	if not lighting.mount_roof(adapter,self):
		startup_failed=true
		push_error("ORISON V2 RUNTIME: roof plant lighting refused: %s" % [lighting.errors])
		return
	if not preload("res://scripts/building/orison_v2_reading_nook.gd").mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: original reading nook refused")
		return
	var task_lamps := preload("res://scripts/building/orison_v2_task_lamp_installations.gd").new()
	if not task_lamps.mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: fitted task lamps refused: %s" % [task_lamps.errors])
		return
	var lamp_supply := preload("res://scripts/building/orison_v2_task_lamp_supply.gd").new()
	if not lamp_supply.mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: task-lamp supply refused: %s" % [lamp_supply.errors])
		return
	adapter.root.set_meta("v2_task_lamp_supply",lamp_supply)
	light_rig = LightRig.new()
	light_rig.name = "LightRig"
	light_rig.glow_intensity = get_node("WakingAtmosphere").environment.glow_intensity
	get_node("WakingAtmosphere").add_child(light_rig)
	# Retain every light and its personality; rank eight local shadow casters.
	# Native 4B attribution: ~41 -> 28.5 ms, with the same near-room lighting.
	# Keep smaller platform budgets and explicit diagnostic overrides intact.
	light_rig.set_budgets(light_rig._active_budget,mini(light_rig._shadow_budget,8))
	var telephone := HouseSwitchboardProp.new()
	telephone.set_meta("v2_house_switchboard",true)
	var line := HouseTelephoneNetwork.new()
	line.name = "HouseTelephoneNetwork"
	add_child(line)
	line.register_endpoint({"id": "F02_A_TELEPHONE", "extension": "2A"})
	telephone.bind_line(line)
	_mount("F01_HOUSE_TELEPHONE_BOARD", telephone)
	if not telephone.get_meta("v2_native_house_switchboard",false) or not telephone.get_meta("v2_switchboard_physical",false):
		startup_failed=true
		push_error("ORISON V2 RUNTIME: native physical house telephone refused")
		return
	_mount("LobbyServiceDumbwaiter", DumbwaiterProp.new())
	var terminal := preload("res://scripts/building/orison_v2_native_signal_terminal.gd").new()
	terminal.prop_type = "signal_terminal"
	_mount("F04_B_MONITOR_01", terminal)
	if not terminal.native_ready:
		startup_failed = true
		push_error("ORISON V2 RUNTIME: native signal terminal refused")
		return
	if not preload("res://scripts/building/orison_v2_task_lamp_installations.gd").fit_terminal(adapter, terminal):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: task lamp/terminal fit refused")
		return
	player = PlayerController.new()
	player.name = "Player"
	player.position = _connection.arrival.position
	add_child(player)
	player.enable_low_step_probe()
	player_avatar=preload("res://scripts/player/doodle_player_avatar.gd").new()
	player_avatar.name="ReflectedPlayer";player_avatar.holder=player;player.add_child(player_avatar)
	if not player_avatar.native_ready:
		startup_failed=true;push_error("ORISON V2 RUNTIME: owner player rig refused");return
	if not _compose_exterior():
		startup_failed = true
		push_error("ORISON V2 RUNTIME: exterior composition failed")
		return
	vantry_points.bind_player(player)
	service_set_carrier = preload("res://scripts/device/companion_world_carrier.gd").new()
	service_set_carrier.name = "ServiceSetCarrier"
	await service_set_carrier.setup(player, player.camera, work_orders)
	if not bool(service_set_carrier.get("world_ready")):
		startup_failed = true
		startup_failure_reason = str(service_set_carrier.get("failure"))
		return
	player.carried_device = service_set_carrier
	player.set_lamp_enabled(true)
	call_interface = CallInterface.new()
	call_interface.name = "CallInterface"
	call_interface.world = _blockout
	add_child(call_interface)
	if not _compose_call_station(terminal):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: invalid support desk anchors")
		return
	virus_director = VirusSoundDirector.new()
	virus_director.name = "VirusSoundDirector"
	virus_director.setup(self)
	add_child(virus_director)
	first_shift_director = FirstShiftDirector.new()
	first_shift_director.name = "FirstShiftDirector"
	first_shift_director.setup(self, objective_tracker, virus_director, work_orders)
	add_child(first_shift_director)
	_bind_first_shift_station()
	mina_gameplay = MinaCaseGameplay.new()
	mina_gameplay.name = "MinaCaseGameplay"
	mina_gameplay.setup(objective_tracker, work_orders)
	add_child(mina_gameplay)
	if not preload("res://scripts/building/orison_v2_case_one_placement.gd").new().mount(adapter, mina_gameplay):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: incomplete case-one placement")
		return
	var surface_props := preload("res://scripts/building/orison_v2_surface_props.gd").new()
	if not surface_props.mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: surface props refused: %s" % [surface_props.errors])
		return
	var bath_details := preload("res://scripts/building/orison_v2_bath_details.gd").new()
	if not bath_details.mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: bathroom details refused: %s" % [bath_details.errors])
		return
	var radios := preload("res://scripts/building/orison_v2_radios.gd").new()
	if not radios.mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: household radios refused: %s" % [radios.errors])
		return
	var projectors := preload("res://scripts/building/orison_v2_projectors.gd").new()
	if not projectors.mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: apartment projectors refused: %s" % [projectors.errors])
		return
	var media_supply := preload("res://scripts/building/orison_v2_media_ac_supply.gd").new()
	if not media_supply.mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: media AC supply refused: %s" % [media_supply.errors])
		return
	var battery_supply := preload("res://scripts/building/orison_v2_media_battery_supply.gd").new()
	if not battery_supply.mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: media battery supply refused: %s" % [battery_supply.errors])
		return
	var accessories := preload("res://scripts/building/orison_v2_household_accessories.gd").new()
	if not accessories.mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: household accessories refused: %s" % [accessories.errors])
		return
	var bookshelves := preload("res://scripts/building/orison_v2_bookshelves.gd").new()
	if not bookshelves.mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: bookshelves refused: %s" % [bookshelves.errors])
		return
	var fire_service := preload("res://scripts/building/orison_v2_native_fire_service.gd").new()
	if not fire_service.mount(adapter,_blockout.layout):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: fire service refused: %s" % [fire_service.errors])
		return
	adapter.root.set_meta("v2_native_fire_service",fire_service)
	if not fire_service.mount_hose_deployment():
		startup_failed=true
		push_error("ORISON V2 RUNTIME: hose deployment refused: %s"%[fire_service.errors])
		return
	var player_fire_contact:=preload("res://scripts/building/v2_fire_player_contact.gd").new()
	if not player_fire_contact.configure(player,fire_service.stations):
		startup_failed=true
		push_error("ORISON V2 RUNTIME: player fire contact refused: %s"%[player_fire_contact.errors])
		return
	adapter.root.set_meta("v2_fire_player_contact",player_fire_contact)
	var electrical_service := preload("res://scripts/building/orison_v2_native_electrical_service.gd").new()
	if not electrical_service.mount(adapter):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: electrical service refused: %s" % [electrical_service.errors])
		return
	adapter.root.set_meta("v2_native_electrical_service",electrical_service)
	var electrical_connections := preload("res://scripts/building/orison_v2_native_electrical_connections.gd").new()
	if not electrical_connections.mount(self,electrical_service):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: electrical connections refused: %s" % [electrical_connections.errors])
		return
	adapter.root.set_meta("v2_native_electrical_connections",electrical_connections)
	var roof_supply := preload("res://scripts/building/orison_v2_roof_lighting_supply.gd").new()
	if not roof_supply.mount(self, electrical_service):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: roof lighting supply refused: %s" % [roof_supply.errors])
		return
	adapter.root.set_meta("v2_native_roof_lighting_supply", roof_supply)
	var front_supply := preload("res://scripts/building/orison_v2_front_lighting_supply.gd").new()
	if not front_supply.mount(self,electrical_service):
		startup_failed = true
		push_error("V2 front supply refused: %s" % [front_supply.errors])
		return
	adapter.root.set_meta("v2_native_front_lighting_supply",front_supply)
	var front_trim := preload("res://scripts/building/orison_v2_front_trim_fittings.gd").new()
	if not front_trim.mount(self):
		startup_failed = true
		push_error("V2 front trim fittings refused: %s" % [front_trim.errors])
		return
	adapter.root.set_meta("v2_native_front_trim_fittings",front_trim)
	var service_instruments := preload("res://scripts/building/orison_v2_native_service_instruments.gd").new()
	if not service_instruments.mount(self):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: service instrument fabrication refused: %s" % [service_instruments.errors])
		return
	adapter.root.set_meta("v2_native_service_instruments",service_instruments)
	var bar_instruments := preload("res://scripts/building/orison_v2_native_service_instruments.gd").new()
	if not bar_instruments.mount(self,bar_instruments.BAR_PATH):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: bar instrument fabrication refused: %s" % [bar_instruments.errors])
		return
	adapter.root.set_meta("v2_native_bar_instruments",bar_instruments)
	for identity in ["F01_WATCHMAN_DETECTOR_BODY","F01_NIGHT_REGISTER_BODY",
			"F01_SIGNAL_REGISTER_BODY","F01_TOUR_KEY_GUARD_BODY"]:
		_retire_blockout_fixture(identity)
	mirror_renderer = PlanarMirrorRenderer.new()
	add_child(mirror_renderer)
	mirror_renderer.setup(player.camera,player_avatar)
	chirp_hunt = ChirpHunt.new()
	chirp_hunt.name = "ChirpHunt"
	add_child(chirp_hunt)
	chirp_hunt.setup(vantry_points, work_orders, maintenance_inventory)
	var shell := get_tree().get_first_node_in_group("campaign_shell")
	var resolver := Callable(adapter, "resolve_return_anchor")
	if shell != null and shell.is_ancestor_of(self):
		core_loop = shell.call("bind_waking_services", work_orders, player, layout,
				null, null, resolver) as CoreLoopDirector
	else:
		core_loop = CoreLoopDirector.new()
		core_loop.name = "CoreLoopDirector"
		add_child(core_loop)
		core_loop.setup(work_orders, player, layout, resolver)
	mina_gameplay.bind_wake(core_loop)
	first_shift_director.bind_opening_report_offer(
			Callable(core_loop, "offer_opening_report"))
	service_round = ServiceRoundDirector.new()
	service_round.name = "ServiceRoundDirector"
	add_child(service_round)
	service_round.setup(work_orders, _blockout, player, service_set_carrier)
	# Every other tenant speaks at their own door (DoorProp knock control) through
	# the authored trees in res://data/dialogue/. The director owns no case; it
	# asks this root which flat the player stands in and whose timetable says
	# they are home.
	conversations = ResidentConversations.new()
	conversations.name = "ResidentConversations"
	add_child(conversations)
	var conversation_panel := CaseDialoguePanel.new()
	conversation_panel.name = "ResidentConversationPanel"
	conversations.add_child(conversation_panel)
	conversations.setup(conversation_panel, Callable(self, "player_unit"),
			Callable(self, "resident_is_home"))
	if not conversations.errors.is_empty():
		push_warning("ORISON V2 RUNTIME: dialogue trees: %s" % [conversations.errors])
	# The two daily papers: the catalogue answers the rack and the shelf; the
	# desk in 4B keeps what the player bought at News & Cigars.
	newspapers = NewspaperCatalog.new()
	newspapers.name = "NewspaperCatalog"
	add_child(newspapers)
	if not newspapers.errors.is_empty():
		push_warning("ORISON V2 RUNTIME: newspapers: %s" % [newspapers.errors.slice(0, 8)])
	var shelf := adapter.resolve(PLAYER_SHELF_ANCHOR) as Node3D
	if shelf != null:
		var shelf_papers := NewsRackProp.new()
		shelf_papers.name = "ShelfPapers"
		shelf_papers.setup("shelf", Vector3(0.75, 0.5, 0.55))
		add_child(shelf_papers)
		shelf_papers.global_position = shelf.global_position + Vector3.UP * SHELF_PAPERS_HEIGHT
	else:
		push_warning("ORISON V2 RUNTIME: no %s; kept papers have no shelf" % PLAYER_SHELF_ANCHOR)
	open_shift_ecosystem = preload("res://scripts/game/open_shift_radiator_ecosystem.gd").new()
	open_shift_ecosystem.name = "OpenShiftRadiatorEcosystem"
	add_child(open_shift_ecosystem)
	var open_shift_radiator := _blockout.get_node_or_null(
			ServiceRoundDirector.RADIATOR_ID) as RadiatorProp
	if open_shift_radiator:
		open_shift_radiator.bind_inventory(maintenance_inventory)
	var tentacle_observer := preload("res://scripts/dream/entity/maintenance_tentacle_observer.gd").new()
	tentacle_observer.name = "MaintenanceTentacleObserver"
	add_child(tentacle_observer)
	tentacle_observer.setup(self,player,work_orders)
	_compose_observation_ledger()
	preload("res://scripts/building/orison_v2_furnishing_clearance.gd").apply(self)
	if not wayfinding.fit_to_finishes(_blockout):
		startup_failed=true;push_error("V2 wayfinding cannot clear installed wall finishes");return
	public_landings=preload("res://scripts/building/orison_v2_landing_programmes.gd").new()
	if not public_landings.setup(self):
		startup_failed=true;push_error("V2 landing programmes refused: %s" % [public_landings.errors]);return
	if not preload("res://scripts/building/orison_v2_window_treatments.gd").mount(self):
		startup_failed=true;push_error("V2 window treatments refused");return
	mina_routine = preload("res://scripts/characters/orison_v2_mina_routine.gd").new()
	mina_routine.name = "MinaRoutine"
	add_child(mina_routine)
	if not mina_routine.setup(self):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: Mina route composition refused")
		return
	# Other residents with a walking body (design/ORISON_RESIDENT_BODIES_2026-10-25.md).
	# A refused route leaves that resident simulated, not the building broken.
	for resident: String in ResidentRoute.ROUTES:
		var route := ResidentRoute.new()
		route.name = resident.to_pascal_case() + "Routine"
		route.resident = resident
		route.source_path = ResidentRoute.ROUTES[resident]
		add_child(route)
		if route.setup(self):
			resident_routes[resident] = route
		else:
			push_warning("ORISON V2 RUNTIME: %s's route refused; simulated only" % resident)
			route.queue_free()
	if not preload("res://scripts/building/orison_v2_case_one_placement.gd").new().mount_captions(adapter,mina_routine.actor):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: case caption subjects missing")
		return
	var remote_captions := preload("res://scripts/cases/orison_v2_remote_caption_display.gd").new()
	remote_captions.name = "MinaRemoteCaptions"
	remote_captions.adapter = adapter
	add_child(remote_captions)
	shop_simulation = ShopSimulation.new()
	shop_simulation.name = "ShopSimulation"
	add_child(shop_simulation)
	if not shop_simulation.setup(campaign_clock, resident_presence,
			exterior_cell.shop_bucket_registry, Callable(exterior_cell, "refresh_shop_presentation")):
		startup_failed = true
		return
	open_shift_ecosystem.setup(work_orders, open_shift_radiator,
			service_round, Callable(campaign_clock, "absolute_minutes"),
			observation_ledger, null, Callable(), "campaign_absolute_minutes")
	safety_net = SafetyNet.new()
	safety_net.name = "SafetyNet"
	safety_net.setup(player)
	safety_net.anchor = _connection.arrival.position
	add_child(safety_net)
	var kitchen_prep:=preload("res://scripts/building/orison_v2_kitchen_prep.gd").new()
	if not kitchen_prep.mount(self):
		startup_failed=true;push_error("V2 kitchen preparation refused: %s" % [kitchen_prep.errors]);return
	# The house cookbook lies shut on 4B's work table beside the bowl.
	var prep_4b := adapter.root.get_node_or_null(COOKBOOK_TABLE) as Node3D
	if prep_4b != null and resident_agenda != null and resident_agenda.larder != null:
		var cookbook := CookbookProp.new()
		cookbook.name = "Cookbook"
		cookbook.setup(resident_agenda.larder)
		prep_4b.add_child(cookbook)
		cookbook.position = COOKBOOK_AT
		cookbook.rotation.y = 0.12
	else:
		push_warning("ORISON V2 RUNTIME: no cookbook; %s or the larders are missing" % COOKBOOK_TABLE)
	if resident_agenda != null and resident_agenda.larder != null:
		_mount_pantries(kitchen_prep.source)
		resident_agenda.larder.changed.connect(_restock_icebox)
		for unit: String in resident_agenda.larder.state.units:
			_restock_icebox(unit)
	var kitchen_plumbing:=preload("res://scripts/building/orison_v2_kitchen_plumbing.gd").new()
	if not kitchen_plumbing.mount(self):
		startup_failed=true;push_error("V2 kitchen plumbing refused: %s" % [kitchen_plumbing.errors]);return
	var economy := preload("res://scripts/game/caretaker_economy.gd").new()
	economy.name = "CaretakerEconomy"
	add_child(economy)
	var care := preload("res://scripts/building/orison_v2_caretaking.gd").new()
	care.name = "Caretaking"
	add_child(care)
	if not economy.setup(work_orders) or not care.setup(_blockout,economy):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: caretaker ledger refused")
		return
	var installed_fire: RefCounted=adapter.root.get_meta("v2_native_fire_service")
	fire_maintenance_counter=preload("res://scripts/building/orison_v2_fire_maintenance_counter.gd").mount(self,economy,installed_fire.stations)
	if fire_maintenance_counter==null:
		startup_failed=true;push_error("ORISON V2 RUNTIME: fire maintenance counter refused");return
	var saved_mechanisms: Dictionary=passage_region.doors.duplicate()
	saved_mechanisms[str(fire_maintenance_counter.name)]=fire_maintenance_counter
	household_state = HouseholdState.new()
	household_state.name = "HouseholdState"
	add_child(household_state)
	if not household_state.bind(adapter, get_node("V2RoomSwitches") as SwitchSystem, saved_mechanisms):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: household save refused: %s" % [household_state.errors])
		return
	var notebook := preload("res://scripts/ui/caretaker_notebook.gd").new()
	notebook.name = "CaretakerNotebook"
	notebook.player = player
	notebook.care = care
	notebook.economy = economy
	add_child(notebook)
	preload("res://scripts/building/orison_v2_owner_finishes.gd").new().apply_service_actors(self)
	service_light_visibility=preload("res://scripts/building/orison_v2_service_light_visibility.gd").new()
	service_light_visibility.name="ServiceLightVisibility"
	add_child(service_light_visibility)
	if not service_light_visibility.setup(self):
		startup_failed=true;push_error("V2 service practical visibility could not bind original sources");return
	service_light_visibility.set_enabled(true)
	# A player-only percept shares the creature movement/pose owner and the
	# already running lamp receiver field; it is not a second ecology or job.
	var companion_body := DreamCritterController.new()
	companion_body.name = "TardigradeCompanion"
	add_child(companion_body)
	companion_body.setup(null, 240304)
	companion_body.bind_companion(self, player)
	var guide_bells := preload("res://scripts/dream/critters/guide_bell_director.gd").new()
	guide_bells.name = "MaintenanceGuideBells"
	add_child(guide_bells)
	guide_bells.setup(self,player,work_orders)

func arrival_placement() -> Dictionary:
	return (_connection.get("arrival", {}) as Dictionary).duplicate(true)


## Share the existing controls and the accepted prop/ecology catalogue. The
## debug shell owns no replacement gameplay or specimen implementations.
func _compose_debug_controls() -> void:
	touch = TouchControls.new()
	touch.name = "TouchControls"
	add_child(touch)
	touch.look_delta.connect(player.apply_look)
	touch.enable_care_actions()
	if service_set_carrier.has_method("request_correspondence"):
		touch.enable_companion_actions()
		touch.companion_action_requested.connect(Callable(service_set_carrier, "request_correspondence"))
	touch.care_action_requested.connect(func(action: StringName):
		if get_node("CaretakerNotebook").request_action(action): touch._release_all())
	player.touch_input = touch.enabled
	shots = ShotCapture.new()
	shots.name = "ShotCapture"
	add_child(shots)
	if GameBoot.launch_mode != GameBoot.LaunchMode.DEBUG \
			or not OS.get_environment("SHOT_ROOMS").is_empty():
		return
	warehouse = PropWarehouse.new()
	add_child(warehouse)
	warehouse.build(preload("res://scripts/building/building_root.gd").PROP_SCRIPTS)
	safety_net.exempt_zones.append(warehouse.hall_aabb())
	var panel := BuildingDebug.new()
	building_debug = panel
	panel.setup(self)
	var layer := CanvasLayer.new()
	layer.name = "BuildingDebugLayer"
	layer.layer = 95
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(layer)
	layer.add_child(panel)
	shots.chrome = layer
	call_deferred("reset_mina_infestation")

func clear_mina_infestation() -> void:
	_infestation_revision += 1
	if is_instance_valid(mina_infestation):
		mina_infestation.free()
	mina_infestation = null

func reset_mina_infestation() -> void:
	if GameBoot.launch_mode != GameBoot.LaunchMode.DEBUG: return
	clear_mina_infestation()
	var revision := _infestation_revision
	# Wait for V2 collision bodies to be registered before choosing contacts.
	await get_tree().physics_frame
	if not is_inside_tree() or revision != _infestation_revision: return
	mina_infestation = preload("res://scripts/debug/mina_apartment_infestation.gd").new()
	mina_infestation.name = "MinaDebugInfestation"
	add_child(mina_infestation)
	if not mina_infestation.setup(self):
		push_error("Mina debug infestation: %s" % [mina_infestation.errors])


## V2 destinations are in its composed world frame. V1 plan coordinates are
## never valid shortcuts here, especially after visiting an off-site exhibit.
func debug_destinations() -> Dictionary:
	var destinations := {"Arrival": _connection.arrival.position}
	var desk := adapter.resolve("F04_B_MONITOR_STANCE") as Node3D
	if desk != null:
		destinations["4B desk"] = desk.global_position + Vector3.UP * 0.05
	# The same owner that places a waking player resolves the bedside. Debug
	# navigation must not introduce a second contract for its semantic anchor.
	if core_loop != null:
		var bedside := core_loop.resolve_return_anchor()
		if not bedside.is_empty():
			destinations["4B bedside"] = bedside.position + Vector3.UP * 0.05
	return destinations

func _compose_exterior() -> bool:
	public_regions=preload("res://scripts/building/orison_v2_public_region_programmes.gd").new()
	if not public_regions.configure(_exterior_resolver):return false
	shop_service = preload("res://scripts/game/v2_maintenance_shop_service.gd").new()
	shop_service.name = "MaintenanceShopService"
	add_child(shop_service)
	shop_service.setup(maintenance_inventory, work_orders)
	if not shop_service.is_valid():
		return false
	exterior_cell = ExteriorCell.new()
	exterior_cell.name = "StreetAndBodega"
	if not exterior_cell.configure_dependencies({"player": player,
			"work_orders": work_orders, "maintenance_inventory": maintenance_inventory,
			"shop_service": shop_service, "spatial_resolver": _exterior_resolver,
			"geometry_source": _connection.geometry,
			"geometry_instance_ids":public_regions.bounded_instance_ids()}):
		exterior_cell.free()
		exterior_cell = null
		return false
	add_child(exterior_cell)
	if exterior_cell.startup_failed:
		return false
	if preload("res://scripts/building/orison_v2_bodega_frontage.gd").mount(exterior_cell,_blockout.architectural_materials)==null:
		return false
	var front_pavement:=preload("res://scripts/building/orison_v2_front_pavement.gd").new()
	front_pavement.name="FrontPavement"
	_blockout.add_child(front_pavement)
	var ground:=preload("res://scripts/building/orison_v2_ground.gd").new()
	ground.name="Ground"
	_blockout.add_child(ground)
	var city_foundations:=preload("res://scripts/building/orison_v2_city_foundations.gd").new()
	city_foundations.name="CityFoundations"
	_blockout.add_child(city_foundations)
	var receiving := preload("res://scripts/building/orison_v2_bodega_receiving.gd").new()
	receiving.name = "BodegaReceiving"
	if not receiving.configure(exterior_cell):
		receiving.free()
		return false
	add_child(receiving)
	if receiving.startup_failed: return false
	var bodega_power:=preload("res://scripts/building/orison_v2_bodega_power.gd").new()
	bodega_power.name="BodegaPower"
	if not bodega_power.configure(exterior_cell):
		bodega_power.free()
		return false
	add_child(bodega_power)
	if bodega_power.startup_failed:return false
	if preload("res://scripts/building/orison_v2_bodega_fittings.gd").mount(exterior_cell,_blockout.architectural_materials)==null:
		return false
	var street_boundaries := StreetBoundaries.new()
	street_boundaries.name = "StreetBoundaries"
	if not street_boundaries.configure(public_regions):street_boundaries.free();return false
	add_child(street_boundaries)
	if street_boundaries.startup_failed:return false
	passage_region = PassageRegion.new()
	passage_region.name = "VantryArcade"
	if not passage_region.configure(shop_service,public_regions):
		passage_region.free()
		passage_region = null
		return false
	add_child(passage_region)
	if passage_region.startup_failed:
		return false
	if not passage_region.enable_residency(player, _blockout, layout):
		return false
	bar_region = BarRegion.new()
	bar_region.name = "Harukiya"
	add_child(bar_region)
	if bar_region.startup_failed:
		return false
	if not passage_region.receiving_row.bind_registered_graph():
		return false
	var city_shells := preload("res://scripts/building/orison_v2_city_shells.gd").new()
	city_shells.name = "CityShells"
	add_child(city_shells)
	var horizon := preload("res://scripts/building/orison_v2_city_horizon.gd").new()
	horizon.name = "CityHorizon"
	horizon.transform = city_shells.global_transform.affine_inverse() * _blockout.global_transform
	city_shells.add_child(horizon)
	var bridge_started:=Time.get_ticks_usec()
	var bridge:=preload("res://scripts/building/orison_v2_city_bridge.gd").mount(city_shells)
	if bridge==null:return false
	bridge.set_meta("v2_mount_cpu_ms",(Time.get_ticks_usec()-bridge_started)/1000.)
	if not preload("res://scripts/building/orison_v2_front_facade.gd").mount(self):return false
	if preload("res://scripts/building/orison_v2_entry_vestibule.gd").mount(self) == null:return false
	if preload("res://scripts/building/orison_v2_street_paving_details.gd").mount(self) == null:return false
	period_traffic = preload("res://scripts/building/orison_v2_street_traffic.gd").mount(self)
	if period_traffic == null:return false
	if preload("res://scripts/building/orison_v2_street_lamps.gd").mount(self) == null:return false
	var signage := preload("res://scripts/building/orison_v2_native_signage.gd").new()
	if not signage.install(self):
		push_error("V2 SIGNAGE: %s" % [signage.errors])
		return false
	adapter.root.set_meta("v2_native_signage",signage)
	if not public_regions.bind(self):return false
	return bool(exterior_cell.set_route_guides_visible(false).get("ok", false))

func _compose_call_station(terminal: SignalTerminalProp) -> bool:
	var operator := adapter.resolve("F04_B_MONITOR_STANCE") as Node3D
	var use := adapter.resolve("F04_B_TERMINAL_USE") as MeshInstance3D
	if operator == null or use == null or terminal == null:
		return false
	var bounds: AABB = use.global_transform * use.get_aabb()
	var toward_operator: Vector3 = operator.global_position - terminal.global_position
	toward_operator.y = 0.0
	if toward_operator.length_squared() < 0.000001 or bounds.size.x <= 0.0 or bounds.size.z <= 0.0:
		return false
	# The instrument face is local +X. Preserve the authored anchor transform;
	# only the mounted production consumer turns toward its operator.
	terminal.global_rotation.y = atan2(-toward_operator.z, toward_operator.x)
	# The ordinary player ray does not hit an Area from inside it. Keep this
	# target inside the existing terminal-use footprint, ahead of the stance.
	var desk := DeskZone.new()
	desk.name = "F04_B_DESK_ZONE"
	desk.call_interface = call_interface
	desk.interaction_footprint = Vector2(bounds.size.x, bounds.size.z)
	_blockout.add_child(desk)
	var center: Vector3 = bounds.position + bounds.size * 0.5
	desk.global_position = Vector3(center.x, operator.global_position.y, center.z)
	return true


## WHO IS ACTUALLY HOME TO SEE IT.
##
## The observation ledger gates in-flat sight on presence, and an unbound
## provider means "assume home" (npc_observation_ledger.gd:107-110): every
## resident is treated as standing in their own flat at the instant of
## every visible event. Lena could therefore earn a durable
## `in_home_sight` belief â€” committed with provenance, deduped forever â€”
## while her own timetable had her out on a corridor round. The ledger's
## contract is that nothing else may author NPC knowledge; assume-home
## quietly authored it.
##
## The timetable is the authority that already owns this fact, and it
## owns it as DATA: `ScheduleDirector.resolve()` is pure over
## res://data/resident_schedules.json and needs no resident body, no floor
## node and no layout geometry. The legacy routine dispatcher stays inert
## because its target is null. Mina's V2 route owner consumes this same
## timetable resolution through the V2 spatial graph.
func _compose_observation_ledger() -> void:
	resident_presence = ScheduleDirector.new()
	resident_presence.name = "ResidentPresenceTimetable"
	add_child(resident_presence)
	resident_presence.setup(null, layout)
	resident_agenda = ResidentAgenda.new()
	resident_agenda.name = "ResidentAgenda"
	add_child(resident_agenda)
	if not resident_agenda.setup(resident_presence, Callable(self, "weather_conditions"),
			Callable(self, "player_agenda_place"), RealityState.has_knowledge,
			RealityState.resident_trust):
		push_warning("ORISON V2 RUNTIME: resident agenda unavailable; residents keep the bare timetable")
	else:
		# Every household's pantry and icebox, kept on the campaign save.
		var kitchens := KitchenLarder.new()
		if kitchens.load_data(resident_agenda.homes()) and kitchens.bind(RealityState.data, RealityState.commit):
			resident_agenda.larder = kitchens
		else:
			push_warning("ORISON V2 RUNTIME: household larders unavailable: %s" % [kitchens.errors])
	observation_ledger = NpcObservationLedger.new()
	observation_ledger.name = "ObservationLedger"
	add_child(observation_ledger)
	# Absolute campaign minutes stamp events. Only schedule lookup wraps to
	# the clock's minute of day; the situation never advances its own clock.
	var clock := Callable(campaign_clock, "absolute_minutes")
	observation_ledger.setup([
		{"npc": ServiceRoundDirector.RESIDENT_ID, "unit": "2B"},
		{"npc": "omar_bell", "unit": "3B"},
	], clock, get_tree().root.get_node_or_null("AcousticGraphData"),
			Callable(self, "resident_is_home"), "campaign_absolute_minutes")


## True only while the resident's own authored timetable puts them inside
## their flat. Reads the `place` token rather than ScheduleDirector's
## mapped directive deliberately: the mapped form resolves world POINTS
## through v1 layout coordinates, which do not exist in this building,
## while the place token is the authored fact itself and needs no
## geometry. Degrades to the ledger's own assume-home if the timetable
## data is unavailable, rather than inventing an absence.
func resident_is_home(npc: String) -> bool:
	if resident_presence == null or resident_presence.data.is_empty():
		return true
	if campaign_clock == null:
		return true
	var info := campaign_clock.day_info()
	if not bool(info.get("valid", false)):
		return true
	var block := resident_whereabouts(npc)
	if block.is_empty():
		block = resident_presence.resolve(npc, str(info.day),
			campaign_clock.minute_of_day(), int(info.doy),
			bool(info.first_sat))
	var place := str(block.get("place", "unit"))
	return place.is_empty() or place.begins_with("unit")


func _compose_service_round_props() -> void:
	var detector := WatchmanClockProp.new()
	detector.prop_type = "watchman_detector"
	_mount("F01_WATCHMAN_DETECTOR", detector)
	var register := NightRegisterProp.new()
	register.prop_type = "night_register"
	_mount("F01_NIGHT_REGISTER", register)
	var signal_register := WatchRegisterProp.new()
	signal_register.prop_type = "signal_register"
	_mount("F01_SIGNAL_REGISTER", signal_register)
	var tour_guard := TourKeyGuardProp.new()
	tour_guard.prop_type = "tour_key_guard"
	_mount("F01_TOUR_KEY_GUARD", tour_guard)
	_retire_blockout_fixture("F02_B_RADIATOR_MASS")
	_retire_blockout_fixture("F02_B_RADIATOR_USE")
	var heating := preload("res://scripts/building/orison_v2_heating.gd").new()
	if not heating.mount(adapter,maintenance_inventory):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: heating refused: %s" % [heating.errors])
		return
	heat_balance = heating.balance
	var boiler := BoilerProp.new()
	boiler.graph_node_id = "B1_BOILER_01"
	boiler.external_pipework = true
	boiler.prop_type = "boiler"
	_mount("B1_BOILER_01", boiler)
	# The semantic anchor names the inspection height. BoilerProp's origin
	# is its feet; ground the physical plant on the authored basement floor.
	boiler.position.y = float(_blockout.level_y["B1"])
	var boiler_stance := adapter.resolve("B1_BOILER_CONTROL_STANCE") as Node3D
	if boiler_stance == null:
		startup_failed = true
		push_error("ORISON V2 RUNTIME: missing boiler control stance")
		return
	var boiler_facing := boiler_stance.global_position
	boiler_facing.y = boiler.global_position.y
	boiler.look_at(boiler_facing)
	_retire_blockout_fixture("B1_BOILER_BODY_MASS")
	_retire_blockout_fixture("B1_WATER_COLUMN_MASS")
	var flue := preload("res://scripts/building/orison_v2_boiler_flue.gd").new()
	flue.name = "BoilerFlue"
	adapter.root.add_child(flue)
	if not flue.mount(boiler,_blockout.layout):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: boiler flue connection refused")
		return
	_retire_blockout_fixture("B1_BREECHING_MASS")
	var stove:=preload("res://scripts/building/orison_v2_c_stove_stack.gd").new()
	if not stove.mount(adapter,_blockout.layout):
		startup_failed=true
		push_error("ORISON V2 RUNTIME: stove stack refused: "+str(stove.errors))
		return
	preload("res://scripts/building/orison_v2_boiler_pipework.gd").mount(adapter.root)
	watch_station_network = WatchStationNetwork.new()
	watch_station_network.name = "WatchStationNetwork"
	add_child(watch_station_network)
	watch_station_network.attach_receiver(signal_register)
	watch_station_network.attach_key_guard(tour_guard)
	# A patrol station on every floor (dossier slice 80): the existing signal box,
	# worked with the existing tour key, wired to the watch room's register.
	for anchor: String in PATROL_STATIONS:
		var station := preload("res://scripts/building/orison_v2_watch_station.gd").new()
		station.prop_type = "watch_station"
		station.station_id = PATROL_STATIONS[anchor]
		_mount(anchor, station)
		if not watch_station_network.register(station):
			startup_failed = true
			push_error("ORISON V2 RUNTIME: patrol station refused: " + anchor)

func _bind_first_shift_station() -> void:
	var detector := find_child("F01_WATCHMAN_DETECTOR", true, false) as WatchmanClockProp
	var register := find_child("F01_NIGHT_REGISTER", true, false) as NightRegisterProp
	var signal_register := find_child("F01_SIGNAL_REGISTER", true, false) as WatchRegisterProp
	var tour_guard := find_child("F01_TOUR_KEY_GUARD", true, false) as TourKeyGuardProp
	if detector:
		detector.bind_first_shift(first_shift_director)
	if register:
		register.report_taken.connect(first_shift_director.accept_report)
		register.register_signed.connect(first_shift_director.accept_signed_register)
	if signal_register:
		signal_register.signal_displayed.connect(
				first_shift_director.observe_central_signal)
	if tour_guard:
		tour_guard.tour_key_taken.connect(first_shift_director.observe_tour_key_taken)
		tour_guard.tour_key_returned.connect(first_shift_director.observe_tour_key_returned)

func _compose_hot_water() -> bool:
	var plant := adapter.resolve("B1_BOILER_01") as BoilerProp
	if plant == null:
		startup_failed = true
		push_error("ORISON V2 RUNTIME: hot water has no mounted boiler")
		return false
	var taps: Array[TapProp] = []
	for node in _blockout.find_children("*", "Node3D", true, false):
		if node is TapProp:
			taps.append(node as TapProp)
	boiler_tend = BoilerTend.new()
	boiler_tend.name = "BoilerTend"
	add_child(boiler_tend)
	# One plant supplies both hot water and all 23 authored heating demands.
	# All eighteen occupied homes expose controls; sealed rooms retain demand.
	boiler_tend.configure(plant, heat_balance, taps)
	return true

func _compose_vantry() -> void:
	var anchor := adapter.resolve("F02_A_MAIN_VANTRY_POINT") as Node3D
	vantry_points = VantryPointNetwork.new()
	vantry_points.name = "VantryPointNetwork"
	vantry_points.floor_nodes = {"F02": _blockout}
	vantry_points.points = {"F02_A_MAIN_VANTRY_POINT": {
		"pos": [anchor.global_position.x, -anchor.global_position.z,
				anchor.global_position.y], "floor": "F02", "room": "2A"}}
	vantry_points.point_order = ["F02_A_MAIN_VANTRY_POINT"]
	vantry_points.work_orders = work_orders
	add_child(vantry_points)
	var point := VantryPointProp.new()
	point.prop_type = "vantry_point"
	point.bind_order_spine(work_orders)
	vantry_points.active_owner = point
	vantry_points.add_child(point)

func _mount(identity: String, consumer: Node3D) -> void:
	if not adapter.mount_consumer(identity, consumer):
		startup_failed = true
		push_error("ORISON V2 RUNTIME: failed to mount " + identity)


func _retire_blockout_fixture(identity: String) -> void:
	# Gray-box fixture masses reserve space until the real production consumer
	# is composed. Once mounted they must neither obscure nor collide with that
	# authority; semantic anchors and clearance envelopes remain untouched.
	var fixture := _blockout.find_child(identity, true, false) as Node3D
	if fixture == null:
		push_error("ORISON V2 RUNTIME: missing blockout fixture " + identity)
		startup_failed = true
		return
	fixture.visible = false
	for node: Node in fixture.find_children("*", "CollisionShape3D", true, false):
		(node as CollisionShape3D).disabled = true

func authority_count(type_name: String) -> int:
	return find_children("*", type_name, true, false).size()

func shutdown_for_tests() -> void:
	# Stop borrowers before adapter restoration frees their radiator/fixture
	# nodes. queue_free() alone still permits callbacks later in this frame.
	process_mode = Node.PROCESS_MODE_DISABLED
	if is_instance_valid(bathroom_moisture):bathroom_moisture.shutdown()
	if public_landings!=null:public_landings.teardown()
	if is_instance_valid(household_state): household_state.shutdown()
	if is_instance_valid(mirror_renderer): mirror_renderer.shutdown()
	if is_instance_valid(shop_simulation):
		shop_simulation.shutdown()
	if is_instance_valid(exterior_cell):
		if is_instance_valid(bar_region):
			bar_region.shutdown()
		if is_instance_valid(passage_region):
			passage_region.shutdown()
		exterior_cell.shutdown_for_tests()
	if adapter != null:
		# Consumers are already detached before synchronous free, so tests and
		# selector reconstruction do not leave deferred audio decoders behind.
		adapter.restore_all(true)
	# Positional owners restore inside the selected topology; release its base last.
	if acoustic_topology!=null: acoustic_topology.release()

func _exit_tree() -> void:
	if is_instance_valid(prologue_director):prologue_director.shutdown()
	if is_instance_valid(bathroom_moisture):bathroom_moisture.shutdown()
	if public_landings!=null:public_landings.teardown();public_landings=null
	if public_regions!=null:public_regions.teardown();public_regions=null
	if is_instance_valid(household_state): household_state.shutdown()
	if is_instance_valid(mirror_renderer): mirror_renderer.shutdown()
	if _exterior_resolver != null:
		_exterior_resolver.teardown()
		_exterior_resolver = null
	if adapter != null:
		adapter.restore_all()
	if acoustic_topology!=null: acoustic_topology.release();acoustic_topology=null

	_contact_precision.release()

## Where a resident is now and why: the agenda when it runs, else the bare
## timetable. Empty when the clock or timetable is unavailable.
func resident_whereabouts(npc: String) -> Dictionary:
	if resident_presence == null or campaign_clock == null:
		return {}
	var info := campaign_clock.day_info()
	if not bool(info.get("valid", false)):
		return {}
	var minute := campaign_clock.minute_of_day()
	if resident_agenda != null and resident_agenda.enabled:
		return resident_agenda.decide(npc, str(info.day), minute, int(info.doy), bool(info.first_sat))
	return resident_presence.resolve(npc, str(info.day), minute, int(info.doy), bool(info.first_sat))


## Every household with a kitchen work table keeps its dry goods along the
## table's back edge, behind the breadboard and clear of the bowl.
func _mount_pantries(prep: Dictionary) -> void:
	var templates := {}
	for template: Dictionary in prep.get("templates", []):
		templates[str(template.id)] = template
	for row: Dictionary in prep.get("stations", []):
		var unit := str(row.unit)
		var station := adapter.root.get_node_or_null(str(row.id)) as Node3D
		if station == null or not templates.has(str(row.template)) \
				or not resident_agenda.larder.state.units.has(unit):
			continue
		var size: Dictionary = templates[str(row.template)]
		var width := float(size.width)
		var pantry := PantryDisplay.new()
		pantry.name = "Pantry"
		pantry.setup(resident_agenda.larder.groceries.pantry_looks,
				Vector2(-width * 0.5 + 0.06, width * 0.5 - 0.06),
				Vector2(width * 0.30 - 0.14, width * 0.30 + 0.14) if bool(row.bowl) else Vector2(INF, INF))
		station.add_child(pantry)
		pantry.position = Vector3(0.0, 0.9, float(size.depth) * 0.5 - 0.07)
		_pantries[unit] = pantry


## A household's icebox and pantry show what its larder holds.
func _restock_icebox(unit: String) -> void:
	if resident_agenda == null or resident_agenda.larder == null:
		return
	if _pantries.has(unit) and is_instance_valid(_pantries[unit]):
		(_pantries[unit] as PantryDisplay).show_rows(resident_agenda.larder.pantry_rows(unit))
	if _iceboxes.is_empty():
		for node: Node in adapter.root.find_children("*", "Node3D", true, false):
			if node is FridgeProp and node.has_method("show_larder"):
				_iceboxes.append(node)
	for node: Node in _iceboxes:
		if is_instance_valid(node) and str((node as FridgeProp).unit) == unit:
			node.show_larder(resident_agenda.larder.icebox_rows(unit))


## The waking weather as the residents feel it: the atmosphere's live
## conditions, or nothing (the agenda then uses the seasonal norm).
func weather_conditions() -> Dictionary:
	var air := get_node_or_null("WakingAtmosphere")
	if air == null or air.get("weather_manager") == null:
		return {}
	return air.weather_manager.current


## The player's whereabouts in the agenda's place grammar, for residents who
## seek or avoid the night man. "" inside flats, shops and the street.
func player_agenda_place() -> String:
	if player == null or not is_instance_valid(player):
		return ""
	var room := room_at_world(player.global_position)
	if room in ["F01_LOBBY", "F01_VESTIBULE", "F01_PUBLIC_CORE", "F01_WATCH"]:
		return "lobby"
	if room in ["F01_MAIL_TELEPHONE", "F01_PACKAGE"]:
		return "mail_bank"
	if room == "B1_LAUNDRY":
		return "laundry"
	if room.begins_with("ROOF_DECK"):
		return "roof"
	if unit_of_room(room) == "" and room.begins_with("F0") \
			and (room.contains("HALL") or room.contains("LANDING") or room.contains("PUBLIC_CORE") or room.contains("GALLERY")):
		return "corridor:" + room.left(3)
	return ""


## The apartment the player is standing in, by the same room-id grammar the
## keyring uses (F0X_A_* belongs to unit XA); "" in corridors and shops.
func player_unit() -> String:
	if player == null or not is_instance_valid(player):
		return ""
	return unit_of_room(room_at_world(player.global_position))


static func unit_of_room(room_id: String) -> String:
	var parts := room_id.split("_")
	if parts.size() >= 3 and parts[0].begins_with("F0") and parts[1] in ["A", "B", "C", "D"]:
		return parts[0].trim_prefix("F0") + parts[1]
	return ""


func room_at_world(world_position: Vector3) -> String:
	if _blockout==null or layout.is_empty():return ""
	if public_landings!=null:return public_landings.room_at(world_position)
	return preload("res://scripts/building/orison_v2_space_footprints.gd").room_at(layout,_blockout.to_local(world_position))
