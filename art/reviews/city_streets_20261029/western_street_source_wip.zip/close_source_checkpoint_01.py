from pathlib import Path
import ast, hashlib, json, subprocess, zipfile

ROOT=Path('C:/ov/city')
OUT=Path(__file__).parent
BASE='80cd1694d02493655e84c35bc3672c74f8c8eee6'
def git(*args):
    return subprocess.run(['git',*args],cwd=ROOT,capture_output=True,check=True).stdout
def digest(raw): return hashlib.sha256(raw).hexdigest()
def write(path,data): path.write_text(json.dumps(data,indent=2,ensure_ascii=True)+'\n',encoding='utf-8',newline='\n')

assert git('rev-parse','HEAD').decode().strip()==BASE
sources=sorted(p.relative_to(OUT/'before').as_posix() for p in (OUT/'before').rglob('*') if p.is_file())
assert len(sources)==6
assert not git('diff','--cached','--name-only').strip()
assert not git('diff','--name-only','--','game','art/blender/*.blend','art/blender/*construction*.json').strip(), 'Runtime/native delivery changed; source-only closure refused'
for rel in sources:
    assert (OUT/'before'/rel).read_bytes().replace(b'\r\n',b'\n')==git('show',BASE+':'+rel).replace(b'\r\n',b'\n')
oldplan=json.loads((OUT/'before/art/data/city_streets/source_plan.json').read_bytes())
newplan=json.loads((ROOT/'art/data/city_streets/source_plan.json').read_bytes())
assert newplan['districts'][:-1]==oldplan['districts']
assert {k:v for k,v in oldplan.items() if k not in ('districts','scope')}=={k:v for k,v in newplan.items() if k not in ('districts','scope')}
helper='art/blender/scripts/city_ground_apron_geometry.py'
before=ast.parse((OUT/'before'/helper).read_bytes())
after=ast.parse((ROOT/helper).read_bytes())
after.body=[n for n in after.body if not isinstance(n,ast.FunctionDef) or n.name!='removed_profile_soil_volume']
assert ast.dump(before,include_attributes=False)==ast.dump(after,include_attributes=False)
baseline=json.loads((OUT/'baseline_assets_01.json').read_bytes())
for rel,control in baseline['assets'].items():
    assert digest((ROOT/rel).read_bytes())==control['raw_sha256'],rel
survey=json.loads((OUT/'grade_survey_01/grade_owners.json').read_bytes())
receipt=json.loads((OUT/'grade_survey_01.log.receipt.json').read_bytes())
assert survey['evidence_class']=='INERT' and survey['failures']==0 and len(survey['records'])==573
assert receipt['execution']['completed'] and receipt['execution']['exit_code']==0 and not receipt['execution']['timed_out']
assert not (OUT/'grade_survey_01.log.stderr').read_bytes()
classification=json.loads((OUT/'native_classification_01_output.json').read_bytes())
prior=git('ls-tree','-r',BASE,'--','art/reviews/city_streets_20261029').decode().splitlines()
prior_zips={line.split('\t')[1]:line.split()[2] for line in prior if line.endswith('.zip')}
assert len(prior_zips)==44
record=dict(evidence_class='INERT',base_commit=BASE,status='SOURCE_ONLY_WIP_HELD_AT_OWNER_REQUEST',
    scope='Source preparation only. No new native meshes, runtime delivery, player route, LOD/material/mipmap/rendering qualification, artistic acceptance or main merge.',
    source_bindings={p:digest((ROOT/p).read_bytes().replace(b'\r\n',b'\n')) for p in sources},
    preserved_runtime_asset_hashes={p:d['raw_sha256'] for p,d in baseline['assets'].items()},
    unchanged_existing_helper_module_ast=True,existing_street_plan_fields_except_scope_and_eastern_district_exact=True,scope_description_change=[oldplan['scope'],newplan['scope']],
    source_tests=dict(tests=26,failures=0,seconds=3.566),grade_survey=dict(boxes=573,failures=0,wrapper_elapsed_s=receipt['execution']['elapsed_s'],evidence_class='INERT'),
    independent_expected_retained_cut_m3=524.4304800474837,independent_original_eastern_cut_m3=185.15556887055703,
    prior_archive_git_blobs=prior_zips,
    resume='Only after owner resumes: reconcile fresh actual grade survey and native classifications against consumed masks with original refusal retained; generate ground, apron and street through Blender, prove native Boolean volume, UV and unchanged parts; inspect native review before combined patched-engine Godot checks. No stale-receipt repinning.')
write(OUT/'source_checkpoint_01.json',record)
archive=ROOT/'art/reviews/city_streets_20261029/western_street_source_wip.zip'
assert not archive.exists()
members={p.relative_to(OUT).as_posix():p.read_bytes() for p in sorted(OUT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
for rel in sources: members['current_source/'+rel]=(ROOT/rel).read_bytes()
index=dict(evidence_class='INERT',scope=record['scope'],base_commit=BASE,members={k:dict(bytes=len(v),raw_sha256=digest(v)) for k,v in members.items()})
members['index.json']=(json.dumps(index,indent=2,ensure_ascii=True)+'\n').encode()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for rel,raw in members.items():z.writestr(rel,raw)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(members)
    for rel,raw in members.items(): assert z.read(rel)==raw
manifest_path=ROOT/'art/reviews/city_streets_20261029/manifest.json'
manifest=json.loads(manifest_path.read_bytes())
assert 'western_street_source_wip' not in manifest
manifest['western_street_source_wip']=dict(evidence_class='INERT',archive=archive.name,bytes=archive.stat().st_size,sha256=digest(archive.read_bytes()),member_count=len(members),index='index.json',status=record['status'],scope=record['scope'])
write(manifest_path,manifest)
print(json.dumps(manifest['western_street_source_wip']))
