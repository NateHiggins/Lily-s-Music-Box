from pathlib import Path
import ast,json,struct,hashlib,numpy as np
root=Path('C:/ov/city');out=Path(__file__).parent
for source in [out.parent/'bodega_frontage_reconciliation_01/check_preservation_01.py',out.parent/'horizon_shards_01/bind_world_frames_01.py']:
    tree=ast.parse(source.read_text(encoding='utf-8-sig'));exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(source),'exec'))

def inspect(relative):
    raw=(root/relative).read_bytes();data=projection(raw);size=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+size]);world=frames(doc)
    for node in doc['nodes']:
        if 'mesh' not in node:continue
        name=node['name'];primitives=doc['meshes'][node['mesh']]['primitives'];data[name]['world_transform']=world[name]
        data[name]['materials']=[doc['materials'][p['material']]['name'] if 'material' in p else None for p in primitives]
        accessors=[doc['accessors'][p['attributes']['POSITION']] for p in primitives]
        low=[min(a['min'][i] for a in accessors) for i in range(3)];high=[max(a['max'][i] for a in accessors) for i in range(3)]
        corners=np.array([[x,y,z,1.] for x in [low[0],high[0]] for y in [low[1],high[1]] for z in [low[2],high[2]]]);placed=corners@np.asarray(world[name]).T
        data[name]['world_bounds']=list(placed[:,:3].min(0))+list(placed[:,:3].max(0))
        data[name]['triangles']=sum(doc['accessors'][p['indices']]['count']//3 for p in primitives)
    return dict(raw_sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),parts=data)

if __name__=='__main__':
    path=out/'baseline_assets_01.json';assert not path.exists()
    assets={f'game/assets/props/{name}.glb':inspect(f'game/assets/props/{name}.glb') for name in ['city_streets','city_streets_lod1','orison_ground','city_ground_apron']}
    path.write_text(json.dumps(dict(evidence_class='INERT',base_commit='80cd1694d02493655e84c35bc3672c74f8c8eee6',assets=assets),indent=2),encoding='utf-8',newline='\n')
    print('Original street/ground baseline:',sum(len(r['parts']) for r in assets.values()),'parts; asset bytes preserved as hashes,not duplicate models',flush=True)
