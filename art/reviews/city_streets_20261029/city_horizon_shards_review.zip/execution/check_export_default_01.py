from pathlib import Path
import ast,subprocess,json,copy,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent
relative='art/blender/scripts/fabrication_native_batch.py'
old=subprocess.check_output(['git','show','HEAD:'+relative],cwd=root).decode('utf-8')
new=(root/relative).read_text(encoding='utf-8')
before=ast.parse(old);after=ast.parse(new);normalized=copy.deepcopy(after)
fn=next(n for n in normalized.body if isinstance(n,ast.FunctionDef) and n.name=='export')
assert fn.args.args[-1].arg=='save_native' and isinstance(fn.args.defaults[-1],ast.Constant) and fn.args.defaults[-1].value is True
fn.args.args.pop();fn.args.defaults.pop()
guards=[(i,n) for i,n in enumerate(fn.body) if isinstance(n,ast.If) and isinstance(n.test,ast.Name) and n.test.id=='save_native']
assert len(guards)==1;i,node=guards[0];assert len(node.body)==1 and not node.orelse
fn.body[i:i+1]=node.body
assert ast.dump(before,include_attributes=False)==ast.dump(normalized,include_attributes=False)
(out/'fabrication_native_batch_ddc_original.py').write_text(old,encoding='utf-8',newline='\n')
record=dict(evidence_class='INERT',scope='Source consumed-projection proof only:remove exactly the new defaultTrue argument andunwrap its one save guard;entire module AST then equals ddc original. No other native/export algorithm changes. Not runtime/artistic proof.',sourcebase=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),original_sha256=hashlib.sha256(old.replace('\r\n','\n').encode()).hexdigest(),changed_sha256=hashlib.sha256(new.replace('\r\n','\n').encode()).hexdigest(),default_true_module_ast_exact=True)
(out/'export_default_projection_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print('DefaultTrue module consumed AST exact;only opt-inFalse skips native save.')
