from pathlib import Path
import json,subprocess
root=Path('C:/ov/city');out=Path(__file__).parent
initial=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).splitlines();assert not initial,initial
fixture=json.loads((root/'game/tests/fixtures/orison_city_horizon.json').read_text())
assets=sorted({a['asset'] for a in fixture['assets'].values()});assert len(assets)==34
new_assets=[p+s for p in assets for s in ['', '.import']]
source=['.gitattributes','TASKS.md','design/V2_CITY_CONTEXT_REPORT_2026-10-19.md','art/blender/scripts/build_city_horizon.py','art/blender/scripts/city_horizon_assets.py','art/blender/scripts/fabrication_native_batch.py','art/blender/scripts/review_city_streets.py','art/blender/v2_fabrication_inventory.json','art/tools/fix_v2_mesh_imports.py','tools/inventory_v2_fabrication.py','tools/tests/test_city_horizon_shards.py','game/data/orison_v2/exterior/city_horizon.json','game/scripts/building/orison_v2_city_horizon.gd','game/tests/v2_city_horizon_bench.gd','game/tests/v2_city_transport_route.gd','art/reviews/city_streets_20261029/manifest.json','art/reviews/city_streets_20261029/city_horizon_shards_review.zip']
source+=['art/blender/city_horizon_'+f+'.blend' for f in ['near','far','lod1']]
source+=list(json.loads((out/'source_closure_02.json').read_text())['original_sha256'])
old=list(json.loads((out/'retirement_03.json').read_text())['removed_assets'])
source=sorted(set(source));assert all(not p.endswith('.uid') for p in source+new_assets+old)
subprocess.run(['git','add','--',*source,*old],cwd=root,check=True,capture_output=True)
subprocess.run(['git','add','-f','--',*new_assets],cwd=root,check=True,capture_output=True)
expected=set(source+new_assets+old);actual=set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).splitlines());assert actual==expected,(expected-actual,actual-expected)
(out/'staged_paths_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Exactnamed-path staging only;noUIDs/canonical/unrelatedpaths.',paths=sorted(actual)),indent=2),encoding='utf-8',newline='\n')
print('Staged',len(actual),'exactnamedpaths;',len(new_assets),'newphysicalasset/importfiles;6oldremovals.')
