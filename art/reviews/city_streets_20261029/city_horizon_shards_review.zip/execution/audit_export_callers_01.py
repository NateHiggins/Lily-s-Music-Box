from pathlib import Path
import ast,subprocess,json,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent;records=[];opted=[]
paths=list((root/'art/blender/scripts').glob('*.py'))+list((root/'tools').rglob('*.py'))
for p in paths:
    text=p.read_text(encoding='utf-8-sig');tree=ast.parse(text);direct=set();modules=set()
    for n in ast.walk(tree):
        if isinstance(n,ast.ImportFrom) and n.module and n.module.endswith('fabrication_native_batch'):
            assert all(a.name!='*' for a in n.names),str(p)
            direct.update(a.asname or a.name for a in n.names if a.name=='export')
        if isinstance(n,ast.Import):modules.update(a.asname or a.name for a in n.names if a.name.endswith('fabrication_native_batch'))
    calls=[]
    for n in ast.walk(tree):
        if not isinstance(n,ast.Call):continue
        target=isinstance(n.func,ast.Name) and n.func.id in direct
        target=target or (isinstance(n.func,ast.Attribute) and n.func.attr=='export' and isinstance(n.func.value,ast.Name) and n.func.value.id in modules)
        if target:calls.append(n)
    if not calls:continue
    relative=p.relative_to(root).as_posix()
    enabled=[n for n in calls if any(k.arg=='save_native' for k in n.keywords)]
    if enabled:
        assert relative=='art/blender/scripts/city_horizon_assets.py' and len(enabled)==1
        assert all(isinstance(k.value,ast.Constant) and k.value.value is False for n in enabled for k in n.keywords if k.arg=='save_native')
        opted.append(relative)
    else:
        old=subprocess.check_output(['git','show','HEAD:'+relative],cwd=root).decode('utf-8-sig')
        assert ast.dump(ast.parse(old),include_attributes=False)==ast.dump(tree,include_attributes=False),relative
        assert all(len(n.args)<=5 for n in calls),relative
    records.append(dict(path=relative,calls=len(calls),explicit_false=bool(enabled),source_sha256=hashlib.sha256(text.replace('\r\n','\n').encode()).hexdigest()))
assert opted==['art/blender/scripts/city_horizon_assets.py']
(out/'export_callers_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Complete live Blender-script/tools import-alias call audit:allpreexisting callers retain exactmoduleAST andomitnewargument;onlynewcityshardhelper explicitlyoptsFalse. Combined with defaultTrue module projection,not runtime or asset acceptance.',callers=records),indent=2),encoding='utf-8',newline='\n')
print(len(records),'caller files;',sum(r['calls'] for r in records),'calls;onlynewshardhelper optsFalse.')
