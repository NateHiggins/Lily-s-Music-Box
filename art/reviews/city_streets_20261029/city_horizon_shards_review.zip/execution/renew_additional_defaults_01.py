from pathlib import Path
import json,hashlib,subprocess,copy
root=Path('C:/ov/city');out=Path(__file__).parent;helper='art/blender/scripts/fabrication_native_batch.py'
proof=json.loads((out/'export_default_projection_01.json').read_text());assert proof['default_true_module_ast_exact']
callers=json.loads((out/'export_callers_01.json').read_text())['callers']
current=hashlib.sha256((root/helper).read_bytes().replace(b'\r\n',b'\n')).hexdigest();changes={}
protected={x['path'] for x in json.loads((root/'design/ORISON_V2_M11C1_PROTECTED_FINAL_RECEIPT_2026-08-31.json').read_text())['files']}
for name in ['house_switchboard','readable_library']:
    caller='art/blender/scripts/build_'+name+'.py';matches=[x for x in callers if x['path']==caller];assert len(matches)==1 and not matches[0]['explicit_false']
    relative='art/blender/'+name+'_construction.json';assert relative not in protected
    p=root/relative;original=p.read_bytes();assert original==subprocess.check_output(['git','show','HEAD:'+relative],cwd=root)
    data=json.loads(original);assert data['source_bindings'][helper]==proof['original_sha256']
    for dep,expected in data['source_bindings'].items():
        if dep==helper:continue
        raw=(root/dep).read_bytes();raw=raw.replace(b'\r\n',b'\n') if Path(dep).suffix in ['.py','.json','.gd','.import'] else raw
        assert hashlib.sha256(raw).hexdigest()==expected,(relative,dep)
    for dep,expected in data.get('outputs',{}).items():assert hashlib.sha256((root/dep).read_bytes()).hexdigest()==expected,(relative,dep)
    before=copy.deepcopy(data);data['source_bindings'][helper]=current
    after=copy.deepcopy(data);after['source_bindings'][helper]=before['source_bindings'][helper];assert after==before
    (out/('before_additional_'+name+'_construction.json')).write_bytes(original)
    p.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
    changes[relative]=dict(caller=caller,only_binding=helper,previous=proof['original_sha256'],current=current,all_other_fields_and_declared_inputs_outputs_exact=True)
(out/'additional_default_projections_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Correct two newstaticgate regressions exposed byfullboard01. Onlyproven defaultTrue helperdigest renewed;retainedcaller AST/defaultbehavior/allotherfields/inputs/outputs exact. Noasset/interior/interaction/save changes orruntime repinning. Original119gate REGRESSEDboard retained.',changes=changes),indent=2),encoding='utf-8',newline='\n')
subprocess.run(['git','add','--',*changes],cwd=root,check=True)
print('Two additional default-behavior sourcebindings renewed;allotherfields/inputs/outputs exact.')
