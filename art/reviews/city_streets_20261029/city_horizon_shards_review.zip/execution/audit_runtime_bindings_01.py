from pathlib import Path
import json,hashlib,subprocess
root=Path('C:/ov/city');out=Path(__file__).parent;bindings={};receipts={}
for name,relative in [('equivalence','equivalence_01/shards_equivalence.runtime.json'),('render','render_03/shards_render.runtime.json')]:
    p=out/relative;d=json.loads(p.read_text());assert d['schema_version']==2 and d['evidence_kind']=='runtime_contract' and not d['failures'] and d['execution']==dict(completed=True,exit_code=0,timed_out=False)
    receipts[name]=dict(path=relative,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),checks=d['checks'])
    for resource,expected in d['source_hashes'].items():
        relative_path='game/'+resource.removeprefix('res://');p=root/relative_path;raw=p.read_bytes();normalized=p.suffix in ['.gd','.json','.gdshader','.gdshaderinc','.import']
        digest=hashlib.sha256(raw.replace(b'\r\n',b'\n') if normalized else raw).hexdigest();assert digest==expected,(name,relative_path)
        record=dict(raw_sha256=hashlib.sha256(raw).hexdigest(),test_sha256=digest,lf_normalized=normalized,bytes=len(raw))
        assert relative_path not in bindings or record==bindings[relative_path];bindings[relative_path]=record
retired={}
for family in ['city_horizon_near','city_horizon_far','city_horizon_lod1']:
    for suffix in ['.glb','.glb.import']:
        relative='game/assets/props/'+family+suffix;raw=(root/relative).read_bytes();old=subprocess.check_output(['git','show','HEAD:'+relative],cwd=root)
        assert raw.replace(b'\r\n',b'\n')==old.replace(b'\r\n',b'\n') if suffix.endswith('import') else raw==old
        retired[relative]=dict(bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),git_recovery_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip())
p=out/'runtime_bindings_before_retirement_01.json';assert not p.exists();p.write_text(json.dumps(dict(evidence_class='INERT',scope='Exactoriginaltest-written inputbindings verified beforetestfixture/oldassetsretirement;notrepinnedruntimeproof. Oldassetbytes recoverfromspecifiedGitcommit,notduplicatedinreviewarchive.',receipts=receipts,runtime_sources=bindings,retired_assets=retired),indent=2),encoding='utf-8',newline='\n')
print(len(bindings),'distinct current runtime inputs exact;6oldasset/sidecar bytes recoverable fromddc.')
