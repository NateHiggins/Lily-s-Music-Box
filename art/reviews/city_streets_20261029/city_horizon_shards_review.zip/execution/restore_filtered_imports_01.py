from pathlib import Path
import subprocess,json,zipfile,hashlib
root=Path('C:/ov/city').resolve();out=Path(__file__).parent
rows=subprocess.run(['git','status','--porcelain','--untracked-files=no'],cwd=root,capture_output=True,text=True,check=True).stdout.splitlines()
paths=[r[3:] for r in rows if r[:2]==' M'];assert len(paths)==436
assert all(p.startswith('game/assets/ui/newspaper/pictures/') and p.endswith('.import') for p in paths)
tree=subprocess.check_output(['git','write-tree'],cwd=root,text=True).strip()
raw=subprocess.run(['git','cat-file','--batch'],input=''.join(':'+p+'\n' for p in paths).encode(),cwd=root,capture_output=True,check=True).stdout
offset=0;before={}
for p in paths:
    end=raw.index(b'\n',offset);header=raw[offset:end].split();assert header[1]==b'blob';size=int(header[2]);offset=end+1;content=raw[offset:offset+size];offset+=size+1
    path=(root/p).resolve();assert path.is_relative_to(root/'game/assets/ui/newspaper/pictures')
    actual=path.read_bytes();assert actual==content,p;before[p]=actual
backup=out/'filtered_imports_before_restore_01.zip';assert not backup.exists()
with zipfile.ZipFile(backup,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p,content in before.items():z.writestr(p,content)
with zipfile.ZipFile(backup) as z:assert z.testzip() is None
for i in range(0,len(paths),80):subprocess.run(['git','restore','--worktree','--',*paths[i:i+80]],cwd=root,capture_output=True,check=True)
assert tree==subprocess.check_output(['git','write-tree'],cwd=root,text=True).strip()
changed=0
for p,content in before.items():
    actual=(root/p).read_bytes();assert actual.replace(b'\r\n',b'\n')==content.replace(b'\r\n',b'\n'),p
    changed+=actual!=content
after=subprocess.run(['git','status','--porcelain','--untracked-files=no'],cwd=root,capture_output=True,text=True,check=True).stdout.splitlines()
record=dict(evidence_class='INERT',scope='Resolve436Git-status-only importentries afterfinalboard. Everypre-restoreworktreebytealreadyequalsindex;Gitrestore reappliesconfiguredcheckout newlinefilter. LF-normalizedcontent andindex treeunchanged,no staging/unrelatedsemanticedit. Originalemptylineendbackup/guard history remainsseparate.',paths=len(paths),byte_different_after_filter=changed,index_tree=tree,remaining_unstaged=[r for r in after if r[:2]==' M'],backup_sha256=hashlib.sha256(backup.read_bytes()).hexdigest())
(out/'filtered_import_restore_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print('436verifiedindex-equal imports restoredthroughcheckoutfilter;',changed,'newlinebytechanges;',len(record['remaining_unstaged']),'remainingunstaged.')
