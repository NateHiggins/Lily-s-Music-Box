from pathlib import Path
import ast,json,struct,hashlib,numpy as np,sys
root=Path('C:/ov/city');out=Path(__file__).parent
for path in [out.parent/'bodega_frontage_reconciliation_01/check_preservation_01.py',out/'bind_world_frames_01.py']:
    tree=ast.parse(path.read_text(encoding='utf-8-sig'));exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(path),'exec'))
baseline=json.loads((out/'baseline_02.json').read_text());fixture=json.loads((root/'game/tests/fixtures/orison_city_horizon.json').read_text())
sys.path.insert(0,str(root/'art/blender/scripts'));from city_horizon_assets import manifest_paths
runtime=json.loads((root/'game/data/orison_v2/exterior/city_horizon.json').read_text());assert len(manifest_paths(runtime))==34
new={k:{} for k in baseline['parts']};assets={};errors=[]
for key,asset in fixture['assets'].items():
    path=root/asset['asset'];raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==asset['sha256']
    projected=projection(raw);size=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+size]);world=frames(doc)
    family=Path(asset['native']).stem
    assert family in new
    for node in doc['nodes']:
        if 'mesh' not in node:continue
        name=node['name'];assert name not in new[family]
        projected[name]['materials']=[doc['materials'][p['material']]['name'] if 'material' in p else None for p in doc['meshes'][node['mesh']]['primitives']]
        projected[name]['world_transform']=world[name];new[family][name]=projected[name]
    assert set(projected)=={p['name'] for p in asset['parts']}
    assets[key]=dict(bytes=len(raw),parts=len(projected),sha256=asset['sha256'])
counts={}
for family,old in baseline['parts'].items():
    changed=[name for name,v in old.items() if new[family].get(name)!=v]
    added=sorted(new[family].keys()-old.keys());missing=sorted(old.keys()-new[family].keys())
    counts[family]=dict(exact=len(old)-len(changed),changed=changed,added=added,missing=missing);errors.extend(changed+added+missing)
assert hashlib.sha256((root/'art/data/city_horizon/source_plan.json').read_bytes()).hexdigest()==baseline['source_plan_sha256']
record=dict(evidence_class='INERT',scope='All938 original accessor/index/local-and-root-composed transforms/material placeholders exact across34 actual native exports;all124 sourceprofiles exact. Not loaded or artistic qualification.',parts=counts,assets=assets,maximum_asset_bytes=max(a['bytes'] for a in assets.values()),aggregate_asset_bytes=sum(a['bytes'] for a in assets.values()),failures=errors)
p=out/'preservation_01.json';assert not p.exists();p.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in record.items() if k!='assets'}));assert not errors
