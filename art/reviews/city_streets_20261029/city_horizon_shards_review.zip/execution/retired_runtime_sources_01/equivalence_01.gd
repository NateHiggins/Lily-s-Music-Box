extends "res://tests/v2_city_horizon_bench.gd"
const Legacy=preload("res://tmp/city_shards_01/legacy_horizon.gd")
const CIVIC=["HORIZON_NEAR_2_3_P0R0","HORIZON_NEAR_2_3_P0R1","HORIZON_NEAR_2_3_P0R2","HORIZON_NEAR_2_3_P1","HORIZON_NEAR_2_3_P2"]
var texture_records:Dictionary={}
var material_records:Dictionary={}
var observations:Array[Dictionary]=[]
var negative_controls:Dictionary={}
var directory:String

func _ready()->void:call_deferred("run_equivalence")

func _digest(value:Variant)->String:
	var context:=HashingContext.new();context.start(HashingContext.HASH_SHA256);context.update(var_to_bytes(value));return context.finish().hex_encode()

func _texture(texture:Texture2D)->Dictionary:
	var path:=texture.resource_path
	if not texture_records.has(path):
		var image:=texture.get_image()
		check(image!=null and not image.is_empty(),"actual loaded map: "+path)
		if image==null or image.is_empty():return {}
		var expected:=int(floor(log(float(maxi(image.get_width(),image.get_height())))/log(2.)))
		check(image.has_mipmaps() and image.get_mipmap_count()==expected,"complete actual loaded mip chain: "+path)
		texture_records[path]={"path":path,"width":image.get_width(),"height":image.get_height(),"mips":image.get_mipmap_count(),"has_mipmaps":image.has_mipmaps()}
	return texture_records[path]

func _material(draw:MeshInstance3D)->Dictionary:
	var actual:Material=draw.material_override
	var stock:StandardMaterial3D=draw.get_meta("v2_city_roof_source",actual) as StandardMaterial3D
	check(stock!=null and stock.normal_enabled and not stock.uv1_triplanar,"source-owned metric PBR: "+str(draw.name))
	if stock==null:return {}
	var maps:Array=[]
	for texture:Texture2D in [stock.albedo_texture,stock.roughness_texture,stock.normal_texture]:
		check(texture!=null,"all three source maps: "+str(draw.name))
		maps.append(_texture(texture) if texture!=null else {})
	var result:Dictionary={"albedo":stock.albedo_color,"normal":stock.normal_scale,"roughness":stock.roughness,"metallic":stock.metallic,"uv_scale":stock.uv1_scale,"filter":stock.texture_filter,"maps":maps,"shader":"","uniforms":{}}
	if actual is ShaderMaterial:
		var shader_material:=actual as ShaderMaterial
		result.shader=shader_material.shader.code.sha256_text()
		for uniform:Dictionary in shader_material.shader.get_shader_uniform_list():
			var key:=str(uniform.name);var value:Variant=shader_material.get_shader_parameter(key)
			if value==null:value=RenderingServer.shader_get_parameter_default(shader_material.shader.get_rid(),key)
			result.uniforms[key]=_texture(value) if value is Texture2D else value
	return result

func _snapshot(owner:Node3D)->Dictionary:
	var result:Dictionary={}
	for draw:MeshInstance3D in owner.find_children("*","MeshInstance3D",true,false):
		var name:=str(draw.name);check(not result.has(name),"unique installed part: "+name)
		var body:=draw.get_node("HorizonCollision") as StaticBody3D
		var shape:=body.get_child(0) as CollisionShape3D
		var physical:=shape.shape as ConcavePolygonShape3D
		check(physical!=null and not shape.disabled and body.collision_layer==1,"actual enabled near collision owner: "+name)
		var surface:Dictionary=RenderingServer.mesh_get_surface(draw.mesh.get_rid(),0)
		var material:=_material(draw);material_records[name]=_digest(material)
		result[name]={"world":draw.global_transform,"arrays":_digest(draw.mesh.surface_get_arrays(0)),"format":draw.mesh.surface_get_format(0),"lods":_digest(surface.get("lods",[])),"material":_digest(material),"collision_world":shape.global_transform,"collision_faces":_digest(physical.get_faces()),"layer":body.collision_layer,"mask":body.collision_mask,"replacement":draw.get_meta("v2_city_horizon_body_lod",false)}
	return result

func _corona(owner:Node3D)->Dictionary:
	var corona:=owner.get_node("StElmoCorona") as MultiMeshInstance3D
	var instances:Array=[];var identities:Array[String]=[]
	for draw:MeshInstance3D in owner.find_children("*","MeshInstance3D",true,false):
		if str(draw.name).ends_with("__limestone"):identities.append(str(draw.name))
	for i in corona.multimesh.instance_count:
		instances.append({"transform":corona.multimesh.get_instance_transform(i),"customdata":corona.multimesh.get_instance_custom_data(i)})
	return {"parts":identities,"instances":instances,"material_shader":(corona.material_override as ShaderMaterial).shader.code.sha256_text(),"cull":corona.extra_cull_margin,"shadow":corona.cast_shadow,"visible":corona.visible}

func _lower(frame:Node3D,entries:Array)->Dictionary:
	var result:Dictionary={}
	for entry:Dictionary in entries:
		var model:Node3D=(load(str(entry.asset)) as PackedScene).instantiate();model.visible=false;frame.add_child(model)
		for draw:MeshInstance3D in model.find_children("*","MeshInstance3D",true,false):
			var name:=str(draw.name);check(not result.has(name),"unique raw imported lower part: "+name)
			result[name]={"world":draw.global_transform,"arrays":_digest(draw.mesh.surface_get_arrays(0)),"format":draw.mesh.surface_get_format(0)}
		model.free()
	return result

func _world(label:String)->Dictionary:
	var viewport:=SubViewport.new();viewport.name=label;viewport.size=Vector2i(3440,1440);viewport.own_world_3d=true;viewport.render_target_update_mode=SubViewport.UPDATE_DISABLED
	viewport.msaa_3d=get_viewport().msaa_3d;viewport.use_taa=false;add_child(viewport)
	var frame:=Node3D.new();frame.transform=Transform3D(Basis.from_scale(Vector3(-1,1,-1)),Vector3(17,3,-11));viewport.add_child(frame)
	var environment:=WorldEnvironment.new();var settings:=Environment.new();settings.background_mode=Environment.BG_COLOR;settings.background_color=Color(.32,.38,.44);settings.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;settings.ambient_light_color=Color(.62,.72,.8);settings.ambient_light_energy=.7;environment.environment=settings;viewport.add_child(environment)
	var sun:=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-40,-25,0);sun.light_energy=2.8;sun.shadow_enabled=true;viewport.add_child(sun)
	var camera:=Camera3D.new();camera.far=20000.;camera.fov=75.;viewport.add_child(camera);camera.make_current()
	camera.global_position=frame.global_transform*Vector3(-115,31,-148);camera.look_at(frame.global_transform*Vector3(-160,8,-123))
	return {"viewport":viewport,"frame":frame,"camera":camera}

func _controls(owner:Node3D,source:Dictionary)->void:
	check(Horizon.manifest_failures(source).is_empty(),"actual schema2 manifest positive control")
	var missing:Dictionary=source.duplicate(true);missing.assets.pop_back();negative_controls.missing_block=not Horizon.manifest_failures(missing).is_empty();check(negative_controls.missing_block,"missing block rejected")
	var duplicate:Dictionary=source.duplicate(true);duplicate.assets[0].parts.append(duplicate.assets[0].parts[0]);negative_controls.duplicate_part=not Horizon.manifest_failures(duplicate).is_empty();check(negative_controls.duplicate_part,"duplicate part rejected")
	var split:Dictionary=source.duplicate(true);split.assets[1].parts.append(split.assets[0].parts.pop_back());negative_controls.split_building=not Horizon.manifest_failures(split).is_empty();check(negative_controls.split_building,"split building rejected")
	var foreign:Dictionary=source.duplicate(true);foreign.assets[0].asset="res://assets/props/orison_ground.glb";negative_controls.foreign_asset=not Horizon.manifest_failures(foreign).is_empty();check(negative_controls.foreign_asset,"unregistered precision target rejected")
	var entry:Dictionary=source.assets[0];var candidate:Node3D=(load(str(entry.asset)) as PackedScene).instantiate()
	check(Horizon.model_failures(candidate,entry).is_empty(),"actual imported roster positive control")
	var part:=candidate.find_children("*","MeshInstance3D",true,false)[0] as MeshInstance3D;part.free()
	negative_controls.missing_imported_part=not Horizon.model_failures(candidate,entry).is_empty();check(negative_controls.missing_imported_part,"actual missing imported mesh rejected");candidate.free()
	candidate=(load(str(entry.asset)) as PackedScene).instantiate();part=candidate.find_children("*","MeshInstance3D",true,false)[0] as MeshInstance3D;part.get_parent().add_child(part.duplicate())
	negative_controls.duplicate_imported_part=not Horizon.model_failures(candidate,entry).is_empty();check(negative_controls.duplicate_imported_part,"actual duplicated imported mesh rejected");candidate.free()
	var corona:=owner.get_node("StElmoCorona") as MultiMeshInstance3D;var original:=_corona(owner)
	check(corona.multimesh.instance_count>1,"nonempty ordered corona phase control")
	if corona.multimesh.instance_count>1:
		var first:=corona.multimesh.get_instance_transform(0);var second:=corona.multimesh.get_instance_transform(1)
		corona.multimesh.set_instance_transform(0,second);corona.multimesh.set_instance_transform(1,first)
		negative_controls.same_pointset_wrong_phase=_digest(_corona(owner))!=_digest(original);check(negative_controls.same_pointset_wrong_phase,"same corona pointset with wrong phase assignment rejected")
		corona.multimesh.set_instance_transform(0,first);corona.multimesh.set_instance_transform(1,second)
		check(_digest(_corona(owner))==_digest(original),"corona exact restore before rendering")

func _frame_sample(viewport:SubViewport)->Dictionary:
	var rid:=viewport.get_viewport_rid()
	return {"draws":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_VISIBLE,RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME),"primitives":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_VISIBLE,RenderingServer.VIEWPORT_RENDER_INFO_PRIMITIVES_IN_FRAME),"shadow_draws":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_SHADOW,RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME),"shadow_primitives":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_SHADOW,RenderingServer.VIEWPORT_RENDER_INFO_PRIMITIVES_IN_FRAME),"cpu_ms":RenderingServer.viewport_get_measured_render_time_cpu(rid),"gpu_ms":RenderingServer.viewport_get_measured_render_time_gpu(rid)}

func run_equivalence()->void:
	RealityState.persistence_enabled=false;RealityState.reset_campaign_for_tests();CampaignTime.set_frozen_for_tests(true)
	directory=OS.get_environment("SHOT_DIR");check(not directory.is_empty() and DisplayServer.get_name()!="headless","graphical output supplied")
	if directory.is_empty() or DisplayServer.get_name()=="headless":get_tree().quit(1);return
	DirAccess.make_dir_recursive_absolute(directory)
	var source:Dictionary=JSON.parse_string(FileAccess.get_file_as_string(Horizon.FINISHES));var old_source:Dictionary=JSON.parse_string(FileAccess.get_file_as_string(Legacy.FINISHES))
	var started:=Time.get_ticks_usec();var old_world:=_world("LegacyWorld");var old:Node3D=Legacy.new();old_world.frame.add_child(old)
	var new_world:=_world("ShardWorld");var current:Node3D=Horizon.new();new_world.frame.add_child(current)
	await get_tree().physics_frame;await get_tree().physics_frame
	check(old.get_world_3d()!=current.get_world_3d(),"legacy andcurrent have independent physicsworlds")
	var old_parts:=_snapshot(old);var new_parts:=_snapshot(current)
	check(old_parts.size()==749 and new_parts.size()==749,"all749 installed nearparts")
	for name:String in old_parts:check(new_parts.has(name) and new_parts[name]==old_parts[name],"exact loaded geometry/LOD/material/nearcollision/rootframe: "+name)
	var old_lower:=_lower(old_world.frame,[{"asset":str(old_source.body_lod.asset)}]);var new_lower:=_lower(new_world.frame,source.body_lod.assets)
	check(old_lower.size()==189 and new_lower.size()==189,"all189 raw lowerparts")
	for name:String in old_lower:check(new_lower.has(name) and new_lower[name]==old_lower[name],"exact raw imported lowerarrays/rootframe: "+name)
	var old_corona:=_corona(old);var new_corona:=_corona(current);check(_digest(old_corona)==_digest(new_corona),"ordered corona transforms/customdata andtipidentity exact")
	_controls(current,source)
	var preparation_ms:float=(Time.get_ticks_usec()-started)/1000.
	var screen:=TextureRect.new();screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);add_child(screen)
	var cap:=Engine.max_fps;var vsync:=DisplayServer.window_get_vsync_mode();Engine.max_fps=0;DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	check(get_viewport().get_visible_rect().size==Vector2(3440,1440),"fullscreen native3440x1440 presentation")
	for pair:Dictionary in [{"label":"legacy","world":old_world,"owner":old},{"label":"shards","world":new_world,"owner":current}]:
		old_world.viewport.render_target_update_mode=SubViewport.UPDATE_DISABLED;new_world.viewport.render_target_update_mode=SubViewport.UPDATE_DISABLED
		var viewport:SubViewport=pair.world.viewport;viewport.render_target_update_mode=SubViewport.UPDATE_ALWAYS;screen.texture=viewport.get_texture();RenderingServer.viewport_set_measure_render_time(viewport.get_viewport_rid(),true)
		for draw:MeshInstance3D in pair.owner.find_children("*","MeshInstance3D",true,false):draw.visible=str(draw.name).split("__")[0] in CIVIC
		for spec:Dictionary in [{"id":"near","threshold":0.},{"id":"lower","threshold":10000.},{"id":"return","threshold":0.}]:
			viewport.mesh_lod_threshold=float(spec.threshold);var warm:Array=[];var samples:Array=[];var previous:=Time.get_ticks_usec()
			for i in 102:
				await RenderingServer.frame_post_draw
				var now:=Time.get_ticks_usec();var sample:=_frame_sample(viewport);sample.wall_ms=(now-previous)/1000.;previous=now
				if i<12:warm.append(sample)
				else:samples.append(sample)
			var file:=str(pair.label)+"_"+str(spec.id)+".png";check(viewport.get_texture().get_image().save_png(directory.path_join(file))==OK,"actualLODframe saved: "+file)
			observations.append({"owner":pair.label,"profile":spec.id,"threshold":spec.threshold,"file":file,"warmup":warm,"samples":samples,"counters":_frame_sample(viewport)})
	Engine.max_fps=cap;DisplayServer.window_set_vsync_mode(vsync)
	for i in 3:check(observations[i].counters.draws==observations[i+3].counters.draws and observations[i].counters.primitives==observations[i+3].counters.primitives,"actualvisible LODdraw/primitive parity: "+str(i))
	var sources:=_industrial_sources(current)
	for path:String in [get_script().resource_path,"res://tmp/city_shards_01/legacy_horizon.gd",Legacy.FINISHES,"res://assets/props/city_horizon_near.glb","res://assets/props/city_horizon_far.glb","res://assets/props/city_horizon_lod1.glb","res://assets/props/city_horizon_near.glb.import","res://assets/props/city_horizon_far.glb.import","res://assets/props/city_horizon_lod1.glb.import"]:sources[path]=_profile_sha(path)
	var record:Dictionary={"schema_version":2,"evidence_kind":"runtime_contract","selector":"v2","production_runtime":true,"scope":"Transport-only34-block Horizon loader parity againstddc legacyloader/data andretained3monolithicGLBs inindependentWorld3Ds. All749 installed partarrays/LODs/rootframes/materialpolicy/collisionfaces plus189rawlowerparts,orderedcorona transforms/customdata,negativecontrols andsixisolatedcivicLODframes. No combinedOrison/ground,player route,traffic/save,weatherbehaviour,matchedperformance gain,wholecity budget or artisticacceptance.","execution":{"completed":true,"exit_code":0 if failures.is_empty() else 1,"timed_out":false},"source":{"test_path":"game/"+get_script().resource_path.trim_prefix("res://"),"test_sha256":FileAccess.get_sha256(get_script().resource_path),"runtime_inputs_sha256":JSON.stringify(sources).sha256_text()},"contracts":{"loaded_geometry_collision_material_lod_parity":{"executed":old_parts.size()==749 and new_parts.size()==749,"passed":failures.is_empty()},"raw_lower_import_parity":{"executed":old_lower.size()==189 and new_lower.size()==189,"passed":failures.is_empty()},"ordered_corona_parity":{"executed":not old_corona.instances.is_empty(),"passed":_digest(old_corona)==_digest(new_corona)},"negative_controls":{"executed":negative_controls.size()==7,"passed":not false in negative_controls.values()},"rendered_lod_parity":{"executed":observations.size()==6,"passed":failures.is_empty()}},"checks":checks,"failures":failures,"preparation_ms":preparation_ms,"negative_controls":negative_controls,"old_parts":old_parts,"new_parts":new_parts,"old_lower":old_lower,"new_lower":new_lower,"old_corona":old_corona,"new_corona":new_corona,"loaded_textures":texture_records,"actual_materials":material_records,"observations":observations,"source_hashes":sources}
	FileAccess.open(directory.path_join("shards_equivalence.runtime.json"),FileAccess.WRITE).store_string(JSON.stringify(record,"\t"))
	print("SHARD EQUIVALENCE: ",checks," checks, ",failures.size()," failures")
	old_world.viewport.free();new_world.viewport.free();get_tree().quit(0 if failures.is_empty() else 1)
