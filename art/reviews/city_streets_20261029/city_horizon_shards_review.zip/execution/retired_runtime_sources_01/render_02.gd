extends "res://tests/v2_city_horizon_bench.gd"
const Legacy=preload("res://tmp/city_shards_01/legacy_horizon.gd")
const IDS=["HORIZON_NEAR_2_3_P0R0","HORIZON_NEAR_2_3_P0R1","HORIZON_NEAR_2_3_P0R2","HORIZON_NEAR_2_3_P1","HORIZON_NEAR_2_3_P2"]
var observations:Array[Dictionary]=[]
var directory:String
func _ready()->void:call_deferred("run_render")

func _foreground(subject:Image,blank:Image)->Dictionary:
	subject.convert(Image.FORMAT_RGBA8);blank.convert(Image.FORMAT_RGBA8)
	var a:=subject.get_data();var b:=blank.get_data();var width:=subject.get_width();var height:=subject.get_height()
	var low:=Vector2i(width,height);var high:=Vector2i(-1,-1);var hits:=0;var tested:=0
	for y in range(0,height,4):
		for x in range(0,width,4):
			var i:=4*(y*width+x);tested+=1
			if maxi(absi(int(a[i])-int(b[i])),maxi(absi(int(a[i+1])-int(b[i+1])),absi(int(a[i+2])-int(b[i+2]))))<=5:continue
			hits+=1;low.x=mini(low.x,x);low.y=mini(low.y,y);high.x=maxi(high.x,x);high.y=maxi(high.y,y)
	var center:Vector2=Vector2(low+high)*.5/Vector2(width,height)
	return {"hits":hits,"tested":tested,"fraction":float(hits)/maxi(1,tested),"low":[low.x,low.y],"high":[high.x,high.y],"center":[center.x,center.y],"width_fraction":float(high.x-low.x)/width,"height_fraction":float(high.y-low.y)/height}

func _sample()->Dictionary:
	var rid:=get_viewport().get_viewport_rid()
	var value:Dictionary={"visible_draws":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_VISIBLE,RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME),"visible_primitives":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_VISIBLE,RenderingServer.VIEWPORT_RENDER_INFO_PRIMITIVES_IN_FRAME),"shadow_draws":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_SHADOW,RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME),"shadow_primitives":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_SHADOW,RenderingServer.VIEWPORT_RENDER_INFO_PRIMITIVES_IN_FRAME)}
	value.cpu_ms=RenderingServer.viewport_get_measured_render_time_cpu(rid);value.gpu_ms=RenderingServer.viewport_get_measured_render_time_gpu(rid)
	return value

func run_render()->void:
	RealityState.persistence_enabled=false;RealityState.reset_campaign_for_tests();CampaignTime.set_frozen_for_tests(true)
	directory=OS.get_environment("SHOT_DIR")
	check(not directory.is_empty() and DisplayServer.get_name()!="headless","graphical native capture supplied")
	if directory.is_empty() or DisplayServer.get_name()=="headless":get_tree().quit(1);return
	DirAccess.make_dir_recursive_absolute(directory)
	var environment:=WorldEnvironment.new();var settings:=Environment.new();settings.background_mode=Environment.BG_COLOR;settings.background_color=Color(.32,.38,.44);settings.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;settings.ambient_light_color=Color(.62,.72,.8);settings.ambient_light_energy=.7;environment.environment=settings;add_child(environment)
	var sun:=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-40,-25,0);sun.light_energy=2.8;sun.shadow_enabled=true;add_child(sun)
	var camera:=Camera3D.new();camera.projection=Camera3D.PROJECTION_ORTHOGONAL;camera.far=20000.;add_child(camera);camera.make_current()
	var frame:=Node3D.new();frame.transform=Transform3D(Basis.from_scale(Vector3(-1,1,-1)),Vector3(17,3,-11));add_child(frame)
	var viewport:=get_viewport();var threshold:=viewport.mesh_lod_threshold;var taa:=viewport.use_taa;var vsync:=DisplayServer.window_get_vsync_mode();var cap:=Engine.max_fps
	viewport.use_taa=false;DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED);Engine.max_fps=0;RenderingServer.viewport_set_measure_render_time(viewport.get_viewport_rid(),true)
	await get_tree().physics_frame;await RenderingServer.frame_post_draw
	check(viewport.get_visible_rect().size==Vector2(3440,1440),"fullscreen native3440x1440 rootviewport")
	var sources:Dictionary={};var retired_bodies:Array[WeakRef]=[]
	for label:String in ["legacy","shards"]:
		for reference:WeakRef in retired_bodies:check(reference.get_ref()==null,"previous owner collision retired before next world")
		var owner:Node3D=Legacy.new() if label=="legacy" else Horizon.new();frame.add_child(owner)
		await get_tree().physics_frame;await get_tree().physics_frame
		var selected:Array[MeshInstance3D]=[];var box:=AABB();var first:=true;var bodies:Array[WeakRef]=[]
		for draw:MeshInstance3D in owner.find_children("*","MeshInstance3D",true,false):
			bodies.append(weakref(draw.get_node("HorizonCollision")))
			draw.visible=str(draw.name).split("__")[0] in IDS
			if not draw.visible:continue
			selected.append(draw);var bounds: AABB=draw.global_transform*draw.get_aabb();box=bounds if first else box.merge(bounds);first=false
		check(selected.size()==42 and bodies.size()==749,"one complete live owner and42selected visual partitions")
		var center:=box.get_center();camera.size=box.size.length()*1.1;camera.global_position=center+Vector3(1.,.5,1.).normalized()*200.;camera.look_at(center)
		camera.reset_physics_interpolation();camera.force_update_transform();RenderingServer.camera_set_transform(camera.get_camera_rid(),camera.get_camera_transform())
		await RenderingServer.frame_post_draw;await RenderingServer.frame_post_draw
		var projected:Array=[]
		for i in 8:
			var point:=box.position+box.size*Vector3(1 if i&1 else 0,1 if i&2 else 0,1 if i&4 else 0)
			var pixel:=camera.unproject_position(point);projected.append([pixel.x,pixel.y]);check(pixel.x>0 and pixel.x<3440 and pixel.y>0 and pixel.y<1440,"actual subject bounds project inside native frame")
		for spec:Dictionary in [{"id":"near","threshold":0.},{"id":"lower","threshold":10000.},{"id":"return","threshold":0.}]:
			viewport.mesh_lod_threshold=float(spec.threshold);var warm:Array=[];var samples:Array=[];var previous:=Time.get_ticks_usec()
			for i in 102:
				await RenderingServer.frame_post_draw
				var now:=Time.get_ticks_usec();var value:=_sample();value.wall_ms=(now-previous)/1000.;previous=now
				if i<12:warm.append(value)
				else:samples.append(value)
			var image:=viewport.get_texture().get_image();var file:=label+"_"+str(spec.id)+".png";check(image.save_png(directory.path_join(file))==OK,"rootviewport subject saved: "+file)
			for draw:MeshInstance3D in selected:draw.visible=false
			await RenderingServer.frame_post_draw;await RenderingServer.frame_post_draw
			var blank:=viewport.get_texture().get_image();check(blank.save_png(directory.path_join(label+"_"+str(spec.id)+"_hidden.png"))==OK,"actual hidden control saved")
			for draw:MeshInstance3D in selected:draw.visible=true
			await RenderingServer.frame_post_draw;await RenderingServer.frame_post_draw
			var coverage:=_foreground(image,blank)
			check(coverage.fraction>.02 and coverage.width_fraction>.15 and coverage.height_fraction>.2,"resolvable subject coverage: "+file)
			check(coverage.center[0]>.25 and coverage.center[0]<.75 and coverage.center[1]>.25 and coverage.center[1]<.75,"actual subject centered: "+file)
			observations.append({"owner":label,"profile":spec.id,"file":file,"warmup":warm,"samples":samples,"counters":samples[-1],"coverage":coverage,"projected_bounds":projected,"camera_world":str(camera.global_transform),"camera_server_input":str(camera.get_camera_transform()),"camera_size":camera.size})
		if label=="shards":sources=_industrial_sources(owner)
		owner.free();retired_bodies=bodies
		await get_tree().physics_frame;await get_tree().physics_frame;await RenderingServer.frame_post_draw
	for reference:WeakRef in retired_bodies:check(reference.get_ref()==null,"final collision owner retired")
	for i in 3:check(observations[i].counters.visible_draws==observations[i+3].counters.visible_draws and observations[i].counters.visible_primitives==observations[i+3].counters.visible_primitives,"actual legacy/shard visibleLOD counters match")
	for path:String in [get_script().resource_path,"res://tmp/city_shards_01/legacy_horizon.gd",Legacy.FINISHES,"res://tests/native_debug_window.gd","res://assets/props/city_horizon_near.glb","res://assets/props/city_horizon_far.glb","res://assets/props/city_horizon_lod1.glb"]:sources[path]=_profile_sha(path)
	viewport.mesh_lod_threshold=threshold;viewport.use_taa=taa;DisplayServer.window_set_vsync_mode(vsync);Engine.max_fps=cap
	var record:Dictionary={"schema_version":2,"evidence_kind":"runtime_contract","selector":"v2","production_runtime":true,"scope":"Focused corrected rootviewport rendering witness only;sequential retired legacy/current physics owners,actual42part civicbounds fit,near/lower/return frames plus six hidden controls. Actualcoverage/centering andLODdrawcounts. Reuses separate10420/0data/corona parity;doesnot rerunorrepin it. No playedroute,composedworld,weather,matchedperformancegain orartisticacceptance. Originaltiny/skewedSubviewportcaptures retained;theirrootcauseisnotclaimedresolved.","execution":{"completed":true,"exit_code":0 if failures.is_empty() else 1,"timed_out":false},"source":{"test_path":"game/"+get_script().resource_path.trim_prefix("res://"),"test_sha256":FileAccess.get_sha256(get_script().resource_path),"runtime_inputs_sha256":JSON.stringify(sources).sha256_text()},"contracts":{"actual_rootviewport_lod_presentation":{"executed":observations.size()==6,"passed":failures.is_empty()},"legacy_collision_retirement":{"executed":retired_bodies.size()==749,"passed":failures.is_empty()}},"checks":checks,"failures":failures,"observations":observations,"source_hashes":sources}
	FileAccess.open(directory.path_join("shards_render.runtime.json"),FileAccess.WRITE).store_string(JSON.stringify(record,"\t"));print("SHARD ROOT RENDER: ",checks," checks, ",failures.size()," failures");get_tree().quit(0 if failures.is_empty() else 1)
