from pathlib import Path
import hashlib,json
root=Path('C:/ov/city');out=Path(__file__).parent
p=root/'game/scripts/building/orison_v2_city_horizon.gd';old=p.read_text(encoding='utf-8');s=old
edits=[
('const ASSETS := [preload("res://assets/props/city_horizon_near.glb"), preload("res://assets/props/city_horizon_far.glb")]\n',''),
('\tassert(int(source.schema) == 1 and str(source.frame) == "ORISON_V2_BUILDING_FRAME")','\tvar manifest_errors:=manifest_failures(source)\n\tassert(manifest_errors.is_empty(),JSON.stringify(manifest_errors))'),
('\tvar lower: Node3D=null','\tvar lower_roots: Array[Node3D]=[]'),
('''		lower=(load(str(replacement.asset)) as PackedScene).instantiate() as Node3D
		for draw: MeshInstance3D in lower.find_children("*","MeshInstance3D",true,false):
			assert(str(draw.name) in replacement.parts and not lower_parts.has(str(draw.name)))
			lower_parts[str(draw.name)]=draw''','''		for entry: Dictionary in replacement.assets:
			var lower: Node3D=(load(str(entry.asset)) as PackedScene).instantiate() as Node3D
			add_child(lower)
			var errors:=model_failures(lower,entry)
			assert(errors.is_empty(),JSON.stringify(errors))
			lower_roots.append(lower)
			for draw: MeshInstance3D in lower.find_children("*","MeshInstance3D",true,false):
				assert(str(draw.name) in replacement.parts and not lower_parts.has(str(draw.name)))
				lower_parts[str(draw.name)]=draw'''),
('''	for asset: PackedScene in ASSETS:
		var model := asset.instantiate() as Node3D
		add_child(model)''','''	for entry: Dictionary in source.assets:
		var model: Node3D=(load(str(entry.asset)) as PackedScene).instantiate() as Node3D
		add_child(model)
		var errors:=model_failures(model,entry)
		assert(errors.is_empty(),JSON.stringify(errors))'''),
('assert(draw.transform.is_equal_approx(far_draw.transform))','assert(draw.global_transform.is_equal_approx(far_draw.global_transform))'),
('\tif lower!=null:lower.free()','\tfor lower: Node3D in lower_roots:lower.free()')]
for a,b in edits:
    assert s.count(a)==1,a;s=s.replace(a,b)
prepared=(out/'manifest_prepared_01.gd').read_text(encoding='utf-8').split('\n',1)[1]
s+='\n'+prepared
(out/'loader_ddc_original.gd').write_text(old,encoding='utf-8',newline='\n')
p.write_text(s,encoding='utf-8',newline='\n')
(out/'loader_source_edit_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Installed uncompiled schema2 block loader;actual source/native/runtime checks pending.',original_sha256=hashlib.sha256(old.encode()).hexdigest(),changed_sha256=hashlib.sha256(s.encode()).hexdigest()),indent=2),encoding='utf-8',newline='\n')
print('Installed schema2 asset roster validation androot-composed lower matching;material/collision logic retained.')
