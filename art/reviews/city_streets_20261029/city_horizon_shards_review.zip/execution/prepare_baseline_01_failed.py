from pathlib import Path
import ast,json,struct,hashlib,subprocess,collections
root=Path('C:/ov/city');out=Path(__file__).parent
reader=out.parent/'bodega_frontage_reconciliation_01/check_preservation_01.py'
tree=ast.parse(reader.read_text(encoding='utf-8-sig'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(reader),'exec'))
base='81d2988ed650f514ab494be06be909b27e894683'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
parts={};assets={};groups=collections.defaultdict(list)
for family in ['city_horizon_near','city_horizon_far','city_horizon_lod1']:
    path=root/f'game/assets/props/{family}.glb';raw=path.read_bytes()
    assert raw==subprocess.check_output(['git','show',base+':'+path.relative_to(root).as_posix()],cwd=root)
    projected=projection(raw);size=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+size])
    for node in doc['nodes']:
        if 'mesh' not in node:continue
        name=node['name'];assert name in projected
        projected[name]['materials']=[doc['materials'][p['material']]['name'] for p in doc['meshes'][node['mesh']]['primitives']]
        groups[family+'|'+'_'.join(name.split('__')[0].split('_')[:4])].append(name)
    parts[family]=projected;assets[path.relative_to(root).as_posix()]=hashlib.sha256(raw).hexdigest()
plan=(root/'art/data/city_horizon/source_plan.json').read_bytes()
record=dict(evidence_class='INERT',sourcebase=base,scope='Immutable exact accessor/index/local transform/material-slot baseline for transport-only block export. All original building partitions andall124profile records remain unchanged. Not runtime,rendering or artistic qualification.',parts=parts,assets=assets,source_plan_sha256=hashlib.sha256(plan).hexdigest(),block_rosters=dict(groups))
p=out/'baseline_01.json';assert not p.exists();p.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print('Baseline',sum(map(len,parts.values())),'parts;',len(groups),'base/lower blocks;',len(json.loads(plan)['buildings']),'profiles.')
