from pathlib import Path
import json,struct,numpy as np
out=Path(__file__).parent;root=Path('C:/ov/city')
record=json.loads((out/'baseline_01.json').read_text())
def frames(doc):
    parents={}
    for i,node in enumerate(doc['nodes']):
        for child in node.get('children',[]):
            assert child not in parents;parents[child]=i
    cache={};visiting=set()
    def world(i):
        if i in cache:return cache[i]
        assert i not in visiting;visiting.add(i);node=doc['nodes'][i]
        if 'matrix' in node:local=np.array(node['matrix'],dtype=float).reshape(4,4).T
        else:
            x,y,z,w=node.get('rotation',[0,0,0,1]);rotation=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
            local=np.eye(4);local[:3,:3]=rotation@np.diag(node.get('scale',[1,1,1]));local[:3,3]=node.get('translation',[0,0,0])
        cache[i]=world(parents[i])@local if i in parents else local;visiting.remove(i);return cache[i]
    return {n['name']:world(i).tolist() for i,n in enumerate(doc['nodes']) if 'mesh' in n}
for family,parts in record['parts'].items():
    raw=(root/f'game/assets/props/{family}.glb').read_bytes();size=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+size]);actual=frames(doc)
    assert set(actual)==set(parts)
    for name,projection in parts.items():projection['world_transform']=actual[name]
record['scope']+=' Full glTF parent/root-composed4x4 frames are included;local equality alone is not preservation.'
p=out/'baseline_02.json';assert not p.exists();p.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print('Bound938 full parent/root-composed mesh frames.')
