from pathlib import Path
import json,re,sys
root=Path('C:/ov/city');out=Path(__file__).parent
sys.path.insert(0,str(root/'tools'));from preflight_spatial_test_bindings import check_fixture
text=(root/'game/tests/orison_v2_surface_inventory.gd').read_text(encoding='utf-8')
declaration=re.search(r'for fixture: String in \[(.*?)\]:',text,re.S);assert declaration
names=re.findall(r'"([^"]+\.json)"',declaration.group(1));assert len(names)==13
result={name:check_fixture(root/'game/tests/fixtures'/name,root) for name in names}
p=out/'required_closure_01.json';assert not p.exists();p.write_text(json.dumps(dict(evidence_class='INERT',scope='Actual requiredsurface-programme nativefixture preflight beforeGodot;sourceonly,notruntimeproof.',fixtures=result),indent=2),encoding='utf-8',newline='\n')
print('Requiredsourceclosure',len(result),'fixtures,',sum(bool(x) for x in result.values()),'failures');assert not any(result.values())
