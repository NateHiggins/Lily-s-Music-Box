from pathlib import Path
import json,re,copy
out=Path(__file__).parent
baseline=json.loads((out/'baseline_02.json').read_text())
def block(name):
    identity=name.split('__')[0]
    assert re.fullmatch(r'HORIZON_(?:(?:NEAR|FAR)_\d+_\d+|STREET_END_\d+)_P\d+(?:R\d+)?',identity),name
    assert len(name.split('__'))==2 and name.split('__')[1],name
    return '_'.join(identity.split('_')[:4])
def validate(groups,expected):
    seen={};owners={}
    for group,names in groups.items():
        assert names,group
        for name in names:
            assert name not in seen and group==block(name),name
            seen[name]=group;identity=name.split('__')[0]
            assert owners.setdefault(identity,group)==group
    assert set(seen)==set(expected),(set(expected)-set(seen),set(seen)-set(expected))
    return len(seen)
base={};lower={};base_parts={}
for family,parts in baseline['parts'].items():
    groups=lower if family=='city_horizon_lod1' else base
    for name in parts:
        groups.setdefault(block(name),[]).append(name)
        if family!='city_horizon_lod1':assert name not in base_parts;base_parts[name]=parts[name]
lower_parts=baseline['parts']['city_horizon_lod1']
assert validate(base,base_parts)==749 and validate(lower,lower_parts)==189
for identity in {name.split('__')[0] for name in lower_parts}:
    assert {n for n in lower_parts if n.split('__')[0]==identity}=={n for n in base_parts if n.split('__')[0]==identity},identity
results={}
for kind in ['missing','duplicate','split','invalid_id']:
    bad=copy.deepcopy(base);key=next(iter(bad));name=bad[key][0]
    if kind=='missing':bad[key].remove(name)
    elif kind=='duplicate':bad[key].append(name)
    elif kind=='split':bad[key].remove(name);bad[next(k for k in bad if k!=key)].append(name)
    else:bad[key][0]='HORIZON_NEAR_BAD__limestone'
    try:validate(bad,base_parts)
    except AssertionError:results[kind]='rejected'
    else:raise AssertionError(kind+' accepted')
record=dict(evidence_class='INERT',scope='Read-only schema/layout planning controls against938-part immutable source baseline. No Blender exports,loader implementation or runtime qualification.',base_blocks={k:sorted(v) for k,v in base.items()},lower_blocks={k:sorted(v) for k,v in lower.items()},controls=results)
p=out/'layout_controls_01.json';assert not p.exists();p.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print('28base+6lower groups,22complete replacement bodies;missing/duplicate/split/invalid-ID controls rejected.')
