from pathlib import Path
import zipfile,json,hashlib
root=Path('C:/ov/city').resolve();out=Path(__file__).parent
records={}
for folder in ['art/blender','game/tests/fixtures']:
    for p in (root/folder).glob('*.json'):
        relative=p.relative_to(root).as_posix();saved=out/('before_renewal_'+relative.replace('/','_'))
        if saved.exists():records[relative]=(p,saved)
assert len(records)==18
backup=out/'failed_source_closure_01.zip';assert not backup.exists()
with zipfile.ZipFile(backup,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for relative,(p,saved) in records.items():z.writestr('partial/'+relative,p.read_bytes())
    z.writestr('renew_source_closure_01.py',(out/'renew_source_closure_01.py').read_bytes())
with zipfile.ZipFile(backup) as z:assert z.testzip() is None
for relative,(p,saved) in records.items():
    assert p.resolve().is_relative_to(root)
    p.write_bytes(saved.read_bytes())
record=dict(evidence_class='INERT',scope='Original failed source-only closure aggregate retained. Eighteen ownedpartialmetadata files archived thenrestoredexactly topre-renewal snapshots;no geometry/assets or unrelatedrecord restored.',failure="AssertionError: art/blender/city_bridge_construction.json -> art/blender/city_ground_apron_construction.json is not previous HEAD projection;bridge itself remainedddc-byteexact.",exit_code=1,backup_sha256=hashlib.sha256(backup.read_bytes()).hexdigest(),restored={k:hashlib.sha256(v[0].read_bytes()).hexdigest() for k,v in records.items()})
(out/'source_closure_failed_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print('Originalfailedaggregate/18partialrecords archived;onlyownmetadata resetforcorrectedclosure.')
