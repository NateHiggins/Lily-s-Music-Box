# Prepared functions for the existing Horizon loader;not installed/compiled yet.
static func asset_paths(source: Dictionary, include_lower: bool=true) -> Array[String]:
	var result: Array[String]=[]
	for asset: Dictionary in source.get("assets",[]):result.append(str(asset.asset))
	if include_lower:
		for asset: Dictionary in source.get("body_lod",{}).get("assets",[]):result.append(str(asset.asset))
	return result

static func _roster(entries: Array, profiles: Dictionary) -> Dictionary:
	var errors: Array[String]=[]
	var names: Dictionary={}
	var owners: Dictionary={}
	var parts_by_building: Dictionary={}
	var paths: Dictionary={}
	for entry: Dictionary in entries:
		var path:=str(entry.get("asset",""))
		if path.is_empty() or paths.has(path):errors.append("missing/duplicate asset: "+path)
		paths[path]=true
		var declared: Array=entry.get("buildings",[])
		var found: Dictionary={}
		var roster: Array=entry.get("parts",[])
		if roster.is_empty() or declared.is_empty():errors.append("empty block roster: "+path)
		var unique_declared: Dictionary={}
		for identity: String in declared:
			if unique_declared.has(identity):errors.append("duplicate building declaration: "+identity)
			unique_declared[identity]=true
		for name: String in roster:
			var pieces:=name.split("__")
			if pieces.size()!=2 or pieces[-1].is_empty():
				errors.append("invalid part ID: "+name)
				continue
			var identity: String=pieces[0]
			var block: String="_".join(identity.split("_").slice(0,4))
			if block!=str(entry.get("block","")):errors.append("split/wrong block: "+name)
			if names.has(name):errors.append("duplicate part: "+name)
			names[name]=true;found[identity]=true
			if not profiles.has(identity) or not unique_declared.has(identity):errors.append("undeclared building: "+identity)
			if owners.has(identity) and owners[identity]!=path:errors.append("building split between assets: "+identity)
			owners[identity]=path
			if not parts_by_building.has(identity):parts_by_building[identity]=[]
			parts_by_building[identity].append(name)
		if found.size()!=unique_declared.size():errors.append("missing building in block: "+path)
	return {"errors":errors,"names":names,"owners":owners,"parts_by_building":parts_by_building}

static func manifest_failures(source: Dictionary) -> Array[String]:
	var errors: Array[String]=[]
	if int(source.get("schema",0))!=2 or str(source.get("frame",""))!="ORISON_V2_BUILDING_FRAME":errors.append("invalid horizon schema/frame")
	var profiles: Dictionary={}
	for row: Dictionary in source.get("buildings",[]):
		var identity:=str(row.id)
		if profiles.has(identity):errors.append("duplicate profile: "+identity)
		profiles[identity]=row
	var base:=_roster(source.get("assets",[]),profiles)
	errors.append_array(base.errors)
	if profiles.is_empty() or base.owners.size()!=profiles.size():errors.append("base does not cover every profile")
	var replacement: Dictionary=source.get("body_lod",{})
	var lower:=_roster(replacement.get("assets",[]),profiles)
	errors.append_array(lower.errors)
	var flat: Array=replacement.get("parts",[])
	if float(replacement.get("error_m",0.))<=0. or flat.is_empty():errors.append("invalid complete-body LOD declaration")
	var flat_names: Dictionary={}
	for name: String in flat:
		if flat_names.has(name) or not lower.names.has(name):errors.append("duplicate/missing flat LOD part: "+name)
		flat_names[name]=true
	if flat_names.size()!=lower.names.size():errors.append("incomplete flat LOD roster")
	for identity: String in lower.parts_by_building:
		var high: Array=base.parts_by_building.get(identity,[]).duplicate()
		var low: Array=lower.parts_by_building[identity].duplicate()
		high.sort();low.sort()
		if high!=low:errors.append("incomplete replacement body: "+identity)
	var paths:=asset_paths(source)
	var unique_paths: Dictionary={}
	for path: String in paths:unique_paths[path]=true
	if unique_paths.size()!=paths.size():errors.append("asset reused across base/lower roles")
	return errors

static func model_failures(model: Node3D, entry: Dictionary) -> Array[String]:
	var errors: Array[String]=[]
	var seen: Dictionary={}
	var expected: Array=entry.parts
	for draw: MeshInstance3D in model.find_children("*","MeshInstance3D",true,false):
		var name:=str(draw.name)
		if seen.has(name) or not name in expected:errors.append("duplicate/unexpected imported part: "+name)
		seen[name]=true
	if seen.size()!=expected.size():errors.append("imported block roster differs: "+str(entry.asset))
	return errors
