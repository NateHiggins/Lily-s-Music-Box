"""Read-only whole-shard native roundtrips andthree assembly renders."""
from pathlib import Path
import bpy,collections,json,hashlib,math
from mathutils import Vector
root=Path('C:/ov/city');out=Path(__file__).parent/'native_review_01';out.mkdir(exist_ok=False)
fixture=json.loads((root/'game/tests/fixtures/orison_city_horizon.json').read_text());roundtrips=[];captures=[];bindings={}
def triangles(obj):
    obj.data.calc_loop_triangles()
    return collections.Counter(tuple(sorted(tuple(float(c) for c in obj.matrix_world@obj.data.vertices[i].co) for i in t.vertices)) for t in obj.data.loop_triangles)
for family in ['city_horizon_near','city_horizon_far','city_horizon_lod1']:
    native=root/f'art/blender/{family}.blend';bindings[str(native.relative_to(root))]=hashlib.sha256(native.read_bytes()).hexdigest();bpy.ops.wm.open_mainfile(filepath=str(native))
    # Evaluate while visible before source measurement;restore nothing on disk.
    for collection in bpy.data.collections:collection.hide_viewport=False
    for obj in bpy.context.scene.objects:obj.hide_viewport=False
    bpy.context.view_layer.update()
    originals={o.name:o for o in bpy.context.scene.objects if o.type=='MESH'}
    for obj in originals.values():obj.hide_render=True
    imported={}
    for asset in fixture['assets'].values():
        if Path(asset['native']).stem!=family:continue
        path=root/asset['asset'];bindings[str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest()
        before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(path));bpy.context.view_layer.update()
        found={}
        for obj in [o for o in bpy.data.objects if o not in before and o.type=='MESH']:
            name=obj.name.split('.')[0];assert name in originals and name not in imported,name
            assert triangles(obj)==triangles(originals[name]),(family,name,'native/export positions differ')
            assert len(obj.data.uv_layers)==1
            obj.data.materials.clear();obj.data.materials.append(originals[name].data.materials[0])
            imported[name]=obj;found[name]=obj
            roundtrips.append(dict(family=family,part=name,exact_world_triangles=True))
        assert set(found)=={p['name'] for p in asset['parts']}
    assert set(imported)==set(originals),(family,set(originals)-set(imported))
    for image in bpy.data.images:
        if image.source!='FILE' or image.packed_file:continue
        path=root/'game/assets/building/textures'/Path(image.filepath).name;assert path.is_file(),path
        image.filepath=str(path);image.reload();assert min(image.size)>0
    scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.cycles.use_denoising=True;scene.cycles.max_bounces=4
    scene.render.threads_mode='FIXED';scene.render.threads=2;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX';scene.render.resolution_percentage=100;scene.render.resolution_x=1400;scene.render.resolution_y=1000
    world=bpy.data.worlds.new('Shard assembly diagnostic');world.use_nodes=True;scene.world=world;world.node_tree.nodes['Background'].inputs[0].default_value=(.18,.21,.27,1);world.node_tree.nodes['Background'].inputs[1].default_value=.7
    sun=bpy.data.objects.new('Review key',bpy.data.lights.new('Review key','SUN'));scene.collection.objects.link(sun);sun.rotation_euler=Vector((-1.,.35,-.9)).to_track_quat('-Z','Y').to_euler();sun.data.energy=2.5;sun.data.angle=.15
    camera=bpy.data.objects.new('Native shard camera',bpy.data.cameras.new('Native shard camera'));scene.collection.objects.link(camera);scene.camera=camera;camera.data.type='ORTHO';camera.data.clip_start=.02;camera.data.clip_end=2000.
    corners=[obj.matrix_world@Vector(c) for obj in imported.values() for c in obj.bound_box]
    low=Vector(tuple(min(v[i] for v in corners) for i in range(3)));high=Vector(tuple(max(v[i] for v in corners) for i in range(3)));aim=(low+high)*.5
    camera.location=aim+Vector((1.,-1.,.9)).normalized()*1000;camera.rotation_euler=(aim-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.ortho_scale=max(high.x-low.x,high.y-low.y)*1.6
    target=out/(family+'_assembly.png');scene.render.filepath=str(target);bpy.ops.render.render(write_still=True)
    captures.append(dict(file=target.name,parts=len(imported),sha256=hashlib.sha256(target.read_bytes()).hexdigest(),scope='Native imported assembly andregistered source materials;no ground/Orison/sky/artistic acceptance.'))
assert len(roundtrips)==938 and len(captures)==3
(out/'review.json').write_text(json.dumps(dict(evidence_class='INERT',scope='938 exact actual world-triangle native-to-shard roundtrips;three imported assembly captures. Prior exact geometry/material native reviews remain separate. Not Godot/runtime/artistic acceptance.',roundtrips=roundtrips,captures=captures,source_sha256=bindings),indent=2),encoding='utf-8',newline='\n')
print('SHARD NATIVE REVIEW PASS938roundtrips/3assemblycaptures',flush=True)
