from pathlib import Path
import json,hashlib,subprocess,copy
root=Path('C:/ov/city');out=Path(__file__).parent
def digest(raw,p):return hashlib.sha256(raw.replace(b'\r\n',b'\n') if Path(p).suffix in ['.py','.json','.gd','.import'] else raw).hexdigest()
cache={}
def old(p):
    if p not in cache:cache[p]=subprocess.check_output(['git','show','HEAD:'+p],cwd=root)
    return cache[p]
known=set(json.loads((out/'additional_default_projections_02.json').read_text())['changes']);changed={};skipped=[];history={}
for p in known:
    before=json.loads(old(p));after=json.loads((root/p).read_text());before.pop('source_bindings');after.pop('source_bindings');assert before==after,p
for step in range(20):
    updates=0
    for folder in ['art/blender','game/tests/fixtures']:
        for path in (root/folder).glob('*.json'):
            p=path.relative_to(root).as_posix()
            try:data=json.loads(path.read_text(encoding='utf-8'))
            except (ValueError,UnicodeError):continue
            if not isinstance(data,dict) or data.get('evidence_kind')=='runtime_contract':continue
            bindings=data.get('source_bindings',{});targets=[]
            for dep,expected in bindings.items():
                if dep not in known:continue
                actual=digest((root/dep).read_bytes(),dep)
                if actual==expected:continue
                allowed={digest(old(dep),dep),*history.get(dep,[])}
                if expected not in allowed:
                    item=dict(path=p,dependency=dep,expected=expected,head=digest(old(dep),dep))
                    if item not in skipped:skipped.append(item)
                    continue
                targets.append((dep,actual))
            if not targets:continue
            original=path.read_bytes();old_data=copy.deepcopy(data)
            if p not in changed:
                assert json.loads(old(p))==data,p
                (out/('before_transitive_'+p.replace('/','_'))).write_bytes(original);changed[p]=[]
            for dep,actual in targets:bindings[dep]=actual
            check=copy.deepcopy(data);check['source_bindings']=old_data['source_bindings'];assert check==old_data
            for dep,expected in bindings.items():
                if dep in known:continue
                assert digest((root/dep).read_bytes(),dep)==expected,(p,dep)
            for dep,expected in data.get('outputs',{}).items():assert digest((root/dep).read_bytes(),dep)==expected,(p,dep)
            history.setdefault(p,set()).add(digest(original,p));path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n');history[p].add(digest(path.read_bytes(),p))
            changed[p].extend(dict(dependency=dep,new=actual,all_nonbinding_fields_and_other_inputs_outputs_exact=True) for dep,actual in targets);known.add(p);updates+=1
    if not updates:break
else:raise AssertionError('metadata cycle didnot settle')
assert set(changed)=={'art/blender/nook_readable_books_construction.json'},changed
record=dict(evidence_class='INERT',scope='Close all declared construction/fixture source_bindings edges transitively fromtwoadditionalunchanged-helperprojections. OnlyNook→Librarymetadata digestchanges;actualbuilderconsumesunchangedLibraryparts/closed-stocks,notitssource_bindings. AllotherNookfields/inputs/outputsexact. Nogeometry/text/state/runtimeproof repinning. Original119gateboard02regression retained.',changes=changed,skipped_original_debt=skipped)
(out/'transitive_metadata_projections_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
subprocess.run(['git','add','--',*changed],cwd=root,check=True)
print('Complete declaredmetadataDAG settled;',len(changed),'digest-onlyrecord renewed;',len(skipped),'originaldebt edgesleftunchanged.')
