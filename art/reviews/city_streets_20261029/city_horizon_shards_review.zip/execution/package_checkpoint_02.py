from pathlib import Path
import json,hashlib,zipfile,subprocess
root=Path('C:/ov/city');out=Path(__file__).parent
def sha(raw):return hashlib.sha256(raw).hexdigest()
binding=json.loads((out/'runtime_bindings_before_retirement_01.json').read_text());retirement=json.loads((out/'retirement_03.json').read_text())
assert len(retirement['removed_assets'])==6 and len(retirement['render_inspection']['images'])==12
stored={};aliases={};seen={}
for p in sorted(out.rglob('*')):
    if not p.is_file() or '__pycache__' in p.parts:continue
    if p.suffix not in ['.py','.json','.gd','.tscn','.log','.stderr','.png','.txt'] and p.name!='failed_source_closure_01.zip':continue
    member='execution/'+p.relative_to(out).as_posix();raw=p.read_bytes()
    if p.suffix=='.png' and sha(raw) in seen:aliases[member]=dict(retained_member=seen[sha(raw)],sha256=sha(raw))
    else:
        stored[member]=raw
        if p.suffix=='.png':seen[sha(raw)]=member
for relative,expected in binding['runtime_sources'].items():
    p=root/relative
    if relative.startswith('game/tmp/city_shards_01/'):
        p=out/'retired_runtime_sources_01'/relative.removeprefix('game/tmp/city_shards_01/')
    recovery=binding['retired_assets'].get(relative,{}).get('git_recovery_commit','HEAD')
    raw=p.read_bytes() if p.exists() else subprocess.check_output(['git','show',recovery+':'+relative],cwd=root)
    actual=sha(raw.replace(b'\r\n',b'\n') if expected['lf_normalized'] else raw)
    assert actual==expected['test_sha256'],relative
    if p.suffix not in ['.glb','.png','.webp']:stored['final/'+relative]=raw
fixture=json.loads((root/'game/tests/fixtures/orison_city_horizon.json').read_text())
asset_paths=sorted({a['asset'] for a in fixture['assets'].values()}|{a['native'] for a in fixture['assets'].values()}|{'art/blender/city_horizon_construction.json','game/data/orison_v2/exterior/city_horizon.json','game/tests/fixtures/orison_city_horizon.json'})
assets={p:dict(bytes=(root/p).stat().st_size,sha256=sha((root/p).read_bytes())) for p in asset_paths};assert len(assets)==40
source_paths=['art/blender/scripts/city_horizon_assets.py','art/blender/scripts/build_city_horizon.py','art/blender/scripts/fabrication_native_batch.py','art/blender/scripts/review_city_streets.py','art/tools/fix_v2_mesh_imports.py','tools/inventory_v2_fabrication.py','tools/tests/test_city_horizon_shards.py','art/blender/v2_fabrication_inventory.json']
source_paths+=list(json.loads((out/'source_closure_02.json').read_text())['original_sha256'])
source_paths+=list(json.loads((out/'additional_default_projections_02.json').read_text())['changes'])
source_paths+=list(json.loads((out/'transitive_metadata_projections_01.json').read_text())['changes'])
for p in set(source_paths):stored['final/'+p]=(root/p).read_bytes()
dest=root/'art/reviews/city_streets_20261029/city_horizon_shards_review.zip'
first=json.loads((out/'archive_record_01.json').read_text());assert sha(dest.read_bytes())==first['sha256']
retained=(out/'initial_package_01.zip').resolve();assert not retained.exists() and dest.resolve().is_relative_to(root/'art/reviews/city_streets_20261029')
dest.rename(retained)
prior={}
for p in sorted(dest.parent.glob('*.zip')):
    relative=p.relative_to(root).as_posix();raw=p.read_bytes();assert raw==subprocess.check_output(['git','show','HEAD:'+relative],cwd=root),relative;prior[p.name]=sha(raw)
scope='Transport-only34-block export/loader checkpoint. All938nativeattributes/rootframes+938nativeworldtriangle roundtrips exact;3nativeassemblyviews inspected. Original10420/0runtime data/corona parity retainedwith6rejectedcameraimages;corrected1545/0rootviewportcontract independentlyqualifies6body/6hiddenviews.172originalruntimebindings,40assets,allpriorarchivesexact. Sourceonly13requiredfixturepreflightsPASS;widerbarcatalog/bridgeaprondebtremainred. First119gateboard2newmetadataregressions andsecondboard1transitiveNookregression preserved;unchangedmaterial/partition projections andunchangedLibraryclosed-stockprojection fixonly3dependencydigests.Finalboardincluded. Originalfailedsourceclosure,compiler,staging andcleanupguards retained. Index/archiveINERT;notplayed/composedcity,weather,matchedperformancegain orartisticacceptance.'
index=dict(evidence_class='INERT',scope=scope,sourcebase='ddcbe9033630d29cdf1a1c69ef05faaaf89684a3',runtime_sources=binding['runtime_sources'],retired_control_assets=binding['retired_assets'],assets=assets,prior_unchanged_archives=prior,byte_exact_reused_image_aliases=aliases,members={k:dict(bytes=len(v),sha256=sha(v)) for k,v in stored.items()})
stored['archive_index.json']=json.dumps(index,indent=2).encode()
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
    for k,v in stored.items():z.writestr(k,v,compress_type=zipfile.ZIP_STORED if k.endswith('.png') else zipfile.ZIP_DEFLATED,compresslevel=1)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None and set(z.namelist())==set(stored)
    for k,v in stored.items():assert z.read(k)==v,k
    for name,a in aliases.items():assert sha(z.read(a['retained_member']))==a['sha256'],name
assert dest.stat().st_size<100*1024*1024
record=dict(evidence_class='INERT',scope=scope,archive=dest.relative_to(root).as_posix(),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),member_count=len(stored),runtime_source_count=len(binding['runtime_sources']),asset_bindings=assets,byte_exact_reused_image_aliases=aliases,runtime_contracts=binding['receipts'])
p=root/'art/reviews/city_streets_20261029/manifest.json';manifest=json.loads(p.read_text());assert manifest['horizon_shards_archive']['sha256']==first['sha256'];manifest['horizon_shards_archive']=record;p.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'archive_record_02.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print('ARCHIVE',len(stored),'members',dest.stat().st_size,'bytes',sha(dest.read_bytes()),'aliases',len(aliases),'prior',len(prior))
