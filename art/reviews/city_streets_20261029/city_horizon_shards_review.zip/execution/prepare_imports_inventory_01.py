from pathlib import Path
import json,hashlib,re,sys,copy
root=Path('C:/ov/city');out=Path(__file__).parent
fixture=json.loads((root/'game/tests/fixtures/orison_city_horizon.json').read_text());created={}
for asset in fixture['assets'].values():
    path=root/asset['asset'];target=Path(str(path)+'.import');assert not target.exists(),target
    family=Path(asset['native']).stem
    original=root/'game/assets/props'/(family+'.glb.import');text=original.read_text(encoding='utf-8')
    old_resource='res://assets/props/'+family+'.glb';new_resource='res://'+path.relative_to(root/'game').as_posix()
    old_hash=hashlib.md5(old_resource.encode()).hexdigest();new_hash=hashlib.md5(new_resource.encode()).hexdigest()
    text=re.sub(r'^uid=.*\n','',text,flags=re.M).replace(family+'.glb',path.name).replace(old_hash,new_hash)
    assert old_resource not in text and new_resource in text and 'uid=' not in text
    assert 'meshes/force_disable_compression=true' in text
    target.write_text(text,encoding='utf-8',newline='\n');created[target.relative_to(root).as_posix()]=hashlib.sha256(target.read_bytes()).hexdigest()
assert len(created)==34
sys.path.insert(0,str(root/'tools'));from inventory_v2_fabrication import index
p=root/'art/blender/v2_fabrication_inventory.json';original=p.read_bytes();data=json.loads(original);prior=copy.deepcopy(data)
key='game/scripts/building/orison_v2_city_horizon.gd';new=index(root)['building_asset_references'][key]
assert len(new)==34
data['building_asset_references'][key]=new
control=copy.deepcopy(data);control['building_asset_references'][key]=prior['building_asset_references'][key];assert control==prior
(out/'inventory_ddc_original.json').write_bytes(original)
p.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
review=json.loads((out/'native_review_01/review.json').read_text())
inspection=dict(evidence_class='INERT',scope='Allthree actual imported native assembly views inspected after938 exact native world-triangle roundtrips. Near/far/lower sourceassembly only;no ground/Orison/sky or artistic acceptance. No new geometry;99generic profiles remain.',images={c['file']:c['sha256'] for c in review['captures']},findings=['Near ring retainsindividualcompletedarchitecture andgenericplaceholders inexactsourcepositions.','Far/streetend assets preservehorizonring andgaps;emptycenterisnotaground/accessclaim.','Sixlowergroups retainall22completebodybuildings,actualsetbacks/courts/rooflines,withnocollapsedrootframe.'])
(out/'native_inspection_01.json').write_text(json.dumps(inspection,indent=2),encoding='utf-8',newline='\n')
(out/'import_inventory_preparation_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='34portable import policies retain documented native chart precision;freshUID omitted forengine allocation. Inventory updates onlyHorizonassetentry fromvalidatedmanifest;allotherfields exact.',sidecars=created,inventory_horizon_paths=new),indent=2),encoding='utf-8',newline='\n')
print('34source import policies prepared;onlyHorizoninventoryentrychanged;3nativeimagesinspected.')
