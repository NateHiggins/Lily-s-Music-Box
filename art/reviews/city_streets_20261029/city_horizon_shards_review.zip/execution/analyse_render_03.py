from pathlib import Path
import json,hashlib,math,statistics
from PIL import Image,ImageDraw
out=Path(__file__).parent;data=json.loads((out/'render_03/shards_render.runtime.json').read_text())
assert data['checks']==1545 and not data['failures'] and data['execution']['completed']
def summary(rows):
    result={}
    for key in ['wall_ms','cpu_ms','gpu_ms']:
        values=sorted(float(x[key]) for x in rows)
        result[key]={'median':statistics.median(values),'p95':values[math.ceil(len(values)*.95)-1],'p99':values[math.ceil(len(values)*.99)-1],'max':values[-1]}
    return dict(frames=len(rows),metrics=result)
record=dict(evidence_class='INERT',scope='Analysis ofexactisolatedrootviewportreceipt;notamatchedperformanceimprovementorwholecitybudget. Startup/captureIOnotinwarmedframes,transitionspikesretained. Earlierdataparipreparationseparate10.039458s.',owners={})
for label in ['legacy','shards']:
    rows=[x for x in data['observations'] if x['owner']==label]
    record['owners'][label]=dict(warmed=summary([s for r in rows for s in r['samples']]),transitions=summary([s for r in rows for s in r['warmup']]),profiles=[{k:r[k] for k in ['profile','coverage','counters']} for r in rows])
paths=sorted((out/'render_03').glob('*.png'));assert len(paths)==12
sheet=Image.new('RGB',(1600,6*360),'#282c30');draw=ImageDraw.Draw(sheet)
for i,p in enumerate(paths):
    with Image.open(p) as im:
        copy=im.convert('RGB');copy.thumbnail((800,335));x=i%2*800;y=i//2*360;sheet.paste(copy,(x,y));draw.text((x+4,y+337),p.stem,fill='white')
sheet.save(out/'render_contact_03.png')
(out/'render_analysis_03.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print(json.dumps({k:{t:v[t] for t in ['warmed','transitions']} for k,v in record['owners'].items()}))
