from pathlib import Path
import json,hashlib,subprocess,re,zipfile
root=Path('C:/ov/city').resolve();out=Path(__file__).parent
processes=subprocess.check_output(['pwsh','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'godot|blender' } | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress"],text=True).strip()
live=json.loads(processes) if processes else []
if isinstance(live,dict):live=[live]
assert not any('c:/ov/city/' in str(p.get('CommandLine','')).replace('\\','/').lower() for p in live),live
binding=json.loads((out/'runtime_bindings_before_retirement_01.json').read_text())
for name,receipt in binding['receipts'].items():
    d=json.loads((out/receipt['path']).read_text());assert not d['failures'] and d['execution']['completed']
render=json.loads((out/'render_03/shards_render.runtime.json').read_text());assert render['checks']==1545
for row in render['observations']:assert row['coverage']['fraction']>.02
# Restore only tracked import files whose sole change is CRLF/LF.
changed=subprocess.run(['git','diff','--name-only','-z'],cwd=root,capture_output=True,check=True).stdout.decode().split('\0')
imports=[p for p in changed if p.endswith('.import')];old={}
if imports:
    requests=''.join('HEAD:'+p+'\n' for p in imports)
    raw=subprocess.run(['git','cat-file','--batch'],input=requests.encode(),cwd=root,capture_output=True,check=True).stdout;offset=0
    for p in imports:
        end=raw.index(b'\n',offset);header=raw[offset:end].split();assert header[1]==b'blob';size=int(header[2]);offset=end+1;content=raw[offset:offset+size];offset+=size+1
        actual=(root/p).read_bytes();assert actual.replace(b'\r\n',b'\n')==content.replace(b'\r\n',b'\n'),p
        old[p]=content
noise_backup=out/'import_lineend_backup_01.zip';assert not noise_backup.exists()
with zipfile.ZipFile(noise_backup,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in old:z.writestr(p,(root/p).read_bytes())
with zipfile.ZipFile(noise_backup) as z:assert z.testzip() is None
for p,content in old.items():
    path=(root/p).resolve();assert path.is_relative_to(root/'game/assets') and path.suffix=='.import';path.write_bytes(content)
# Cache-only UIDs must match the import warning inventory exactly.
warned={'game/'+p+'.uid' for p in re.findall(r'Missing \.uid file for path "res://([^"]+)"',(out/'import_01.log.stderr').read_text())}
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root).decode().split('\0')
uids={p for p in untracked if p.endswith('.uid')};assert len(uids)==664 and uids==warned,(len(uids),len(warned),uids-warned,warned-uids)
uid_backup=out/'import_uid_backup_01.zip';assert not uid_backup.exists();uid_hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(uids)}
with zipfile.ZipFile(uid_backup,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in uid_hashes:z.writestr(p,(root/p).read_bytes())
with zipfile.ZipFile(uid_backup) as z:
    assert z.testzip() is None
    for p,h in uid_hashes.items():assert hashlib.sha256(z.read(p)).hexdigest()==h
for p,h in uid_hashes.items():
    path=(root/p).resolve();assert path.is_relative_to(root/'game') and path.suffix=='.uid';assert hashlib.sha256(path.read_bytes()).hexdigest()==h;path.unlink()
# Keep executed test sources outside res:// before retiring their old inputs.
source=(root/'game/tmp/city_shards_01').resolve();destination=(out/'retired_runtime_sources_01').resolve()
assert source.is_relative_to(root/'game/tmp') and source.is_dir() and not destination.exists()
source.rename(destination)
removed={}
for p,record in binding['retired_assets'].items():
    path=(root/p).resolve();assert path.parent==root/'game/assets/props' and path.name in [f'city_horizon_{f}{s}' for f in ['near','far','lod1'] for s in ['.glb','.glb.import']]
    assert hashlib.sha256(path.read_bytes()).hexdigest()==record['raw_sha256'],p
    removed[p]=record;path.unlink()
inspection={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((out/'render_03').glob('*.png'))};assert len(inspection)==12
record=dict(evidence_class='INERT',scope='Afterbothqualifiedtests/native review,removeonly3obsolete GLBs/importpairs;executedtemporarylegacy/candidatefixturesretiredoutsideresbeforeassetremoval. Nooriginalruntimeproofrepinned. Native3sources and34publishedassetsretained. Onlyimport-warning664untrackedUIDs removedafterverifiedbackup;trackedUIDs/canonicaluntouched.',removed_assets=removed,retired_sources=str(destination),restored_lineend_imports=len(old),removed_uids=uid_hashes,render_inspection=dict(images=inspection,findings=['Allsixproperrootviewportbodyframesandall sixactualhiddencontrolsinspected.','Native3440x1440viewportwithactualsubject~10.079%foreground,center(.5,.5056);completefivebodyassemblyresolvable.','Near/lower/returnpreservebuildingproportions/silhouettes;sourcefrontentryreviewsremainseparate.','Originaltiny/skewedSubviewportcapturesareretainedandnotvisualacceptance;rootcauseunknown. Noartistic/composedworldacceptance.']))
(out/'retirement_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print('Retired6obsoleteassets;',len(old),'lineendimports restored;',len(uids),'cacheUIDs backedup/removed;12final framesinspected.')
