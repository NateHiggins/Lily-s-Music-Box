"""Renew construction metadata only with explicit unchanged-consumption proofs."""
from pathlib import Path
import json,hashlib,subprocess,copy,sys
root=Path('C:/ov/city');out=Path(__file__).parent
sys.path.insert(0,str(root/'tools'));from preflight_spatial_test_bindings import check_fixture,TEXT_SUFFIXES
def sha(raw,p):return hashlib.sha256(raw.replace(b'\r\n',b'\n') if Path(p).suffix in TEXT_SUFFIXES else raw).hexdigest()
cache={}
def head(p):
    if p not in cache:cache[p]=subprocess.check_output(['git','show','HEAD:'+p],cwd=root)
    return cache[p]
proof=json.loads((out/'export_default_projection_01.json').read_text());assert proof['default_true_module_ast_exact']
callers=json.loads((out/'export_callers_01.json').read_text());assert len(callers['callers'])==40
preservation=json.loads((out/'preservation_01.json').read_text());assert not preservation['failures']
helper='art/blender/scripts/fabrication_native_batch.py';current_helper=sha((root/helper).read_bytes(),helper)
stem_pairs=[('orison_bar_receiving','bar_receiving_construction'),('orison_city_elevations','city_elevations_construction'),('orison_city_elevations_lod1','city_elevations_lod1_construction'),('orison_city_frontage','city_frontage_construction'),('orison_city_ground_apron','city_ground_apron_construction'),('orison_city_streets','city_streets_construction'),('orison_city_transport','city_transport_construction'),('orison_street_paving_details','street_paving_details_construction')]
initial=[p for a,b in stem_pairs for p in ['game/tests/fixtures/'+a+'.json','art/blender/'+b+'.json']]
horizon=['art/blender/city_horizon_construction.json','game/tests/fixtures/orison_city_horizon.json']
originals={};changes={};known=set()
def edit(p,data,reason):
    path=root/p
    if p not in originals:originals[p]=path.read_bytes();(out/('before_renewal_'+p.replace('/','_'))).write_bytes(originals[p])
    path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n');known.add(p);changes.setdefault(p,[]).append(reason)
for p in initial:
    data=json.loads((root/p).read_text());assert data['source_bindings'][helper]==proof['original_sha256'],p
    assert json.loads(head(p))==data,p
    data['source_bindings'][helper]=current_helper
    edit(p,data,'DefaultTrue helper module AST andallretained callerAST exact;only new shardhelper optsFalse. No other field change.')
for p in horizon:
    data=json.loads((root/p).read_text());old=json.loads(head(p))
    assert {k:v for k,v in data.items() if k not in ['assets','source_bindings','source_ground_reconciliation']}=={k:v for k,v in old.items() if k not in ['assets','source_bindings','source_ground_reconciliation']},p
    loader='game/scripts/building/orison_v2_city_horizon.gd';executed=json.loads((out/'native_build_01.json').read_text())['source_sha256'][loader]
    assert data['source_bindings'][loader]==executed
    data['source_bindings'][loader]=sha((root/loader).read_bytes(),loader)
    edit(p,data,'Fresh nativegeneration usescanonicalground. Allspatial fields exact/938native arraysrootframes exact;assets graph becomes34blocks. Loader adds onlyregistered-path guard aftergeneration;nativebuilder hashes butdoesnotexecuteGDScript. Originalcanonical source_ground_reconciliation remains inHEAD/history;freshgeneration replaces its metadata stage.')
# Hash-only construction metadata forms a DAG. Update its transitive consumers,
# accepting only the exact previous HEAD dependency digest,never existing debt.
all_records=[p.relative_to(root).as_posix() for folder in ['game/tests/fixtures','art/blender'] for p in (root/folder).glob('*.json')]
for iteration in range(20):
    progressed=False
    for p in all_records:
        try:data=json.loads((root/p).read_text(encoding='utf-8'))
        except (ValueError,UnicodeError):continue
        bindings=data.get('source_bindings',{}) if isinstance(data,dict) else {}
        updates=[]
        for dep,expected in bindings.items():
            if dep not in known:continue
            actual=sha((root/dep).read_bytes(),dep)
            if actual==expected:continue
            assert expected==sha(head(dep),dep) or any(expected==x['after'] for x in changes.get('_binding_history',[] ) if x['path']==dep),(p,dep,'notpreviousprojection')
            updates.append((dep,actual))
        if updates:
            before=sha((root/p).read_bytes(),p)
            for dep,actual in updates:bindings[dep]=actual
            edit(p,data,'Onlydependencydigestsofprovedunchanged spatial/default projections renewed: '+','.join(x[0] for x in updates))
            after=sha((root/p).read_bytes(),p);changes.setdefault('_binding_history',[]).append(dict(path=p,before=before,after=after));progressed=True
    if not progressed:break
else:raise AssertionError('sourcebindingcycle/notconverged')
affected={}
for p in (root/'game/tests/fixtures').glob('*.json'):
    try:data=json.loads(p.read_text())
    except (ValueError,UnicodeError):continue
    bindings=data.get('source_bindings',{}) if isinstance(data,dict) else {}
    if p.relative_to(root).as_posix() in known or set(bindings)&known or helper in bindings:
        affected[p.relative_to(root).as_posix()]=check_fixture(p,root)
bar='game/tests/fixtures/orison_bar_receiving.json'
assert affected[bar]==['stale fixture dependency: game/data/runtime_material_sets.json']
assert not any(v for k,v in affected.items() if k!=bar),affected
for p,raw in originals.items():
    if p in horizon:continue
    before=json.loads(raw);after=json.loads((root/p).read_text());before.pop('source_bindings',None);after.pop('source_bindings',None);assert before==after,p
record=dict(evidence_class='INERT',scope='Construction-source metadata closure only,not repinned runtime proof. DefaultTrue helper/callers exact,allnonbinding fields/nativeassets preserved;Horizon spatialprojection/938partrootattributes exact. Originalbarcatalogfailure explicitlyretained.',sourcebase=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),changes=changes,preflight=affected,original_sha256={p:sha(v,p) for p,v in originals.items()})
(out/'source_closure_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print('Renewed',len(originals),'construction records;',len(affected),'fixtureclosure;',sum(not v for v in affected.values()),'PASS;originalbarcatalogfailure remains.')
