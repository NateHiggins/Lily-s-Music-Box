"""Run only after developer timing release. Assets stay in original external root."""
import pathlib,json,hashlib,zipfile
root=pathlib.Path(__file__).resolve().parent.parent
target=pathlib.Path('C:/ov/city/art/reviews/city_streets_20261029/city_building_packets_native_20261103.zip')
paths=set(root.glob('*.json'))|set(root.glob('*.md'))|{root/'integration.patch'}
paths|=set((root/'review_sheets').glob('*'))
for packet in root.glob('horizon_*'):
 if not packet.is_dir():continue
 paths|=set(packet.glob('*.json'))|set((packet/'review').glob('*.json'))
for path in (root/'attempts').iterdir():
 if path.is_file() and path.suffix in ['.json','.py','.log','.txt','.md']:paths.add(path)
selected=[p for p in sorted(paths) if p.is_file()]
contents=[dict(file=p.relative_to(root).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in selected]
manifest=dict(evidence_class='INERT',scope='Native evidence and contact sheets. Editable blend/GLB assets remain external at original delivery root,with92hashes in NATIVE_SUMMARY.json. No runtime/art acceptance.',external_root=str(root),entries=contents)
target.parent.mkdir(parents=True,exist_ok=True)
assert not target.exists(),'Never overwrite published evidence'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for p in selected:archive.write(p,p.relative_to(root).as_posix())
 archive.writestr('ARCHIVE_CONTENTS.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(target) as archive:
 assert archive.testzip() is None
 for item in contents:assert hashlib.sha256(archive.read(item['file'])).hexdigest()==item['sha256']
result=dict(file=str(target),sha256=hashlib.sha256(target.read_bytes()).hexdigest(),bytes=target.stat().st_size,entries=len(contents)+1,scope='Independently reopened CRC and every entry SHA verified;no duplicated blend/GLB/catalogue maps')
(root/'EVIDENCE_ARCHIVE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
