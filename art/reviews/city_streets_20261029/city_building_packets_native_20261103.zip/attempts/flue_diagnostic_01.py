import json,sys
sys.path.insert(0,"C:/ov/city/art/blender/scripts")
from city_packet_architecture import PacketBuildings
from mathutils import Vector
from mathutils.bvhtree import BVHTree
def diagnostic(self,result):
 tree=BVHTree.FromPolygons(self.roof_vertices,self.roof_faces)
 lo=[min(v[i] for v in self.roof_vertices) for i in range(3)];hi=[max(v[i] for v in self.roof_vertices) for i in range(3)]
 print("ROOF",self.study["style"],lo,hi,"HEIGHT",self.builder.levels[-1],flush=True)
 for u,v in [(.15,.85),(.85,.15),(.5,.15),(.5,.85),(.5,.5),(.3,.3),(.7,.7)]:
  x=lo[0]+(hi[0]-lo[0])*u;y=lo[1]+(hi[1]-lo[1])*v
  for dx,dy in [(-.23,-.23),(.23,-.23),(.23,.23),(-.23,.23)]:
   hit,n,i,d=tree.ray_cast(Vector((x+dx,y+dy,hi[2]+3)),Vector((0,0,-1)),30)
   print(u,v,dx,dy,hit,n,flush=True)
PacketBuildings.flues=diagnostic
rows=json.load(open("C:/ov/asset-prototypes/city-building-packets-20261103/proposed_source_plan.json"))["buildings"]
r=next(r for r in rows if r["id"]=="HORIZON_NEAR_0_3_P0R0");r.update(grade_datum_m=0.,grade_low_m=0.)
PacketBuildings(r,lambda *a:None,[],False).build()
