import pathlib,json,math,bisect,hashlib
root=pathlib.Path(__file__).resolve().parent.parent
repo=pathlib.Path("C:/ov/city");identity="HORIZON_NEAR_3_0_P2"
old=json.loads((repo/"game/tests/fixtures/orison_city_horizon.json").read_bytes())
oldrow=next(r for r in old["buildings"] if r["id"]==identity)
oldwindows=[w for w in old["window_rows"] if w["building"]==identity]
manifestpath=root/"horizon_near_3_0/manifest.json";manifest=json.loads(manifestpath.read_bytes())
record=next(r for r in manifest["records"] if r["level"]=="near");body=next(r for r in record["bodies"] if r["id"]==identity)
row=next(r for r in json.loads((root/"proposed_source_plan.json").read_bytes())["buildings"] if r["id"]==identity)
study=row["architecture"];local=study["fabrication_profile"]["architecture"];frame=study["native_frame"]
points=[(x,-z) for x,z in local["outline_m"]];levels=[0.]
for h in local["floor_heights_m"]:levels.append(levels[-1]+h)
def inverse(p,normal=False):
 q=list(p)
 if not normal:q=[p[0]-frame[0][3],p[1]-frame[1][3],p[2]-body["grade_datum_m"]]
 return [sum(frame[j][i]*q[j] for j in range(3)) for i in range(3)]
new=[]
for witness in body["proof"]["windows"]:
 p=inverse(witness["point"]);n=inverse(witness["normal"],True);matched=[]
 for side,(a,b) in enumerate(zip(points,points[1:]+points[:1])):
  length=math.dist(a,b);u=((b[0]-a[0])/length,(b[1]-a[1])/length);N=(-u[1],u[0]);delta=(p[0]-a[0],p[1]-a[1])
  along=sum(x*y for x,y in zip(delta,u));gap=abs(sum(x*y for x,y in zip(delta,N)))
  if sum(x*y for x,y in zip(n,N))>.99999 and gap<.0001 and -.0001<=along<=length+.0001:matched.append((side,along,length))
 assert len(matched)==1,(witness,matched)
 side,along,length=matched[0];bay=min(local["side_bays"][side]-1,int(along/length*local["side_bays"][side]));floor=bisect.bisect_right(levels,p[2])-1
 new.append(dict(semantic_id=f"hampton/F{floor:02d}/S{side:02d}/B{bay:02d}",floor=floor,outline_side=side,bay=bay,witness=witness,disposition="new source-fitted aperture;retained and hit in both near/lower bodies"))
oldroster=[];a,b,c,d=oldrow["rect"];depth=oldrow["reveal_m"]
sides=[((c,-d),(-1,0),c-a),((c,-b-depth),(0,-1),d-b-2*depth),((a,-b),(1,0),c-a),((a,-d+depth),(0,1),d-b-2*depth)]
for w in oldwindows:
 side=w["side"];O,U,L=sides[side];along=sum((w["point"][i]-O[i])*U[i] for i in range(2));bays=round(L/oldrow["bay_pitch_m"]);bay=int(along/L*bays);floor=int((w["point"][2]-oldrow["grade_datum_m"])/oldrow["storey_m"])
 oldroster.append(dict(semantic_id=f"generic/F{floor:02d}/S{side:02d}/B{bay:02d}",floor=floor,side=side,bay=bay,witness=w,disposition="retired original generic-body aperture;not a failed or waived installed ray"))
assert len(new)==184 and len(oldroster)==192
assert len({x["semantic_id"] for x in new})==184 and len({x["semantic_id"] for x in oldroster})==192
lower=next(r for r in manifest["records"] if r["level"]=="lower")["bodies"][0]["proof"]["windows"]
assert lower==body["proof"]["windows"]
neighbor=[w for w in old["window_rows"] if w["building"]=="HORIZON_NEAR_3_0_P0R2"];assert len(neighbor)==46
result=dict(evidence_class="INERT",scope="Per-pane native replacement disposition,not installed-runtime proof. All192 currently installed assertions/rays remain unchanged until reviewed intake;preserve separate46 neighbor controls.",baseline_fixture_sha256=hashlib.sha256((repo/"game/tests/fixtures/orison_city_horizon.json").read_bytes()).hexdigest(),new_native_manifest_sha256=hashlib.sha256(manifestpath.read_bytes()).hexdigest(),old_roster=oldroster,new_roster=new,near_lower_witnesses_exact=True,neighbor_46_sha256=hashlib.sha256(json.dumps(neighbor,sort_keys=True,separators=(",",":")).encode()).hexdigest(),disposition="Entire P2 generic body is replaced:all192old witness identities retired,all184new witness identities authored. This is not eight missing checks;source outline,basement/storey schedule,sash and recess change. No one-to-one geometric aperture mapping is claimed.")
(root/"P2_PANE_DISPOSITION.json").write_text(json.dumps(result,indent=2)+"\n")
print("P2 disposition",len(oldroster),"retired",len(new),"new;neighbor46preserved")
