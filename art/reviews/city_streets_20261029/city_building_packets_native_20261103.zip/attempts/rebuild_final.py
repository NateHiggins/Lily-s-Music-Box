import json,pathlib,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parent.parent
blocks=json.loads((root/"packet_index.json").read_bytes())["blocks"]
for block in blocks:
 while (root/"DEVELOPER_HOLD").exists():time.sleep(1)
 p=subprocess.run([sys.executable,str(root/"attempts/run_native.py"),block])
 if p.returncode:sys.exit(p.returncode)
print("FINAL NATIVE PACKETS BUILT",flush=True)
