import subprocess,time,json,pathlib,shutil,sys
root=pathlib.Path(__file__).resolve().parent.parent
block=sys.argv[1];review="--review" in sys.argv
stem=block.lower()+("_review" if review else "_build")
n=1
while (root/"attempts"/(stem+f"_{n:02d}.execution.json")).exists():n+=1
stem+=f"_{n:02d}"
args=["C:/Program Files/Blender Foundation/Blender 5.2/blender.exe","--background","--threads","1","--python-exit-code","1","--python","art/blender/scripts/build_city_building_packets.py","--","--out",str(root),"--block",block]+(["--review"] if review else [])
for src in ["build_city_building_packets.py","city_packet_architecture.py"]:shutil.copy2(pathlib.Path("art/blender/scripts")/src,root/"attempts"/(stem+"_"+src))
if review:
 args[args.index("--python")+1]=str(root/"attempts/native_review_bootstrap.py")
t=time.perf_counter()
with open(root/"attempts"/(stem+".stdout.log"),"wb") as stdout,open(root/"attempts"/(stem+".stderr.log"),"wb") as stderr:p=subprocess.run(args,stdout=stdout,stderr=stderr)
receipt={"evidence_class":"INERT","command":args,"exit_code":p.returncode,"elapsed_s":time.perf_counter()-t}
(root/"attempts"/(stem+".execution.json")).write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True)
if p.returncode:
 print((root/"attempts"/(stem+".stdout.log")).read_text(errors="replace")[-2000:]);print((root/"attempts"/(stem+".stderr.log")).read_text(errors="replace")[-2000:])
sys.exit(p.returncode)
