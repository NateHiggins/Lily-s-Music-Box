import pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent.parent
for i in range(4):
 p=subprocess.run([sys.executable,str(root/"attempts/run_native.py"),f"HORIZON_STREET_END_{i}"])
 if p.returncode:sys.exit(p.returncode)
