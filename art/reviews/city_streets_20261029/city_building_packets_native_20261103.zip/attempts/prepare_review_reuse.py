import pathlib,json,struct,hashlib,numpy as np,sys
root=pathlib.Path(__file__).resolve().parent.parent
block,changed,old_path=sys.argv[1:];oldroot=root/old_path;newroot=root/block.lower();old=json.load(open(oldroot/"manifest.json"));new=json.load(open(newroot/"manifest.json"))
def meshes(path):
 raw=path.read_bytes();ln=struct.unpack_from("<I",raw,12)[0];doc=json.loads(raw[20:20+ln]);binary=raw[20+ln+8:];result={}
 def array(i):
  a=doc["accessors"][i];v=doc["bufferViews"][a["bufferView"]];dtype=np.dtype({5121:"u1",5123:"<u2",5125:"<u4",5126:"<f4"}[a["componentType"]]);width={"SCALAR":1,"VEC2":2,"VEC3":3,"VEC4":4}[a["type"]]
  return np.ndarray((a["count"],width),dtype=dtype,buffer=binary,offset=v.get("byteOffset",0)+a.get("byteOffset",0),strides=(v.get("byteStride",width*dtype.itemsize),dtype.itemsize)).copy()
 for m in doc["meshes"]:result[m["name"]]=[{**{k:array(v) for k,v in p["attributes"].items()},"indices":array(p["indices"])} for p in m["primitives"]]
 return result,{n["name"]:{k:v for k,v in n.items() if k!="mesh"} for n in doc["nodes"] if "mesh" in n}
comparisons=[];annex=[]
for level in ["near","lower"]:
 o=next(x for x in old["records"] if x["level"]==level);n=next(x for x in new["records"] if x["level"]==level);O,On=meshes(oldroot/o["asset"]);N,Nn=meshes(newroot/n["asset"])
 for name in O:
  if name.startswith(changed+"__"):continue
  assert name in N and On[name]==Nn[name] and len(O[name])==len(N[name])
  for a,b in zip(O[name],N[name]):assert a.keys()==b.keys() and all(np.array_equal(a[k],b[k]) for k in a),name
  comparisons.append({"level":level,"part":name,"all_exported_attributes_indices_node_frame_exact":True})
 for body in n["bodies"]:
  baseline=next(b for b in o["bodies"] if b["id"]==body["id"])
  if body["id"]!=changed:assert body==baseline
  else:
   original=[e for e in baseline["proof"]["entries"] if e["kind"]=="open_annex_passage"];actual=[e for e in body["proof"]["entries"] if e["kind"]=="open_annex_passage"];assert original==actual
   annex.extend(dict(level=level,entry=e,exact=True) for e in actual)
assert old["maps_external"]==new["maps_external"]
result={"evidence_class":"INERT","scope":"Retained exported arrays/indices/node frames,body witnesses and external map bindings exact. Reused frames are read at final contact-sheet review;not owner/runtime acceptance.","old_manifest_sha256":hashlib.sha256((oldroot/"manifest.json").read_bytes()).hexdigest(),"new_manifest_sha256":hashlib.sha256((newroot/"manifest.json").read_bytes()).hexdigest(),"comparisons":comparisons,"annex_frames_width_headroom_unchanged":annex,"reused_captures":[]}
review_path=oldroot/"review/review.json"
if review_path.exists():
 review=json.load(open(review_path));reuse=[c for c in review["captures"] if changed+"_" not in c["file"]];result["old_review_sha256"]=hashlib.sha256(review_path.read_bytes()).hexdigest();result["reused_captures"]=[{"file":str((oldroot/c["file"]).relative_to(root)).replace("\\","/"),"sha256":c["sha256"]} for c in reuse]
(newroot/"REVIEW_REUSE.json").write_text(json.dumps(result,indent=2)+"\n");print(block,len(comparisons),"retained partitions exact",len(result["reused_captures"]),"reused images",len(annex),"retained annex entries")
