# REPORT - V2-CITY-BUILDING-PACKETS - 2026-11-03

Evidence class: **INERT**. Native delivery; final visual review is in progress.

Branch / HEAD / origin/main / merge-base: codex/v2-city-20261029 / 531e6d398b1448ac3e1d82cdf9ba1e7dc4ea329f / fb3167942f02cc9c6db15176eb670f0724e6f981 / source checkpoint starts599813f210ac0d4ef4c3492d3068bce9d8e411a4.
Worktree clean at source checkpoint: yes. Source committed and pushed,not merged.
Protected17/17: no game files changed from599813;candidate verifier NOT_EXECUTED. Selector unchanged.
Ledger before -> after: NOT_EXECUTED;requirements_changed: []. INERT records grant no requirement promotion.

Gates:13 existing city horizon/shard tests pass;reader NEW0;design lint clean;diff check clean. Full board/candidate verifier and Godot suites NOT_EXECUTED for native-only delivery. Blender5.2.0 fbe6228777e7,one CPU thread;170 final geometry bodies/0failures and23 completed strict exports. Actual process commands,stdout,stderr and execution receipts are under attempts/. Original failures remain unchanged.

Numbers:85 new building bodies,39 preserved reference-specific profiles,124 exact reservations;23 partial-block packets. Near5,382,056/lower3,058,760 source triangles,769 material partitions per level,14,445 recessed pane witnesses and718 positive roof/equal outside controls per level.102 hollow flues with408 roof-hit witnesses per level. GLBs572,052,780/316,447,800 total bytes;largest47,623,840/33,835,648. These are native counts and file sizes,not measured rendering cost/draws/VRAM/frame spikes.14 current source bindings and36 registered external map hashes independently match.

Changes outside expected boundary: none. Six source/record paths in the source commit;all editable natives/GLBs/review receipts remain in this external delivery. Canonical checkout/index and installed source plan/assets/tests remain untouched. No new materials,images,gameplay,collision,clock,save,weather,narrative or companion authority.

Research: repeated specific LPC0450,LPC1831 and Dutch Kills examples form architectural families with rebuilt metric bays,not stretched meshes or85different historical addresses. Hampton79thStreet central entry/flanking canted bays/openwork parapet/light sash distinguished from78thStreet recent rails. Office35.2m cap/setbacks/finish are AU composition;LP2570's11-storey building with three-storey clock tower is not a90m height source. No photograph pixels or generated lettering embedded.

Open findings: final reopened GLB/CPU front,rear and lower review IN_PROGRESS. Earlier exact UV comparison failed on float32 V conversion;replacement checks every triangle corner with measured drift/four-ULP bound. Original narrow-stock,office-init and flue-key diagnostics and both earlier native cohorts are retained. Loaded mipmaps,renderer lighting,collision/access,LOD transitions,real frame cost/spikes and owner artistic review are unqualified.

P2_PANE_DISPOSITION.json lists192 retired generic and184 new floor/outline-side/bay witness identities. Entire body replaced;no one-to-one aperture mapping or eight missing checks claim. Near/lower witnesses match;canonical old192 list independently equals baseline. NeighborP0R2 remains46 separately. Installed192 assertions and all first-hit rays remain unchanged until reviewed actual replacement qualification.

Decision needed from owner: none. Orison Developer Sol6.1 owns later integration after backlog/current qualification.

Integration: verify packet_index.json85/39 IDs and each manifest;merge only declared profiles into current source plan. The supplied integration.patch passes git apply --check against the unchanged owning producer but remains unapplied. Use that producer to assemble complete blocks preserving all other bodies;never copy a partial packet GLB over a whole installed block. Register new lower-body imports and source discovery,compare actual retained/replacement arrays,finish native context review,then one coordinated runtime qualification. Preserve P2 semantic assertions and all existing access/shop/traffic authorities. No main merge here.

BLOCKED integration candidate pending final native visual review and developer intake/runtime qualification;packet authoring continues.
