import subprocess,sys,pathlib,os
root=pathlib.Path(__file__).resolve().parent.parent
for block in ["HORIZON_FAR_0_0","HORIZON_FAR_0_1","HORIZON_FAR_3_1"]:
 p=subprocess.run([sys.executable,str(root/"attempts/prepare_review_reuse.py"),block,block+"_P1","attempts/wide_factory_v1_original/"+block.lower()]);assert p.returncode==0
 p=subprocess.run([sys.executable,str(root/"attempts/run_native.py"),block,"--review"],env={**os.environ,"CITY_PACKET_REVIEW_IDS":block+"_P1"})
 if p.returncode:sys.exit(p.returncode)
p=subprocess.run([sys.executable,str(root/"attempts/prepare_review_reuse.py"),"HORIZON_STREET_END_0","HORIZON_STREET_END_0_P1","attempts/wide_factory_v1_original/horizon_street_end_0"]);assert p.returncode==0
