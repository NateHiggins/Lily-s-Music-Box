import pathlib,json,bpy,collections,numpy as np
root=pathlib.Path(__file__).resolve().parent.parent;packet=root/"horizon_street_end_0";m=json.load(open(packet/"manifest.json"));r=m["records"][0];target="HORIZON_STREET_END_0_P1__cast_iron"
bpy.ops.wm.open_mainfile(filepath=str(packet/r["native"]));original=bpy.data.objects[target];bpy.context.view_layer.update()
def points(o):
 o.data.calc_loop_triangles();return np.array([sorted(tuple(float(c) for c in o.matrix_world@o.data.vertices[i].co) for i in t.vertices) for t in o.data.loop_triangles])
O=points(original);oldmatrix=[list(x) for x in original.matrix_world];prior=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(packet/r["asset"]));bpy.context.view_layer.update();actual=next(o for o in bpy.data.objects if o not in prior and o.type=="MESH" and o.name.split(".")[0]==target);A=points(actual)
result=dict(evidence_class="INERT",target=target,native_triangles=len(O),imported_triangles=len(A),native_matrix=oldmatrix,imported_matrix=[list(x) for x in actual.matrix_world],native_bounds=[O.min(axis=(0,1)).tolist(),O.max(axis=(0,1)).tolist()],imported_bounds=[A.min(axis=(0,1)).tolist(),A.max(axis=(0,1)).tolist()])
if O.shape==A.shape:
 delta=np.abs(O-A);result["max_face_order_component_delta_m"]=float(delta.max());where=np.where(np.max(delta,axis=(1,2))>0)[0];result["differing_face_order_triangles"]=len(where);result["samples"]=[dict(index=int(i),native=O[i].tolist(),imported=A[i].tolist(),max_delta_m=float(delta[i].max())) for i in where[:3]]
(root/"attempts/roundtrip_diagnostic_01.json").write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result),flush=True)
