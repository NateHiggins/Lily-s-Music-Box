import bpy,runpy,time,pathlib,os
from bpy.app.handlers import persistent
root=pathlib.Path(__file__).resolve().parent.parent
@persistent
def cpu_freeze_barrier(scene):
 if (root/"DEVELOPER_HOLD").exists():print("CPU FREEZE BARRIER: waiting for developer terminal notice",flush=True)
 while (root/"DEVELOPER_HOLD").exists():time.sleep(1)
 scene.render.threads_mode="FIXED";scene.render.threads=4
 print("ACTUAL NATIVE REVIEW SETTINGS: CYCLES CPU,4renderthreads,640x640,8samples",flush=True)
bpy.app.handlers.render_pre.append(cpu_freeze_barrier)
entry=runpy.run_path("C:/ov/city/art/blender/scripts/build_city_building_packets.py",run_name="city_packet_review_entry")
selected=os.environ.get("CITY_PACKET_REVIEW_IDS","").split(",")
if selected!=[""]:
 original=entry["review_block"]
 def filtered(packet,rows):
  chosen=[r for r in rows if r["id"] in selected];assert len(chosen)==len(selected)
  print("NATIVE RENDER SELECTED IDS",selected,flush=True)
  return original(packet,chosen)
 entry["build_block"].__globals__["review_block"]=filtered
entry["main"]()
