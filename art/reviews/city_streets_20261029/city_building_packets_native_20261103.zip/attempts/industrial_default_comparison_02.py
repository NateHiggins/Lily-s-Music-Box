import sys,pathlib,json,types,hashlib,collections,copy
sys.path.insert(0,"C:/ov/city/art/blender/scripts")
import city_industrial_architecture as current
root=pathlib.Path(__file__).resolve().parent.parent
oldsource=(root/"attempts/city_industrial_at531.py").read_text()
old=types.ModuleType("industrial_at531");exec(compile(oldsource,"industrial_at531","exec"),old.__dict__)
rows=json.load(open("C:/ov/city/art/data/city_horizon/source_plan.json"))["buildings"]
fixture=json.load(open("C:/ov/city/game/tests/fixtures/orison_city_horizon.json"));grades={r["id"]:r for r in fixture["buildings"]}
packet=json.load(open(root/"proposed_source_plan.json"))["buildings"]
controls=[]
inputs=[]
for r in rows:
 if r.get("architecture",{}).get("type")=="industrial_front":inputs.append(dict(r,grade_datum_m=grades[r["id"]]["grade_datum_m"],grade_low_m=grades[r["id"]]["grade_low_m"]))
for r in packet:
 a=r.get("architecture",{})
 if a.get("fabricator")=="industrial":
  local=copy.deepcopy(a["fabrication_profile"]);local.update(id=r["id"],grade_datum_m=0.,grade_low_m=-.02);inputs.append(local)
for row in inputs:
 for lower in [False,True]:
  outputs=[]
  for module in [old,current]:
   buffers=collections.defaultdict(lambda:([],[]))
   def emit(name,key,v,f):
    vv,ff=buffers[(name,key)];n=len(vv);vv.extend(v);ff.extend(tuple(n+i for i in x) for x in f)
   cls=module.PianoFactory if row["architecture"]["style"]=="sohmer_3101" else module.IndustrialBuildings
   proof=cls(copy.deepcopy(row),emit,[],lower).build();outputs.append((dict(buffers),proof))
  assert outputs[0]==outputs[1],(row["id"],lower)
  controls.append(dict(id=row["id"],lower=lower,all_emitted_positions_faces_and_witnesses_exact=True))
(root/"attempts/industrial_default_comparison_02.json").write_text(json.dumps(dict(evidence_class="INERT",controls=controls,default_override_absent=True),indent=2)+"\n")
print("DEFAULT INDUSTRIAL EXACT",len(controls),"body variants",flush=True)
