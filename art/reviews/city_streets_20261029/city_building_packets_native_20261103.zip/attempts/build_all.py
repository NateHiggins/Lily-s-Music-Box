import json,pathlib,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parent.parent
blocks=json.loads((root/"packet_index.json").read_bytes())["blocks"]
priority=["HORIZON_NEAR_3_0","HORIZON_NEAR_3_1","HORIZON_NEAR_0_0","HORIZON_FAR_3_0"]
for block in priority+[b for b in blocks if b not in priority]:
 while (root/"HOLD_NATIVE").exists():time.sleep(1)
 if (root/block.lower()/"manifest.json").exists():continue
 p=subprocess.run([sys.executable,str(root/"attempts/run_native.py"),block])
 if p.returncode:sys.exit(p.returncode)
print("ALL NATIVE PACKETS BUILT",flush=True)
