import sys,json,pathlib,traceback,time
sys.path.insert(0,"C:/ov/city/art/blender/scripts")
from city_packet_architecture import PacketBuildings
from city_horizon_geometry import building_outline
root=pathlib.Path(__file__).resolve().parent.parent
rows=json.loads((root/"proposed_source_plan.json").read_bytes())["buildings"]
results=[]
for row in rows:row.update(grade_datum_m=0.,grade_low_m=-.02)
for row in rows:
 if row.get("architecture",{}).get("type")!="packet_front":continue
 for lower in [False,True]:
  try:
   count=[0]
   def emit(name,key,v,f):count[0]+=len(f)
   proof=PacketBuildings(row,emit,[o for o in rows if o["id"]!=row["id"]],lower).build()
   results.append(dict(id=row["id"],lower=lower,status="PASS",faces=count[0],panes=len(proof["windows"])))
  except Exception as e:results.append(dict(id=row["id"],lower=lower,status="FAIL",error=traceback.format_exc()))
(root/"attempts/geometry_preflight_01.json").write_text(json.dumps(results,indent=2))
fail=[r for r in results if r["status"]=="FAIL"]
print("PREFLIGHT",len(results),"failed",len(fail),flush=True)
for r in fail:print(r["id"],r["lower"],r["error"][-700:])
