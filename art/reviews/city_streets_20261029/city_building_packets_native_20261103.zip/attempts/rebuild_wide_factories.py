import pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent.parent
for block in ["HORIZON_FAR_0_0","HORIZON_FAR_0_1","HORIZON_FAR_3_1","HORIZON_STREET_END_0"]:
 p=subprocess.run([sys.executable,str(root/"attempts/run_native.py"),block])
 if p.returncode:sys.exit(p.returncode)
