import pathlib,json,hashlib,subprocess,collections,ast
root=pathlib.Path(__file__).resolve().parent.parent
repo=pathlib.Path('C:/ov/city')
def read(p):return json.loads(p.read_bytes())
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
current='be2c1a83c37f149091e08aa634d53d2035565358'
old=read(root/'SOURCE_VERSION_CUSTODY.json')
versions={r['block']:r['source_checkpoint'] for r in old['packets']}
for i in range(4):versions[f'HORIZON_STREET_END_{i}']=current
cache={};custody=[];levels={};ids=[];roundtrips=[];fresh=0;reused=0;files=[];maps={}
for path in sorted(root.glob('horizon_*/manifest.json')):
 m=read(path);packet=path.parent;version=versions[m['block']];ids+=m['buildings']
 for name,expected in m['source_bindings'].items():
  name=name.replace('\\','/');key=(version,name)
  if key not in cache:cache[key]=subprocess.check_output(['git','show',version+':'+name],cwd=repo)
  raw=cache[key];assert expected in [hashlib.sha256(raw).hexdigest(),hashlib.sha256(raw.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')).hexdigest()],(version,name)
 assert len(m['source_bindings'])==14
 for name,value in m['maps_external'].items():
  candidates=[repo/'game/assets/building/textures'/name]
  # Native packets bind the existing catalogue maps externally; no duplicate maps.
  candidates=[p for p in candidates if p.is_file()]
  assert candidates,(name,'missing external map')
  if name not in maps:assert any(sha(p)==value['sha256'] for p in candidates),name
  assert name not in maps or maps[name]==value['sha256'];maps[name]=value['sha256']
 r=read(packet/'review/review.json');assert r['manifest_sha256']==sha(path)
 assert all(x['world_triangles_exact'] and x['uv_roundtrip'] for x in r['roundtrips'])
 roundtrips+=r['roundtrips'];fresh+=len(r['captures'])
 for c in r['captures']:assert sha(packet/c['file'])==c['sha256'] and c['whole_body_framed']
 if (packet/'REVIEW_REUSE.json').exists():
  reuse=read(packet/'REVIEW_REUSE.json');reused+=len(reuse['reused_captures'])
  for c in reuse['reused_captures']:assert sha(root/c['file'])==c['sha256']
 for record in m['records']:
  target=levels.setdefault(record['level'],dict(triangles=0,partitions=0,panes=0,roof_contacts_and_equal_outside_controls=0,bytes=0,max_asset_bytes=0))
  target['triangles']+=sum(p['triangles'] for p in record['parts']);target['partitions']+=len(record['parts'])
  target['panes']+=record['panes'];target['roof_contacts_and_equal_outside_controls']+=record['roof_contacts']
  target['bytes']+=record['bytes'];target['max_asset_bytes']=max(target['max_asset_bytes'],record['bytes'])
  assert record['export_check']['status']=='PASS'
  for name,expected in [(record['asset'],record['sha256']),(record['native'],record['native_sha256'])]:
   assert sha(packet/name)==expected;files.append(dict(file=str((packet/name).relative_to(root)),sha256=expected,bytes=(packet/name).stat().st_size))
 custody.append(dict(block=m['block'],source_checkpoint=version,raw_bindings_matched=14,manifest_sha256=sha(path)))
assert len(ids)==len(set(ids))==85 and len(custody)==23 and len(files)==92 and len(maps)==36
index=read(root/'packet_index.json');baseline=read(repo/'art/data/city_horizon/source_plan.json');proposal=read(root/'proposed_source_plan.json')
assert sha(repo/'art/data/city_horizon/source_plan.json')==index['baseline_plan_sha256']
assert set(ids)==set(index['changed']) and len(index['preserved'])==39
before_rows={r['id']:r for r in baseline['buildings']};after_rows={r['id']:r for r in proposal['buildings']}
assert before_rows.keys()==after_rows.keys() and len(after_rows)==124
assert all(before_rows[k]['rect']==after_rows[k]['rect'] for k in before_rows)
assert all(before_rows[k]==after_rows[k] for k in index['preserved'])
assert set(k for k in before_rows if before_rows[k]!=after_rows[k])==set(ids)
assert {k:v for k,v in baseline.items() if k!='buildings'}=={k:v for k,v in proposal.items() if k!='buildings'}
assert len(roundtrips)==1538 and fresh==219 and reused==36
write(root/'SOURCE_VERSION_CUSTODY.json',dict(evidence_class='INERT',packets=custody,raw_bindings_matched=322,git_checkout_line_endings='Exact Git bytes or checkout CRLF conversion,never normalized digest repinning',version_counts=dict(collections.Counter(versions.values()))))
visual=read(root/'review_sheets/visual_review.json')
for i in range(4):
 name=f'horizon_street_end_{i}.png';meta=read(root/'review_sheets'/name.replace('.png','.json'))
 assert sha(root/'review_sheets'/name)==meta['sha256']
 visual['sheets']=[x for x in visual['sheets'] if x['file']!=name]
 visual['sheets'].append(dict(file=name,sha256=meta['sha256'],source_captures_covered=len(meta['captures']),observations='Actually viewed complete contact sheet: front/rear near and front lower. Distinct apartment courts,entry bays,parapets,sash and industrial loft grid where present;whole lower-body silhouettes retained. No clipping or missing bodies observed at sheet resolution. Scenic roofs await owning runtime dressing and integrated lighting review.'))
assert len(visual['sheets'])==23
visual['logical_source_captures_covered']=sum(x['source_captures_covered'] for x in visual['sheets']);assert visual['logical_source_captures_covered']==255
write(root/'review_sheets/visual_review.json',visual)
summary=read(root/'NATIVE_SUMMARY.json');summary.update(levels=levels,source_checkpoint=current,review_status='COMPLETE:23 native review records and23 actually viewed contact sheets covering255 logical views;219fresh and36proven unchanged reused',source_revision_policy='15at531,1officeatf696,3widefactoryblocksat928,4streetendblocksatbe2c;322 rawbindings verified against exact Git/checkout bytes',roundtrip_parts=len(roundtrips),max_uv_roundtrip_drift_m=max(x['max_uv_roundtrip_drift_m'] for x in roundtrips),fresh_captures=fresh,reused_captures=reused,artifact_hashes=files)
summary['geometry_preflight']['scope']='Original170-body preflight reused for unchanged geometry;corrected office,four wide factories andfour street packets rechecked by their strict build/review runs. Not a newly repeated monolithic170-body suite.'
write(root/'NATIVE_SUMMARY.json',summary)
# Compare complete writer AST: only added datum assignment is permitted.
before=ast.parse(subprocess.check_output(['git','show','928ae8230:art/blender/scripts/build_city_building_packets.py'],cwd=repo))
after=ast.parse((repo/'art/blender/scripts/build_city_building_packets.py').read_bytes())
class Strip(ast.NodeTransformer):
 def visit_Assign(self,node):
  if any(isinstance(t,ast.Name) and t.id=='center' for t in node.targets) and '2e-06' in ast.unparse(node):return None
  return self.generic_visit(node)
after=Strip().visit(after);assert ast.dump(before,include_attributes=False)==ast.dump(after,include_attributes=False)
reconcile=read(root/'SOURCE_RECONCILIATION.json');reconcile['prior_versions_preserved_in']='attempts/source_reconciliation_before_precision.json';reconcile['versions']=dict(collections.Counter(versions.values()));reconcile['writer_AST_exact_to928_after_removing_one_near_zero_center_assignment']=True;reconcile['precision_scope']='Packet near/lower writer before local vertices;exporter2um near-zero rule;originalfailedworldtriangle receipt retained;strict comparison unchanged'
write(root/'SOURCE_RECONCILIATION.json',reconcile)
print(json.dumps(dict(packets=23,bodies=85,files=92,maps=36,raw_bindings=322,roundtrips=len(roundtrips),captures=[fresh,reused],levels=levels,max_uv_drift=summary['max_uv_roundtrip_drift_m'],versions=summary['source_revision_policy']),indent=2))
