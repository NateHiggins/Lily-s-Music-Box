extends Node3D
var failures: Array[String]=[]
var checks := 0
func check(ok: bool, label: String) -> void:
 checks+=1
 if not ok: failures.append(label);push_error(label)
func _ready() -> void:
 call_deferred("run")
func run() -> void:
 RealityState.persistence_enabled=false
 RealityState.reset_campaign_for_tests()
 CampaignTime.set_frozen_for_tests(true)
 var city := preload("res://scripts/building/orison_v2_city_shells.gd").new()
 add_child(city)
 await get_tree().physics_frame;await get_tree().physics_frame
 var bodies: Dictionary={}
 for draw: MeshInstance3D in city.find_children("*","MeshInstance3D",true,false):
  var body := draw.get_parent().get_node(str(draw.name)+"Collision") as StaticBody3D
  bodies[body.get_rid()]=str(draw.name)
 var fixture: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://tests/fixtures/orison_city_elevation_probes.json"))
 var placement := preload("res://scripts/building/orison_v2_city_placement.gd").new()
 var helper := preload("res://tests/v2_city_elevation_review.gd").new()
 var seen: Dictionary={}
 var results: Array=[]
 for station: Dictionary in fixture.stations:
  var identity := str(station.building)
  if not identity in ["site_nbr_w","site_ne2","site_back_e","site_far_n"] or seen.has(identity):continue
  seen[identity]=true
  var a: Array=station.point
  var b: Array=station.normal
  var point := city.to_global(Vector3(a[0],a[1],a[2])+placement.city_offset(identity))
  var normal := city.global_basis*Vector3(b[0],b[1],b[2])
  var ray := PhysicsRayQueryParameters3D.create(point+normal*.04,point-normal*.04,1)
  check(helper._wall_hit_matches(city.get_world_3d().direct_space_state.intersect_ray(ray),point,normal,identity,bodies),"initial real body corresponds to native target: "+identity)
  results.append(await helper._exercise_wall_backing(city,self,ray,point,normal,identity,bodies))
 check(results.size()==4,"four real owner mutations completed")
 city.free()
 await get_tree().physics_frame;await get_tree().physics_frame
 var out := OS.get_environment("CITY_WALL_CONTROL_OUT")
 if not out.is_empty(): FileAccess.open(out,FileAccess.WRITE).store_string(JSON.stringify({"evidence_class":"INERT","scope":"isolated loaded city wall mutation controls; no composed world or artistic acceptance","checks":checks,"failures":failures,"results":results},"  "))
 print("CITY WALL CONTROLS: checks=",checks," failures=",failures.size())
 get_tree().quit(0 if failures.is_empty() else 1)
