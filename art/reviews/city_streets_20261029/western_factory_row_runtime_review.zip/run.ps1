$env:ORISON_VISIBLE_GODOT='0'
Remove-Item Env:ORISON_GODOT_EXE -ErrorAction SilentlyContinue
$env:ORISON_SCRIPT_CHECK='["res://scripts/building/orison_v2_city_horizon.gd","res://tests/v2_city_individual_body_review.gd"]'
pwsh -NoProfile -File C:/ov/city/tools/lane.ps1 batch -BatchFile C:/ov/reports/city_streets_20261029/western_factory_row_01/runtime_family_01/batch.json -ProjectPath C:/ov/city/game -WaitMinutes 240
exit $LASTEXITCODE
