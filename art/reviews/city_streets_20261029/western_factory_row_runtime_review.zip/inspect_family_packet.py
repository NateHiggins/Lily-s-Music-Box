"""Read actual completed output; never produce or renew a runtime receipt."""
from pathlib import Path
import json,hashlib,statistics,subprocess,math

root=Path('C:/ov/city');out=Path(__file__).parent;family=out/'family'
contract=json.loads((family/'individual_bodies.runtime.json').read_bytes())
assert contract['schema_version']==2 and contract['evidence_kind']=='runtime_contract'
assert contract['execution']['completed'] and not contract['execution']['timed_out']
assert contract['execution']['exit_code']==0 and not contract['failures'],contract['failures']
assert contract['pane_controls']==170 and len(contract['loaded_materials'])==26
assert len(contract['observations'])==9
clock=None

def stats(values):
    values=sorted(float(x) for x in values)
    assert values and all(math.isfinite(x) for x in values)
    def percentile(p):
        at=(len(values)-1)*p;low=int(at);high=min(low+1,len(values)-1)
        return values[low]+(values[high]-values[low])*(at-low)
    return {'n':len(values),'median':statistics.median(values),'p95_linear':percentile(.95),
            'p99_linear':percentile(.99),'min':values[0],'max':values[-1]}

observations=[]
for row in contract['observations']:
    assert len(row['samples'])==90 and len(row['transition_samples'])==12
    observations.append({'building':row['building'],'case':row['case'],'counters':row['counters'],
        'wall_ms':stats(x['wall_ms'] for x in row['samples']),
        'renderer_cpu_reported_ms':stats(x['cpu_ms'] for x in row['samples']),
        'renderer_gpu_reported_ms':stats(x['gpu_ms'] for x in row['samples']),
        'transition_wall_ms':stats(x['wall_ms'] for x in row['transition_samples'])})

hash_mismatches=[]
for path,expected in contract['source_hashes'].items():
    assert path.startswith('res://'),path
    file=(root/'game'/path.removeprefix('res://')).resolve()
    raw=file.read_bytes()
    if file.suffix.removeprefix('.') in ['gd','json','gdshader','gdshaderinc','import']:
        raw=raw.replace(b'\r\n',b'\n')
    if hashlib.sha256(raw).hexdigest()!=expected:hash_mismatches.append(path)
assert not hash_mismatches,hash_mismatches

receipts=[]
for name in ['import_1','import_2','compile','family']:
    p=out/(name+'.log.receipt.json');r=json.loads(p.read_bytes())
    assert r['execution']['completed'] and r['execution']['exit_code']==0 and not r['execution']['timed_out'],name
    error=out/(name+'.log.stderr')
    receipts.append({'path':str(p),'execution':r['execution'],'stderr_bytes':error.stat().st_size if error.exists() else None})

images=[{'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        for p in sorted(family.glob('*.png'))]
report={'evidence_class':'INERT','scope':'Independent read-only verification/summary of original schema2 outputs. '
        'Not a new runtime receipt, current-canonical qualification or artistic acceptance. '
        'Times are isolated fixed-light viewport observations, not whole-city or incremental cost. '
        'All-zero renderer timers, if present, do not prove zero rendering cost.',
        'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
        'checks':contract['checks'],'failures':contract['failures'],'pane_controls':contract['pane_controls'],
        'frozen_consumed_sources_matched':len(contract['source_hashes']),'settings':contract['settings'],
        'observations':observations,'natural_transitions':contract['natural_transitions'],
        'clock':clock,'wrapper_receipts':receipts,'images':images,
        'visual_inspection':'Pending individual inspection; image/hash existence is not appearance acceptance.'}
(out/'independent_family_summary_01.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('Verified',report['checks'],'checks',report['pane_controls'],'panes',report['frozen_consumed_sources_matched'],'source hashes')
for row in observations:print(row['building'][-4:],row['case'],'wallMedian/P95/max',*[round(row['wall_ms'][k],4) for k in ['median','p95_linear','max']],'CPUmed',round(row['renderer_cpu_reported_ms']['median'],4),'GPUmed',round(row['renderer_gpu_reported_ms']['median'],4),'transitionMax',round(row['transition_wall_ms']['max'],4))
for name,value in contract['natural_transitions'].items():print(name[-4:],value['part'],value['before'],value['after'])
print('Actual PNGs',len(images),'visual review pending')
