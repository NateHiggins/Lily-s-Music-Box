"""Refresh actual discoveries only after exact consumed-mask comparisons."""
from pathlib import Path
import collections, hashlib, json, re, sys
ROOT=Path('C:/ov/city'); HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'tools'))
from run_receipt import runtime_inputs_sha256
from grade_source_snapshot import validate
PLAN='art/data/orison_ground/retained_grade_source.json'
SURVEY='art/data/orison_ground/discovery/runtime_survey.json'
NATIVE='art/data/orison_ground/discovery/native_sources.json'
FOUND='art/blender/city_foundations_construction.json'
FIXTURE='game/tests/fixtures/orison_city_foundations_construction.json'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def digest(path):
    raw=path.read_bytes();return sha(raw if path.suffix in ('.blend','.glb') else raw.replace(b'\r\n',b'\n'))
def encoded(data):return (json.dumps(data,indent=2,ensure_ascii=True)+'\n').encode()
original={p:(ROOT/p).read_bytes() for p in (PLAN,SURVEY,NATIVE,FOUND,FIXTURE)}
backup=HERE/'before_grade_refresh_02';assert not backup.exists()
for rel,raw in original.items():
    p=backup/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
plan=json.loads(original[PLAN]);old=json.loads(original[SURVEY])
fresh_path=HERE/'grade_survey_01/grade_owners.json';fresh=json.loads(fresh_path.read_bytes())
native_path=HERE/'native_classification_01_output.json';native=json.loads(native_path.read_bytes())
assert fresh['evidence_class']=='INERT' and fresh['failures']==0
assert fresh['source']['runtime_inputs_sha256']==runtime_inputs_sha256(ROOT)
assert old['poses']==fresh['poses']
normalize=lambda p:re.sub(r'(@[A-Za-z0-9_]+)@\d+',r'\1',p)
def groups(data):
    result=collections.defaultdict(list)
    for r in data['records']:
        result[(normalize(r['owner']),normalize(r['shape_owner']),r['shape_type'],r['aligned'])].append(tuple(r['bounds']))
    return {k:sorted(v) for k,v in result.items()}
assert len(old['records'])==len(fresh['records'])==573 and groups(old)==groups(fresh)
lookup={(r['owner'],r['id']):r for r in native['records']};checked=0;derived=0;runtime=0
for category in ('retained_solids','occupation_reservations','surface_exclusions'):
    for row in plan[category]:
        actual=lookup.get((row['owner'],row.get('id')))
        if actual:
            if category=='surface_exclusions' and row['owner']=='ServiceAlley' and row['kind']=='retained_paving_envelope':
                assert actual['kind']=='retained_continuous_paving_substrate'
                assert all(row['bounds'][i]==actual['bounds'][i] for i in (0,2,3,5))
                assert row['bounds'][1]==plan['soil_bottom'] and row['bounds'][4]==plan['asphalt_y']
                derived+=1
            else:assert row['kind']==actual['kind'] and row['bounds']==actual['bounds'],(category,row)
            checked+=1
        elif row['kind']=='actual_axis_aligned_box':
            matches=[r for r in fresh['records'] if r['owner']==row['owner'] and r['aligned'] and max(abs(x-y) for x,y in zip(r['bounds'],row['bounds']))<.00003]
            assert len(matches)==1,row
            runtime+=1
assert (checked,derived,runtime)==(9601,6,66),(checked,derived,runtime)
allowed={'art/blender/city_transport_construction.json','art/blender/city_streets_construction.json',
         'art/data/city_streets/source_plan.json','art/blender/scripts/build_city_streets.py'}
stale={p for p,h in plan['bindings'].items() if digest(ROOT/p)!=h}
assert stale==allowed,stale
for rel,h in native['bindings'].items():assert digest(ROOT/rel)==h,rel
for rel,h in fresh['source']['test_dependencies'].items():assert digest(ROOT/rel)==h,rel
mask_keys=['retained_solids','occupation_reservations','surface_exclusions','region','soil_bottom','asphalt_y','open']
mask_hash=sha(encoded({k:plan[k] for k in mask_keys}))
for rel in allowed:plan['bindings'][rel]=native['bindings'][rel]
plan['bindings'][SURVEY]=sha(fresh_path.read_bytes().replace(b'\r\n',b'\n'))
if NATIVE in plan['bindings']:plan['bindings'][NATIVE]=sha(native_path.read_bytes().replace(b'\r\n',b'\n'))
plan['method']+=' Western intake: fresh573-owner discovery has exact retained geometry/registration; all9601 consumed native rows retain exact bounds (six paving envelopes retain their explicit derived depth),66 runtime-box projections match. No new discovery masks are admitted; source-derived district polygons own excavation. Original refusal/discoveries remain in western_street_01.'
assert sha(encoded({k:plan[k] for k in mask_keys}))==mask_hash
foundation=json.loads(original[FOUND]);assert original[FOUND]==original[FIXTURE]
placements={r['id']:r.get('assembly_translation_m',[0,0,0]) for r in json.loads((ROOT/'art/data/city_elevations/source_plan.json').read_bytes())['buildings']}
assert len(foundation['profiles'])==23
assert all(r['assembly_translation_m']==placements.get(r['id'].removesuffix('_base0'),[0,0,0]) for r in foundation['profiles'])
assert digest(ROOT/'game/assets/props/city_foundations.glb')==foundation['source_native_sha256']
for rel,h in foundation['bindings'].items():assert digest(ROOT/rel)==h,rel
plan_raw=encoded(plan);foundation['bindings'][PLAN]=sha(plan_raw)
try:
    (ROOT/SURVEY).write_bytes(fresh_path.read_bytes())
    (ROOT/NATIVE).write_bytes(native_path.read_bytes())
    (ROOT/PLAN).write_bytes(plan_raw)
    validate(plan,ROOT)
    (ROOT/FOUND).write_bytes(encoded(foundation));(ROOT/FIXTURE).write_bytes(encoded(foundation))
except BaseException:
    for rel,raw in original.items():(ROOT/rel).write_bytes(raw)
    raise
report=dict(evidence_class='INERT',scope='Fresh actual discovery, exact consumed projection only; no changed masks/native geometry/runtime acceptance.',runtime_boxes=573,consumed_native_rows=checked,derived_paving_envelopes=derived,actual_box_projections=runtime,mask_payload_sha256=mask_hash,changed_bindings=sorted(allowed),new_discovered_records_not_admitted=len(native['records'])-len(json.loads(original[NATIVE])['records']),foundation_placement_projections=23,updated_paths={p:dict(before_raw_sha256=sha(original[p]),after_raw_sha256=sha((ROOT/p).read_bytes())) for p in original})
(HERE/'grade_source_reconciliation_02.json').write_bytes(encoded(report))
print(json.dumps(report))
