# Gate board - 2413f6e4a2a5

- commit `2413f6e4a2a5f6283a66d3b238e67b3a59870de5`
- tree `2c6fdb4a2e80af80f2e3a08938abb1ff5d0d7131`
- created 2026-11-01T13:46:37Z
- dirty paths: 1143

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| spatial | PASS | 0 | 20.39 | no defects counted |
| reader | PASS | 0 | 10.03 | unread 1060; vs frozen baseline: new 0, resolved 248 |
