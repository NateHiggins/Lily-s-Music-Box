extends Node
var failures:int=0
var checks:int=0
func _check(ok:bool,label:String)->void:
    checks+=1
    if not ok:
        failures+=1
        print("IMPORTED UV FAILURE: ",label)
func _ready()->void:
    RealityState.persistence_enabled=false
    var parts:int=0
    var input_hashes:Dictionary={}
    for path:String in ["res://assets/props/city_streets.glb","res://assets/props/city_streets_lod1.glb","res://assets/props/orison_ground.glb","res://assets/props/city_ground_apron.glb"]:
        input_hashes[path]=FileAccess.get_sha256(path)
        var model:Node3D=(load(path) as PackedScene).instantiate()
        for draw:MeshInstance3D in model.find_children("*","MeshInstance3D",true,false):
            var name:String=str(draw.name)
            if name.begins_with("Street_Western") or name.begins_with("StreetCut_") or name.begins_with("Court_soil_P34_") or name.begins_with("GradeCut_soil_P34_") or (name.begins_with("Horizon_") and (name.ends_with("__soil") or name.ends_with("__asphalt") or name.ends_with("__concrete"))):
                _check_cap_mapping(draw.mesh,true,true);parts+=1
        model.free()
    _check(parts>0,"nonempty actual imported body roster")
    for path:String in input_hashes:_check(FileAccess.get_sha256(path)==input_hashes[path],"native exports remain frozen")
    var record:Dictionary={"evidence_class":"INERT","scope":"Actual imported arrays only,canonical metric/basis/derivative thresholds with scalar-double edge/UV arithmetic; no world,controller,rendered appearance or artistic acceptance.","checks":checks,"failures":failures,"parts":parts,"source_hashes":input_hashes,"test_sha256":FileAccess.get_sha256(get_script().resource_path)}
    var file:FileAccess=FileAccess.open(OS.get_environment("SHOT_DIR").path_join("imported_mesh_probe.json"),FileAccess.WRITE)
    if file==null:get_tree().quit(1);return
    file.store_string(JSON.stringify(record,"\t"));file.close()
    print("IMPORTED MESH PROBE ",checks," checks ",parts," parts ",failures," failures")
    get_tree().quit(0 if failures==0 else 1)

func _check_cap_mapping(mesh: Mesh, check_derivatives: bool=false, triangle_surfaces: bool=false) -> void:
    for surface in mesh.get_surface_count():
        var arrays:=mesh.surface_get_arrays(surface)
        var vertices: PackedVector3Array=arrays[Mesh.ARRAY_VERTEX]
        var normals: PackedVector3Array=arrays[Mesh.ARRAY_NORMAL]
        var uv: PackedVector2Array=arrays[Mesh.ARRAY_TEX_UV]
        var tangents: PackedFloat32Array=arrays[Mesh.ARRAY_TANGENT]
        # Clipped terrain partitions may be a single real triangle. Roof-cap
        # callers retain the quad minimum unless they explicitly opt in.
        _check(vertices.size()>=(3 if triangle_surfaces else 4) and normals.size()==vertices.size() and uv.size()==vertices.size() and tangents.size()==vertices.size()*4,"planar surface has active UV, normal and tangent on every imported vertex")
        var valid:=true
        for i in vertices.size():
            valid=valid and vertices[i].is_finite() and uv[i].is_finite() and absf(normals[i].length()-1)<.001
            if tangents.size()==vertices.size()*4:
                var tangent:=Vector3(tangents[i*4],tangents[i*4+1],tangents[i*4+2])
                valid=valid and tangent.is_finite() and absf(tangent.length()-1)<.001 and absf(tangent.dot(normals[i]))<.001 and absf(absf(tangents[i*4+3])-1)<.001
        _check(valid,"finite unit normals and orthogonal tangent handedness")
        var indices: PackedInt32Array=arrays[Mesh.ARRAY_INDEX]
        _check(indices.size()>=(3 if triangle_surfaces else 6) and indices.size()%3==0,"planar surface has complete native indexed triangles")
        var mapped:=true
        var widest:=0.0
        var excess:=0.0
        var derivatives:=true
        var bad_derivatives:=0
        var min_determinant:=INF
        var worst_dot:=1.0
        for triangle in range(0,indices.size(),3):
            if check_derivatives:
                var a:=indices[triangle]
                var b:=indices[triangle+1]
                var c:=indices[triangle+2]
                # Scalar doubles match the native GLB validator. Vector3/2
                # subtraction/multiplication rounds these thin faces to float32.
                var x1:float=float(vertices[b].x)-float(vertices[a].x)
                var y1:float=float(vertices[b].y)-float(vertices[a].y)
                var z1:float=float(vertices[b].z)-float(vertices[a].z)
                var x2:float=float(vertices[c].x)-float(vertices[a].x)
                var y2:float=float(vertices[c].y)-float(vertices[a].y)
                var z2:float=float(vertices[c].z)-float(vertices[a].z)
                var u1:float=float(uv[b].x)-float(uv[a].x)
                var v1:float=float(uv[b].y)-float(uv[a].y)
                var u2:float=float(uv[c].x)-float(uv[a].x)
                var v2:float=float(uv[c].y)-float(uv[a].y)
                var determinant:float=u1*v2-u2*v1
                min_determinant=minf(min_determinant,absf(determinant))
                derivatives=derivatives and absf(determinant)>1e-12
                if absf(determinant)>1e-12:
                    var expected:Vector3=Vector3((x1*v2-x2*v1)/determinant,(y1*v2-y2*v1)/determinant,(z1*v2-z2*v1)/determinant)
                    var bitangent:Vector3=Vector3((x2*u1-x1*u2)/determinant,(y2*u1-y1*u2)/determinant,(z2*u1-z1*u2)/determinant)
                    for index: int in [a,b,c]:
                        var projected: Vector3=(expected-normals[index]*expected.dot(normals[index])).normalized()
                        var actual:=Vector3(tangents[index*4],tangents[index*4+1],tangents[index*4+2])
                        worst_dot=minf(worst_dot,projected.dot(actual))
                        if projected.dot(actual)<=.999 or normals[index].cross(actual).dot(bitangent)*tangents[index*4+3]<=0:
                            bad_derivatives+=1
                            if bad_derivatives<4:print("UV DERIVATIVE DIAGNOSTIC: ",mesh.resource_name," tri=",triangle," n=",normals[index]," actual=",actual," expected=",projected," bitangent=",bitangent," determinant=",determinant)
                        derivatives=derivatives and projected.dot(actual)>.999
                        derivatives=derivatives and normals[index].cross(actual).dot(bitangent)*tangents[index*4+3]>0
            for edge in 3:
                var a:=indices[triangle+edge]
                var b:=indices[triangle+(edge+1)%3]
                var length:=vertices[a].distance_to(vertices[b])
                var texture:=uv[a].distance_to(uv[b])
                mapped=mapped and texture<=length+.00005
                excess=maxf(excess,texture-length)
                if length>.00005: widest=maxf(widest,texture/length)
        _check(mapped and absf(widest-1)<.005,"planar mapping retains one texture metre per model metre")
        if check_derivatives: _check(derivatives,"tangent direction and handedness match actual imported UV derivatives")
        print("CAP MAPPING: mesh=",mesh.resource_name," valid_basis=",valid," max_uv_excess=",excess," widest=",widest," vertices=",vertices.size()," derivatives=",derivatives," bad_derivatives=",bad_derivatives," min_determinant=",min_determinant," worst_dot=",worst_dot)
