from pathlib import Path
import sys,json,bpy,bmesh
from mathutils import Vector
root=Path('C:/ov/city');out=Path(__file__).parent
sys.path.insert(0,str(root/'art/blender/scripts'))
from city_ground_apron_geometry import repair_cut_draw_representation
cases=[('actual_failed_positive', [(-1.7021636962890625,-1.4744091033935547,-.18946778774261475),(-1.7021636962890625,-1.4744033813476562,-.18946754932403564),(-1.7021636962890625,-1.4744091033935547,-.18946754932403564)],(138.,18.,-1.910499930381775),True),
       ('meaningful_triangle',[(0,0,0),(1,0,0),(0,1,0)],(138.,18.,-1.9),False),
       ('positive_beyond_representation',[(0,0,0),(.00001,0,0),(0,.00000001,0)],(0,0,0),False)]
rows=[]
for name,points,origin,collapse in cases:
    bm=bmesh.new();verts=[bm.verts.new(p) for p in points];bm.faces.new(verts);bm.normal_update()
    before=[tuple(v.co) for v in bm.verts];area=sum(f.calc_area() for f in bm.faces)
    result=repair_cut_draw_representation(bm,Vector(origin))
    assert bool(result['collapsed_edges'])==collapse,(name,result)
    if collapse:assert not bm.faces and result['maximum_vertex_shift_m']<=.000001
    else:assert len(bm.faces)==1 and [tuple(v.co) for v in bm.verts]==before
    if name=='positive_beyond_representation':assert 0.<area<1e-12
    rows.append(dict(id=name,before_area_m2=area,remaining_faces=len(bm.faces),**result));bm.free()
record=dict(evidence_class='INERT',scope='Native isolated actual-failure and positive/negative draw repair controls, not asset/runtime acceptance.',cases=rows)
(out/'draw_repair_probe_01.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(record))
