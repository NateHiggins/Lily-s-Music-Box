from pathlib import Path
import json,struct,subprocess,hashlib,numpy as np
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent
before=json.loads((OUT/'baseline_assets_01.json').read_bytes())['assets']
after=json.loads((OUT/'generated_assets_01.json').read_bytes())['assets']
changes=json.loads((OUT/'asset_preservation_01.json').read_bytes())['assets']
def read(raw):
    length=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+length]);binary=raw[28+length:]
    def array(i):
        a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']]
        dtype=np.dtype({5121:'u1',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']]);width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
        return np.ndarray((a['count'],width),dtype=dtype,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',width*dtype.itemsize),dtype.itemsize))
    def triangles(name,frame):
        node=next(n for n in doc['nodes'] if n.get('name')==name and 'mesh' in n)
        points=np.concatenate([array(p['attributes']['POSITION'])[array(p['indices']).astype(int).reshape(-1,3)] for p in doc['meshes'][node['mesh']]['primitives']]).astype(float)
        return np.concatenate([points,np.ones((*points.shape[:2],1))],axis=2)@np.asarray(frame).T
    return lambda name,frame:triangles(name,frame)[:,:,:3]
def nearest(point,triangles):
    a=triangles[:,0];u=triangles[:,1]-a;v=triangles[:,2]-a
    n=np.cross(u,v);norm=np.sum(n*n,axis=1);assert np.all(norm>0)
    offset=point-a;normal=np.sum(offset*n,axis=1)/norm
    projected=offset-normal[:,None]*n
    uu=np.sum(u*u,axis=1);uv=np.sum(u*v,axis=1);vv=np.sum(v*v,axis=1)
    pu=np.sum(projected*u,axis=1);pv=np.sum(projected*v,axis=1);det=uu*vv-uv*uv
    # Ultra-thin triangles may lose a Gram determinant in double precision.
    # Cross-product barycentrics avoid subtracting two nearly equal squares.
    s=np.sum(np.cross(projected,v)*n,axis=1)/norm
    t=np.sum(np.cross(u,projected)*n,axis=1)/norm
    inside=(s>=0)&(t>=0)&(s+t<=1)
    distance=np.where(inside,normal*normal*norm,np.inf)
    for start,end in [(0,1),(1,2),(2,0)]:
        a=triangles[:,start];edge=triangles[:,end]-a;length=np.sum(edge*edge,axis=1)
        along=np.clip(np.divide(np.sum((point-a)*edge,axis=1),length,out=np.zeros_like(length),where=length>0),0,1)
        delta=point-a-along[:,None]*edge
        distance=np.minimum(distance,np.sum(delta*delta,axis=1))
    return float(np.sqrt(distance.min()))
control=np.asarray([[[0.,0.,0.],[1.,0.,0.],[0.,1.,0.]]])
for p,expected in [([.2,.2,0],0.),([.2,.2,1],1.),([-1,0,0],1.),([-1,-1,0],2**.5)]:assert abs(nearest(np.asarray(p),control)-expected)<1e-12
records=[]
for rel in changes:
    names=[n for n in changes[rel]['changed'] if 'StreetCut' in n]
    if not names:continue
    old_raw=subprocess.run(['git','show','2413f6e4a:'+rel],cwd=ROOT,capture_output=True,check=True).stdout
    new_raw=(ROOT/rel).read_bytes()
    assert hashlib.sha256(old_raw).hexdigest()==before[rel]['raw_sha256'] and hashlib.sha256(new_raw).hexdigest()==after[rel]['raw_sha256']
    old=read(old_raw);new=read(new_raw)
    for name in names:
        frame=before[rel]['parts'][name]['world_transform'];assert frame==after[rel]['parts'][name]['world_transform']
        a=old(name,frame);b=new(name,frame);worst=0.;samples=0
        for source,target in [(a,b),(b,a)]:
            points=np.concatenate([source.reshape(-1,3),source.mean(axis=1),(source[:,0]+source[:,1])*.5,(source[:,1]+source[:,2])*.5,(source[:,2]+source[:,0])*.5])
            for p in points:worst=max(worst,nearest(p,target));samples+=1
        assert nearest(a[0,0]+np.asarray([1000,1000,1000]),b)>100.,'wrong-frame negative control'
        assert worst<.00003,(rel,name,worst)
        records.append(dict(asset=rel,part=name,old_triangles=len(a),new_triangles=len(b),bidirectional_samples=samples,maximum_sampled_surface_distance_m=worst))
report=dict(evidence_class='INERT',scope='Actual old/new retained Eastern cavity exports: vertices,centroids,edge-midpoints in both directions,existing exact frames,30micrometre sampled tolerance and independent triangle/wrong-frame controls. Not continuous geometric equality, runtime access or artistic acceptance.',parts=records,samples=sum(r['bidirectional_samples'] for r in records),maximum_sampled_surface_distance_m=max(r['maximum_sampled_surface_distance_m'] for r in records))
(OUT/'retained_cavity_surfaces_01.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print('RETAINED CAVITIES',len(records),'parts',report['samples'],'two-way samples; maximum metres',report['maximum_sampled_surface_distance_m'])
