from pathlib import Path
import sys,json,hashlib,bpy,numpy as np
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_ground_apron_geometry import stored_cut_chart_guides
from fabrication_native_batch import export
bpy.ops.wm.open_mainfile(filepath=str(OUT/'failed_ground_build_04.blend'))
changes=[]
for obj in bpy.data.collections['GroundExports'].objects:
    mesh=obj.data;coords=np.asarray([v.co[:] for v in mesh.vertices],dtype=np.float64)
    indices=np.asarray([loop.vertex_index for loop in mesh.loops],dtype=np.int32).reshape((-1,3))
    points=coords[indices][:,:,[0,2,1]].copy();points[:,:,2]*=-1
    normals=np.asarray([n.vector[:] for n in mesh.corner_normals],dtype=np.float32).reshape((-1,3,3))[:,:,[0,2,1]].astype(np.float64);normals[:,:,2]*=-1
    charts=np.asarray([v.uv[:] for v in mesh.uv_layers.active.data],dtype=np.float32).reshape((-1,3,2));charts[:,:,1]=np.float32(1)-charts[:,:,1]
    guide=mesh.attributes['_tangent_guide'];current=np.asarray([v.vector[:] for v in guide.data],dtype=np.float32).reshape((-1,3,3))
    fixed,count=stored_cut_chart_guides(points,normals,charts,current)
    if count:guide.data.foreach_set('vector',fixed.astype(np.float32).ravel());changes.append(dict(id=obj.name,triangles=count))
assert len(changes)==2,changes
target=OUT/'guide_probe_01';(target/'game/assets/props').mkdir(parents=True,exist_ok=True)
proof=export(target,'orison_ground',bpy.data.collections['GroundExports'],save_native=False)
(OUT/'stored_guides_probe_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Actual failed saved native export recharted guides only; no geometry/UV/normal edits or production delivery.',changes=changes,proof=proof),indent=2)+'\n',encoding='utf-8',newline='\n')
print('STORED GUIDE PROBE',json.dumps(changes),json.dumps(proof))
