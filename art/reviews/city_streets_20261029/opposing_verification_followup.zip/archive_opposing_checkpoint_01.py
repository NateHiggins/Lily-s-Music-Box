"""Preserve reviewed construction/runtime evidence without duplicate native assets."""
import hashlib,json,zipfile
from pathlib import Path
base=Path(__file__).parent;root=Path('C:/ov/city')
destination=root/'art/reviews/city_streets_20261029'
archive=destination/'opposing_architecture_qualification.zip'
assert not archive.exists()
selected=set()
text_suffixes={'.py','.json','.log','.stderr','.ps1'}
for prefix in ['opposing','library']:
    for path in base.glob(prefix+'*'):
        if path.is_file() and (path.suffix in text_suffixes or path.name.endswith('.receipt.json')):
            selected.add(path)
for name in ['library_production_01','library_production_02','opposing_geometry_preflight_01',
             'opposing_geometry_preflight_07','opposing_batch_01','opposing_batch_02',
             'opposing_batch_03','opposing_batch_04','opposing_batch_05',
             'opposing_elevation_bench_01','opposing_elevation_bench_02',
             'opposing_focused_route_01','opposing_grade_survey_01','opposing_ground_replay_01']:
    for path in (base/name).rglob('*'):
        if path.is_file() and path.suffix in text_suffixes and 'before' not in path.relative_to(base/name).parts:
            selected.add(path)
native=json.loads((base/'opposing_batch_04/actual_native_inspection.json').read_text())
for row in native['captures']:
    path=base/row['path'];assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
    selected.add(path)
for folder in ['opposing_elevation_bench_02','opposing_focused_route_01']:
    selected.update((base/folder).glob('*.png'))
for relative in ['library_production_01/near_native_review/library_entry.png',
                 'opposing_batch_01/near_native_review/firehouse_front.png',
                 'opposing_batch_01/near_native_review/hampton_front.png',
                 'opposing_batch_01/near_native_review/hampton_openwork.png',
                 'opposing_bench_failed_01_sources.zip']:
    path=base/relative;assert path.is_file(),relative;selected.add(path)
members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in sorted(selected):
        assert path.resolve().is_relative_to(base.resolve())
        raw=path.read_bytes();name='phase07_opposing/'+path.relative_to(base).as_posix()
        assert path.suffix.lower() not in {'.blend','.glb','.jpg','.jpeg','.webp'}
        z.writestr(name,raw)
        members[name]={'bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest()}
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,row in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==row['raw_sha256']
assert archive.stat().st_size<95_000_000,'Preserve oversized original; make a new bounded archive separately'
path=destination/'manifest.json';manifest=json.loads(path.read_text(encoding='utf-8'))
assert 'opposing_architecture_qualification_archive' not in manifest
manifest['opposing_architecture_qualification_archive']={
    'evidence_class':'INERT','file':archive.name,'bytes':archive.stat().st_size,
    'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'scope':'Original failed native controls and bench01; current19 inspected native frames,21 engine bench captures,4 production street captures,unchanged test-written route contract and source comparisons. Physical surface packet is installed separately. No new artistic/full-city acceptance or duplicate native/reference-image assets.',
    'members':members}
path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archived',len(members),'members;',archive.stat().st_size,'bytes; SHA',manifest['opposing_architecture_qualification_archive']['sha256'])
