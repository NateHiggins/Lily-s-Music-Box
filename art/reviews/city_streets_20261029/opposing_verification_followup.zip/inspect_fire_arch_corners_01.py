from pathlib import Path
import bpy,json,os
from mathutils import Vector
from mathutils.bvhtree import BVHTree
ROOT=Path('C:/ov/city');OUT=Path(os.environ['FIRE_CORNER_OUTPUT'])
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'art/blender/city_elevations.blend'))
vertices=[];faces=[];owners=[]
for obj in bpy.data.collections['V2CityElevations'].objects:
 if not obj.name.startswith('site_sw3__'):continue
 offset=len(vertices);vertices.extend(obj.matrix_world@v.co for v in obj.data.vertices)
 faces.extend(tuple(offset+i for i in f.vertices) for f in obj.data.polygons);owners.extend([obj.name]*len(obj.data.polygons))
bvh=BVHTree.FromPolygons(vertices,faces,all_triangles=True);rows=[]
for x in [-53.1,-51.5]:
 point=Vector((x,-28.52,17.25));hit,normal,index,distance=bvh.ray_cast(point+Vector((0,.1,0)),Vector((0,-1,0)),.4)
 passed=hit is not None and (hit-point).length<.0001 and owners[index]=='site_sw3__arcade_brick_bond'
 rows.append({'point':list(point),'hit':list(hit) if hit is not None else None,'owner':owners[index] if hit is not None else None,'pass':passed})
report={'evidence_class':'INERT','scope':'Independent native solid-spandrel rays outside the rounded gable opening,inside its rectangular envelope. No runtime acceptance.','rows':rows,'failures':sum(not r['pass'] for r in rows)}
OUT.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(report));assert report['failures']==0
