"""Before/after exact ground-family arrays; never refresh survey fingerprints."""
import ast,hashlib,json,sys
from pathlib import Path
base=Path(__file__).parent;root=Path('C:/ov/city');out=base/'opposing_ground_replay_01'
source=base/'nw_dependency_snapshot_01.py';tree=ast.parse(source.read_text())
body=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in ['digest','glb']]
scope={};exec(compile(ast.Module(body=body,type_ignores=[]),str(source),'exec'),scope)
families=['city_foundations','orison_ground','city_ground_apron','city_horizon_near','city_horizon_far']
runtime=['game/data/orison_v2/exterior/city_ground_relief.json','game/data/orison_v2/exterior/city_horizon.json']
metadata=['art/data/orison_ground/retained_grade_source.json','art/data/orison_ground/discovery/runtime_survey.json','art/data/orison_ground/discovery/native_sources.json','art/data/orison_ground/bar_reservations.json','art/blender/city_foundations_construction.json','game/tests/fixtures/orison_city_foundations_construction.json','art/blender/orison_ground_construction.json','game/tests/fixtures/orison_ground_construction.json','art/blender/city_ground_apron_construction.json','game/tests/fixtures/orison_city_ground_apron.json','art/blender/city_horizon_construction.json','game/tests/fixtures/orison_city_horizon.json',*runtime]
def sha(path):return hashlib.sha256(path.read_bytes().replace(b'\r\n',b'\n')).hexdigest()
def current():
    return {'assets':{family:scope['glb'](root/'game/assets/props'/f'{family}.glb') for family in families},'runtime_data':{p:sha(root/p) for p in runtime}}
mode=sys.argv[1];out.mkdir(exist_ok=True)
if mode=='before':
    path=out/'before.json';assert not path.exists(),'Do not overwrite the original ground snapshot'
    path.write_text(json.dumps(current(),indent=2)+'\n',newline='\n')
    for relative in metadata:
        original=root/relative;assert original.is_file(),relative
        target=out/'before'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(original.read_bytes())
    print('Five original complete GLB signatures and fourteen source/fixture files preserved')
elif mode=='compare':
    before=json.loads((out/'before.json').read_text());after=current();rows=[]
    for family in families:
        a=before['assets'][family];b=after['assets'][family]
        rows.append({'asset':family,'same_file':a['file_sha256']==b['file_sha256'],'same_arrays_indices_and_node_transforms':a['nodes']==b['nodes'],'parts':len(b['nodes'])})
    failures=[r['asset'] for r in rows if not r['same_arrays_indices_and_node_transforms']]
    same_runtime=before['runtime_data']==after['runtime_data']
    if not same_runtime:failures.append('runtime ground/horizon data changed; do not reuse an expired grade survey')
    report={'evidence_class':'INERT','scope':'Actual source-family arrays/indices/node transforms and runtime data around owning native replay. Does not renew runtime, loaded texture, collision/access or artistic acceptance.','assets':rows,'same_runtime_data':same_runtime,'failures':failures}
    (out/'comparison.json').write_text(json.dumps(report,indent=2)+'\n',newline='\n');print(json.dumps(report,indent=2));raise SystemExit(bool(failures))
else:raise ValueError(mode)
