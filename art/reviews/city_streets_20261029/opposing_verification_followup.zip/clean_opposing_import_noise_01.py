"""Preserve then remove only proven local import EOL/generated UID noise."""
import hashlib,io,json,re,subprocess,zipfile,stat
from pathlib import Path
root=Path('C:/ov/city').resolve();base=Path(__file__).parent
archive_path=base/'opposing_import_noise_before_01.zip'
manifest_path=base/'opposing_import_noise_before_01.json'
assert not archive_path.exists() and not manifest_path.exists()
def safe_path(relative):
    raw=root/relative
    for parent in [raw,*raw.parents]:
        if parent==root.parent:break
        assert not (parent.lstat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT),relative
    path=raw.resolve();assert path.is_relative_to(root),relative
    return path

def git(*args):return subprocess.check_output(['git',*args],cwd=root,stderr=subprocess.PIPE)
tracked=[];generated=[];unexpected=[]
# Status exposes import EOL/stat dirt that a normalized `git diff` omits.
changed=[record[3:] for record in git('status','--porcelain=v1','-z').decode().split('\0') if len(record)>3 and record[:2]!='??' and record[1]!=' ']
assert all('\n' not in relative for relative in changed)
batch=subprocess.run(['git','cat-file','--batch'],input=''.join(':'+relative+'\n' for relative in changed).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=root,check=True)
stream=io.BytesIO(batch.stdout)
for relative in changed:
    path=safe_path(relative)
    header=stream.readline().decode().split();assert len(header)==3 and header[1]=='blob'
    indexed=stream.read(int(header[2]));assert stream.read(1)==b'\n'
    raw=path.read_bytes()
    if relative.endswith('.import') and raw.replace(b'\r\n',b'\n')==indexed.replace(b'\r\n',b'\n'):
        tracked.append((relative,path,raw))
    else:unexpected.append(relative)
for relative in git('ls-files','--others','--exclude-standard','-z').decode().split('\0'):
    if not relative:continue
    path=safe_path(relative)
    raw=path.read_bytes()
    if relative.startswith('game/') and relative.endswith('.uid') and re.fullmatch(rb'uid://[a-z0-9]+\r?\n?',raw):
        generated.append((relative,path,raw))
    else:unexpected.append(relative)
assert not unexpected,('Preserve unexpected changes; stage only reviewed named paths first',unexpected)
assert tracked and generated
members={}
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED) as archive:
    for role,rows in [('tracked_import_eol_only',tracked),('untracked_engine_generated_uid',generated)]:
        for relative,path,raw in rows:
            archive.writestr(relative,raw)
            members[relative]={'role':role,'bytes':len(raw),'sha256_raw':hashlib.sha256(raw).hexdigest()}
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for relative,row in members.items():assert hashlib.sha256(archive.read(relative)).hexdigest()==row['sha256_raw']
manifest={'evidence_class':'INERT','scope':'Verified own worktree EOL-only tracked imports and untracked engine-generated UID files preserved before named cleanup. No source/gameplay/art changes or foreign checkout mutations.','root':str(root),'archive_sha256':hashlib.sha256(archive_path.read_bytes()).hexdigest(),'tracked_imports':len(tracked),'generated_uids':len(generated),'members':members}
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
pathspec=base/'opposing_import_noise_named_paths_01.txt'
assert not pathspec.exists();pathspec.write_bytes(b'\0'.join(relative.encode() for relative,_,_ in tracked)+b'\0')
subprocess.check_call(['git','restore','--worktree','--pathspec-from-file='+str(pathspec),'--pathspec-file-nul'],cwd=root)
for relative,path,raw in generated:
    assert path.is_relative_to(root/'game') and path.read_bytes()==raw
    path.unlink()
assert not git('diff','--name-only').strip()
assert not git('ls-files','--others','--exclude-standard').strip()
print('Preserved and cleaned',len(tracked),'named EOL-only imports and',len(generated),'generated UIDs; staged construction untouched')
