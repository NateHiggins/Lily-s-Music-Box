$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:/ov/city'
$cityEvidence='C:/ov/reports/city_streets_20261029'
$cityBlender='C:/Program Files/Blender Foundation/Blender 5.2/blender.exe'
# This recipe is invoked only after the owned benchmark/grade batch is terminal.
# A valid fresh test-written survey is required before any project data changes.
& python "$cityEvidence/validate_opposing_grade_for_replay_01.py"
if($LASTEXITCODE -ne 0){throw 'Fresh grade verification failed; do not change construction data'}
$cityActive=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -like '*godot*' -and ($_.CommandLine -like '*C:\ov\city\game*' -or $_.CommandLine -like '*C:/ov/city/game*')})
if($cityActive.Count -gt 0){throw 'Own Godot still active; retain its frozen inputs'}
if(@(Get-Process blender -ErrorAction SilentlyContinue).Count -gt 0){throw 'Another Blender run is active; inspect before replay'}
$citySurvey="$cityEvidence/opposing_grade_survey_01/grade_owners.json"
$cityNative="$cityEvidence/opposing_ground_replay_01/native_sources.json"
$cityDiscoveryLog="$cityEvidence/opposing_grade_native_discovery_01.log"
if(Test-Path -LiteralPath $cityNative){throw 'Preserve previous native discovery'}
if(Test-Path -LiteralPath $cityDiscoveryLog){throw 'Preserve previous native discovery log'}
& $cityBlender --background -t 2 --python-exit-code 1 --python art/blender/scripts/export_retained_grade_sources.py -- --survey $citySurvey --out $cityNative *> $cityDiscoveryLog
if($LASTEXITCODE -ne 0){throw 'Native discovery failed; original log retained'}
$cityCandidate="$cityEvidence/opposing_ground_replay_01/retained_grade_candidate.json"
if(Test-Path -LiteralPath $cityCandidate){throw 'Preserve previous grade candidate'}
& python tools/plan_v2_retained_grade.py --native $cityNative --survey $citySurvey --out $cityCandidate --report "$cityEvidence/opposing_ground_replay_01/grade_plan_report.json" *> "$cityEvidence/opposing_grade_plan_01.log"
if($LASTEXITCODE -ne 0){throw 'Grade planning failed; inspect original evidence'}
Write-Output 'Fresh classified grade candidate prepared externally. Inspect physical bounds, reservations and sources before installing it or rebuilding ground.'
