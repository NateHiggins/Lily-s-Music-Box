# Reproduce the canonical apartment physical/city qualification.
# Launch only after confirming no previous attempt is live; keep source frozen.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath C:/PleaseRemainOnTheLine
$env:ORISON_VISIBLE_GODOT='0'
$env:ORISON_REVIEW_FULLSCREEN='1'
$env:ORISON_SURFACE_PHYSICAL_ONLY='1'
$env:ORISON_SURFACE_CITY_REVIEW='1'
$env:ORISON_SURFACE_CITY_ONLY='0'
$env:ORISON_SURFACE_FIRE_ONLY='0'
$env:ORISON_SURFACE_SKIP_FIRE_INTERACTION='1'
$env:ORISON_SURFACE_CITY_CIVIC_ACCESS='0'
$env:ORISON_SURFACE_CITY_CONTEXT_IDS='HORIZON_NEAR_3_2_P1,HORIZON_NEAR_3_2_P2'
& ./tools/lane.ps1 batch -BatchFile C:/ov/reports/city_apartments_intake_20261101/composed01.json -WaitMinutes 30
exit $LASTEXITCODE
