from pathlib import Path
import json,subprocess,time,datetime
out=Path('C:/ov/reports/city_streets_20261029/canonical_bridge_01')
with (out/'physical_retry01_memory.jsonl').open('x',buffering=1) as f:
 for i in range(1200):
  row={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  try:row['gpu']=subprocess.check_output(['nvidia-smi','--query-gpu=memory.used,memory.total,utilization.gpu','--format=csv,noheader,nounits'],text=True,timeout=8).strip()
  except Exception as e:row['gpu_error']=str(e)
  if i%3==0:
   command="$m=Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory; $p=Get-Process -ErrorAction SilentlyContinue | Where-Object ProcessName -Like '*godot*' | Select-Object Id,ProcessName,WorkingSet64,PrivateMemorySize64; @{available=$m.AvailableBytes;committed=$m.CommittedBytes;limit=$m.CommitLimit;processes=$p} | ConvertTo-Json -Depth 4 -Compress"
   try:row['host']=json.loads(subprocess.check_output(['pwsh','-NoProfile','-Command',command],text=True,timeout=12))
   except Exception as e:row['host_error']=str(e)
  f.write(json.dumps(row)+'\n')
  if (out/'physical_retry01.log.receipt.json').exists():break
  time.sleep(5)
