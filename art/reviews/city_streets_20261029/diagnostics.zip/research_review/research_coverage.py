"""Coverage ledger only; no duplicated research text or acceptance claims."""
from pathlib import Path
import hashlib,json,csv,ast,re,math,collections
P=Path(__file__).parent;B=Path('C:/ov/reports');R=Path('C:/ov/city')
required={
'bridge_research_20261028':['reference_brief.txt'],
'elevated_research_20261028':['reference_brief.txt','crossover_elevations_supplement.txt'],
'city_reference_next_20261028':['reference_brief.txt','geometry_roof_register.txt'],
'city_next_six_20261028':['READ_FIRST.txt','reference_brief.txt','selection.csv','roof_equipment.csv','selected_source_inventory.json'],
'storefront_research_20261028':['REFERENCE_CARDS.md','sources.md','dimension_schedule.csv'],
'traffic_reference_research_20261028':['READ_FIRST.txt','reference_brief.txt','braking_envelopes.csv','existing_vehicle_dimensions.csv','roster_dimensions.csv'],
'city_sightline_research_20261028':['SIGHTLINE_PLAN.md','STREET_LEVEL_PROPOSAL.md','TOWER_CHRONOLOGY_AND_SOURCES.md'],
'gaslight_research_20261028':['GASLIGHT_RESEARCH.md','SOURCE_SURVEY.md'],
'industrial_ground_research_20261028':['READ_FIRST.txt','reference_brief.txt','kit_schedule.csv'],
'site_grade_research_20261028':['SITE_AND_STREET_GRADE_STUDY.md','DATUM_AND_FRAME_REGISTER.md','GRADE_OPTIONS.csv','ANCHOR_CONSEQUENCES.csv','CROSS_SECTION_FOLLOW_UP.md','ARCHIVE_RESEARCH_TARGETS.md'],
'facade_window_research_20261028':['AUDIT.md','candidate_inventory.md','source_locators.txt','window_schedule.csv'],
'research_agenda_20261028':['RESEARCH_AGENDA.md','QUESTIONNAIRE_AND_DECISIONS.md'],
'city_continuity_research_20261028':['RESEARCH_INDEX_AND_HANDOFF.md','SOURCE_REGISTER.md','FOLLOW_UP_AND_CONFLICTS.md','INDUSTRIAL_USE_AND_SECTORS.md','MONTHLY_CITY_CALENDAR.md','MONTHLY_EVIDENCE.csv','NIGHT_GEOGRAPHY_AND_ROOF_SERVICES.md','WAYFINDING_AND_DAILY_RHYTHMS.md']}
read={
'industrial_ground_research_20261028':set(required['industrial_ground_research_20261028']),
'site_grade_research_20261028':set(required['site_grade_research_20261028']),
'facade_window_research_20261028':set(required['facade_window_research_20261028']),
'research_agenda_20261028':set(required['research_agenda_20261028']),
'city_continuity_research_20261028':set(required['city_continuity_research_20261028']),
'city_next_six_20261028':{'READ_FIRST.txt','reference_brief.txt','selection.csv','roof_equipment.csv'},
'storefront_research_20261028':set(required['storefront_research_20261028']),
'gaslight_research_20261028':set(required['gaslight_research_20261028'])}
for packet in ['bridge_research_20261028','elevated_research_20261028','traffic_reference_research_20261028','city_sightline_research_20261028']:
    read[packet]=set(required[packet])
read['city_reference_next_20261028']={'reference_brief.txt'}
rows=[]
for packet,names in required.items():
    for name in names:
        p=B/packet/name
        rows.append(dict(path=str(p),exists=p.is_file(),sha256=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None,status='newly read/re-read in coverage audit' if name in read.get(packet,set()) else 'reading not yet established by this audit'))
p=R/'art/docs/research_1927_construction.md'
rows.append(dict(path=str(p),exists=True,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),status='newly read in coverage audit',note='Canonical copy compared byte-identical; legacy Midwest typology, not Queens street evidence.'))
for name in ['MATERIAL_PROMPT_SHEET.md','WALL_TEXTURE_PROMPT_SHEET.md','V2_ENVIRONMENT_DOSSIER_MERGE_ERRATA_2026-10-10.md']:
    p=R/'design'/name
    rows.append(dict(path=str(p),exists=p.is_file(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),status='newly read/re-read in coverage audit',note='Production guidance and historical implementation notes; not proof of Queens1928 materials or current qualification.'))
out=dict(evidence_class='INERT',scope='Bounded compiled-guidance review complete: all thirteen authored city packets and linked repo material/wall guidance,48 read entries plus two complete structured inventories,55 named figures/contact sheets viewed. Excludes duplicate exports, unrelated runtime captures, rejected Decker stock and unselected raw OCR/archive pages; inaccessible, caption-only and unacquired originals remain unverified. No source fact becomes canon, implementation or runtime acceptance.',documents=rows,missing=[r['path'] for r in rows if not r['exists']],figures_reviewed=[],findings=['Retain limestone as existing coping key during geometry pass; not documentary bluestone proof. Current street bedding/gutters and original coping interfaces remain unfinished.','SiteB is recommended AU central-western descent, supported by owner research direction; no surveyed historic absolute level or selected exact new grade.','Facade/window report identifies protected interior/aperture conflicts; no city-scope apartment repair or floor movement. Candidate inventory is dated; new prologue entrance intake supersedes its no-newer-model finding.','The agenda identifies an additional distinct city_next_six packet beyond the initial twelve-folder inventory.'])
figures={
'industrial_ground_research_20261028':['construction_sections.png','tillson1900_p487.png','tillson1900_p497.png','greene1917_p122.png','penn1910_p29.png','noble1910_plateXV.png','queens_contact.jpg','dutch_primary_reproduction.jpg','P856c_1929.jpg'],
'site_grade_research_20261028':['GRADE_AND_VIEW_CHANNELS.png','CROSS_SECTION_ENVELOPE.png','references/raymond_plate3.png','references/IRM_selected_p6.png','references/IRM_selected_p42.png'],
'city_next_six_20261028':['reference_contact.jpg','site_plan.png','hampton79.jpg','germania_p16.png','robbins_p9.png','scheffel_p14.png','engine258_p9.png','ottendorfer_published1917.jpg'],
'bridge_research_20261028':['annotated_construction.png','report_p3.png','engineer_p38.png','engineer_p59.png','engineer29_map.png','burr1908_p23.png','engineer_p22.png','panorama_P856.jpg','panorama_P856b.jpg'],
'elevated_research_20261028':['reference_plates.jpg','lavis1915_p81.png','psc1913_station_elevation_p83.jpg','erj1916_station_pdf191.png','photo_77461.jpg'],
'storefront_research_20261028':['references/butler_reproduced.png','references/cigar_1917.jpg','references/olliffe_NYPL_ca1950.jpg','references/chumley_application_photo22.jpg','references/childs_pdf_p10_Im3.jpg','references/childs_pdf_p10_Im4.jpg'],
'traffic_reference_research_20261028':['reference_contact.jpg','ih1928_spec.jpg','ih_ad_pdf67.png','stopping_envelopes.png'],
'city_reference_next_20261028':['plates_overview.png','plate_61.png','plate_65.png','plate_66.png','plate_67.png','plate_69.png','plate_70.png','elm_court_modern_reference.jpg']}
out['figures_reviewed']=[dict(path=str(B/packet/name),sha256=hashlib.sha256((B/packet/name).read_bytes()).hexdigest(),scope='Actually viewed; source/date limits in authored brief retained. Contact sheet inspection is not full-resolution plate inspection.') for packet,names in figures.items() for name in names]
out['figures_reviewed'].append(dict(path=str(B/'facade_window_research_20261028/annotated_elevations.svg'),scope='Viewed external PyMuPDF rasterization. CSS styling was not faithfully rendered; geometry/text diagnostic only, source unchanged.'))
out['findings'] += ['Tillson printed468 New York specification leaves some depth/face dimensions blank; other cities specify different sections. No universal1928 Queens curb standard is established.','Bridge granite is a documented distinct substance; limestone must not silently masquerade as granite. Painted steel is dielectric; primary eye-bars and painted surfaces are separate substance/finish questions.','Elevated supplement supersedes unsupported34m width with primary reported27.432m; exact1928 heights/switches remain unresolved. Current shortened station is an authored adaptation, not historical reconstruction.','The six-court packet dated before completed city work is historical guidance; retain current eleven individual studies and bindings, not its stale open-work count.']
inventory=json.loads((B/'city_next_six_20261028/selected_source_inventory.json').read_text())
csv_rows={x['id']:x for x in csv.DictReader((B/'city_next_six_20261028/roof_equipment.csv').open())}
errors=[];seen=set();stock_count=0;schemas=collections.defaultdict(set);roster=[]
def close(a,b):
    if isinstance(a,list):return len(a)==len(b) and all(close(x,y) for x,y in zip(a,b))
    return abs(float(a)-float(b))<1e-8
def finite(value):
    if isinstance(value,(int,float)):return math.isfinite(value)
    if isinstance(value,list):return all(finite(x) for x in value)
    if isinstance(value,dict):return all(finite(x) for x in value.values())
    return True
for group,data in inventory.items():
    if not finite(data):errors.append(group+': nonfinite value')
    for stock in data['source_stock']:
        stock_count+=1;schemas['stock'].update(stock)
        rect=stock['rect']
        if not(rect[0]<rect[2] and rect[1]<rect[3] and stock['h']>0):errors.append(stock['id']+': nonpositive body')
    for family,records in data['equipment'].items():
        for record in records:
            schemas[family].update(record);identity=record['id'];seen.add(identity);row=csv_rows[identity]
            shift=record['registration_offset_x']
            for field,column in [('p0','registered_p0'),('p1','registered_p1'),('rect','registered_rect')]:
                if field not in record:continue
                values=list(record[field]);values[0]+=shift
                if field=='rect':values[2]+=shift
                if not close(values,ast.literal_eval(row[column])):errors.append(identity+': '+field+' registration mismatch')
            for field,column in [('r','radius'),('z0','z0'),('h','h')]:
                if field in record and not close(record[field],row[column]):errors.append(identity+': '+field+' mismatch')
    roster.append(dict(group=group,registered_rect=data['registered_xy_rect'],offset=data['source_x_offset'],body_top=data['body_top'],stocks=len(data['source_stock']),equipment={k:len(v) for k,v in data['equipment'].items()}))
if seen!=set(csv_rows):errors.append('equipment CSV roster mismatch')
contacts=[];comments=[]
for line in (B/'city_reference_next_20261028/geometry_roof_register.txt').read_text().splitlines():
    if not line.startswith('BEARING '):comments.append(line);continue
    prefix,footprint=line.split('; footprint=');match=re.fullmatch(r'BEARING (\S+) on (\S+): (.*)',prefix)
    points=ast.literal_eval(footprint);center=ast.literal_eval(match[3])
    if not finite(points) or not finite(center):errors.append(match[1]+': nonfinite contact')
    bounds=[[min(p[a] for p in points),max(p[a] for p in points)] for a in range(3)]
    if bounds[2][1]-bounds[2][0]>1e-5:errors.append(match[1]+': nonplanar bearing')
    contacts.append(dict(id=match[1],support=match[2],center=center,bounds=bounds,vertices=len(points)))
out['structured_inventory_review']=dict(method='Complete JSON schema/roster and numeric stock review; all hardware endpoints/rectangles/radii cross-checked against the fully read registered CSV, applying X offset once. Complete TXT contact roster parsed, finite/planarity checked, support centers and full polygon bounds inspected; does not claim literal line-by-line reading of every duplicated vertex or native/runtime fit.',roster=roster,stocks=stock_count,equipment=len(seen),schemas={k:sorted(v) for k,v in schemas.items()},contacts=contacts,comments=comments,errors=errors)
out['coverage_boundary']='All thirteen authored city packets, linked repo material/wall guidance and the two complete structured inventories reviewed;55 named figures/contact sheets actually viewed. Bounded review excludes duplicate exports, rejected Decker candidate, unrelated runtime capture folders and unselected raw OCR/archive pages. Original sources not obtained or only caption/text-inspected retain those explicit limitations. This is research coverage for construction decisions, not exhaustive authentication of every linked original or implementation/acceptance.'
out['findings'].append('Correction from actual owner trace: legacy coping records say limestone, but build_street_paving_details.py and runtime street_paving_details.json replace the coping with registered concrete. Match actual installed cap response/section, not the old record label.')
for row in rows:
    if row['path'].endswith(('geometry_roof_register.txt','selected_source_inventory.json')):
        row['status']='structured inventory review; see explicit method and complete roster'
(P/'research_coverage.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Documents',len(rows),'read',sum(r['status'].startswith('newly') for r in rows),'missing',len(out['missing']))
print('Structured inventory:',stock_count,'stocks,',len(seen),'equipment,',len(contacts),'contacts; errors',errors)
print('Contact support families',dict(collections.Counter(x['support'] for x in contacts)))
