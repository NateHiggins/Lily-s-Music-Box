"""Reopen street, station and retained context; inspect physical supports."""
from pathlib import Path
import hashlib,json,math,os,sys
import bpy,bmesh
from mathutils import Matrix,Vector
from mathutils.bvhtree import BVHTree
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'game/project.godot').is_file());OUT=Path(os.environ['CITY_STREET_REVIEW']);OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(Path(__file__).parent))
from city_street_geometry import area,bounds,intersection,rectangle

def read(p):return json.loads((ROOT/p).read_text())
def sha(p):
    raw=(ROOT/p).read_bytes();return hashlib.sha256(raw if Path(p).suffix in ['.blend','.glb'] else raw.replace(b'\r\n',b'\n')).hexdigest()
paths=['art/blender/city_streets.blend','art/blender/city_streets_construction.json','art/data/city_streets/source_plan.json','art/blender/city_transport.blend','art/blender/city_transport_construction.json','art/blender/scripts/review_city_streets.py','art/blender/scripts/city_street_geometry.py']
hashes={p:sha(p) for p in paths};meta=read(paths[1]);plan=read(paths[2]);station=read(paths[4]);checks=[];failures=[]
def check(ok,label,**detail):
    row=dict(passed=bool(ok),label=label,**detail);checks.append(row)
    if not ok:failures.append(row)
bpy.ops.wm.open_mainfile(filepath=str(ROOT/paths[0]))
for lod in range(2):
    source=bpy.data.collections['StreetClosed_LOD'+str(lod)];source.hide_render=True
    for obj in source.objects:
        bm=bmesh.new();bm.from_mesh(obj.data);check(all(e.is_manifold for e in bm.edges) and bm.calc_volume(signed=True)>0,'closed native street stock',id=obj.name);bm.free()
    bpy.data.collections['StreetExports_LOD'+str(lod)].hide_render=bool(lod)
near=list(bpy.data.collections['StreetExports_LOD0'].objects)

def load(relative,names,label,transform=Matrix.Identity(4)):
    with bpy.data.libraries.load(str(ROOT/relative),link=False) as (available,loaded):
        assert set(names)<=set(available.objects),(relative,set(names)-set(available.objects));loaded.objects=names
    col=bpy.data.collections.new(label);bpy.context.scene.collection.children.link(col)
    for obj in loaded.objects:col.objects.link(obj);obj.matrix_world=transform@obj.matrix_world;obj.hide_render=False;obj.hide_set(False)
    bpy.context.view_layer.update();hashes[relative]=sha(relative)
    return list(col.objects)
station_names=sorted({r['id'] for r in station['stocks'] if r['lod']==0})
station_objects=load('art/blender/city_transport.blend',station_names,'StationClosedContext')
# Editable stocks carry native catalogue materials only in their export parts;
# use exported near partitions for diagnostic PBR and actual source positions.
for obj in station_objects:obj.hide_render=True
station_exports=load('art/blender/city_transport.blend',list(read('game/data/orison_v2/exterior/city_transport.json')['parts']),'StationExportsContext')
layout=read('game/data/orison_v2_blockout.json');door=next(r for r in layout['doors'] if r['id']=='F01_DOOR_06');frame=read('game/data/orison_v2/exterior/street_frame.json');shift=-(door['center'][1]+frame['source_threshold_z'])
root_to_city=Matrix.Translation((0,shift,0))@Matrix.Diagonal((-1,-1,1,1))
front=read('game/tests/fixtures/orison_front_pavement_construction.json')
front_objects=load('art/blender/front_pavement.blend',[r['id'] for r in front['parts']],'RetainedFrontPaving',root_to_city)

def tree(objects):
    verts=[];faces=[];names=[]
    for obj in objects:
        n=len(verts);verts.extend(obj.matrix_world@v.co for v in obj.data.vertices);faces.extend(tuple(n+i for i in p.vertices) for p in obj.data.polygons);names.extend([obj.name]*len(obj.data.polygons))
    return BVHTree.FromPolygons(verts,faces),names
ground_objects=[o for o in near if o.name.endswith(('__road','__walk'))]+[o for o in station_exports if o.name.endswith('__paving')]+front_objects
ground,names=tree(ground_objects);road,_=tree([o for o in near if o.name.endswith('__road')]);all_geometry,all_names=tree(near+station_exports)
for row in meta['stocks']:
    if row['lod']!=0 or row['finish']!='curb':continue
    p=row['polygon'];center=Vector((sum(x for x,y in p)/len(p),sum(y for x,y in p)/len(p),0))
    # A stone can bridge the authored four-millimetre slab joints. Test
    # distributed actual bearing points, not its outside rectangular AABB.
    probes=[center]+[center.lerp(Vector((x,y,0)),.55) for x,y in p]
    hits=[]
    for at in probes:
        hit,n,index,d=ground.ray_cast(at+Vector((0,0,.015)),Vector((0,0,-1)),.04)
        if hit is not None and abs(hit.z)<.0001 and n.z>.99:hits.append(names[index])
    check(len(hits)>=min(3,len(probes)),'curb actual bearing at retained zero walk plane',id=row['id'],supports=sorted(set(hits)),samples=len(probes),supported=len(hits))
for x in [-85,-76,-60,-44,-24,24,40,60,80,100,112]:
    for y in [-22.0,-19.3,-17.0]:
        hit,n,index,d=road.ray_cast(Vector((x,y,.03)),Vector((0,0,-1)),.2)
        check(hit is not None and abs(hit.z+.1)<.0001 and n.z>.99,'actual main road surface',x=x,y=y)
for x in meta['topology']['junction_x']:
    for y in [-35,-30,-26,-12,-6,0,8,16,23]:
        for dx in [-1.5,1.5]:
            hit,n,index,d=road.ray_cast(Vector((x+dx,y,.03)),Vector((0,0,-1)),.2)
            check(hit is not None and abs(hit.z+.1)<.0001,'unchanged traffic lane supported through crossing',x=x+dx,y=y)
for rect in meta['topology']['islands']:
    a,b,c,d=rect
    overlap_area=sum(area(intersection(p,rectangle(rect))) for p in meta['topology']['road'])
    check(overlap_area<1e-8,'road does not cut through protected pier footprint',rect=rect,overlap_m2=overlap_area)
# Independent source reservation checks: the entire near street body must
# have no positive polygon overlap with the fixed road or retained slab masks.
for row in meta['stocks']:
    if row['lod']==0 and row['finish']=='walk':
        overlaps=sum(area(intersection(row['polygon'],rectangle(r))) for r in meta['retained_footprints'])
        check(overlaps<1e-7,'new sidewalk respects retained occupied/paving footprint',id=row['id'],overlap_m2=overlaps)
(OUT/'native_geometry_checks.json').write_text(json.dumps(dict(evidence_class='INERT',source_hashes=hashes,checks=checks,failures=failures),indent=2)+'\n')
assert not failures,failures[:12]

elevation=read('game/tests/fixtures/orison_city_elevations.json');offsets={r['id']:Vector(r.get('assembly_translation_m',[0,0,0])) for r in read('art/data/city_elevations/source_plan.json')['buildings']}
context=load('art/blender/city_elevations.blend',[r['name'] for r in elevation['parts']],'RetainedCityContext')
for obj in context:
    key=next(k for k in offsets if obj.name.startswith(k+'__'));obj.matrix_world=Matrix.Translation(offsets[key])@obj.matrix_world
bpy.context.view_layer.update();scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=12
scene.render.resolution_x=1600;scene.render.resolution_y=900;scene.render.resolution_percentage=100
scene.world=bpy.data.worlds.new('DiagnosticNativeWorld');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.55,.65,.8,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.7
sun=bpy.data.objects.new('DiagnosticSun',bpy.data.lights.new('DiagnosticSun','SUN'));scene.collection.objects.link(sun);sun.data.energy=3;sun.rotation_euler=(.45,-.35,-.7)
camera=bpy.data.objects.new('NativeStreetCamera',bpy.data.cameras.new('NativeStreetCamera'));scene.collection.objects.link(camera);scene.camera=camera;camera.data.lens=25
views=[('block_overview',(-115,-75,72),(10,-10,0)),('east_intersection',(60,-32,5.5),(72,-9,0)),('east_north_walk',(64.3,18,1.41),(65.5,-13,0)),('west_corner',(-63,-10,1.41),(-72,-25,0)),('curb_grazing',(-55,-16,0.45),(-65,-14.7,0))]
for name,at,target in views:
    camera.location=at;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(OUT/(name+'.png'));bpy.ops.render.render(write_still=True)
for p,h in hashes.items():assert sha(p)==h,p
(OUT/'native_review.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Actual reopened native bodies and catalogue materials under diagnostic lighting; no runtime, historical survey, save, performance or artistic acceptance.',source_hashes=hashes,checks=len(checks),failures=failures,renders=[v[0]+'.png' for v in views]),indent=2)+'\n')
print('CITY STREETS NATIVE REVIEW:',len(checks),'checks;',len(failures),'failures')
