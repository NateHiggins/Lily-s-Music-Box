from pathlib import Path
import sys,json
import bpy,bmesh,numpy as np
from mathutils import Vector
ROOT=Path('C:/ov/city');P=Path(__file__).parent;sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_ground_apron_geometry import coalesced_grid_planes,clip_profile_face,profile_roof_caps,profile_grid_volume,parcel_transition_cells
from ground_closed_union import build_closed_ground
bpy.ops.wm.read_factory_settings(use_empty=True)
col=bpy.data.collections.new('ParcelControls');bpy.context.scene.collection.children.link(col)
xs=np.arange(9,dtype=float);ys=np.asarray([-4.,-3.,-.2,0.],dtype=np.float32).astype(float);zs=xs.copy();coords=[xs,ys,zs]
solid=np.ones((8,3,8),dtype=bool);protected=np.zeros((8,8),dtype=bool);protected[2:6,2:6]=True
solid[2:6,2,2:6]=False
for i in range(2,6):
    for k in range(2,6):
        if i in (2,5) or k in (2,5):solid[i,1,k]=False
profile=[[0.,-1.],[8.,-1.]];retained=~solid;asphalt=np.zeros_like(solid)
assert parcel_transition_cells(xs,ys,solid,profile,protected)==0
assert parcel_transition_cells(xs,ys,np.ones_like(solid),profile,protected)>0,'Unretained raised-soil control must reject'
original=sum(float(np.count_nonzero(solid[:,j,:]))*(ys[j+1]-ys[j]) for j in range(3));wanted=original-48.
def points(row,r):
    axis=row['axis'];u,v=[i for i in range(3) if i!=axis];lo=[coords[axis][row['plane']]]*3;hi=lo.copy()
    lo[u],lo[v]=coords[u][r[0]],coords[v][r[1]];hi[u],hi[v]=coords[u][r[2]],coords[v][r[3]]
    x,y,z=lo;X,Y,Z=hi
    if axis==0:return [(x,y,z),(x,y,Z),(x,Y,Z),(x,Y,z)] if row['direction']<0 else [(X,y,z),(X,Y,z),(X,Y,Z),(X,y,Z)]
    if axis==1:return [(x,y,z),(X,y,z),(X,y,Z),(x,y,Z)] if row['direction']<0 else [(x,Y,z),(x,Y,Z),(X,Y,Z),(X,Y,z)]
    return [(x,y,z),(x,Y,z),(X,Y,z),(X,y,z)] if row['direction']<0 else [(x,y,Z),(X,y,Z),(X,Y,Z),(x,Y,Z)]
rows=[]
for name,parcel in [('retained',protected),('wrong_global_cut',None)]:
    faces=[]
    for row in coalesced_grid_planes(solid,retained,asphalt,coords,parcel_protection=parcel):
        faces += [points(row,r) for r in row['source_protected']]
        faces += [p for r in row['source_unprotected'] for p in clip_profile_face(points(row,r),profile)]
    faces += profile_roof_caps(xs,ys,zs,solid,profile,chunk_m=4.,parcel_protection=parcel)
    expected=profile_grid_volume(xs,ys,zs,solid,profile,parcel_protection=parcel)
    assert abs(expected-(wanted if parcel is not None else wanted-3.2))<1e-6
    mesh,area,contacts,fans=build_closed_ground(faces,col,expected,sloped=True)
    obj=next(o for o in col.objects if o.data==mesh);bpy.context.view_layer.update()
    found,point,normal,index=obj.ray_cast(Vector((4.,-4.,float(ys[2])+.015)),Vector((0,0,-1)),distance=.03)
    if parcel is not None:assert found and abs(point.z-ys[2])<1e-5
    else:assert not found,'Old global cut must fail the fixed course seat'
    rows.append(dict(case=name,expected_volume_m3=expected,fixed_course_soil_contact=found))
report=dict(evidence_class='INERT',scope='Native retained-parcel control with actual closed ring/plate voids and an unchanged seat ray; global-cut and missing-retainer controls reject. Not a production ground pass.',cases=rows,failures=0)
(P/'ground_parcel_control_01.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
