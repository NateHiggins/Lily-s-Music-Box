from pathlib import Path
from itertools import product
import json,sys,hashlib
import numpy as np
ROOT=Path('C:/ov/city');P=Path(__file__).parent;sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_ground_apron_geometry import coalesced_grid_planes
def check(solid,retained,asphalt,coords):
    occupied={p for p in product(*(range(n) for n in solid.shape)) if solid[p]}
    native={p for p in product(*(range(n) for n in solid.shape)) if retained[p]}
    expected={};wanted={};buried=0;base=0
    for p in occupied:
        for axis,direction in product(range(3),(-1,1)):
            q=list(p);q[axis]+=direction;q=tuple(q)
            if q in occupied:continue
            key=(axis,direction,*p);expected[key]=True
            if q in native:buried+=1;continue
            if axis==1 and direction==-1 and p[1]==0:base+=1;continue
            chunk=tuple(int(np.floor((coords[i][p[i]]+coords[i][p[i]+1])*.5/4)) for i in (0,2))
            wanted[key]=(2 if asphalt[p] else 1,chunk)
    actual={};rendered={};observed_buried=0;observed_base=0;cells=0
    for row in coalesced_grid_planes(solid,retained,asphalt,coords):
        axis,direction=row['axis'],row['direction'];u,v=[i for i in range(3) if i!=axis]
        observed_buried+=row['buried_cells'];observed_base+=row['base_cells'];cells+=row['boundary_cells']
        def expand(rect):
            for i,j in product(range(rect[0],rect[2]),range(rect[1],rect[3])):
                at=[0]*3;at[axis]=row['plane']-(direction>0);at[u]=i;at[v]=j
                yield (axis,direction,*at)
        for rect in row['source']:
            for key in expand(rect):assert key not in actual;actual[key]=True
        for label,rect,chunk in row['render']:
            for key in expand(rect):assert key not in rendered;rendered[key]=(label,chunk)
    assert actual==expected and rendered==wanted
    assert observed_buried==buried and observed_base==base and cells==len(expected)
cases=0
for bits in range(256):
    solid=np.array([(bits>>i)&1 for i in range(8)],dtype=bool).reshape(2,2,2)
    for mode in range(4):
        retained=(~solid)&np.array([((i+mode)%4)!=0 for i in range(8)]).reshape(2,2,2)
        asphalt=solid&np.array([((i+mode)%3)==0 for i in range(8)]).reshape(2,2,2)
        check(solid,retained,asphalt,[[-4.,0.,4.],[-4.,-.7,0.],[-4.,0.,4.] ]);cases+=1
rng=np.random.default_rng(7391)
for shape in [(1,4,3),(3,1,4),(4,3,1),(5,4,7)]:
    coords=[np.arange(shape[0]+1)-6,np.linspace(-4.,-.02,shape[1]+1),np.arange(shape[2]+1)-3]
    for _ in range(32):
        solid=rng.random(shape)>.4;retained=(~solid)&(rng.random(shape)>.5);asphalt=solid&(rng.random(shape)>.5)
        check(solid,retained,asphalt,coords);cases+=1
report=dict(evidence_class='INERT',scope='Exact occupancy-set oracle for every source face, render class, chunk, burial and omitted base; no native/render/runtime acceptance.',cases=cases,failures=0,source_lf_sha256=hashlib.sha256((ROOT/'art/blender/scripts/city_ground_apron_geometry.py').read_bytes().replace(b'\r\n',b'\n')).hexdigest())
(P/'grid_coalesce_controls_01.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
