from pathlib import Path
from itertools import product
import sys,json,hashlib
import numpy as np
ROOT=Path('C:/ov/city');P=Path(__file__).parent;sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_ground_apron_geometry import exposed_grid_faces
def oracle(solid,retained):
    occupied={p for p in product(*(range(n) for n in solid.shape)) if solid[p]}
    native={p for p in product(*(range(n) for n in solid.shape)) if retained[p]}
    result=[]
    for axis in range(3):
        for direction in (-1,1):
            for p in sorted(occupied):
                q=list(p);q[axis]+=direction;q=tuple(q)
                if q not in occupied:result.append((axis,direction,*p,q in native))
    return result
cases=0;negative=False
for bits in range(256):
    solid=np.array([(bits>>i)&1 for i in range(8)],dtype=bool).reshape(2,2,2)
    for mode in range(4):
        retained=(~solid)&np.array([((i+mode)%4)!=0 for i in range(8)]).reshape(2,2,2)
        actual=list(exposed_grid_faces(solid,retained));expected=oracle(solid,retained)
        assert actual==expected,(bits,mode)
        if any(r[-1] for r in expected):
            assert [(a,d,x,y,z,False) for a,d,x,y,z,_ in actual]!=expected;negative=True
        cases+=1
rng=np.random.default_rng(4819)
for shape in [(1,1,1),(1,5,3),(4,1,5),(3,4,1),(5,4,7)]:
    for _ in range(32):
        solid=rng.random(shape)>.4;retained=(~solid)&(rng.random(shape)>.5)
        assert list(exposed_grid_faces(solid,retained))==oracle(solid,retained);cases+=1
assert negative
report=dict(evidence_class='INERT',scope='Exact occupancy-set oracle for all face directions and retained-neighbour flags; no native/render/runtime acceptance.',cases=cases,burial_flag_negative_rejected=negative,failures=0,source_lf_sha256=hashlib.sha256((ROOT/'art/blender/scripts/city_ground_apron_geometry.py').read_bytes().replace(b'\r\n',b'\n')).hexdigest())
(P/'grid_stream_controls_01.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
