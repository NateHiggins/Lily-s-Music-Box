from pathlib import Path
import bpy,bmesh,json,re,hashlib,math
ROOT=Path('C:/ov/city');P=Path(__file__).parent
names=sorted(set(re.findall(r'Warning: ([^:]+): Could not calculate tangents',(P/'ground_rebuild_05.log').read_text())))
assert len(names)==6
path=ROOT/'art/blender/orison_ground.blend';signature=hashlib.sha256(path.read_bytes()).hexdigest()
bpy.ops.wm.open_mainfile(filepath=str(path));rows=[]
for name in names:
    mesh=bpy.data.objects[name].data;ngons=sum(len(f.vertices)>4 for f in mesh.polygons)
    bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.triangulate(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free();mesh.update()
    minimum=min(float(f.area) for f in mesh.polygons);assert minimum>1e-12,(name,minimum)
    mesh.calc_tangents(uvmap=mesh.uv_layers.active.name)
    assert all(math.isfinite(x) for loop in mesh.loops for x in loop.tangent)
    rows.append(dict(part=name,original_ngons=ngons,triangles=len(mesh.polygons),minimum_area_m2=minimum,tangent_loops=len(mesh.loops)))
assert hashlib.sha256(path.read_bytes()).hexdigest()==signature
report=dict(evidence_class='INERT',scope='Read-only native triangulation control for six actual failed tangent parts; production rebuild/export still required.',native_sha256=signature,parts=rows,failures=0)
(P/'ground_ngon_tangent_control_01.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
