from pathlib import Path
from zipfile import ZipFile
import json,sys
import numpy as np
ROOT=Path('C:/ov/city');P=Path(__file__).parent;sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_ground_apron_geometry import profile_roof_caps
path=P/'ground_incomplete_01_cells.npz';q=np.load(path);xs,ys,zs=[q[k] for k in ['xs','ys','zs']]
first=int(np.searchsorted(xs,45.99))-1;last=int(np.searchsorted(xs,46.01))+1
with ZipFile(path) as z,z.open('solid.npy') as f:
    version=np.lib.format.read_magic(f)
    reader=np.lib.format.read_array_header_1_0 if version==(1,0) else np.lib.format.read_array_header_2_0
    shape,order,dtype=reader(f);assert not order and dtype==np.dtype(bool)
    offset=f.tell();stride=shape[1]*shape[2];f.seek(offset+first*stride)
    solid=np.frombuffer(f.read((last-first)*stride),dtype=bool).reshape(last-first,*shape[1:])
caps=profile_roof_caps(xs[first:last+1],ys,zs,solid,q['roof_profile'],chunk_m=4.)
origin=np.asarray([46.,106.,-.3154999911785126],dtype=np.float32)
def area(points):
    return sum(np.linalg.norm(np.cross(b-points[0],c-points[0]))*.5 for b,c in zip(points[1:-1],points[2:]))
rows=[]
for face in caps:
    if min(p[2] for p in face)<-108.001 or max(p[2] for p in face)>-103.999:continue
    global_points=np.asarray([(x,-z,y) for x,y,z in face],dtype=np.float64)
    early=global_points.astype(np.float32)-origin
    local=(global_points-origin.astype(np.float64)).astype(np.float32)
    old,new=float(area(early)),float(area(local))
    if old==0. and new>1e-12:rows.append(dict(global_points=global_points.tolist(),premature_float32_area_m2=old,local_first_area_m2=new))
assert rows,'Actual collapsed cap must reproduce and pass local-first conversion'
report=dict(evidence_class='INERT',scope='Actual previous-grid cap reproduces premature global float32 collapse and retains positive area after local-first conversion; not a full build/import pass.',cases=rows,failures=0)
(P/'ground_local_precision_control_01.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
