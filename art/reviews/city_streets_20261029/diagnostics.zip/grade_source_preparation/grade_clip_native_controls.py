"""Read independent analytic controls into native closed stock."""
from pathlib import Path
import sys,json,hashlib
import bpy,bmesh
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'art/blender/scripts'));sys.path.insert(0,str(OUT))
from ground_closed_union import build_closed_ground
from grade_clip_diagnostic import box,cases,profile_height,clip_profile_face
bpy.ops.wm.read_factory_settings(use_empty=True)
collection=bpy.data.collections.new('AnalyticSoilCutControls');bpy.context.scene.collection.children.link(collection)
rows=[];negative=False
for name,profile,known in cases:
    if known==0:continue
    sides=[part for face in box for part in clip_profile_face(face,profile)];caps=[]
    for (a,h),(b,H) in zip(profile,profile[1:]):
        stations=[a,b]
        if h!=H:stations += [a+(y-h)*(b-a)/(H-h) for y in (0,1) if min(h,H)<y<max(h,H)]
        stations.sort()
        for c,d in zip(stations,stations[1:]):
            if 0<profile_height((c+d)/2,profile)<1:
                caps.append([(c,profile_height(c,profile),0),(c,profile_height(c,profile),1),
                             (d,profile_height(d,profile),1),(d,profile_height(d,profile),0)])
    mesh,area,contacts,fans=build_closed_ground(sides+caps,collection,known,sloped=True)
    bm=bmesh.new();bm.from_mesh(mesh)
    actual=bm.calc_volume(signed=True);bad=sum(not e.is_manifold for e in bm.edges);bm.free()
    assert bad==0 and abs(actual-known)<1e-6
    rows.append(dict(case=name,saved_float32_volume=actual,known_volume=known,nonmanifold_edges=bad))
    if name=='flat_half':
        try:build_closed_ground(sides,collection,known,sloped=True)
        except AssertionError:negative=True
        assert negative,'Missing cap must be rejected by native manifold proof'
sources=['art/blender/scripts/ground_closed_union.py','art/blender/scripts/city_ground_apron_geometry.py']
report=dict(evidence_class='INERT',scope='Seven native analytic closed-cell controls; not full terrain or runtime qualification.',
            cases=rows,missing_cap_rejected=negative,failures=0,
            sources={p:hashlib.sha256((ROOT/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in sources})
(OUT/'grade_clip_native_controls.json').write_text(json.dumps(report,indent=2)+'\n')
print('GRADED GROUND NATIVE CONTROLS:',len(rows),'cases; missing-cap rejection',negative,flush=True)
