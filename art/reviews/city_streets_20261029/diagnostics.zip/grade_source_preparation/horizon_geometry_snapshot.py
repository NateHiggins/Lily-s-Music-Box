"""Semantic accessor/pose preservation check for the three completed studies."""
from pathlib import Path
import hashlib,json,struct,sys
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent
plan=json.loads((ROOT/'art/data/city_horizon/source_plan.json').read_text())
studies={r['id'] for r in plan['buildings'] if r.get('architecture')}
raw=(ROOT/'game/assets/props/city_horizon_near.glb').read_bytes();chunks={};offset=12
while offset<len(raw):
    size,kind=struct.unpack_from('<II',raw,offset);chunks[kind]=raw[offset+8:offset+8+size];offset+=8+size
doc=json.loads(chunks[0x4e4f534a]);binary=chunks[0x004e4942]
widths={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4};sizes={5120:1,5121:1,5122:2,5123:2,5125:4,5126:4}
def accessor(index):
    a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];assert 'sparse' not in a
    width=widths[a['type']]*sizes[a['componentType']];stride=v.get('byteStride',width)
    start=v.get('byteOffset',0)+a.get('byteOffset',0)
    value=b''.join(binary[start+i*stride:start+i*stride+width] for i in range(a['count']))
    return dict(count=a['count'],type=a['type'],component=a['componentType'],normalized=a.get('normalized',False),sha256=hashlib.sha256(value).hexdigest())
rows={}
for node_index,node in enumerate(doc['nodes']):
    name=node.get('name','')
    if name.split('__')[0] not in studies or 'mesh' not in node:continue
    assert node_index in doc['scenes'][doc.get('scene',0)]['nodes'],'Unexpected parent changes registered study pose'
    primitives=[]
    for p in doc['meshes'][node['mesh']]['primitives']:
        primitives.append(dict(attributes={k:accessor(v) for k,v in sorted(p['attributes'].items())},indices=accessor(p['indices']),mode=p.get('mode',4)))
    rows[name]=dict(pose={k:node[k] for k in ['translation','rotation','scale','matrix'] if k in node},primitives=primitives)
assert len(studies)==3 and len(rows)>12
mode=sys.argv[1]
if mode=='before':
    with (OUT/'horizon_geometry_before.json').open('x') as f:json.dump(dict(studies=sorted(studies),parts=rows),f,indent=2)
    print('Original study geometry retained:',len(studies),'studies;',len(rows),'parts')
elif mode=='compare':
    before=json.loads((OUT/'horizon_geometry_before.json').read_text());assert before['parts']==rows,'Completed study arrays or poses changed'
    result=dict(evidence_class='INERT',scope='Exact semantic accessor bytes and node poses for three completed horizon studies, not whole-scene or runtime acceptance.',studies=sorted(studies),parts=len(rows),unchanged=True)
    with (OUT/'horizon_geometry_comparison.json').open('x') as f:json.dump(result,f,indent=2)
    print(json.dumps(result))
else:raise ValueError(mode)
