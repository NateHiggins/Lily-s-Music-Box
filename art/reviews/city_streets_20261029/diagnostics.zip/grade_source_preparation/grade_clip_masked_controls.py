"""INERT cropped-cell construction, including a preserved internal cavity."""
from pathlib import Path
import json,sys,hashlib
import numpy as np
import bpy,bmesh
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_ground_apron_geometry import clip_profile_face,profile_roof_caps,profile_grid_volume
from ground_closed_union import build_closed_ground
bpy.ops.wm.read_factory_settings(use_empty=True)
collection=bpy.data.collections.new('ReservedSoilCutControls');bpy.context.scene.collection.children.link(collection)
rows=[]
for name,profile,known in [('flat_cavity',[(0,.5),(1,.5)],.5-1/54),
                           ('rising_cavity',[(0,0),(1,1)],.5-1/54),
                           ('at_cell_plane',[(0,1/3),(1,1/3)],1/3)]:
    axis=np.linspace(0,1,4);solid=np.ones((3,3,3),dtype=bool);solid[1,1,1]=False
    source=[]
    for i,j,k in np.argwhere(solid):
        x,X=axis[i:i+2];y,Y=axis[j:j+2];z,Z=axis[k:k+2]
        faces=[[(x,y,z),(x,y,Z),(x,Y,Z),(x,Y,z)],[(X,y,z),(X,Y,z),(X,Y,Z),(X,y,Z)],
               [(x,y,z),(X,y,z),(X,y,Z),(x,y,Z)],[(x,Y,z),(x,Y,Z),(X,Y,Z),(X,Y,z)],
               [(x,y,z),(x,Y,z),(X,Y,z),(X,y,z)],[(x,y,Z),(X,y,Z),(X,Y,Z),(x,Y,Z)]]
        for dim,direction,face in [(0,-1,faces[0]),(0,1,faces[1]),(1,-1,faces[2]),(1,1,faces[3]),(2,-1,faces[4]),(2,1,faces[5])]:
            neighbor=[i,j,k];neighbor[dim]+=direction
            if not 0<=neighbor[dim]<3 or not solid[tuple(neighbor)]:source.append(face)
    clipped=[part for face in source for part in clip_profile_face(face,profile)]
    caps=profile_roof_caps(axis,axis,axis,solid,profile)
    integral=profile_grid_volume(axis,axis,axis,solid,profile)
    assert abs(integral-known)<1e-12,(name,integral,known)
    mesh,area,contacts,fans=build_closed_ground(clipped+caps,collection,known,sloped=True)
    bm=bmesh.new();bm.from_mesh(mesh);actual=bm.calc_volume(signed=True)
    bad=sum(not e.is_manifold for e in bm.edges);bm.free()
    assert bad==0 and abs(actual-known)<1e-6
    rows.append(dict(case=name,known_volume=known,grid_integral=integral,native_volume=actual,nonmanifold_edges=bad))
report=dict(evidence_class='INERT',scope='Three reserved analytic grids with exact cavity subtraction; not full terrain or runtime qualification.',cases=rows,failures=0,
            sources={p:hashlib.sha256((ROOT/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in ['art/blender/scripts/ground_closed_union.py','art/blender/scripts/city_ground_apron_geometry.py']})
(OUT/'grade_clip_masked_controls.json').write_text(json.dumps(report,indent=2)+'\n')
print('GRADED MASKED NATIVE CONTROLS:',len(rows),'PASS',flush=True)
