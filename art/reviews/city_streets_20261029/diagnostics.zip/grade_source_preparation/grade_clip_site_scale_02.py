"""INERT site-scale precision and fixed reservation control, not installed soil."""
from pathlib import Path
import json,sys
import numpy as np
import bpy
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_ground_apron_geometry import clip_profile_face,profile_roof_caps,profile_grid_volume
from ground_closed_union import build_closed_ground
bpy.ops.wm.read_factory_settings(use_empty=True)
c=bpy.data.collections.new('SiteScaleControl');bpy.context.scene.collection.children.link(c)
xs=np.unique(np.asarray(list(np.arange(-140,141,4))+[20.3,24.3,28.3,32.3,92.],dtype=np.float32)).astype(float)
ys=np.asarray([-4.,-3.8,-3.6,-.4,-.1,-.02],dtype=np.float32).astype(float)
zs=np.asarray(list(np.arange(-108,77,4)),dtype=np.float32).astype(float)
profile=np.asarray([[20.3,-.02],[24.3,-.03],[28.3,-.06],[32.3,-.11],[92,-1.0055],[140,-1.7255]],dtype=np.float32).astype(float).tolist()
solid=np.ones((len(xs)-1,len(ys)-1,len(zs)-1),dtype=bool)
for i,(x,X) in enumerate(zip(xs,xs[1:])):
    for j,(y,Y) in enumerate(zip(ys,ys[1:])):
        for k,(z,Z) in enumerate(zip(zs,zs[1:])):
            if 36<=x and X<=44 and -3.8<=y and -8<=z and Z<=8:solid[i,j,k]=False
source=[]
for i,j,k in np.argwhere(solid):
    x,X=xs[i:i+2];y,Y=ys[j:j+2];z,Z=zs[k:k+2]
    faces=[[(x,y,z),(x,y,Z),(x,Y,Z),(x,Y,z)],[(X,y,z),(X,Y,z),(X,Y,Z),(X,y,Z)],
           [(x,y,z),(X,y,z),(X,y,Z),(x,y,Z)],[(x,Y,z),(x,Y,Z),(X,Y,Z),(X,Y,z)],
           [(x,y,z),(x,Y,z),(X,Y,z),(X,y,z)],[(x,y,Z),(X,y,Z),(X,Y,Z),(x,Y,Z)]]
    for dim,direction,face in [(0,-1,faces[0]),(0,1,faces[1]),(1,-1,faces[2]),(1,1,faces[3]),(2,-1,faces[4]),(2,1,faces[5])]:
        n=[i,j,k];n[dim]+=direction
        if not 0<=n[dim]<solid.shape[dim] or not solid[tuple(n)]:source.append(face)
clipped=[part for face in source for part in clip_profile_face(face,profile)]
caps=profile_roof_caps(xs,ys,zs,solid,profile,chunk_m=4.)
expected=profile_grid_volume(xs,ys,zs,solid,profile)
print('SITE SCALE INPUT:',len(source),'faces;',len(caps),'caps; expected',expected,flush=True)
mesh,area,contacts,fans=build_closed_ground(clipped+caps,c,expected,sloped=True)
report=dict(evidence_class='INERT',scope='Site-scale synthetic grid, fixed cavity and authored profile; not installed terrain.',expected_volume=expected,source_faces=len(source),cap_faces=len(caps),failures=0)
(OUT/'grade_clip_site_scale_02.json').write_text(json.dumps(report,indent=2)+'\n')
print('SITE SCALE CONTROL PASS',flush=True)

