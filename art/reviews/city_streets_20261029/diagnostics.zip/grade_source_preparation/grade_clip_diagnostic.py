"""INERT analytic controls for the pending retained-ground roof cut."""
import json, sys
from pathlib import Path
import numpy as np
ROOT=Path('C:/ov/city');sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_ground_apron_geometry import clip_profile_face,profile_cell_volume,profile_height
box=[[(0,0,0),(1,0,0),(1,0,1),(0,0,1)],
     [(0,1,0),(0,1,1),(1,1,1),(1,1,0)],
     [(0,0,0),(0,0,1),(0,1,1),(0,1,0)],
     [(1,0,0),(1,1,0),(1,1,1),(1,0,1)],
     [(0,0,0),(0,1,0),(1,1,0),(1,0,0)],
     [(0,0,1),(1,0,1),(1,1,1),(0,1,1)]]
def volume(faces):
    return sum(np.dot(f[0],np.cross(a,b))/6 for f in faces for a,b in zip(f[1:-1],f[2:]))
cases=[('uncut',[(0,2),(1,2)],1.),('empty',[(0,-1),(1,-1)],0.),
       ('flat_half',[(0,.5),(1,.5)],.5),
       ('two_threshold_rise',[(0,-.5),(1,1.5)],.5),
       ('two_threshold_fall',[(0,1.5),(1,-.5)],.5),
       ('valley',[(0,1),(.5,0),(1,1)],.5),
       ('crest',[(0,0),(.5,1),(1,0)],.5),
       ('plateau',[(0,.25),(.25,.75),(.75,.75),(1,.25)],.625)]
rows=[]
for name,profile,known in cases:
    side=[part for face in box for part in clip_profile_face(face,profile)]
    caps=[]
    for (a,h),(b,H) in zip(profile,profile[1:]):
        stations=[a,b]
        if h!=H:stations += [a+(y-h)*(b-a)/(H-h) for y in (0,1) if min(h,H)<y<max(h,H)]
        stations.sort()
        for c,d in zip(stations,stations[1:]):
            if not 0<profile_height((c+d)/2,profile)<1:continue
            caps.append([(c,profile_height(c,profile),0),(c,profile_height(c,profile),1),
                         (d,profile_height(d,profile),1),(d,profile_height(d,profile),0)])
    actual=volume(side+caps);integral=profile_cell_volume(0,1,0,1,0,1,profile)
    assert abs(actual-known)<1e-12,(name,actual,known)
    assert abs(integral-known)<1e-12,(name,integral,known)
    assert all(p[1]<=profile_height(p[0],profile)+1e-12 for f in side+caps for p in f)
    if name=='flat_half':
        wrong=volume(side)
        assert abs(wrong-known)>.01,'missing-cap control must fail'
    rows.append(dict(case=name,known_volume=known,closed_surface_volume=float(actual),cell_integral=integral))
report=dict(evidence_class='INERT',scope='Eight analytic cells and one missing-cap control; not native source, reserved-site support or runtime qualification.',cases=rows,failures=0)
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
