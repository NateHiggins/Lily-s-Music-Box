"""INERT preflight against the previous saved native/grid, never installation."""
from pathlib import Path
import json,sys,hashlib,time
import numpy as np
import bpy,bmesh
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_ground_apron_geometry import clip_profile_face,profile_roof_caps,profile_grid_volume
from ground_closed_union import build_closed_ground
start=time.monotonic()
paths=['art/blender/orison_ground.blend','art/blender/orison_ground_construction.json','art/data/city_ground_apron/source_plan.json','art/blender/scripts/city_ground_apron_geometry.py','art/blender/scripts/ground_closed_union.py','tmp/orison-ground/orison-ground-cells.npz']
bindings={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
bpy.ops.wm.open_mainfile(filepath=str(ROOT/paths[0]))
original=bpy.data.objects['OrisonGroundClosedUnion']
q=np.load(ROOT/'tmp/orison-ground/orison-ground-cells.npz');solid=q['solid']
profile=json.loads((ROOT/'art/data/city_ground_apron/source_plan.json').read_text())['relief']['west_profile']
profile=np.asarray(profile,dtype=np.float32).astype(float).tolist()
source=[]
for face in original.data.polygons:
    points=[original.matrix_world@original.data.vertices[i].co for i in face.vertices]
    source.extend(clip_profile_face([(float(p.x),float(p.z),-float(p.y)) for p in points],profile))
caps=profile_roof_caps(q['xs'],q['ys'],q['zs'],solid,profile,chunk_m=4.)
expected=profile_grid_volume(q['xs'],q['ys'],q['zs'],solid,profile)
print('PREVIOUS NATIVE CUT:',len(source),'old clipped faces;',len(caps),'new caps; expected',expected,flush=True)
collection=bpy.data.collections.new('PreviousGridCutDiagnostic');bpy.context.scene.collection.children.link(collection)
mesh,area,contacts,fans=build_closed_ground(source+caps,collection,expected,sloped=True)
bm=bmesh.new();bm.from_mesh(mesh)
volume=bm.calc_volume(signed=True);bad=sum(not e.is_manifold for e in bm.edges);bm.free()
assert bad==0 and abs(volume-expected)<.001
report=dict(evidence_class='INERT',scope='Previous native/grid diagnostic only. Fresh street AIR and runtime survey absent; no new installed-terrain acceptance.',
            source_bindings=bindings,source_faces=len(source),cap_faces=len(caps),expected_volume_m3=expected,native_volume_m3=volume,
            pre_storage_volume_m3=mesh['pre_storage_volume_m3'],represented_volume_error_m3=mesh['represented_volume_error_m3'],
            nonmanifold_edges=bad,seconds=time.monotonic()-start,failures=0)
(OUT/'grade_previous_native_review_01_geometry.json').write_text(json.dumps(report,indent=2)+'\n')
print('PREVIOUS NATIVE CUT PASS',json.dumps(report),flush=True)

from mathutils import Matrix,Vector
from fabrication_native_batch import material
for obj in bpy.context.scene.objects: obj.hide_render=True
obj=next(o for o in collection.objects if o.data==mesh);obj.hide_render=False
uv=mesh.uv_layers.new(name='Metres');uv.active_render=True
for face in mesh.polygons:
 drop=max(range(3),key=lambda i:abs(face.normal[i]));u,v=((1,2),(0,2),(0,1))[drop]
 for loop in face.loop_indices:
  point=mesh.vertices[mesh.loops[loop].vertex_index].co
  uv.data[loop].uv=(point[u],point[v])
catalog=json.loads((ROOT/'game/data/runtime_material_sets.json').read_text())['materials']
finish=dict(catalog_key='soil',tint=[1,1,1,1],pigment=1.,normal=.35,roughness=1.)
mesh.materials.append(material(ROOT,'DiagnosticSoil',finish,catalog))
parts=json.loads((ROOT/'game/data/orison_v2/exterior/city_streets.json').read_text())['parts']
with bpy.data.libraries.load(str(ROOT/'art/blender/city_streets.blend'),link=False) as (a,b): b.objects=list(parts)
layout=json.loads((ROOT/'game/data/orison_v2_blockout.json').read_text());frame=json.loads((ROOT/'game/data/orison_v2/exterior/street_frame.json').read_text())
shift=-(next(r for r in layout['doors'] if r['id']=='F01_DOOR_06')['center'][1]+frame['source_threshold_z'])
transform=Matrix.Translation((0,shift,0))@Matrix.Diagonal((-1,-1,1,1))
context=bpy.data.collections.new('RegisteredStreet');bpy.context.scene.collection.children.link(context)
for o in b.objects:context.objects.link(o)
bpy.context.view_layer.update()
for o in b.objects:o.matrix_world=transform@o.matrix_world;o.hide_render=False
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=8
scene.render.resolution_x=1280;scene.render.resolution_y=800;scene.render.resolution_percentage=100
scene.world=bpy.data.worlds.new('DiagnosticWorld');scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.55,.65,.8,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.7
sun=bpy.data.objects.new('DiagnosticSun',bpy.data.lights.new('DiagnosticSun','SUN'));scene.collection.objects.link(sun);sun.hide_render=False
sun.data.energy=3;sun.rotation_euler=(.45,-.35,-.7)
cam=bpy.data.objects.new('DiagnosticCamera',bpy.data.cameras.new('DiagnosticCamera'));scene.collection.objects.link(cam);scene.camera=cam;cam.data.lens=30
views=[('previous_grid_west_end',(100,29,1),(85,27,-1)),('previous_grid_west_junction',(77,36,1.8),(66,24,-.7))]
for label,at,target in views:
 cam.location=at;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
 scene.render.filepath=str(OUT/(label+'.png'));bpy.ops.render.render(write_still=True)
(OUT/'grade_previous_native_review_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Previous-mask visual diagnostic: deliberate absence of fresh street AIR. Soil proxy uses registered maps; no installed surface or artistic acceptance.',views=[r[0] for r in views],city_to_building_native_translation_m=shift,failures=0),indent=2)+'\n')
