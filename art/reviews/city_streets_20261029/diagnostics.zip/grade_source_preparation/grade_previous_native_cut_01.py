"""INERT preflight against the previous saved native/grid, never installation."""
from pathlib import Path
import json,sys,hashlib,time
import numpy as np
import bpy,bmesh
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_ground_apron_geometry import clip_profile_face,profile_roof_caps,profile_grid_volume
from ground_closed_union import build_closed_ground
start=time.monotonic()
paths=['art/blender/orison_ground.blend','art/blender/orison_ground_construction.json','art/data/city_ground_apron/source_plan.json','art/blender/scripts/city_ground_apron_geometry.py','art/blender/scripts/ground_closed_union.py','tmp/orison-ground/orison-ground-cells.npz']
bindings={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
bpy.ops.wm.open_mainfile(filepath=str(ROOT/paths[0]))
original=bpy.data.objects['OrisonGroundClosedUnion']
q=np.load(ROOT/'tmp/orison-ground/orison-ground-cells.npz');solid=q['solid']
profile=json.loads((ROOT/'art/data/city_ground_apron/source_plan.json').read_text())['relief']['west_profile']
profile=np.asarray(profile,dtype=np.float32).astype(float).tolist()
source=[]
for face in original.data.polygons:
    points=[original.matrix_world@original.data.vertices[i].co for i in face.vertices]
    source.extend(clip_profile_face([(float(p.x),float(p.z),-float(p.y)) for p in points],profile))
caps=profile_roof_caps(q['xs'],q['ys'],q['zs'],solid,profile,chunk_m=4.)
expected=profile_grid_volume(q['xs'],q['ys'],q['zs'],solid,profile)
print('PREVIOUS NATIVE CUT:',len(source),'old clipped faces;',len(caps),'new caps; expected',expected,flush=True)
collection=bpy.data.collections.new('PreviousGridCutDiagnostic');bpy.context.scene.collection.children.link(collection)
mesh,area,contacts,fans=build_closed_ground(source+caps,collection,expected,sloped=True)
bm=bmesh.new();bm.from_mesh(mesh)
volume=bm.calc_volume(signed=True);bad=sum(not e.is_manifold for e in bm.edges);bm.free()
assert bad==0 and abs(volume-expected)<.001
report=dict(evidence_class='INERT',scope='Previous native/grid diagnostic only. Fresh street AIR and runtime survey absent; no new installed-terrain acceptance.',
            source_bindings=bindings,source_faces=len(source),cap_faces=len(caps),expected_volume_m3=expected,native_volume_m3=volume,
            pre_storage_volume_m3=mesh['pre_storage_volume_m3'],represented_volume_error_m3=mesh['represented_volume_error_m3'],
            nonmanifold_edges=bad,seconds=time.monotonic()-start,failures=0)
(OUT/'grade_previous_native_cut_01.json').write_text(json.dumps(report,indent=2)+'\n')
print('PREVIOUS NATIVE CUT PASS',json.dumps(report),flush=True)
