# REPORT - V2-CITY-CONTEXT - 2026-10-19

Evidence class: **INERT**. Publication report; no additional acceptance grant.

## Main integration — October 28 UTC

PR **#72** merges at **93e8eaaf84ca02cc0fd3748637e060f2442fec28**. Verified candidate
**a9703c457b55094c4011e95ced41d9a8a0d6b5df** has an exactly identical tree. The frozen
in-place verifier compares all **114** static/tool gates with clean main baseline
**04d72f3a**: **zero regressions**, **17/17 protected paths unchanged**, selector
**v2**, zero design-lint errors and no changed ledger requirements. The three
changed tool-test diffs were read: original source guards remain and additional
negative/geometry controls are substantive. Main retains its unrelated red gates.

The verifier uses **--no-godot**, reusing the separately executed and source-bound
fullscreen imported bench and full schema-2 surface qualification below. It does
not claim a fresh-checkout import/autocrlf run. Candidate JSON/Markdown, raw output
and merge-tree proof are archived under **city_height_batch_verification/** in the
existing skywatch packet. All thirteen preceding surface-packet files are also
verified byte-for-byte against Git **04d72f3a**, with an external publication backup
retained; old PNGs are not duplicated into another archive.

The canonical checkout fast-forwards to main; the fully merged local/remote
**codex/v2-city-relief-20261028** branch is removed. No other worktree/branch is
altered. This publication child changes only this report and the diagnostic
archive/index. It does not alter rendering or gameplay inputs. The city, weather
artistic qualification, individual building studies, unresolved stutter and
remaining V2 work remain open; no whole-game completion or human acceptance.

## Eight-block height repair and surface renewal — October 28 UTC

Branch **codex/v2-city-relief-20261028**, parent **e10c0425**, integration base
**04d72f3a**. Three individual horizon studies remain installed. This batch
repairs the other seven oversized near-city masses; it does **not** complete
their individual architectural studies or the full **149-building** mandate.

| Mass | Previous body / new body (m) | Floors | Proportion reference |
|---|---:|---:|---|
| **site_far_nw** | 38.0 / 16.7 | 5 | Hampton Court, 35-16 79th Street |
| **site_far_n** | 44.0 / 16.25 | 5 | Greystone Apartments; preceding checkpoint |
| **site_far_ne** | 33.5 / 19.8 | 6 | The Towers, 33-16 81st Street |
| **site_far_e** | 41.0 / 23.1 | 6 | Sohmer Piano Factory, 31-01 Vernon Boulevard |
| **site_far_se** | 29.5 / 13.4 | 4 | Elm Court, 34-27 79th Street |
| **site_far_s** | 44.71530952 / 20.5 | 6 | The Chateau, 34-22 81st Street |
| **site_far_sw** | 31.0 / 16.7 | 5 | Laburnum Court, 37-15 79th Street |
| **site_far_w** | 36.5 / 13.1 | 4 | Cambridge Court, 37-14 86th Street |

The existing source plan records primary LPC references/pages and remaining
distinctive features. Storey counts inform authored dimensions, not surveyed
replicas. Courts, projecting bays, differentiated entrances, loggias, mansards,
industrial arches, towers and ornament remain to be individually constructed.
The existing inward-only detail policy leaves plainer outward walls; no final
all-angle architectural acceptance is claimed. Playable ground, footprints,
original V1 source and gameplay/state owners remain unchanged.

Five source tests pass, including unchanged source data, rigid roof-equipment
endpoint vectors/radii, unedited buildings and invalid/stale height controls.
The old native library correctly refuses the new height program before rebuild.
All **335** stocks and dependent equipment rebuild. Final native checks pass
**1,205 bearing** and **2,613 pane** samples at **0.1 mm**. **638** unrelated draws
retain exact decoded arrays and poses against **e10c0425**. Installed city GLBs
shrink **20,185,984 bytes / 196,859 triangles**, **941→935 draws**. This is a
storage/geometry result, not an FPS claim.

Native and imported review first exposes outward-wall camera choices and cropped
assemblies. Retain those attempts; final review selects city-facing façades and
projects all assembly bounds into the actual viewport with a margin. All eight
complete native/imported views were inspected. The final production-loader bench
passes **5,243 checks**, eight real lowered-roof/old-height controls, **1,205**
roof samples, source hashes, imported derivatives, PBR/mips and physical backing;
empty shutdown stderr. Its wrapper binds after final dependency renewal.

The **124-waypoint** occupied route passes in **345 s**, with **4,850 measured
frames**, **3440×1440**, **8× MSAA**, TAA and the same calendar/control schedule
as the preceding relief route. Wall p50/p95/p99/max are
**36.178 / 65.850 / 75.815 / 142.788 ms**, versus
**36.397 / 65.381 / 75.941 / 105.032 ms** before. Main-viewport GPU p50/p95/p99/max
are **14.867 / 21.635 / 23.645 / 26.220 ms**, versus
**15.160 / 21.897 / 23.911 / 25.697 ms**. No meaningful whole-route stutter gain
is established; the worst frame is worse. Residents/traffic remain live and the
earlier baseline predates the three horizon studies, so this is not an isolated
height experiment. Two 100+ ms spikes coincide with **5,083** nodes entering the
tree and **5,081** fewer orphans; one adds ten shader specializations. This is
correlation, not function attribution. Investigate the existing passage activation
timing and staged-publication path next; process/physics monitors are one-second
peaks and viewport GPU timing excludes private views.

The first surface run stops after **10 s**: closure binds equipment exports from
the wrong batch order. Keep that failure. Correct the order to **shells → masts /
aerials / tanks / beacons → closure → elevations**, rerun the last two producers,
and independently prove all **six runtime GLBs byte-identical**. No hash repinning
or guard removal. Native/fixture provenance changes still expire the earlier
wrappers; retain the route as measured same-geometry evidence, not fresh runtime
qualification. Renew the bench and full surface run after preflight passes.

Final surface wrapper: **775 s**, empty shutdown stderr, current source binds.
The test itself writes a schema-2 runtime contract: **39,207 checks**, **zero
failures/unresolved surfaces**, **27,827 draws / 17,013 meshes / 6,324 materials /
527 textures**. Production composition, surface requirements and runtime-owned
teardown pass. **Save reconstruction is NOT_EXECUTED**; unchanged save authorities
reuse their separate evidence. Fire interactions are skipped while their physical
surfaces remain inventoried. No hose input suite is repeated.

All **237** optical captures were inspected via seven contact sheets; seven
representative native-resolution images were also inspected individually. The
published packet is renewed using **publish_v2_surface_packet.py**, preserving
the preceding packet before installing the test-written contract last. This is
technical rendered review, not human acceptance. Dark street exposure, bright
gallery fixtures, near-flat storm ceilings and repeated seasonal cloud silhouettes
remain limitations. No annual-weather, all-area gameplay or whole-V2 completion
is claimed. Candidate/static comparison and merge are separate pending steps.

Diagnostics and original failures: **C:/ov/reports/city_mass_batch_20261028**;
the existing skywatch archive carries the compact packet, provenance and prior
surface publication. Full-resolution intermediate captures stay externally
indexed. Existing ground-recipe binding debt remains as recorded below; no
retained ground was rebuilt or repinned.

## North-block proportion repair — October 28 UTC

Unmerged WIP after **586a0ddd**, still based on main **04d72f3a**. This is a
height/floor repair, not a fourth completed individual architectural study.
The **site_far_n** body changes **44.0→16.25 m**, with five **3.25 m** floors,
one full-height upper setback, and a **16.51 m** roof-cap datum. Greystone
Apartments' documented five-storey hierarchy informs this authored proportion;
its Tudor porches, entrance/courtyard organisation and individual finish study
remain open. The other seven oversized background masses still need repair.

The existing authoring helper projects explicit monotone height landmarks from
the frozen V1 layout. Ground/footprints stay fixed; hardware above the roof
translates without changing endpoint vectors or radii. The source owner rebuilds
all **335** closed native stocks. Every roof consumer validates both the original
consumed source and exact V2 projection before fitting its actual native stock.
Changing a physical source field or height program rejects stale reuse. Five
Python tests include bad-height and changed-program controls. No new runtime
state authority, asset file family or addon is introduced; V1 data is unchanged.

Rebuild shells, joined parapets, masts, aerials, tanks, beacons and elevations
together. The final native elevation checks pass **1,205 support samples** and
**3,489 pane-depth samples** at **0.1 mm**. Four context images and a focused
roof-equipment native image were actually inspected. All **975** unrelated
exported draws across six GLBs retain exact decoded arrays and node poses.
The five installed GLBs together shrink **3,182,120 bytes**; bounded hardware
partitioning adds one draw. This is not an FPS or memory-residency claim.

The renewed **V2CityElevationBench** uses the actual production city loader,
retains the earlier source-parser/apron coverage, and exercises all five installed
asset hashes, native UV derivatives, loaded PBR/mips, triangle collision and
**1,205** actual imported roof contacts. Positive lowered-roof and negative
old-tower-roof probes pass. Final **bench_frozen.log.receipt.json** binds:
**5,213 checks / zero failures**, **19.73 s**,
**3440×1440 fullscreen**, empty shutdown stderr; its final optical image was
actually inspected. The first run's PNG save error remains recorded; the bench
now creates the directory and checks the save result. Camera framing now derives
from the building's actual fixture dimensions. The intermediate camera-bound
wrapper becomes stale when normalizing the final mixed line ending; keep it
and renew rather than repin. These wrappers are
diagnostics, not schema-2 production qualification or artistic acceptance.

Ground reconciliation correctly stops on a pre-existing pavement binding.
The retained-grade plan has five pre-existing stale non-city bindings plus the
new city-native binding. Do not repin those as acceptance. The ground GLB and its
underground reservations are unchanged; a fresh consumed-geometry survey is
needed before rebuilding that historical ground recipe. No ground source was
rewritten after this refusal.

The original **OrisonV2CityClosureTest** completes in **256 s**: **3,846 checks**,
**227 elevation partitions**, **814,611 triangles**, **25 joined parapets** and
**1,205 retained hardware footprint samples**, zero failures and empty shutdown
stderr. Its wrapper still binds after the bench-only camera/line-ending repair.
All **58** real fullscreen captures were inspected via four contact sheets.
The before/after pairs compare roof finishes, not old/new building heights.
This is posed composed-world review, not a walked route or final artistic grant.

The early **114-gate** diagnostic comparison reports a new raw bench camera
coordinate and stale/missing full-surface qualification. The camera is repaired
as above and the renewed spatial audit has **zero NEW reported** references.
The other five existing tool-test failures remain baseline debt, with no new
tool-test regression. This board spans a report edit and is diagnostic; renew
a frozen comparison/candidate check before merging. Full-surface and rendered
review qualification must be renewed; do not waive or repin them. No performance
route or save test is repeated for this passive geometry-only repair.
Original/new diagnostics: **C:/ov/reports/city_mass_20261028**; archive under
**city_north_height_repair/** in the existing skywatch packet. The overall city
and V2 goals remain open.

## Construction update — October 27 evening / October 28 UTC

**Unmerged WIP**, branch **codex/v2-city-relief-20261028**, parent **499ebad0**,
based on main **04d72f3a**. Earlier publication evidence below retains its
original scope; it does not qualify this new construction.

Three of **149** passive buildings now have authored individual studies:
**HORIZON_NEAR_0_0_P0R0**, a stone Italianate adaptation of 21-21 45th Avenue,
has three main floors over a low basement, a seated seven-step stoop, iron rails,
recessed paneled entrance and bracketed cornice; **HORIZON_NEAR_0_0_P0R1** uses
21-42 45th Avenue's four-storey angled-bay vocabulary;
**HORIZON_NEAR_0_0_P2** uses Linden Court's paired-block vocabulary with a genuine
recessed entrance court. Body heights are **10.55 / 13.0 / 12.4 m**. Dimensions
are authored adaptations, not surveys or complete copies of historic ornament.

The existing source plan holds references/pages, floor heights, outlines, bay
counts, entrances and cornice programs. Closed polygonal stocks and mitred
cornice rings follow the bays/court. No rectangular roof spans the court.
Extend existing builders/helper/loader; serialize just three finish overrides.

The native build passes **12,287 pane-depth rays** at **0.1 mm**, closed-stock
checks, **20 parapet seats + 20 outside controls**, and complete exported tangent
checks. Near stock changes **396→398 draws**,
**528,364→529,300 triangles**, **52,485,040→52,641,652 bytes**. Far GLB is
byte-identical. A decoded comparison against **499ebad0** verifies all exported
attribute/index arrays and node poses on **381 other near + 214 far draws**, with
no unrelated added draw. This is geometric preservation, not an FPS claim.

The first imported bench passes **12,472** checks, then **12,474** after explicit
native-asset SHA checks. Both original wrappers remain but are stale after the
subsequent test/geometry changes. Review identifies parapets incorrectly seated
outside the wall line on decorative cornices. Move their footprint inward to
bear over the wall/roof assembly. Final **bench_bearings.log.receipt.json** passes
**12,534 checks / zero failures** in **15.95 seconds**, empty shutdown stderr,
and verifies against current source. Opposing front-face rays prove that actual
parapet bottoms and roof tops meet; outside-wall probes cannot count a decorative
cornice as a roof bearing.
It checks actual imported bounds, panes, terrain, source asset hashes, mapping
and teardown. A ray through the court reaches ground rather than a rectangular
roof. Three final **3440×1440 fullscreen** captures and three final native views
were actually inspected. Stoop/rails, angled bay, wrapped cornice and court read
distinctly. Neutral bench lighting, opaque distant panes and simplified ornament
remain limits. This wrapper is not a schema-2 runtime contract; composed-world,
played-access, human acceptance and full surface renewal remain unproven.

The editor recreates **627** untracked UIDs and **14** normalized-identical import
sidecars. Archive their bytes and verify the known roster, indexed parents,
resolved paths and creation times against this import before removing only that
churn. Two UIDs regenerate for the two edited script owners; none is committed.
The empty pre-import PowerShell pipeline created no file: cleanup additionally
checks the prior archived 627-path roster and 625 unchanged values, without
inventing an earlier file. Cleanup preflight stops are in the tool transcript;
the eventual provenance, changed UID values and empty orphan lock are archived.
No shared stash, reset, bulk staging or unrelated source removal is used.

Diagnostics are **C:/ov/reports/city_studies_20261028**, archived in the existing
skywatch packet under **city_building_studies_three/**. Python geometry tests
pass; physical source retention has no missing/wrong source; reader has **zero
NEW** unread fields. Candidate verification and merge are pending. No save suite
or hose interaction is repeated for passive models/finishes. The earlier terrain
route does not qualify these later building changes.

| Location / issue | Reproduction / severity | Evidence | Repair / verification |
|---|---|---|---|
| Three horizon frontages lack coherent individual proportions | Inspect at source street height; visual high | Explicit floor plans and native/loaded renders above | Three studies implemented and bench-verified; composed-world review pending. |
| Eight near-city background masses dominate the low-rise brief | Review street/roof skyline and elevation inventory; visual high | Existing roof heights **29.5–44.715 m** across eight **site_far** groups | Next: individual period mass/floor profiles and dependent roof equipment together. Preserve accessories' dimensions, playable anchors, frozen V1 source and strict source guards. |
| Remaining **25 near-city + 121 horizon** buildings lack individual study acceptance | Compare repeated generic recipes; visual high | Source roster and earlier captures | Continue reference-based geometry and combined qualification. Three examples do not close the city task. |

---

Branch / HEAD / origin/main / merge-base: **main** / verified candidate
**30f603c3bdd75ab5557cba15c2db4c9b35be1555** / **fa6e8f9762763a0ff369c74ed42aa704b44365e2** /
**fa6e8f9762763a0ff369c74ed42aa704b44365e2**.
This publication child changes documentation and preserves the unmodified final
verification output. No runtime, rendering, asset or helper inputs change.

Worktree clean at end: verification checkout yes; canonical shared checkout no.
Inherited/generated UID, import, receipt, enamel/M08F and unrelated capture
changes remain unowned. Only named owned paths are staged.

Protected 17/17: unchanged versus merge-base. Selector: **v2**;
explicit V1 rollback preserved. Historical raw hash differences are not new work.

Ledger before -> after (blockers):

| Gate | Before | After |
|---|---:|---:|
| FIRST_SLICE_TECHNICAL | 0 | 0 |
| GOLDEN_SHIFT_V2 | 1 | 1 |
| FULL_BUILDING_STRUCTURAL | 27 | 27 |
| FULL_BUILDING_RUNTIME | 25 | 25 |
| PRODUCTION_CUTOVER | 44 | 44 |
| V1_RETIREMENT | 46 | 46 |

Requirements changed: []. City scenery and the source-derived
context camera grant no new played-region, programme or human appearance proof.

All 92 gates, including 80 tools-test suites, complete.
The clean verifier exits 0 with zero regressions, 0 improvements,
zero accepted regressions and zero design lint errors. The ledger intentionally
remains incomplete. Exact results, original exits and all diagnostics are in
**art/reviews/v2_city_polish_20261018/verified/verification.json** and
**verification.md**. Verification uses **--no-godot**: the original canonical
engine runs below bind the identical source pair. The clean checkout ran no
engine and makes no fresh import/cache claim.

All six original Godot jobs complete with zero failures and zero script errors:

| Original run | Actual checks | Seconds |
|---|---:|---:|
| final_surface4 | 39527 | 636.77 |
| final_circulation1 | 90 | 318.08 |
| final_service1 | 360 | 374.73 |
| final_home1 | 909 | 441.54 |
| final_upper1 | 989 | 1127.82 |
| final_landing1 | 41 | 343.44 |

The service run executes 360 checks; 359 are serialized because its final flush
check runs after writing the JSON. Original stdout and matching wrapper retain
that check. Contracts are copied unchanged, never repinned. The independent
**original_qualification_summary.json** validates current fingerprints, original
contract identity and every wrapper/raw-log hash. Canonical packets are under
**art/renders/orison_v2/**; prior packets and failed diagnostics are preserved
under **art/reviews/v2_city_polish_20261018/**.

The primary 25 buildings now have varied sash, curtains and roller shades:
3,682 windows, 3,975 independently inspected closed curtain stocks and 1,205
retained roof-bearing samples. The additive horizon has 124 disjoint footprints:
48 rowhouses, 57 walkups, 18 factories and one commercial accent. Its 12,331
recessed panes, sash frames, cornices and chimney caps are native closed stocks.
This is authored western Queens scenery informed by period sources, not a
surveyed reconstruction. Sources, dates and inspection limits are documented in
**design/V2_QUEENS_1928_CITY_REFERENCE_2026-10-18.md**. No reference photographs
are baked, projected or committed as game assets.

Four disjoint native grade slabs extend to 420 metres outside the retained
ground envelope. The old ground asset is byte-identical. Thirty-six actual
first-hit samples retain the 0.1 mm tolerance and include all building colliders.
The context camera is explicitly source-derived, not a retained player vista.
Native source checks precede the combined composed review; the final loaded
context bench passes 12,500 checks. Dry V2 fog reaches 70..400 metres, humidity
40..300; fog/heavy rain retain 13..58. V1 retains its writer and distances. The
actual-writer visibility bench passes 138 checks.

All nineteen current scoped surface images and seven current standing service
images were inspected. Four native primary-elevation and four final native
horizon previews were also inspected. These reviews concern fit, continuity and
correspondence; they do not grant whole-game photorealism or human acceptance.
The composed inventory is 26,475 draws, 17,441 meshes, 6,135 material instances
and 497 textures, with zero unresolved UV/custom-PBR/loaded-mipmap surfaces.
Existing catalogue maps are reused; no new texture images or material keys.

Runtime inputs: **8b1ba493e78e83c64f5a19e9298ff28acadaa47f8ce88be6a41d9766e5508b0c**.
Surface inputs: **246782ff7adee6f7a7ef51ed359fe887d1afd3b71e617e086ae8ef69714b5709**.
Both match canonical and clean-checkout source **1d41eac1**.

Changed gate files requiring explicit review:

- **M tools/orison_spatial_dependency_manifest.json**
- **A tools/tests/test_city_ground_apron.py**
- **A tools/tests/test_city_horizon.py**
- **M tools/tests/test_v2_surface_requirements.py**

Review: surface provenance adds ten owning native plans/assets/reports and
negative tests that mutate each input. The ground tests independently check
ring area, old-ground reservation and invalid envelopes/depth. Horizon tests
check closed edges, signed volume, entire party-wall segments, actual roof
height and duplicate/invalid footprints. The spatial manifest appends one
inspected camera record with all prior rows unchanged. Three mesh assets use
metric precision to avoid demonstrated UV distortion; texture compression and
mipmap requirements are unchanged. No baseline waiver is accepted.

A composed blind review exposed a timer/tween scheduling race at low FPS.
The isolated real-save-owner diagnostic reproduces the old timer firing while
the same tween is still running; it later finishes normally. Tests now observe
that original tween's finished signal with a bounded frame wait and reject
cancelled/replaced tweens. Production blind/save code is unchanged. Failed
originals remain archived. This is stronger completion testing, not new hand
input or mechanism acceptance.

Changes outside expected city art: the shared director gains a no-op profile
hook for V2's sole fog writer; V1 behavior is retained. The blind review timing
repair resolves an independently reproduced qualification failure. New source
expiry inputs and negative gates bind the actual authored stock.

Open findings: seven leaked Texture RIDs reported at surface shutdown; carried
light hotspots, repeated glazing/timber/shades, coarse artwork, schematic cloud
art and plain outward faces on retained far buildings. Remaining structural and
runtime blockers above, V2 acoustic rederivation, eleven authored Golden Shift
beats, full programme/system proof, human appearance acceptance and explicit V1
retirement remain open. Ignored regional prototypes grant no acceptance.

Decision needed from owner: none for this scoped checkpoint. Human acceptance
and eventual explicit V1 retirement remain separate.

MERGE-CANDIDATE 30f603c3bdd75ab5557cba15c2db4c9b35be1555


## Sohmer factory study — October 28

REPORT — branch **codex/v2-sohmer-factory-20261028**, clean integration base
**8d295207**. Evidence remains **INERT**: technical construction and executed
checks, not human artistic acceptance or whole-city completion.

The east mass **site_far_e** is now a specific six-storey factory adaptation,
using [LPC LP-2172](https://s-media.nyc.gov/agencies/lpc/lp/2172.pdf), pp. 1, 8,
14–15, for segmental openings, selected floor bands and a mansard clock tower.
The source photographs inform form only; no photograph pixels enter the game
or this committed evidence. The 30 x 34 m reservation is retained, not presented
as a surveyed replica or relocation of the actual Sohmer factory.

| Location / reproduction | Severity | Evidence | Repair | Verification |
|---|---|---|---|---|
| East factory, city/roof views | Architectural coherence | Former generic upper setback and rectangular sash did not convey the named factory precedent | Continuous six-storey wall, 300 segmental-headed openings across four elevations, bands above floors 1/2/5, corner piers and two closed panelled portals with glazed transoms | Native and imported focused renders; 2,841 native pane samples; actual portal backing rays |
| Factory roof and tower | Support / continuity | Original guy anchor was carried on the inset parapet being retired | Disjoint roof-extension stock meets the original cap; a local pier preserves the old anchor; new pavilion seats on the enlarged roof | All 1,205 original bearing samples and nine separately filtered tower-foundation samples pass |
| Broad factory roof plate | Finish coherence | Imported image exposed inherited bronze roof stock | Registered bituminous-roof finish on retained cap geometry | Loaded PBR/mip checks and final optical view; no new texture recipe |
| Tower clock hands | Geometry / time | Two hands initially occupied one plane; manual refresh alone could hide a disconnected update loop | Separate plate layers, shared hub, eight independently pivoted hands reading CampaignClock every 0.5 s | Float32 export clearances 7.999–8.003 mm; actual direction, reversal, automatic update, pause/resume and three rendered poses pass |
| Native GLB publication | Tool failure | Direct overwrite raises Windows OSError 22 after native geometry checks pass | Existing validated temporary-export and bounded replacement mode | Original failure/log/source retained; staged export passes; no hand-edited GLB |

Body height remains **23.1 m**, roof bearing **23.36 m**, and pavilion top
**30.94 m**. The pavilion is a corner continuation rather than an unrelated
floating roof object. Retained equipment remains at its original repaired
height/pose; mast, aerial, tank, beacon and shell GLBs are byte-identical to
main. Across all six source families, **971** unedited draws retain exact decoded
arrays and poses. Original V1 layout, playable datums, inventory, residents,
quests, reading, weather and save authorities remain unchanged. These portals
are closed background architecture, not new accessible rooms or interactions.

The native dependency chain rebuilds in order: shells, masts, aerials, tanks,
beacons, closure, elevations. The reused cornice helper is explicitly bound in
the elevation source provenance. Timing/dependency finalization regenerates a
**byte-identical GLB**; earlier native views retain their original file bindings
rather than being repinned. Final imported/source-bound checks follow that
finalization. Raw evidence is under **C:/ov/reports/city_sohmer_20261028** and
archived under **city_sohmer/** in the existing skywatch packet.

The final production-loader bench passes **5,392 checks / zero failures**,
**1,205 roof samples**, **946 draws**, empty stderr. It retains all original
height/old-roof, loaded UV/normal/tangent, PBR/mip and visible/collision checks.
New checks cover real closed portals, tower support excluding the tower's own
underside, four clock faces/eight hands, clockwise directions, out-of-order
calendar return, actual scheduled updates and pause/resume. Full-size body and
clock-detail renders were inspected. Clock timing adds no writer or save fields;
CampaignClock remains authoritative. Bounded timing runs only in the existing
cloud-route diagnostic mode. No new runtime source files or dependencies.

### Measured cost and remaining stutter

All routes use fullscreen **3440 x 1440**, RTX 4080, pinned patched Vulkan,
8x MSAA, TAA, uncapped/vsync off, seed 1928 and frozen June 25, 1929 18:00.
The four cloud-off/on/on/off blocks retain actual movement and door input.
Readback/PNG encoding stays outside measured intervals. Residents/traffic remain
live, so individual tail frames are not an isolated rendering microbenchmark.

| Route | Frames | Wall p50 / p95 / p99 / max (ms) | Main viewport GPU p50 / p95 / p99 / max (ms) |
|---|---:|---|---|
| Main runtime baseline | 4,922 | 35.755 / 64.861 / 75.404 / 101.068 | 14.833 / 21.700 / 23.635 / 26.555 |
| Factory, original reader | 4,901 | 36.080 / 63.968 / 75.009 / 137.491 | 14.760 / 21.706 / 23.648 / 26.235 |
| Factory, bounded reader timing | 4,926 | 35.773 / 64.738 / 75.693 / 114.935 | 14.651 / 21.622 / 23.662 / 26.326 |

Both factory routes pass **124 waypoints / zero failures**, frozen source-before/
source-after hashes. The uninstrumented reader was recovered exactly by reversing
the timing-only patch and matching the **complete original runtime digest**;
its original test source SHA also matches Git **8d295207**. Original receipts
are preserved as historical measurements, not repinned to current code. Final
bench/route receipts bind to the finalized source.

Typical/GPU distributions show no meaningful change, while **after maxima exceed
this baseline**. No FPS or stutter improvement is claimed for the architecture.
The new reader's **410** timed calls measure p50/p95/p99/max **29 / 42.55 / 47.91 /
68 microseconds**, with **two** pose publications over the run. This includes
synchronous campaign binding/read and transform publication, excludes deferred
engine work and diagnostic storage, and does not attribute all graphics/physics
costs. Large cold/door/loading stalls remain open. Passage publication frames
remain **60.868–66.369 ms**, preserving the previous publication repair.

This study spends **10,911,904 runtime GLB bytes**, **98,410 triangles** and
**11 draws** on the four-sided factory/clock. City elevation totals move from
618,935 to **717,345 triangles**, 227 to **238** partitions. It adds three loaded
materials and **zero textures**. These are measured asset costs, not FPS claims.

### Surface renewal and integration boundary

The composed inventory completes in **774 wrapper seconds**: **39,265 checks /
zero failures**, **27,838 draws / 17,024 meshes / 6,327 materials / 527 textures**,
empty shutdown stderr. Its test-written schema-2 production-composition,
surface-requirements and runtime-owned teardown contracts pass. **Save
reconstruction is NOT_EXECUTED**. Unchanged hose interaction is not repeated;
its physical stock remains inventoried. Seven representative actual world
captures were inspected; 237 exist, not all newly artistically reviewed.
Dark streets, strong gallery highlights and the flat storm ceiling remain debt.

The canonical packet is renewed through the existing validated publisher.
Preceding packet bytes are preserved against Git **8d295207** and an external
backup. Four lossless WebP review images decode to exactly the original Godot
PNG pixels; original PNG bytes/hashes remain external. No reference photographs
are committed. Import warnings/627 generated UIDs and 14 EOL-only sidecars were
archived before named cleanup. A stale empty index lock was removed only after
no live Git process, an exclusive-open probe and unchanged metadata checks.

Static preflight found one new test-camera record and stale surface evidence.
The camera is now recorded as TEST_CONTRACT / UPDATE_TEST_FIXTURE; scanner,
classifications and baselines are unchanged. Spatial drift and NEW reader fields
are zero; all five city-source tests pass. The original test assertions and
budgets remain. Frozen candidate **1cb5f104** passes the **114-gate** comparison
with **zero regressions**, all **17 protected paths unchanged**, selector **V2**,
clean changed-document lint and no changed requirement statuses. The one
test-camera manifest addition was reviewed; no scanner or baseline weakened.
Existing unrelated red gates remain red. Verification is in-place with separately
executed source-bound Godot receipts, not fresh-checkout import/autocrlf proof.

Merged through **PR #74**, commit **079b951e5aa105cbee2d042813bd38419f81a168**; its tree exactly matches
the qualified candidate. This final report/archive update changes metadata only;
runtime and test sources remain the executed candidate. The four review images,
original failures, raw measurements and candidate verdict are preserved in the
existing archive, below 50 MiB. No runtime qualification is inferred from this
metadata update.

There are now **four individually developed technical city studies** (three
horizon studies plus this factory), **145** still open across the 149-building
mandate. Height repairs are not additional individual studies. Curbs, bulkheads,
ballast, bridge/station construction, the entrance remodel, weather polish and
human acceptance remain open. Owner decision needed: **none**.


## Hunters Point street-front repair and inspection camera — October 28

REPORT — clean integration base **2467e7e6**, branch
**codex/v2-city-townhouse-20261028**. Evidence class remains **INERT**.

One existing mass, **site_nw2**, now uses a coherent brick Italianate house
composition informed by **21-13 45th Avenue**, Root & Rust, 1871–72:
[NYC LPC LP-0450](https://s-media.nyc.gov/agencies/lpc/lp/0450.pdf), PDF pp. 3–4.
The original **8 × 23.7 m** body and **10.9 m** height remain. Three floors,
three narrow street bays, segmental hoods, one pedimented closed entry and a
four-bracket timber cornice replace the oversized 6.2 m concrete podium.
The plinth is now 0.53 m. The street-level entry adapts the reference's raised
stoop; this is no surveyed replica, relocated historical parcel or new interior.
Reference photographs inform form only and are not committed or projected.

| Location / reproduction | Severity | Evidence | Repair | Verification |
|---|---|---|---|---|
| Northwest low block, street approach | Architectural coherence | Generic upper sash above a warehouse-scale podium | One narrow-front Italianate house with quieter party walls and rear windows | Native review, actual composed street first-hit and rendered street captures |
| Initial isolated camera / frontage | Incorrect experiment | A camera facing the party wall was incorrectly treated as street direction, producing a three-house long-front terrace | Restore the actual narrow street frontage; retain the discarded experiment at WIP **197944bf** | Final composed street view and F8 capture show the single house between its neighbors |
| City source chain | Startup blocker | Original surface run rejects stale closure provenance; closure-only rebuild rejects the upstream plan | Regenerate shells → masts → aerials → tanks → beacons → closure → elevations | Nine preflight fixtures pass; original failures retained |
| F8 detached inspection | Input/support safety | Observer-only residency could abandon the parked body; unrestricted camera input could conflict with protected calls | Existing player input lease, parked-body-first residency, bounded observer additions and interruption cleanup | Actual engine key/mouse dispatch, movement, pointer, pause and protected-call checks |
| Mouse-look test after physics ticks | Test failure | Original **surface_supported**: 39,291 checks, one unchanged mouse-basis assertion fails; contract preserved | Flush synthetic input and sample after rendered frame, retaining the same assertion | Focused 5,134-check diagnostic and final 39,291-check composed run pass; no production input setting changed |

All **1,002** unrelated decoded draw arrays/local poses remain exact. Other five
city GLBs remain byte-identical to main. The seven native sources regenerate
their dependency bindings; generated GLBs are not hand-edited. Elevations move
from **717,345 to 705,821 triangles**, **238 to 239 draws**, and
**72,064,596 to 70,928,092 GLB bytes**. No texture assets are added. Existing
registered PBR recipes, UVs, normals and loaded mipmaps remain authoritative.
The original **1,205 roof samples** and equipment/support poses are retained;
all **2,755** native pane probes pass at the unchanged 0.1 mm tolerance.
Earlier conservative box/slab overlap diagnostics are not physical penetration
proof; their three-house clearance result is not claimed for the final house.

### F8 inspection tool

The tool extends existing ShotCapture, not the legacy V1 free_cam script. F8
enters/returns in developer/debug launch or explicitly enabled rooftop preview.
**WASD** flies, **Q/E** moves vertically, **Shift/Ctrl** adjusts travel,
wheel changes speed, **F** captures a clean image, backtick releases/captures
the pointer, right click recaptures, and **Esc** returns. No collision is applied
to the debug camera. It preserves the parked player pose and its processing
flags, copies the real view, hides the interaction HUD/companion for inspection,
and restores mirrors, residency observation, input ownership and pointer state.
Protected conversations, text owners, active grabs/inspection/seating and pause
refuse entry; incoming protected calls end inspection without stealing input.
Inactive camera allocates no camera/HUD and does no per-frame processing.

Actual Input.parse_input_event tests exercise F8, held movement, mouse look,
wheel, screenshot, pointer release/reacquisition, pause return and incoming-call
interruption. A physics-frame negative control retains support beneath the
parked operator while the observer moves away. These are engine-dispatched
inputs, not OS-hardware or owner feel acceptance. Individual vertical/speed
modifier keys were not separately qualified. Save/load is not claimed here.

The windowed rooftop regression passes **46 checks / zero failures**, including
detached date/operator invariance while flying and complete campaign-state
restoration on exit. The final imported native bench passes **5,405 checks /
zero failures**, **1,205 roof samples**, **947 draws**, empty shutdown stderr.
The surface, roof and bench wrapper receipts independently bind current inputs.

### Measured occupied route and surface renewal

At native **3440 × 1440 fullscreen**, RTX 4080, pinned patched Vulkan 4.7.1,
8x MSAA, TAA, uncapped/vsync off, seed 1928, frozen June 25 1929 18:00,
the current source-bound route completes **124 waypoints / zero failures**.
Its **4,933 frames** yield wall p50/p95/p99/max **35.865 / 63.886 / 75.329 /
104.781 ms**, GPU **14.746 / 21.783 / 23.661 / 26.320 ms**.
The accepted factory baseline's 4,926 frames yield wall **35.773 / 64.738 /
75.693 / 114.935 ms**, GPU **14.651 / 21.622 / 23.662 / 26.326 ms**.
Two intermediate correct-frontage repetitions and their bindings remain in
**supported_performance.json**. Residents, traffic and driver caches remain
live; these results do not demonstrate a general FPS or stutter improvement.
Screenshot readback stays outside measured intervals. A discarded terrace
route's 230.567 ms loading spike correlates with compilation/resource changes;
that correlation does not identify script, physics or asset-loading cost.

The final composed surface qualification passes **39,291 checks / zero
failures**, with **27,839 draws / 17,025 meshes / 6,328 materials / 527 textures**
and empty shutdown stderr. Test-written schema-2 production-composition,
surface-requirements and runtime-owned teardown contracts pass. Save
reconstruction remains **NOT_EXECUTED**. Unchanged hose interaction is not
repeated; its physical surfaces remain inventoried. The canonical packet is
renewed only from **surface_verified**, not the failed **surface_supported**
or the wrong-frontage **surface_bound** experiment. The latter passed technical
checks but did not establish correct architectural placement. One superseded
run was explicitly canceled by its owner; cancellation is not a suite result.

Seven representative final world captures plus the actual street/F8 views were
inspected. This is not artistic review of every capture. Dark streets, strong
gallery highlights and the flat storm ceiling remain presentation debt. Raw
receipts, original failures, source snapshots and repeatable diagnostics are
retained externally under **C:/ov/reports/city_townhouse_20261028**; the existing
review archive carries selected portable evidence with explicit recovery
provenance. Candidate **05715f12** passes the **114-gate** comparison with zero
regressions, all **17 protected paths unchanged**, selector **V2**, clean
checkout and document lint, zero NEW reader fields and unchanged requirement
statuses. Existing unrelated red gates remain red. Godot ran separately through
the lane; the in-place verifier used --no-godot and does not establish fresh
checkout import/autocrlf behavior.

Merged through **PR #75**, commit **3ac65118cbca8f7fe28e4ea2a86fdecea1d23883**.
The merge tree exactly matches the qualified candidate. This following
report/archive change is metadata only; it does not renew runtime evidence.
The evidence archive preserves 1,570 prior members byte-for-byte and records
exact immutable Git recovery for three earlier clock images, keeping the
archive below 50 MiB. Task-owned import churn was archived before cleanup;
an empty stale index lock required a no-live-Git/exclusive-open/metadata check
before its exact-path removal. No other contributor's source was discarded.

There are now **five individual technical city studies**, **144** remaining
across the 149-mass mandate; eight height repairs are separate. The completed
read-only six-building research brief is under
**C:/ov/reports/city_reference_next_20261028/reference_brief.txt**. It recommends
the existing Greystone, Towers, Elm, Chateau, Laburnum and Cambridge reference
masses, excluding this house and Sohmer. It corrects the Chateau address/type
and Cambridge flat-roof end-pavilion precedent; it grants no runtime acceptance.
The entrance remodel, remaining city identities, bridge/station, weather polish,
frame-time spikes, current route/save gaps and owner acceptance remain open.
Owner decision needed: **none**. V2 is not complete.

## Court-apartment batch in progress — October 28

WIP, **INERT**. Base **9896ebe7**, clean 114-gate board captured before edits.
The six-building research brief is being implemented on
**codex/v2-city-courts-20261028**. **site_far_se / Elm**, **site_far_w / Cambridge**, **site_far_n / Greystone**
and **site_far_sw / Laburnum** now have native prototypes. Towers and Chateau
remain unfinished. No additional completed city studies are
counted yet. The owner canceled parallel entrance work and requested one task
at a time; this batch remains the sole construction focus.

Elm has nine front axes, a round-headed stair window, six-over-one front sash
and a seated columned/balustraded portico. Cambridge has thirteen axes, an
arched central light with flat sidelights, a pilastered iron-crowned porch and
a flat roof with a front balustrade. Both use actual shallow, sky-open recesses.
Original rooftop bearings remain supported. On October 28 the owner explicitly
authorized editing legacy roof slabs; subsequent court/roof work need not retain
obsolete slab shapes, but must verify structure, bearings and affected access.

| Reproduction / location | Severity | Evidence | Repair | Verification |
|---|---|---|---|---|
| First pair build, court outline | Build blocker | Mixed Vector2/Vector3 arithmetic fails before export | Use a planar tangent for the planar perimeter | Fresh native build passes |
| Door transom / Cambridge ordinary sash | Native pane failure | New low door probe hits its leaf; Palladian mullions repeat on ordinary windows | Sample the actual transom; restrict mullions to the central stair light | Original pane tolerance retained; all 2,950 pane samples pass |
| New crown courses | Visible shading defect | Actual native renders show inward, black-shaded stock | Correct this new perimeter's winding; retain unrelated geometry | Both sampled crown normals dot outward = 1, zero position error; refined renders inspected |

Final pair native build: **1,205 bearing samples**, **2,950 pane samples**,
zero failures at 0.1 mm tolerance; both open-court negative controls pass.
The focused imported diagnostic completes **5,411 checks**, **1,205 roof
samples**, **946 draws**, zero failures and empty shutdown stderr. Its wrapper
receipt binds the earlier two-prototype inputs, not the later four-building or
additive-material work. Thirteen relevant Python source tests pass and
NEW unread fields remain zero. All **918 unrelated decoded draw arrays/poses**
remain exact; five other city GLBs remain byte-identical to the base.

Elevation totals are provisionally **761,329 triangles / 238 draws /
76,675,332 GLB bytes**, versus base **705,821 / 239 / 70,928,092**. No new texture
or runtime source file is added. This is an increased geometry cost, not an FPS
claim. Composed-world optical review, occupied-route performance, renewed
surface qualification, full candidate gates and merge are **NOT_EXECUTED** for
this WIP. The existing main surface packet does not qualify these changed
inputs. Save/load is not claimed. Native failures, source snapshots and rendered
reviews are retained under **C:/ov/reports/city_reference_next_20261028**.


### Four native forms and shared finishes — October 28 WIP

Greystone now has a fifteen-axis, five-storey gray-brick composition, keyed
Tudor-style doorway, connected stepped centre parapet and a 3 m-deep open rear
court. Laburnum has two 2.8 m-deep entry courts, attached portico decks with iron
crowns and pale arched upper windows. The legacy cap/parapet stock is replaced
where these courts require it; new closed roof panels subtract the real voids.
Original equipment bearing heights and supports remain verified. No new
accessible interior, route, resident, shop or gameplay state owner is added.

Native result: **3,189 panes / 1,205 bearings / 10 wall-return samples**, zero
failures at the original 0.1 mm tolerance. All four sampled crown faces have
outward dot = 1 and zero position error. Native building, entry and roof images
were inspected. The first return-probe tangent was reversed; its failure and
source are retained. Correcting the probe leaves the optically reviewed GLB
byte-identical. **915 unrelated draw arrays/poses** remain exact against the
preceding two-prototype WIP; five other city GLBs remain byte-identical.

Three catalogue-owned periodic PBR families are added: **city_grey_brick**,
**city_slate**, **city_roof_clay**. The latter two are prepared for the unfinished
roof pair, not evidence of completed roofs. All **125 pre-existing material
records remain exact**. The existing additive renewal tool validates and archives
prior construction bindings; it never repins runtime contracts. The catalogue
persistence test initially exposed missing declarations in the layout generator;
only three catalogue entries were added there, without running the world-data
writer. A preserved negative-control reproduction fails the original assertion;
the current persistence test and seven additive-binding tests pass. Thirteen
city-source tests pass; NEW reader fields remain zero. Procedural source maps
have no lettering, photography or baked lighting. Source files/metadata are
marked -text; no new material default is substituted for an existing finish.

Provisional elevation totals: **805,043 triangles / 239 draws / 81,105,472 GLB
bytes**. This increases geometry/asset cost and has not yet been measured on the
occupied route. The new finishes have not yet received imported loaded-mipmap
or composed-world optical qualification. The four-building imported checks,
final six-building world review, performance comparison, source-bound surface
renewal, candidate verification and merge remain **NOT_EXECUTED**. The earlier
5,411-check imported result applies only to its original two-prototype inputs.
This work remains WIP; the active queue still counts only five qualified city
studies and 144 unfinished identities. Reproduction and failure records remain
under **C:/ov/reports/city_reference_next_20261028**.


### Six native forms and imported diagnostics — October 28 WIP

Towers now adds a real 3.8 m-deep court and a seated corner belvedere with
2.4 m internal wall height, twelve open arches, solid jambs and a closed tiled
hip. Its top is **23.61 m** in source coordinates. Chateau replaces the obsolete
sixth-storey perimeter with a five-storey body, six-storey end pavilion,
two-pitch slate mansard and four closed dormers. The roof is actually cut at
the dormers; masonry cheeks, gabled caps and galvanized valley flashing join
the host roof. The existing equipment deck/bearing elevations remain exact.
Its highest corner cap is **22.61 m**. These dimensions are authored adaptations,
not a surveyed replica of the historical buildings.

The first six-building pass caught eight twisted dormer roof quads, with
roughly 4–5 cm surface discrepancies. Rear eave heights now give planar stock;
a planarity assertion and all original 0.1 mm surface tolerances remain. Roof
UVs use horizontal courses and metric downslope axes, with updated exported
tangent guides. Native results: **3,396 panes / 1,205 bearings / 12 wall returns /
74 roof surfaces**, zero failures. Final native whole-building and roof-detail
renders were inspected; those do not constitute owner artistic acceptance.

The windowed native-resolution imported bench now passes **5,557 checks /
1,205 roof samples / 950 draws / zero failures**, empty shutdown stderr. It
checks actual loaded PBR mipmaps/derivatives, roof surfaces and twelve open arch
rays with twelve adjacent solid-jamb controls. Two failed runs preserve an
untyped ray-result declaration in the new world-view test. The first attempted
edit guard did not apply, so the second run repeated the same failure; explicit
Dictionary declarations fix it. Tests and tolerances are not weakened. Nine
new sidecars were configured with the established V2 import policy; other
settings were already correct. Task-generated UID/EOL churn was archived before
named cleanup; an empty orphan index lock was removed only after a no-live-Git,
exclusive-open and unchanged-metadata check.

Provisional elevation cost is **862,859 triangles / 242 draws / 86,784,956 GLB
bytes**, against main's **705,821 / 239 / 70,928,092**. No performance gain is
claimed. New actual-world daylight/dusk viewpoints are derived from source
bounds and require first-hit visibility with real blockers retained. These are
posed construction views, not new player access or calendar progression. Their
execution, the occupied-world before/after comparison, full surface renewal,
candidate verification and merge remain pending. This WIP is not production
qualification; the queue's five qualified studies / 144 remaining identities
remain unchanged until the full batch qualifies.

### Six-building world qualification — October 28, integration pending

The first composed run stopped before startup because the shared material
catalogue addition left the passage-leaf construction binding stale. The
existing strict additive-renewal tool now discovers that explicitly named
fixture; it still excludes runtime contracts. Thirteen tooling tests pass.
Renewal proves all 125 pre-existing material records and 361 shipped maps
unchanged, updates five construction/dependency bindings, and preserves 640
already-stale baseline bindings. Original fixture bytes and failures remain
under **C:/ov/reports/city_reference_next_20261028**.

A second preflight caught missing independent normal-authoring calibration
for the three new finishes. Recipes now declare metre height, OpenGL normals
and their authored strength of 1.0. All twelve regenerated source maps are
hash-identical to their preceding committed versions. Independently
differentiating retained 16-bit heights with the shared normal helper agrees
within one 8-bit quantization code. No renderer default or test was weakened.

The first actual city review completed 5,196 checks with four failures: its
Chateau perimeter probes extended above the five-storey shaft into the new
mansard. The generator now records the actual **17.2 m shaft top** separately
from the retained **20.5 m deck**. The composed review adds 74 physical roof
face/normal probes, retaining its 100-micrometre tolerance. Posed day/dusk views
use the existing forced-lighting diagnostic and restore its environment flag,
director processing and real campaign presentation afterward. The original
minute-only views had retained the actual nighttime celestial direction.
Neither version seeks the campaign clock or grants player roof access.

Final executed evidence on the patched Vulkan engine at fullscreen 3440×1440:
**bench_six_shaft.log.receipt.json** records 5,557 imported checks, zero
failures; **city_diag_six_shaft.log.receipt.json** records 5,270 city/camera
diagnostic checks, zero failures; **route_six_shaft.log.receipt.json** records
124 waypoints, zero failures. **surface_six_shaft.log.receipt.json** accompanies
the test-written schema-2 runtime contract: **39,427 checks**, zero failures,
27,842 draws, 17,028 meshes, 6,335 materials and 536 textures. All four runs have
empty shutdown stderr. The canonical surface packet was independently
validated and published with the previous packet preserved. Production
composition, surface requirements and runtime-owned teardown pass;
**save reconstruction remains NOT_EXECUTED**. Unchanged hose input was skipped;
its physical surfaces remain inventoried.

All eighteen new street/day/dusk city captures and seven full-run packet
images were inspected. Roof silhouettes, real courts, dormers and retained
equipment are visible in composition. Exterior exposure remains dim; the
low-contrast storm ceiling, entrance remodel and final artistic acceptance
remain open. These posed construction views do not establish new playable
access, annual sky acceptance or complete city coverage.

The matched main route and current route hold the same calendar, weather,
resolution, 8× MSAA and TAA, with live NPC/traffic variation. Across 4,933 before
and 4,913 after samples, wall-time p50/p95/p99/max is
**35.865/63.886/75.329/104.781 → 35.869/64.465/75.609/171.141 ms**;
main-viewport GPU is **14.746/21.783/23.661/26.320 →
14.929/21.596/23.647/25.830 ms**. Frames over 100 ms rise from one to four.
The largest current spike coincides with first passage loading, 2,299 added
resources and 20 mesh pipeline compilations, while its main GPU time is 14 ms.
That is correlation, not isolated attribution. Driver caches are uncontrolled;
process/physics counters are one-second peaks, and private viewports are not
included in main GPU timing. **No stutter improvement is claimed.** Raw frame
tables, settings checks and outlier context are retained in
**six_route_comparison.json** and **six_route_spike_context.json** externally.

Archive consolidation, full static candidate comparison and integration remain
pending. The active queue remains at five integrated city studies / 144
remaining until that checkpoint is merged. This work does not complete V2.

The first clean candidate **7f301c66** passes the 114-gate main comparison with
zero regressions, unchanged requirement statuses, 17 protected paths unchanged
and selector V2. Godot was executed separately as recorded above; in-place
verification does not qualify a fresh checkout. The sole changed tooling-test
file adds two discovery controls without relaxing existing assertions.

Evidence is consolidated into the existing **art/reviews/skywatch_20261027/**
archive and manifest, under **city_courts/**. All original non-image members
remain exact; 33 historical images are byte-verified against immutable main
**9896ebe7** and have exact archive/member/hash recovery records. Eighteen new
posed images, two native roof details and an original failed-crown image retain
lossless decoded pixels. The first overlarge packing attempt is retained as a
diagnostic failure; it did not overwrite the repository archive. The previous
canonical surface packet is byte-verified against that same main commit.

The owner then requested immediate file cleanup. Separate checkpoint
**f3252a3f** replaces 25,740 historical navigation source copies with three
indexed archives; original logs, verdicts and raw hashes remain. Astra packet
validation passes before and after; the installed surface packet still binds
and validates. No Godot rerun is needed for that evidence-only move. Final
post-cleanup static comparison and integration remain pending; the existing
city-count queue is not yet promoted.

PR **76** is merged at **dee9e28b6be95584c9fd43148fffa36a6bda6655**. Its tree
matches candidate **faf0c1ec7e7d95826ff2a47c6eb5e8221cedce44** exactly. Final
clean in-place verification passes the 114-gate comparison with zero regressions,
all 17 protected paths unchanged, selector V2 and no requirement-status changes.
The canonical checkout was fast-forwarded onto main. The queue now counts
eleven integrated individual studies and 138 remaining; height repairs are
separate. Stutter, exterior lighting, dramatic/annual skies, save reconstruction
and human acceptance remain open. The owner's immediate file-size cleanup is
now explicit housekeeping priority before another construction batch.


## West frontage construction checkpoint — October 29

**INERT**, isolated **C:/ov/city**, branch **codex/v2-city-20261029**,
starting **3ea80715bd201738d5566dea18bc17d4353ca867**. Preserve the eleven
integrated individual studies. First bounded target: open the west foreground
from the existing front walk by re-siting seven complete passive assemblies;
refit their actual foundations and regenerate vacated ground. The larger road
regrading, Manhattan skyline, bridge and station remain separate unfinished work.
No Orison/arcade/shop/bar/tent access or simulation authority is relocated.
The west north-footway remains closed at the existing works boundary.

Issue/evidence log under **C:/ov/reports/city_west_20261029/**:

| Issue | Evidence | Disposition / verification |
|---|---|---|
| Native study read stale object matrices | Original script, log and bad-pose JSON retained | Update the Blender dependency graph before reading poses. Corrected source study opens four westward near-city rays; this is not runtime proof. |
| Fresh worktree import cache | **import1.log.receipt.json** and stderr | Required second import completes without script errors. Initial failures retained. |
| Fullscreen flag retained 1280×720 viewport | **before_route.log.receipt.json**, frame JSON | Existing native-window script confirms 3440×1440 on the next diagnostic; both routes complete 124 waypoints. |
| Ignored engine pin absent from fresh worktree | Official-engine route receipts | Existing canonical pin copied read-only into city worktree. Earlier routes remain diagnostics; patched-engine baseline and candidate comparison pending. |
| Closure guard rejects changed authoring-plan hash | **build_closure.log** | Rebuild shell/closure dependencies through their owners. Elevation and shell GLBs remain byte-identical; source provenance is renewed by construction, not by repinning runtime receipts. |
| Foundation builder rejects stale grade discovery | **build_city_foundations_01.log** | Fresh brokered **grade_owner_survey_01.log.receipt.json** passes 581 aligned boxes, zero failures. No assertion or tolerance relaxed. |
| Ground build catches old bar reservation bindings | **build_orison_ground_02.log** | Replay the existing bar exporter; all 32 construction boxes, 18 air reservations and registration compare exactly. No bar authority or geometry changes. |
| Native context/framing rejected visually | **native_final_01/** and **native_final_02.log** | Preserve both, including exact review scripts. Include the retained public slab and installed masonry export; require first-hit ownership for the relocated pocket and Cambridge views. |
| Imported frontage metric and translated townhouse probe failures | **imported_bench_01.log.receipt.json** and original stderr | Default UV quantization stretched small barricade charts by up to 6.07%; use the existing asset-specific full-precision policy. Translate the existing cornice probe with its assembly, preserving tolerances. **imported_bench_02.log.receipt.json** completes 5,567 checks / zero failures, including 1,205 real roof bearings and loaded maps/mips. |
| First played route expires during cold startup | **west_frontage_01.log.receipt.json**, failed test-written contract and exact executed source | First movement receives one physics frame in 7,526 ms, with no wall contact. Preserve failure; record forty rendered startup frames separately before unchanged controller deadlines. **west_frontage_05** passes; its largest recorded startup frame is 7,038.711 ms. |
| Native retry launcher did not execute its scene | **west_frontage_02.log.receipt.json** and stderr | Wrapper exit zero has no route output or test-written contract; rejected. Reissue using the proven JSON batch argument path. |
| Resident-inventory assertion after normal streaming | **west_frontage_03.log.receipt.json**, failed contract and executed source | Original 24 road/door waypoints pass. Preserve failure; require all 13 cells at initial composition, record initial/settled residency, then exercise unchanged actual controller routes. No streamer edits. **west_frontage_05** passes, with 13 cells in both recorded snapshots. |
| Courtyard centres are not body undersides | **west_frontage_04.log.receipt.json**, failed contract and executed source | Nine fifth probes targeted voids in individually authored buildings. Preserve all four passing perimeter probes; derive the fifth from a real imported bottom triangle instead. **west_frontage_05** passes all 115 probes with exact owners/points recorded and the same 0.1 mm tolerance. |
| Surface posed-view type inference failure | **surface_final_01.log.receipt.json**, stderr and executed city-review source | Test-only Variant comparison required an explicit bool. Gracefully close only the exact city test window; exit zero with no qualification contract is rejected. **city_parse_01.log.receipt.json** then parses all three affected test sources; **surface_final_02** passes after the fix. |
| Existing 2.4 m WestNorthWorks still blocks the actual view | Existing V2 street boundary source | Replace only that span with a 1.35 m native timber barricade at its exact 0.36 × 5.30 m footprint; retain its identity and closed route. Imported UV/basis/PBR/mip and exact visual/collider bounds pass. **west_frontage_05** passes the actual walk/jump closed-boundary control. |

Current placement source and runtime projection preserve all building mesh stock,
UVs and materials. **native_final_04/** reopens current source assets and checks
1,205 rooftop bearings, 23 positive closed foundation unions and seven filled
vacated plots, with zero failures at the original 0.1 mm tolerance. The retained
public slab/masonry context and all seven native renders were inspected. This
is native geometry/appearance review, not runtime or artistic acceptance.

The new barricade has 87 closed stocks, 15 actual pavement-contact probes and
40 board/carrier contacts. Its export is 2 draws / 2,996 triangles; exported
tangent agreement exceeds 0.99999996. Existing registered timber/iron maps are
reused. Other hoardings and marker-beacon count remain; only this beacon seats
on the lower cap. No photographic pixels or generated lettering are introduced.

Ground now has 2,647 bounded parts / 10,700 triangles, compared with the earlier
2,099 / 6,084 source totals; the main apron has 14 primitives / 2,783 triangles.
These are geometry counts, not measured FPS or a performance gain. The exact
patched baseline passes 124 waypoints at native 3440×1440, 8× MSAA and TAA:
wall p50/p95/p99/max **36.084/64.304/76.588/132.502 ms**; main-viewport GPU
**14.917/21.912/23.875/25.663 ms**, 4,871 samples. Raw frames and wrapper remain
in **patched_before_route/** and **patched_before_route.log.receipt.json**.
No uncontended-machine or isolated-cause claim is made.

The barricade integration is covered by fresh **grade_owner_survey_02.log.receipt.json**: 581 boxes, zero failures and fixed inputs. Its source-driven replay completes without relaxed guards. All six rebuilt installed GLBs compare byte-identical to the preceding native-reviewed geometry (**grade_replay_02_asset_comparison.json**). The test-written schema-2 **west_frontage_05/west_frontage_contract.json** passes
159 checks and 39 actual-controller waypoints with fixed runtime inputs and
empty stderr. The original crossing/door hands, west walk, unfiltered sightline,
restored-blocker negative control, 115 imported-body underside probes and seven
vacated-grade probes pass. The existing closed works boundary stops actual
forward input at x = -19.589 m despite a real 0.619 m jump. Initial and settled
arcade snapshots both retain 13 cells; no streaming, shop or bar authority changes.
This is narrow played qualification, not passive-lot or save reconstruction proof.

The actual fullscreen street and restored-blocker captures were inspected.
The opened strip is visible beside the retained frontage/lamp/traffic/works.
Distant generic stock and dark street exposure remain presentation limitations;
this checkpoint adds no Manhattan or bridge-view acceptance.

**patched_after_route.log.receipt.json** passes the same 124 controller waypoints,
with 4,769 raw frame samples. Calendar, conditions, resolution, MSAA/TAA, weather
source, render-source hashes and mirage parameters compare exactly. Using linear
quantiles from the raw data:

| Whole-route measurement | Starting commit | City candidate |
|---|---:|---:|
| Wall p50 / p95 / p99 / max (ms) | 36.084 / 64.304 / 76.588 / 132.502 | 36.347 / 68.883 / 78.502 / 110.111 |
| Main GPU p50 / p95 / p99 / max (ms) | 14.917 / 21.912 / 23.875 / 25.663 | 14.410 / 21.865 / 23.705 / 26.591 |
| Samples exceeding 50 / 100 ms | 1,203 / 3 | 1,387 / 2 |

These are mixed results, not a speedup: p95/p99 wall tails increase while the
maximum decreases. The same-process west-facing ABBA control gives wall medians
36.013 / 31.883 / 29.764 / 29.112 ms (original / placed / placed / original),
which does not establish a consistent placement gain. Main GPU excludes private
viewports and rendering counters retain their global scope. Live NPC/traffic
and driver caches are uncontrolled; screenshot readback is excluded. The forty
recorded startup frames include a 7,038.711 ms stall, separately from travel and
warmed samples. **measured_city_comparison.json** retains quantile method, per-block
cost/counters and the largest route spikes. No proposed triangle/draw budget is
presented as measured performance, and no new body LOD is claimed.

**surface_final_02.log.receipt.json** completes in 860 s: 42,530 checks,
zero failures and empty stderr. Its test-written schema-2 production composition,
surface requirements and runtime-owned teardown contracts pass. All 1,033 actual
foundation partitions match native fitted bounds and identical visible/collision
stock. Loaded inventory: 28,351 draws, 17,537 meshes, 6,337 materials, 536 textures;
zero unresolved surfaces. Nine actual fullscreen images, including the new
barricade diffuse/grazing views, are inspected and published through the existing
surface-packet publisher. Unchanged fire-hose interaction is explicitly skipped;
save reconstruction remains **NOT_EXECUTED**. No old runtime receipt is repinned.

Eight installed city/roof-equipment/horizon GLBs compare byte-identical with the
starting commit (**retained_city_asset_parity.json**); completed architecture,
proportions, UVs and materials are retained. Geometry is placed through one passive
assembly helper; collision and fittings follow. Native foundation/ground/apron
outputs are regenerated through their existing owners. The only additional art
family is the source-owned low timber works body, with registered materials.
Bar reservation boxes, occupied-air volumes and registration compare exactly;
only their construction bindings change. No apartment, companion, Tardi, weather,
campaign clock, narrative, save, shop or traffic authority is edited.

Owned import cleanup archives/restores 1,658 EOL-only sidecars and removes 627
own generated untracked UIDs; no semantic import change is restored. The two new
GDScript UIDs are staged and absent from origin/main. The only precision-policy
addition is the demonstrated new barricade exception; the spatial manifest adds
five reviewed records while preserving every prior record. No gate logic or
tolerance is relaxed. Final LF-only source-plan normalization preserves JSON
values and the normalized binding; its exact native-review raw input and
normalization witness are archived without repinning any receipt.

Clean construction candidate **04f155c4818ae3de8b6fb65eef2c69369ccd3ba8** passes the complete clean in-place verifier in **C:/ov/city**: 114 gates/tests, zero regressions, zero improvements, all 17 protected paths unchanged, selector **v2**, zero design-lint errors and no changed requirements. The verifier uses **--no-godot** to reuse the separately executed source-bound native/imported, played and full-surface runs. Its generic canonical-checkout wording refers here to this isolated worktree; no canonical prologue checkout is verified or modified. Fresh final-checkout/autocrlf behaviour is outside this in-place comparison. Existing project
records preserve original failed logs, exact executed scripts and raw
measurements under **city_west_frontage_20261029/** in the existing skywatch
archive; 2,011 earlier members/hashes are verified unchanged. Previous surface packet bytes
are preserved externally and recoverable from the starting Git revision.
No additional individual building, requirement or artistic acceptance is claimed.
Manhattan, road regrading, bridge/station, waterfront construction, new body LODs
and the remaining 138 individual studies are still open.


### Management record for this checkpoint

REPORT - V2-CITY-WEST-FRONTAGE - 2026-10-29

Branch / HEAD / origin/main / merge-base: **codex/v2-city-20261029 / 04f155c4818ae3de8b6fb65eef2c69369ccd3ba8 / 3ea80715bd201738d5566dea18bc17d4353ca867 / 3ea80715bd201738d5566dea18bc17d4353ca867**.
HEAD above is the verified construction; its following publication changes only
this report and the existing diagnostic archive/index. Runtime/rendering inputs
remain identical, with a source-Merkle witness in **publication_inputs.json**.

Worktree clean at verification: **yes**. Protected **17/17** unchanged; selector
**v2**, explicit **ORISON_BUILDING_ROOT=v1** rollback retained. Ledger blockers
before -> after: **[7,8,110,42,134,136] -> [7,8,110,42,134,136]**;
requirements_changed: **[]**. No additional human or requirement acceptance.

All 114 baseline comparisons have zero regressions. Existing debt remains:
ledger **INCOMPLETE**, plus the interaction-implementor, interaction-prompt,
M11C1 source-ownership, M11C2 export and completeness tool-test failures. Reader
has zero NEW unread fields; spatial/systemic/period and the physical surface
gates pass. The verifier flags only the spatial manifest as a changed gate file;
its five appended records were individually reviewed, with every earlier row
unchanged. The separate import-policy list addition was also reviewed against
the preserved 6.07% default-compression failure. No waived regression or suite.

Godot results are the original wrapper receipts/test-written contracts named
above, not typed exit-code claims. Native and posed review are INERT; played
frontage is narrow runtime proof; full-surface qualification is technical only.
Save reconstruction, whole-city completion and human artistic acceptance are
not executed or granted. Full file changes and all gate results are preserved
in **candidate_verification/verification.json** inside the existing archive.

Changes outside the immediate street assets: bar reservation *bindings* and
global surface evidence require renewal after native grade construction. Their
geometry/authorities remain unchanged. Other generated native reports renew
dependency bindings rather than introducing duplicate art or new material keys.

Integration remains separate from the active prologue. The independently pushed
prologue **8634333dd4f8dcf353e3c18f7b90f6eff2056c1b** changes face presentation and
the V2 shadow budget to eight. This city comparison retains the starting 32-slot
lighting settings. Reconcile that setter and renew combined-source qualification
at future integration; do not mix these profile baselines or treat either
branch's receipts as proof of the combined world. No merge into main here.

Decision needed from owner: **none for this city checkpoint**. Remaining city,
LOD, lighting/sky artistic and frame-tail limitations are recorded above.

Last line: **BLOCKED main integration pending coordinated prologue reconciliation and combined verification; isolated city construction is technically qualified.**

### Eastern plaza construction in progress — 2026-10-29

Evidence class: **INERT**. Starting checkpoint **8f7d81f305b33d35676952c7baeb7bec36c502be**;
original integration base **3ea80715bd201738d5566dea18bc17d4353ca867**.
The next bounded construction is a 75 m elevated station east of the installed
Orison, with four tracks on each of two levels, two island platforms per level,
public U-stairs, transfer mezzanine and extended jointed sidewalks/curbs.
The source adapts contemporary PSC station proposals to the alternate geography;
it is not a surveyed reconstruction. Original building bodies are retained and
seven eastern assemblies move as units to open the plaza. No train service or
calendar authority is introduced.

Native batch 05 exports **361,820 / 65,944 triangles** in near/far bodies from
**11,767 closed source stocks**. These are asset counts, not measured rendering
cost. Reopened native review 01 checks actual treads, standing headroom and road
clearance and renders platforms, stairs, canopy and both replacement LODs.
The retained diagnostic logs, executed sources and images are currently under
**C:/ov/reports/city_transport_20261029/**. Original build 03 fails on the native
Vector-length call and is retained; later builds correct it. Current source
replay, composed soil/foundation support, runtime collision/access, loaded maps,
LOD transitions, timing and full surface renewal remain pending. This section
grants no implementation completion, runtime qualification or artistic acceptance.

Imported diagnostics retain the original 180 s import timeout and original
bench 01 failure (missing output directory, rejected equal-count LOD buffers,
default compressed-chart errors), including its eventual wrapper timeout.
The corrected bench 03 completes **193 checks / zero failures**, with clean
stderr, loaded PBR mip chains and retained UV/tangent tolerances. Precision
exceptions are limited to the two new station GLBs: the original compressed
near charts stretch **99.97%**, and the far charts **9.98%** with **3,888** bad
tangent derivatives. Their uncompressed imports pass without tolerance changes.
At **3440 x 1440**, actual visible rendering counters report **361,820 near /
65,944 far triangles**, **30 draw calls** each. The ordinary 75-degree view
selects the far body; a 5-degree view at the same pose restores the near body.
This proves isolated per-view selection and counts, not a city frame-time gain.
The first composed grade survey reaches production startup at **131,941.716 ms**
but its final source digest exceeds the 180 s wrapper ceiling; no completed
survey or runtime acceptance comes from that run. A long-wrapper rerun is
required. This cold startup is retained as a performance observation rather
than hidden in steady-state averages.

Subsequent native framing review replaces overlapping sleeper/stringer stock
with seated stringers, web tongues, riveted angles and segmented columns at
actual seat plates. Deck separation becomes **5.30 m**, with a declared empty
rail envelope **2.80 m wide / 3.80 m high**. This is an authored clearance, not
a historical rolling-stock measurement. The raised upper deck/canopy and longer
upper stair flights export **396,356 / 73,856 triangles** in near/far bodies.
Reopened native review 04 completes **8,682 checks / zero failures**, including
actual stringer/sleeper/rail bearing faces and the sampled empty rail envelope.
These new bodies supersede the earlier imported counts for current qualification;
their imported, route and timing checks remain pending.

Native composition 01 checks **1,205 retained roof bearings**, **23 closed
foundations**, **12 ground/paving locations** and **120 soil samples below
station footings**, with zero failures. Framing revision 08 preserves all
**2,389** ground stock records exactly; fresh extraction also preserves all
**3,398** classified native masks and the survey's runtime-input digest.
This permits reuse of the unchanged static-box/pose discovery from completed
grade survey 02; it does not reuse visual acceptance of the earlier station.
Provenance and native products are regenerated through their builders, without
rewriting a test receipt. The composed player run 01 completes the retained
frontage checks but fails its third live entrance attempt before the station:
the partially closed leaf's hinge-side contact is beyond the test stance's
reach. The corrected test walks closer; door and player authorities are intact.
The second startup is **130,848.863 ms**, so the earlier spike cannot yet be
attributed solely to a cold cache. No city startup or frame-time gain is claimed.

Pre-expansion route 03 completes **216 checks / 128 controller waypoints / zero
failures**, including both levels, both islands and the street return. Its
schema-2 test-written receipt and exact executed sources remain under
**transport_route_03/**. The owner subsequently requests removal of artificial
walking limits and a temporary distance wall, deferring the narcoleptic bed
return. This is a new exterior-access authorization, not acceptance of earlier
closed-frontage behaviour or of the whole city.

The revised V2 owner retires the short street-end works and seven shed closure/
hoarding/notice actors. Native scaffold roofs, lapped posts/beams, floor and work
lights stay in their existing frame; the rebuilt five-partition export has
**155 source parts / 91,926 triangles**, and its nine tool checks pass. Native
renders are inspected before runtime renewal. One temporary invisible physics
cylinder limits horizontal travel to **450 m from the front-door threshold**;
no player-position clamp, clock, narrative, save or bed-return writer is added.
Existing physical city buildings and shop access controls stay authoritative.
The planned wider controller tour follows real street gaps around the distant
blocks; source-footprint path planning is INERT guidance until actually walked.
New boundary, scaffold and extended-area qualification remain pending.

The first expanded run exposes another real travel limit: the existing safety
owner rescues the normally walking player at its former **240 m** fallback,
recording **429 recoveries** in failed **open_exterior_02**. The city now
registers the actual imported apron footprint through the safety owner's
existing exemption API. Non-finite and below-world recovery remain owned there.
The initial registration attempt assumes that owner already exists and asserts
during composition in **open_exterior_03**. Its own verified GUI is closed
cooperatively; wrapper exit zero is not a pass and no runtime contract exists.
Both original failures, executed sources and cancellation explanation remain.
The corrected city owner binds the safety node's actual creation and removes
only its own exemption on retirement. A transformed-section boundary diagnostic
completes **13 checks / zero failures** in **open_ownership_04**; this does not
replace the running occupied-world walk or its controller negative control.

Native composition review **03** omits the unmounted west barricade, retaining
its independent native-stock checks, and includes the actual five scaffold
partitions at their installed transform. Its Blender render overlaps part of
**open_exterior_04**. Any raw frame timings from that run are diagnostic under
concurrent load, not isolated rendering performance or a before/after claim.

Expanded occupied-world run **open_exterior_04** completes **228 checks / 164
normal-controller waypoints / zero failures**, with clean stderr and its own
schema-2 **city_exterior_contract.json**. It walks through the former closures,
both station levels/islands, real street gaps to **280 m west and east**, and
back. Safety recovery counts remain unchanged. Separate airborne controller
fixtures contact the distance wall at five angles with maximum centre distances
**449.669–449.711 m**; disabling only that wall admits **453.499 m**. Original
pose/layer and all preceding exemption memberships are restored. These fixtures
do not prove a continuous ground route to every point on the450m circle.

The run takes **993 s**, reports production startup **149,737.450 ms**, and
records **38,371** street-walk frame samples at **3440×1440 / MSAA8 / TAA on**.
Wall median/p95/p99/max are **7.950 / 48.358 / 63.266 / 102.052 ms**; main-view
GPU median/p95/p99/max are **3.804 / 16.736 / 21.265 / 24.948 ms**. Varying
distance/residency and concurrent diagnostic work preclude a speed comparison.
The distant captures expose repetitive shallow background facades and unfinished
streets; opening access does not qualify them as completed architecture.

Isolated station bench **05** completes **193 checks / zero failures**, clean
stderr. With uncapped90-frame cases, MSAA8 and **TAA off**, the imported body
uses **30 draws**, **396,356 near / 73,856 far triangles**, and mounts in
**609.684 ms**. Forced-near/far GPU medians are **0.634 / 0.566 ms**, repeated
**0.592 / 0.549 ms**; wide/narrow projection selects far/near bodies independently.
This measures the station, not occupied-world performance or artistic acceptance.
Native composition03 also completes with zero failures. Fresh grade discovery,
ground binding replay and the complete surface packet remain pending before a
coherent construction checkpoint is committed.

Fresh grade survey **03** passes **573 aligned boxes / zero failures / 210 s**,
with production startup **140,245.149 ms**. Native extraction03 still yields
**3,398** classified records. The full native replay preserves all **3,451
retained solid bounds**, **3,288 surface exclusions**, **57 occupied reservations**,
the constructed soil grid and all five exported foundation/ground/apron/horizon
bodies exactly. Fresh source records differ in provenance and generated collision
names. **open_replay_identity_03.json** independently checks these identities,
the original walk's runtime-input digest and all **15** bound programme files.
All match. The original test-written228/164 contract and inspected native03
renders are retained unchanged; the witness does not manufacture a new receipt.
Foundation inventory is **1,049 parts**, so the composed review's older1,033
literal is corrected to the actual native/export fixture. Its retired-barricade
capture is replaced by the open frontage. The physical-import gate now passes
with **359 retained sources**, and the **66** precision-policy imports pass.
The full surface renewal remains pending.

### REPORT - V2-CITY-TRANSPORT-CONSTRUCTION - 2026-10-29

- Branch **codex/v2-city-20261029**; preceding HEAD **8f7d81f3**;
  origin/main / merge-base **3ea80715bd201738d5566dea18bc17d4353ca867**.
  Construction is published separately from the pending qualification update.
- Worktree clean at this construction boundary: **no**. Owned generated import
  line-ending/UID churn is retained until the last Godot run; a scoped cleanup
  archives it and preserves the three new script UIDs. No canonical checkout
  or outstanding prologue changes are included.
- Protected **17/17 unchanged**, checked against the merge-base; selector **v2**
  with explicit V1 rollback retained. Ledger **7/8/110/42/134/136 → same**;
  no requirement status changes are claimed.
- Gates: full **open_board_01** records all114 checks and the original failures.
  Its four untracked-model/import findings are subsequently resolved: physical
  import retention passes **359 sources**. The two stale full-surface packet/
  rendered-review findings remain open. Reader **0 NEW**, spatial **clean**;
  no other gate regresses against the captured clean-main board.
- Runtime: **open_exterior_04** test-written contract **228 checks / 164
  waypoints / zero failures**; native/imported measurements and exact reuse
  witness are detailed above. Fresh survey03 passes; current rendering inputs
  stay frozen for the pending full surface renewal. No complete surface pass
  is claimed for this construction commit.
- Expected file boundary: native city/scaffold source and exports, eastern
  placements, additive station owner, exterior boundary owner, affected reviews
  and fixtures. The grade exporter is extended for actual station ground stocks;
  the precision catalogue adds only two demonstrated station import exceptions;
  two reviewed test records are appended to the spatial manifest. These tool
  changes and shared city mount were coordinated with the prologue chat.
- Open findings: full surface/candidate qualification; long startup and frame
  spikes; repetitive distant stock, unfinished streets, bridge/yard/waterfront
  work and remaining **138 of149** individual building studies. Train service,
  the later sleep/bed event and human artistic acceptance remain unimplemented
  or ungranted. The window-depth request stays queued; the reserved entrance
  authoring and all interior/companion/Tardi/weather/clock/save owners stay out
  of this checkpoint.
- Decision needed from owner: **none for continued implementation**. The city
  renewal waits through the shared lane. No main merge is requested or performed.

BLOCKED integration qualification pending; bounded construction checkpoint only.

Next-street discovery, not construction acceptance: fresh survey03 measures the
existing **STREET_ORISON_01** road box at **−0.10 m**, **9.144 m** across and
**41.1 m** long; its kerb boxes reach **+0.12 m**, with retained footways at zero.
The traffic source owns junction positions **−69.6 / +68.8 m**. These datums and
the installed threshold/shop approaches must be reconciled with actual new road,
sidewalk and intersection construction. Opening the exterior and adding station
paving does not by itself complete that continuous street section.

Surface renewal01 reaches preflight and fails before composition in **20.7 s**:
the two pavement fixtures still bind the pre-expansion shed source. Earlier
four-fixture checking missed this downstream dependency; the original failed
wrapper receipt/log remain preserved. Independent projection proves all seven
removed actors are outside the slab: the sole consumed shed mask is the retained
**ShedTurnFloor**, exactly unchanged. Native reopening verifies **34 parts**, all
**48 masks** (including34 masonry masks), and closed volume **27.583769631 m³**.

The existing pavement inspector now reconstructs those shed masks explicitly.
A read-only negative control shifts the floor **5 cm** and supplies a matching
fresh whole-file hash; the consumed-mask guard rejects it. Reviewed provenance
is refreshed without changing the pavement body. Native street-detail replay
passes **187 closed stocks / 224 supports**; fresh diffuse/grazing/end renders
are inspected. All paving exports remain byte-identical. Full preflight then
finds the retired works fixture's dependent pavement pin; its native replay
passes **87 closed stocks / 15 contacts**, with its unmounted body unchanged.
Both source-only failures are retained, without a fabricated runtime contract.

Downstream grade provenance is replayed through the builders again. All **ten**
fixtures from the actual surface suite pass **surface_all10_preflight_03**;
**13** binding-preflight tool tests pass. **open_replay_identity_04.json** matches
the original runtime digest,15 programme inputs, paving/retired-works/five grade
bodies, soil cells and all retained/exclusion/reservation bounds. There are zero
semantic material/shader changes. The original228/164 contract remains untouched;
the corrected full surface renewal is still required.

Full renewal02 completes in **936.14 s** with **42,548 checks / two failures**.
Its test-written contract is **failed**, preserved unchanged. The exhaustive
technical inventory has **zero unresolved surfaces**, covering **28,807 draws /
17,993 meshes / 6,336 materials / 536 textures**; this numerical pass does not
override the failed contract. Both failures are the new shed-clearance rays.
The associated nine-waypoint controller trace completes successfully.

The first ray ends at the player's arrival and used the default all-body mask;
the second aims through retained shop geometry. The corrected review excludes
the player from architecture rays, retains the shop, and ends its diagonal at
**x=21** outside the shop while still crossing former hoarding footprints. It
also retains the old rays as actual-collider controls, whose identities must
be confirmed in the next run. No production collider, controller mask, floor
or shop authority changes. The failed executed source is archived separately.
Reader **0 NEW** and spatial **clean** after the test correction. Corrected
renewal03 is held unarmed for the agreed short prologue review batch.

Qualification update, 2026-10-29: renewal03 subsequently runs through the shared
lane with the pinned patched Vulkan engine, fullscreen **3440×1440**. Its
original test-written schema-2 contract passes **42,550 checks / zero failures**;
wrapper duration **982.26 s**, empty stderr. Production composition, surface
requirements and runtime-owned teardown pass. Save reconstruction is explicitly
**NOT EXECUTED**. The exhaustive inventory has **zero unresolved surfaces**:
**28,807 draws / 17,993 meshes / 6,336 materials / 536 textures**. These are
inventory totals, not simultaneous rendered-frame counts or a performance budget.

Both retained negative controls identify the actual obstruction: the first old
ray hits **Player**, the diagonal hits **StreetAndBodega / ExteriorInstances /
SHOP_BODEGA / Collision**. Corrected architecture rays exclude the player's RID
and avoid the retained shop; all nine controller waypoints reach their targets.
Only the test probes changed; the original failed02 contract remains unchanged.
The primary surface packet publishes this fresh03 contract, exact raw-log
hashes and eight actually inspected representative captures. Its source digest
is **03d19f893139075c93187f3d717c10b50b48066034b2cedc579c5a35e6770e30**.

Startup remains **137,108.727 ms**. The earlier open-route timing tails and
isolated station measurements remain as reported, without a new speed claim.
Actual captures show open west/scaffold routes, station structure, retained
entrance/arcade and unchanged interior surfaces. Dark exposure, generic distant
stock, incomplete continuous streets and lighting highlights remain visible.
This is technical qualification of a bounded construction checkpoint, not
whole-city completion or human artistic acceptance. The remaining **138/149**
building studies and bridge, yard, steam, waterfront and street work stay open.

After the final city run, scoped cleanup archives **1,658** owned EOL-only import
changes and **627** generated untracked UIDs, preserving all three new committed
UIDs. No meaningful import changes are discarded; the runtime digest remains
**c0965c4726903e59895bfc080e659d8f3f95d47174121b3af8c05c99668b01dc**.
No further city Godot process is queued during the prologue's next focused run.
No main merge is requested. Candidate static verification follows publication.

Candidate verification subsequently passes at
**5c28bb902c4e719cd4b9f5016dac72bcd0f04fde**, against fetched main
**33e60f149f3bf348b05562e0ae3ac5499b7114af** and the original merge-base
**3ea80715bd201738d5566dea18bc17d4353ca867**: **114 gates, zero regressions,
zero accepted regressions, zero changed requirements**, clean checkout,
**17/17 protected unchanged**, selector **v2**, zero design lint errors.
The known main ledger/tool-test failures remain baseline debt. The verifier's
in-place mode runs in this **isolated city worktree**, despite its generic
“canonical checkout” wording. It deliberately uses **--no-godot**; the original
source-bound surface03 and open-route04 receipts above supply their separately
scoped runtime evidence. Fresh-checkout import/autocrlf is not tested here.
The additive spatial manifest records preserve prior rows; its two new station
test coordinates do not grant access or completeness acceptance. No main merge.

Inventory clarification: **TASKS.md F-RELOCATION** and the October23 started-work
record identify the film tent as a **native candidate with installation and
access unqualified**. The current runtime still mounts three apartment
projectors. These owners remain untouched; this city checkpoint does not claim
an installed or route-qualified film tent. Coordinate its intended bar-side
placement before later street work occupies that approach.

Next bounded construction target remains the street between the existing
traffic junctions. Read-only source topology places them at native city
**x=−69.6 / +68.8 m, y=−19.322 m**. The eastern nine-metre traffic corridor
overlaps station pad edges at **x=73 m**, and its crossing must be cut through
the current station paving. Fit the road, curb returns and protected pier
islands to the fixed traffic/entrance/access datums before claiming a continuous
street. This discovery is not a new collision or construction pass.

## Continuous street construction — October29, in progress

Evidence class: **INERT**. Starts from qualified city checkpoint **f734a173**;
this section does not renew its runtime evidence after geometry changes.

The native source now adds a **207 m** carriageway at the retained **−0.10 m**
datum, two fixed-axis traffic junctions, **2.5 m** curved curb returns, jointed
sidewalks and protected station-pier islands. The existing central road and
public slabs remain separate owners. Station paving is cut at the crossing;
its general underside becomes **−0.30 m**, with the existing footing-top seats
retained. Roads and new sidewalks share that underside so their curved-edge
clearances do not create unsupported bedding gaps.

The eastern west sidewalk would be **0.62 m** wide at the retained row. Its
curb is inset **1 m**, yielding **1.62 m**, while both existing traffic lane
centers and all traffic timing/behaviour remain unchanged. All lamps, entrances,
bar/shop/arcade approaches and reserved external deliveries keep their owners.
Model A and gaslamp prototype intake belongs to the prologue chat; this batch
does not duplicate those assets.

Original native review01 fails with **265** curb-bearing findings. It exposes
two construction defects: straight cross curbs placed on the carriageway side,
and discarded on-plane vertices in polygon subtraction. Both are repaired;
failed native sources/geometry are preserved externally. Review02 retains
**170** findings from a separate review-tool error: imported native matrices
were read before dependency-graph publication. The corrected loader verifies
saved local translations before applying the city transform. No bearing
tolerance is relaxed. Review03 passes **2,424 checks / zero failures**, and all
five actual native renders are inspected. The current street body contains
**12,112 near / 4,224 replacement triangles**. Station geometry02 independently
passes **8,682 checks / zero failures**, without claiming new station renders.

Native views show seated limestone curb courses, continuous asphalt, jointed
concrete, the narrowed-but-passable east sidewalk and protected pier bases.
These diagnostic views omit the installed Orison/arcade/full ground context;
their visible central gap and background void are not final world appearance.
Actual imported UV/TBN/mip, frame costs, loaded LOD transitions, played access,
ground-clearance replay and renewed surface qualification remain pending.
The original failed logs and executed source snapshots are retained under
**C:/ov/reports/city_streets_20261029/**. No main merge is requested.

Subsequent source roster preflight finds four missing far curb partitions:
near/far **28/24**. Long replacement curb courses had been assigned solely by
their midpoint. Both bodies now split at the same **16 m** spatial boundaries,
with an explicit identical material/chunk-roster guard. The final native body
has **36/36** matching partitions and **12,472 / 4,848 triangles**; native
review04 passes **2,506 checks / zero failures**, with five renewed actual
renders inspected. Whole replacement bodies are retained. This supersedes
the preceding native triangle count, not the retained failure history.

The new passive street owner uses the existing **SurfacePass.weather_surface**
exterior adapter on its three local catalogue finishes. No weather logic or
authority changes. The isolated benchmark checks loaded source maps/mips and
that existing adapter binding, plus frozen source hashes at entry and exit.
Its wide/narrow street LOD diagnostic isolates one unchanged visible partition
so frustum culling cannot masquerade as a detail-selection result; repeated
forced near/far timings still cover the complete street family.

Original import01/02 wrapper receipts complete in **341 s / 7.03 s** with zero
script errors; second stderr is empty. The first benchmark attempt **does not
start**: wrapper **73** rejects another worktree's process between batch
children. No benchmark pass or runtime contract is invented for that refusal.
A single replacement import/benchmark batch is queued after native review04;
the actual shared holder remains authoritative. Reader **0 NEW**; one additive
test-coordinate record preserves all **11,000** preceding manifest rows.
Physical import retention, fresh grade survey, terrain replay, played tour and
new full surface/candidate qualification remain pending. The prepared tour adds
both junctions, cross-street walks and the eastern pinch to the existing station,
entrance/crossing and wider exterior programme.

## Research coverage correction — October29, audit in progress

Evidence class: **INERT**. The owner asked whether **all** construction/material
research had been reviewed. Complete coverage had **not** been established
before the new street section was authored. Further affected design choices
are held while the compiled packets are actually read and reconciled. Existing
native checks do not cure that coverage gap or qualify the provisional layout.

Already reviewed: applicable Bible/DOCS/AGENTS, current city plans and regional
reference, native fabrication/UV/PBR/loaded-map requirements and current asset
owners. The following records distinguish the new audit from that prior work:

| Packet / exact source | Coverage at this update | Consequence |
|---|---|---|
| **art/docs/research_1927_construction.md**, compared with the identical canonical copy | Newly read fully | Legacy Midwest1927 typology is not evidence for Queens1928 street materials or grades. |
| **C:/ov/reports/industrial_ground_research_20261028/**: **READ_FIRST.txt**, **reference_brief.txt**, **kit_schedule.csv** | Authored text/CSV newly read; named plates pending | Limestone remains the existing coping key, not proof of bluestone. Reconcile actual old curb/coping faces, provide bedding and draining gutters; do not duplicate existing hardware. |
| **C:/ov/reports/site_grade_research_20261028/**: site study, datum register, both CSVs, cross-section follow-up and archive targets | Authored text/CSV newly read; diagrams/primary plates pending | Western central descent is the preferred AU study, not a historic survey. The flat prototype has not satisfied that view/grade direction. Preserve separate threshold, road, bar, boiler, traffic and water frames. |
| **C:/ov/reports/facade_window_research_20261028/**: **AUDIT.md**, **candidate_inventory.md**, **source_locators.txt**, all99 **window_schedule.csv** rows | Authored text/CSV newly read; elevation figure pending | Record seven bathroom-window conflicts, opposing-room opening,18 trim/pier metadata intersections and basement/canonical discrepancy. Preserve installed floors/interiors; these are not city-scope repair permissions. The Oct29 prologue entrance intake supersedes the audit's dated candidate-search result. |
| **C:/ov/reports/research_agenda_20261028/**: agenda and questionnaire/decisions | Newly read fully | Owner prioritizes descending Manhattan view, later bridge reveal, industrial Queens and geographic order with compression. Exact proposed levels remain unselected. A distinct **city_next_six_20261028** packet also requires reading. |
| **C:/ov/reports/city_continuity_research_20261028/** | All eight authored documents/CSV read; relevant source figures pending | Separate passenger yard E/NE, freight transfer W/SW and workshop/residential pockets. Steam belongs to credible plant/heating sources; passive beacon/tank component counts are not active lights/tank counts. Construction, cladding, occupancy and illumination have separate dates; no completed Chrysler crown at opening. |
| **C:/ov/reports/city_next_six_20261028/** | Brief, read-first, selection and complete roof-equipment CSV read; complete source JSON structurally reviewed, contact sheet and source plan viewed | Hampton, Germania, Robbins, Scheffel, Engine258 and Ottendorfer are distinct proposed adaptations. All76 stocks and85 equipment records are accounted for; registered hardware endpoints, radii and rectangles agree with CSV after one X offset. This is source consistency, not native fit. |
| **C:/ov/reports/storefront_research_20261028/** | All three authored documents/CSV read; figures pending | Preserve four arcade trades and street bodega/bar approaches. Joinery ranges are proposed fits, not surveyed apertures; no exterior rain awning inside arcade. Founding dates do not date surviving decor. |
| **C:/ov/reports/gaslight_research_20261028/** | Both authored documents read; external patent/source figures pending | Gas-fed electric-style crooks are deliberate AU construction. Preserve fixture/clock owners and separate municipal versus house supply. Paint remains dielectric, wear causal, vents and service access physical. Prologue owns current lamp intake. |
| **design/MATERIAL_PROMPT_SHEET.md**, **WALL_TEXTURE_PROMPT_SHEET.md**, environment dossier merge errata | Fully read/re-read | Production templates contain century-old wear,1930s/1960s examples and a legacy numbering prompt; these are neither1928 facts nor exceptions to the no-lettering rule. Causal wall overlays differ from homogeneous tiling layers. Historical light-budget and missing-bodega claims were corrected by errata, not current performance measurements. |
| Bridge, elevated/supplement, first individual-building packet, traffic and sightlines/chronology | All narrative briefs/registers/CSVs now read; relevant full source figures still being inspected | Bridge granite is distinct from limestone; two bridge elevated tracks differ from the eight-track plaza station. The supplement's reported27.432m width supersedes34m as a historical claim. Preserve eleven current architectural studies; the earlier six-court packet's open-work counts are dated. Traffic braking/headway numbers are analytical proposals, not current played crossing results. |

The external **city_streets_20261029/research_coverage.json** tracks exact paths,
hashes and incremental status; it is a coverage ledger, not a duplicate research
handbook or acceptance evidence. Historical facts, source observations,
recommendations, AU choices and measured installed constraints remain separate.
The benchmark waiter subsequently ends **73 after30min**, with nothing started;
no city Godot job remains queued during this research reconciliation.

The incremental inventory is now **50 entries:48 fully read/re-read, two
structured inventory reviews; zero missing paths**. The second structured
review accounts for all **78 fitted roof contacts** across the six court masses,
including bulkhead-cap and parapet seats, full footprint bounds and source
registration. Finite/planarity and cross-register checks find no inconsistency.
This method does not imply literal reading of every duplicated polygon vertex,
or renew native bearing proof. Relevant figures remain an explicit open coverage
item; inspecting a contact sheet does not establish full-resolution plate review.

| Current decision | Research reconciliation | Construction consequence |
|---|---|---|
| Flat207m street prototype | **Contradicts preferred central-west descent direction**, though its exact replacement grades remain AU/provisional | Reconcile whole west road/junction/walk/building-base surfaces, traffic support and view corridor together before qualification. |
| New curb top+.12m/width.16m and4mm joints | **Provisional**; original coping reaches+.1525m and.37m width, and source New York specification has blank dimensions | Resolve actual end/face transitions, bedding/haunch and gutters. Other cities' detailed specifications are comparisons, not Queens standards. |
| Asphalt/concrete/limestone keys | **Supported as installed catalogue choices**, not proof of historic wearing courses or bluestone chemistry | Keep physical scale and loaded-map review; no silent renaming of limestone as bluestone/granite. |
| Shortened two-level/eight-track station | **Supported structural hierarchy; authored dimensions and access adaptation** | Preserve declared scenic compression; exact1928 numeric levels/switchwork remain unresolved. No historical-as-built claim. |
| Painted structural iron via **iron_neutral** | **Contradicted optical response**: generated runtime set inherits metallic.65 | Correct owned coating response and review actual native/loaded appearance; bare-metal tint alone is insufficient. |
| Rail **metal** and sleeper **wood_dark** | **Provisional substitutes**: actual generated sets use galvanized appliance maps and visually locked walnut furniture maps | Inspect actual loaded maps, not only **catalog_mapping.json**. Decide suitable existing substance or catalogue correction before accepting rail/sleeper finish. |
| Existing traffic and shop/access owners | **Supported installed constraints** | Preserve gentle crossing and current identities; prologue retains Model A/gaslamp intake. No city-wide traffic/supply simulation follows from research. |

Approved fail-closed engineering work adds the six transport/street
plan/native/construction paths to **tools/v2_surface_evidence.py** and the existing
source-expiry regression, retaining all prior bindings. All12 native fixtures
are actually preflighted: **11 pass; city_elevations fails stale
orison_v2_city_shells.gd dependency** after the additive street mount. The original
result remains **C:/ov/reports/city_streets_20261029/native_preflight_all_01.txt**.
No fixture is repinned to conceal it; affected qualification remains pending.
The surface-requirements unittest module completes **42 tests / zero failures**
in **393.981s**, including six individual authoring-source expiry mutations.
This is static tool verification, not a Godot run or surface acceptance.

### Bounded compiled-research review completed

All13 authored city packets and both linked material/wall prompt sheets are now
reviewed, with **48 read entries plus two complete structured inventories** and
**55 named figures/contact sheets actually viewed**. The coverage JSON records
exact files, hashes and method. Selection covers the street/grade/industrial
sections, primary bridge section/tower/approach, station/bent/opening evidence,
both architectural rosters, storefront survivals and vehicle-version references.
It excludes duplicate exports, unrelated runtime captures, rejected Decker stock
and unselected raw OCR/archive pages. Contact sheets remain identified as such.
This closes the compiled-guidance review, not authentication of every linked
original. Caption-only, inaccessible and unacquired originals retain their limits;
fine future asset details still require their relevant original plate.

Actual owner tracing corrects the coping interpretation: legacy source records
name **limestone**, but **build_street_paving_details.py** and the installed
**game/data/orison_v2/street_paving_details.json** replace its cap with registered
**concrete**. Its physical cap spans+.12..+.1525m, width.37m, on the.34m original
curb. New work must fit that installed section/material, not silently promote
the legacy label or the researcher's recommendation to installed truth.

The selected AU grade keeps the actual central occupied slab level and introduces
a smooth western crest beyond x=-20.3m, then approximately1.5% descent through
the complete west junction. This is a fit-driven adaptation of studyB, not its
unadopted numeric table or a surveyed1928 grade. Bar lobby source x4.3..5.9,
east crossing/arcade/bodega, entrance and boiler relation retain their existing
datums. The shared traffic-owner coordination is complete: prologue reports no
overlap and agrees to the bounded surface adapter, preserving all stock and
simulation owners. Its future ModelA wheel-stock seam remains untouched.

Material correction is now authored but unbuilt/unqualified: structural iron
uses an explicit dielectric response; rail uses worked iron instead of galvanized
appliance maps; sleepers use structural timber instead of visually locked walnut
furniture. These changes need native and loaded review before acceptance.

### Graded street and material construction — native checkpoint

The207m block now contains actual graded near/replacement bodies. Its AU crest
uses X/height anchors **(-20.3,0),(-24.3,-.01),(-28.3,-.04),(-32.3,-.09)**,
continuing at1.5% to **(-92,-.9855)**. West junction reference height is
**-.6495m**, road surface **-.7495m**; the central/eastern installed approaches
remain at their existing datum. Prisms split at every grade break and16m chunk
boundary, preserving planar surface faces. The coordinated traffic adapter
changes only surface height/basis, parked-collider pose and audio height;
stock normalization, speeds, yields, turns, arrival/contact and clock remain.

New buried curb bodies, concrete bedding and concrete caps are constructed.
Caps seat at+.12..+.1525 relative to local grade. Two-metre transition stocks
meet the retained.34m curb/.37m cap section before narrowing to the new.16m
body/.19m cap. Actual carriageway width follows the installed9.144m section,
resolving the1mm difference from the traffic table's rounded far bound without
changing that simulation table. Gutters/drain integration still remain open.

Build06 succeeds, but original native review06 records **180 failures**:
duplicate bedding overlaps retained station paving, and tiny render partitions
were tested as separate physical cap stones. Its executed sources/native/GLBs
are preserved in **native_failed_06_sources.zip**, alongside original logs and
test-written checks. New bedding is cut away from retained slabs, and curb
stocks on those slabs seat at the actual slab top. Bearing probes now cover
each complete physical stone before render-chunk division, retaining the
three-sample threshold. Short curved stones no longer split into accidental
slivers at unrelated straight joint stations.

Native review07 passes **4,029 checks** and all seven saved views are inspected.
Review08 additionally verifies body embedment beneath the bounded soil-air
clearance: **4,775 checks / zero failures**. Buried paving bottom is now-.40m;
only actual road/walk surfaces generate air clearance, not their buried bedding.
The graded road's.30m body depth exceeds the maximum.24m height difference
across16m, leaving embedment beneath the stepped clearance. This is construction
geometry arithmetic, not fresh soil/runtime support proof.

Final street bodies contain **20,064 near /8,256 replacement triangles**.
Corrected station materials are rebuilt; native review passes **8,682 checks**,
with all nine new actual renders inspected. All seven street08 renders are also
inspected; pixel comparison finds none byte-identical to07, so no unchanged-image
reuse is claimed. Native views retain near/far bodies, matte painted structure,
bare worked-iron rails and rough structural timber. They omit installed Orison,
arcade, soil and foundations; floating context/voids are not composed acceptance.

Both current native fixtures preflight successfully; reader02 reports **0 NEW**.
A single import/street-bench/station-bench batch is queued through the broker
after native review, with frozen sources and the pinned patched engine. The last
observed live holder is the bodies checkout's ResidentWalk. No loaded-map,
collision, LOD-cost, fresh terrain, played-route or surface pass is claimed yet.

### Loaded diagnostic attempt and western terrain join

The actual **import_04.log.receipt.json** records a completed import in22.42s,
with zero script errors. The subsequent **bench_03.log.receipt.json** records
a180.13s timeout, not a benchmark verdict. Its extra arguments put **--** before
the wrapper-appended scene, so Godot launched the default title scene and treated
the requested benchmark scene as a user argument. The original batch, executed
test/owner snapshots, logs and receipt remain in the external street diagnostics
directory. No timings or loaded-surface result are inferred from that attempt.

The corrected **street_bench_batch_04.json** uses the existing environment-only
family selector and leaves the scene among engine arguments. Its broker waiter
is62172, queued22:44:27Z; the latest observed holder remains the bodies
ResidentWalk. Street/station assets and benchmark inputs remain frozen while
that actual waiter runs. A separate station-material invocation will follow;
the aborted batch never reached its station row.

Read-only terrain inspection identifies a further construction requirement:
the old retained grade remains flat at-.02m, and western outer relief starts
only at building-frameX290m. Merely clearing narrow air volumes over the new
descending road/walk would leave raised parcel edges and an approximately1m
step at the207m street body's western end. The terrain connection must continue
the selected western descent and join street ends/back edges before that block
can be described as coherently walkable. Existing foundation seats and occupied
room reservations remain authoritative; this finding does not authorize moving
interiors or treating mask bounds as exact solid geometry.

### Prepared terrain cut — controls, not installed terrain

Prologue confirms no overlap in the ground/apron builders and agrees to the
bounded join while preserving occupied datums and the entrance threshold.
The shared authored western soil profile now matches the street crest with
building-frameX/height anchors **(20.3,-.02),(24.3,-.03),(28.3,-.06),
(32.3,-.11),(92,-1.0055),(140,-1.7255)**. The2cm offset seats soil below the
walk surface. The1.5% descent continues towardX290 before flattening toward
the existing waterfront composition. These are AU fit dimensions, not verified
1928 elevations. No generated terrain has yet been replaced by this preparation.

The ground builder clips soil above that profile instead of translating its
existing cavities. New caps follow actual occupied cells, subdividing at profile
breaks and height-plane crossings; existing exposed tops are not doubled.
Source faces retain winding and conforming edge subdivision. The inspector
adds a separate positive-part layer integral; it does not derive expected soil
volume from the mesh under inspection. Saved native manifold, foundation-seat,
reservation and0.001m3 absolute volume checks remain required.

External controls pass eight analytic integrals, seven native closed cells,
and three native grids containing a fixed cavity. A missing cap is deliberately
rejected. The site-scale01 control fails on coincident consecutive edge samples;
its sources/log remain in **grade_clip_site_failed_01_sources.zip**. Canonical
point identities now discard only consecutive repeats before the nonconsecutive
duplicate assertion. Site-scale02 then fails the old pre-storage comparison
after float32 conversion, by.0000316505m3 over186731.6122105m3. Its original
sources/log remain in **grade_clip_site_failed_02_sources.zip**.

The affine path now proves its double-precision construction at the unchanged
.00001m3 bound before storage, and checks the represented mesh at the native
inspector's existing.001m3 bound. The orthogonal path retains its original
.00001m3 check. Site-scale03 passes with7,944 source faces and7,946 represented
vertices, zero edge contacts and that measured.0000316505m3 represented error.
These synthetic controls do not qualify the installed site, visual quality or
runtime collision. Full native and loaded review are still pending.

Read-only horizon inspection also finds passive western buildings still authored
at the old zero datum with only.28m base depth. The wider descent will require
proper seating of those complete assemblies before a coherent combined capture;
merely replaying their old geometry would leave floating bases. The eleven
completed eastern studies, installed Orison and occupied/access authorities
remain protected. No horizon seating or terrain continuity acceptance is claimed.

Source preparation now also seats passive horizon assemblies at the uphill
parcel height, retaining their complete architectural proportions. Their existing
.28m bases remain buried uphill; where the downhill edge needs more depth, a
separate closed concrete foundation meets that base. Differing parcel datums no
longer share the old coplanar party-wall suppression. The three authored horizon
studies lie in the unchanged eastern flat area; their geometry must still be
compared before/after rebuilding, rather than assumed unchanged from that fact.
This prepared builder has not yet generated or qualified new horizon assets.

A read-only run against the previous953x293x943 terrain grid produces38,039
candidate cap faces and180748.2422696m3 remaining soil. Across3,001 stations,
the authored soil-to-walk setback differs from2cm by at most4.45e-16m. This is
a datum/complexity diagnostic only: that old grid lacks the fresh street AIR
reservations. The native inspector additionally requires all actual saved source
vertices below the roof profile and at least20 distributed real roof-contact
rays, alongside the retained foundation-seat and reservation checks.

### Street imported bench04 — original failure retained

The corrected broker waiter actually runs after canonical prologue releases.
**bench_04.log.receipt.json** records a completed23.09s run ending23:12:44Z,
exit1, not a timeout. The test-written **bench_04/transport_bench.json** records
365 checks and one aggregate imported-chart failure. Default compression stretches
mounted near charts by up to2.508974% and replacement charts by8.679245%, with
6 and12 bad derivative triangles respectively. Original native/exports, import
sidecars, executed sources, output JSON, logs and wrapper receipt are retained
in **bench_failed_04_sources.zip** (1,775,370 bytes). Its stderr contains the
original failed metric assertions; they are not erased or relabelled as passing.

Both forced whole-family cases actually render48 draws, with20,064 near and
8,256 replacement triangles. GPU p50/p95/p99/max milliseconds are
**.583/.589/.5937/.599** near and **.580/.585/.586/.586** far; repeats are
**.541/.546/.5471/.548** near and **.540/.546/.5494/.553** far. Wall-frame
p50/p95/p99/max are **.8985/1.0993/1.3957/1.596** near and
**.895/1.0547/1.0993/1.102** far. These are isolated uncapped90-frame samples,
3440x1440, MSAA8, TAAoff, vsyncoff, excluding captures. They are not whole-city
frame costs, matched route speed claims, or a qualified performance result.

The same-distance focused partition actually renders60 versus120 triangles
under wide versus narrow FOV, one draw in each case. All six saved captures
are inspected: actual curb/material close views, whole-family forced LOD views,
and focused FOV views. The close views omit retained station/Orison paving and
show intentional fixture voids; they do not establish a composed street.
The import-policy owner has been contacted about precisely two demonstrated
compression exceptions. Repair/reimport/rebench remains required before any
loaded street-surface acceptance.

### Street imported bench05 — repaired isolated pass

Prologue confirms no import-policy overlap. The catalogue tool adds precisely
the two demonstrated street exceptions; its precheck names only those two
incorrect sidecars, and its repair changes only those two. Existing66 exceptions
remain. **import_05.log.receipt.json** records a completed19.43s import;
**bench_05.log.receipt.json** records a completed16.06s run, exit0, ending
23:16:17Z. The test-written result records **365 checks / zero failures**;
stderr is empty. Strict mapping/derivative thresholds are unchanged.

All48 mounted near and48 source replacement parts pass their imported charts.
Worst measured stretch is.00173643% near and.00020905% replacement, with zero
bad derivative triangles. Actual local materials, loaded PBR mip chains, the
existing weather adapter, near-only collision, authored grade anchors and sampled
carriageway collision pass.36 parts carry a reducing replacement; the remaining
12 retain their complete bodies. No decorative-only deletion substitutes for
the rendered8,256-triangle replacement family.

Forced near/far render20,064/8,256 triangles,48 draws each. GPU
p50/p95/p99/max milliseconds are **.584/.5926/.5941/.595** near and
**.541/.548/.5502/.552** far; repeats are **.543/.5506/.554/.554** near
and **.541/.5475/.5512/.553** far. Near wall-frame distribution is
**.904/1.0131/1.3208/1.481**, far **.8255/1.0291/1.3048/1.408**.
Mount CPU time is225.704ms. Settings and sample scope match bench04; repeat
variation prevents treating these small GPU differences as a whole-city speed
gain. The focused same-distance FOV check still renders60/120 triangles in one
draw. All six new images are actually inspected, including curb close views.

This qualifies only the isolated imported street family. The composed terrain
and access route, full surface contract and whole-world performance remain open.
A separate station-material bench and fresh INERT grade-owner survey are now
queued as **station_survey_batch_06.json** through the same wrappers, with their
actual sources frozen. No generated ground/horizon replacement has started.

### Previous native ground preflight and route expectations

While the next batch waits behind the bodies import, a diagnostic constructs
the proposed cut from the actual previous saved closed native ground and its
matching cell grid. It writes no installed asset. Float32-normalized profile
planes produce18,856 clipped old faces plus7,367 caps;26,223 conforming faces
use34,128 represented vertices. The original15 edge contacts and30 split fans
remain, with zero nonmanifold edges. Independent cell volume is
180748.2426684153m3; pre-storage error is zero and represented error
.0000434680m3. Actual elapsed diagnostic time is8.323s. The source-bound JSON
and log are **grade_previous_native_cut_01.json/log**. These old masks omit the
fresh street AIR, so this pass cannot qualify the installed terrain.

The earlier38,039-cap estimate used raw decimal planes. Normalizing the soil
datum to its existing saved float32 plane avoids spurious sub-nanometre flat
cuts; this explains the smaller actual native candidate rather than claiming
equivalent raw and represented grids.

The played-route source now supplies graded ground targets without changing the
production controller, reach tolerances or travel budgets. New street targets
use the separately benchmarked surface owner. Wider world targets are converted
once into the building frame and checked against an explicit independent AU
soil table. Frontage floor rays are centred on their actual expected elevation,
retaining the same.0001m owner/height check instead of widening the ray or height
tolerance. None of these updated route assertions has executed yet.

The attempted static **SOURCES** preflight on these dynamic-programme route
scripts reports missing declarations; **spatial_03.txt** is retained as that
tool-scope failure, not a runtime verdict. The appropriate coordinate dependency
audit is run separately. The pending grade survey's actual two-file dependency
closure contains neither edited route, and its surface snapshot excludes them.

The separate coordinate audit **spatial_audit_03.json** returns **clean**.
Two actual Cycles views of the previous-mask cut and registered current street
are rendered and inspected in **grade_previous_native_review_01**. They confirm
the low walk-to-soil join, and visibly reproduce the expected buried carriageway
where fresh street AIR is absent. This deliberately incomplete control is not a
finished road or a terrain pass. Its soil proxy uses registered maps and metre
UVs for shape reading; it does not qualify installed surface appearance. Both
saved views omit Orison, occupied rooms and the complete city context. All bound
source files remain unchanged after rendering; bound text is already LF.

The original station/survey waiter61688 remains live. The latest lane status
shows bodies continuing its own batch with LenaRoute, started23:24:14Z, after
its import. Neither queued city run has started. No process is terminated or
restarted to obtain the lane.

### Fresh survey and native replay — current checkpoint

Station material bench02 completes in23.14s, **204 checks / zero failures**,
empty stderr; all six actual captures are inspected. Thirty draws render391,752
near or73,448 replacement triangles. Initial near GPU p50/p95/p99/max is
.627/8.846/16.4687/18.012ms; six of90 samples exceed2ms, all at indices0..5.
The repeated near case is.586/.5956/.5981/.599ms. Far medians are.547ms and
.5465ms repeated; narrow FOV median is2.385ms. The initial burst is retained
and unattributed; no stable-speed or whole-world budget claim follows from it.

Fresh grade survey01 completes in262.91s, zero failures and empty stderr,
recording573 aligned boxes while separately counting non-box shapes. This is
INERT discovery, not a runtime contract. Native export02 classifies5,465 records;
the reconciled plan has5,518 retained records, omitting269 redundant runtime
boxes. Elevation replay01 is byte-identical and runtime bindings remain current.
Foundation/bar replay completes; foundations now contain207 disjoint components,
1,049 parts and20,946 triangles, pending native contact/render review.

The first ground replay's handle and processes disappear after its grid line;
no new ground asset is written and no exit code or cause is inferred. Its
1375x760x1369 grid and stopped log are preserved in the external incomplete01
records, including all seven array hashes and executed sources. Whole-grid
neighbour scratch arrays are replaced with exact Y/Z-plane extraction; the
unchanged cell indices and burial flags pass1,184 occupancy-set controls,
including a rejected missing-burial-flag control. Replay02 is underway; a native
or playable-ground pass is not claimed.

The project archive **art/reviews/city_streets_20261029/diagnostics.zip** now
retains168 terminal diagnostic members (60,442,173 bytes), with the original145
members verified unchanged. Its INERT manifest distinguishes failures,
isolated passes and discovery. The newest ground attempt remains external
until its terminal artifacts can be appended without changing prior members.

### Retained grade and street context — native checkpoint

The fresh-grid rebuild is now terminal. Original incomplete01 and deliberately
stopped02 artifacts remain preserved externally. Replay02 reached a measured
18.218 GiB peak working set while storing individual exposed faces; only that
owned Blender process was stopped after its command identity was checked.
Plane coalescing now preserves the same seven saved grid arrays byte for byte,
with 1,152 exact face/material/chunk controls in addition to the 1,184 occupancy
controls. This is an authoring-memory repair, not a rendering-speed claim.

Failed replays03–06 retain their executed sources and logs: represented global
coordinates collapsed a narrow cap before local subtraction; six clipped
pentagons needed triangulation; and the exported tangent check then found zero
tangents. Local subtraction now precedes float32 storage, and the shared native
chart/export helpers supply validated tangents. No area, volume or derivative
bound was relaxed. The first independent inspector attempt had a hidden-source
setup error; its next attempt exposed a real unseated fixed foundation course.
Those failures and the superseded geometry remain preserved.

Rebuild08 preserves soil within the actual 23 fixed foundation contact parcels
while grading the exposed western ground. Native construction rejects a parcel
boundary with unsupported soil; the closed-ring positive control passes and the
unretained negative control rejects. Independent inspection03 passes 367
unshifted foundation seat probes and 5,968 retained/reserved-volume checks.
The saved closed mesh has zero nonmanifold edges; expected volume is
181578.92188627252 m3, represented volume 181578.92193752262 m3, a difference of
0.0000512501 m3 within the unchanged 0.001 m3 inspection bound. Its 3,256 material
parts contain 96,400 triangles. These are native construction facts, not runtime
cost or playable-area acceptance.

Apron replay01 passes. Horizon replay01 retains a genuine blocked-window failure
across different building datums; corrected party-wall occlusion includes all
neighbours at their actual datum. Horizon replay02 passes with 124 buildings and
12,294 recessed panes. All 17 mesh parts and node poses of the three completed
horizon studies compare unchanged. Elevation replay02 renews the shared-helper
binding through the actual builder; its installed GLB is byte-identical. Street
replay01 likewise renews the elevation-fixture dependency and both street GLBs
are byte-identical, permitting reuse of their already inspected native views.

Combined native context review01 passes 4,775 checks. All nine actual images
have been inspected, including both replacement views, the eastern intersection,
the western street end and the retained foundation course. It contains actual
street, ground, foundation, apron and horizon meshes, but omits the installed
Orison and does not qualify the complete playable composition. A dark curb band
remains an appearance question for composed runtime inspection. Repeated passive
background architecture, drains and gutters remain unfinished. Current ground,
route, full-surface and rendering qualification are still pending. The newer
terminal artifacts remain external pending an append-only archive update.

### Imported ground and first composed route — qualification still open

Import06 completes in18.83s with empty stderr. Horizon/ground bench03 finishes
with25,616 checks and one aggregate failure: two real clipped parts have exactly
three vertices/three indices, while the reused roof-cap helper requires quads.
Their metric UV, unit basis and derivative checks pass. Exact executed sources,
original output and wrapper receipt remain in **horizon_bench_failed_03_sources.zip**.
After coordination with prologue, the helper adds an explicit triangle option;
all existing callers retain their quad default and numerical tolerances.
Ground alone opts in. Bench04 passes25,616 checks in23.68s, empty stderr.
This is an imported diagnostic, not a runtime_contract or city acceptance.

The initial composed launch05 cannot parse a new inferred waypoint type. Its
verified own empty window is closed; wrapper exit0 records that manual close,
not a pass. Launch06 receives a malformed joined CLI token; its verified own
window is likewise closed and not qualified. Both original logs, receipts and
termination notes are retained. The waypoint now has an explicit Vector3 type;
subsequent launches use the JSON lane batch with an actual argument array.

Composed route07 executes283.62s and writes a schema-2 failing runtime contract:
158 checks,41 waypoints,five failed grade probes. The original five rays at
source y=-10 hit graded soil2cm below the walk, not sidewalk. Native slab bounds
show these rays are exactly in the authored4mm paving joints: adjacent slabs end
at-10.002 and begin at-9.998. All115 foundation contacts and the retained
crossing/entrance programme pass. Both actual captures are inspected, including
the restored-blocker control. Original sources, logs, wrapper receipt and failed
test-written contract remain in **exterior_route_failed_07_sources.zip**.

All five joint rays remain and must hit the underlying soil. Five added rays at
y=-10.1 separately require sidewalk field at full height; no owner/height bound
is widened. Route08 is queued normally behind the active canonical prologue,
with no city Godot process yet started. A queued-source scalar classification
uses y<-10 rather than exact comparison with a non-binary decimal. No production
geometry, traffic, entrance or movement authority changes for this repair.

The actual fixture inventories reconcile to25 near elevations plus124 horizon
buildings,149 total. The23 fixed foundation contact parcels are a different
inventory and do not reduce the architectural queue. The append-only native
archive now has230 members,91,694,200 bytes, with the original168 members
verified unchanged. Its phase03 manifest records the external large-grid hash;
all newer imported/route failures remain external pending final retention.

Route08 subsequently executes476.20s,167 checks and70 waypoints, one failure.
All original joint and added slab-field probes pass. The controller reaches both
northern junction ends, the east1.62m footway, street end and pier-island view.
Three new actual player captures are inspected. Curbs/paving are continuous;
parked vehicle wheels remain partly buried and are logged for coordinated
vehicle work, not repaired here. Native black curb bands read as shaded faces
in these runtime views, with no visible hole; lighting remains dark.

The remaining route failure is a real collision with the retained VantryArcade
gateway cast-iron post at world x5.225,z16.705. Its original failing schema-2
contract, logs, wrapper receipt and executed sources remain preserved in
**exterior_route_failed_08_sources.zip**. No gateway/shop collision is removed.
The source gateway collider bounds begin at z24.969999 in the registered asset,
world z15.174999 after its existing translation. Route09 detours roadward along
the actual sidewalk at world z14.705, then returns beyond the post, retaining the
0.33m production capsule and original movement/reach bounds. This leaves about
0.14m capsule clearance from the conservative gateway bound and0.10m from the
curb cap; actual traversal is pending. The rest of the street/station/wider tour
remains required. This is a route correction around physical architecture, not
an access-authority or construction change.

The original route07 frame samples are summarized without changing their failed
contract in **route07_frame_summary.json**. At3440x1440,MSAA8,TAA on, four warmed
ABBA placement blocks contain240 frames each. Wall medians are31.2005,28.9300,
30.2840 and31.6090ms; maxima45.933,41.720,50.102 and44.480ms. Main-viewport GPU
medians are13.3780,12.7245,13.7670 and13.3850ms. NPC/traffic and caches are
uncontrolled, engine counters are global, and private-viewport GPU work is
excluded. These are current-cost diagnostics, not matched construction gains.
The40 cold-settle frames have median71.267ms and maximum7898.530ms. All raw
samples and the five original grade assertion failures remain preserved.

### Composed exterior route09 — bounded runtime qualification

The shared-lane wrapper records1229.64s, completed exit0, empty stderr and no
script errors. The original test-written schema-2 runtime contract passes237
checks and199 waypoints, including the35-point new street loop, both platform
levels/islands, the36-point wider tour and exact world-root retirement. Both280m
east/west ground walks complete without safety-net recovery. Five separate
controller fixtures at150m altitude touch the450m temporary radial wall; maximum
centre distance is449.71094m. Disabling that wall alone allows453.49890m, after
which its exact layer and the original player pose are restored. Those airborne
fixtures do not prove450m ground routes or roof access. No sleep, bed, narrative,
shop, campaign-time or save authority is added.

All13 actual route09 captures are inspected. They confirm the continuous walks,
curved corners, east pinch, seated pier islands, public entry, both platform
levels, open/restored west sightline and building/ground contact at the wider
stations. Darkness, sparse generic exterior ground, repeated background forms,
unfinished station detailing and partly buried vehicle wheels remain visible.
This is technical access qualification, not whole-city or artistic acceptance.

Walking samples exclude screenshot readback. New street:15,415 frames, wall
p50/p95/p99/max11.399/51.3633/59.6903/89.218ms; main-viewport GPU
4.857/17.6622/20.0210/21.844ms. Wider tour:37,518 frames, wall
8.128/49.657/61.0453/121.525ms; GPU3.916/16.6496/19.7628/23.851ms.
Global primitive counters peak186.7m/188.3m, covering all renderer work;
main-viewport GPU excludes private viewports. NPCs, traffic and caches remain
uncontrolled; spikes are not causally attributed. Cold settling includes a
7812.081ms maximum. These distributions are current diagnostics, not matched
construction speed gains or a proposed performance budget.

The unmodified successful contract, original failed/aborted runs, logs, wrapper
receipts, bound executed helpers and all original route07/08/09 images are
retained in the existing review directory's **exterior_qualification.zip**:
62 members,67,009,711 bytes. The INERT manifest indexes exact raw hashes; the
original230-member **diagnostics.zip** remains byte-identical. Full static gates,
full surface renewal, cleanup, candidate verification and commit/push remain
pending. The prologue took its queued profiling slot normally after route09;
city waits for that terminal run before starting CPU-heavy static qualification.

### Static expectations and natural LOD inspection

Full static board01 completes. Its new non-surface failure is the original apron
unit assertion that every installed horizon footprint and seam stays at-.02m;
the approved western grade contradicts that assertion. Original source and board
remain in **static_failed_01_sources.zip**. The test now checks independent
explicit AU heights, retaining exact flat eastern controls and all river/canal
anchors. Its added occupancy-set oracle checks1,152 small grids, including thin
axes, retained burial, asphalt/soil, protected parcels and4m render chunking.
Five tests pass. The first selected-board invocation02 selects zero gates due
to an incorrectly comma-joined CLI selection and is rejected as no evidence.
Corrected board03 contains exactly spatial,reader and apron-test gates; all pass,
reader NEW=0. The other full-board regressions are the expected expired surface
packet, which still requires a fresh test-written contract and image review.

The LOD bench now measures actual distance-driven switching at default pixel
threshold1. Initial standalone parse failures and a check-only invocation that
cannot resolve project autoload RealityState remain preserved, with manual-close
exit0 explicitly not counted as passes. Primitive-count-only run02 passes but its
actual street narrow capture looks between disconnected curb pieces. That
optical aiming defect is retained in **lod_transition_optical_02_sources.zip**.
The final programme aims at an actual camera-facing native triangle, fits the
whole body at wide FOV and requires non-background centre coverage in each
capture. No production mesh, shader or runtime authority changes for this test.

Final street03 passes399 checks in13.91s; station03 passes238 in18.79s; both
wrapper receipts are complete and stderr is empty. Eight new natural-transition
images are actually inspected. Representative street curb48/24 triangles switch
between31.1751327 and31.1752919m; station timber31,680/144 switch between
55.0157235 and55.0160343m. Narrow FOV at the far pose recovers the near body, and
inward return restores it. These are complete-body replacements with consistent
visible stock at the switch, not whole-family/world transition acceptance. The
unchanged earlier family-view reviews remain reusable; these inspections add the
actual optical/distance transition that the old forced endpoints did not prove.

Full composed surface renewal01 terminated in901.00s, exit1:42,667 checks,
three failures, all actual retained east passage pavement bearing. Its material
inventory reports zero unresolved surfaces, but the combined qualification
fails. The unchanged fire-hose interaction subprogramme was explicitly skipped
as before; this supplies no new fire interaction proof. Original contract,
wrapper receipt, logs and exact failing native/export sources are preserved in
**full_surface_failed_01_sources.zip**. The old published surface packet remains
expired; no passing renewal is claimed.

The exterior evidence archive now appends the original static/parse/optical
findings and final transition diagnostics:108 members,93,911,814 bytes, with all
original62 member hashes unchanged. All eight new transition captures are marked
actually inspected; unchanged family viewpoints retain their earlier review
scope. The original230 native archive members remain unchanged; phase04 adds the
failed full-surface source bundle. The primary archive now contains231 members
and98,104,987 bytes. Its current hash and member hashes are indexed in the
existing INERT manifest.

### Retained arcade pavement repair and dependency replay

The old curb end at source x20.8 was incorrectly reused as the retained slab
mask end; the existing opposite pavement actually reaches x22. Its north edge
is -23.894, not -23.895. Five independent unchanged collision-provider records
in **exterior_geometry.json** reveal overlaps of0,.020215,5.299853,.004128,0m².
The original overlap diagnostic is preserved byte-for-byte with the failure.
Street construction now derives all five floor reservations from those actual
providers, and asserts zero positive overlap for near and replacement walk
stock before export. The curb transition remains independent and unchanged.
All five repaired overlap areas are zero. Existing floor, gateway, shop and
access authorities are unchanged.

The rebuilt street contains2,388 closed stocks,19,752 near and8,184 replacement
triangles,48 parts per export. Reopened native review passes4,778 checks,
including87 original pavement-bearing samples with the original height/normal
bounds. All eight initial repair images were inspected. They omit full ground
context and do not establish whole-city composition or artistic acceptance.

Native discovery and the retained-grade plan were renewed from actual producers.
The original573-box runtime survey remains reusable only because its production
input digest and all three test dependencies validate unchanged. The first
ground09 preflight stopped on stale foundation bindings; later native preflight06
stopped on stale station bindings. Both original failures and their sources are
preserved. Dependency replay follows station, native discovery, grade plan,
foundations, ground, apron, horizon; no stored hashes were patched by hand.
All twelve native fixture preflights now pass. All147 deep grade source bindings
validate using the producer's digest. An initial ad-hoc checker incorrectly
normalized binary .bin bytes; its diagnostic is preserved and corrected without
changing any production source or binding.

Ground10/11 export3,256 parts and96,396 triangles. Independent inspection04
finds5,915 retained/reserved volumes clear and retains the original seat probes;
its actual native overview was inspected. Ground10 export tangent agreement is
at least.9999999706 and represented volume error is.00005126m³. Ground11 and all
seven other dependency-replayed GLBs are byte-identical to their pre-replay
versions. Those comparisons permit reuse of unchanged geometry reviews, not
repinning old source-bound runtime contracts. Combined native ground-context
review02 passes4,778 checks; all ten actual images are inspected. The retained
seam is continuous and western contacts appear seated. Abrupt finish changes,
sparse street fittings and repetitive distant forms remain visible; this is
not artistic acceptance. Import07 completes without script errors. Renewed
street bench04 passes399 checks in17.92s, including natural replacement LODs;
six actual crossing/curb/transition captures are inspected. Ground/horizon
bench05 passes25,616 checks in23.91s with no script errors; it writes diagnostics,
not a runtime contract. Full composed surface renewal02 is queued through the
shared lane with the same explicit unchanged fire-interaction skip. No passing
full renewal or renewed composed route is claimed yet. Cleanup, candidate
verification and checkpoint commit/push remain pending.
