from pathlib import Path
import copy,json,hashlib
root=Path('C:/ov/city');here=Path(__file__).parent
path=root/'art/data/city_horizon/source_plan.json';raw=path.read_bytes();plan=json.loads(raw)
backup=here/'before_eastern_row_source_plan_01.json'
if not backup.exists():backup.write_bytes(raw)
else:assert backup.read_bytes()==raw,'Do not replay authoring against edited plan'
before=copy.deepcopy(plan)
specs={
 'HORIZON_NEAR_2_0_P2':dict(style='mill_2102',precedent='21-02 40th Avenue, circa1912 brick-and-mill factory/loft; H.S.Karp / Touroff & Karp attribution',side_bays=[6,7,6,7]),
 'HORIZON_FAR_2_1_P0':dict(style='alder_2122',precedent='21-22 40th Avenue,1911 Alder Veneer Company brick-and-mill loft; H.S.Karp / Touroff & Karp attribution',side_bays=[5,15,5,15]),
}
for row in plan['buildings']:
    if row['id'] not in specs:continue
    assert not row.get('architecture') and abs(row['height_m']-19.2)<1e-9
    item=specs[row['id']]
    row['architecture']=dict(type='mill_front',source='https://www.nyc.gov/assets/planning/download/pdf/applicants/env-review/dutch_kills/appendm_feis.pdf',source_pdf_pages=[135,136],adaptation='Five-storey brick bearing walls,heavy-timber floors,narrow six-over-six double-hung sash and individual stone lintels/sills. AU dimensions,bay schedule and finishes;modern sash/paint and contemporary parcel placement are not1928 proof. Alder source documents30.5x21.3m;this48.75x18m parcel adapts the rhythm,not a stretched replica. Closed scenic leaves introduce no shop/access authority.',floor_heights_m=[4.0,3.8,3.8,3.8,3.8],front_side=1,cornice_key='limestone',**item)
    row['joinery_tint']=[.28,.30,.25,1.]
assert all(old==new for old,new in zip(before['buildings'],plan['buildings']) if old['id'] not in specs)
assert all(old['rect']==new['rect'] and old['height_m']==new['height_m'] for old,new in zip(before['buildings'],plan['buildings']))
path.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Authored two mill profiles;all124 footprints/heights and122 other profile records unchanged. Source only;no generated asset or acceptance.')
