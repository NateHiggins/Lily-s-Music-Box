from pathlib import Path
import json,math
path=Path('C:/ov/city/art/data/city_horizon/source_plan.json');plan=json.loads(path.read_text())
for row in plan['buildings']:
    study=row.get('architecture',{})
    if study.get('type')!='eastern_row':continue
    assert 'outline_m' not in study
    a,b,c,d=row['rect'];x,y,X,Y=a,-d,c,-b;style=study['style']
    if style!='tinshop_2810':X-=1.35
    points=[(X,y),(x,y),(x,Y),(X,Y)]
    if style!='tinshop_2810':
        first,last=(3.10,6.80) if style=='beauxarts_3001' else (.25,4.45)
        projection=.65 if style=='beauxarts_3001' else .42
        points.extend([(X,Y-first),(X+projection,Y-first-.65),(X+projection,Y-last+.65),(X,Y-last)])
    counts=[]
    for p,q in zip(points,points[1:]+points[:1]):
        length=math.dist(p,q);front=-(q[1]-p[1])/length>.65
        counts.append(3 if style=='tinshop_2810' and front else max(1,round(length/(2.3 if front else 3.2))))
    study['outline_m']=[[x,-y] for x,y in points];study['side_bays']=counts
path.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Authored three exact primary footprints and bay schedules;reservation rectangles unchanged.')
