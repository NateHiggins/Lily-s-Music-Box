from pathlib import Path
import copy,json
root=Path('C:/ov/city');here=Path(__file__).parent
path=root/'art/data/city_horizon/source_plan.json';raw=path.read_bytes();plan=json.loads(raw);before=copy.deepcopy(plan)
backup=here/'before_three_small_rows_01.json';assert not backup.exists();backup.write_bytes(raw)
specs={
 'HORIZON_NEAR_2_0_P0R0':dict(style='tinshop_2810',height=9.6,floors=[3.5,3.1,3.0],wall='arcade_brick_bond',tint=[.69,.48,.34,1],precedent='28-10 38th Avenue tin shop,built1898-1915;three bays,three storeys,pressed-metal display cornices and semicircular parapet',pages=[127,128,129]),
 'HORIZON_NEAR_2_0_P0R1':dict(style='beauxarts_3001',height=7.5,floors=[1.05,3.25,3.20],wall='limestone',tint=[.82,.79,.69,1],precedent='30-01 39th Avenue,circa1910 Beaux-Arts dwelling;two storeys above raised basement,stone cladding,bow terrace and raised double-leaf entrance',pages=[126,127]),
 'HORIZON_NEAR_2_0_P0R2':dict(style='renaissance_3732',height=7.3,floors=[.90,3.25,3.15],wall='arcade_brick_bond',tint=[.92,.79,.56,1],precedent='37-32 28th Street Renaissance Revival dwelling;two storeys,buff brick,full-height bay,side-hall stoop and foliated metal cornice;construction date unresolved in reviewed assessment',pages=[130,131]),
}
for row in plan['buildings']:
    if row['id'] not in specs:continue
    assert not row.get('architecture');s=specs[row['id']]
    row['height_m']=s['height'];row['wall_key']=s['wall'];row['wall_tint']=s['tint'];row['joinery_tint']=[.38,.40,.34,1]
    row['architecture']=dict(type='eastern_row',style=s['style'],precedent=s['precedent'],source='https://www.nyc.gov/assets/planning/download/pdf/applicants/env-review/dutch_kills/appendm_feis.pdf',source_pdf_pages=s['pages'],adaptation='AU parcel,dimensions and finishes. Houses retain two main storeys over low raised basements;1.35m front setback accommodates real stairs and bays. Modern photographs are form guidance,not1928 parcels,colors or sash evidence.37-32 construction date is not established here;use as an AU form adaptation,not a dated historical replica. Scenic closed leaves create no occupied programme or access authority.',floor_heights_m=s['floors'],front_side=1,cornice_key='door_paint')
assert all(a==b for a,b in zip(before['buildings'],plan['buildings']) if a['id'] not in specs)
assert all(a['rect']==b['rect'] for a,b in zip(before['buildings'],plan['buildings']))
path.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Three small row sources authored;all124 footprints and121other profiles unchanged. Geometry/export/render qualification pending.')
