"""Read-only exported triangle height survey; no runtime/visual acceptance."""
from pathlib import Path
import hashlib,json,struct,subprocess
import numpy as np

ROOT=Path('C:/ov/city')
OUT=Path(__file__).with_suffix('.json')

def meshes(path):
    raw=path.read_bytes(); chunks={}; cursor=12
    assert struct.unpack_from('<III',raw)==(0x46546c67,2,len(raw))
    while cursor<len(raw):
        size,kind=struct.unpack_from('<II',raw,cursor)
        chunks[kind]=raw[cursor+8:cursor+8+size];cursor+=8+size
    doc=json.loads(chunks[0x4e4f534a]);blob=chunks[0x004e4942]
    def array(index):
        a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']]
        assert 'sparse' not in a
        width={'SCALAR':1,'VEC3':3}[a['type']]
        dtype=np.dtype({5121:'u1',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']])
        return np.ndarray((a['count'],width),dtype=dtype,buffer=blob,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',width*dtype.itemsize),dtype.itemsize))
    seen=set();result=[]
    def visit(index,parent):
        assert index not in seen;seen.add(index);n=doc['nodes'][index]
        if 'matrix' in n:m=np.array(n['matrix']).reshape((4,4),order='F')
        else:
            x,y,z,w=n.get('rotation',[0,0,0,1]);m=np.eye(4)
            m[:3,:3]=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])@np.diag(n.get('scale',[1,1,1]))
            m[:3,3]=n.get('translation',[0,0,0])
        m=parent@m
        if 'mesh' in n:
            for p in doc['meshes'][n['mesh']]['primitives']:
                assert p.get('mode',4)==4
                vertices=array(p['attributes']['POSITION']).astype(float)@m[:3,:3].T+m[:3,3]
                result.append((n.get('name',''),vertices[array(p['indices']).reshape(-1,3)]))
        for c in n.get('children',[]):visit(c,m)
    for n in doc['scenes'][doc.get('scene',0)]['nodes']:visit(n,np.eye(4))
    return result,hashlib.sha256(raw).hexdigest()

def hits(parts,x,z,select=lambda name:True):
    result=[]
    for name,t in parts:
        if not select(name):continue
        a=t[:,0];b=t[:,1]-a;c=t[:,2]-a
        det=b[:,0]*c[:,2]-b[:,2]*c[:,0];valid=abs(det)>1e-12
        indices=np.flatnonzero(valid);a=a[valid];b=b[valid];c=c[valid];det=det[valid]
        u=((x-a[:,0])*c[:,2]-(z-a[:,2])*c[:,0])/det
        v=(b[:,0]*(z-a[:,2])-b[:,2]*(x-a[:,0]))/det
        inside=(u>=-1e-7)&(v>=-1e-7)&(u+v<=1+1e-7)
        for j in np.flatnonzero(inside):result.append({'part':name,'y_m':float(a[j,1]+u[j]*b[j,1]+v[j]*c[j,1]),'triangle_index':int(indices[j])})
    return sorted(result,key=lambda h:h['y_m'],reverse=True)

street,street_sha=meshes(ROOT/'game/assets/props/city_streets.glb')
ground,ground_sha=meshes(ROOT/'game/assets/props/orison_ground.glb')
threshold=json.loads((ROOT/'game/data/orison_v2/exterior/street_frame.json').read_text())['source_threshold_z']
rows=[]
for x in [-90.,-60.,-30.,0.,30.,60.,110.]:
    z=16.5
    s=hits(street,x,z,lambda name:name.endswith('__road'))
    g=hits(ground,x,z-threshold)
    row=dict(city_source_x_m=x,street_export_z_m=z,building_frame_z_m=z-threshold,street_hits=s[:4],ground_hits=g[:4])
    if s and g:row['street_minus_ground_m']=s[0]['y_m']-g[0]['y_m']
    rows.append(row)
report=dict(evidence_class='INERT',scope='Read-only exact exported-triangle vertical intersections with complete glTF node transforms. Not loaded collision,rendered visibility or artistic acceptance. Street model is translated -source_threshold_z at runtime; ground is in building frame.',commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),asset_sha256={'game/assets/props/city_streets.glb':street_sha,'game/assets/props/orison_ground.glb':ground_sha},source_threshold_z_m=threshold,samples=rows)
assert not OUT.exists();OUT.write_text(json.dumps(report,indent=2),encoding='utf-8',newline='\n')
print(json.dumps([dict(x=r['city_source_x_m'],street=r['street_hits'][:1],ground=r['ground_hits'][:1],delta=r.get('street_minus_ground_m')) for r in rows],indent=2))
