"""Corrected read-only survey: derive complete installed registration first."""
from pathlib import Path
import hashlib,json,math,subprocess
import numpy as np

HERE=Path(__file__).parent;ROOT=Path('C:/ov/city')
helper=HERE/'survey_street_grade_exports_01.py'
# Preserve original failed-frame survey and reuse its actual GLB/ray decoder.
exec(compile(helper.read_text(encoding='utf-8').split('\nstreet,street_sha=')[0],str(helper),'exec'))
def read(path):return json.loads((ROOT/path).read_text(encoding='utf-8'))
config=read('game/data/orison_v2/world_connection.json')
layout=read('game/data/orison_v2_blockout.json');regions=read('game/data/orison_v2/exterior/regions.json')
door=next(x for x in layout['doors'] if x['id']==config['door_id'])
inside=next(x for x in layout['spaces'] if x['id']==config['inside_space_id'])
level=next(x for x in layout['levels'] if x['id']==door['level'])
instance=next(x for x in regions['instances'] if x['id']==config['instance_id'])
assert instance['offset_uvn_m']==[0.,0.,0.] and instance['local_yaw_degrees']==0
surface=next(x for t in regions['surface_templates'] if t['id']==config['template_id'] for x in t['surfaces'] if x['id']==config['surface_id'])
threshold=np.array([door['center'][0],level['y'],door['center'][1]],dtype=float)
a,b,c,d=inside['rect'];outward=threshold-np.array([(a+c)*.5,level['y'],(b+d)*.5])
normal=np.array(surface['normal']);point=np.array(surface['point_m'])
angle=math.atan2(normal[0],normal[2])-math.atan2(outward[0],outward[2])
cs,sn=math.cos(angle),math.sin(angle)
rotation=np.array([[cs,0,sn],[0,1,0],[-sn,0,cs]])
origin=point-rotation@threshold
assert np.allclose(rotation,np.diag([-1,1,-1]),atol=1e-12)
assert np.allclose(origin,[0,0,-11.65],atol=1e-12)
street_threshold=read('game/data/orison_v2/exterior/street_frame.json')['source_threshold_z']
street,street_sha=meshes(ROOT/'game/assets/props/city_streets.glb')
ground,ground_sha=meshes(ROOT/'game/assets/props/orison_ground.glb')
rows=[]
for x in [-90.,-60.,-30.,0.,30.,60.,110.,115.]:
    z=16.5;world=np.array([x,0,z-street_threshold]);local=rotation.T@(world-origin)
    s=hits(street,x,z,lambda n:n.endswith('__road'));g=hits(ground,float(local[0]),float(local[2]))
    row=dict(street_export_xz_m=[x,z],world_xz_m=world[[0,2]].tolist(),ground_local_xz_m=local[[0,2]].tolist(),street_hits=s[:4],ground_hits=g[:4])
    if s and g:row['street_minus_ground_world_y_m']=s[0]['y_m']-(g[0]['y_m']+origin[1])
    rows.append(row)
horizon=read('art/data/city_horizon/source_plan.json')
ids=['HORIZON_NEAR_2_0_P0R0','HORIZON_NEAR_2_0_P0R1','HORIZON_NEAR_2_0_P0R2','HORIZON_NEAR_2_0_P2','HORIZON_FAR_2_1_P0']
parcels=[]
for r in horizon['buildings']:
    if r['id'] not in ids:continue
    a,b,c,d=r['rect'];corners=[rotation@np.array([x,0,z])+origin for x,z in [(a,b),(c,b),(c,d),(a,d)]]
    parcels.append(dict(id=r['id'],building_local_rect=r['rect'],world_xz_corners_m=[p[[0,2]].tolist() for p in corners]))
plan=read('art/data/city_streets/source_plan.json')
paths=['game/scripts/building/orison_v2_world_connection.gd','game/scripts/building/orison_v2_runtime_root.gd','game/scripts/building/orison_v2_city_shells.gd','game/scripts/building/orison_v2_ground.gd','game/data/orison_v2/world_connection.json','game/data/orison_v2_blockout.json','game/data/orison_v2/exterior/regions.json','game/data/orison_v2/exterior/street_frame.json','art/data/city_streets/source_plan.json','art/data/city_horizon/source_plan.json']
report=dict(evidence_class='INERT',scope='Corrected source/GLB-only survey. Full WorldConnection registration is derived before comparing coordinates. No loaded collision or rendered acceptance.',supersedes='survey_street_grade_exports_01.json: its street-to-ground conversion omitted the rotated blockout transform. Its approximately1.07m eastern seam claim is withdrawn; original script/JSON retained.',commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),registration=dict(rotation=rotation.tolist(),origin_m=origin.tolist(),street_root_translation_m=[0,0,-street_threshold]),source_sha256={p:hashlib.sha256((ROOT/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in paths},decoder_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(),asset_sha256={'game/assets/props/city_streets.glb':street_sha,'game/assets/props/orison_ground.glb':ground_sha},samples=rows,parcels=parcels,conclusion='Eastern near frontage is worldX+150,far frontage+207. Current eastern street edge is worldX+115,whose walk-profile datum is0,not western edge-92. Eastern horizon grade is-.02;no1.07m eastern seam is established. New street/sidewalk connection still needed;do not extrapolate across mismatched frames.')
output=HERE/'survey_street_grade_exports_02.json';assert not output.exists();output.write_text(json.dumps(report,indent=2),encoding='utf-8',newline='\n')
print(json.dumps(dict(registration=report['registration'],samples=[dict(world=r['world_xz_m'],ground_local=r['ground_local_xz_m'],road_y=r['street_hits'][:1],ground_y=r['ground_hits'][:1]) for r in rows],conclusion=report['conclusion']),indent=2))
