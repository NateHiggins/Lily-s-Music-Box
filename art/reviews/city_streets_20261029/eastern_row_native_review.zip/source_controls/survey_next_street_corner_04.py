"""Exact exported-surface clipping of unbuilt street proposals, not route proof."""
from pathlib import Path
import json,subprocess
import numpy as np

HERE=Path(__file__).parent;ROOT=Path('C:/ov/city')
helper=HERE/'survey_street_grade_exports_01.py'
exec(compile(helper.read_text(encoding='utf-8').split('\nstreet,street_sha=')[0],str(helper),'exec'))
def clip_polygon(polygon,axis,value,lower):
    if not polygon:return []
    result=[]
    for a,b in zip(polygon,polygon[1:]+polygon[:1]):
        da=(a[axis]-value)*(1 if lower else -1);db=(b[axis]-value)*(1 if lower else -1)
        if da>=0:result.append(a)
        if (da<0<db) or (db<0<da):result.append(a+(b-a)*(da/(da-db)))
    return result
def clipped(triangle,low,high):
    p=list(triangle)
    for axis in range(3):
        p=clip_polygon(p,axis,low[axis],True);p=clip_polygon(p,axis,high[axis],False)
    if len(p)<3:return []
    area=sum(np.linalg.norm(np.cross(p[i]-p[0],p[i+1]-p[0]))*.5 for i in range(1,len(p)-1))
    return p if area>1e-10 else []
control=np.array([[0.,0.,0.],[2.,0.,0.],[0.,2.,0.]])
assert clipped(control,[.2,.2,-1],[.4,.4,1])
assert not clipped(control,[2.,2.,-1],[3.,3.,1])
survey=json.loads((HERE/'next_street_envelope_survey_03.json').read_text())
rotation=np.array(survey['registration']['rotation']);origin=np.array(survey['registration']['origin_m'])
parts,sha=meshes(ROOT/'game/assets/props/city_horizon_near.glb')
assert sha==survey['asset_sha256']['game/assets/props/city_horizon_near.glb']
parts={name:triangles@rotation.T+origin for name,triangles in parts}
rows=[]
for proposal in survey['proposals']:
    if proposal['id'] not in ['east_row_front_walk','east_row_road','east_row_opposite_walk']:continue
    a,b,c,d=proposal['rect'];low=np.array([a,.05,b]);high=np.array([c,2.1,d]);hits_out=[]
    for candidate in proposal['broad_phase_overlaps']:
        if candidate['asset']!='city_horizon_near':continue
        triangles=parts[candidate['part']];possible=(triangles.max(axis=1)>low).all(axis=1)&(triangles.min(axis=1)<high).all(axis=1)
        points=[];indices=[]
        for index in np.flatnonzero(possible):
            polygon=clipped(triangles[index],low,high)
            if polygon:points.extend(polygon);indices.append(int(index))
        if points:
            p=np.array(points)
            hits_out.append(dict(part=candidate['part'],surface_triangle_count=len(indices),triangle_indices=indices,clipped_bounds_m=[*p.min(axis=0).tolist(),*p.max(axis=0).tolist()]))
    rows.append(dict(proposal=proposal['id'],rect=proposal['rect'],exact_exported_surface_intersections=hits_out))
report=dict(evidence_class='INERT',scope='Exact transformed exported triangle/six-plane AABB surface clips in Y.05..2.1 for unbuilt proposal envelopes. Crossing/contained surface evidence only,not a volume classifier,complete clearance,capsule support,runtime collision or approved street design.',commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),registration=survey['registration'],asset_sha256=sha,controls='Known inside-area clip passes;disjoint clip rejects.',results=rows)
out=HERE/'next_street_corner_survey_04.json';assert not out.exists();out.write_text(json.dumps(report,indent=2),encoding='utf-8',newline='\n')
print(json.dumps([dict(proposal=r['proposal'],overlaps=[{k:v for k,v in h.items() if k!='triangle_indices'} for h in r['exact_exported_surface_intersections']]) for r in rows],indent=2))
