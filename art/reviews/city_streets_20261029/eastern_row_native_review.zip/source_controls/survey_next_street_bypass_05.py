"""Conservative source-only standing-capsule envelopes for unbuilt footways."""
from pathlib import Path
import hashlib,json,subprocess
import numpy as np

HERE=Path(__file__).parent;ROOT=Path('C:/ov/city')
source=HERE/'survey_next_street_corner_04.py'
exec(compile(source.read_text(encoding='utf-8').split('\nsurvey=json.loads(')[0],str(source),'exec'))
previous=json.loads((HERE/'next_street_envelope_survey_03.json').read_text())
registration=previous['registration'];rotation=np.array(registration['rotation']);origin=np.array(registration['origin_m'])
city_shift=np.array(registration['street_root_translation_m'])
profiles=json.loads((ROOT/'game/data/orison_v2/exterior/city_elevations.json').read_text())['buildings']
offsets={p['id']:np.array(p.get('assembly_translation_m',[0.,0.,0.])) for p in profiles}
points=[np.array(p,dtype=float) for p in [[115.,9.527],[148.8,9.527],[148.8,135.3],[115.,135.3]]]
rows=[]
for i,(a,b) in enumerate(zip(points,points[1:])):
    lo=np.array([min(a[0],b[0])-.33,.02,min(a[1],b[1])-.33]);hi=np.array([max(a[0],b[0])+.33,1.524,max(a[1],b[1])+.33])
    rows.append(dict(leg=i,start_world_xz_m=a.tolist(),end_world_xz_m=b.tolist(),conservative_body_box_m=[*lo.tolist(),*hi.tolist()],intersections=[]))
hashes={}
for asset in ['city_elevations','city_horizon_near','city_horizon_far','city_transport']:
    path=f'game/assets/props/{asset}.glb';parts,sha=meshes(ROOT/path)
    assert sha==previous['asset_sha256'][path];hashes[path]=sha
    for name,triangles in parts:
        if asset=='city_elevations':
            owner=name.split('__')[0];matches=[k for k in offsets if owner==k or owner.startswith(k+'_')];assert len(matches)==1
            x,y,z=offsets[matches[0]];triangles=triangles+np.array([x,z,-y])+city_shift
        elif asset.startswith('city_horizon'):triangles=triangles@rotation.T+origin
        else:triangles=triangles+city_shift
        lower=triangles.min(axis=1);upper=triangles.max(axis=1)
        for row in rows:
            lo=np.array(row['conservative_body_box_m'][:3]);hi=np.array(row['conservative_body_box_m'][3:])
            possible=(upper>lo).all(axis=1)&(lower<hi).all(axis=1)
            indices=[int(i) for i in np.flatnonzero(possible) if clipped(triangles[i],lo,hi)]
            if indices:row['intersections'].append(dict(asset=asset,part=name,triangle_indices=indices))
report=dict(evidence_class='INERT',scope='Conservative actual exported surface intersection survey for three hypothetical walking legs. Full composed registration,1.524m height/.33m radius,foot datum0,ignore only bottom20mm. No generated walkway,live input,ground support,actors,save or runtime acceptance. Excludes all assets outside the four enumerated families.',commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),registration=registration,asset_sha256=hashes,decoder_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),legs=rows,construction_constraints=['No generation until coordinated intake release.','The candidate northern pedestrian bypass atworldZ135.3 precedes the preserved stoop minZ136.4600. Future curbs,walks and corner geometry still need native and loaded review.','The existing street roadtop is-.1 while uncut apron top is-.02. Future road reservation/profile must explicitly resolve covering ground;this is not a current rendered defect claim.','Three legs are a future geometry fit study,not proof of450m exploration or a continuous built street.'])
out=HERE/'next_street_bypass_survey_05.json';assert not out.exists();out.write_text(json.dumps(report,indent=2),encoding='utf-8',newline='\n')
print(json.dumps([dict(leg=r['leg'],start=r['start_world_xz_m'],end=r['end_world_xz_m'],intersections=[dict(asset=h['asset'],part=h['part'],triangles=len(h['triangle_indices'])) for h in r['intersections']]) for r in rows],indent=2))
