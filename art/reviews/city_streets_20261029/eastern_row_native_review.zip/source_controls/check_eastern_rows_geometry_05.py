from pathlib import Path
import collections,hashlib,json,sys,time
import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree
ROOT=Path('C:/ov/city');HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_industrial_architecture import EasternRows
plan=json.loads((ROOT/'art/data/city_horizon/source_plan.json').read_text())
results=[]
for row in plan['buildings']:
    if row.get('architecture',{}).get('type')!='eastern_row':continue
    row['grade_datum_m']=0.;levels=[]
    for lower in [False,True]:
        buffers=collections.defaultdict(lambda:([],[]))
        def emit(name,key,vertices,faces):
            vv,ff=buffers[key];start=len(vv);vv.extend(vertices);ff.extend(tuple(start+i for i in f) for f in faces)
        result=EasternRows(row,emit,[r for r in plan['buildings'] if r['id']!=row['id']],lower=lower).build()
        assert len(result['entries'])==1,(row['id'],'expected one retained scenic entrance',result['entries'])
        vertices=[];faces=[];owners=[]
        for key,(vv,ff) in buffers.items():
            start=len(vertices);vertices.extend(vv);faces.extend(tuple(start+i for i in f) for f in ff);owners.extend([key]*len(ff))
        bvh=BVHTree.FromPolygons(vertices,faces,all_triangles=False)
        for window in result['windows']:
            point=Vector(window['point']);normal=Vector(window['normal'])
            hit,n,index,distance=bvh.ray_cast(point+normal*.05,-normal,.30)
            assert hit is not None and owners[index]=='mirror_aged' and (hit-(point-normal*.17)).length<.0001,(row['id'],window,owners[index] if index is not None else None)
        vv,ff=buffers['galvanized_roof'];roof=BVHTree.FromPolygons(vv,ff,all_triangles=False)
        for seat in result['bearings']:
            p=Vector(seat['point']);hit,n,index,distance=roof.ray_cast(p+Vector((0,0,.02)),Vector((0,0,-1)),.04)
            assert hit is not None and (hit-p).length<.0001,(row['id'],'roof-seat',seat)
            p=Vector(seat['outside_probe']);hit,n,index,distance=roof.ray_cast(p+Vector((0,0,.02)),Vector((0,0,-1)),.04)
            assert hit is None,(row['id'],'outside-control',seat)
        triangles=sum(len(f)-2 for f in faces)
        levels.append(dict(lower=lower,triangles=triangles,parts=len(buffers),closed_stocks=result['closed_stocks'],min_stock_volume_m3=result['min_closed_stock_volume_m3'],panes=len(result['windows']),roof_seats=len(result['bearings']),entries=result['entries'],mitre_seams=len(result['mitre_seams'])))
    assert levels[1]['triangles']<levels[0]['triangles'] and levels[0]['panes']==levels[1]['panes'] and levels[0]['entries']==levels[1]['entries']
    results.append(dict(building=row['id'],levels=levels))
assert len(results)==3
report=dict(evidence_class='INERT',scope='Native construction diagnostics only: actual closed stocks,near/lower panes,roof first hits/outside controls. No saved mesh,UV/export,render,Godot,loaded mipmap,collision or artistic acceptance.',blender=bpy.app.version_string,results=results,failures=[],source_sha256={p:hashlib.sha256((ROOT/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in ['art/blender/scripts/city_industrial_architecture.py','art/data/city_horizon/source_plan.json']})
out=HERE/'rows_geometry_check_05.json';assert not out.exists();out.write_text(json.dumps(report,indent=2),encoding='utf-8',newline='\n')
print('MILL GEOMETRY DIAGNOSTIC',json.dumps(results),flush=True)
