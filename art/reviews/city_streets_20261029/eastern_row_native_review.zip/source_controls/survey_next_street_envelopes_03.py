"""Read-only runtime-frame broad phase; intersects envelopes, not player routes."""
from pathlib import Path
import hashlib,json,subprocess
import numpy as np

HERE=Path(__file__).parent;ROOT=Path('C:/ov/city')
helper=HERE/'survey_street_grade_exports_01.py'
exec(compile(helper.read_text(encoding='utf-8').split('\nstreet,street_sha=')[0],str(helper),'exec'))
registration=json.loads((HERE/'survey_street_grade_exports_02.json').read_text())['registration']
rotation=np.array(registration['rotation']);origin=np.array(registration['origin_m'])
city_shift=np.array(registration['street_root_translation_m'])
profiles=json.loads((ROOT/'game/data/orison_v2/exterior/city_elevations.json').read_text())['buildings']
offsets={p['id']:np.array(p.get('assembly_translation_m',[0.,0.,0.])) for p in profiles}
proposals=[
    dict(id='main_road_extension',rect=[115.,4.955,147.44,14.099]),
    dict(id='main_north_walk_extension',rect=[115.,-3.595,147.6,4.955]),
    dict(id='main_south_walk_extension',rect=[115.,14.099,147.6,18.521]),
    dict(id='east_row_front_walk',rect=[147.6,-17.65,150.,138.35]),
    dict(id='east_row_road',rect=[138.296,-17.65,147.44,138.35]),
    dict(id='east_row_opposite_walk',rect=[135.736,-17.65,138.136,138.35]),
]
assets=['city_elevations','city_horizon_near','city_horizon_far','city_transport']
all_parts=[];hashes={}
for asset in assets:
    relative=f'game/assets/props/{asset}.glb';path=ROOT/relative
    parts,sha=meshes(path);hashes[relative]=sha
    for name,triangles in parts:
        if asset=='city_elevations':
            owner=name.split('__')[0]
            matches=[key for key in offsets if owner==key or owner.startswith(key+'_')]
            assert len(matches)==1,(name,matches)
            x,y,z=offsets[matches[0]];triangles=triangles+np.array([x,z,-y])+city_shift
        elif asset.startswith('city_horizon'):
            triangles=triangles@rotation.T+origin
        else:triangles=triangles+city_shift
        # Only triangles touching the future walking body's vertical band.
        selected=triangles[(triangles[:,:,1].max(axis=1)>.05)&(triangles[:,:,1].min(axis=1)<2.1)]
        if not len(selected):continue
        low=selected.min(axis=(0,1));high=selected.max(axis=(0,1))
        all_parts.append(dict(asset=asset,part=name,bounds_m=[*low.tolist(),*high.tolist()],triangles=selected))

for proposal in proposals:
    a,b,c,d=proposal['rect'];overlaps=[]
    for part in all_parts:
        x,y,z,X,Y,Z=part['bounds_m']
        if min(c,X)-max(a,x)<=1e-5 or min(d,Z)-max(b,z)<=1e-5:continue
        t=part['triangles'];candidate=(t[:,:,0].max(axis=1)>a)&(t[:,:,0].min(axis=1)<c)&(t[:,:,2].max(axis=1)>b)&(t[:,:,2].min(axis=1)<d)
        if not candidate.any():continue
        overlaps.append(dict(asset=part['asset'],part=part['part'],bounds_m=part['bounds_m'],candidate_triangle_aabb_count=int(candidate.sum())))
    proposal['broad_phase_overlaps']=overlaps
report=dict(evidence_class='INERT',scope='Unbuilt candidate rectangles in the composed runtime world frame,derived from complete source registration. Broad phase of actual exported triangle AABBs in Y.05..2.1 only;not exact intersection,collision,actor clearance,continuous support,acceptance or an approved street layout. Roads/sidewalks have not been authored.',commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),registration=registration,asset_sha256=hashes,proposals=proposals)
out=HERE/'next_street_envelope_survey_03.json';assert not out.exists();out.write_text(json.dumps(report,indent=2),encoding='utf-8',newline='\n')
print(json.dumps([dict(id=p['id'],overlaps=[dict(asset=o['asset'],part=o['part'],triangles=o['candidate_triangle_aabb_count']) for o in p['broad_phase_overlaps']]) for p in proposals],indent=2))
