from pathlib import Path
import json,hashlib,subprocess
root=Path('C:/ov/city');e=Path(__file__).parent
def read(p):return json.loads(p.read_text(encoding='utf-8'))
plan=read(root/'art/data/city_horizon/source_plan.json');fixture=read(root/'game/tests/fixtures/orison_city_horizon.json');proof=read(root/'art/blender/city_horizon_construction.json')
derived={r['id']:r for r in fixture['buildings']}
ids=['HORIZON_NEAR_2_0_P0R0','HORIZON_NEAR_2_0_P0R1','HORIZON_NEAR_2_0_P0R2','HORIZON_NEAR_2_0_P2','HORIZON_FAR_2_1_P0']
def neighbours(row):
 a,b,c,d=row['rect'];out=[]
 for r in plan['buildings']:
  if r['id']==row['id']:continue
  x,y,X,Y=r['rect'];along_x=min(c,X)-max(a,x);along_z=min(d,Y)-max(b,y)
  if (along_z>1e-6 and min(abs(a-X),abs(c-x))<1e-6) or (along_x>1e-6 and min(abs(b-Y),abs(d-y))<1e-6):out.append(dict(id=r['id'],rect=r['rect'],height_m=r['height_m'],architecture=r.get('architecture',{}).get('style')))
 return out
rows=[]
for identity in ids:
 row=next(r for r in plan['buildings'] if r['id']==identity);assert not row.get('architecture')
 a,b,c,d=row['rect'];existing=derived[identity]
 parts=[p for asset in proof['assets'].values() for p in asset['parts'] if p['name'].split('__')[0]==identity]
 rows.append(dict(id=identity,rect=row['rect'],current_height_m=row['height_m'],actual_derived_grade_datum_m=existing['grade_datum_m'],native_stock_bounds=existing['native_stock_bounds'],current_export_parts=len(parts),current_export_triangles=sum(p['triangles'] for p in parts),west_facing_frontage_m=d-b,depth_m=c-a,shared_boundary_neighbours=neighbours(row)))
back_to_back=[dict(id=r['id'],rect=r['rect']) for r in plan['buildings'] if r['id'].startswith('HORIZON_NEAR_2_1_P0R')]
pdf=Path('C:/ov/reports/city_reference_next_20261028/DutchKills_AppendixM.pdf');assert hashlib.sha256(pdf.read_bytes()).hexdigest()=='d28051f905a3c208d1f8edb034ad720c8efe83636c4fb5566e5e9f7d5c106d84'
r=dict(evidence_class='INERT',scope='Executed read-only source/export-envelope survey for future construction,not geometry generation,implementation,layout authentication or acceptance. Current three industrial assets and candidate stay frozen pending coordinated intake.',commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),compass='Installed local+X west,+Z north. These negative-X parcels lie east of Orison;front side1 faces west toward it.',current_candidates=rows,orientation_rejection=dict(rows=back_to_back,reason='This second group splits along X into back-to-back shallow masses. Do not author three nominal west-facing public frontages here;only its outer western parcel is directly exposed that way.'),primary_form_guidance=dict(source_url='https://www.nyc.gov/assets/planning/download/pdf/applicants/env-review/dutch_kills/appendm_feis.pdf',pdf_sha256=hashlib.sha256(pdf.read_bytes()).hexdigest(),actual_viewed_pdf_pages=[127,128,129,136],forms=[dict(name='28-10 38th Avenue tin shop',evidence='Pre1915 three-storey,three-bay brick/tinwork form;semicircular parapet,bracketed cornice and ground bullseyes. Modern sash/glass-block infill are not period proof.'),dict(name='30-01 39th Avenue dwelling',evidence='Circa1910 two-storey stone/tile-clad dwelling with raised basement,rusticated lower register,curved bay/balustrade and raised stoop. Do not turn it into a three-identical-storey box.'),dict(name='21-02 and21-22 40th Avenue mill lofts',evidence='Circa1912/1911 five-storey brick-mill forms with narrow double-hung openings,stone lintels/sills.21-22 documented100ft×70ft;longer AU parcel needs an explicit adapted composition,not a scaled replica.'),dict(name='Adjacent28-08 dwelling',evidence='Added after1915,but reviewed text does not establish a pre1928 completion date. Remains uncertain guidance,not asserted period canon.1940s/1950s rear extensions excluded.')]),constraints=['No next generation until current three-building intake;no source/data/native/export edits in this survey.','Keep all current three industrial body hashes,registered materials,existing shop/access/traffic authorities and450m radius.','Proposed form guidance does not establish historical parcel placement,elevations,finishes or acceptance.','Coordinate any new external stoop/bay projection with district integration owner;actual floor and capsule proof needed later.'])
p=e/'next_block_readonly_survey_01.json';assert not p.exists();p.write_text(json.dumps(r,indent=2),encoding='utf-8',newline='\n')
print([(v['id'],v['west_facing_frontage_m'],v['depth_m'],v['actual_derived_grade_datum_m'],v['current_export_triangles']) for v in rows])
