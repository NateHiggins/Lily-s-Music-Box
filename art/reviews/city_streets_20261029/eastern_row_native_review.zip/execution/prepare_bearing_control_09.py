from pathlib import Path
here=Path(__file__).parent;previous=here.parent/'east_industrial_01'
s=(previous/'check_eastern_rows_geometry_08.py').read_text(encoding='utf-8')
old="            assert hit is not None and (hit-p).length<.0001,(row['id'],'roof-seat',seat)"
assert s.count(old)==1
new=old+"\n            stock_v,stock_f=buffers[seat['wall_key']];stock=BVHTree.FromPolygons(stock_v,stock_f,all_triangles=False)\n            underside,n,index,distance=stock.ray_cast(p-Vector((0,0,.02)),Vector((0,0,1)),.04)\n            assert underside is not None and (underside-p).length<.0001,(row['id'],'actual-bearing-underside',seat)"
s=s.replace(old,new).replace('rows_geometry_check_08.json','rows_geometry_check_09.json')
q=here/'check_eastern_rows_geometry_09.py';assert not q.exists();q.write_text(s,encoding='utf-8',newline='\n')
