from pathlib import Path
import subprocess,os,json,time,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent
engine='C:/Program Files/Blender Foundation/Blender 5.2/blender.exe'
env=os.environ.copy()
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:env[key]='2'
paths=['art/blender/scripts/build_city_horizon.py','art/blender/scripts/city_industrial_architecture.py','art/data/city_horizon/source_plan.json']
bindings={p:hashlib.sha256((root/p).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in paths}
assert not (out/'native_build_03.json').exists()
started=time.time()
with (out/'build_city_horizon_03.log').open('xb') as log:
    result=subprocess.run([engine,'-b','-t','2','--python-exit-code','1','-P',str(root/paths[0])],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
record=dict(evidence_class='INERT',scope='Native generation/export only;no rendering,Godot or artistic acceptance.',exit_code=result.returncode,seconds=time.time()-started,source_sha256=bindings)
(out/'native_build_03.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print(record,flush=True)
raise SystemExit(result.returncode)
