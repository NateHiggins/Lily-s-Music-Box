from pathlib import Path
import json,hashlib
out=Path(__file__).parent;review=json.loads((out/'native_review_02/review.json').read_text())
assert len(review['captures'])==10 and len(review['roundtrips'])==46 and len(review['lower_roof_and_actual_bearing_controls'])==19
for row in review['captures']:
    assert hashlib.sha256((out/'native_review_02'/row['path']).read_bytes()).hexdigest()==row['sha256']
record=dict(evidence_class='INERT',scope='Allten repaired native views actually inspected,including near/lower bodies and bow/entry detail. Current source/export diagnostics,not Godot runtime,street support or artistic acceptance.',reviewed_images=[r['path'] for r in review['captures']],findings=[dict(id='row_floor_exterior_bands',status='visually-resolved',evidence='Dark bands absent in allthree near/lower bodies and corresponding detail frames;140mm floor clearance control also passes.'),dict(id='buff_brick_color',status='visually-resolved',evidence='Registered grey-brick maps with warm-buff tint now produce a distinct buff/brown facade;original red result preserved.'),dict(id='balustrade_header_readability',status='artistic-review-open',evidence='Wider continuous cap physically passes actual front-face ray controls;central span remains difficult to distinguish against same-color upper wall. No owner/artistic acceptance claimed.')],original_review_preserved='native_review_01/',no_runtime_claim=True)
q=out/'native_inspection_02.json';assert not q.exists();q.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
s=(out/'verify_export_uv_02.py').read_text();q=out/'verify_export_uv_03.py';assert not q.exists();q.write_text(s.replace('uv_audit_02','uv_audit_03').replace('uv_source_binding_02','uv_source_binding_03'),encoding='utf-8',newline='\n')
s=(out/'check_preservation_01.py').read_text();q=out/'check_preservation_02.py';assert not q.exists();q.write_text(s.replace('preservation_01.json','preservation_02.json'),encoding='utf-8',newline='\n')
print('Allten repaired native images hash-verified and inspection recorded')
