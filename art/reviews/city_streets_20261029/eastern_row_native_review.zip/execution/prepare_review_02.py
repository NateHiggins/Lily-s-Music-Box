from pathlib import Path
here=Path(__file__).parent
s=(here/'review_native_01.py').read_text()
old="IDS=['HORIZON_NEAR_2_0_P0R0','HORIZON_NEAR_2_0_P0R1','HORIZON_NEAR_2_0_P0R2','HORIZON_NEAR_2_0_P2','HORIZON_FAR_2_1_P0']"
new="IDS=['HORIZON_NEAR_2_0_P0R0','HORIZON_NEAR_2_0_P0R1','HORIZON_NEAR_2_0_P0R2']"
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('IDS[:4]','IDS').replace(",('city_horizon_far','CityHorizon_far',IDS[4:])",'')
s=s.replace('native_review_01','native_review_02').replace('len(roundtrips)==78 and len(contacts)==29 and len(captures)==16','len(roundtrips)==46 and len(contacts)==19 and len(captures)==10')
q=here/'review_native_02.py';assert not q.exists();q.write_text(s,encoding='utf-8',newline='\n')
s=(here/'run_native_review_01.py').read_text().replace('native_review_01','native_review_02').replace('review_native_01.py','review_native_02.py').replace('native_review_execution_01','native_review_execution_02')
q=here/'run_native_review_02.py';assert not q.exists();q.write_text(s,encoding='utf-8',newline='\n')
