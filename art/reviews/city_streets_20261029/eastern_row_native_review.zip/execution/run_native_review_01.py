from pathlib import Path
import subprocess,os,json,time,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent
engine='C:/Program Files/Blender Foundation/Blender 5.2/blender.exe'
env=os.environ.copy()
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:env[key]='2'
script=out/'review_native_01.py';started=time.time()
with (out/'native_review_01.log').open('xb') as log:
    result=subprocess.run([engine,'-b','-t','2','--python-exit-code','1','-P',str(script)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
record=dict(evidence_class='INERT',scope='Sequential CPU2/Cycles12spp native review only;actual output inspection still required. No Godot or artistic acceptance.',exit_code=result.returncode,seconds=time.time()-started,review_script_sha256=hashlib.sha256(script.read_bytes()).hexdigest())
(out/'native_review_execution_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n');print(record,flush=True)
raise SystemExit(result.returncode)
