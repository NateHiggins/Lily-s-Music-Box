from pathlib import Path
import json,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent
p=out/'native_review_01/review.json';review=json.loads(p.read_text())
assert len(review['captures'])==16
for capture in review['captures']:
    assert hashlib.sha256((p.parent/capture['path']).read_bytes()).hexdigest()==capture['sha256']
record=dict(evidence_class='INERT',scope='All16 rendered native images actually inspected. Render completion/roundtrip checks do not constitute artistic acceptance.',reviewed_images=[r['path'] for r in review['captures']],findings=[dict(id='row_floor_exterior_bands',status='repair-required',evidence='Allthree small forms show dark horizontal bands in near/lower whole/detail frames. Timber floor slab ends overlap exterior masonry planes;inset them into real wall bearing.'),dict(id='buff_brick_color',status='repair-required',evidence='37-32 adaptation renders red/orange with tinted red brick. Reuse the registered grey-brick recipe with an authored warm buff tint;colors remain AU choices.'),dict(id='balustrade_header_readability',status='investigate',evidence='Bow-and-stoop detail makes the central rail hard to distinguish from the wall. Establish actual rail visibility/occlusion before accepting the native presentation.')],unchanged_mill_review=dict(images=[r['path'] for r in review['captures'] if r['building'] in ['HORIZON_NEAR_2_0_P2','HORIZON_FAR_2_1_P0']],scope='Plain brick-mill form,narrow six-over-six windows,roof/flue and full lower bodies visually inspected. Reuse only if subsequent exported geometry/materials remain exact.'),acceptance='not granted')
q=out/'native_inspection_01.json';assert not q.exists();q.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
for relative in ['art/blender/scripts/city_industrial_architecture.py','art/data/city_horizon/source_plan.json']:
    q=out/('first_render_'+Path(relative).name);assert not q.exists();q.write_bytes((root/relative).read_bytes())
print('All16 image hashes verified;source and visual failures preserved')
