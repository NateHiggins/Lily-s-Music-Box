from pathlib import Path
here=Path(__file__).parent;s=(here/'check_eastern_rows_geometry_12.py').read_text()
needle="        vertices=[];faces=[];owners=[]"
guard="""        if author.style=='beauxarts_3001':
            height=author.levels[2];outline=author.outline(True)[4:]
            from city_horizon_geometry import offset_outline
            inset=offset_outline(outline,-.09)
            stock_v,stock_f=buffers['limestone'];caps=BVHTree.FromPolygons(stock_v,stock_f,all_triangles=False)
            for p,q in zip(inset,inset[1:]):
                p=Vector((*p,0));q=Vector((*q,0));u=(q-p).normalized();normal=Vector((-u.y,u.x,0))
                center=(p+q)*.5+Vector((0,0,height+.93))
                hit,n,index,distance=caps.ray_cast(center+normal*.20,-normal,.4)
                assert hit is not None and (hit-(center+normal*.11)).length<.0001,(row['id'],'continuous cap front',list(center),hit)
"""
assert s.count(needle)==1;s=s.replace(needle,guard+needle).replace('rows_geometry_check_12.json','rows_geometry_check_13.json')
q=here/'check_eastern_rows_geometry_13.py';assert not q.exists();q.write_text(s,encoding='utf-8',newline='\n')
