from pathlib import Path
import json,copy
path=Path('C:/ov/city/art/data/city_horizon/source_plan.json');plan=json.loads(path.read_text());before=copy.deepcopy(plan)
row=next(r for r in plan['buildings'] if r['id']=='HORIZON_NEAR_2_0_P0R2')
assert row['wall_key']=='arcade_brick_bond' and row['architecture']['style']=='renaissance_3732'
row['wall_key']='city_grey_brick';row['wall_tint']=[1.,.90,.68,1.]
assert all(a==b for a,b in zip(before['buildings'],plan['buildings']) if a['id']!=row['id'])
path.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Existing registered grey-brick PBR + authored warm buff tint;no new texture/key')
