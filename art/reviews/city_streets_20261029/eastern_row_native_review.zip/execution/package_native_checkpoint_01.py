from pathlib import Path
import hashlib,json,zipfile
root=Path('C:/ov/city');out=Path(__file__).parent;old=out.parent/'east_industrial_01'
destination=root/'art/reviews/city_streets_20261029/eastern_row_native_review.zip'
assert not destination.exists()
original=root/'art/reviews/city_streets_20261029/eastern_industrial_native_review.zip'
expected='8062f3e7d1b108d8435eb0d1ff978d8713b7fc294e6da0a75c0731f8bc5a8cb3'
assert hashlib.sha256(original.read_bytes()).hexdigest()==expected
sources={}
for p in out.iterdir():
    if p.is_file() and p.suffix in ['.py','.json','.log']:sources['execution/'+p.name]=p.read_bytes()
for folder in ['native_review_01','native_review_02']:
    for p in sorted((out/folder).iterdir()):
        assert p.suffix in ['.png','.json'],p
        sources[folder+'/'+p.name]=p.read_bytes()
old_names=['mill_geometry_check_01.json','mill_geometry_check_02.json','mill_helper_initial_01.py','row_helper_failure_01.py','row_helper_failure_02.py','row_helper_failure_03.py','row_helper_blockout_05.py','row_helper_detail_07.py','row_plan_before_outlines_07.json','before_eastern_row_source_plan_01.json','before_three_small_rows_01.json','author_eastern_mills_01.py','author_eastern_rows_01.py','author_row_outlines_02.py','check_eastern_mill_geometry_01.py','check_eastern_mill_geometry_02.py','next_block_readonly_survey_01.json','survey_next_block_readonly_01.py','survey_street_grade_exports_01.py','survey_street_grade_exports_01.json','survey_street_grade_exports_02.py','survey_street_grade_exports_02.json','survey_next_street_envelopes_03.py','next_street_envelope_survey_03.json','survey_next_street_corner_04.py','next_street_corner_survey_04.json','survey_next_street_bypass_05.py','next_street_bypass_survey_05.json']
old_names += [f'rows_geometry_{i:02}.log' for i in range(1,9)]
old_names += [f'check_eastern_rows_geometry_{i:02}.py' for i in range(1,9)]
old_names += ['rows_geometry_check_03.json','rows_geometry_check_05.json','rows_geometry_check_06.json','rows_geometry_check_07.json','rows_geometry_check_08.json']
for name in old_names:
    p=old/name;assert p.is_file(),p;sources['source_controls/'+name]=p.read_bytes()
for relative in ['art/blender/scripts/build_city_horizon.py','art/blender/scripts/city_industrial_architecture.py','art/data/city_horizon/source_plan.json','art/blender/city_horizon_construction.json','game/data/orison_v2/exterior/city_horizon.json']:
    sources['final/'+relative]=(root/relative).read_bytes()
aliases={};png_seen={};stored={}
for name,data in sources.items():
    digest=hashlib.sha256(data).hexdigest()
    if name.endswith('.png') and digest in png_seen:
        aliases[name]=dict(stored_member=png_seen[digest],bytes=len(data),sha256=digest);continue
    if name.endswith('.png'):png_seen[digest]=name
    stored[name]=data
index=dict(evidence_class='INERT',scope='Native source/export/PBR/UV/LOD review and original diagnostics. No Godot runtime contract,street/ground support,rendering-cost budget or artistic acceptance.',sourcebase='59270877243ac40545865788cf3b70bc62780162',original_industrial_archive_sha256=expected,image_aliases=aliases,members={name:dict(bytes=len(data),raw_sha256=hashlib.sha256(data).hexdigest()) for name,data in stored.items()})
index_data=json.dumps(index,indent=2).encode('utf-8');stored['archive_index.json']=index_data
with zipfile.ZipFile(destination,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as archive:
    for name,data in stored.items():archive.writestr(name,data,compress_type=zipfile.ZIP_STORED if name.endswith('.png') else zipfile.ZIP_DEFLATED,compresslevel=1)
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None and set(archive.namelist())==set(stored)
    for name,data in stored.items():assert archive.read(name)==data,name
    for name,alias in aliases.items():assert archive.read(alias['stored_member'])==sources[name],name
assert hashlib.sha256(original.read_bytes()).hexdigest()==expected
attrs=root/'.gitattributes';raw=attrs.read_bytes();line=b'art/reviews/city_streets_20261029/eastern_row_native_review.zip -text\n'
assert line.strip() not in raw
attrs.write_bytes(raw+(b'' if raw.endswith(b'\n') else b'\n')+line)
assert attrs.read_bytes().startswith(raw)
manifest_path=root/'art/reviews/city_streets_20261029/manifest.json';manifest=json.loads(manifest_path.read_text())
assert 'eastern_row_native_archive' not in manifest
record=dict(evidence_class='INERT',archive=destination.relative_to(root).as_posix(),sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),bytes=destination.stat().st_size,members={name:dict(bytes=len(data),raw_sha256=hashlib.sha256(data).hexdigest()) for name,data in stored.items()},image_aliases=aliases,scope=index['scope'],unresolved=['Balustrade central-cap contrast/artistic review.','Native street/ground reservations,loaded Godot materials/mips/LODs,actual access,performance and full-city acceptance.'],original_industrial_archive_unchanged=True)
manifest['eastern_row_native_archive']=record
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'archive_record_01.json').write_text(json.dumps({k:v for k,v in record.items() if k not in ['members','image_aliases']},indent=2),encoding='utf-8',newline='\n')
print(json.dumps(dict(bytes=record['bytes'],sha256=record['sha256'],members=len(stored),stored_pngs=len(png_seen),png_aliases=len(aliases),original140_archive_unchanged=True)))
