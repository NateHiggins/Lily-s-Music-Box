from pathlib import Path
import ast,json,struct,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent
reader=Path('C:/ov/reports/city_streets_20261029/bodega_frontage_reconciliation_01/check_preservation_01.py')
tree=ast.parse(reader.read_text(encoding='utf-8-sig'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(reader),'exec'))
baseline=json.loads((out/'baseline_01.json').read_text())
targets={'HORIZON_NEAR_2_0_P0R0','HORIZON_NEAR_2_0_P0R1','HORIZON_NEAR_2_0_P0R2','HORIZON_NEAR_2_0_P2','HORIZON_FAR_2_1_P0'}
report=dict(evidence_class='INERT',scope='Exact pre/post exported attribute/index/node projections and other asset hashes. Source/native diagnostics,not runtime or artistic acceptance.',parts={},retained_assets={},failures=[])
for family in baseline['parts']:
    old=baseline['parts'][family];new=projection((root/f'game/assets/props/{family}.glb').read_bytes())
    untouched=[k for k in old if k.split('__')[0] not in targets]
    changed=[k for k in untouched if old[k]!=new.get(k)]
    unexpected_added=[k for k in new if k not in old and k.split('__')[0] not in targets]
    report['parts'][family]=dict(unaffected_exact=len(untouched)-len(changed),other_changed=changed,unexpected_added=unexpected_added,added=sorted(new.keys()-old.keys()),removed=sorted(old.keys()-new.keys()))
    report['failures'].extend(changed+unexpected_added)
for path,expected in baseline['retained_assets'].items():
    actual=hashlib.sha256((root/path).read_bytes()).hexdigest();report['retained_assets'][path]=actual
    if actual!=expected:report['failures'].append(path)
old={r['id']:r for r in baseline['profiles']['buildings']}
current=json.loads((root/'art/data/city_horizon/source_plan.json').read_text())
unchanged=[r for r in current['buildings'] if r['id'] not in targets]
assert len(unchanged)==119
report['unchanged_source_profiles']=119
report['reservation_rectangles_exact']=all(r['rect']==old[r['id']]['rect'] for r in current['buildings'])
report['failures'].extend(r['id'] for r in unchanged if r!=old[r['id']])
assert report['reservation_rectangles_exact']
assert not (out/'preservation_02.json').exists()
(out/'preservation_02.json').write_text(json.dumps(report,indent=2),encoding='utf-8',newline='\n')
print(json.dumps({k:{a:v for a,v in row.items() if a not in ['added','removed']} for k,row in report['parts'].items()},indent=2))
print('119 other profiles and',len(report['retained_assets']),'assets compared;failures',len(report['failures']))
assert not report['failures'],report['failures']
