from pathlib import Path
here=Path(__file__).parent
s=(here/'check_eastern_rows_geometry_10.py').read_text()
old="        result=EasternRows(row,emit,[r for r in plan['buildings'] if r['id']!=row['id']],lower=lower).build()"
assert s.count(old)==1
s=s.replace(old,"        author=EasternRows(row,emit,[r for r in plan['buildings'] if r['id']!=row['id']],lower=lower);result=author.build()")
needle="        vertices=[];faces=[];owners=[]"
guard="""        for floor,height in enumerate(author.levels[1:-1],start=1):
            bay=author.style=='renaissance_3732' or author.style=='beauxarts_3001' and floor<2
            outline=author.outline(bay)
            points=[Vector(v) for v in buffers['timber'][0] if abs(v[2]-height)<.0001]
            assert points
            for point in points:
                distances=[]
                for p,q in zip(outline,outline[1:]+outline[:1]):
                    a=Vector(p);b=Vector(q);at=Vector((point.x,point.y));edge=b-a
                    t=max(0.,min(1.,(at-a).dot(edge)/edge.length_squared))
                    distances.append((at-(a+edge*t)).length)
                assert min(distances)>=.1399,(row['id'],'timber reaches exterior face',height,list(point),min(distances))
"""
assert s.count(needle)==1;s=s.replace(needle,guard+needle).replace('rows_geometry_check_10.json','rows_geometry_check_11.json')
q=here/'check_eastern_rows_geometry_11.py';assert not q.exists();q.write_text(s,encoding='utf-8',newline='\n')
