from pathlib import Path
import json,struct,hashlib,numpy as np
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent
DT={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'};WD={'SCALAR':1,'VEC3':3}
def read_city(name):
 p=ROOT/'game/assets/props'/f'{name}.glb';raw=p.read_bytes();off=12
 while off<len(raw):
  n,k=struct.unpack_from('<II',raw,off);off+=8;b=raw[off:off+n];off+=n
  if k==0x4e4f534a:d=json.loads(b)
  elif k==0x004e4942:binary=b
 def acc(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];dt=np.dtype(DT[a['componentType']]);w=WD[a['type']]
  return np.ndarray((a['count'],w),dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',w*dt.itemsize),dt.itemsize)).copy()
 assert all('children' not in n for n in d['nodes']),name
 rows=[]
 for n in d['nodes']:
  if 'mesh' not in n or not n.get('name','').startswith(('site_sw2__',)):continue
  assert not any(k in n for k in ['matrix','rotation','scale']),(name,n)
  for prim in d['meshes'][n['mesh']]['primitives']:
   v=acc(prim['attributes']['POSITION']).astype(float)+n.get('translation',[0,0,0]);i=acc(prim['indices']).ravel().reshape(-1,3)
   v=np.stack([v[:,0],-v[:,2],v[:,1]],axis=1)
   tri=v[i];rows.append((n['name'],tri,tri.min(axis=1),tri.max(axis=1)))
 return rows,{'path':str(p),'sha256':hashlib.sha256(raw).hexdigest()}


rows=[];bindings=[];candidate=np.array([[-44.8,-30.30,10.06],[-34.8,-28.70,10.76]])
for family in ['city_masts','city_aerials','city_tanks','city_beacons']:
 parts,binding=read_city(family);bindings.append(binding)
 for name,tri,lo,hi in parts:
  L=lo.min(axis=0);H=hi.max(axis=0)
  overlaps=bool(np.all(L<=candidate[1]) and np.all(H>=candidate[0]))
  rows.append(dict(family=family,part=name,lo=list(L),hi=list(H),candidate_skylight_aabb_overlap=overlaps))
result=dict(evidence_class='INERT',bindings=bindings,scope='Actual installed exported SW2 hardware bounds. No AABB overlap proves separation only from this proposed envelope; not new skylight construction/acceptance.',candidate_skylight_envelope=candidate.tolist(),hardware=rows,overlaps=[r for r in rows if r['candidate_skylight_aabb_overlap']])
(OUT/'retained_hardware_envelope_01.json').write_text(json.dumps(result,indent=2),encoding='utf-8',newline='\n')
print('retainedhardwareparts',len(rows),'proposedenvelopeoverlaps',len(result['overlaps']))
print(result['overlaps'])
