from pathlib import Path
import sys,ast,json,hashlib,collections,math,re
sys.dont_write_bytecode=True
import bpy,bmesh,numpy as np
from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent;DEST=OUT/'detached_native_01'
(DEST/'art/blender').mkdir(parents=True,exist_ok=True);(DEST/'game/assets/props').mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_commercial_architecture import CommercialFronts
from fabrication_native_batch import material,partition,export
source=ROOT/'art/blender/scripts/build_city_elevations.py';draft=OUT/'delano126_method_01.py'
exec(compile(draft.read_text(encoding='utf-8'),str(draft),'exec'))
CommercialFronts.delano126=delano126
names={'box','profile_stock','arch_stock','turned_stock','roof_panel','clip_roof_polygon','wood_stock_charts'}
tree=ast.parse(source.read_text(encoding='utf-8'));definitions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names];assert {n.name for n in definitions}==names
exec(compile(ast.Module(body=definitions,type_ignores=[]),str(source),'exec'))
records=json.loads((ROOT/'art/blender/city_closure_construction.json').read_bytes())['original_records'];profile=next(p for p in json.loads((ROOT/'art/data/city_elevations/source_plan.json').read_bytes())['buildings'] if p['id']=='site_sw2')
profile.update(floor_heights=[3.3,3.9,2.6],storey_height=3.3,wall_key='limewash_plaster',wall_tint=[.86,.84,.76,1],frame_tint=[.18,.22,.20,1],architecture=dict(type='commercial_front',style='delano126',front_side=2,front_floor_count=3,front_bays=4,roof_depth_m=0,entry_ground_m=-.27225,entry_projection_m=.72))
catalog=json.loads((ROOT/'game/data/runtime_material_sets.json').read_bytes())['materials'];runs=[]
for level in [0,1]:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    with bpy.data.libraries.load(str(ROOT/'art/blender/city_closure.blend'),link=False) as (available,loaded):loaded.objects=[n for n in available.objects if n.startswith('site_sw2_') and (n.endswith('__RetainedStock') or n.endswith('__JoinedParapet'))]
    original={};rings={}
    for obj in loaded.objects:
        bpy.context.scene.collection.objects.link(obj);obj.hide_render=True
        if obj.name.endswith('__RetainedStock'):original[obj.name.removesuffix('__RetainedStock')]=obj
        elif obj.name.endswith('__JoinedParapet'):rings[obj.name.removesuffix('__JoinedParapet')]=obj
    assert 'site_sw2_c0' in original and 'site_sw2' in rings,(list(original),list(rings))
    buffers=collections.defaultdict(lambda:([],[]));stocks=[];roof_samples=[]
    def add(name,key,verts,faces):
        vv,ff=buffers[name,key];offset=len(vv);vv.extend(verts);ff.extend(tuple(offset+i for i in f) for f in faces);stocks.append((name,key,verts,faces))
    owner=CommercialFronts({'site_sw2':profile},records,original,rings,dict(add=add,box=box,profile_stock=profile_stock,arch_stock=arch_stock,turned_stock=turned_stock,roof_panel=roof_panel,clip_roof_polygon=clip_roof_polygon),detail_level=level)
    owner.delano126('site_sw2')
    vertices=[];faces=[];owners=[]
    for index,(name,key,vv,ff) in enumerate(stocks):
        mesh=bpy.data.meshes.new('ClosedStockProof');mesh.from_pydata(vv,[],ff);mesh.update();bm=bmesh.new();bm.from_mesh(mesh)
        assert all(e.is_manifold for e in bm.edges),(level,index,key,'openstock')
        assert bm.calc_volume(signed=True)>1e-10,(level,index,key,'nonpositivevolume')
        bm.free();bpy.data.meshes.remove(mesh);offset=len(vertices);vertices.extend(vv);faces.extend(tuple(offset+i for i in f) for f in ff);owners.extend([key]*len(ff))
    bvh=BVHTree.FromPolygons(vertices,faces);panes=0;portals=0
    for row in owner.window_samples:
        p=Vector(row['point']);n=Vector(row['normal']);hit,normal,index,distance=bvh.ray_cast(p+n*.1,-n,.2)
        assert hit is not None and (hit-p).length<.0001 and owners[index]=='mirror_aged',('pane',level,row,list(hit) if hit else None,owners[index] if hit else None)
        panes+=1
    for row in owner.portal_rows:
        n=[Vector((0,-1,0)),Vector((1,0,0)),Vector((0,1,0)),Vector((-1,0,0))][row['side']];p=Vector(row['point']);hit,normal,index,distance=bvh.ray_cast(p+n*.1,-n,.4)
        assert hit is not None and (hit-(p+n*row['front'])).length<.0001 and owners[index]=='door_paint',('portal',level,row)
        portals+=1
    collection=bpy.data.collections.new('DetachedSW2Body');bpy.context.scene.collection.children.link(collection);parts=[]
    for (name,key),(vv,ff) in sorted(buffers.items()):
        tint=profile['wall_tint'] if key==profile['wall_key'] else profile['frame_tint'] if key=='door_paint' else [.18,.23,.25,1] if key=='mirror_aged' else [1,1,1,1]
        finish=dict(catalog_key=key,tint=tint,pigment=1.,normal=.65,roughness=1.)
        if key=='mirror_aged':finish.update(metallic=.65,roughness=.45,normal=.12)
        mat=material(ROOT,name+'__'+key,finish,catalog)
        mesh=bpy.data.meshes.new('Raw');mesh.from_pydata(vv,[],ff);mesh.update();center=Vector(((min(v[0] for v in vv)+max(v[0] for v in vv))/2,(min(v[1] for v in vv)+max(v[1] for v in vv))/2,0))
        for v in mesh.vertices:v.co-=center
        bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.triangulate(bm,faces=list(bm.faces));zero=[f for f in bm.faces if (f.verts[1].co-f.verts[0].co).cross(f.verts[2].co-f.verts[0].co).length_squared==0]
        if zero:bmesh.ops.delete(bm,geom=zero,context='FACES_ONLY')
        bm.to_mesh(mesh);bm.free();stock=bpy.data.objects.new('Raw',mesh)
        obj=partition(collection,name+'__'+key,[stock],finish,mat,Matrix.Translation(center),catalog)
        if key=='wood_dark':wood_stock_charts(obj,catalog[key]['files'][0])
        bpy.data.objects.remove(stock);bpy.data.meshes.remove(mesh);parts.append(dict(name=obj.name,triangles=len(obj.data.polygons)))
    result=export(DEST,'city_sw2_draft_'+['near','lower'][level],collection,staged_output=True)
    row=dict(lod=level,closed_stocks=len(stocks),panes=panes,closed_portals=portals,roof_samples=len(roof_samples),parts=parts,triangles=sum(p['triangles'] for p in parts),roof_seats=owner.building_rows[-1]['skylight_seat_samples'],export_check=result)
    runs.append(row);print('DETACHED_NATIVE_LOD',level,row['closed_stocks'],panes,portals,len(parts),row['triangles'],flush=True)
    (OUT/'detached_native_proof_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Detached actual geometry/UV/export study only; not installed or runtime/art qualification. Factory native glass is diagnostic; production preview/render and standing body remain required.',frozen_production_head='fe4899a5',source_sha256=hashlib.sha256(draft.read_bytes()).hexdigest(),profile=profile,runs=runs),indent=2),encoding='utf-8',newline='\n')
