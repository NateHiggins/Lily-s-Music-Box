from pathlib import Path
import ast,json,struct,hashlib,numpy as np
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent;DT={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'};WD={'SCALAR':1,'VEC3':3}
s=(OUT/'measure_installed_sections_01.py').read_text(encoding='utf-8');tree=ast.parse(s);exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['read','read_streets','query']],type_ignores=[]),'<existing exported section helpers>','exec'))
base={};bindings=[]
for name in ['orison_ground','city_ground_apron','city_foundations','front_pavement']:
 base[name],binding=read(name);bindings.append(binding)
base['city_streets'],binding=read_streets('city_streets');bindings.append(binding)
def blocked(a,b,assets):
 a=np.array(a);b=np.array(b);d=b-a;distance=np.linalg.norm(d);d/=distance;hits=[]
 for owner,parts in assets.items():
  for name,t,lo,hi in parts:
   mask=np.all(hi>=np.minimum(a,b)-1e-7,axis=1)&np.all(lo<=np.maximum(a,b)+1e-7,axis=1);t=t[mask]
   if not len(t):continue
   e=t[:,1]-t[:,0];f=t[:,2]-t[:,0];h=np.cross(d,f);det=np.einsum('ij,ij->i',e,h);valid=abs(det)>1e-9;t=t[valid];e=e[valid];f=f[valid];h=h[valid];det=det[valid];v=a-t[:,0];u=np.einsum('ij,ij->i',v,h)/det;q=np.cross(v,e);w=q@d/det;z=np.einsum('ij,ij->i',f,q)/det
   valid=(u>=-1e-7)&(w>=-1e-7)&(u+w<=1.0000001)&(z>1e-5)&(z<distance-1e-5)
   for zz in z[valid]:hits.append(dict(owner=owner,part=name,point=list(a+d*zz)))
 return hits
results=[];rays=[]
for lod in ['city_elevations','city_elevations_lod1']:
 assets=dict(base);assets[lod],binding=read_streets(lod);bindings.append(binding)
 stations=[(.60,-.1215),(.36,.02925),(.12,.18),(-.12,.18),(-.60,.18),(-1.05,.18)]
 for t,z in stations:
  for dx in [-.35,0,.35]:
   hits=query(-44.45+dx,-28.32+t);actual=hits[0]['z'] if hits else None;ok=actual is not None and abs(actual-z)<1e-5;results.append(dict(lod=lod,x=-44.45+dx,y=-28.32+t,expected_z=z,actual_z=actual,pass_section=ok));assert ok,results[-1]
 for t,z in stations:
  a=[-44.45,-23.5,2.];b=[-44.45,-28.32+t,z+.001];hits=blocked(a,b,assets);rays.append(dict(lod=lod,a=a,b=b,blockers=hits));assert not hits,rays[-1]
(OUT/'actual_entry_sections_03.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Actual exported combined support sections and review-camera optical rays to tread surfaces. Original low footline intersected expected risers and was an invalid walk criterion; preserved separately. These are optical diagnostics, not standing capsule, runtime route or artistic acceptance.',bindings=bindings,sections=results,approach_rays=rays,failures=[]),indent=2),encoding='utf-8');print('ENTRY_SECTIONS',len(results),'SIGHT_RAYS',len(rays),'failures0')
