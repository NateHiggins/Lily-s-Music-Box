from pathlib import Path
import bpy,json,collections,hashlib,math
from mathutils import Vector,Matrix
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent/'lower_native_review_01';OUT.mkdir(exist_ok=False)
own_paths=[ROOT/'art/blender/city_elevations_lod1.blend',ROOT/'game/assets/props/city_elevations_lod1.glb',ROOT/'art/data/city_elevations/source_plan.json',ROOT/'art/blender/scripts/city_commercial_architecture.py']
own_bindings={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in own_paths}
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'art/blender/city_elevations_lod1.blend'))
primary=['site_sw2'];neighbor=['site_sw3'];plans={r['id']:r for r in json.loads((ROOT/'art/data/city_elevations/source_plan.json').read_bytes())['buildings']}
collection=bpy.data.collections['V2CityElevationReplacementBodies'];native=[o for o in collection.objects if o.name.startswith('site_sw2__')];context=[o for o in collection.objects if o.name.startswith('site_sw3__')]
for o in bpy.context.scene.objects:
 if o.type=='MESH':o.hide_render=True

def triangles(o):return collections.Counter(tuple(sorted(tuple(float(v) for v in o.matrix_world@o.data.vertices[i].co) for i in f.vertices)) for f in o.data.polygons)
expected={o.name:triangles(o) for o in native};mats={o.name:o.data.materials[0] for o in native}
before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(ROOT/'game/assets/props/city_elevations_lod1.glb'))
all_imported=[o for o in bpy.data.objects if o not in before and o.type=='MESH']
for o in all_imported:o.hide_render=True
imported=[o for o in all_imported if o.name.startswith('site_sw2__')];assert len(imported)==len(native)
roundtrip=[]
for o in imported:
 name=o.name.split('.')[0];actual=triangles(o);assert actual==expected[name],name
 assert len(o.data.uv_layers)==1,name
 o.data.uv_layers.active.name='Metres';o.data.materials.clear();o.data.materials.append(mats[name]);roundtrip.append(dict(name=name,triangles=sum(actual.values()),exact_triangle_positions=True))
context_bindings={}
for family in ['city_masts','city_aerials','city_tanks','city_beacons']:
 p=ROOT/'art/blender'/f'{family}.blend';context_bindings[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 with bpy.data.libraries.load(str(p),link=False) as (available,loaded):loaded.objects=[n for n in available.objects if any(n.startswith(k+'__') for k in primary+neighbor) and 'ClosedFabricatedTree' not in n]
 for o in loaded.objects:
  if o.type!='MESH' or o.hide_render:continue
  bpy.context.scene.collection.objects.link(o);o.hide_set(False);o.hide_viewport=False;context.append(o)
for o in native+imported+context:o.location+=Vector(plans[o.name.split('__')[0]].get('assembly_translation_m',[0,0,0]))
sections=json.loads((Path(__file__).parent/'installed_sections_01.json').read_bytes());by_asset={}
for row in sections['vertical_sections']:
 for hit in row['hits']:by_asset.setdefault(hit['asset'],set()).add(hit['part'])
support_bindings={}
for asset,names in by_asset.items():
 p=ROOT/'game/assets/props'/f'{asset}.glb';support_bindings[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest();before=set(bpy.data.objects)
 bpy.ops.import_scene.gltf(filepath=str(p));bpy.context.view_layer.update();selected=[]
 registration=Matrix.Identity(4) if asset=='city_streets' else Matrix.Translation(Vector((0,1.855,0)))@Matrix.Rotation(math.pi,4,'Z')
 for o in [o for o in bpy.data.objects if o not in before]:
  if o.type!='MESH' or o.name.split('.')[0] not in names:bpy.data.objects.remove(o,do_unlink=True);continue
  o.matrix_world=registration@o.matrix_world;o.name='site_sw2__MeasuredSupport_'+o.name;o.hide_set(False);o.hide_viewport=False;context.append(o);selected.append(o)
 assert selected,(asset,names)
 if asset=='city_streets':
  with bpy.data.libraries.load(str(ROOT/'art/blender/city_streets.blend'),link=False) as (available,loaded):loaded.materials=[n for n in available.materials if n.startswith('Street_')]
  native_street_mats={m.name.split('.')[0]:m for m in loaded.materials}
  for o in selected:
   key='Street_'+o.name.split('__')[-1];assert key in native_street_mats,(o.name,key,list(native_street_mats))
   o.data.materials.clear();o.data.materials.append(native_street_mats[key])
for image in bpy.data.images:
 if image.source!='FILE' or image.packed_file:continue
 p=ROOT/'game/assets/building/textures'/Path(image.filepath).name;assert p.is_file(),p
 image.filepath=str(p);image.reload();assert min(image.size)>0,image.name
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.cycles.use_denoising=True
scene.render.threads_mode='FIXED';scene.render.threads=2;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX'
world=bpy.data.worlds.new('Southwest native review');scene.world=world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.16,.19,.24,1);world.node_tree.nodes['Background'].inputs[1].default_value=.55
sun=bpy.data.objects.new('ReviewKey',bpy.data.lights.new('ReviewKey','SUN'));scene.collection.objects.link(sun);sun.rotation_euler=Vector((.4,-.7,-1)).to_track_quat('-Z','Y').to_euler();sun.data.energy=2.5;sun.data.angle=math.radians(15)
camera=bpy.data.objects.new('SouthwestCamera',bpy.data.cameras.new('SouthwestCamera'));scene.collection.objects.link(camera);scene.camera=camera
captures=[]
def shoot(name,visible,at,target,scale=None,resolution=(1100,1000),detail=False):
 assert 'site_sw2' in visible
 for o in native:o.hide_render=True
 for o in imported+context:o.hide_render=o.name.split('__')[0] not in visible
 camera.location=at;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO' if scale else 'PERSP';camera.data.ortho_scale=scale or 30;camera.data.lens=38
 scene.render.resolution_x,scene.render.resolution_y=resolution;framed=None
 if not detail:
  from bpy_extras.object_utils import world_to_camera_view
  objects=[o for o in imported+context if not o.hide_render and '__MeasuredSupport_' not in o.name]
  for attempt in range(20):
   bpy.context.view_layer.update();points=[world_to_camera_view(scene,camera,o.matrix_world@Vector(corner)) for o in objects for corner in o.bound_box]
   framed=all(p.z>0 and .035<=p.x<=.965 and .035<=p.y<=.965 for p in points)
   if framed:break
   factor=max(1.08,max(max(abs(p.x-.5),abs(p.y-.5))/.46 for p in points))
   if scale:camera.data.ortho_scale*=factor
   else:camera.location=Vector(target)+(camera.location-Vector(target))*factor
  assert framed,name
 scene.render.filepath=str(OUT/(name+'.png'));bpy.ops.render.render(write_still=True);p=OUT/(name+'.png')
 captures.append(dict(file=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),visible=visible,camera=list(camera.location),target=list(target),complete_building_hardware_framed=framed,intentional_detail_crop=detail,terrain_context_partially_framed=True))
shoot('block_corner',['site_sw2','site_sw3'],(-17,-5,22),(-45,-31,9),None,(1400,1100))
shoot('entry_ground',['site_sw2'],(-44.45,-23.5,2.0),(-44.45,-28.5,1.0),5.8,(1100,1100),True)
shoot('skylight_roof',['site_sw2'],(-27,-18,18),(-39.8,-30.5,11.0),17.,(1200,1000),True)
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in own_bindings.items()),'Review inputs mutated'
result=dict(own_bindings=own_bindings,evidence_class='INERT',scope='Actual new native/export exact triangle-position roundtrip and CPU images with unchanged firehouse/hardware,real existing streets and measured ground/foundation context. Terrain partially framed; ground/foundation neutralglTF material is diagnostic. No runtime/controller/loaded-mipmap or artistic acceptance.',roundtrip=roundtrip,context_bindings=context_bindings,support_bindings=support_bindings,captures=captures)
(OUT/'native_review.json').write_text(json.dumps(result,indent=2),encoding='utf-8',newline='\n');print('SW2_NATIVE_REVIEW',len(captures),len(roundtrip),flush=True)
