from pathlib import Path
import json,hashlib,zipfile,subprocess,stat
root=Path('C:/ov/city').resolve();out=Path('C:/ov/reports/city_streets_20261029/southwest_carriagehouse_01');proof=json.loads((out/'generated_uid_preservation_01.json').read_text(encoding='utf-8'));archive=Path(proof['archive']);assert hashlib.sha256(archive.read_bytes()).hexdigest()==proof['archive_sha256']
tracked=set(subprocess.run(['git','ls-files','-z'],cwd=root,capture_output=True,check=True).stdout.decode('utf-8').split('\0'));untracked=set(subprocess.run(['git','ls-files','--others','--exclude-standard','-z'],cwd=root,capture_output=True,check=True).stdout.decode('utf-8').strip('\0').split('\0'))
assert untracked=={e['path'] for e in proof['entries']}
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for e in proof['entries']:
  rel=e['path'];p=root/rel;resolved=p.resolve();assert root in resolved.parents and rel not in tracked and rel.endswith('.uid');assert not p.is_symlink();assert not any(getattr(q.stat(),'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT for q in [p,*p.parents] if q!=q.parent)
  raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==e['sha256'] and raw==z.read(rel)
 for e in proof['entries']:(root/e['path']).unlink()
proof['scope']='Only638 owned untracked import-generated UID files individually resolved/reparse/tracked/hash checked and removed after own Godot process terminal. Raw bytes exactly reused existing archive; no duplicate backup.';proof['removed']=638;(out/'generated_uid_cleanup_01.json').write_text(json.dumps(proof,indent=2),encoding='utf-8',newline='\n');print('Removed638 owned UID outputs, original bytes preserved/exact')
# Frozen portable packet excludes reference photos/PDF/text and production meshes.
files={}
for p in out.rglob('*'):
 if not p.is_file() or p.suffix not in ['.json','.py','.png','.log','.stderr']:continue
 rel=p.relative_to(out).as_posix()
 if p.name.startswith('reference_') and p.suffix!='.json':continue
 files[rel]=p.read_bytes()
for rel in ['art/blender/scripts/city_commercial_architecture.py','art/blender/scripts/build_city_closure.py','art/blender/scripts/build_city_elevations.py','art/blender/scripts/build_city_elevation_lods.py','art/blender/scripts/build_city_streets.py','art/data/city_elevations/source_plan.json','game/tests/v2_city_elevation_bench.gd','game/tests/fixtures/orison_city_elevations.json','game/tests/fixtures/orison_city_elevations_lod1.json','game/data/orison_v2/exterior/city_elevations.json']:
 files['frozen_sources/'+rel]=(root/rel).read_bytes()
ziprel='art/reviews/city_streets_20261029/southwest_carriagehouse_native_isolated_review.zip';path=root/ziprel
with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for rel,data in sorted(files.items()):z.writestr(rel,data)
with zipfile.ZipFile(path) as z:
 assert z.testzip() is None
 assert all(z.read(k)==v for k,v in files.items())
entry={'path':ziprel,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,'members':len(files),'evidence_class':'INERT','scope':'SW2 actual native and isolated loaded geometry/material/mip/LOD/timing diagnostics; original failures retained. No standing controller/composed/artistic acceptance.','files':{k:{'bytes':len(v),'raw_sha256':hashlib.sha256(v).hexdigest()} for k,v in sorted(files.items())}}
p=root/'art/reviews/city_streets_20261029/manifest.json';d=json.loads(p.read_text(encoding='utf-8'));d['southwest_carriagehouse_native_isolated_archive']=entry;p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n');print('ARCHIVE',entry['members'],entry['bytes'],entry['sha256'])
p=root/'design/V2_CITY_CONTEXT_REPORT_2026-10-19.md';s=p.read_text(encoding='utf-8');s+='''
REPORT - K-V2-CITY-REVAMP - 2026-10-30

Evidence class: **INERT**. SW2 native/isolated diagnostics, not acceptance.

The actual current patched-Vulkan fullscreen3440x1440 bench passes **7162/0**,
1205 roof samples and1067 family draws. The unmodified wrapper receipt
**southwest_carriagehouse_01/bench_01.log.receipt.json** records41.72seconds,
completed/exit0/no timeout and empty stderr. It is **suite_run**,not a schema-2
runtime_contract. Seven current loaded images were inspected,eleven native
images indexed,and207 loaded source hashes match after the run. UV/PBR/loaded
mipmap checks pass in this isolated scene. Production lighting and whole-city
artistic acceptance remain open.

At MSAA3/TAAoff,uncapped/vsyncoff,the SW2+equipment group uses25 draws:
20550 near and16943 forced-lower primitives. Five cases each retain90 warmed
frames. First near viewport GPU median1.199/p951.51305/max1.692ms;wall
median1.6865/p952.5371/max**39.929ms**,four frames above16.667ms. Subsequent
far/natural/far-repeat/near-repeat GPU medians.771/.775/.769/.668ms and wall
maxima1.323/1.531/1.558/1.273ms. Original samples remain intact. First-case
wall spikes are unexplained; no quiet-host,matched baseline,causal speedup,
cold-start or whole-city performance claim. Existing316.861ms composed spike
and Windows startup hang remain separate unresolved findings.

Actual limewash material-body transition occurs between189.2158219 and
189.2315820metres,2036 to1292primitives. Five-degree FOV recovers2036;
inward return restores the original before-PNG bytes exactly. This proves a
single material-body transition,not an entire-world LOD/artistic threshold.
All retained body parts,including limestone entrance and glazed skylight,keep
full replacement body meshes. No detail-only deletion substitutes for the LOD.

Import25.61seconds and compiler14.76seconds completed normally. Import stderr
retains126454bytes of638 missing-UID/cache-recreation warnings;all lines were
inspected and contain only those warnings/location lines. An earlier message
incorrectly said both logs were empty; corrected without rerunning. Compiler
stderr is empty.1474 texture import policies are correct,four source preflights
pass. Own638 generated untracked UID bytes exactly match the existing raw ZIP;
after own Godot terminal they were individually guarded and removed. No tracked
UID or unrelated checkout/index/process changed.

Portable **southwest_carriagehouse_native_isolated_review.zip** indexes every
member hash in the existing manifest;CRC/member bytes verified. It retains
original native/setup/low-footline failures,raw loaded timings and original
wrapper receipts. Reference pixels/PDFs and duplicate production meshes are
excluded. Current source checkpoint is **a3bdb703**. SW2 standing-body step-up,
ascent/descent,footway and composed physical qualification remain open.
Canonical's narrower E/Bodega+west cohort independently reports7086/0 isolated
and256 checks/eight actual movement legs/0,including real door grab/move/release
and inside/outside. That is not SW2 qualification; original234/6/2 remains.
Published tally stays21/149 until canonical renewal/publication is complete.
''';p.write_text(s,encoding='utf-8',newline='\n')
p=root/'TASKS.md';s=p.read_text(encoding='utf-8');start=s.index('- **K-V2-CITY-REVAMP');end=s.index('\n',start);s=s[:end]+' SW2 isolated7162/0 in41.72s,7 loaded views inspected,207 input hashes exact;25 draws/20550→16943 primitives. First warmed wallmax39.929ms remains unexplained; actual SW2 standing/controller/composed qualification still open. Canonical narrower houses have7086/0 isolated and256/8/0 actual door/controller result; publication remains separate.'+s[end:];p.write_text(s,encoding='utf-8',newline='\n')
