from pathlib import Path
import json,hashlib,subprocess,struct,sys
root=Path('C:/ov/city');out=Path(__file__).parent
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='fe4899a5baa9528cd428201d00e394dfc596ef12'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
(out/'setup_failure_01.json').write_text(json.dumps(dict(evidence_class='INERT',error='NameError: struct not imported while collecting baseline; source mutation stage was not reached. Subsequent missing runner also stopped without native work.',production_changes=0),indent=2),encoding='utf-8',newline='\n')
src=Path('C:/ov/reports/city_streets_20261029/narrow_neighbors_01/compare_export_preservation_01.py').read_text(encoding='utf-8');exec(src[src.index('def projection'):src.index('result=dict')])
assets={}
for family in ['city_shells','city_elevations','city_elevations_lod1','city_streets','city_streets_lod1']:
 p=root/'game/assets/props'/f'{family}.glb';assets[family]=dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
 if family in ['city_elevations','city_elevations_lod1']:assets[family]['parts']=projection(p)
plan_path=root/'art/data/city_elevations/source_plan.json';old=json.loads(plan_path.read_bytes())
(out/'baseline_01.json').write_text(json.dumps(dict(evidence_class='INERT',head='fe4899a5',assets=assets,profiles=old['buildings']),indent=2),encoding='utf-8',newline='\n')
p=root/'art/blender/scripts/city_commercial_architecture.py';s=p.read_text(encoding='utf-8');method=(out/'delano126_method_01.py').read_text(encoding='utf-8');assert 'def delano126' not in s
s=s.replace('    def build(self, name):','\n'.join('    '+line if line else '' for line in method.splitlines())+'\n\n    def build(self, name):')
s=s.replace('    def build(self, name):\n',"    def build(self, name):\n        if self.specs[name]['style']=='delano126':\n            return self.delano126(name)\n")
p.write_text(s,encoding='utf-8',newline='\n')
r=next(r for r in old['buildings'] if r['id']=='site_sw2')
r.update(description='Four-bay AU carriagehouse studio with bracketed balcony,tall segmental French casements,circular upper windows and pitched glazed attic;retained service bulkhead and plant',floor_heights=[3.3,3.9,2.6],storey_height=3.3,wall_key='limewash_plaster',wall_tint=[.86,.84,.76,1],frame_tint=[.18,.22,.20,1],architecture=dict(type='commercial_front',style='delano126',front_side=2,front_floor_count=3,front_bays=4,roof_depth_m=0,entry_ground_m=-.27225,entry_projection_m=.72,precedent='INERT:LPC LP2102,p113/p153,126 East38th Street,Delano&Aldrich1916 alteration,c1869carriagehouse,three storiesANDattic,cementstucco. Explicit AUfour-bay12.4m frontage/9.8m body with retained roofplant;not exact1928height/condition. Blindwestpartywall/exposedeastcrossstreet,three shallow risers on measuredpavement;glazedfrontatticstrip clears7roofcontacts/13hardwareparts. No lettering/interior/shop authority.'))
plan_path.write_text(json.dumps(old,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['build_city_elevations.py','build_city_elevation_lods.py']:
 p=root/'art/blender/scripts'/name;s=p.read_text(encoding='utf-8').replace("['site_ne1','site_nbr_w','site_nbr_e']","['site_ne1','site_nbr_w','site_nbr_e','site_sw2']")
 if name=='build_city_elevations.py':
  s=s.replace("'linford119':('roof_bitumen',)","'delano126':('roof_bitumen','galvanized_roof','mirror_aged'),'linford119':('roof_bitumen',)")
  s=s.replace("['ottendorfer','faber','fulton','jamaica','linford119','hayden113']","['ottendorfer','faber','fulton','jamaica','linford119','hayden113','delano126']")
 p.write_text(s,encoding='utf-8',newline='\n')
s=Path('C:/ov/reports/city_streets_20261029/narrow_neighbors_01/run_native_build_05.py').read_text(encoding='utf-8').replace("builder+'.stoop.log'","builder+'.log'").replace("'native_build_05.json'","'native_build_01.json'")
(out/'run_native_build_01.py').write_text(s,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-m','py_compile',str(root/'art/blender/scripts/city_commercial_architecture.py'),str(root/'art/blender/scripts/build_city_elevations.py'),str(root/'art/blender/scripts/build_city_elevation_lods.py')],check=True,cwd=root)
subprocess.run([sys.executable,str(out/'run_native_build_01.py')],check=True,cwd=root)
