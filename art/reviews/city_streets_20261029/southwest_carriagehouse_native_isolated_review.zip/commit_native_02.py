from pathlib import Path
import subprocess,sys
root=Path('C:/ov/city');p=root/'design/V2_CITY_CONTEXT_REPORT_2026-10-19.md';s=p.read_text(encoding='utf-8');s+='''
SW2 native continuation after Bodega repair intake: merged **99398ee7** source
into the saved city branch, preserving both evidence sections and regenerating
closure,near,lower and street derivatives. No canonical checkout edits.
The carriagehouse outer archivolt/jamb courses now project beyond the plaster;
its deep barrel ends behind the facade, with a separate proud keystone clear
of the balcony. Plinth tops recess5mm below the landing. Native near/lower
entry and complete firehouse-block views were inspected (four new views);
unchanged balcony/skylight views from the first review remain applicable.
Actual export multisets match native geometry for all12 SW2 material parts.
SW2 near/lower **15710/12518 triangles**;1154 new near stocks are closed and
positive. Full lower10771 stocks/555 bearings/575 panes pass. Near126 roof,
12 return,1205 bearing and2557 pane samples pass. Four source preflights and
two-asset UV audit pass. Compared with the repair checkpoint,all266 near and
143 lower non-SW2 parts are exact,including the complete E/Bodega fix. Compared
with the first SW2 WIP,all11 non-limestone SW2 parts are exact at both levels.

Combined exported support diagnostics pass36 tread/landing sections and12
review-camera sight rays. The first attempted low footline rays correctly hit
the stair risers; that is an invalid straight-line walk criterion,not a failed
standing-controller run. Original script/trace are retained. Revised optical
rays establish visibility only; production step-up/full-capsule ascent/descent
and sidewalk clear passage remain open. External evidence stays under
**southwest_carriagehouse_01**, including the original detached cap-seat/setup
failures and original/revised native images. No runtime,loaded mips,LOD timing
or artistic acceptance from the new native checkpoint. Published count stays
**21/149** until canonical source-bound controller/composed qualification.
''';p.write_text(s,encoding='utf-8',newline='\n')
p=root/'TASKS.md';s=p.read_text(encoding='utf-8');start=s.index('- **K-V2-CITY-REVAMP');end=s.index('\n',start);s=s[:end]+' Native continuation:99398ee7 repair source merged back; SW2 entrance trim corrected,near/lower15710/12518triangles,4 revised native views inspected,36 support sections/12 optical rays pass. Loaded/LOD measurements and real standing-controller checks remain open.'+s[end:];p.write_text(s,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'tools/lint_design_doc.py','design/V2_CITY_CONTEXT_REPORT_2026-10-19.md'],cwd=root,check=True)
paths=['TASKS.md','design/V2_CITY_CONTEXT_REPORT_2026-10-19.md','art/blender/city_closure.blend','art/blender/city_closure_construction.json','art/blender/city_elevations.blend','art/blender/city_elevations_construction.json','art/blender/city_elevations_lod1.blend','art/blender/city_elevations_lod1_construction.json','art/blender/city_streets.blend','art/blender/city_streets_construction.json','art/blender/scripts/build_city_elevations.py','art/blender/scripts/build_city_elevation_lods.py','art/blender/scripts/city_commercial_architecture.py','art/data/city_elevations/source_plan.json','game/assets/props/city_elevations.glb','game/assets/props/city_elevations_lod1.glb','game/tests/fixtures/orison_city_closure.json','game/tests/fixtures/orison_city_elevations.json','game/tests/fixtures/orison_city_elevations_lod1.json','game/tests/fixtures/orison_city_streets.json','game/tests/v2_city_elevation_bench.gd','art/reviews/city_streets_20261029/bodega_frontage_native_reconciliation.zip','art/reviews/city_streets_20261029/manifest.json']
subprocess.run(['git','add','--']+paths,cwd=root,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
assert not subprocess.run(['git','diff','--name-only','--diff-filter=U'],cwd=root,capture_output=True,check=True).stdout
subprocess.run(['git','commit','-m','Carry retained Bodega repair into city and finish carriagehouse entry stonework'],cwd=root,check=True)
subprocess.run(['git','push','origin','codex/v2-city-20261029'],cwd=root,check=True)
