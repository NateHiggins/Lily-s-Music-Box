from pathlib import Path
import subprocess,re,ast
root=Path('C:/ov/city');out=Path('C:/ov/reports/city_streets_20261029/southwest_carriagehouse_01')
def content(rev,path):return subprocess.run(['git','show',rev+':'+path],cwd=root,capture_output=True,check=True).stdout.decode('utf-8')
# Preserve both append-only evidence sections, with no unresolved conflict marker.
p=root/'design/V2_CITY_CONTEXT_REPORT_2026-10-19.md';s=p.read_text(encoding='utf-8');s=re.sub(r'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>> codex/v2-city-bodega-fix-20261030\n',lambda m:m[1]+'\n'+m[2],s,flags=re.S);p.write_text(s,encoding='utf-8',newline='\n')
p=root/'TASKS.md';s=content('99398ee7','TASKS.md');line=next(l for l in content('HEAD','TASKS.md').splitlines() if l.startswith('- **K-V2-CITY-REVAMP'));extra=line.split(' SW2 carriagehouse now')[1];start=s.index('- **K-V2-CITY-REVAMP');end=s.index('\n',start);s=s[:end]+' SW2 carriagehouse now'+extra+s[end:];p.write_text(s,encoding='utf-8',newline='\n')
p=root/'game/tests/v2_city_elevation_bench.gd';s=content('HEAD','game/tests/v2_city_elevation_bench.gd');s=s.replace('fixture.portals.size()==26,"twenty-five retained passive portals and one new recessed studio leaf"','fixture.portals.size()==25,"twenty-four retained city portals and one studio leaf; Bodega remains separately owned"');s=s.replace('(3 if identity=="site_ne1" else 2 if identity=="site_sw3" else 1)','(0 if identity=="site_nbr_e" else 3 if identity=="site_ne1" else 2 if identity=="site_sw3" else 1)');s=s.replace('"site_nbr_e":16,"site_sw2":33','"site_nbr_e":14,"site_sw2":33').replace('all577 studied panes','all575 studied panes');p.write_text(s,encoding='utf-8',newline='\n')
# Derived assets use our preserved SW2 snapshot only as producer starting input;
# every closure/near/lower/street dependency is regenerated next.
derived=['art/blender/city_closure.blend','art/blender/city_closure_construction.json','art/blender/city_elevations.blend','art/blender/city_elevations_construction.json','art/blender/city_elevations_lod1.blend','art/blender/city_elevations_lod1_construction.json','art/blender/city_streets.blend','art/blender/city_streets_construction.json','game/assets/props/city_elevations.glb','game/assets/props/city_elevations_lod1.glb','game/tests/fixtures/orison_city_closure.json','game/tests/fixtures/orison_city_elevations.json','game/tests/fixtures/orison_city_elevations_lod1.json','game/tests/fixtures/orison_city_streets.json']
subprocess.run(['git','checkout','--ours','--']+derived,cwd=root,check=True)
p=root/'art/blender/scripts/city_commercial_architecture.py';s=p.read_text(encoding='utf-8');index=s.index('    def delano126(');prefix=s[:index];m=s[index:];m=m.replace("((i+1)*width/14-.001,.03,.18)","((i+1)*width/14-.001,.03,.175)")
m=m.replace("(r,-.2,spring))","(r,-.205,spring))")
needle="self.arch_stock(name,'limestone',origin,u,out,center,spring,.66,.66,.10,-recess-.48,-.20,self.profile_steps)"
replacement="""self.arch_stock(name,'limestone',origin,u,out,center,spring,.66,.66,.10,-recess-.48,-.205,self.profile_steps)
                # Proud outer archivolt and jamb courses seat in the plaster,
                # while the deep barrel continues behind the face without a
                # coplanar duplicate. Keystone clears the balcony underside.
                self.arch_stock(name,'limestone',origin,u,out,center,spring,.66,.66,.13,-.26,-.04,self.profile_steps)
                for l,r in [(wl-.13,wl),(wr,wr+.13)]:
                    self.local_box(name,'limestone',origin,u,out,(l,-.26,-.65),(r,-.04,spring))
                self.profile_stock(name,'limestone',origin,u,out,[(center-.075,high-.02),(center+.075,high-.02),(center+.06,high+.17),(center-.06,high+.17)],-.27,-.015)"""
assert needle in m;m=m.replace(needle,replacement);p.write_text(prefix+m,encoding='utf-8',newline='\n');ast.parse(prefix+m)
subprocess.run(['python',str(out/'run_native_build_01.py')],cwd=root,check=True)
