from pathlib import Path
import subprocess,os,json
root=Path('C:/ov/city');out=Path(__file__).parent;engine='C:/Program Files/Blender Foundation/Blender 5.2/blender.exe'
for family in ['near','lower']:
 p=out/f'review_{family}_01.py';s=p.read_text(encoding='utf-8');s=s.replace(f"{family}_native_review_01",f"{family}_native_review_02");s='\n'.join(line for line in s.splitlines() if not line.startswith("shoot('balcony_order'") and not line.startswith("shoot('skylight_roof'"))+'\n';p=out/f'review_{family}_02.py';p.write_text(s,encoding='utf-8',newline='\n')
 with (out/f'review_{family}_02.log').open('wb') as log:subprocess.run([engine,'-b','-t','2','--python-exit-code','1','-P',str(p)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('NATIVE_REVIEW_FINISHED',family,flush=True)
