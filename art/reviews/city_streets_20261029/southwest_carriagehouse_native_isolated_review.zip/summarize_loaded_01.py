from pathlib import Path
import json,hashlib,statistics,math
root=Path('C:/ov/city');out=Path('C:/ov/reports/city_streets_20261029/southwest_carriagehouse_01');d=json.loads((out/'bench_01/city_elevation_profile.json').read_text(encoding='utf-8'))
assert d['checks']==7162 and d['failures']==[]
def pct(v,p):
 v=sorted(v);at=(len(v)-1)*p;lo=math.floor(at);return v[lo]+(v[min(lo+1,len(v)-1)]-v[lo])*(at-lo)
observations=[]
for row in d['observations']:
 summary={k:row[k] for k in ['id','draws','primitives','distance_m']};summary['frames']=len(row['frame_samples']);summary['timing_ms']={}
 for key in ['viewport_cpu_ms','viewport_gpu_ms','wall_ms']:
  values=[s[key] for s in row['frame_samples']];summary['timing_ms'][key]={'median':statistics.median(values),'p95_linear':pct(values,.95),'max':max(values),'over_16_667ms':sum(v>16.667 for v in values)}
 observations.append(summary)
bindings=[]
for rel,expected in d['source_hashes'].items():
 p=root/'game'/rel.removeprefix('res://');raw=p.read_bytes()
 if p.suffix in ['.gd','.json','.gdshader','.gdshaderinc','.import']:raw=raw.decode('utf-8').replace('\r\n','\n').encode('utf-8')
 actual=hashlib.sha256(raw).hexdigest();assert actual==expected,(rel,actual,expected);bindings.append(rel)
images=[{'path':p.relative_to(out).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((out/'bench_01').glob('*.png'))];assert len(images)==7
assert (out/'bench_01/site_sw2_natural_before.png').read_bytes()==(out/'bench_01/site_sw2_natural_return.png').read_bytes()
receipt=json.loads((out/'bench_01.log.receipt.json').read_text(encoding='utf-8'));assert receipt['execution']['completed'] and receipt['execution']['exit_code']==0 and Path(receipt['log']['stderr']).stat().st_size==0
result={'evidence_class':'INERT','scope':'Actual isolated native-resolution current loaded geometry/material/UV/mipmap and LOD diagnostics. No test-written runtime_contract, standing controller, whole city budget or artistic acceptance.','checks':7162,'failures':[],'receipt':'bench_01.log.receipt.json','wrapper_seconds':receipt['execution']['elapsed_s'],'images_inspected':images,'source_inputs_exact':len(bindings),'settings':d['settings'],'observations':observations,'natural_transition':d['natural_transitions'],'findings':['All7 actual images inspected. Full building image retains four-bay upper order,oculi,balcony,entrance and rooftop plant; isolated bench omits adjacent city/production lighting.','Actual material-only natural transition retains apertures; narrowFOV recovers near detail and before/returnPNG bytes match.','First warmed near case has wall spikes despite small viewport GPU timings; cause undetermined. No quiet-host or matched-baseline claim. Repeated cases are retained as measurements, not a causal speedup.','No production standing-player access proof for SW2 yet. Original native floorline diagnostic hit expected risers; not a runtime failure or acceptance.']}
(out/'actual_bench_inspection_01.json').write_text(json.dumps(result,indent=2),encoding='utf-8',newline='\n')
for r in observations:print(r['id'],r['draws'],r['primitives'],r['frames'],'GPU',r['timing_ms']['viewport_gpu_ms'],'wall',r['timing_ms']['wall_ms'])
print(len(bindings),'actual loaded inputs exact;7 images inspected;before-return exact')
