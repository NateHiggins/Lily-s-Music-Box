from pathlib import Path
import ast,json,subprocess
root=Path('C:/ov/city');out=Path(__file__).parent
s=Path('C:/ov/reports/city_streets_20261029/bodega_frontage_reconciliation_01/check_preservation_01.py').read_text(encoding='utf-8-sig');tree=ast.parse(s);exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),'<projection>','exec'),globals())
import struct,hashlib
rows=[]
for family in ['city_elevations','city_elevations_lod1']:
 path='game/assets/props/'+family+'.glb';actual=projection((root/path).read_bytes())
 for baseline,select in [('99398ee7',lambda k:not k.startswith('site_sw2__')),('28834fea',lambda k:k.startswith('site_sw2__') and not k.endswith('__limestone'))]:
  old=projection(subprocess.run(['git','show',baseline+':'+path],cwd=root,capture_output=True,check=True).stdout);keys=[k for k in old if select(k)];failed=[k for k in keys if old[k]!=actual.get(k)];assert not failed,failed
  rows.append(dict(family=family,baseline=baseline,exact_parts=len(keys),failures=failed))
(out/'preservation_02.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Actual exported accessors/transforms; current E fix and every non-SW2 part exact, SW2 only limestone changes from original native WIP',checks=rows),indent=2),encoding='utf-8');print(rows)
p=out/'check_near_closed_stocks_01.py';s=p.read_text(encoding='utf-8');s=s.replace('near_closed_stocks_01.json','near_closed_stocks_02.json');(out/'check_near_closed_stocks_02.py').write_text(s,encoding='utf-8',newline='\n')
