from pathlib import Path
import json,struct,hashlib,numpy as np
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent
DT={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'};WD={'SCALAR':1,'VEC3':3}
def read(name):
 p=ROOT/'game/assets/props'/f'{name}.glb';raw=p.read_bytes();off=12
 while off<len(raw):
  n,k=struct.unpack_from('<II',raw,off);off+=8;b=raw[off:off+n];off+=n
  if k==0x4e4f534a:d=json.loads(b)
  elif k==0x004e4942:binary=b
 def acc(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];dt=np.dtype(DT[a['componentType']]);w=WD[a['type']]
  return np.ndarray((a['count'],w),dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',w*dt.itemsize),dt.itemsize)).copy()
 assert all('children' not in n for n in d['nodes']),name
 rows=[]
 for n in d['nodes']:
  if 'mesh' not in n or 'water_clear' in n.get('name',''):continue
  assert not any(k in n for k in ['matrix','rotation','scale']),(name,n)
  for prim in d['meshes'][n['mesh']]['primitives']:
   v=acc(prim['attributes']['POSITION']).astype(float)+n.get('translation',[0,0,0]);i=acc(prim['indices']).ravel().reshape(-1,3)
   # GLB positions are already Godot building-frame XYZ. Registered PI yaw
   # and translation(0,0,-11.65), then invert city street b2g/threshold.
   v[:,0]*=-1;v[:,2]=-v[:,2]-11.65
   v=np.stack([v[:,0],-v[:,2]-9.795,v[:,1]],axis=1)
   tri=v[i];rows.append((n['name'],tri,tri.min(axis=1),tri.max(axis=1)))
 return rows,{'path':str(p),'sha256':hashlib.sha256(raw).hexdigest()}
assets={};bindings=[]
for name in ['orison_ground','city_ground_apron','city_foundations','front_pavement']:
 assets[name],binding=read(name);bindings.append(binding)
def query(x,y):
 hits=[]
 for asset,parts in assets.items():
  for name,tri,lo,hi in parts:
   mask=(lo[:,0]<=x+1e-7)&(hi[:,0]>=x-1e-7)&(lo[:,1]<=y+1e-7)&(hi[:,1]>=y-1e-7)
   t=tri[mask]
   if not len(t):continue
   a=t[:,0];u=t[:,1]-a;v=t[:,2]-a;det=u[:,0]*v[:,1]-u[:,1]*v[:,0];valid=abs(det)>1e-10
   t=t[valid];a=a[valid];u=u[valid];v=v[valid];det=det[valid]
   b=((x-a[:,0])*v[:,1]-(y-a[:,1])*v[:,0])/det;c=(u[:,0]*(y-a[:,1])-u[:,1]*(x-a[:,0]))/det
   valid=(b>=-1e-6)&(c>=-1e-6)&(b+c<=1+1e-6)
   z=a[:,2]+b*u[:,2]+c*v[:,2]
   for value in z[valid]:
    if -4<float(value)<1:hits.append({'asset':asset,'part':name,'z':round(float(value),7)})
 return sorted(hits,key=lambda r:r['z'],reverse=True)

def read_streets(name):
 p=ROOT/'game/assets/props'/f'{name}.glb';raw=p.read_bytes();off=12
 while off<len(raw):
  n,k=struct.unpack_from('<II',raw,off);off+=8;b=raw[off:off+n];off+=n
  if k==0x4e4f534a:d=json.loads(b)
  elif k==0x004e4942:binary=b
 def acc(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];dt=np.dtype(DT[a['componentType']]);w=WD[a['type']]
  return np.ndarray((a['count'],w),dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',w*dt.itemsize),dt.itemsize)).copy()
 assert all('children' not in n for n in d['nodes']),name
 rows=[]
 for n in d['nodes']:
  if 'mesh' not in n or 'water_clear' in n.get('name',''):continue
  assert not any(k in n for k in ['matrix','rotation','scale']),(name,n)
  for prim in d['meshes'][n['mesh']]['primitives']:
   v=acc(prim['attributes']['POSITION']).astype(float)+n.get('translation',[0,0,0]);i=acc(prim['indices']).ravel().reshape(-1,3)
   v=np.stack([v[:,0],-v[:,2],v[:,1]],axis=1)
   tri=v[i];rows.append((n['name'],tri,tri.min(axis=1),tri.max(axis=1)))
 return rows,{'path':str(p),'sha256':hashlib.sha256(raw).hexdigest()}

assets['city_streets'],binding=read_streets('city_streets');bindings.append(binding)
rows=[]
for x in [-45.7,-44.45,-43.,-41.5,-40.,-38.5,-37.,-35.5,-33.9]:
 for y in [-28.7,-28.5,-28.34,-28.32,-28.30,-28.15,-28.,-27.8,-27.5,-27.,-26.,-25.,-24.2]:
  hits=query(x,y);rows.append(dict(x=x,y=y,hits=hits[:5]))
def horizontal(x,z):
 origin=np.array([x,-26.32,z]);direction=np.array([0.,-1.,0.]);hits=[]
 for asset,parts in assets.items():
  for name,tri,lo,hi in parts:
   mask=(lo[:,0]<=x+1e-7)&(hi[:,0]>=x-1e-7)&(lo[:,2]<=z+1e-7)&(hi[:,2]>=z-1e-7)&(hi[:,1]>=-30.32)&(lo[:,1]<=-26.32)
   t=tri[mask]
   if not len(t):continue
   e1=t[:,1]-t[:,0];e2=t[:,2]-t[:,0];h=np.cross(direction,e2);det=np.einsum('ij,ij->i',e1,h);valid=abs(det)>1e-9
   e1=e1[valid];e2=e2[valid];h=h[valid];det=det[valid];t=t[valid];v=origin-t[:,0];u=np.einsum('ij,ij->i',v,h)/det;q=np.cross(v,e1);b=q@direction/det;distance=np.einsum('ij,ij->i',e2,q)/det
   valid=(u>=-1e-6)&(b>=-1e-6)&(u+b<=1.000001)&(distance>=0)&(distance<=4.)
   for dist in distance[valid]:hits.append(dict(asset=asset,part=name,point=list(origin+direction*dist),distance=float(dist)))
 return sorted(hits,key=lambda r:r['distance'])
sides=[]
for x in [-45.,-44.45,-43.9]:
 for z in [-.30,-.20,-.10,0.,.05,.18,.50,1.5]:sides.append(dict(x=x,z=z,hits=horizontal(x,z)[:4]))
result=dict(evidence_class='INERT',scope='Read-only actual exported installed ground/foundation/pavement AND street triangle sections. Horizontal barriers recorded separately; no production standing capsule or continuous route proof.',bindings=bindings,vertical_sections=rows,horizontal_sections=sides)
(OUT/'installed_sections_01.json').write_text(json.dumps(result,indent=2),encoding='utf-8',newline='\n')
for r in rows:
 if r['x']==-44.45:print('floor',r['y'],r['hits'][:1])
for r in sides:
 if r['x']==-44.45:print('side',r['z'],r['hits'][:1])
