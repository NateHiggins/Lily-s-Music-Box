from pathlib import Path
import json,subprocess,sys,hashlib
root=Path('C:/PleaseRemainOnTheLine');run=Path(sys.argv[1]);mode=sys.argv[2];sys.path.insert(0,str(root/'tools'));from v2_surface_evidence import file_hash,test_dependency_paths
paths=test_dependency_paths(root,{root/p for p in ['game/tests/v2_city_horizon_bench.gd','game/tests/V2CityHorizonBench.tscn','game/tests/v2_entry_render_preparation_test.gd','game/tests/V2EntryRenderPreparationTest.tscn','game/tests/native_debug_window.gd','game/tests/CompileChangedScripts.tscn','game/tests/compile_changed_scripts.gd']})
actual=subprocess.check_output([sys.executable,'tools/run_receipt.py','digest','--root',str(root)],cwd=root,text=True).strip();files={str(p.relative_to(root)).replace('\\','/'):file_hash(p) for p in sorted(paths) if p.is_file()}
if mode=='capture':
 (run/'SOURCE_FREEZE.json').write_text(json.dumps({'runtime_inputs_sha256':actual,'files':files},indent=2)+'\n');print('CAPTURED',len(files),actual)
else:
 expected=json.loads((run/'SOURCE_FREEZE.json').read_bytes());assert expected['runtime_inputs_sha256']==actual,'production sources changed';assert files==expected['files'],'diagnostic sources changed';print('UNCHANGED',len(files),actual)
 if mode=='after':
  for name in ['compile','entry_bench','city_family']:
   receipt=json.loads((run/(name+'.log.receipt.json')).read_text(encoding='utf-8-sig'));e=receipt['execution'];assert e['completed'] and e['exit_code']==0 and not e['timed_out'] and receipt['log']['script_error_count']==0,(name,e)
   assert hashlib.sha256((run/(name+'.log')).read_bytes()).hexdigest()==receipt['log']['stdout_sha256'],name

  compile_raw=(run/'compile.log').read_bytes();assert b'SCRIPT COMPILATION: PASS; 4 scripts; 0 failures; no composed world' in compile_raw
  entry_raw=(run/'entry_bench.log').read_bytes();assert b'ENTRY RENDER PREPARATION: ' in entry_raw and b'0 failures' in entry_raw
  outcome=json.loads((run/'city_family/family_outcome.json').read_bytes());assert not outcome['failures'] and outcome['checks']>0
  assert len(outcome['roof_controls'])==4 and len(outcome['derivative_controls'])==2
  profile=json.loads((run/'city_family/city_industrial_profile.json').read_bytes());selection=json.loads((run/'selection.json').read_bytes());wanted={r['id'] for r in selection['buildings']}
  assert len(wanted)==9 and set(profile['requested_profiles'])==wanted and not profile['failures']
  assert len(profile['observations'])==45 and {r['building'] for r in profile['observations']}==wanted
  assert set(profile['natural_transitions'])==wanted and all(r['after'] for r in profile['natural_transitions'].values())
  print('VERIFIED NINE PROFILE PROGRAMMES AND COMPLETE FAMILY OUTCOME')
