from pathlib import Path
import json,sys,subprocess,hashlib
root=Path('C:/PleaseRemainOnTheLine');run=Path(__file__).parent;out=run.parent
subprocess.run([sys.executable,str(out/'guard_loaded.py'),str(run),'check'],cwd=root,check=True)
freeze=json.loads((run/'SOURCE_FREEZE.json').read_bytes());reuse=json.loads((run/'REUSED_ENTRY.json').read_bytes())
assert freeze['runtime_inputs_sha256']==reuse['runtime_inputs_sha256']
sys.path.insert(0,str(root/'tools'));from v2_surface_evidence import file_hash
assert all(file_hash(root/n)==v for n,v in reuse['entry_test_files'].items())
assert hashlib.sha256(Path(reuse['receipt']).read_bytes()).hexdigest()==reuse['receipt_sha256']
for name in ['compile','city_family']:
 r=json.loads((run/(name+'.log.receipt.json')).read_text(encoding='utf-8-sig'));e=r['execution'];log=r['log'];assert e['completed'] and e['exit_code']==0 and not e['timed_out'] and not log['script_error_count'],(name,e)
 for stream in ['stdout','stderr']:assert hashlib.sha256(Path(log[stream]).read_bytes()).hexdigest()==log[stream+'_sha256']
assert b'SCRIPT COMPILATION: PASS; 1 scripts; 0 failures; no composed world' in (run/'compile.log').read_bytes()
family=json.loads((run/'city_family/family_outcome.json').read_bytes());assert not family['failures'] and family['checks']>0
assert family['test_sha256']==hashlib.sha256((root/'game/tests/v2_city_horizon_bench.gd').read_bytes()).hexdigest()
assert family['fixture_sha256']==hashlib.sha256((root/'game/tests/fixtures/orison_city_horizon.json').read_bytes()).hexdigest()
assert family['native_inventory']==dict(expected_static=1110,seen_static=1110,expected_lower=1093,seen_lower=1093,checked_panes=17180,clock_hands=dict(expected=4,seen=4)),family['native_inventory']
assert len(family['roof_controls'])==4 and len(family['derivative_controls'])==2
profile=json.loads((run/'city_family/city_industrial_profile.json').read_bytes());selection=json.loads((run/'selection.json').read_bytes());wanted={r['id'] for r in selection['buildings']}
assert len(wanted)==9 and set(profile['requested_profiles'])==wanted and not profile['failures']
assert len(profile['observations'])==45 and {r['building'] for r in profile['observations']}==wanted
assert set(profile['natural_transitions'])==wanted and all(r['after'] for r in profile['natural_transitions'].values())
print('FAMILY GUARD PASS: actual1110static/1093lower/17180panes/4hands,9profiles/45observations; unchanged39check entry bench reused. No composed/runtime/artistic acceptance.')
