"""Read-only actual native/export review of the Western street-facing row."""
from pathlib import Path
import bpy,collections,json,hashlib
from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree
from bpy_extras.object_utils import world_to_camera_view
root=Path('C:/ov/city');out=Path(__file__).parent/'native_review_03';out.mkdir(exist_ok=False)
ids=['HORIZON_NEAR_3_0_P0R0','HORIZON_NEAR_3_0_P0R1','HORIZON_NEAR_3_0_P0R2','HORIZON_NEAR_3_0_P1','HORIZON_NEAR_3_0_P2']
fixture=json.loads((root/'game/tests/fixtures/orison_city_horizon.json').read_bytes());profiles={r['id']:r for r in fixture['buildings']};roundtrips=[];captures=[];contacts=[];bindings={}
def tris(obj):
    obj.data.calc_loop_triangles()
    return collections.Counter(tuple(sorted(tuple(float(c) for c in obj.matrix_world@obj.data.vertices[i].co) for i in t.vertices)) for t in obj.data.loop_triangles)

def context_load(relative,names,transform=Matrix.Identity(4)):
    path=root/relative;bindings[relative]=hashlib.sha256(path.read_bytes()).hexdigest()
    with bpy.data.libraries.load(str(path),link=False) as (source,loaded):loaded.objects=list(names)
    for obj in loaded.objects:bpy.context.scene.collection.objects.link(obj)
    bpy.context.view_layer.update()
    for obj in loaded.objects:
        assert obj.parent is None
        obj.matrix_world=transform@obj.matrix_world;obj.hide_viewport=False;obj.hide_render=False
    bpy.context.view_layer.update()
    return loaded.objects

def terrain_context():
    gm=json.loads((root/'art/blender/orison_ground_construction.json').read_bytes())
    am=json.loads((root/'art/blender/city_ground_apron_construction.json').read_bytes())
    soil=context_load('art/blender/orison_ground.blend',[p['id'] for p in gm['parts']])
    soil+=context_load('art/blender/city_ground_apron.blend',[p['name'] for p in am['parts']])
    vv=[];ff=[]
    for obj in soil:
        start=len(vv);vv.extend(obj.matrix_world@v.co for v in obj.data.vertices)
        ff.extend(tuple(start+i for i in p.vertices) for p in obj.data.polygons)
        # Render only actual source stocks near this row, without editing stock.
        corners=[obj.matrix_world@Vector(c) for c in obj.bound_box]
        obj.hide_render=not (min(p.x for p in corners)<=180 and max(p.x for p in corners)>=135 and min(p.y for p in corners)<=155 and max(p.y for p in corners)>=80)
    tree=BVHTree.FromPolygons(vv,ff)
    layout=json.loads((root/'game/data/orison_v2_blockout.json').read_bytes());frame=json.loads((root/'game/data/orison_v2/exterior/street_frame.json').read_bytes())
    shift=-(next(d for d in layout['doors'] if d['id']=='F01_DOOR_06')['center'][1]+frame['source_threshold_z'])
    transform=Matrix.Translation((0,shift,0))@Matrix.Diagonal((-1,-1,1,1))
    with bpy.data.libraries.load(str(root/'art/blender/city_streets.blend'),link=False) as (source,loaded):loaded.collections=['StreetExports_LOD0']
    bpy.context.scene.collection.children.link(loaded.collections[0]);loaded.collections[0].hide_viewport=False
    bpy.context.view_layer.update()
    for obj in loaded.collections[0].objects:
        obj.matrix_world=transform@obj.matrix_world;obj.hide_render=True
    bpy.context.view_layer.update()
    return tree

for family,collection in [('city_horizon_near','CityHorizon_near')]:
    native=root/f'art/blender/{family}.blend';bindings[str(native.relative_to(root))]=hashlib.sha256(native.read_bytes()).hexdigest();bpy.ops.wm.open_mainfile(filepath=str(native))
    for col in bpy.data.collections:col.hide_viewport=False
    for obj in bpy.context.scene.objects:obj.hide_viewport=False;obj.hide_render=True
    bpy.context.view_layer.update();original={o.name:o for o in bpy.data.collections[collection].objects if o.name.split('__')[0] in ids};imported={}
    for asset in fixture['assets'].values():
        if Path(asset['native']).stem!=family or not set(asset['buildings'])&set(ids):continue
        path=root/asset['asset'];bindings[str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest();before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(path));bpy.context.view_layer.update()
        for obj in [o for o in bpy.data.objects if o not in before and o.type=='MESH']:
            name=obj.name.split('.')[0];obj.hide_render=name not in original
            if obj.hide_render:continue
            assert name not in imported and tris(obj)==tris(original[name]),(family,name,'world triangles')
            assert len(obj.data.uv_layers)==1
            obj.data.materials.clear();obj.data.materials.append(original[name].data.materials[0]);imported[name]=obj;roundtrips.append(dict(family=family,part=name,exact_world_triangles=True))
    assert set(imported)==set(original),(family,set(original)-set(imported))
    verts=[];faces=[];owners=[]
    for name,obj in imported.items():
        n=len(verts);verts.extend(obj.matrix_world@v.co for v in obj.data.vertices);faces.extend(tuple(n+i for i in p.vertices) for p in obj.data.polygons);owners.extend([name]*len(obj.data.polygons))
    tree=BVHTree.FromPolygons(verts,faces)
    for window in fixture['window_rows']:
        if window['building'] not in ids:continue
        p=Vector(window['point']);normal=Vector(window['normal']);hit,n,index,d=tree.ray_cast(p+normal*.03,-normal,.30)
        assert hit is not None and owners[index]==window['building']+'__mirror_aged' and (hit-(p-normal*window['recess_m'])).length<.0001,(family,'pane',window,owners[index] if index is not None else None)
        contacts.append(dict(family=family,kind='actual_first_pane',building=window['building']))
    # A continuous1.05m minimum parcel-edge lane lies outside every stoop.
    # Full capsule movement is a separate runtime check; these are native rays.
    soil_tree=terrain_context()
    a,b,c,d=profiles['HORIZON_NEAR_3_0_P1']['rect'];end=d
    for i in range(201):
        station=b+.5+(end-b-1)*i/200;x=a+.5;y=-station
        row=profiles['HORIZON_NEAR_3_0_P1']
        datum=float(row['grade_datum_m'])
        hit,n,index,distance=tree.ray_cast(Vector((x,y,datum+.10)),Vector((0,0,-1)),.20)
        assert hit is not None and owners[index].endswith('__concrete') and abs(hit.z-datum)<.0001,(family,'front support',x,y,hit,datum)
        ground,gn,gi,gd=soil_tree.ray_cast(Vector((x,y,datum+.5)),Vector((0,0,-1)),1.)
        assert ground is not None and datum-ground.z>=.019,(family,'actual terrain rises through apron',x,y,ground,datum)
        contacts.append(dict(family=family,kind='real_soil_below_frontage',point=[x,y,datum],soil_z=ground.z))
        for dx,dy in [(0,0),(.33,0),(-.33,0),(0,.33),(0,-.33)]:
            hit,n,index,distance=tree.ray_cast(Vector((x+dx,y+dy,datum+.03)),Vector((0,0,1)),1.524)
            assert hit is None,(family,'lane clearance',x,y,owners[index] if index is not None else None)
    for image in bpy.data.images:
        if image.source!='FILE' or image.packed_file:continue
        path=root/'game/assets/building/textures'/Path(image.filepath).name;assert path.is_file();image.filepath=str(path);image.reload();assert min(image.size)>0
    scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.cycles.use_denoising=True;scene.cycles.max_bounces=4;scene.render.threads_mode='FIXED';scene.render.threads=2;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX';scene.render.resolution_percentage=100;scene.render.resolution_x=1200;scene.render.resolution_y=950
    world=bpy.data.worlds.new('Western frontage native review');world.use_nodes=True;scene.world=world;world.node_tree.nodes['Background'].inputs[0].default_value=(.18,.21,.27,1);world.node_tree.nodes['Background'].inputs[1].default_value=.7
    sun=bpy.data.objects.new('Diagnostic key',bpy.data.lights.new('Diagnostic key','SUN'));scene.collection.objects.link(sun);sun.rotation_euler=Vector((-1,.35,-.9)).to_track_quat('-Z','Y').to_euler();sun.data.energy=2.5;sun.data.angle=.15
    cam=bpy.data.objects.new('Native review camera',bpy.data.cameras.new('Native review camera'));scene.collection.objects.link(cam);scene.camera=cam;cam.data.type='ORTHO';cam.data.clip_start=.02;cam.data.clip_end=1000
    for label,chosen in [('sohmer_front',ids),('sohmer_rear',ids)]:
        sun.rotation_euler=Vector((1,-.35,-.9) if 'front' in label else (-1,.35,-.9)).to_track_quat('-Z','Y').to_euler()
        visible=[]
        for name,obj in imported.items():
            obj.hide_render=name.split('__')[0] not in chosen
            if not obj.hide_render:visible.append(obj)
        corners=[o.matrix_world@Vector(c) for o in visible for c in o.bound_box];lo=Vector([min(v[i] for v in corners) for i in range(3)]);hi=Vector([max(v[i] for v in corners) for i in range(3)]);aim=(lo+hi)*.5;cam.location=aim+Vector((1,-.45,.72) if 'rear' in label else (-1,.55,.55)).normalized()*90;cam.rotation_euler=(aim-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=max(hi.x-lo.x,hi.y-lo.y,hi.z-lo.z)*1.2
        for attempt in range(24):
            bpy.context.view_layer.update();points=[world_to_camera_view(scene,cam,p) for p in corners]
            if all(p.z>0 and .04<=p.x<=.96 and .04<=p.y<=.96 for p in points):break
            cam.data.ortho_scale*=1.1
        else:raise AssertionError((family,label,'framing'))
        if label=='hayes_portal':
            row=profiles[ids[1]];middle=(float(row['rect'][1])+float(row['rect'][3]))/2;datum=float(row['grade_datum_m'])
            front=float(row['architecture']['outline_m'][9][0]);cam.data.type='PERSP';cam.data.lens=22.
            cam.location=Vector((front-4.5,-middle,datum+1.41));target=Vector((front+3.0,-middle,datum+1.8));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
        path=out/(family+'_'+label+'.png');scene.render.filepath=str(path);bpy.ops.render.render(write_still=True);captures.append(dict(file=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),whole_selected_geometry_framed=label!='hayes_portal',buildings=chosen,scope='partial portal eye diagnostic' if label=='hayes_portal' else 'whole body oblique'))
        cam.data.type='ORTHO'
for path,digest in bindings.items():assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest
assert len(captures)==2 and len(roundtrips)>20 and len(contacts)>201
(out/'review.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Actual corrected five-body block native/export exact world-triangle and UV-layer review, all five-body fixture pane first hits and201 Sohmer apron stations over real terrain;2 whole-block near front/rear CPU renders with registered native materials. Unchanged Sohmer lower/target views retain their original separate provenance. Not Godot collision,loaded maps,actual access,performance or artistic acceptance.',roundtrips=roundtrips,contacts=contacts,captures=captures,source_sha256=bindings),indent=2),encoding='utf-8',newline='\n')
print('NATIVE WESTERN TERRAIN CONTACT PASS',len(roundtrips),'roundtrips',len(contacts),'pane controls',len(captures),'images',flush=True)
