from pathlib import Path
import json,hashlib,zipfile,subprocess
root=Path('C:/ov/city');out=Path(__file__).parent;review=root/'art/reviews/city_streets_20261029'
archive_path=review/'cedar_approach_review.zip';assert not archive_path.exists()
text_suffixes={'.gd','.py','.json','.gdshader','.gdshaderinc','.import','.tscn','.tres','.md','.txt'}
def digest(raw):return hashlib.sha256(raw).hexdigest()
runtime_bindings={}
for relative in ['family_04/cedar_approach.runtime.json','access_03/cedar_access.runtime.json']:
    record=json.loads((out/relative).read_bytes());assert not record['failures'] and record['execution']['completed']
    for name,expected in record['source_hashes'].items():
        path=(root/'game'/name.removeprefix('res://')).resolve();assert path.is_relative_to(root)
        raw=path.read_bytes();actual=digest(raw.replace(b'\r\n',b'\n') if path.suffix in text_suffixes else raw)
        assert actual==expected,(relative,name,'current runtime binding mismatch')
        key=path.relative_to(root).as_posix();assert key not in runtime_bindings or runtime_bindings[key]==actual;runtime_bindings[key]=actual
world=json.loads((out/'world_01/cedar_composed.runtime.json').read_bytes());assert not world['failures'] and world['programme']['passed']
for name in ['family_04','access_03','world_01']:
    receipt=json.loads((out/(name+'.log.receipt.json')).read_bytes());assert receipt['execution']['completed'] and receipt['execution']['exit_code']==0 and not receipt['execution']['timed_out'];assert (out/(name+'.log.stderr')).stat().st_size==0
asset_paths=['art/blender/city_horizon_near.blend','art/blender/city_horizon_far.blend','art/blender/city_horizon_lod1.blend','game/assets/props/city_horizon_near_2_1.glb','game/assets/props/city_horizon_near_2_1_lod1.glb','art/blender/city_horizon_construction.json','game/tests/fixtures/orison_city_horizon.json','game/data/orison_v2/exterior/city_horizon.json']
assets={p:dict(bytes=(root/p).stat().st_size,sha256=digest((root/p).read_bytes())) for p in asset_paths}
prior={}
index=subprocess.run(['git','ls-files','--stage','-z','--','art/reviews/city_streets_20261029'],cwd=root,capture_output=True,check=True).stdout
for line in index.split(b'\0'):
    if not line:continue
    metadata,name=line.split(b'\t',1);name=name.decode()
    if not name.endswith('.zip'):continue
    raw=(root/name).read_bytes();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==metadata.split()[1].decode(),name
    prior[name]=digest(raw)
selected=[]
for path in out.iterdir():
    if path.is_file() and path.suffix in {'.json','.py','.gd','.tscn','.log','.stderr'}:selected.append(path)
for folder in ['native_review_01','family_01','family_02','family_03','family_04','access_01','access_02','access_03','world_01','candidate_board_01']:
    for path in (out/folder).rglob('*'):
        if path.is_file() and path.suffix in {'.json','.md','.txt','.log','.stderr','.png'}:selected.append(path)
selected=sorted(set(selected));members={};aliases={};image_digests={}
# Store final reviewed image bytes once. Earlier identical captures keep explicit aliases.
selected.sort(key=lambda p:(0 if any(folder in p.parts for folder in ['native_review_01','family_04','access_03','world_01']) else 1,p.as_posix()))
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for path in selected:
        relative=path.relative_to(out).as_posix();raw=path.read_bytes();sha=digest(raw)
        if path.suffix=='.png' and sha in image_digests:aliases[relative]=image_digests[sha];continue
        if path.suffix=='.png':image_digests[sha]=relative
        archive.writestr(relative,raw);members[relative]=dict(bytes=len(raw),raw_sha256=sha)
    record=dict(evidence_class='INERT',scope='Native construction and exact-scope test-written contracts; raw failed and rejected diagnostics retained. Only final family04/access03/world01 qualify their declared scopes. No broader city,global surface,saves,performance or artistic acceptance.',baseline_commit='17ac565cc89adfc5d69c16b5e55284da535c65a3',members=members,image_aliases=aliases,runtime_input_bindings=runtime_bindings,generated_asset_bindings=assets,prior_archives_byte_exact_to_index=prior,external_originals=str(out))
    archive.writestr('index.json',json.dumps(record,indent=2)+'\n')
with zipfile.ZipFile(archive_path) as archive:
    for name,entry in members.items():assert digest(archive.read(name))==entry['raw_sha256']
    for name,target in aliases.items():assert digest(archive.read(target))==digest((out/name).read_bytes())
manifest_path=review/'manifest.json';manifest=json.loads(manifest_path.read_bytes());assert 'cedar_approach_archive' not in manifest
manifest['cedar_approach_archive']=dict(evidence_class='INERT',archive=archive_path.name,bytes=archive_path.stat().st_size,sha256=digest(archive_path.read_bytes()),member_count=len(members)+1,index='index.json',runtime_bindings=len(runtime_bindings),generated_assets=len(assets),prior_archives_preserved=len(prior),scope=record['scope'])
manifest_path.write_text(json.dumps(manifest,indent=2,ensure_ascii=True)+'\n',encoding='utf-8',newline='\n')
(out/'package_01.json').write_text(json.dumps(manifest['cedar_approach_archive'],indent=2),encoding='utf-8',newline='\n');print(json.dumps(manifest['cedar_approach_archive']))
