from pathlib import Path
import subprocess,json,hashlib,re,zipfile,datetime
root=Path('C:/ov/city').resolve();out=Path(__file__).parent
assert not (out/'cleanup_owned_imports_01.json').exists()
def git(*args):return subprocess.run(['git',*args],cwd=root,capture_output=True,check=True).stdout
index_before=git('write-tree').decode().strip()
stages={}
for row in git('ls-files','--stage','-z').split(b'\0'):
    if not row:continue
    meta,path=row.split(b'\t',1);stages[path.decode()]=meta.split()[1].decode()
untracked=[p.decode() for p in git('ls-files','--others','--exclude-standard','-z').split(b'\0') if p]
receipts=[json.loads((out/f'import_{i:02}.log.receipt.json').read_bytes()) for i in [1,2]]
def stamp(value):return datetime.datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()
start=min(stamp(r['execution']['started_utc']) for r in receipts)-2;end=max(stamp(r['execution']['finished_utc']) for r in receipts)+2
uids=[]
for relative in untracked:
    assert relative.endswith('.uid'),('unexpected untracked path',relative)
    path=(root/relative).resolve();assert path.is_relative_to(root) and relative[:-4] in stages
    raw=path.read_bytes();assert re.fullmatch(rb'uid://[a-z0-9]+\s*',raw),(relative,'UID syntax')
    assert start<=path.stat().st_mtime<=end,(relative,'outside owned import interval',path.stat().st_mtime,start,end)
    uids.append((relative,raw))
assert len(uids)==673,('unexpected owned UID roster',len(uids))
changes=[p.decode() for p in git('status','--porcelain=v1','-z','--untracked-files=no').split(b'\0') if p]
imports=[]
for status in changes:
    relative=status[3:]
    if not relative.endswith('.import'):continue
    assert status[:2]==' M',('unexpected staged import',status)
    raw=(root/relative).read_bytes();normalized=raw.replace(b'\r\n',b'\n');oid=hashlib.sha1(b'blob '+str(len(normalized)).encode()+b'\0'+normalized).hexdigest()
    assert oid==stages[relative],('real import-policy change: refuse restore',relative)
    imports.append((relative,raw))
backup=out/'owned_import_backup_01.zip'
with zipfile.ZipFile(backup,'x',compression=zipfile.ZIP_DEFLATED) as archive:
    for relative,raw in uids+imports:archive.writestr(relative,raw)
with zipfile.ZipFile(backup) as archive:
    for relative,raw in uids+imports:assert archive.read(relative)==raw
for relative,raw in uids:
    path=(root/relative).resolve();assert path.is_relative_to(root) and path.read_bytes()==raw;path.unlink()
for offset in range(0,len(imports),40):git('restore','--worktree','--',*[r for r,b in imports[offset:offset+40]])
assert git('write-tree').decode().strip()==index_before
for relative,raw in imports:assert (root/relative).read_bytes().replace(b'\r\n',b'\n')==raw.replace(b'\r\n',b'\n')
record=dict(evidence_class='INERT',scope='Only this clean-start worktree import-generated untrackedUIDs and demonstrated index-equivalent import filters; no trackedUIDs,index entries,art inputs or canonical files changed.',removed_uid_count=len(uids),restored_import_count=len(imports),uid_paths=[r for r,b in uids],import_paths=[r for r,b in imports],index_tree_unchanged=index_before,backup_sha256=hashlib.sha256(backup.read_bytes()).hexdigest())
(out/'cleanup_owned_imports_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n');print('Owned cleanup',len(uids),'UIDs,',len(imports),'index-equivalent imports; verified byte backup; index unchanged')
