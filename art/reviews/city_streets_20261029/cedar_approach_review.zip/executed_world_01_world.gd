extends "res://tests/orison_v2_floor_surface_test.gd"
const Programme=preload("res://tmp/city_cedar_approach_01/world_programme.gd")
func _snapshot()->Dictionary:
    var root=ProjectSettings.globalize_path("res://..").simplify_path()
    var output:Array=[]
    if OS.execute("python",[root.path_join("tools/v2_surface_evidence.py"),"--snapshot"],output)!=0 or output.is_empty():return {}
    var result:Dictionary=JSON.parse_string(str(output[0]))
    result["test_overlay"]={}
    for path:String in [get_script().resource_path,"res://tmp/city_cedar_approach_01/world_programme.gd"]:result.test_overlay[path]=FileAccess.get_sha256(path)
    return result

func _run()->void:
    var directory=OS.get_environment("SHOT_DIR")
    check(not directory.is_empty() and DisplayServer.get_name()!="headless","fullscreen graphical output required")
    if not failures.is_empty():get_tree().quit(1);return
    DirAccess.make_dir_recursive_absolute(directory)
    RealityState.persistence_enabled=false;RealityState.reset_campaign_for_tests();CampaignTime.set_frozen_for_tests(true)
    GameBoot.settings.weather_network_enabled=false;GameBoot.launch_mode=GameBoot.LaunchMode.CINEMATIC
    check(CampaignClock.new().configure_date(1928,11,10,660),"authoritative campaign daytime selection")
    var before=_snapshot();check(not before.is_empty(),"production source snapshot exists")
    var world=_world_scene().instantiate() as OrisonV2RuntimeRoot
    add_child(world)
    while not world.startup_failed and world.startup_ms<=0.:await get_tree().process_frame
    check(not world.startup_failed and world.player!=null,"actual production world and player ready")
    var programme={"executed":false,"passed":false}
    var startup=world.startup_ms
    if not world.startup_failed and world.player!=null:
        world.player.set_physics_process(false)
        for frame in 40:await get_tree().physics_frame
        programme=await Programme.new().run(world,self)
    var retired=weakref(world);world.shutdown_for_tests();world.free();await get_tree().physics_frame
    check(retired.get_ref()==null,"actual production world retires")
    var after=_snapshot();check(before==after,"production rendering inputs remain frozen")
    var record={"schema_version":2,"evidence_kind":"runtime_contract","selector":"v2","production_runtime":true,"scope":"Actual composed city: one validated street placement, public street join, three scenic row stoop roundtrips and lane return through normal controller/input with unchanged collision and guards. Specific12legs/7endpoints; no full-surface survey,saves,450m exploration,wholecity performance or artistic acceptance.","execution":{"completed":true,"exit_code":0 if failures.is_empty() else 1,"timed_out":false},"source":{"test_path":"game/"+get_script().resource_path.trim_prefix("res://"),"test_sha256":FileAccess.get_sha256(get_script().resource_path),"runtime_inputs_sha256":JSON.stringify(before).sha256_text()},"source_snapshot":before,"checks":batch_checks,"failures":failures,"programme":programme,"startup_ms":startup,"contracts":{"composed_street_and_row_access":{"executed":programme.executed,"passed":programme.passed and failures.is_empty()}}}
    var file=FileAccess.open(directory.path_join("cedar_composed.runtime.json"),FileAccess.WRITE)
    if file==null:push_error("Cannot write composed contract");get_tree().quit(1);return
    file.store_string(JSON.stringify(record,"\t"));file.close()
    print("CEDAR COMPOSED ",batch_checks," checks ",failures.size()," failures")
    get_tree().quit(0 if failures.is_empty() else 1)
