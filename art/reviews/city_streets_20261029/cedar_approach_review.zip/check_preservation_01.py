from pathlib import Path
import ast,struct,json,hashlib,numpy as np
root=Path('C:/ov/city');out=Path(__file__).parent
for path in [out.parent/'bodega_frontage_reconciliation_01/check_preservation_01.py',out.parent/'horizon_shards_01/bind_world_frames_01.py']:
    tree=ast.parse(path.read_text(encoding='utf-8-sig'));exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(path),'exec'))
baseline=json.loads((out/'baseline_01.json').read_text());fixture=json.loads((root/'game/tests/fixtures/orison_city_horizon.json').read_text());targets=set(json.loads((out/'source_prepare_01.json').read_text())['targets']);new={};assets={}
for asset in fixture['assets'].values():
    raw=(root/asset['asset']).read_bytes();data=projection(raw);size=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+size]);world=frames(doc);family=Path(asset['native']).stem;target=new.setdefault(family,{})
    for node in doc['nodes']:
        if 'mesh' not in node:continue
        name=node['name'];data[name]['materials']=[doc['materials'][p['material']]['name'] if 'material' in p else None for p in doc['meshes'][node['mesh']]['primitives']];data[name]['world_transform']=world[name];assert name not in target;target[name]=data[name]
    digest=hashlib.sha256(raw).hexdigest();assert digest==asset['sha256'];assets[asset['asset']]=dict(bytes=len(raw),sha256=digest,unchanged=digest==baseline['assets'].get(asset['asset']))
failures=[];counts={}
for family,old in baseline['parts'].items():
    keep={k:v for k,v in old.items() if k.split('__')[0] not in targets};changed=[k for k,v in keep.items() if new[family].get(k)!=v];added=set(new[family])-set(old);removed=set(old)-set(new[family]);unexpected=[k for k in added|removed if k.split('__')[0] not in targets];failures.extend(changed+unexpected);counts[family]=dict(preserved=len(keep)-len(changed),changed=changed,added=sorted(added),removed=sorted(removed))
plan=json.loads((root/'art/data/city_horizon/source_plan.json').read_text())['buildings'];old=baseline['profiles'];assert len(plan)==len(old)==124
assert all(a['rect']==b['rect'] and (a==b or a['id'] in targets) for a,b in zip(plan,old))
record=dict(evidence_class='INERT',scope='Actual accessor/index/local and composed-root transforms/material-placeholder preservation outside three changed owners. Not rendered or loaded qualification.',parts=counts,preserved_other_profiles=121,parcels=124,assets=assets,failures=failures)
(out/'preservation_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n');print('PRESERVATION',sum(v['preserved'] for v in counts.values()),'parts;',sum(a['unchanged'] for a in assets.values()),'byte-exact assets;',len(failures),'failures');assert not failures
