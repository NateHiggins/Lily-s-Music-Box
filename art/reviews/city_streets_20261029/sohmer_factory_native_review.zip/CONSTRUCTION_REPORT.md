REPORT - K-V2-CITY-REVAMP / SOHMER NATIVE - 2026-11-02
Evidence class: INERT. Native checkpoint; not a merge candidate.
Branch / HEAD / origin/main / merge-base: codex/v2-city-20261029 / 4fae3c389e01ad798cda746e8f69b6a04dc4e51b plus named staged native work / same / same.
Worktree clean at end: no; owned changes listed below; same live queued family68396/session90489.
Protected17/17: working bytes unchanged against currentmain. Selector:v2; explicitv1rollback retained.
Ledger before -> after: FIRSTSLICE7/GOLDEN8/STRUCTURAL110/RUNTIME42/CUTOVER134/RETIREMENT136 unchanged;requirements_changed: [].
Gates: actual12static gates in static_01/board.json. ReaderNEW0,spatial/systemic/period/rulings and materialrecipe/importtexture checks pass. Expected current regressions:newlower.import missing/untracked newmodel and stalephysical review/qualification.107tools rows NOTRUN on this board. Focused12 horizon/manifest testsPASS0,source_tests_01.log. Ownhorizonfixture sourcepreflightPASS0. NoGodot started yet.
Numbers: one original20x22m parcel; six floors20.4m/tower24.96m;167616/96704exporttriangles,11near/lower partitions;12432wholeproducerpane probes/142targetpanesperbody;native04exit0/50.562s;native review02exit0/101.552s,22exactnative/exportparts/686pane/frontagecontrols/4actualinspectedimages. Sourcecountsarenot rendering measurements. All124reservations/123otherprofiles/35otherGLBsexact;threeP2partitionsrebuildfornewlyexposedpartywall.36individual/88generic roster remains unfinished.
Source-cost delta: baselineP1 6924tri -> near167616/lower96704; entire shard33880tri/3.45MB ->193836tri/20.75MB plus10.48MBlower. P1paintedwood78128/45936 andbrick63292/34876 dominate. Rendering costs still unmeasured; do not scale this density blindly across remaining88bodies. If actual viewport cost fails, reduce complete stock tessellation while preserving identity/openings, not wholebody deletion.
Changes outsideexpectedboundary: P2threepartitions in sameblock are dependentpartywall consumers,not newprofile. Newstandaloneonebody scene uses existing reusablebench with explicit1-or2IDs and3samplespertarget;defaults/two-body scene retained. NoOrison/interior/shop/traffic/weather/clockwriter/narrative/save owner edits.
Open findings: no loadedmip/LOD/cost/playercollision/access proof yet; GPUlane held by ownerLoRA/earlierFIFOjobs; runtimeclockhandspending architect reuse existingarcade nativehands/campaigntime; globalphysicalsourceproof stale; productionlighting/artistic/fullcity/450m/saves notaccepted. Native01windingfailure and firstreview sash/headcorrection plus text-encoding failure/correction preserved.
Decisionneededfromowner: none. Continue existing family queue; preserve all originals. Sol owns composedintake/clock/access/light/dependency renewal and eventual verified integration; no mainmerge before gates.
Changed namedpaths:
- .gitattributes
- art/blender/city_horizon_construction.json
- art/blender/city_horizon_far.blend
- art/blender/city_horizon_lod1.blend
- art/blender/city_horizon_near.blend
- art/blender/scripts/build_city_horizon.py
- art/blender/scripts/city_industrial_architecture.py
- art/data/city_horizon/source_plan.json
- design/V2_CITY_CONTEXT_REPORT_2026-10-19.md
- game/assets/props/city_horizon_near_3_0.glb
- game/assets/props/city_horizon_near_3_0_lod1.glb
- game/data/orison_v2/exterior/city_horizon.json
- game/tests/V2CitySohmerBody.tscn
- game/tests/fixtures/orison_city_horizon.json
- game/tests/v2_city_individual_body_review.gd

BLOCKED runtimequalification awaits existing FIFOqueue; native construction/review complete,fullcity incomplete.
