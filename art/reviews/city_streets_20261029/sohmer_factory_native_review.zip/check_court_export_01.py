from pathlib import Path
import bpy,json,hashlib,math
from mathutils import Vector
from mathutils.bvhtree import BVHTree
r=Path('C:/ov/city');o=Path(__file__).parent;target='HORIZON_NEAR_3_0_P1'
fixture=json.loads((r/'art/blender/city_horizon_construction.json').read_bytes())
row=next(x for x in fixture['buildings'] if x['id']==target);datum=row['grade_datum_m'];drop=datum-row['grade_low_m'];steps=math.ceil(drop/.15)
records=[];bindings={}
for family in ['base','body_lod']:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    asset=next(a for a in fixture['assets'].values() if a['role']==family and target in a['buildings'])
    p=r/asset['asset'];bindings[asset['asset']]=hashlib.sha256(p.read_bytes()).hexdigest();bpy.ops.import_scene.gltf(filepath=str(p));bpy.context.view_layer.update()
    vv=[];ff=[];owners=[]
    for obj in bpy.context.scene.objects:
        if obj.type!='MESH' or not obj.name.startswith(target+'__'):continue
        start=len(vv);vv.extend(obj.matrix_world@v.co for v in obj.data.vertices)
        ff.extend(tuple(start+i for i in poly.vertices) for poly in obj.data.polygons);owners.extend([obj.name]*len(obj.data.polygons))
    tree=BVHTree.FromPolygons(vv,ff)
    stations=[('apron',151.6,-127+i,datum) for i in range(21)]
    stations += [('court',x,z,datum) for x in [161.2,164,167.8] for z in [-117.0,-114,-108.0]]
    stations += [('descent',168.5+(i-.5)*.25,-112,datum-drop*i/steps) for i in range(1,steps)]
    for kind,x,z,expected in stations:
        p=Vector((x,-z,expected));hit,n,index,d=tree.ray_cast(p+Vector((0,0,.05)),Vector((0,0,-1)),.10)
        assert hit is not None and owners[index].split('.')[0].endswith('__concrete') and abs(hit.z-expected)<1e-4 and n.z>.999,(family,kind,x,z,hit,expected)
        hit,n,index,d=tree.ray_cast(p+Vector((0,0,.03)),Vector((0,0,1)),1.524)
        assert hit is None,(family,'headroom',kind,x,z,hit)
        records.append(dict(family=family,kind=kind,point=[x,expected,z]))
    # Wrong-height floor controls must reject: the roof is outside this range.
    p=Vector((164,112,datum+1.0));hit,*_=tree.ray_cast(p,Vector((0,0,-1)),.1);assert hit is None
for p,digest in bindings.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==digest
(o/'court_export_01.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Native exported first-hit support/upnormal and1.524m vertical rays,not fullcapsule sweeps,Godotcollision or actualcontroller access. Terrain beyond descent is not tested here.','controls':records,'wrong_height_rejections':2,'riser_m':drop/steps,'source_sha256':bindings},indent=2)+'\n',encoding='utf-8')
print('COURT EXPORT',len(records),'support/headroom stations,2 rejectingwrongheight controls;notruntimeproof')
