from pathlib import Path
import json,struct,ast,hashlib
r=Path('C:/ov/city');o=Path(__file__).parent
baseline=json.loads((o/'baseline_01.json').read_bytes())
oldplan=json.loads((o/'baseline/art/data/city_horizon/source_plan.json').read_bytes())
plan=json.loads((r/'art/data/city_horizon/source_plan.json').read_bytes());target='HORIZON_NEAR_3_0_P1'
assert [x['rect'] for x in oldplan['buildings']]==[x['rect'] for x in plan['buildings']]
assert [x for x in oldplan['buildings'] if x['id']!=target]==[x for x in plan['buildings'] if x['id']!=target]
oldast=ast.parse((o/'baseline/art/blender/scripts/city_industrial_architecture.py').read_text(encoding='utf-8'))
newclasses={x.name:ast.dump(x) for x in ast.parse((r/'art/blender/scripts/city_industrial_architecture.py').read_text(encoding='utf-8')).body if isinstance(x,ast.ClassDef)}
for x in oldast.body:
    if isinstance(x,ast.ClassDef):assert newclasses[x.name]==ast.dump(x),x.name

def glb(path):
    raw=path.read_bytes();n=struct.unpack_from('<I',raw,12)[0];j=json.loads(raw[20:20+n]);b=raw[28+n:]
    width={5120:1,5121:1,5122:2,5123:2,5125:4,5126:4};size={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
    def arr(i):
        a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];stride=width[a['componentType']]*size[a['type']]
        start=v.get('byteOffset',0)+a.get('byteOffset',0);step=v.get('byteStride',stride)
        return (a['componentType'],a['type'],a['count'],a.get('normalized',False),b''.join(b[start+k*step:start+k*step+stride] for k in range(a['count'])))
    result={}
    for node in j.get('nodes',[]):
        if 'mesh' not in node:continue
        m=j['meshes'][node['mesh']];parts=[]
        for p in m['primitives']:
            parts.append(({k:arr(i) for k,i in p['attributes'].items()},arr(p['indices']) if 'indices' in p else None,p.get('mode',4),p.get('material')))
        result[node['name']]=(parts,{k:v for k,v in node.items() if k not in ['mesh','name']})
    return result

changed=[];serialization=[];same=[];partdiff=[]
for rec in baseline['files']:
    p=rec['path']
    if not p.endswith('.glb'):continue
    old=o/'baseline'/p;new=r/p
    if old.read_bytes()==new.read_bytes():same.append(p);continue
    a=glb(old);b=glb(new);diff=[k for k in a.keys()|b.keys() if a.get(k)!=b.get(k)]
    if not diff:serialization.append(p)
    else:changed.append(p);partdiff.extend(sorted(diff))
j=json.loads((r/'art/blender/city_horizon_construction.json').read_bytes())
report={'evidence_class':'INERT','scope':'Native source/semantic export preservation only,not runtime or visual acceptance',
    'reservations_exact':124,'other_profiles_exact':123,'old_industrial_classes_AST_exact':sum(isinstance(x,ast.ClassDef) for x in oldast.body),
    'unchanged_GLbs':len(same),'serialization_only':serialization,'changed_assets':changed,'changed_parts':partdiff,
    'individual':sum(bool(x.get('architecture')) for x in plan['buildings']),'generic':sum(not x.get('architecture') for x in plan['buildings']),
    'target_assets':[{k:a[k] for k in ['asset','role','parts']} for a in j['assets'].values() if target in a['buildings']],
    'native_checks':j['native_checks']}
(o/'preservation_01.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ['target_assets','native_checks']},indent=2))
