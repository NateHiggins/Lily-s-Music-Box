extends "res://tests/v2_city_horizon_bench.gd"
## One placement, scripted waypoint headings, unchanged controller/input/physics.
const IDS=["HORIZON_NEAR_2_3_P0R0","HORIZON_NEAR_2_3_P0R1","HORIZON_NEAR_2_3_P0R2","HORIZON_NEAR_2_3_P1","HORIZON_NEAR_2_3_P2"]
var legs:Array[Dictionary]=[]
var endpoints:Array[Dictionary]=[]
var player:PlayerController
var directory:String

func _ready()->void:call_deferred("run_access")

func _seat_part(hit:Dictionary)->String:
    if hit.is_empty():return ""
    var draw=hit.collider.get_parent() as MeshInstance3D
    return str(draw.name) if draw!=null else ""

func run_access()->void:
    RealityState.persistence_enabled=false;RealityState.reset_campaign_for_tests();CampaignTime.set_frozen_for_tests(true)
    directory=OS.get_environment("SHOT_DIR")
    check(not directory.is_empty() and DisplayServer.get_name()!="headless","graphical output supplied")
    if directory.is_empty() or DisplayServer.get_name()=="headless":get_tree().quit(1);return
    DirAccess.make_dir_recursive_absolute(directory)
    var fixture:Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://tests/fixtures/orison_city_horizon.json"))
    var profiles:Dictionary={}
    for row:Dictionary in fixture.buildings:profiles[str(row.id)]=row
    var horizon=Horizon.new();add_child(horizon)
    var ground=preload("res://scripts/building/orison_v2_ground.gd").new();add_child(ground)
    var environment=WorldEnvironment.new();var settings=Environment.new()
    settings.background_mode=Environment.BG_COLOR;settings.background_color=Color(.32,.38,.44)
    settings.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;settings.ambient_light_color=Color(.62,.72,.8);settings.ambient_light_energy=.7
    environment.environment=settings;add_child(environment)
    var sun=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-40,-25,0);sun.light_energy=2.8;sun.shadow_enabled=true;add_child(sun)
    await get_tree().physics_frame;await get_tree().physics_frame
    var sources=_industrial_entry_sources(horizon,ground);sources[get_script().resource_path]=_profile_sha(get_script().resource_path)
    check(get_viewport().get_visible_rect().size==Vector2(3440,1440),"native fullscreen viewport")
    var row0:Dictionary=profiles[IDS[0]];var row2:Dictionary=profiles[IDS[2]]
    var lane_z=float(row0.rect[3])-.45;var lane_x=float(row2.rect[2])-.45
    player=PlayerController.new();player.position=Vector3(float(row0.rect[0])+.45,float(row0.grade_datum_m)+.03,lane_z)
    add_child(player);player.set_lamp_enabled(false);player.camera.make_current()
    for frame in 30:await get_tree().physics_frame
    check(player.is_on_floor() and absf(player.position.y)<.002,"single initial placement settles on real row-front paving")
    check(is_equal_approx(player._capsule.height,1.524) and is_equal_approx(player._capsule.radius,.33) and is_equal_approx(player.camera.position.y,1.41),"unmodified standing capsule and eye")
    for identity:String in IDS.slice(0,3):
        var row:Dictionary=profiles[identity];var opening=_entry(row,0,true)
        opening.x+=.15 # Stand onthe left leaf side,clear ofthe physical handle.
        await _walk(identity+"_lane",Vector3(opening.x,0,lane_z),true)
        await _walk(identity+"_landing",opening+Vector3(0,0,.22),false)
        await _endpoint(identity,"row_landing",opening.y,"limestone",true)
        await _walk(identity+"_return",Vector3(opening.x,0,lane_z),false)
        await _endpoint(identity,"row_return",0.,"concrete",false)
    await _walk("row_lane_corner",Vector3(lane_x,0,lane_z),true)
    await _endpoint(IDS[2],"lane_corner",0.,"concrete",true)
    var school:Dictionary=profiles[IDS[3]];var school_entry=_entry(school,7,false)
    for side:int in [-1,1]:
        var approach_z=school_entry.z+side*2.82
        await _walk("school_outer_"+str(side),Vector3(lane_x,0,approach_z),true)
        await _walk("school_to_flight_"+str(side),Vector3(school_entry.x+.65,0,approach_z),true)
        await _walk("school_landing_"+str(side),Vector3(school_entry.x+.65,school_entry.y,school_entry.z),false)
        await _endpoint(IDS[3],"school_landing_"+str(side),school_entry.y,"limestone",true)
        await _walk("school_descend_"+str(side),Vector3(school_entry.x+.65,0,approach_z),false)
        await _walk("school_return_"+str(side),Vector3(lane_x,0,approach_z),true)
        await _endpoint(IDS[3],"school_return_"+str(side),0.,"concrete",false)
    var factory:Dictionary=profiles[IDS[4]];var factory_entry=_entry(factory,3,false)
    await _walk("factory_outer_lane",Vector3(lane_x,0,factory_entry.z),true)
    await _walk("factory_landing",factory_entry+Vector3(.31,0,0),false)
    await _endpoint(IDS[4],"factory_landing",factory_entry.y,"limestone",true)
    await _walk("factory_return",Vector3(lane_x,0,factory_entry.z),false)
    await _endpoint(IDS[4],"factory_return",0.,"concrete",false)
    await _walk("factory_lane_end",Vector3(lane_x,0,float(factory.rect[3])-.45),true)
    await _endpoint(IDS[4],"lane_end",0.,"concrete",true)
    check(not player.noclip and not player._profile_disable_step_guard and not player._profile_disable_step_up,"gravity/collision/both step guards retained")
    var final_sources=_industrial_entry_sources(horizon,ground);final_sources[get_script().resource_path]=_profile_sha(get_script().resource_path)
    check(sources==final_sources,"all production inputs remain frozen")
    check(legs.size()==24,"all24 normal-input legs execute")
    var record={"schema_version":2,"evidence_kind":"runtime_contract","selector":"v2","production_runtime":true,"scope":"One initial placement and connected L-shaped block route with three row stoop roundtrips,both school flights and factory stoop. Scripted waypoint headings with normal forward input thereafter;no position rescue,noclip,synthetic floor,step overrides or changed standing capsule. Flat legs require every sample onfloor/height within2mm. Stair samples retain actual airborne/gap diagnostics;landing/return endpoints require floor and2mm height. Fixed diagnostic lighting. Not occupied campaign,traffic/save,performance or artistic acceptance.","execution":{"completed":true,"exit_code":0 if failures.is_empty() else 1,"timed_out":false},"source":{"test_path":"game/"+get_script().resource_path.trim_prefix("res://"),"test_sha256":FileAccess.get_sha256(get_script().resource_path),"runtime_inputs_sha256":JSON.stringify(sources).sha256_text()},"contracts":{"connected_production_controller_route":{"executed":legs.size()==24,"passed":failures.is_empty()}},"checks":checks,"failures":failures,"legs":legs,"endpoints":endpoints,"source_hashes":sources}
    var file=FileAccess.open(directory.path_join("civic_access.runtime.json"),FileAccess.WRITE)
    if file==null:push_error("Cannot write access receipt");get_tree().quit(1);return
    file.store_string(JSON.stringify(record,"\t")+"\n");file.close()
    print("CIVIC ACCESS: ",checks," checks; ",failures.size()," failures; ",legs.size()," connected legs")
    player.free();get_tree().quit(0 if failures.is_empty() else 1)

func _entry(row:Dictionary,side:int,residential:bool)->Vector3:
    var points:Array=row.architecture.outline_m;var p:Array=points[side];var q:Array=points[(side+1)%points.size()]
    var a=Vector3(float(p[0]),0,float(p[1]));var b=Vector3(float(q[0]),0,float(q[1]));var count=int(row.architecture.side_bays[side]);var bay=0 if residential else count/2
    var point=a+(b-a)*(float(bay)+.5)/float(count)
    point.y=float(row.grade_datum_m)+float(row.architecture.floor_heights_m[0])+.025
    return point

func _walk(label:String,target:Vector3,flat:bool)->void:
    var origin=player.global_position;var direction=target-origin;direction.y=0;direction=direction.normalized()
    if direction.length()>.5:player.look_at(player.global_position+direction,Vector3.UP)
    var samples:Array=[];var bad_flat=0;var unsupported=0;var airborne=0;var max_gap=0.
    Input.action_press("move_forward")
    for frame in 900:
        await get_tree().physics_frame
        var at=player.global_position
        var query=PhysicsRayQueryParameters3D.create(at+Vector3.UP*.05,at-Vector3.UP*.40,1);query.exclude=[player.get_rid()]
        var hit=player.get_world_3d().direct_space_state.intersect_ray(query)
        var gap=at.y-float(hit.position.y) if not hit.is_empty() else INF
        if not player.is_on_floor():airborne+=1
        if hit.is_empty():unsupported+=1
        else:max_gap=maxf(max_gap,gap)
        if flat and (not player.is_on_floor() or absf(at.y-target.y)>.002):bad_flat+=1
        samples.append({"position":[at.x,at.y,at.z],"on_floor":player.is_on_floor(),"noclip":player.noclip,"floor_gap_m":gap if is_finite(gap) else "no hit"})
        if (target-at).dot(direction)<.025:break
    Input.action_release("move_forward")
    for frame in 12:await get_tree().physics_frame
    var delta=player.global_position-target;delta.y=0
    check(delta.length()<.08,"normal-input target reached "+label)
    check(not samples.is_empty() and unsupported==0,"actual floor remains below every movement sample "+label)
    check(not flat or bad_flat==0,"flat leg retains actual floor and2mm height "+label)
    check(not player.noclip,"collision retained "+label)
    legs.append({"id":label,"flat":flat,"target":[target.x,target.y,target.z],"samples":samples,"bad_flat_samples":bad_flat,"unsupported_samples":unsupported,"airborne_samples":airborne,"maximum_floor_gap_m":max_gap})

func _endpoint(identity:String,label:String,height:float,key:String,capture:bool)->void:
    var at=player.global_position
    check(player.is_on_floor() and absf(at.y-height)<.002,"standing endpoint floor/height "+label)
    var query=PhysicsRayQueryParameters3D.create(at+Vector3.UP*.08,at-Vector3.UP*.12,1);query.exclude=[player.get_rid()]
    var hit=player.get_world_3d().direct_space_state.intersect_ray(query)
    check(_seat_part(hit)==identity+"__"+key,"actual first receiving endpoint stock "+label)
    var image=""
    if capture:
        for frame in 2:await RenderingServer.frame_post_draw
        image=identity+"_"+label+".png"
        check(get_viewport().get_texture().get_image().save_png(directory.path_join(image))==OK,"standing eye saved "+label)
    endpoints.append({"building":identity,"id":label,"position":[at.x,at.y,at.z],"expected_foot_m":height,"first_receiving_part":_seat_part(hit),"file":image})
