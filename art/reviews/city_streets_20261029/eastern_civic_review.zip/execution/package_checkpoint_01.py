from pathlib import Path
import json,hashlib,zipfile,subprocess
root=Path('C:/ov/city');out=Path(__file__).parent
def sha(raw):return hashlib.sha256(raw).hexdigest()
records={}
for name,folder,file in [('bench','bench_02','civic_loaded.runtime.json'),('access','access_02','civic_access.runtime.json')]:
    record=json.loads((out/folder/file).read_text())
    assert record['schema_version']==2 and record['evidence_kind']=='runtime_contract'
    assert record['execution']==dict(completed=True,exit_code=0,timed_out=False) and not record['failures']
    assert all(c['executed'] and c['passed'] for c in record['contracts'].values())
    records[name]=record
assert len(records['bench']['actual_visible_materials'])==189
assert len(records['bench']['observations'])==25 and len(records['access']['legs'])==24
assert (out/'loaded_inspection_01.json').is_file() and (out/'native_inspection_01.json').is_file()
stored={};runtime_bindings={};aliases={};seen={}
for p in sorted(out.rglob('*')):
    if p.is_file() and p.suffix in ['.py','.json','.log','.stderr','.png','.gd','.tscn','.txt'] and '__pycache__' not in p.parts:
        member='execution/'+p.relative_to(out).as_posix();raw=p.read_bytes()
        if p.suffix=='.png' and sha(raw) in seen:
            aliases[member]=dict(retained_member=seen[sha(raw)],sha256=sha(raw))
        else:
            stored[member]=raw
            if p.suffix=='.png':seen[sha(raw)]=member
for record in records.values():
    for resource,expected in record['source_hashes'].items():
        relative='game/'+resource.removeprefix('res://');p=root/relative;raw=p.read_bytes()
        normal=p.suffix in ['.gd','.json','.gdshader','.gdshaderinc','.import']
        check=raw.replace(b'\r\n',b'\n') if normal else raw
        assert sha(check)==expected,relative
        binding=dict(bytes=len(raw),raw_sha256=sha(raw),test_sha256=expected,lf_normalized=normal)
        assert relative not in runtime_bindings or runtime_bindings[relative]==binding
        runtime_bindings[relative]=binding
        if p.suffix not in ['.png','.glb']:stored['final/'+relative]=raw
for relative in ['art/blender/scripts/build_city_horizon.py','art/blender/scripts/city_residential_architecture.py','art/blender/scripts/city_industrial_architecture.py','art/data/city_horizon/source_plan.json','game/tmp/city_civic_01/Bench02.tscn','game/tmp/city_civic_01/Access02.tscn']:
    stored['final/'+relative]=(root/relative).read_bytes()
assets=['art/blender/city_horizon_near.blend','art/blender/city_horizon_far.blend','art/blender/city_horizon_lod1.blend','art/blender/city_horizon_construction.json','game/assets/props/city_horizon_near.glb','game/assets/props/city_horizon_far.glb','game/assets/props/city_horizon_lod1.glb','game/data/orison_v2/exterior/city_horizon.json','game/tests/fixtures/orison_city_horizon.json']
bindings={p:dict(bytes=(root/p).stat().st_size,sha256=sha((root/p).read_bytes())) for p in assets}
dest=root/'art/reviews/city_streets_20261029/eastern_civic_review.zip';assert not dest.exists()
prior={}
for name in ['eastern_industrial_native_review.zip','eastern_row_native_review.zip','eastern_street_native_review.zip','northern_houses_native_review.zip','houses_loaded_review.zip','eastern_houses_review.zip','eastern_courts_review.zip']:
    raw=(dest.parent/name).read_bytes();assert raw==subprocess.check_output(['git','show','05f5df70:art/reviews/city_streets_20261029/'+name],cwd=root)
    prior[name]=sha(raw)
scope='Five civic-block adaptations,complete replacement LODs. Native84roundtrips/56receivingcontrols/15inspectedviews. Schema2 contracts qualify only declared isolated loaded geometry/PBR/mips/LOD and connected controller route. All58final runtime frames inspected;original failures/captures retained with byte-exact aliases. Capsule support400mm isnot continuous-floor-on-stairs. Archive/index INERT. Not composed campaign,traffic/save,matched/wholecity performance or artistic acceptance.'
index=dict(evidence_class='INERT',scope=scope,sourcebase='05f5df70d6b0e3f8488653e1fb99e5b79ec16093',assets=bindings,runtime_sources=runtime_bindings,prior_unchanged_archives=prior,byte_exact_reused_image_aliases=aliases,members={k:dict(bytes=len(v),sha256=sha(v)) for k,v in stored.items()})
stored['archive_index.json']=json.dumps(index,indent=2).encode()
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
    for k,v in stored.items():z.writestr(k,v,compress_type=zipfile.ZIP_STORED if k.endswith('.png') else zipfile.ZIP_DEFLATED,compresslevel=1)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None and set(z.namelist())==set(stored)
    for k,v in stored.items():assert z.read(k)==v,k
assert dest.stat().st_size<100*1024*1024
record=dict(evidence_class='INERT',scope=scope,archive=dest.relative_to(root).as_posix(),bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),member_count=len(stored),byte_exact_reused_image_aliases=aliases,runtime_source_count=len(runtime_bindings),runtime_contracts={name:dict(member='execution/'+('bench_02/civic_loaded.runtime.json' if name=='bench' else 'access_02/civic_access.runtime.json'),checks=r['checks']) for name,r in records.items()},asset_bindings=bindings)
p=root/'art/reviews/city_streets_20261029/manifest.json';manifest=json.loads(p.read_text());assert 'eastern_civic_archive' not in manifest;manifest['eastern_civic_archive']=record;p.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'archive_record_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['asset_bindings','byte_exact_reused_image_aliases']}));print('aliases',len(aliases))
