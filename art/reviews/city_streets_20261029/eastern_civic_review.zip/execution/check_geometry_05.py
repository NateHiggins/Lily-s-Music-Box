from pathlib import Path
import sys,json,collections,hashlib,bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree
root=Path('C:/ov/city');out=Path(__file__).parent
sys.path.insert(0,str(root/'art/blender/scripts'))
from city_residential_architecture import CivicRows,CivicBlocks
plan=json.loads((root/'art/data/city_horizon/source_plan.json').read_text())
ids=json.loads((out/'source_prepare_01.json').read_text())['targets'];results=[];whole={}
for identity in ids:
    row=next(r.copy() for r in plan['buildings'] if r['id']==identity);row['grade_datum_m']=0.;levels=[]
    constructor=CivicRows if row['architecture']['style'] in CivicRows.STYLES else CivicBlocks
    for lower in [False,True]:
        buf=collections.defaultdict(lambda:([],[]))
        def emit(owner,key,vertices,faces):
            vv,ff=buf[key];start=len(vv);vv.extend(vertices);ff.extend(tuple(start+i for i in face) for face in faces)
        print('SOURCE SUBJECT',identity,'lower',lower,flush=True)
        result=constructor(row,emit,[r for r in plan['buildings'] if r['id']!=identity],lower).build()
        vertices=[];faces=[];owners=[];trees={}
        for key,(vv,ff) in buf.items():
            trees[key]=BVHTree.FromPolygons(vv,ff,all_triangles=False)
            start=len(vertices);vertices.extend(vv);faces.extend(tuple(start+i for i in face) for face in ff);owners.extend([key]*len(ff))
        bvh=BVHTree.FromPolygons(vertices,faces,all_triangles=False)
        for w in result['windows']:
            p=Vector(w['point']);n=Vector(w['normal']);expected=p-n*float(w['recess_m'])
            hit,normal,index,distance=bvh.ray_cast(p+n*.03,-n,.28)
            assert hit is not None and owners[index]=='mirror_aged' and (hit-expected).length<.0001,(identity,lower,'unfiltered pane',w,owners[index] if index is not None else None)
        roof=trees['galvanized_roof']
        for seat in result['bearings']:
            p=Vector(seat['point']);hit,n,index,distance=roof.ray_cast(p+Vector((0,0,.025)),Vector((0,0,-1)),.05)
            assert hit is not None and (hit-p).length<.0001,(identity,lower,'roof top',seat)
            support=p.copy();residential=constructor==CivicRows
            if residential:support.z=sum(row['architecture']['floor_heights_m'])
            direction=Vector((0,0,-1 if residential else 1));candidates=[]
            for key,tree in trees.items():
                hit,n,index,distance=tree.ray_cast(support-direction*.025,direction,.05)
                if hit is not None and n.dot(direction)<0:candidates.append((distance,key,hit))
            assert candidates,(identity,lower,'missing receiving stock',seat)
            distance,key,hit=min(candidates,key=lambda x:x[0])
            assert key==seat['wall_key'] and (hit-support).length<.0001,(identity,lower,'actual receiver',seat,key,list(hit))
            # Check the flat sheet underside independently at the receiving
            # plane; roof-top contact alone is not bearing continuity.
            if residential:
                hit,n,index,distance=roof.ray_cast(support-Vector((0,0,.025)),Vector((0,0,1)),.05)
                assert hit is not None and (hit-support).length<.0001,(identity,lower,'roof underside',seat)
            outside=Vector(seat['outside_probe']);hit,n,index,distance=roof.ray_cast(outside+Vector((0,0,.025)),Vector((0,0,-1)),.05)
            assert hit is None,(identity,lower,'outside',seat)
        levels.append(dict(lower=lower,triangles=sum(len(f)-2 for f in faces),closed_stocks=result['closed_stocks'],minimum_stock_volume_m3=result['min_closed_stock_volume_m3'],panes=len(result['windows']),roof_seats=len(result['bearings']),entries=result['entries'],parts=sorted(buf)))
        if not lower:whole[identity]=(vertices,faces,owners)
    assert levels[1]['triangles']<levels[0]['triangles'],(identity,'no complete body reduction',levels)
    assert levels[0]['panes']==levels[1]['panes'] and levels[0]['entries']==levels[1]['entries']
    results.append(dict(id=identity,style=row['architecture']['style'],levels=levels))
vertices=[];faces=[];owners=[]
for identity,(vv,ff,keys) in whole.items():
    start=len(vertices);vertices.extend(vv);faces.extend(tuple(start+i for i in face) for face in ff);owners.extend((identity,key) for key in keys)
bvh=BVHTree.FromPolygons(vertices,faces,all_triangles=False);probes=[]
row=next(r for r in plan['buildings'] if r['id']==ids[0]);a,b,c,d=row['rect']
wall_probe=Vector((a-.15,-d+row['architecture']['front_inset_m']+.5,.30))
hit,n,index,distance=bvh.ray_cast(wall_probe,Vector((1,0,0)),.70)
assert hit is not None and owners[index][0]==ids[0] and distance<.16,('vertical-wall positive control',owners[index] if index is not None else None)
# Sample the full connected L-shaped exterior lane using actual generated
# first receiving stock and capsule-height clearance rays. This is a native
# diagnostic; actual capsule movement remains a separate Godot requirement.
route=[(x,-d+.45) for x in [-169.55+i*.5 for i in range(39)]]
route +=[(-150.45,-z) for z in [113.0+i*.5 for i in range(74)]]
for x,y in route:
    p=Vector((x,y,0.));hit,n,index,distance=bvh.ray_cast(p+Vector((0,0,.10)),Vector((0,0,-1)),.20)
    assert hit is not None and owners[index][1]=='concrete' and abs(hit.z)<.0001,('lane support',list(p),owners[index] if index is not None else None)
    for dx,dy in [(0,0),(.33,0),(-.33,0),(0,.33),(0,-.33),(.23,.23),(-.23,.23),(.23,-.23),(-.23,-.23)]:
        at=p+Vector((dx,dy,.03));hit,n,index,distance=bvh.ray_cast(at,Vector((0,0,1)),1.524)
        assert hit is None,('lane overhead/side sample',list(at),owners[index] if index is not None else None)
    for height in [.08,.45,.90,1.45]:
        for axis in [Vector((1,0,0)),Vector((0,1,0))]:
            at=p+Vector((0,0,height))-axis*.34
            hit,n,index,distance=bvh.ray_cast(at,axis,.68)
            assert hit is None,('lane horizontal body-slice sample',list(at),owners[index] if index is not None else None)
    probes.append(list(p))
bindings={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in ['art/blender/scripts/city_residential_architecture.py','art/blender/scripts/city_industrial_architecture.py','art/data/city_horizon/source_plan.json']}
record=dict(evidence_class='INERT',scope='Unsaved native source stock,pane,roof/underside/receiving and sampled connected-lane diagnostics. Not final export,UV,rendered review,loaded physics,actual player access,performance or artistic acceptance.',results=results,connected_lane_sample_controls=probes,source_bindings=bindings)
path=out/'geometry_05.json';assert not path.exists();path.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print('NEXT BLOCK SOURCE GEOMETRY PASS',len(results),'bodies,',len(probes),'lane stations',flush=True)
