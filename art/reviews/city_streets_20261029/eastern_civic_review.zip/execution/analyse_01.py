from pathlib import Path
import json,math,statistics
from PIL import Image,ImageDraw,ImageChops
out=Path(__file__).parent
data=json.loads((out/'bench_02/civic_loaded.runtime.json').read_text())
access=json.loads((out/'access_02/civic_access.runtime.json').read_text())
assert not data['failures'] and not access['failures']
assert len(data['observations'])==25 and len(access['legs'])==24
def summary(rows):
    result={}
    for key in ['wall_ms','viewport_cpu_ms','viewport_gpu_ms']:
        values=sorted(float(x[key]) for x in rows)
        result[key]={k:values[min(len(values)-1,max(0,math.ceil(len(values)*v)-1))] for k,v in [('p95',.95),('p99',.99),('max',1.)]}
        result[key]['median']=statistics.median(values)
    return dict(frames=len(rows),metrics=result)
record=dict(evidence_class='INERT',scope='Exact isolated runtime analysis;startup excluded,transition spikes retained. Not matched gain,whole-city budget or artistic acceptance.',checks=data['checks'],access_checks=access['checks'],warmed=summary([x for r in data['observations'] for x in r['samples']]),transitions=summary([x for r in data['observations'] for x in r['warmup_samples']]),profiles=[dict(building=r['building'],id=r['id'],counters=r['counters']) for r in data['observations']],controller_legs=[{k:(len(v) if k=='samples' else v) for k,v in r.items()} for r in access['legs']])
(out/'loaded_analysis_01.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
for name,paths in [('whole',list((out/'bench_02').glob('*_profile_*.png'))),('access',list((out/'access_02').glob('*.png')))]:
    paths=sorted(paths);assert paths
    canvas=Image.new('RGB',(1600,math.ceil(len(paths)/2)*360),'#282c30');draw=ImageDraw.Draw(canvas)
    for i,path in enumerate(paths):
        with Image.open(path) as im:
            copy=im.convert('RGB');copy.thumbnail((800,335))
            x=i%2*800;y=i//2*360;canvas.paste(copy,(x,y));draw.text((x+4,y+337),path.stem,fill='white')
    canvas.save(out/(name+'_contact_01.png'))
sheet=Image.new('RGB',(2400,1300),(35,35,35));draw=ImageDraw.Draw(sheet);bounds=[]
for row,identity in enumerate(sorted(data['natural_transitions'])):
    for col,phase in enumerate(['before','after','narrow','return']):
        target=out/'bench_02'/(identity+'_natural_'+phase+'.png');background=target.with_name(target.stem+'_background.png')
        a=Image.open(target).convert('RGB');b=Image.open(background).convert('RGB')
        diff=ImageChops.difference(a,b).convert('L').point(lambda v:255 if v>5 else 0)
        box=diff.getbbox();assert box,(identity,phase)
        box=(max(0,box[0]-8),max(0,box[1]-8),min(a.width,box[2]+8),min(a.height,box[3]+8))
        bounds.append(dict(target=target.name,background=background.name,crop=box))
        for offset,img in enumerate([a,b]):
            crop=img.crop(box);crop.thumbnail((295,230));x=col*600+offset*300;y=row*260
            sheet.paste(crop,(x+(300-crop.width)//2,y));draw.text((x+3,y+233),identity.replace('HORIZON_','')+' '+phase+(' hidden' if offset else ''),fill='white')
sheet.save(out/'natural_contact_01.png')
(out/'natural_contact_crops_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Derived diagnostic crops;original frames unchanged.',records=bounds),indent=2),encoding='utf-8',newline='\n')
print(json.dumps({k:record[k] for k in ['warmed','transitions']}))
