from pathlib import Path
import ast,json,struct,hashlib,subprocess
root=Path('C:/ov/city');out=Path(__file__).parent
reader=out.parent/'bodega_frontage_reconciliation_01/check_preservation_01.py'
tree=ast.parse(reader.read_text(encoding='utf-8-sig'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(reader),'exec'))
base='05f5df70d6b0e3f8488653e1fb99e5b79ec16093'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
plan=json.loads((out/'baseline_source_plan_05.json').read_text(encoding='utf-8'))
prior=json.loads((out.parent/'eastern_courts_01/baseline_01.json').read_text(encoding='utf-8'))
parts={};assets={}
for family in ['city_horizon_near','city_horizon_far','city_horizon_lod1']:
    path=root/f'game/assets/props/{family}.glb';raw=path.read_bytes()
    sha=subprocess.check_output(['git','show',base+':'+path.relative_to(root).as_posix()],cwd=root)
    assert raw==sha,family
    parts[family]=projection(raw);assets[path.relative_to(root).as_posix()]=hashlib.sha256(raw).hexdigest()
others={}
for relative,expected in prior['other_assets'].items():
    actual=hashlib.sha256((root/relative).read_bytes()).hexdigest();assert actual==expected,relative;others[relative]=actual
record=dict(evidence_class='INERT',sourcebase=base,scope='Exact pre-generation accessor/transform/indices baseline;no duplicated mesh assets. Not native/render/runtime acceptance.',targets=json.loads((out/'source_prepare_01.json').read_text())['targets'],profiles=plan['buildings'],parts=parts,other_assets=others,horizon_assets=assets)
path=out/'baseline_01.json';assert not path.exists();path.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print('BASELINE',len(plan['buildings']),'profiles',sum(len(x) for x in parts.values()),'parts',len(others),'other assets')
