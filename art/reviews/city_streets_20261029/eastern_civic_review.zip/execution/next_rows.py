"""Next-block native authoring; not installed, exported or accepted.

LPC0450 21-29 stone Italianate,21-41 narrow plain brick,21-22 Neo-Grec.
AU placement/color/dimensions; scenic closed doors, no occupied interiors.
"""
import math
from mathutils import Vector
from city_residential_architecture import ResidentialHouses
from city_industrial_architecture import MillLofts


class CivicRows(ResidentialHouses):
    STYLES={'stone_2129','narrow_2141','neogrec_2122'}

    def __init__(self,row,emit,neighbours,lower=False):
        super().__init__(row,emit,neighbours,lower)
        self.eave=self.levels[-1]
        self.steps=1 if lower else 2
        if self.style=='narrow_2141':
            # The documented16ft frontage is a real proportion,not a tint on
            # another22ft box. Retain its parcel and leave two service gaps.
            x,y,X,Y=self.rect;middle=(x+X)/2
            self.rect=(middle-2.44,y,middle+2.44,Y)

    def add(self,key,vertices,faces):
        if self.basement and key==self.row['wall_key']:key='limestone'
        return MillLofts.add(self,key,vertices,faces)

    def star(self,O,U,N,center,height,radius):
        points=[]
        for i in range(10):
            angle=math.pi/2+i*math.pi/5;r=radius if i%2==0 else radius*.43
            points.append((center+math.cos(angle)*r,height+math.sin(angle)*r))
        self.profile('limestone',O,U,N,points,.18,.205)

    def panel(self,O,U,N,l,r,z0,z1,length,front=False,door=False,basement=False):
        if basement and door:
            self.wall_stock(O,U,N,(l,-.4,z0),(r,0,z1),length);return
        width=min(1.18 if door else .88 if self.style=='narrow_2141' else 1.06,r-l-.58)
        assert width>.65,(self.name,width)
        center=(l+r)/2;left=center-width/2;right=center+width/2
        low=z0+(.025 if door else .17 if basement else .58)
        high=z0+2.65 if door else z1-(.20 if basement else .47)
        arched=front and not basement and self.style=='stone_2129'
        rise=(.43 if door else .16) if arched else 0.;spring=high-rise
        assert z0<low<spring<=high<z1
        for a,b in [((l,-.4,z0),(left,0,z1)),((right,-.4,z0),(r,0,z1)),
                    ((left,-.4,z0),(right,0,low)),((left,-.4,high),(right,0,z1))]:
            self.wall_stock(O,U,N,a,b,length)
        if arched:
            head=[(center-width/2*math.cos(i*math.pi/self.arch_steps),spring+rise*math.sin(i*math.pi/self.arch_steps)) for i in range(self.arch_steps+1)]
            for a,b in zip(head,head[1:]):
                points=[a,b,(b[0],high),(a[0],high)]
                points=[p for i,p in enumerate(points) if p!=points[i-1]]
                if len(points)>2:self.profile(self.row['wall_key'],O,U,N,points,-.4,0)
        else:head=[(left,high),(right,high)]
        # Recessed physical pane/leaf and continuous jambs. The arched entry
        # has a separate glazed fanlight and solid double leaves below it.
        leaf=[(left+.02,low+.02),(right-.02,low+.02)]+[(x,h-.02) for x,h in reversed(head)]
        if door and arched:leaf=[(left+.02,low+.02),(right-.02,low+.02),(right-.02,spring),(left+.02,spring)]
        self.profile('door_paint' if door else 'mirror_aged',O,U,N,leaf,-.205,-.17)
        for a,b in [(left,left+.065),(right-.065,right)]:
            self.stock('door_paint',O,U,N,(a,-.205,low),(b,-.07,spring),.004)
        for h in [low,spring]:
            self.stock('door_paint',O,U,N,(left,-.205,h),(right,-.07,h+.055),.004)
        if arched:
            self.arch('door_paint',O,U,N,center,spring,width/2,rise,.065,-.205,-.07)
            self.arch('limestone',O,U,N,center,spring,width/2+.055,rise+.035,.11,-.10,.10)
            if door:
                inner=[(center-(width/2-.07)*math.cos(i*math.pi/self.arch_steps),spring+.055+(rise-.10)*math.sin(i*math.pi/self.arch_steps)) for i in range(self.arch_steps+1)]
                self.profile('mirror_aged',O,U,N,inner,-.208,-.173)
        self.stock('limestone',O,U,N,(left-.08,-.22,low-.08),(right+.08,.09,low),.008)
        if not arched:self.stock('limestone',O,U,N,(left-.07,-.22,high),(right+.07,.08,high+.12),.008)
        if door:
            self.stock('door_paint',O,U,N,(center-.025,-.16,low+.02),(center+.025,-.07,spring-.03),.003)
            for a,b in [(left+.10,center-.07),(center+.07,right-.10)]:
                for h,H in [(low+.13,low+.80),(low+1.02,spring-.13)]:
                    assert H>h
                    self.stock('door_paint',O,U,N,(a,-.166,h),(b,-.125,H),.01)
            self.stock('bronze_sheet',O,U,N,(center+.10,-.08,low+.95),(center+.13,-.025,low+1.20),.003)
            if self.style=='stone_2129':
                self.profile('limestone',O,U,N,[(left-.19,high+.13),(right+.19,high+.13),(center,high+.53)],-.05,.20)
                for at in [left-.12,right+.12]:
                    self.stock('limestone',O,U,N,(at-.075,-.07,high-.04),(at+.075,.17,high+.16),.008)
            self.stoop(O,U,N,left,right,low)
            self.entries.append(dict(building=self.name,point=list(O+U*center+Vector((0,0,low+1.2))),kind='closed_scenic_leaf'))
        else:
            middle=low+(spring-low)*.48
            self.stock('door_paint',O,U,N,(left+.05,-.195,middle-.025),(right-.05,-.075,middle+.03),.003)
            if not basement:
                for at in [left+width/3,left+2*width/3]:
                    self.stock('door_paint',O,U,N,(at-.012,-.19,middle+.03),(at+.012,-.08,spring-.03),.002)
            if arched:
                floor=self.levels.index(z0)
                # Stone front has three different head/sill orders rather
                # than one repeating extrusion. First-floor stars belong to
                # the original ribbed head consoles described by LPC.
                for at in [left-.04,right+.04]:
                    self.stock('limestone',O,U,N,(at-.075,-.04,low-.20),(at+.075,.07,low-.075),.008)
                if floor==1:
                    self.arch('limestone',O,U,N,center,spring,width/2+.16,rise+.12,.10,-.03,.19)
                    for at in [left-.13,right+.13]:
                        self.stock('limestone',O,U,N,(at-.075,-.03,high-.04),(at+.075,.18,high+.12),.007)
                        self.star(O,U,N,at,high+.035,.055)
                elif floor==2:
                    self.arch('limestone',O,U,N,center,spring,width/2+.13,rise+.085,.075,-.025,.15)
            self.windows.append(dict(building=self.name,point=list(O+U*(left+width*.25)+Vector((0,0,low+(spring-low)*.27))),normal=list(N),recess_m=.17))

    def stoop(self,O,U,N,left,right,top):
        count=6;run=.25;landing=.25
        self.stock('limestone',O,U,N,(left-.14,-.06,-.12),(right+.14,landing,top),.008)
        for i in range(count):
            self.stock('limestone',O,U,N,(left-.14,landing+i*run,-.12),(right+.14,landing+(i+1)*run,top*(count-i)/count),.008)
        for at in [left-.10,right+.10]:
            for depth,height in [(landing/2,top),(landing+(count-.5)*run,top/count)]:
                self.stock('cast_iron',O,U,N,(at-.025,depth-.025,height),(at+.025,depth+.025,height+.90),.003)
            first=landing/2;last=landing+(count-.5)*run
            rise=lambda t:top+.90+(top/count-top)*(t-first)/(last-first)
            self.profile('cast_iron',O+U*at,N,-U,[(first,rise(first)-.023),(last,rise(last)-.023),(last,rise(last)+.023),(first,rise(first)+.023)],-.023,.023)
            if self.style=='neogrec_2122':
                # Curvilinear forged rail infill is retained in both bodies.
                for i in range(3):
                    center=first+(last-first)*(i+.5)/3;height=rise(center)-.27
                    self.arch('cast_iron',O+U*at,N,-U,center,height,.14,.18,.018,-.014,.014)

    def flat_roof(self):
        x,y,X,Y=self.rect;z=self.eave;outline=[(X,y),(x,y),(x,Y),(X,Y)]
        self.box('galvanized_roof',(x,y,z),(X,Y,z+.14))
        # A deep timber cornice has supported crown/fascia/base stocks; the
        # Neo-Grec frontage has exactly four principal shaped brackets.
        O,U,N,L=self.sides(self.rect)[0]
        for lo,hi,projection in [(z-.33,z-.24,.16),(z-.24,z+.035,.24),(z+.035,z+.14,.34)]:
            self.stock('door_paint',O,U,N,(0,-.12,lo),(L,projection,hi),.009)
        # Brackets sit onthe opening piers,not over window heads.
        # Neo-Grec's four aredocumented; the narrow two-bay front uses three.
        count=3 if self.style=='narrow_2141' else 4
        for i in range(count):
            at=.16+(L-.32)*i/(count-1)
            points=[(at-.07,z-.33),(at+.07,z-.33),(at+.07,z-.48),(at+.035,z-.57),(at-.035,z-.57),(at-.07,z-.48)]
            self.profile('door_paint',O,U,N,points,-.025,.22)
        for i in range(4):
            a=Vector((*outline[i],z+.14));b=Vector((*outline[(i+1)%4],z+.14));t=(b-a).normalized();n=Vector((-t.y,t.x,0))
            self.bearings.append(dict(building=self.name,wall_key=self.row['wall_key'],point=list((a+b)/2-n*.18),outside_probe=list((a+b)/2+n*.10)))

    def build(self):
        x,y,X,Y=self.rect;a,b,c,d=self.row['rect']
        #2.8m front reservation minus1.75m stoop leaves a continuous1.05m
        # lane at the adjoining school edge,clear for the0.66m player body.
        assert self.study['front_inset_m']>=2.8
        self.box('concrete',(a,-d,-.12),(c,y,0))
        self.box('concrete',(x,y,-.28),(X,Y,0))
        for z in self.levels[1:]:self.box('timber',(x+.4,y+.4,z-.16),(X-.4,Y-.4,z))
        for side,(O,U,N,L) in enumerate(self.sides(self.rect)):
            count=self.study['side_bays'][side];pitch=L/count
            for floor,(z,Z) in enumerate(zip(self.levels,self.levels[1:])):
                self.basement=floor==0
                for bay in range(count):
                    l=bay*pitch;r=(bay+1)*pitch;entry=side==0 and bay==0
                    if self.covered(O,U,N,l,r,z,[]) or entry and floor==0:self.wall_stock(O,U,N,(l,-.4,z),(r,0,Z),L)
                    else:self.panel(O,U,N,l,r,z,Z,L,front=side==0,door=entry and floor==1,basement=floor==0)
        self.basement=False;self.flat_roof()
        assert len(self.entries)==1,(self.name,self.entries)
        return dict(windows=self.windows,bearings=self.bearings,entries=self.entries,mitre_seams=self.seams,closed_stocks=self.parts,min_closed_stock_volume_m3=self.min_volume,style=self.style)
