"""Native source authoring for Bryant/Garside AU exterior adaptations.
Not installed/exported/accepted until the coordinated next batch executes.
"""
import math
from mathutils import Vector
from city_industrial_architecture import EasternRows
from city_horizon_geometry import extrusion,offset_outline,cornice_ring


class CivicBlocks(EasternRows):
    STYLES={'bryant_2801','garside_3502'}

    def __init__(self,row,emit,neighbours,lower=False):
        super().__init__(row,emit,neighbours,lower)
        self.steps=1 if lower else 2
        self.basement=False;self.windowing=False;self.crowning=False
        self.wall_depth=.3048 if self.style=='garside_3502' else .40

    def wall_stock(self,O,U,N,lo,hi,length):
        # Keep this cohort's actual section: Garside's documented12inch
        # brick/tile curtain andthe authored400mm school masonry. The older
        # garden-apartment helper's280mm section isnot silently substituted.
        l,back,z=lo;r,front,Z=hi
        assert abs(back+self.wall_depth)<1e-7 and abs(front)<1e-7
        left=self.tapers[0] if abs(l)<1e-7 else 0.
        right=self.tapers[1] if abs(r-length)<1e-7 else 0.
        assert r-l>0 and r-right>l+left,(self.name,l,r,left,right,length)
        plan=[(l,front),(r,front),(r-right,back),(l+left,back)]
        vertices=[tuple(O+U*a+N*b+Vector((0,0,h))) for h in [z,Z] for a,b in plan]
        faces=[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
        if U.cross(N).z>0:faces=[tuple(reversed(f)) for f in faces]
        self.add(self.row['wall_key'],vertices,faces)

    def add(self,key,vertices,faces):
        if self.style=='bryant_2801':
            if self.basement and key==self.row['wall_key']:key='limestone'
            if self.windowing and key=='cast_iron':key='door_paint'
        if self.crowning and key=='door_paint':key='limestone' if self.style=='bryant_2801' else 'concrete'
        return super().add(key,vertices,faces)

    def opening(self,O,U,N,l,r,z,Z,length,door=False,basement=False):
        school=self.style=='bryant_2801';center=(l+r)/2
        # Reserve the full two corner sections plus20mm on each side before
        # selecting a sash width. A fixed700mm allowance left5mm too little
        # material at the shortened school's17.2m/five-bay side.
        width=min(1.85 if door else 2.65 if school else 3.85,r-l-2*self.wall_depth-.04)
        assert width>.65,(self.name,l,r,width)
        left=center-width/2;right=center+width/2
        low=z+(.025 if door else .17 if basement else .64)
        high=z+2.82 if door else Z-(.18 if basement and school else .38 if basement else .54)
        assert z<low<high<Z,(self.name,z,Z,low,high)
        for a,b in [((l,-self.wall_depth,z),(left,0,Z)),((right,-self.wall_depth,z),(r,0,Z)),
                    ((left,-self.wall_depth,z),(right,0,low)),((left,-self.wall_depth,high),(right,0,Z))]:
            self.wall_stock(O,U,N,a,b,length)
        self.profile('door_paint' if door else 'mirror_aged',O,U,N,
                     [(left+.02,low+.02),(right-.02,low+.02),(right-.02,high-.02),(left+.02,high-.02)],-.205,-.17)
        self.windowing=True;self.rectangular_frame(O,U,N,left,right,low,high)
        trim='limestone' if school else 'concrete'
        self.stock(trim,O,U,N,(left-.075,-.22,low-.075),(right+.075,.075,low),.008)
        self.stock(trim,O,U,N,(left-.075,-.22,high),(right+.075,.075,high+.12),.008)
        if door:
            self.stock('door_paint',O,U,N,(center-.035,-.20,low+.025),(center+.035,-.07,high-.025),.004)
            for a,b in [(left+.10,center-.08),(center+.08,right-.10)]:
                self.stock('door_paint',O,U,N,(a,-.165,low+.15),(b,-.13,low+.82),.008)
                self.stock('door_paint',O,U,N,(a,-.165,low+1.04),(b,-.13,high-.13),.008)
            for at in [center-.13,center+.13]:
                self.stock('bronze_sheet',O,U,N,(at-.015,-.075,low+1.0),(at+.015,-.025,low+1.24),.003)
            self.windowing=False
            if school:
                # Compound limestone arch and abstract owl/tablet relief are
                # geometry; no lettering or new school/entry programme.
                self.arch('limestone',O,U,N,center,high-.12,width/2+.14,.31,.13,-.08,.20)
                self.arch('limestone',O,U,N,center,high-.12,width/2+.31,.43,.11,-.07,.25)
                self.profile('limestone',O,U,N,[(center-.11,high+.23),(center+.11,high+.23),(center+.15,high+.51),(center-.15,high+.51)],-.05,.30)
                for at in [center-.075,center+.075]:
                    self.profile('limestone',O,U,N,[(at-.05,high+.34),(at+.05,high+.34),(at,high+.45)],.30,.34)
                self.school_stair(O,U,N,center,low)
            else:self.entry_stoop(O,U,N,center,low)
            self.entries.append(dict(building=self.name,point=list(O+U*center+Vector((0,0,low+1.2))),kind='closed_scenic_leaf'))
        else:
            columns=6;rows=1 if basement else 4
            for i in range(1,columns):
                at=left+width*i/columns
                thick=.038 if school and i in [2,4] else .016
                self.stock('cast_iron',O,U,N,(at-thick,-.195,low+.055),(at+thick,-.085,high-.035),.003)
            for i in range(1,rows):
                at=low+(high-low)*i/rows
                self.stock('cast_iron',O,U,N,(left+.055,-.195,at-.016),(right-.055,-.085,at+.016),.003)
            self.windowing=False
            self.windows.append(dict(building=self.name,point=list(O+U*(left+width*.27)+Vector((0,0,low+(high-low)*.29))),normal=list(N),recess_m=.17))

    def school_stair(self,O,U,N,center,top):
        # Two flights ascend parallel to the facade to a shared entrance
        # landing. The outer lane remains beyond their1.1m normal projection.
        self.stock('limestone',O,U,N,(center-.90,-.10,-.12),(center+.90,1.10,top),.009)
        count=7;run=.21
        for sign in [-1,1]:
            for i in range(count):
                a=center+sign*(.90+i*run);b=center+sign*(.90+(i+1)*run)
                self.stock('limestone',O,U,N,(min(a,b),.15,-.12),(max(a,b),1.10,top*(count-i)/count),.008)
            first=center+sign*(.90+(count-.5)*run);last=center+sign*.86
            for at,height in [(first,top/count),(last,top)]:
                self.stock('cast_iron',O,U,N,(at-.022,1.04-.022,height),(at+.022,1.04+.022,height+.90),.003)
            lo=min(first,last);hi=max(first,last)
            h=lambda x:top/count+.90+(top-top/count)*(x-first)/(last-first)
            self.profile('cast_iron',O,U,N,[(lo,h(lo)-.022),(hi,h(hi)-.022),(hi,h(hi)+.022),(lo,h(lo)+.022)],1.018,1.062)

    def school_detail(self,outline,height):
        z=self.levels[-2]
        v,f=cornice_ring(offset_outline(outline,-.04),.20,z-.13,z+.025)
        self.add('limestone',v,f)
        for index,(p,q) in enumerate(zip(outline,outline[1:]+outline[:1])):
            O=Vector((*p,0));U=Vector((q[0]-p[0],q[1]-p[1],0));length=U.length;U.normalize();N=Vector((-U.y,U.x,0))
            if length<.7:continue
            if N.x>.65:
                # End-pavilion quoins,not a flat color stripe.
                if index in [3,11]:
                    for at in [.13,length-.13]:
                        base=self.levels[1];span=height-.38-base
                        courses=max(1,round(span/.34));pitch=span/courses
                        assert pitch>.12
                        # Integer course phase avoids emitting a zero-height
                        # floating-point remainder after43 nominal courses.
                        for course in range(courses):
                            h=base+course*pitch;H=h+pitch-.08
                            self.stock('limestone',O,U,N,(at-.13,-.04,h),(at+.13,.065,H),.008)
                count=max(1,round(length/.48))
                for i in range(count):
                    at=(i+.5)*length/count
                    self.stock('limestone',O,U,N,(at-.065,-.04,height-.24),(at+.065,.18,height-.06),.008)
                if index in [3,11]:
                    center=length/2
                    # Solid gable spandrel and seated stone rakes retain the
                    # pre-alteration school's roof silhouette inboth LODs.
                    self.profile(self.row['wall_key'],O,U,N,[(.22,height+.52),(length-.22,height+.52),(center,height+1.55)],-.20,.0)
                    for a,b in [((.17,height+.50),(center,height+1.62)),((center,height+1.62),(length-.17,height+.50))]:
                        self.profile('limestone',O,U,N,[a,b,(b[0],b[1]+.10),(a[0],a[1]+.10)],-.10,.16)

    def factory_frame(self,outline):
        # The primary assessment explicitly describes mushroom columns.
        # These passive structural stocks carry floors/roof; no occupied
        # factory interior or new access authority isintroduced. Both bodies
        # retain every shaft andcapital,with16/8-sided section sampling.
        xs=[p[0] for p in outline];ys=[p[1] for p in outline]
        steps=8 if self.lower else 16
        for floor,(z,Z) in enumerate(zip(self.levels,self.levels[1:])):
            top=Z if floor==len(self.levels)-2 else Z-.18
            shoulder=top-.17
            assert z<shoulder<top
            for i in range(4):
                x=min(xs)+.8+(max(xs)-min(xs)-1.6)*i/3
                for j in range(4):
                    y=min(ys)+.8+(max(ys)-min(ys)-1.6)*j/3
                    vertices=[(x+radius*math.cos(k*math.tau/steps),y+radius*math.sin(k*math.tau/steps),h) for radius,h in [(.18,z),(.18,shoulder),(.60,top)] for k in range(steps)]
                    faces=[tuple(reversed(range(steps))),tuple(range(2*steps,3*steps))]
                    for ring in range(2):
                        for k in range(steps):
                            a=ring*steps+k;b=ring*steps+(k+1)%steps
                            faces.append((a,b,b+steps,a+steps))
                    self.add('concrete',vertices,faces)

    def build(self):
        outline=self.outline(True);inside=offset_outline(outline,-self.wall_depth);height=self.levels[-1]
        for box in self.study['court_paving_m']:
            a,b,c,d=box;self.box('concrete',(a,-d,-.12),(c,-b,0))
        for floor,(z,Z) in enumerate(zip(self.levels,self.levels[1:])):
            v,f=extrusion(outline if floor==0 else offset_outline(outline,-.16),-.28 if floor==0 else z-.18,0 if floor==0 else z)
            self.add('concrete',v,f)
            self.basement=floor==0
            for side,(p,q) in enumerate(zip(outline,outline[1:]+outline[:1])):
                O=Vector((*p,0));U=Vector((q[0]-p[0],q[1]-p[1],0));length=U.length;U.normalize();N=Vector((-U.y,U.x,0))
                self.tapers=((Vector((*inside[side],0))-O).dot(U),length-(Vector((*inside[(side+1)%len(outline)],0))-O).dot(U))
                count=self.study['side_bays'][side]
                for bay in range(count):
                    l=bay*length/count;r=(bay+1)*length/count
                    entry=side in self.study['entry_sides'] and bay==count//2
                    if length<.7 or floor==0 and entry or self.covered(O,U,N,l,r,z,[]):
                        self.wall_stock(O,U,N,(l,-self.wall_depth,z),(r,0,Z),length)
                    else:self.opening(O,U,N,l,r,z,Z,length,door=entry and floor==1,basement=floor==0)
                if self.style=='garside_3502':
                    # Actual exposed concrete piers andfloor beams wrap the
                    # brick/tile curtain wall; panes remain deeply recessed.
                    for bay in range(count+1):
                        at=bay*length/count
                        lo=max(0,at-.18);hi=min(length,at+.18)
                        if hi>lo:self.stock('concrete',O,U,N,(lo,-.12,z),(hi,.055,Z),.008)
                    self.stock('concrete',O,U,N,(0,-.10,Z-.22),(length,.075,Z),.008)
            self.basement=False
        if self.style=='garside_3502':self.factory_frame(outline)
        self.crowning=True;self.row_roof(outline,height);self.crowning=False
        if self.style=='bryant_2801':self.school_detail(outline,height)
        assert len(self.entries)==1,(self.name,self.entries)
        return dict(windows=self.windows,bearings=self.bearings,entries=self.entries,mitre_seams=self.seams,closed_stocks=self.parts,min_closed_stock_volume_m3=self.min_volume,style=self.style)
