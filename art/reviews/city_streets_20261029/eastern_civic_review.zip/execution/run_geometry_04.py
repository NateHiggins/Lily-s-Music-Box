from pathlib import Path
import subprocess,json,hashlib,time,os
root=Path('C:/ov/city');out=Path(__file__).parent
script=out/'check_geometry_04.py'
env=os.environ.copy()
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:env[key]='2'
bindings={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ['art/blender/scripts/city_residential_architecture.py','art/blender/scripts/city_industrial_architecture.py','art/data/city_horizon/source_plan.json']}
started=time.time();timed_out=False
with (out/'geometry_04.log').open('xb') as log:
    proc=subprocess.Popen(['C:/Program Files/Blender Foundation/Blender 5.2/blender.exe','-b','-t','2','--python-exit-code','1','-P',str(script)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    try:code=proc.wait(timeout=30)
    except subprocess.TimeoutExpired:
        # This child was created here and is exclusively this no-render test.
        # Never enumerate or terminate a foreign Blender/Godot process.
        timed_out=True;proc.kill();proc.wait();code=124
record=dict(evidence_class='INERT',scope='Owned bounded CPU2 no-render source geometry diagnostic;not export/render/Godot/art acceptance.',pid=proc.pid,exit_code=code,timed_out=timed_out,seconds=time.time()-started,script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),source_sha256=bindings)
for path,expected in bindings.items():assert hashlib.sha256((root/path).read_bytes()).hexdigest()==expected,path
(out/'geometry_execution_04.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print(record,flush=True)
raise SystemExit(code)
