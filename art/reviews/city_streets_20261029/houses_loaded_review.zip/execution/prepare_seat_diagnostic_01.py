from pathlib import Path
import json
root=Path('C:/ov/city');out=Path(__file__).parent
(out/'seat_diagnostic_executed_01.gd').write_bytes((root/'game/tmp/city_houses_20261031/seats.gd').read_bytes())
batch=[dict(scene='res://tests/CompileChangedScripts.tscn',log=str(out/'seat_compile_01.log'),runner='serial',timeout=60,windowed=False,extra_args=[]),dict(scene='res://tmp/city_houses_20261031/Seats.tscn',log=str(out/'seat_diagnostic_01.log'),shot_dir=str(out/'seat_diagnostic_01'),runner='serial',timeout=60,windowed=False,extra_args=[])]
(out/'seat_batch_01.json').write_text(json.dumps(batch,indent=2),encoding='utf-8',newline='\n')
