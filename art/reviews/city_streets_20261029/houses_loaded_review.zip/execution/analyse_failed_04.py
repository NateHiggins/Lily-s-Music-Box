from pathlib import Path
import json,statistics,hashlib
out=Path(__file__).parent;path=out/'bench_04/houses_loaded.runtime.json';raw=path.read_bytes();data=json.loads(raw)
assert data['execution']['completed'] and data['execution']['exit_code']==1 and len(data['failures'])==6
def describe(values):
    values=sorted(values)
    return dict(samples=len(values),median=statistics.median(values),p95=values[round((len(values)-1)*.95)],p99=values[round((len(values)-1)*.99)],maximum=max(values))
rows=[]
for case in data['observations']:
    row=dict(building=case['building'],case=case['id'],counters=case['counters'])
    for phase,key in [('transition','warmup_samples'),('warmed','samples')]:
        samples=case[key];row[phase]={metric:describe([s[metric] for s in samples]) for metric in ['wall_ms','viewport_cpu_ms','viewport_gpu_ms']}
    rows.append(row)
record=dict(evidence_class='INERT',scope='Analysis of ORIGINAL FAILED family04 only. Measured isolated viewport work and frame intervals,not runtime qualification,matched improvement,wholecity budget or artistic acceptance.',runtime_receipt_sha256=hashlib.sha256(raw).hexdigest(),checks=data['checks'],failures=data['failures'],settings=data['settings'],rows=rows)
path=out/'failed_04_analysis.json';assert not path.exists();path.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
print('Failed-run diagnostic:32s wrapper,40cases,',sum(len(c['samples']) for c in data['observations']),'warmed and',sum(len(c['warmup_samples']) for c in data['observations']),'transition frames')
print('Wall max',max(s['wall_ms'] for c in data['observations'] for s in c['samples']),'transition max',max(s['wall_ms'] for c in data['observations'] for s in c['warmup_samples']))
