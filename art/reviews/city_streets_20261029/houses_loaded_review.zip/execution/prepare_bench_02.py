from pathlib import Path
import json
root=Path('C:/ov/city');out=Path(__file__).parent;path=root/'game/tmp/city_houses_20261031/bench.gd'
code=path.read_text(encoding='utf-8').expandtabs(4)
code=code.replace('            for frame in 12:await RenderingServer.frame_post_draw','''            var warmup:Array[Dictionary]=[];var transition_previous=Time.get_ticks_usec()
            for frame in 12:
                await RenderingServer.frame_post_draw
                var transition_now=Time.get_ticks_usec();var transition_sample=_counters()
                transition_sample.merge({"wall_ms":(transition_now-transition_previous)/1000.,"viewport_cpu_ms":RenderingServer.viewport_get_measured_render_time_cpu(viewport.get_viewport_rid()),"viewport_gpu_ms":RenderingServer.viewport_get_measured_render_time_gpu(viewport.get_viewport_rid())})
                warmup.append(transition_sample);transition_previous=transition_now''')
code=code.replace('"samples":samples,"counters":_counters()', '"warmup_samples":warmup,"samples":samples,"counters":_counters()')
code=code.replace('"checks":checks,"failures":failures,"source_hashes":sources','"checks":checks,"failures":failures,"mapping_failures":metric_failures,"source_hashes":sources')
assert '\t' not in code
path.write_text(code,encoding='utf-8',newline='\n');(out/'bench_02_executed_source.gd').write_bytes(path.read_bytes())
batch=[dict(scene='',log=str(out/'compile_02.log'),runner='serial',timeout=60,windowed=False,extra_args=['--check-only','--script','res://tmp/city_houses_20261031/bench.gd']),dict(scene='res://tmp/city_houses_20261031/Bench.tscn',log=str(out/'bench_02.log'),shot_dir=str(out/'bench_02'),runner='long',timeout=240,windowed=True,extra_args=['--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440'])]
(out/'batch_02.json').write_text(json.dumps(batch,indent=2),encoding='utf-8',newline='\n')
