from pathlib import Path
from PIL import Image,ImageDraw
out=Path(__file__).parent
paths=sorted((out/'bench_04').glob('*profile*.png'))
assert len(paths)==16
sheet=Image.new('RGB',(1600,800),(35,35,35));draw=ImageDraw.Draw(sheet)
for i,path in enumerate(paths):
    img=Image.open(path);img.thumbnail((400,170));x=(i%4)*400;y=(i//4)*200
    sheet.paste(img,(x,y));draw.text((x+4,y+173),path.stem.replace('HORIZON_',''),fill='white')
path=out/'failed_04_profile_contact.png';assert not path.exists();sheet.save(path)
print(path)
