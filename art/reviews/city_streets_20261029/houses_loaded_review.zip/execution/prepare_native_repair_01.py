from pathlib import Path
import ast,json,struct,hashlib,subprocess
root=Path('C:/ov/city');out=Path(__file__).parent
reader=out.parent/'bodega_frontage_reconciliation_01/check_preservation_01.py';tree=ast.parse(reader.read_text(encoding='utf-8-sig'))
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),str(reader),'exec'))
targets=['HORIZON_NEAR_0_1_P0R0','HORIZON_NEAR_0_1_P0R1','HORIZON_NEAR_2_0_P0R1','HORIZON_NEAR_2_0_P0R2']
families=['city_horizon_near','city_horizon_far','city_horizon_lod1']
for name in ['city_residential_architecture.py','city_industrial_architecture.py']:
    raw=subprocess.check_output(['git','show','HEAD:art/blender/scripts/'+name],cwd=root)
    path=out/('ef1_original_'+name);assert not path.exists();path.write_bytes(raw)
baseline=dict(evidence_class='INERT',sourcebase='ef1c06a3e6a061aa1c3ff7e2cb53544540f44e39',targets=targets,parts={f:projection((root/f'game/assets/props/{f}.glb').read_bytes()) for f in families},other_assets={f'game/assets/props/{f}.glb':hashlib.sha256((root/f'game/assets/props/{f}.glb').read_bytes()).hexdigest() for f in ['city_elevations','city_elevations_lod1','city_streets','city_streets_lod1','city_transport','city_transport_lod1','city_ground_apron','orison_ground','front_pavement','bodega_receiving']},profiles=json.loads((root/'art/data/city_horizon/source_plan.json').read_text())['buildings'])
for family in families:
    path=f'game/assets/props/{family}.glb';raw=subprocess.check_output(['git','show','HEAD:'+path],cwd=root)
    assert hashlib.sha256(raw).hexdigest()==hashlib.sha256((root/path).read_bytes()).hexdigest(),path
path=out/'repair_baseline_01.json';assert not path.exists();path.write_text(json.dumps(baseline,indent=2),encoding='utf-8',newline='\n')
runner=(out.parent/'northern_houses_01/run_native_build_06.py').read_text(encoding='utf-8').replace('_06','_07')
path=out/'run_native_build_07.py';assert not path.exists();path.write_text(runner,encoding='utf-8',newline='\n')
print('Immutable ef1 products verified;source repair baseline captured;no products changed')
