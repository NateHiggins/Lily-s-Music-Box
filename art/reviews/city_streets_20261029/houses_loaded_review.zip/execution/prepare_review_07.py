from pathlib import Path
out=Path(__file__).parent
prior=out.parent/'northern_houses_01'
code=(prior/'review_native_04.py').read_text(encoding='utf-8')
code=code.replace("/'native_review_04'","/'native_review_07'")
code=code.replace("'HORIZON_NEAR_0_1_P0R2']","'HORIZON_NEAR_2_0_P0R1','HORIZON_NEAR_2_0_P0R2']")
start=code.index("    if family=='city_horizon_lod1':")
end=code.index('    for image in bpy.data.images:',start)
code=code[:start]+'''    trees={name:BVHTree.FromPolygons([obj.matrix_world@v.co for v in obj.data.vertices],[tuple(f.vertices) for f in obj.data.polygons],all_triangles=True) for name,obj in imported.items()}
    for row in construction['parapet_contacts']:
        if row['building'] not in IDS:continue
        identity=row['building'];p=Vector(row['point']);profile=profiles[identity]
        residential=profile['architecture']['type']=='residential_front'
        support=p.copy()
        if residential:
            heights=profile['architecture']['floor_heights_m']
            support.z=sum(heights if profile['architecture']['style']=='italianate_2109' else heights[:-1])+profile['grade_datum_m']
        direction=Vector((0,0,-1 if residential else 1))
        expected=identity+'__'+row['wall_key']
        hits=[]
        for name,tree in trees.items():
            hit,normal,index,distance=tree.ray_cast(support-direction*.025,direction,.05)
            if hit is not None and normal.dot(direction)<0:hits.append((distance,name,hit))
        assert hits,('no unfiltered receiver',family,row)
        distance,name,hit=min(hits,key=lambda h:h[0])
        assert name==expected and (hit-support).length<.0001,('actual first receiving stock',family,row,name,list(hit),list(support))
        roof=trees[identity+'__galvanized_roof']
        hit,normal,index,distance=roof.ray_cast(p+Vector((0,0,.025)),Vector((0,0,-1)),.05)
        assert hit is not None and (hit-p).length<.0001,('roof top',family,row)
        outside=Vector(row['outside_probe']);hit,normal,index,distance=roof.ray_cast(outside+Vector((0,0,.025)),Vector((0,0,-1)),.05)
        assert hit is None,('outside roof control',family,row)
        contacts.append(dict(family=family,contact=row,first_receiving_part=name,error_m=(support-(min(hits,key=lambda h:h[0])[2])).length))
''' +code[end:]
start=code.index('    for identity in chosen:')
end=code.index('for path,expected in bindings.items():',start)
code=code[:start]+'''    views=[
        ('northern_pair',IDS[:2],(-44.,125.,18.),(-59.,159.,5.),29.,(1200,850)),
        ('northern_cap_joint',IDS[:2],(-58.,155.,12.),(-59.35,160.8,8.8),7.,(1000,850)),
        ('eastern_pair',IDS[2:],(-121.,117.,17.),(-159.,138.,4.8),28.,(1200,850)),
        ('eastern_party_cornice',IDS[2:],(-151.,131.,10.),(-160.,135.333333,7.3),8.,(1000,850)),
    ]
    for label,identities,eye,aim,scale,res in views:
        visible=[]
        for name,obj in imported.items():
            obj.hide_render=name.split('__')[0] not in identities
            if not obj.hide_render:visible.append(obj)
        camera.location=eye;camera.rotation_euler=(Vector(aim)-camera.location).to_track_quat('-Z','Y').to_euler()
        camera.data.type='ORTHO';camera.data.ortho_scale=scale;scene.render.resolution_x,scene.render.resolution_y=res
        detail='pair' not in label;framed=None
        if not detail:
            for attempt in range(24):
                bpy.context.view_layer.update();points=[world_to_camera_view(scene,camera,obj.matrix_world@Vector(corner)) for obj in visible for corner in obj.bound_box]
                framed=all(p.z>0 and .035<=p.x<=.965 and .035<=p.y<=.965 for p in points)
                if framed:break
                camera.data.ortho_scale*=1.12
            assert framed,(family,label,'whole framing')
        path=OUT/(family+'_'+label+'.png');scene.render.filepath=str(path);bpy.ops.render.render(write_still=True)
        captures.append(dict(path=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),family=family,buildings=identities,whole_body_framed=framed,intentional_detail_crop=detail))
''' +code[end:]
code=code.replace('assert len(roundtrips)==56 and len(contacts)==8 and len(captures)==2','assert len(roundtrips)>0 and len(contacts)==38 and len(captures)==8')
code=code.replace('lower_roof_and_actual_bearing_controls=contacts','near_and_lower_unfiltered_bearing_controls=contacts')
(out/'review_native_07.py').write_text(code,encoding='utf-8',newline='\n')
runner=(prior/'run_native_review_04.py').read_text(encoding='utf-8').replace('_04','_07')
(out/'run_native_review_07.py').write_text(runner,encoding='utf-8',newline='\n')
uv=(prior/'verify_export_uv_06.py').read_text(encoding='utf-8').replace('_06','_07')
(out/'verify_export_uv_07.py').write_text(uv,encoding='utf-8',newline='\n')
preserve=(prior/'check_preservation_06.py').read_text(encoding='utf-8').replace("/'baseline_01.json'","/'repair_baseline_01.json'").replace('len(old)-3','len(old)-len(baseline[\'targets\'])').replace('preservation_06','preservation_07')
preserve=preserve.replace("report['parts'][family]=dict(","report.setdefault('changed_target_parts',{})[family]=[k for k,v in old.items() if new.get(k)!=v]\n    report['parts'][family]=dict(")
(out/'check_preservation_07.py').write_text(preserve,encoding='utf-8',newline='\n')
print('Prepared bounded native/export review;no Godot launch')
