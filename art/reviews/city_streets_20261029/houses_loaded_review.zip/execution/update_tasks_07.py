from pathlib import Path
p=Path('C:/ov/city/TASKS.md');s=p.read_text(encoding='utf-8')
old='Native-only delivery;loaded/access/performance/artistic qualification remains open.'
new='Native-only delivery;first eight-building loaded run04 fails1,634checks/6failures in32.14s:four14mm near masonry cap gaps,one20mm neighbour cornice interference andone stable-wall LOD-selection harness error. Original receipts/assets/captures retained;no new loaded grant. Source repair generation07 exits0/33.14s,three exports UV0,727 unrelated parts/120 profiles/124parcels/ten assets exact. Corrected native review andloaded rerun pending;actual access,whole-city cost andartistic qualification remain open.'
assert s.count(old)==1;p.write_text(s.replace(old,new),encoding='utf-8',newline='\n')
