from pathlib import Path
import sys,json,collections,importlib.util
from mathutils import Vector
from mathutils.bvhtree import BVHTree
root=Path('C:/ov/city');out=Path(__file__).parent;sys.path.insert(0,str(root/'art/blender/scripts'))
fixture=json.loads((root/'art/blender/city_horizon_construction.json').read_text());plan=json.loads((root/'art/data/city_horizon/source_plan.json').read_text());results=[]
for label,path in [('original',out.parent/'northern_houses_01/executed_06_city_residential_architecture.py'),('repaired',root/'art/blender/scripts/city_residential_architecture.py')]:
    spec=importlib.util.spec_from_file_location('wallcap_'+label,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);failures=[];panes=0;seats=0
    for i in [0,1]:
        row=next(r.copy() for r in fixture['buildings'] if r['id']==f'HORIZON_NEAR_0_1_P0R{i}');row['grade_datum_m']=0.;buf=collections.defaultdict(lambda:([],[]))
        def emit(owner,key,vertices,faces):
            vv,ff=buf[key];start=len(vv);vv.extend(vertices);ff.extend(tuple(start+j for j in f) for f in faces)
        product=module.ResidentialHouses(row,emit,[r for r in plan['buildings'] if r['id']!=row['id']],False).build()
        key=row['wall_key'];vv,ff=buf[key];tree=BVHTree.FromPolygons(vv,ff,all_triangles=False)
        eave=sum(row['architecture']['floor_heights_m'] if i==0 else row['architecture']['floor_heights_m'][:-1])
        for seat in product['bearings']:
            seats+=1;p=Vector(seat['point']);p.z=eave
            hit,n,index,d=tree.ray_cast(p+Vector((0,0,.025)),Vector((0,0,-1)),.05)
            if hit is None or (hit-p).length>=.0001:failures.append(dict(building=row['id'],point=list(p),actual=list(hit) if hit is not None else None,error_m=(hit-p).length if hit is not None else None))
        vertices=[];faces=[];owners=[]
        for key,(vv,ff) in buf.items():
            start=len(vertices);vertices.extend(vv);faces.extend(tuple(start+j for j in f) for f in ff);owners.extend([key]*len(ff))
        tree=BVHTree.FromPolygons(vertices,faces,all_triangles=False)
        for window in product['windows']:
            panes+=1;p=Vector(window['point']);n=Vector(window['normal']);hit,N,index,d=tree.ray_cast(p+n*.05,-n,.30)
            assert hit is not None and owners[index]=='mirror_aged' and (hit-(p-n*.17)).length<.0001,(label,row['id'],window)
    assert len(failures)==(4 if label=='original' else 0),(label,failures)
    results.append(dict(source=label,receiving_seats=seats,panes=panes,failures=failures))
path=out/'source_cap_control_01.json';assert not path.exists();path.write_text(json.dumps(dict(evidence_class='INERT',scope='Actual emitted near structural caps and pane BVH. Original4 failed14mm seat notches retained;new caps pass original0.1mm tolerance. No regenerated product or runtime acceptance.',results=results),indent=2),encoding='utf-8',newline='\n');print(results)
