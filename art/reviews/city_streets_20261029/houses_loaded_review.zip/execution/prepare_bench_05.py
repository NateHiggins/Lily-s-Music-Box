from pathlib import Path
import json
root=Path('C:/ov/city');out=Path(__file__).parent;path=root/'game/tmp/city_houses_20261031/bench.gd'
code=path.read_text(encoding='utf-8')
old='        transitions[identity]=await _profile_natural(horizon,camera,draws,identity,str(profile.wall_key),directory)'
new='''        var natural_key=str(profile.wall_key);var primary_reduces=false;var alternative="";var alternative_indices=0
        for draw:MeshInstance3D in draws:
            if not str(draw.name).begins_with(identity+"__"):continue
            var part_surface:Dictionary=RenderingServer.mesh_get_surface(draw.mesh.get_rid(),0)
            if (part_surface.get("lods",[]) as Array).size()!=1:continue
            var key=str(draw.name).split("__")[-1]
            if key==natural_key:primary_reduces=true
            if draw.mesh.surface_get_array_index_len(0)>alternative_indices:
                alternative=key;alternative_indices=draw.mesh.surface_get_array_index_len(0)
        if not primary_reduces:natural_key=alternative
        check(not natural_key.is_empty(),"natural control selects an actually reducing production material part")
        transitions[identity]=await _profile_natural(horizon,camera,draws,identity,natural_key,directory)
        transitions[identity]["selection"]={"requested_wall_key":profile.wall_key,"actual_key":natural_key,"primary_material_reduces":primary_reduces,"reason":"Whole-building forced LOD already measured. Stable wall quads have no authored index reduction;natural material control selects an actual reducing body part."}'''
assert code.count(old)==1;code=code.replace(old,new)
code=code.replace('"actual roof top seating"','"actual roof top seating "+str(row)')
code=code.replace('"actual receiving wall/sheathing below roof sheet"','"actual receiving wall/sheathing below roof sheet "+str(row)')
code=code.replace('"actual parapet/post underside meets roof"','"actual parapet/post underside meets roof "+str(row)')
code=code.replace('"natural_material_transitions":{"executed":transitions.size()==8,"passed":failures.is_empty()}', '"natural_material_transitions":{"executed":transitions.size()==8,"passed":failures.is_empty()},"collision_pane_and_roof_seats":{"executed":seat_result.pane_samples==418 and seat_result.roof_controls==37,"passed":failures.is_empty()}')
path.write_text(code,encoding='utf-8',newline='\n');(out/'bench_05_executed_source.gd').write_bytes(path.read_bytes())
batch=json.loads((out/'batch_04.json').read_text())
for row in batch:
    row['log']=row['log'].replace('_04','_05')
    if 'shot_dir' in row:row['shot_dir']=row['shot_dir'].replace('_04','_05')
(out/'batch_05.json').write_text(json.dumps(batch,indent=2),encoding='utf-8',newline='\n')
print('Next bench prepared but NOT launched;wait for native source repair and review')
