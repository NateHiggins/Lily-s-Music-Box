from pathlib import Path
import json,hashlib,zipfile
root=Path('C:/ov/city');out=Path(__file__).parent
receipt=json.loads((out/'bench_05/houses_loaded.runtime.json').read_text());assert receipt['checks']==1660 and not receipt['failures']
assert (out/'loaded_inspection_05.json').is_file() and (out/'native_inspection_08.json').is_file()
dest=root/'art/reviews/city_streets_20261029/houses_loaded_review.zip';assert not dest.exists()
stored={}
for p in sorted(out.rglob('*')):
    if p.is_file() and p.suffix in ['.py','.json','.log','.stderr','.png','.gd','.tscn'] and '__pycache__' not in p.parts:
        stored['execution/'+p.relative_to(out).as_posix()]=p.read_bytes()
runtime_bindings={}
for resource,expected in receipt['source_hashes'].items():
    relative='game/'+resource.removeprefix('res://');p=root/relative;raw=p.read_bytes()
    normalized=raw.replace(b'\r\n',b'\n') if p.suffix in ['.gd','.json','.gdshader','.gdshaderinc','.import'] else raw
    assert hashlib.sha256(normalized).hexdigest()==expected,relative
    runtime_bindings[relative]=dict(bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),test_sha256=expected,lf_normalized=p.suffix in ['.gd','.json','.gdshader','.gdshaderinc','.import'])
    if p.suffix not in ['.png','.glb']:stored['final/'+relative]=raw
for relative in ['art/blender/scripts/build_city_horizon.py','art/blender/scripts/city_residential_architecture.py','art/blender/scripts/city_industrial_architecture.py','art/data/city_horizon/source_plan.json']:
    stored['final/'+relative]=(root/relative).read_bytes()
for name in ['Bench.tscn','Seats.tscn']:stored['final/game/tmp/city_houses_20261031/'+name]=(root/'game/tmp/city_houses_20261031'/name).read_bytes()
assets=['art/blender/city_horizon_near.blend','art/blender/city_horizon_far.blend','art/blender/city_horizon_lod1.blend','art/blender/city_horizon_construction.json','game/assets/props/city_horizon_near.glb','game/assets/props/city_horizon_far.glb','game/assets/props/city_horizon_lod1.glb','game/data/orison_v2/exterior/city_horizon.json','game/tests/fixtures/orison_city_horizon.json']
bindings={p:dict(bytes=(root/p).stat().st_size,sha256=hashlib.sha256((root/p).read_bytes()).hexdigest()) for p in assets}
prior={'eastern_industrial_native_review.zip':'8062f3e7d1b108d8435eb0d1ff978d8713b7fc294e6da0a75c0731f8bc5a8cb3','eastern_row_native_review.zip':'dbd65f964c99e311be59c657f1f103098fdb73a9506e92843a4224817d2b1055','eastern_street_native_review.zip':'9f95d8aaa564cc83066d1f345b4ecde8148ff3efd64a7948061bde4cdd0622fb','northern_houses_native_review.zip':'127f7c8e50a84d6b65c5a1f85059cddb0a2f5042a5c34ac8ad37ee3149bf7bd6'}
for name,sha in prior.items():assert hashlib.sha256((dest.parent/name).read_bytes()).hexdigest()==sha,name
scope='Native repair68 exact roundtrips/42 near+lower receiving controls/8 inspected renders;passed test-written schema2 isolated production family05 1660/0,80 inspected captures. Original failed04 1634/6 andharness/native failures preserved. Archive/report/analysis remain INERT;only embedded runtime_contract hasits exact scope. No composedground,ordinaryplayeraccess,actors,saves,wholecity budget orartistic acceptance.'
index=dict(evidence_class='INERT',scope=scope,sourcebase='ef1c06a3e6a061aa1c3ff7e2cb53544540f44e39',assets=bindings,runtime_sources=runtime_bindings,prior_unchanged_archives=prior,members={k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in stored.items()})
stored['archive_index.json']=json.dumps(index,indent=2).encode('utf-8')
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
    for k,v in stored.items():z.writestr(k,v,compress_type=zipfile.ZIP_STORED if k.endswith('.png') else zipfile.ZIP_DEFLATED,compresslevel=1)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None and set(z.namelist())==set(stored)
    for k,v in stored.items():assert z.read(k)==v,k
record=dict(evidence_class='INERT',scope=scope,archive=dest.relative_to(root).as_posix(),bytes=dest.stat().st_size,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),member_count=len(stored),runtime_contract='execution/bench_05/houses_loaded.runtime.json',runtime_contract_sha256=hashlib.sha256((out/'bench_05/houses_loaded.runtime.json').read_bytes()).hexdigest(),asset_bindings=bindings)
path=root/'art/reviews/city_streets_20261029/manifest.json';manifest=json.loads(path.read_text());assert 'houses_loaded_archive' not in manifest;manifest['houses_loaded_archive']=record;path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'archive_record_05.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
p=root/'design/V2_CITY_CONTEXT_REPORT_2026-10-19.md';s=p.read_text(encoding='utf-8');s+='\n\nAdditive house loaded packet: **'+record['archive']+'**, '+str(record['member_count'])+'members/'+str(record['bytes'])+'bytes/SHA256 **'+record['sha256']+'**. CRC/every member andall'+str(len(runtime_bindings))+' current runtime source bindings verified. Original four city packets remain byte-exact inthis branch;canonical separately owns its appended street-intake evidence. No blend/glTF/texture/reference-photo duplicate is stored. Embedded original failed andpassed test-written receipts retain their distinct scopes.638 untracked UID files generated byour imports were byte-backed-up externally andremoved only withinC:/ov/city afterown engine terminal;no tracked UID/canonical index touched.\n';p.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in record.items() if k!='asset_bindings'}),flush=True)
