extends Node
const Horizon=preload("res://scripts/building/orison_v2_city_horizon.gd")
const IDS=["HORIZON_NEAR_2_0_P0R0","HORIZON_NEAR_2_0_P0R1","HORIZON_NEAR_2_0_P0R2","HORIZON_NEAR_2_0_P2","HORIZON_FAR_2_1_P0","HORIZON_NEAR_0_1_P0R0","HORIZON_NEAR_0_1_P0R1","HORIZON_NEAR_0_1_P0R2"]
func _ready()->void:call_deferred("run_diag")
func point(a:Array)->Vector3:return Vector3(a[0],a[2],-a[1])
func vector(v:Vector3)->Array:return [v.x,v.y,v.z]
func describe(hit:Dictionary)->Dictionary:
    if hit.is_empty():return {"missing":true}
    return {"part":str(hit.collider.get_parent().name),"position":vector(hit.position),"normal":vector(hit.normal)}
func run_diag()->void:
    RealityState.persistence_enabled=false;RealityState.reset_campaign_for_tests();CampaignTime.set_frozen_for_tests(true)
    var fixture:Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://tests/fixtures/orison_city_horizon.json"))
    var horizon=Horizon.new();add_child(horizon);await get_tree().physics_frame;await get_tree().physics_frame
    var profiles:Dictionary={};var all_bodies:Dictionary={};var records:Array[Dictionary]=[]
    for row:Dictionary in fixture.buildings:profiles[str(row.id)]=row
    for draw:MeshInstance3D in horizon.find_children("*","MeshInstance3D",true,false):all_bodies[str(draw.name)]=(draw.get_node("HorizonCollision") as StaticBody3D).get_rid()
    var space=horizon.get_world_3d().direct_space_state
    for row:Dictionary in fixture.parapet_contacts:
        if str(row.building) not in IDS:continue
        var p=point(row.point);var profile:Dictionary=profiles[str(row.building)];var support=p
        var residential=str(profile.architecture.type)=="residential_front"
        if residential:
            support.y=float(profile.grade_datum_m)
            var heights:Array=profile.architecture.floor_heights_m
            for index in (heights.size() if str(profile.architecture.style)=="italianate_2109" else heights.size()-1):support.y+=float(heights[index])
        var sign_value=1. if residential else -1.
        var expected=str(row.building)+"__"+str(row.wall_key)
        var query=PhysicsRayQueryParameters3D.create(support+Vector3.UP*.025*sign_value,support-Vector3.UP*.025*sign_value,1);query.hit_back_faces=false
        var hit=space.intersect_ray(query)
        var original=describe(hit)
        var passed=not hit.is_empty() and str(hit.collider.get_parent().name)==expected and hit.position.distance_to(support)<.0001
        var excludes:Array[RID]=[]
        for name:String in all_bodies:
            if name!=expected:excludes.append(all_bodies[name])
        query.exclude=excludes
        var isolated=describe(space.intersect_ray(query))
        query.from=support+Vector3.UP*.25*sign_value;query.to=support-Vector3.UP*.25*sign_value
        var wide=describe(space.intersect_ray(query))
        records.append({"building":row.building,"style":profile.architecture.style,"roof_point":vector(p),"support_point":vector(support),"expected_part":expected,"original_passed":passed,"original_unfiltered":original,"expected_stock_only":isolated,"wide_diagnostic_only":wide})
    horizon.free();await get_tree().physics_frame
    var directory=OS.get_environment("SHOT_DIR");DirAccess.make_dir_recursive_absolute(directory)
    var file=FileAccess.open(directory.path_join("seat_hits.json"),FileAccess.WRITE)
    if file==null:get_tree().quit(1);return
    file.store_string(JSON.stringify({"evidence_class":"INERT","scope":"Actual original unfiltered receiving-seat queries plus independently filtered stock and wider diagnostic rays. Filtering/wider rays are diagnosis only,not access or tolerance changes.","records":records},"\t")+"\n");file.close()
    print("SEAT HIT DIAGNOSTIC: ",records.size()," records; no acceptance")
    get_tree().quit(0)
