from pathlib import Path
import json,hashlib,bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree
root=Path('C:/ov/city');out=Path(__file__).parent
fixture=json.loads((root/'art/blender/city_horizon_construction.json').read_text())
ids={'HORIZON_NEAR_2_0_P0R0','HORIZON_NEAR_2_0_P0R1','HORIZON_NEAR_2_0_P0R2','HORIZON_NEAR_2_0_P2','HORIZON_FAR_2_1_P0'}|{f'HORIZON_NEAR_0_1_P0R{i}' for i in range(3)}
profiles={r['id']:r for r in fixture['buildings']};records=[];bindings={}
for family in ['near','far']:
    path=root/f'art/blender/city_horizon_{family}.blend';bindings[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
    bpy.ops.wm.open_mainfile(filepath=str(path));bpy.context.view_layer.update()
    trees={obj.name:BVHTree.FromPolygons([obj.matrix_world@v.co for v in obj.data.vertices],[tuple(f.vertices) for f in obj.data.polygons],all_triangles=True) for obj in bpy.data.collections['CityHorizon_'+family].objects if obj.name.split('__')[0] in ids}
    for contact in fixture['parapet_contacts']:
        identity=contact['building']
        if identity not in ids or (identity.startswith('HORIZON_NEAR')!=(family=='near')):continue
        row=profiles[identity];p=Vector(contact['point']);residential=row['architecture']['type']=='residential_front'
        if residential:p.z=sum(row['architecture']['floor_heights_m'] if row['architecture']['style']=='italianate_2109' else row['architecture']['floor_heights_m'][:-1])+row['grade_datum_m']
        direction=Vector((0,0,-1 if residential else 1));tree=trees[identity+'__'+contact['wall_key']]
        hit,n,index,distance=tree.ray_cast(p-direction*.025,direction,.05)
        passed=hit is not None and (hit-p).length<.0001
        records.append(dict(building=identity,style=row['architecture']['style'],expected_key=contact['wall_key'],point=list(p),actual=list(hit) if hit is not None else None,normal=list(n) if n is not None else None,error_m=(hit-p).length if hit is not None else None,passed=passed))
for path,expected in bindings.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==expected
path=out/'native_receiving_01.json';assert not path.exists();path.write_text(json.dumps(dict(evidence_class='INERT',scope='Read-only actual near native receiving-stock BVH at the exact failed runtime probe locations. No shape change,Godot acceptance or tolerance relaxation.',records=records,source_hashes=bindings),indent=2),encoding='utf-8',newline='\n')
print('NATIVE RECEIVING DIAGNOSTIC',len(records),'records; failures',json.dumps([r for r in records if not r['passed']]),flush=True)
