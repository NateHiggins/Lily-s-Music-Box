from pathlib import Path
import subprocess,json,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent;rows=[]
for name,args in [('horizon_tests',['python','-m','unittest','tools.tests.test_city_horizon']),('reader',['python','tools/audit_data_consumption.py','--baseline']),('design_lint',['python','tools/lint_design_doc.py','design/V2_CITY_CONTEXT_REPORT_2026-10-19.md'])]:
    result=subprocess.run(args,cwd=root,capture_output=True,text=True)
    path=out/(name+'_05.log');assert not path.exists();path.write_text(result.stdout+result.stderr,encoding='utf-8',newline='\n')
    rows.append(dict(name=name,args=args,exit_code=result.returncode,log=path.name,log_sha256=hashlib.sha256(path.read_bytes()).hexdigest()));print(name,result.returncode,result.stdout[-400:],result.stderr[-200:],flush=True)
    assert result.returncode==0
(out/'source_checks_05.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Source-only checks;not runtime or artistic acceptance.',checks=rows),indent=2),encoding='utf-8',newline='\n')
