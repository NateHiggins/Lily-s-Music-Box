from pathlib import Path
import json
root=Path('C:/ov/city');out=Path(__file__).parent
batch=json.loads((out/'batch_03.json').read_text())
batch[0].update(scene='res://tests/CompileChangedScripts.tscn',extra_args=[])
for row in batch:
    row['log']=row['log'].replace('_03','_04')
    if 'shot_dir' in row:row['shot_dir']=row['shot_dir'].replace('_03','_04')
(out/'batch_04.json').write_text(json.dumps(batch,indent=2),encoding='utf-8',newline='\n')
(out/'bench_04_executed_source.gd').write_bytes((root/'game/tmp/city_houses_20261031/bench.gd').read_bytes())
