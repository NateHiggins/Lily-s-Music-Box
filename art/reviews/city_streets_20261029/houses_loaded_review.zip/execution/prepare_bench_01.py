from pathlib import Path
import json,hashlib
root=Path('C:/ov/city');out=Path(__file__).parent;folder=root/'game/tmp/city_houses_20261031'
code='''extends "res://tests/v2_city_horizon_bench.gd"
## Isolated production-loader programme; no world/ground/access claim.
const IDS=["HORIZON_NEAR_2_0_P0R0","HORIZON_NEAR_2_0_P0R1","HORIZON_NEAR_2_0_P0R2","HORIZON_NEAR_2_0_P2","HORIZON_FAR_2_1_P0","HORIZON_NEAR_0_1_P0R0","HORIZON_NEAR_0_1_P0R1","HORIZON_NEAR_0_1_P0R2"]
var view_direction=Vector3(1.,.12,.18).normalized()
var observations:Array[Dictionary]=[]
var transitions:Dictionary={}
var maps:Dictionary={}

func _ready()->void:call_deferred("run_family")

func _sources(owner:Node3D)->Dictionary:
    var result=_industrial_sources(owner)
    for path:String in [get_script().resource_path,"res://tests/orison_v2_domestic_native_test.gd","res://tests/orison_v2_roof_bulkhead_caps_test.gd"]:result[path]=_profile_sha(path)
    return result

func _counters()->Dictionary:
    var rid=get_viewport().get_viewport_rid()
    return {"visible_draws":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_VISIBLE,RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME),"visible_primitives":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_VISIBLE,RenderingServer.VIEWPORT_RENDER_INFO_PRIMITIVES_IN_FRAME),"shadow_draws":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_SHADOW,RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME),"shadow_primitives":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_SHADOW,RenderingServer.VIEWPORT_RENDER_INFO_PRIMITIVES_IN_FRAME),"aggregate_draws":Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME),"aggregate_primitives":Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME)}

func run_family()->void:
    RealityState.persistence_enabled=false;RealityState.reset_campaign_for_tests();CampaignTime.set_frozen_for_tests(true)
    var directory=OS.get_environment("SHOT_DIR")
    check(not directory.is_empty() and DisplayServer.get_name()!="headless","graphical output directory supplied")
    if directory.is_empty() or DisplayServer.get_name()=="headless":get_tree().quit(1);return
    DirAccess.make_dir_recursive_absolute(directory)
    var fixture:Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://tests/fixtures/orison_city_horizon.json"))
    for asset:Dictionary in fixture.assets.values():check(FileAccess.get_sha256("res://"+str(asset.asset).trim_prefix("game/"))==str(asset.sha256),"asset matches native fixture")
    var horizon=Horizon.new();add_child(horizon)
    await get_tree().physics_frame;await get_tree().physics_frame
    var sources=_sources(horizon)
    var metrics=preload("res://tests/orison_v2_domestic_native_test.gd").new()
    var lower=(load("res://assets/props/city_horizon_lod1.glb") as PackedScene).instantiate()
    var low_counts:Dictionary={};var expected_parts:Dictionary={}
    for part:Dictionary in fixture.assets.body_lod.parts:
        if str(part.name).split("__")[0] in IDS:expected_parts[str(part.name)]=int(part.triangles)
    for part:MeshInstance3D in lower.find_children("*","MeshInstance3D",true,false):
        if not expected_parts.has(str(part.name)):continue
        metrics._check_cap_mapping(part.mesh,true)
        low_counts[str(part.name)]=part.mesh.surface_get_array_index_len(0)/3
        check(int(low_counts[str(part.name)])==int(expected_parts[str(part.name)]),"complete imported replacement part "+str(part.name))
    lower.free()
    var draws:Array=horizon.find_children("*","MeshInstance3D",true,false)
    var bounds:Dictionary={};var selected=0
    for draw:MeshInstance3D in draws:
        var identity=str(draw.get_meta("v2_city_horizon_building"));draw.visible=identity in IDS
        if not draw.visible:continue
        selected+=1
        check(draw.get_meta("v2_city_horizon_body_lod",false),"production complete-body replacement mounted")
        check(low_counts.has(str(draw.name)),"selected production part in replacement roster")
        metrics._check_cap_mapping(draw.mesh,true)
        var box=draw.global_transform*draw.get_aabb()
        bounds[identity]=(bounds[identity] as AABB).merge(box) if bounds.has(identity) else box
        var surface:Dictionary=RenderingServer.mesh_get_surface(draw.mesh.get_rid(),0)
        var lods:Array=surface.get("lods",[])
        var reduces=int(low_counts[str(draw.name)])*3<draw.mesh.surface_get_array_index_len(0)
        check(lods.size()==1 if reduces else lods.is_empty(),"source-authored replacement without automatic tail")
    check(selected==67 and selected==low_counts.size() and bounds.size()==8,"eight requested buildings and67 production partitions execute")
    check(metrics.failures.is_empty(),"loaded native and replacement UVs/basis/derivatives pass original tolerances")
    var metric_failures=metrics.failures.duplicate();metrics.free()
    var material_rows=_industrial_materials(horizon)
    for name:String in material_rows:
        if name.split("__")[0] not in IDS:continue
        var row:Dictionary=material_rows[name];maps[name]=row
        check(not row.triplanar and row.maps.size()==3,"registered authored UV PBR binding "+name)
        for channel:String in ["albedo","roughness","normal"]:
            var texture:Dictionary=row.maps[channel]
            var dimensions:Array=texture.dimensions
            var required=int(floor(log(float(maxi(int(dimensions[0]),int(dimensions[1]))))/log(2.)))
            check(bool(texture.has_mipmaps) and int(texture.mipmap_count)==required,"complete actual loaded "+channel+" mip chain "+name)
    check(maps.size()==67,"all selected materials inspected")
    var environment=WorldEnvironment.new();var settings=Environment.new()
    settings.background_mode=Environment.BG_COLOR;settings.background_color=Color(.32,.38,.44)
    settings.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;settings.ambient_light_color=Color(.62,.72,.8);settings.ambient_light_energy=.7
    environment.environment=settings;add_child(environment)
    var sun=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-40,-25,0);sun.light_energy=2.8;sun.shadow_enabled=true;add_child(sun)
    var camera=Camera3D.new();camera.far=20000.;add_child(camera);camera.make_current()
    await RenderingServer.frame_post_draw
    var viewport=get_viewport();var threshold=viewport.mesh_lod_threshold;var taa=viewport.use_taa;var vsync=DisplayServer.window_get_vsync_mode();var cap=Engine.max_fps
    check(viewport.get_visible_rect().size==Vector2(3440,1440),"fullscreen native3440x1440 viewport")
    viewport.use_taa=false;DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED);Engine.max_fps=0
    RenderingServer.viewport_set_measure_render_time(viewport.get_viewport_rid(),true)
    for profile:Dictionary in fixture.buildings:
        var identity=str(profile.id)
        if identity not in IDS:continue
        for draw:MeshInstance3D in draws:draw.visible=str(draw.name).begins_with(identity+"__")
        view_direction=Vector3(.18,.12,1.).normalized() if str(profile.architecture.get("type",""))=="residential_front" else Vector3(1.,.12,.18).normalized()
        var box:AABB=bounds[identity];var center=box.get_center();camera.fov=75.
        camera.global_position=center+view_direction*box.size.length()*.5/sin(deg_to_rad(37.5))*1.25;camera.look_at(center)
        var family_rows:Array[Dictionary]=[]
        for spec:Dictionary in [{"id":"near","threshold":0.},{"id":"far","threshold":10000.},{"id":"natural","threshold":1.},{"id":"far_repeat","threshold":10000.},{"id":"near_repeat","threshold":0.}]:
            viewport.mesh_lod_threshold=float(spec.threshold)
            for frame in 12:await RenderingServer.frame_post_draw
            var samples:Array[Dictionary]=[];var previous=Time.get_ticks_usec()
            for frame in 90:
                await RenderingServer.frame_post_draw
                var now=Time.get_ticks_usec()
                var sample=_counters()
                sample.merge({"wall_ms":(now-previous)/1000.,"viewport_cpu_ms":RenderingServer.viewport_get_measured_render_time_cpu(viewport.get_viewport_rid()),"viewport_gpu_ms":RenderingServer.viewport_get_measured_render_time_gpu(viewport.get_viewport_rid())})
                samples.append(sample);previous=now
            var row:Dictionary={"building":identity,"id":spec.id,"threshold":spec.threshold,"samples":samples,"counters":_counters()}
            family_rows.append(row);observations.append(row)
            if str(spec.id) in ["near","far"]:check(viewport.get_texture().get_image().save_png(directory.path_join(identity+"_profile_"+str(spec.id)+".png"))==OK,"full-body image saved")
        check(int(family_rows[1].counters.visible_primitives)<int(family_rows[0].counters.visible_primitives),"visible full-body LOD index reduction "+identity)
        transitions[identity]=await _profile_natural(horizon,camera,draws,identity,str(profile.wall_key),directory)
    check(transitions.size()==8,"all eight natural material-body transitions execute")
    viewport.mesh_lod_threshold=threshold;viewport.use_taa=taa;DisplayServer.window_set_vsync_mode(vsync);Engine.max_fps=cap
    check(sources==_sources(horizon),"all imported rendering/test sources frozen")
    var viewport_settings={"resolution":str(viewport.get_visible_rect().size),"timed_taa":false,"timed_vsync":"disabled","timed_max_fps":0,"msaa":viewport.msaa_3d,"lighting":"fixed isolated bench;not composed campaign light"}
    var retired=weakref(horizon);horizon.free();camera.free();sun.free();environment.free();await get_tree().physics_frame
    check(retired.get_ref()==null,"production passive family retires")
    var record:Dictionary={"schema_version":2,"evidence_kind":"runtime_contract","selector":"v2","production_runtime":true,"scope":"Eight isolated production-loader building bodies:imported UV/basis/derivatives,registered loaded PBR/mips,full-body forced LOD rendering andone material-body natural/narrow/return control each. No composed ground,player access,actors,saves,wholecity performance or artistic acceptance.","execution":{"completed":true,"exit_code":0 if failures.is_empty() else 1,"timed_out":false},"source":{"test_path":"game/"+get_script().resource_path.trim_prefix("res://"),"test_sha256":FileAccess.get_sha256(get_script().resource_path),"runtime_inputs_sha256":JSON.stringify(sources).sha256_text()},"contracts":{"production_family_loader":{"executed":true,"passed":selected==67 and bounds.size()==8},"loaded_surface_mapping":{"executed":true,"passed":metric_failures.is_empty()},"loaded_pbr_mipmaps":{"executed":maps.size()==67,"passed":failures.is_empty()},"rendered_replacement_lods":{"executed":observations.size()==40,"passed":failures.is_empty()},"natural_material_transitions":{"executed":transitions.size()==8,"passed":failures.is_empty()}},"checks":checks,"failures":failures,"source_hashes":sources,"loaded_materials":maps,"observations":observations,"natural_transitions":transitions,"settings":viewport_settings}
    var file=FileAccess.open(directory.path_join("houses_loaded.runtime.json"),FileAccess.WRITE)
    if file==null:push_error("Cannot write family receipt");get_tree().quit(1);return
    file.store_string(JSON.stringify(record,"\\t")+"\\n");file.close()
    print("HOUSES LOADED FAMILY: ",checks," checks; ",failures.size()," failures;8 buildings;67 parts")
    get_tree().quit(0 if failures.is_empty() else 1)
'''
base=(root/'game/tests/v2_city_horizon_bench.gd').read_text(encoding='utf-8')
start=base.index('func _profile_natural(')
method=base[start:].replace('var direction:=Vector3(1.,.12,.18).normalized()','var direction:=view_direction')
code+='\n'+method
path=folder/'bench.gd';assert not path.exists();path.write_text(code,encoding='utf-8',newline='\n')
scene='[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://tmp/city_houses_20261031/bench.gd" id="1"]\n\n[node name="CityHouseLoadedBench" type="Node"]\nscript = ExtResource("1")\n'
(folder/'Bench.tscn').write_text(scene,encoding='utf-8',newline='\n')
(out/'bench_01_executed_source.gd').write_bytes(path.read_bytes())
batch=[dict(scene='',log=str(out/'import_01.log'),runner='long',timeout=600,windowed=False,extra_args=['--editor','--import','--quit']),dict(scene='res://tmp/city_houses_20261031/Bench.tscn',log=str(out/'bench_01.log'),shot_dir=str(out/'bench_01'),runner='long',timeout=240,windowed=True,extra_args=['--script','res://tests/native_debug_window.gd','--fullscreen','--resolution','3440x1440'])]
(out/'batch_01.json').write_text(json.dumps(batch,indent=2),encoding='utf-8',newline='\n')
print('Bench prepared',len(code.splitlines()),'lines;production inputs unchanged')
