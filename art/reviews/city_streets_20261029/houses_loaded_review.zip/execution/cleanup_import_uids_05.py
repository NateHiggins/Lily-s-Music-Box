from pathlib import Path
import subprocess,json,hashlib,zipfile
root=Path('C:/ov/city').resolve();out=Path(__file__).parent
raw=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root)
paths=[p.decode('utf-8') for p in raw.split(b'\0') if p and p.decode('utf-8').endswith('.uid')]
assert len(paths)==638,('unexpected imported UID census;inspect before any delete',len(paths))
rows=[];backup=out/'generated_uid_backup_05.zip';assert not backup.exists()
with zipfile.ZipFile(backup,'x',zipfile.ZIP_DEFLATED) as z:
    for name in paths:
        path=(root/name).resolve();assert path.is_relative_to(root) and path.suffix=='.uid' and path.is_file()
        assert not subprocess.check_output(['git','ls-files','--',name],cwd=root).strip()
        raw=path.read_bytes();z.writestr(name,raw);rows.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
with zipfile.ZipFile(backup) as z:
    assert z.testzip() is None
    for row in rows:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
for row in rows:
    path=(root/row['path']).resolve();assert path.is_relative_to(root) and hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'];path.unlink()
(out/'generated_uid_cleanup_05.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Only638 untracked import-generated UID files removed inside isolated city tree after own engine terminal;verified byte-exact external backup retained. No tracked UID or canonical checkout touched.',backup=backup.name,backup_sha256=hashlib.sha256(backup.read_bytes()).hexdigest(),removed=rows),indent=2),encoding='utf-8',newline='\n')
print('Backed up and removed',len(rows),'untracked imported UIDs;no tracked file changed')
