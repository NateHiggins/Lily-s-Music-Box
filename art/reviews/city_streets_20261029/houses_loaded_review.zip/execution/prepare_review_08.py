from pathlib import Path
out=Path(__file__).parent
code=(out/'review_native_07.py').read_text(encoding='utf-8').replace('native_review_07','native_review_08')
old="+profile['grade_datum_m']"
new="+next(r['grade_datum_m'] for r in construction['buildings'] if r['id']==identity)"
assert code.count(old)==1
(out/'review_native_08.py').write_text(code.replace(old,new),encoding='utf-8',newline='\n')
runner=(out/'run_native_review_07.py').read_text(encoding='utf-8').replace('_07','_08')
(out/'run_native_review_08.py').write_text(runner,encoding='utf-8',newline='\n')
