from pathlib import Path
import json,statistics,hashlib
from PIL import Image,ImageDraw,ImageChops
out=Path(__file__).parent;folder=out/'bench_05';raw=(folder/'houses_loaded.runtime.json').read_bytes();data=json.loads(raw)
assert data['checks']==1660 and not data['failures'] and data['execution']['exit_code']==0
def describe(values):
    values=sorted(values);return dict(samples=len(values),median=statistics.median(values),p95=values[round((len(values)-1)*.95)],p99=values[round((len(values)-1)*.99)],maximum=max(values))
rows=[]
for case in data['observations']:
    row=dict(building=case['building'],case=case['id'],counters=case['counters'])
    for phase,key in [('transition','warmup_samples'),('warmed','samples')]:
        row[phase]={metric:describe([s[metric] for s in case[key]]) for metric in ['wall_ms','viewport_cpu_ms','viewport_gpu_ms']}
    rows.append(row)
record=dict(evidence_class='INERT',scope='Analysis of passed isolated family05. Not a matched improvement,whole-city performance budget or artistic acceptance.',runtime_receipt_sha256=hashlib.sha256(raw).hexdigest(),checks=data['checks'],failures=data['failures'],settings=data['settings'],rows=rows)
path=out/'loaded_05_analysis.json';assert not path.exists();path.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n')
ids=sorted(data['natural_transitions'])
sheet=Image.new('RGB',(1600,800),(35,35,35));draw=ImageDraw.Draw(sheet)
for i,path in enumerate(sorted(folder.glob('*profile*.png'))):
    img=Image.open(path);img.thumbnail((400,170));x=i%4*400;y=i//4*200;sheet.paste(img,(x,y));draw.text((x+3,y+174),path.stem.replace('HORIZON_',''),fill='white')
sheet.save(out/'loaded_05_profile_contact.png')
sheet=Image.new('RGB',(2000,1760),(35,35,35));draw=ImageDraw.Draw(sheet);bounds=[]
for row,identity in enumerate(ids):
    for col,phase in enumerate(['before','after','narrow','return']):
        target=folder/(identity+'_natural_'+phase+'.png');background=folder/(identity+'_natural_'+phase+'_background.png')
        a=Image.open(target).convert('RGB');b=Image.open(background).convert('RGB')
        diff=ImageChops.difference(a,b).convert('L').point(lambda v:255 if v>5 else 0);box=diff.getbbox();assert box,(identity,phase)
        box=(max(0,box[0]-8),max(0,box[1]-8),min(a.width,box[2]+8),min(a.height,box[3]+8))
        bounds.append(dict(target=target.name,background=background.name,crop=box))
        for offset,img in enumerate([a,b]):
            crop=img.crop(box);crop.thumbnail((245,190));x=col*500+offset*250;y=row*220
            sheet.paste(crop,(x+(250-crop.width)//2,y));draw.text((x+3,y+193),identity.replace('HORIZON_','')+' '+phase+(' hidden' if offset else ''),fill='white')
sheet.save(out/'loaded_05_natural_contact.png')
(out/'loaded_05_contact_crops.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Derived diagnostic crops for inspection only;80 original full-resolution captures unchanged.',records=bounds),indent=2),encoding='utf-8',newline='\n')
for phase,key in [('warmed','samples'),('transition','warmup_samples')]:
    print(phase,{metric:describe([s[metric] for c in data['observations'] for s in c[key]]) for metric in ['wall_ms','viewport_cpu_ms','viewport_gpu_ms']})
for identity in ids:
    near=next(c for c in data['observations'] if c['building']==identity and c['id']=='near');far=next(c for c in data['observations'] if c['building']==identity and c['id']=='far')
    print(identity,near['counters'],far['counters'],data['natural_transitions'][identity].get('selection'))
