from pathlib import Path
import json
root=Path('C:/ov/city');out=Path(__file__).parent;path=root/'game/tmp/city_houses_20261031/bench.gd'
code=path.read_text(encoding='utf-8').replace('var view_direction=Vector3','var view_direction:Vector3=Vector3')
code=code.replace('    var material_rows=_industrial_materials(horizon)','    var seat_result=_check_seats(fixture,horizon)\n    var catalog:Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://data/runtime_material_sets.json"))\n    var material_rows=_industrial_materials(horizon)')
code=code.replace('        check(not row.triplanar and row.maps.size()==3,"registered authored UV PBR binding "+name)','''        check(not row.triplanar and row.maps.size()==3,"registered authored UV PBR binding "+name)
        check(int(row.texture_filter) in [BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS,BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC],"actual mip-capable filter "+name)
        var registered:Dictionary=catalog.materials[name.split("__")[-1]]
        for index in 3:
            var channel:String=["albedo","roughness","normal"][index]
            check(str(row.maps[channel].path)=="res://assets/building/textures/"+str(registered.files[index]),"loaded map is exact registered substance "+name+"/"+channel)''')
code=code.replace('"mapping_failures":metric_failures,"source_hashes":sources','"mapping_failures":metric_failures,"collision_seats":seat_result,"source_hashes":sources')
seats='''func _seat_part(hit:Dictionary)->String:
    if hit.is_empty():return ""
    var draw=hit.collider.get_parent() as MeshInstance3D
    return str(draw.name) if draw!=null else ""

func _check_seats(fixture:Dictionary,horizon:Node3D)->Dictionary:
    var space=horizon.get_world_3d().direct_space_state;var panes=0;var roofs=0;var profiles:Dictionary={}
    for row:Dictionary in fixture.buildings:profiles[str(row.id)]=row
    for row:Dictionary in fixture.window_rows:
        if str(row.building) not in IDS:continue
        panes+=1;var p:Array=row.point;var n:Array=row.normal
        var point=Vector3(p[0],p[2],-p[1]);var normal=Vector3(n[0],n[2],-n[1]);var expected=point-normal*float(row.recess_m)
        var hit=space.intersect_ray(PhysicsRayQueryParameters3D.create(point+normal*.03,point-normal*.25,1))
        check(_seat_part(hit)==str(row.building)+"__mirror_aged" and hit.position.distance_to(expected)<.0001,"actual first-hit pane seating "+str(row.building))
    for row:Dictionary in fixture.parapet_contacts:
        if str(row.building) not in IDS:continue
        roofs+=1;var p:Array=row.point;var point=Vector3(p[0],p[2],-p[1])
        var query=PhysicsRayQueryParameters3D.create(point+Vector3.UP*.025,point-Vector3.UP*.025,1);query.hit_back_faces=false
        var hit=space.intersect_ray(query)
        check(_seat_part(hit)==str(row.building)+"__galvanized_roof" and hit.position.distance_to(point)<.0001,"actual roof top seating")
        var profile:Dictionary=profiles[str(row.building)]
        if str(profile.architecture.type)=="residential_front":
            var support=point;support.y=float(profile.grade_datum_m)
            var heights:Array=profile.architecture.floor_heights_m
            for index in (heights.size() if str(profile.architecture.style)=="italianate_2109" else heights.size()-1):support.y+=float(heights[index])
            query=PhysicsRayQueryParameters3D.create(support+Vector3.UP*.025,support-Vector3.UP*.025,1);query.hit_back_faces=false;hit=space.intersect_ray(query)
            check(_seat_part(hit)==str(row.building)+"__"+str(row.wall_key) and hit.position.distance_to(support)<.0001,"actual receiving wall/sheathing below roof sheet")
        else:
            query=PhysicsRayQueryParameters3D.create(point-Vector3.UP*.025,point+Vector3.UP*.025,1);query.hit_back_faces=false;hit=space.intersect_ray(query)
            check(_seat_part(hit)==str(row.building)+"__"+str(row.wall_key) and hit.position.distance_to(point)<.0001,"actual parapet/post underside meets roof")
        var a:Array=row.outside_probe;var outside=Vector3(a[0],a[2],-a[1])
        query=PhysicsRayQueryParameters3D.create(outside+Vector3.UP*.025,outside-Vector3.UP*.025,1);query.hit_back_faces=false;hit=space.intersect_ray(query)
        check(_seat_part(hit)!=str(row.building)+"__galvanized_roof","outside control is not own structural roof seat")
    check(panes==418 and roofs==37,"nonempty exact418 pane/37roof controls for eight buildings")
    return {"pane_samples":panes,"roof_controls":roofs,"frame":"actual unfiltered isolated production Horizon physics;no ground/player access claim"}

'''
code=code.replace('func _profile_natural(',seats+'func _profile_natural(',1)
path.write_text(code,encoding='utf-8',newline='\n');(out/'bench_03_executed_source.gd').write_bytes(path.read_bytes())
batch=json.loads((out/'batch_02.json').read_text())
for row in batch:
    row['log']=row['log'].replace('_02','_03')
    if 'shot_dir' in row:row['shot_dir']=row['shot_dir'].replace('_02','_03')
(out/'batch_03.json').write_text(json.dumps(batch,indent=2),encoding='utf-8',newline='\n')
