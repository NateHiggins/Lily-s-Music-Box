from pathlib import Path
import json
out=Path(__file__).parent
batch=json.loads((out/'batch_05.json').read_text())
assert len(batch)==2
target=out/'batch_import_and_05.json';assert not target.exists()
batch.insert(0,dict(scene='',log=str(out/'import_05.log'),runner='long',timeout=180,windowed=False,extra_args=['--editor','--import','--quit']))
target.write_text(json.dumps(batch,indent=2),encoding='utf-8',newline='\n')
