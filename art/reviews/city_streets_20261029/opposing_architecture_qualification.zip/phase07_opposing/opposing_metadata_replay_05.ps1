$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:/ov/city'
$cityBlender='C:/Program Files/Blender Foundation/Blender 5.2/blender.exe'
$cityEvidence='C:/ov/reports/city_streets_20261029'
$env:CITY_ELEVATIONS_REVIEW_DIR="$cityEvidence/opposing_batch_05"
New-Item -ItemType Directory -Path "$cityEvidence/opposing_batch_05/sources" -Force | Out-Null
foreach($citySource in @('art/blender/scripts/build_city_elevations.py','art/blender/scripts/build_city_elevation_lods.py','art/blender/scripts/city_commercial_architecture.py','art/data/city_elevations/source_plan.json','game/scripts/building/orison_v2_city_shells.gd')){
    $cityTarget=Join-Path "$cityEvidence/opposing_batch_05/sources" $citySource
    New-Item -ItemType Directory -Path (Split-Path -Parent $cityTarget) -Force | Out-Null
    Copy-Item -LiteralPath $citySource -Destination $cityTarget
}
function Invoke-CityNative([string]$name,[string]$script){
    $cityLog="$cityEvidence/$name.log"
    if(Test-Path -LiteralPath $cityLog){throw "Preserve original log: $cityLog"}
    $cityStarted=[DateTime]::UtcNow.ToString('o')
    & $cityBlender --background -t 2 --python-exit-code 1 --python $script *> $cityLog
    $cityExit=$LASTEXITCODE
    [ordered]@{evidence_class='INERT';script=$script;started_utc=$cityStarted;finished_utc=[DateTime]::UtcNow.ToString('o');exit_code=$cityExit;threads=2} | ConvertTo-Json | Set-Content -Encoding utf8 "$cityEvidence/$name.execution.json"
    if($cityExit -ne 0){throw "$name failed; original output retained"}
    Write-Output "$name PASS"
}
$env:CITY_ELEVATIONS_SKIP_OVERVIEW_RENDERS='1'
Invoke-CityNative 'opposing_elevations_05' 'art/blender/scripts/build_city_elevations.py'
Invoke-CityNative 'opposing_lods_05' 'art/blender/scripts/build_city_elevation_lods.py'
Invoke-CityNative 'opposing_streets_replay_05' 'art/blender/scripts/build_city_streets.py'
