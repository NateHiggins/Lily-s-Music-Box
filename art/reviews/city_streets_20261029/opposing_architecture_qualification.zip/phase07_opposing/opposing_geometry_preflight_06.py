from pathlib import Path
import hashlib,json,shutil
ROOT=Path('C:/ov/city');OUT=Path('C:/ov/reports/city_streets_20261029/opposing_geometry_preflight_06')
source=ROOT/'art/blender/scripts/build_city_elevation_lods.py'
text=source.read_text(encoding='utf-8');sentinel="raw=(ROOT/'game/assets/props/city_elevations.glb').read_bytes()"
assert text.count(sentinel)==1
for name in ['art/blender/scripts/city_commercial_architecture.py','art/blender/scripts/build_city_elevations.py','art/blender/scripts/build_city_elevation_lods.py','art/data/city_elevations/source_plan.json']:
 target=OUT/'sources'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target)
namespace={'__file__':str(source),'__name__':'__native_geometry_diagnostic__'}
exec(compile(text.split(sentinel)[0],str(source),'exec'),namespace)
report={'evidence_class':'INERT','scope':'Exact existing lower-producer closed-stock, signed-volume, retained roof-bearing and actual-pane checks before export. No production file written, no rendered or runtime acceptance.','closed_stocks':len(namespace['stocks']),'bearing_samples':namespace['bearings'],'pane_samples':namespace['panes'],'parts':len(namespace['buffers']),'failures':[]}
(OUT/'result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n');print('OPPOSING_GEOMETRY_PREFLIGHT',json.dumps(report),flush=True)
