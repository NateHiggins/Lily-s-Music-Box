"""Bounded source-geometry diagnostic; no export/render/runtime acceptance."""
import sys,json,math,collections,hashlib
from pathlib import Path
import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree

root=Path('C:/ov/city');out=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'art/blender/scripts'))
from city_residential_architecture import SouthGardenApartments
from city_horizon_geometry import building_outline,extrusion
from city_ground_apron_geometry import relief_height
plan=json.loads((root/'art/data/city_horizon/source_plan.json').read_text())
grade=json.loads((root/'art/blender/city_ground_apron_construction.json').read_text())
ids=['HORIZON_NEAR_3_3_P1','HORIZON_NEAR_3_3_P2']
for row in plan['buildings']:
    outline=building_outline(row);samples=[(x,-y) for x,y in outline]
    study=row.get('architecture',{})
    if 'front_apron_rect_m' in study:
        a,b,c,d=study['front_apron_rect_m'];samples.extend([(a,b),(a,d),(c,b),(c,d)])
    if study.get('style') in SouthGardenApartments.STYLES:
        for a,b,c,d in study['court_paving_m']:samples.extend([(a,b),(a,d),(c,b),(c,d)])
    for p,q in zip(outline,outline[1:]+outline[:1]):
        if abs(q[0]-p[0])<1e-12:continue
        for x,_ in grade['relief']['west_profile']:
            t=(x-p[0])/(q[0]-p[0])
            if 0<t<1:samples.append((x,-(p[1]+t*(q[1]-p[1]))))
    heights=[relief_height(x,z,-.02,grade['relief']) for x,z in samples]
    row['grade_datum_m']=max(heights)+.02;row['grade_low_m']=min(heights)

records=[]
for lower in [False,True]:
    for row in [r for r in plan['buildings'] if r['id'] in ids]:
        vertices=[];faces=[];keys=[]
        def emit(owner,key,vv,ff):
            assert owner==row['id'];n=len(vertices)
            vertices.extend(Vector(p) for p in vv)
            faces.extend(tuple(n+i for i in f) for f in ff);keys.extend([key]*len(ff))
        result=SouthGardenApartments(row,emit,[r for r in plan['buildings'] if r['id']!=row['id']],lower=lower).build()
        a,b,c,d=row['architecture']['front_apron_rect_m']
        vv,ff=extrusion([(c,-d),(a,-d),(a,-b),(c,-b)],-.12,0.)
        emit(row['id'],'concrete',vv,ff)
        tree=BVHTree.FromPolygons(vertices,faces)
        for window in result['windows']:
            point=Vector(window['point']);normal=Vector(window['normal'])
            hit,_,index,_=tree.ray_cast(point+normal*.03,-normal,.30)
            assert hit is not None and keys[index]=='mirror_aged' and (hit-(point-normal*window['recess_m'])).length<.0001,('pane',lower,window,keys[index] if index is not None else None)
        ray_checks=[]
        if row['id'].endswith('P2'):
            middle=-(row['rect'][1]+row['rect'][3])/2
            # Clear whole front-to-court axial path at capsule-width witnesses,
            # including the height of the split raised floor and its bands.
            for lateral in [-.32,0.,.32]:
                for height in [.10,.75,.80,1.30,1.80]:
                    hit,_,index,_=tree.ray_cast(Vector((150.4,middle+lateral,height)),Vector((1,0,0)),19.0)
                    assert hit is None,('blocked public vault',lower,lateral,height,keys[index] if index is not None else None,hit)
                    ray_checks.append('clear passage capsule-width/height witness')
            for lateral in [-1.26,1.26]:
                hit,_,index,_=tree.ray_cast(Vector((150.4,middle+lateral,1.5)),Vector((1,0,0)),9.)
                assert hit is not None,('wall negative missed',lower,lateral)
                ray_checks.append('outside aperture rejects passage')
            hit,_,index,_=tree.ray_cast(Vector((155.5,middle,1.8)),Vector((0,0,1)),3.)
            assert hit is not None and keys[index]=='limewash_plaster' and abs(hit.z-3.25)<.0001,('actual vault soffit',lower,hit,keys[index] if index is not None else None)
            ray_checks.append('actual vaulted soffit')
            for x in [159.,163.,168.5]:
                hit,_,index,_=tree.ray_cast(Vector((x,middle,25.)),Vector((0,0,-1)),30.)
                assert hit is not None and keys[index]=='concrete' and abs(hit.z)<.0001,('court roof bridge',lower,x,hit,keys[index] if index is not None else None)
                ray_checks.append('court open to sky with paved floor')
            for i in range(181):
                x=150.4+i*.1
                for lateral in [-.32,.32]:
                    hit,_,index,_=tree.ray_cast(Vector((x,middle+lateral,.4)),Vector((0,0,-1)),.6)
                    assert hit is not None and abs(hit.z)<.0001,('continuous authored path',lower,x,lateral,hit)
                    ray_checks.append('continuous floor across apron/portal/court')
        records.append({'building':row['id'],'lower':lower,'closed_stocks':result['closed_stocks'],'minimum_stock_volume_m3':result['min_closed_stock_volume_m3'],'vertices':len(vertices),'polygons':len(faces),'pane_first_hits':len(result['windows']),'entries':result['entries'],'path_ray_checks':len(ray_checks),'bounds':[min(v[i] for v in vertices) for i in range(3)]+[max(v[i] for v in vertices) for i in range(3)]})
        print('SOUTH PAIR SOURCE FIT',records[-1],flush=True)
record={'evidence_class':'INERT','scope':'Raw authored near/lower source stocks and native BVH rays only; no strict export, UV/PBR, rendered appearance, Godot collision or played-support acceptance. Actual surrounding native context still pending.','records':records,'failures':[],'source_bindings':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in [root/'art/data/city_horizon/source_plan.json',root/'art/blender/scripts/city_residential_architecture.py',root/'art/blender/scripts/build_city_horizon.py']}}
(out/'native_fit_01.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print('SOUTH PAIR SOURCE FIT COMPLETE',flush=True)
