"""Package existing qualified evidence; never fabricate or repin test proof."""
from pathlib import Path
import hashlib,json,sys,zipfile
ROOT=Path('C:/ov/city');W=Path(__file__).parent
sys.path.insert(0,str(ROOT/'tools'))
from v2_surface_evidence import qualify,PACKET
assert qualify(PACKET,ROOT)['result']=='PASS'
world=W/'world_01'
access=json.loads((world/'south_garden_access.runtime.json').read_text(encoding='utf-8'))
assert access['schema_version']==2 and access['evidence_kind']=='runtime_contract'
assert access['execution']['completed'] and access['execution']['exit_code']==0 and access['failures']==0
assert access['programme']['passed'] and len(access['programme']['legs'])==14 and len(access['programme']['endpoints'])==6
assert all(r['reached'] and r['unsupported_samples']==0 and r['bad_flat_samples']==0 for r in access['programme']['legs'])
assert len(access['optical_views'])==4
review=json.loads((W/'world_visual_review_01.json').read_text(encoding='utf-8'))
assert review['evidence_class']=='INERT' and review['all_frames_individually_inspected']
actual={p.name for p in world.glob('*.png')}
assert actual=={r['file'] for r in review['images']}
for r in review['images']:
 assert r['individually_inspected'] and hashlib.sha256((world/r['file']).read_bytes()).hexdigest()==r['sha256']
published={r['file'] for r in json.loads((PACKET/'visual_review.json').read_text(encoding='utf-8'))['images']}
paths={p for p in W.iterdir() if p.is_file() and p.suffix in {'.json','.log','.stderr','.py','.gd','.tscn'}}
for sub in ['native_review_01','family_01','grade_01','board_before_world_01','static_before_world_02','static_final_01']:
 paths.update(p for p in (W/sub).glob('*') if p.is_file() and p.suffix in {'.png','.json','.md'})
paths.update(world/n for n in ['south_garden_access.runtime.json','grade_owners.json'])
# Published captures/inventory remain with the independently qualified canonical packet.
# Keep the additional local route/hidden frames here without duplicating published images.
paths.update(p for p in world.glob('*.png') if 'HORIZON_NEAR_3_3_P' in p.name and p.name not in published)
for sub in ['before_grade_refresh_01']:
 paths.update(p for p in (W/sub).rglob('*.json') if p.name!='native_sources.json')
# Backup/current binaries and cached primary-source photographs are not duplicated.
archive=ROOT/'art/reviews/city_streets_20261029/western_south_garden_review.zip'
assert not archive.exists()
manifest=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(paths):
  raw=p.read_bytes();name=p.relative_to(W).as_posix();z.writestr(name,raw);manifest.append({'file':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 z.writestr('CONTENTS.json',json.dumps({'evidence_class':'INERT','scope':'Actual native,loaded family,grade discovery and composed qualification;original failures and source versions retained. Technical evidence does not grant artistic or fullcity acceptance. Canonical physical packet is the separate installed authority.','files':manifest},indent=2)+'\n')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'archive':archive.relative_to(ROOT).as_posix(),'members':len(manifest)+1,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
