"""Read-only native GLB framing/occlusion proposal; no engine/render acceptance."""
from pathlib import Path
import json,struct,hashlib,sys
import numpy as np
R=Path('C:/ov/city');W=Path(__file__).parent
fixture=json.loads((R/'game/tests/fixtures/orison_city_horizon.json').read_bytes())
grade=json.loads((W/'grade_01/grade_owners.json').read_bytes())
assert grade['failures']==0 and len(grade['records'])==571
sys.path.insert(0,str(R/'tools'));from run_receipt import runtime_inputs_sha256
assert runtime_inputs_sha256(R)==grade['source']['runtime_inputs_sha256']
city=grade['poses']['city'];CB=np.array([city[k] for k in ['x_axis','y_axis','z_axis']]).T;CT=np.array(city['origin'])
fit=np.vstack([CB.T,CT]) # Diagnostic only;actual Godot horizon.to_global is authoritative.
bindings={};parts={}
def read_glb(rel,kind='horizon'):
    path=R/rel;raw=path.read_bytes();bindings[rel]=hashlib.sha256(raw).hexdigest();size=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+size]);binary=raw[28+size:]
    def acc(i):
        a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];dt=np.dtype({5121:'u1',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']]);return np.ndarray((a['count'],n),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',n*dt.itemsize),dt.itemsize)).astype(float)
    offsets={}
    if kind=='city':
        f=json.loads((R/'game/data/orison_v2/exterior/city_elevations.json').read_bytes())
        for row in f['buildings']:
            x,y,z=row.get('assembly_translation_m',[0,0,0]);offsets[row['id']]=np.array([x,z,-y])
    for node in d['nodes']:
        if 'mesh' not in node:continue
        assert not any(k in node for k in ['children','matrix','rotation','scale']),node['name']
        at=np.array(node.get('translation',[0,0,0]));tri=[]
        for p in d['meshes'][node['mesh']]['primitives']:
            pos=acc(p['attributes']['POSITION'])+at
            if kind=='city':
                names=[k for k in offsets if node['name']==k or node['name'].startswith(k+'_')];assert len(names)<=1
                pos=(pos+(offsets[names[0]] if names else 0))@CB.T+CT
            elif kind in ['street','transport']:pos=pos@CB.T+CT
            elif kind=='bridge':
                data=json.loads((R/'game/data/orison_v2/exterior/city_bridge.json').read_bytes());az=np.radians(data['eastbound_azimuth_deg']);direction=np.array([np.sin(az),0.,-np.cos(az)]);B=np.column_stack([direction,[0,1,0],np.cross(direction,[0,1,0])]);q=data['queens_source_xy_m'];T=np.array([q[0],data['water_scene_y_m'],-q[1]])-direction*data['main_length_m'];pos=(pos@B.T+T)@CB.T+CT
            tri.append(pos[acc(p['indices']).astype(int).reshape(-1,3)])
        t=np.concatenate(tri);lo=t.min((0,1));hi=t.max((0,1))
        # All proposed camera segments and subjects lie in this finite corridor.
        if np.any(hi<np.array([120,-5,90])) or np.any(lo>np.array([200,40,170])):continue
        n=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);length=np.linalg.norm(n,axis=1);assert np.all(length>1e-12)
        parts[node['name']]=dict(tri=t,center=t.mean(1),normal=n/length[:,None],area=length/2,lo=lo,hi=hi)
for a in fixture['assets'].values():
    if a['role']=='body_lod':continue
    b=a['bounds']
    if b[3]<120 or b[0]>200 or b[5]<90 or b[2]>170:continue
    read_glb(a['asset'])
read_glb('game/assets/props/city_elevations.glb','city')
read_glb('game/assets/props/city_streets.glb','street')
read_glb('game/assets/props/city_transport.glb','transport')
read_glb('game/assets/props/city_bridge.glb','bridge')
def hit(eye,point):
    delta=point-eye;length=np.linalg.norm(delta);direction=delta/length;best=length+.002;owner=None
    for name,p in parts.items():
        if np.any(p['hi']<np.minimum(eye,point)-.002) or np.any(p['lo']>np.maximum(eye,point)+.002):continue
        t=p['tri'];e=t[:,1]-t[:,0];f=t[:,2]-t[:,0];h=np.cross(direction,f);det=np.einsum('ij,ij->i',e,h);mask=abs(det)>1e-10
        inv=np.divide(1,det,out=np.zeros_like(det),where=mask);s=eye-t[:,0];u=inv*np.einsum('ij,ij->i',s,h);q=np.cross(s,e);v=inv*(q@direction);distance=inv*np.einsum('ij,ij->i',f,q)
        okay=mask&(u>=-1e-8)&(v>=-1e-8)&(u+v<=1+1e-8)&(distance>.01)&(distance<best)
        if np.any(okay):best=float(distance[okay].min());owner=name
    return owner,best
def project(eye,target,points,fov):
    forward=(target-eye);forward/=np.linalg.norm(forward);right=np.cross(forward,[0,1,0]);right/=np.linalg.norm(right);up=np.cross(right,forward);v=points-eye;depth=v@forward;scale=np.tan(np.radians(fov/2));return np.stack([.5+(v@right)/(depth*scale*(3440/1440))*0.5,.5-(v@up)/(depth*scale)*.5],1),depth
stations=[]
for identity in ['HORIZON_NEAR_3_3_P1','HORIZON_NEAR_3_3_P2']:
    row=next(r for r in fixture['buildings'] if r['id']==identity);draws={n:p for n,p in parts.items() if n.startswith(identity+'__')};assert len(draws)==(10 if identity.endswith('P1') else 11)
    lo=np.min([p['lo'] for p in draws.values()],0);hi=np.max([p['hi'] for p in draws.values()],0);center=(lo+hi)/2;outline=row['architecture']['outline_m'];side=row['architecture']['entry_sides'][0];a,b=np.array(outline[side]),np.array(outline[(side+1)%len(outline)]);edge=b-a;front_n=np.array([edge[1],0,-edge[0]])/np.linalg.norm(edge);assert np.dot(front_n,[-1,0,0])>.99
    corners=np.array([[x,y,z] for x in [lo[0],hi[0]] for y in [lo[1],hi[1]] for z in [lo[2],hi[2]]])
    for scope in ['front_roof','rear_court_roof']:
        eye=np.array([float(a[0])-18,hi[1]+5,center[2]-3]) if scope=='front_roof' else np.array([hi[0]+14,hi[1]+5,center[2]+3]);target=center.copy();fov=50.
        # Only adjust framing;never move blockers or target geometry.
        for _ in range(30):
            xy,depth=project(eye,target,corners,fov)
            if np.all(depth>0) and np.all(xy>=.06) and np.all(xy<=.94):break
            eye=target+(eye-target)*1.06
        else:raise AssertionError('Could not fit whole body')
        witnesses=[]
        keys=['arcade_brick_bond','galvanized_roof' if identity.endswith('P1') else 'city_slate'] if scope=='front_roof' else ['concrete','arcade_brick_bond','galvanized_roof' if identity.endswith('P1') else 'city_slate']
        for key in keys:
            name=identity+'__'+key;p=draws[name];toeye=eye-p['center'];toeye/=np.linalg.norm(toeye,axis=1)[:,None];mask=(p['area']>.12)&(np.einsum('ij,ij->i',p['normal'],toeye)>.25)
            if key=='arcade_brick_bond':mask&=(p['normal'][:,0]<-.99 if scope=='front_roof' else p['normal'][:,0]>.99)
            if key=='concrete':mask&=(p['normal'][:,1]>.99)&(p['center'][:,0]>159.5)&(abs(p['center'][:,2]-center[2])<3.8)
            candidates=np.where(mask)[0];chosen=[]
            # Broad stock,spread across the actual represented faces.
            for k in sorted(candidates,key=lambda j:-p['area'][j]):
                point=p['center'][k];uv,dep=project(eye,target,point[None,:],fov)
                if np.any(uv<.07) or np.any(uv>.93) or (chosen and min(np.linalg.norm(point-q) for q in chosen)<2.):continue
                owner,distance=hit(eye,point)
                if owner!=name or abs(distance-np.linalg.norm(eye-point))>.0001:continue
                chosen.append(point);witnesses.append(dict(draw=name,point=point.tolist(),normal=p['normal'][k].tolist(),triangle_index=int(k),source_first_hit=owner,area_m2=float(p['area'][k])))
                if len(chosen)==(4 if key in ['concrete','arcade_brick_bond'] else 2):break
            assert len(chosen)>=2,(identity,scope,key,len(chosen))
        stations.append(dict(id=identity+'_'+scope,building=identity,scope=scope,eye_local=eye.tolist(),target_local=target.tolist(),eye_world=(np.r_[eye,1]@fit).tolist(),target_world=(np.r_[target,1]@fit).tolist(),fov_vertical_deg=fov,bounds_local=list(lo)+list(hi),draws=sorted(draws),frame_uv_min=xy.min(0).tolist(),frame_uv_max=xy.max(0).tolist(),witnesses=witnesses,played_support_claim=False))
result=dict(evidence_class='INERT',scope='Read-only native mesh/installed-frame proposal;CPU triangle first-hit checks include nearby horizon,placed city elevations,streets,transport andrigidly placed bridge only. Actual production-world physics visibility/rendering and artistic acceptance still pending. Posed camera makes no player/support claim.',starting_sha='73fcf097bf7ba38495928ebbc2f0d32005c67823',runtime_inputs_sha256=grade['source']['runtime_inputs_sha256'],source_to_world_affine_rows=fit.tolist(),source_bindings=bindings,occluder_draws=len(parts),stations=stations,legacy_error=[dict(building=i,legacy_target_z=-float((r['rect'][1]+r['rect'][3])/2),actual_center_z=float((r['rect'][1]+r['rect'][3])/2)) for i in ['HORIZON_NEAR_3_3_P1','HORIZON_NEAR_3_3_P2'] for r in fixture['buildings'] if r['id']==i])
out=W/'camera_station_proposal_01.json';assert not out.exists();out.write_text(json.dumps(result,indent=2),encoding='utf-8',newline='\n');print(json.dumps({k:result[k] for k in ['occluder_draws','legacy_error']},indent=2));print([(s['id'],s['eye_local'],s['target_local'],len(s['witnesses'])) for s in stations])
