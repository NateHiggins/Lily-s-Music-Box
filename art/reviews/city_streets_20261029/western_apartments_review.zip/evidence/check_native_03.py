from pathlib import Path
import ast,subprocess,json,hashlib,sys
root=Path('C:/ov/city');w=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
    p=w/name;assert not p.exists();p.write_text(json.dumps(data,indent=2),encoding='utf-8',newline='\n')
baseline=json.loads((w/'asset_baseline_01.json').read_bytes())
fixture=json.loads((root/'game/tests/fixtures/orison_city_horizon.json').read_bytes())
assert set(fixture['assets'])==set(baseline['assets'])
changed=[k for k,v in baseline['assets'].items() if sha(root/v['asset'])!=v['sha256']]
assert set(changed)=={'city_horizon_near_3_2','city_horizon_near_3_2_lod1'},changed
src='art/blender/scripts/city_residential_architecture.py'
old=ast.parse(subprocess.check_output(['git','show',baseline['start_sha']+':'+src],cwd=root).decode())
new=ast.parse((root/src).read_bytes())
classes={n.name:ast.dump(n) for n in new.body if isinstance(n,ast.ClassDef)}
retained=[n.name for n in old.body if isinstance(n,ast.ClassDef)]
for n in old.body:
    if isinstance(n,ast.ClassDef):assert ast.dump(n)==classes[n.name],n.name
plan=json.loads((root/'art/data/city_horizon/source_plan.json').read_bytes())
prior=json.loads((w/'source_plan_before.json').read_bytes())
assert [(r['id'],r['rect']) for r in plan['buildings']]==[(r['id'],r['rect']) for r in prior['buildings']]
targets={'HORIZON_NEAR_3_2_P1','HORIZON_NEAR_3_2_P2'}
assert [r for r in plan['buildings'] if r['id'] not in targets]==[r for r in prior['buildings'] if r['id'] not in targets]
# Restore serialization-only churn only after all unchanged exports are proved.
far='art/blender/city_horizon_far.blend'
far_bytes=subprocess.check_output(['git','show',baseline['start_sha']+':'+far],cwd=root)
(root/far).write_bytes(far_bytes);far_sha=sha(root/far)
for name in ['art/blender/city_horizon_construction.json','game/tests/fixtures/orison_city_horizon.json']:
    p=root/name;d=json.loads(p.read_bytes())
    for a in d['assets'].values():
        if a['native']==far:a['native_sha256']=far_sha
    p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
write('export_preservation_03.json',dict(evidence_class='INERT',baseline=baseline['start_sha'],unchanged_exports=33,changed_exports=changed,new_or_deleted_exports=0,retained_classes_exact=retained,unchanged_other_source_profiles=122,ordered_parcel_reservations=124,restored_far_native_sha256=far_sha))
source=Path('C:/ov/reports/city_streets_20261029/western_frontage_01/check_partition_preservation_04.py')
tree=ast.parse(source.read_bytes());namespace={}
exec(compile(ast.Module(body=[n for n in tree.body if (isinstance(n,(ast.Import,ast.ImportFrom)) and n.lineno<6) or (isinstance(n,ast.FunctionDef) and n.name=='load')],type_ignores=[]),str(source),'exec'),namespace)
load=namespace['load']
class GitFile:
    def __init__(self,path):self.path=path
    def read_bytes(self):return subprocess.check_output(['git','show',baseline['start_sha']+':'+self.path],cwd=root)
proof=[];addition=[]
for key in changed:
    rel=fixture['assets'][key]['asset'];a=load(GitFile(rel));b=load(root/rel);pre=load(w/'pre_flue_assets'/Path(rel).name)
    assert set(pre)==set(b)
    for name,p in a.items():
        if name.split('__')[0] in targets:continue
        assert p==b[name],name
        proof.append(dict(asset=key,part=name,all_corner_attributes_material_and_frame_exact=True))
    before=load(w/'post_flue_assets'/Path(rel).name)
    for name,p in before.items():
        if name.split('__')[0]=='HORIZON_NEAR_3_2_P1':
            assert p==b[name],name
            addition.append(dict(asset=key,part=name,Chateau_exact_after_Towers_plinth_repair=True))
assert len(proof)==56
write('retained_partition_proof_03.json',dict(evidence_class='INERT',scope='Winding-preserving cyclic full triangle corners POSITION/NORMAL/TANGENT/UV plus material slots and part pose.33 unchanged GLBs and56 retained old-house partitions. Earlier optical review reused only for exact retained geometry; corrected Towers needs separate four-view optical review.',retained=proof,unchanged_Chateau_after_plinth_repair=addition))
sys.path.insert(0,str(root/'art/blender/scripts'));from check_exported_tangents import validate
checks=[validate(root/fixture['assets'][k]['asset']) for k in changed]
write('uv_audit_03.json',dict(evidence_class='INERT',scope='Raw float32 export UV/normal/tangent derivatives only; not loaded or runtime qualification',results=checks))
print('PASS:33 byte-exact GLBs;56 retained partitions;all Chateau partitions exact across Towers-only plinth repair;124 reservations/122 other profiles unchanged;UV audit',[(r['triangles'],r['minimum_tangent_agreement']) for r in checks])
