from pathlib import Path
import subprocess,os,json,time
root=Path('C:/ov/city');out=Path(__file__).parent;env=os.environ.copy()
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:env[key]='2'
assert not (out/'native_review_execution_03.json').exists();started=time.time();timed_out=False
with (out/'native_review_03.log').open('xb') as log:
    process=subprocess.Popen(['C:/Program Files/Blender Foundation/Blender 5.2/blender.exe','-b','-t','2','--python-exit-code','1','-P',str(out/'review_native_03.py')],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    print('OWNED BLENDER PID',process.pid,flush=True)
    (out/'native_review_process_03.json').write_text(json.dumps(dict(pid=process.pid,started_epoch=started,ceiling_s=900)),encoding='utf-8',newline='\n')
    try:code=process.wait(timeout=900)
    except subprocess.TimeoutExpired:timed_out=True;process.terminate();process.wait(timeout=15);code=124
record=dict(evidence_class='INERT',scope='Native assembly review execution;inspect actual review.json andimages separately.',pid=process.pid,exit_code=code,timed_out=timed_out,seconds=time.time()-started)
(out/'native_review_execution_03.json').write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n');print(record,flush=True);raise SystemExit(code)
