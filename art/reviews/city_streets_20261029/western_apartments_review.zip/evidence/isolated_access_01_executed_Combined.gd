extends "res://tmp/v2_city_western_apartments_01/Bench.gd"
const Programme=preload("res://tests/v2_city_western_apartments_programme.gd")
var directory:String
var access_captures:Array[String]=[]
func _ready()->void:call_deferred("run_combined")
func shot(label:String)->void:
    for frame in 4:await RenderingServer.frame_post_draw
    check(get_viewport().get_texture().get_image().save_png(directory.path_join(label+".png"))==OK,"standing isolated image")
    access_captures.append(label+".png")
func run_combined()->void:
    RealityState.persistence_enabled=false;RealityState.reset_campaign_for_tests();CampaignTime.set_frozen_for_tests(true)
    directory=OS.get_environment("SHOT_DIR")
    var begin_checks:int=checks
    var horizon=Horizon.new();add_child(horizon)
    var ground=preload("res://scripts/building/orison_v2_ground.gd").new();add_child(ground)
    var street_owner=Node3D.new();add_child(street_owner)
    var layout:Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://data/orison_v2_blockout.json"))
    var frame:Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://data/orison_v2/exterior/street_frame.json"))
    var shift:=0.
    for door:Dictionary in layout.doors:
        if str(door.id)=="F01_DOOR_06":shift=-(float(door.center[1])+float(frame.source_threshold_z))
    street_owner.transform=Transform3D(Basis(Vector3.UP,PI),Vector3(0,0,-shift))
    var street=preload("res://scripts/building/orison_v2_city_streets.gd").mount(street_owner)
    var actor=PlayerController.new();actor.position=Vector3(149.05,-1.82,12.5);add_child(actor)
    actor.set_physics_process(false);actor.set_lamp_enabled(false)
    var environment=WorldEnvironment.new();environment.environment=Environment.new()
    environment.environment.background_mode=Environment.BG_COLOR;environment.environment.background_color=Color(.32,.38,.44)
    environment.environment.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;environment.environment.ambient_light_energy=.7;add_child(environment)
    var sun=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-40,-25,0);sun.light_energy=2.8;add_child(sun)
    await get_tree().physics_frame;await get_tree().physics_frame
    var sources:Dictionary=_sources(horizon);sources.merge(_industrial_entry_sources(horizon,ground),true)
    for path:String in ["res://tests/v2_city_western_apartments_programme.gd","res://scripts/building/orison_v2_city_streets.gd","res://scripts/building/orison_v2_city_transport.gd","res://assets/props/city_streets.glb","res://assets/props/city_streets_lod1.glb","res://data/orison_v2/exterior/city_streets.json","res://data/orison_v2_blockout.json","res://data/orison_v2/exterior/street_frame.json"]:sources[path]=_profile_sha(path)
    var programme:Dictionary=await Programme.new().run_owners(actor,horizon,street,self)
    for path:String in sources:check(_profile_sha(path)==sources[path],"frozen isolated input "+path)
    var record:Dictionary={"schema_version":2,"evidence_kind":"runtime_contract","selector":"v2","production_runtime":true,"scope":"Isolated production horizon,ground,apron,street and PlayerController with the identical19leg apartment programme used by the composed fixture. Actual full-size input/collision,one initial placement,no rescue owner or synthetic floor. Not composed traffic,campaign,saves,450m or artistic acceptance.","execution":{"completed":true,"exit_code":0 if failures.is_empty() else 1,"timed_out":false},"source":{"test_path":"game/"+get_script().resource_path.trim_prefix("res://"),"test_sha256":FileAccess.get_sha256(get_script().resource_path),"runtime_inputs_sha256":JSON.stringify(sources).sha256_text()},"source_hashes":sources,"checks":checks-begin_checks,"failures":failures,"programme":programme,"captures":access_captures,"contracts":{"isolated_frontage_controller":{"executed":bool(programme.get("movement_attempted",false)),"passed":failures.is_empty() and bool(programme.get("passed",false))}}}
    var file:=FileAccess.open(directory.path_join("isolated_access.runtime.json"),FileAccess.WRITE)
    check(file!=null,"write isolated access contract")
    if file!=null:file.store_string(JSON.stringify(record,"\t"));file.close()
    actor.free();horizon.free();ground.free();street_owner.free();sun.free();environment.free()
    get_tree().quit(0 if failures.is_empty() else 1)
