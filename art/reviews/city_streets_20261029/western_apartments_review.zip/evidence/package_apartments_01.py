from pathlib import Path
import subprocess,json,hashlib,zipfile,gzip
root=Path('C:/ov/city');w=Path(__file__).parent
archive=root/'art/reviews/city_streets_20261029/western_apartments_review.zip'
assert not archive.exists()
def sha(raw):return hashlib.sha256(raw).hexdigest()
for name in ['native_build_03.json','native_review_execution_03.json']:
    d=json.loads((w/name).read_bytes());assert d['exit_code']==0 and not d['timed_out']
for name in ['family_02/western_apartments.runtime.json','isolated_access_02/isolated_access.runtime.json','world_01/western_apartments_composed.runtime.json','surfaces_01/runtime_contract.json']:
    d=json.loads((w/name).read_bytes());assert d['evidence_kind']=='runtime_contract' and d['schema_version']==2 and d['execution']['completed'] and d['execution']['exit_code']==0 and not d['failures']
assert json.loads((w/'surface_publication_01.json').read_bytes())['result']=='PASS'
assert json.loads((w/'grade_source_reconciliation_01.json').read_bytes())['runtime_boxes']==571
base='32f59b0a48e210d07fe21b50fe4530986081c121'
recovery={}
for p in sorted((w/'previous_surface_packet').iterdir()):
    if not p.is_file():continue
    relative='art/renders/orison_v2/surface_requirements_20261011/'+p.name.removesuffix('.gz') if p.name=='surface-inventory.json.gz' else 'art/renders/orison_v2/surface_requirements_20261011/'+p.name
    raw=gzip.decompress(p.read_bytes()) if p.name=='surface-inventory.json.gz' else p.read_bytes()
    original=subprocess.check_output(['git','show',base+':'+relative],cwd=root)
    assert raw==original,relative
    recovery[p.name]={'git_sha':base,'path':relative,'restored_raw_sha256':sha(raw),'external_preserved_path':str(p)}
(w/'previous_packet_git_recovery_01.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Publisher preserved predecessor externally. Every original byte is also recoverable from the immutable starting commit; avoid committing duplicate prior packet assets.', 'files':recovery},indent=2),encoding='utf-8',newline='\n')
prior={p.name:sha(p.read_bytes()) for p in archive.parent.glob('*.zip')}
selected=set(x['file'] for x in json.loads((w/'surfaces_01/visual_review.json').read_bytes())['images'])|{'dumbwaiter.png','watch_station.png'}
members={};omitted={}
def add(z,name,raw):z.writestr(name,raw);members[name]={'bytes':len(raw),'raw_sha256':sha(raw)}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(w.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts:continue
        rel=p.relative_to(w)
        skip=p.suffix in ['.pyc','.zip','.jpg','.glb'] or 'previous_surface_packet' in rel.parts or (rel.parts[0]=='surfaces_01' and p.suffix=='.png' and p.name not in selected)
        raw=p.read_bytes()
        if skip:omitted[rel.as_posix()]={'bytes':len(raw),'sha256':sha(raw),'reason':'Duplicate assets/montages or unselected intermediate frame; external originals remain. Prior packet is byte-exact recoverable from starting Git. Raw pre/post-flue GLBs remain external; exact executed native sources and proofs are archived.'};continue
        add(z,'evidence/'+rel.as_posix(),raw)
    changed=subprocess.check_output(['git','diff','--ignore-cr-at-eol','--name-only'],cwd=root,stderr=subprocess.DEVNULL).decode().splitlines()
    changed+=['game/tests/v2_city_western_apartments_programme.gd','game/tests/v2_city_western_apartments_review.gd','game/tests/V2CityWesternApartmentsReview.tscn']
    for rel in sorted(set(changed)):
        if rel.endswith(('.py','.gd','.tscn')):add(z,'executed_sources/'+rel,(root/rel).read_bytes())
    for p in sorted((root/'game/tmp/v2_city_western_apartments_01').iterdir()):
        if p.suffix in ['.gd','.tscn']:add(z,'isolated_instruments/'+p.name,p.read_bytes())
    fixture=json.loads((root/'game/tests/fixtures/orison_city_horizon.json').read_bytes())
    index={'evidence_class':'INERT','scope':'One Western apartment pair: native sources/review, loaded mapping/mips/full replacement LODs, isolated and composed19leg access, fresh571box discovery and actual physical-surface qualification. Original source/harness failures and first-import log loss are explicit. Full clean candidate verification/canonical intake remain pending; no whole-city,save,uncontended performance or artistic acceptance.','starting_sha':base,'members':members,'external_omissions':omitted,'current_generated_assets':{k:{'path':a['asset'],'sha256':sha((root/a['asset']).read_bytes())} for k,a in fixture['assets'].items()},'prior_archives_preserved':prior}
    z.writestr('index.json',json.dumps(index,indent=2))
with zipfile.ZipFile(archive) as z:
    for name,row in members.items():assert sha(z.read(name))==row['raw_sha256']
for name,h in prior.items():assert sha((archive.parent/name).read_bytes())==h
assert archive.stat().st_size<95_000_000,'Review packaging requires a smaller selected artifact,not an oversized push'
p=archive.parent/'manifest.json';manifest=json.loads(p.read_bytes());assert 'western_apartments_archive' not in manifest
manifest['western_apartments_archive']={'evidence_class':'INERT','archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'member_count':len(members)+1,'index':'index.json','prior_archives_preserved':len(prior),'scope':index['scope']}
p.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(manifest['western_apartments_archive'],indent=2))
