from pathlib import Path
import subprocess,os,json,time,hashlib,argparse
root=Path('C:/ov/city');out=Path(__file__).parent
parser=argparse.ArgumentParser();parser.add_argument('stage');parser.add_argument('script');parser.add_argument('--ceiling',type=int,default=600);parser.add_argument('extra',nargs=argparse.REMAINDER);args=parser.parse_args()
assert args.stage.replace('_','').isalnum();receipt=out/(args.stage+'.json');assert not receipt.exists()
script=(root/args.script).resolve();assert script.is_relative_to(root) and script.is_file()
paths=list(dict.fromkeys([script,root/'art/blender/scripts/city_residential_architecture.py',root/'art/blender/scripts/city_industrial_architecture.py',root/'art/blender/scripts/city_horizon_geometry.py',root/'art/data/city_horizon/source_plan.json',root/'art/blender/city_ground_apron_construction.json']))
bindings={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in paths}
for p in paths:(out/(args.stage+'_executed_'+p.relative_to(root).as_posix().replace('/','__'))).write_bytes(p.read_bytes())
env=os.environ.copy()
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:env[key]='2'
extra=args.extra
if extra and extra[0]=='--':extra=extra[1:]
command=['C:/Program Files/Blender Foundation/Blender 5.2/blender.exe','-b','-t','2','--python-exit-code','1','-P',str(script)]
if extra:command+=['--',*extra]
started=time.time();timed_out=False
with (out/(args.stage+'.log')).open('xb') as log:
    process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    (out/(args.stage+'_process.json')).write_text(json.dumps(dict(pid=process.pid,started_epoch=started,ceiling_s=args.ceiling),indent=2),encoding='utf-8',newline='\n');print('OWNED BLENDER',args.stage,'PID',process.pid,flush=True)
    try:code=process.wait(timeout=args.ceiling)
    except subprocess.TimeoutExpired:timed_out=True;process.terminate();process.wait(timeout=15);code=124
record=dict(evidence_class='INERT',scope='Native script execution only; inspect stage outputs and rendered/loaded proof separately.',pid=process.pid,exit_code=code,timed_out=timed_out,seconds=time.time()-started,source_sha256=bindings,command=command)
receipt.write_text(json.dumps(record,indent=2),encoding='utf-8',newline='\n');print(json.dumps(record),flush=True);raise SystemExit(code)
