# Gate board - 32f59b0a48e2

- commit `32f59b0a48e210d07fe21b50fe4530986081c121`
- tree `fe0b0d65f2229882e92ef8c28acbd7f4792be483`
- created 2026-11-01T19:49:50Z
- dirty paths: 15

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| spatial | PASS | 0 | 50.19 | no defects counted |
| test:test_city_closure_source | PASS | 0 | 2.59 | ran 5, failed 0 |
| test:test_city_ground_apron | PASS | 0 | 18.34 | ran 25, failed 0 |
| test:test_city_horizon | FAIL | 1 | 2.14 | ran 4, failed 1 |
| test:test_city_horizon_shards | PASS | 0 | 1.78 | ran 8, failed 0 |
| test:test_city_street_geometry | PASS | 0 | 1.92 | ran 3, failed 0 |
