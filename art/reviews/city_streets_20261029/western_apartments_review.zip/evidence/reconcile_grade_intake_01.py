"""Refresh actual discoveries only after exact consumed-mask comparisons."""
from pathlib import Path
import collections, hashlib, json, re, sys
ROOT=Path('C:/ov/city'); HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT/'tools'))
from run_receipt import runtime_inputs_sha256
from grade_source_snapshot import validate
PLAN='art/data/orison_ground/retained_grade_source.json'
SURVEY='art/data/orison_ground/discovery/runtime_survey.json'
NATIVE='art/data/orison_ground/discovery/native_sources.json'
FOUND='art/blender/city_foundations_construction.json'
FIXTURE='game/tests/fixtures/orison_city_foundations_construction.json'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def digest(path):
    raw=path.read_bytes();return sha(raw if path.suffix in ('.blend','.glb','.bin','.png') else raw.replace(b'\r\n',b'\n'))
def encoded(data):return (json.dumps(data,indent=2,ensure_ascii=True)+'\n').encode()
original={p:(ROOT/p).read_bytes() for p in (PLAN,SURVEY,NATIVE,FOUND,FIXTURE)}
backup=HERE/'before_grade_refresh_01'
if backup.exists():assert all((backup/p).read_bytes()==raw for p,raw in original.items())
for rel,raw in original.items():
    p=backup/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
plan=json.loads(original[PLAN]);old=json.loads(original[SURVEY])
fresh_path=HERE/'world_01/grade_owners.json';fresh=json.loads(fresh_path.read_bytes())
native_path=ROOT/NATIVE;native=json.loads(original[NATIVE])
contract=json.loads((HERE/'world_01/western_apartments_composed.runtime.json').read_bytes())
assert contract['execution']['completed'] and contract['execution']['exit_code']==0 and contract['failures']==0
assert fresh['evidence_class']=='INERT' and fresh['failures']==0
assert fresh['source']['runtime_inputs_sha256']==runtime_inputs_sha256(ROOT)
assert old['poses']==fresh['poses']
normalize=lambda p:re.sub(r'(@[A-Za-z0-9_]+)@\d+',r'\1',p)
def groups(data):
    result=collections.defaultdict(list)
    for r in data['records']:
        result[(normalize(r['owner']),normalize(r['shape_owner']),r['shape_type'],r['aligned'])].append(tuple(r['bounds']))
    return {k:sorted(v) for k,v in result.items()}
assert len(old['records'])==len(fresh['records'])==571 and groups(old)==groups(fresh)
lookup={(r['owner'],r['id']):r for r in native['records']};checked=0;derived=0;runtime=0
for category in ('retained_solids','occupation_reservations','surface_exclusions'):
    for row in plan[category]:
        actual=lookup.get((row['owner'],row.get('id')))
        if actual:
            if category=='surface_exclusions' and row['owner']=='ServiceAlley' and row['kind']=='retained_paving_envelope':
                assert actual['kind']=='retained_continuous_paving_substrate'
                assert all(row['bounds'][i]==actual['bounds'][i] for i in (0,2,3,5))
                assert row['bounds'][1]==plan['soil_bottom'] and row['bounds'][4]==.05
                derived+=1
            else:assert row['kind']==actual['kind'] and row['bounds']==actual['bounds'],(category,row)
            checked+=1
        elif row['kind']=='actual_axis_aligned_box':
            matches=[r for r in fresh['records'] if r['owner']==row['owner'] and r['aligned'] and max(abs(x-y) for x,y in zip(r['bounds'],row['bounds']))<.00003]
            assert len(matches)==1,row
            runtime+=1
assert (checked,derived,runtime)==(9601,6,66),(checked,derived,runtime)
allowed=set() # All consumed native/classification inputs remain exact.
stale={p for p,h in plan['bindings'].items() if digest(ROOT/p)!=h}
assert stale==allowed,stale
for rel,h in native['bindings'].items():assert digest(ROOT/rel)==h,rel
for rel,h in fresh['source']['test_dependencies'].items():assert digest(ROOT/rel)==h,rel
mask_keys=['retained_solids','occupation_reservations','surface_exclusions','region','soil_bottom','asphalt_y','open']
mask_hash=sha(encoded({k:plan[k] for k in mask_keys}))
for rel in allowed:
    plan['bindings'][rel]=fresh['source']['test_dependencies'][rel] if rel=='game/tests/v2_grade_owner_survey.gd' else native['bindings'][rel]
plan['bindings'][SURVEY]=sha(fresh_path.read_bytes().replace(b'\r\n',b'\n'))
if NATIVE in plan['bindings']:plan['bindings'][NATIVE]=sha(native_path.read_bytes().replace(b'\r\n',b'\n'))
plan['method']+=' Western apartment pair: fresh actual571-owner discovery has exact retained geometric/registration projections,9601consumed native rows including6explicit paving depths and66actual runtime boxes. Both changed horizon bodies remain outside this native consumed region. Reuse14947native records only after checking40current inputs. No masks,soil geometry or historical snapshots are changed; original failure controls and source snapshots remain in western_apartments_01.'
assert sha(encoded({k:plan[k] for k in mask_keys}))==mask_hash
foundation=json.loads(original[FOUND]);assert original[FOUND]==original[FIXTURE]
placements={r['id']:r.get('assembly_translation_m',[0,0,0]) for r in json.loads((ROOT/'art/data/city_elevations/source_plan.json').read_bytes())['buildings']}
assert len(foundation['profiles'])==23
assert all(r['assembly_translation_m']==placements.get(r['id'].removesuffix('_base0'),[0,0,0]) for r in foundation['profiles'])
assert digest(ROOT/'game/assets/props/city_foundations.glb')==foundation['source_native_sha256']
for rel,h in foundation['bindings'].items():assert digest(ROOT/rel)==h,rel
plan_raw=encoded(plan);foundation['bindings'][PLAN]=sha(plan_raw)
try:
    (ROOT/SURVEY).write_bytes(fresh_path.read_bytes())
    assert (ROOT/NATIVE).read_bytes()==original[NATIVE] # Reuse unchanged classification; do not rewrite it.
    (ROOT/PLAN).write_bytes(plan_raw)
    validate(plan,ROOT)
    (ROOT/FOUND).write_bytes(encoded(foundation));(ROOT/FIXTURE).write_bytes(encoded(foundation))
except BaseException:
    for rel,raw in original.items():(ROOT/rel).write_bytes(raw)
    raise
report=dict(evidence_class='INERT',scope='Fresh actual discovery, exact consumed projection only; no changed masks/native geometry/runtime acceptance.',runtime_boxes=571,consumed_native_rows=checked,derived_paving_envelopes=derived,actual_box_projections=runtime,mask_payload_sha256=mask_hash,changed_bindings=sorted(allowed),reused_native_records=len(native['records']),reused_native_bindings=len(native['bindings']),foundation_placement_projections=23,updated_paths={p:dict(before_raw_sha256=sha(original[p]),after_raw_sha256=sha((ROOT/p).read_bytes())) for p in original})
(HERE/'grade_source_reconciliation_01.json').write_bytes(encoded(report))
print(json.dumps(report))
