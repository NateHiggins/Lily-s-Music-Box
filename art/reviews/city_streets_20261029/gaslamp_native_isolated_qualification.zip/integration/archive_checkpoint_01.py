"""Preserve original diagnostics without duplicating committed asset payloads."""
from pathlib import Path
import json,hashlib,zipfile
ROOT=Path('C:/ov/city');OUT=Path(__file__).resolve().parent
STUDY=OUT.parent/'gaslamp_lod_01'
REVIEW=ROOT/'art/reviews/city_streets_20261029'
ARCHIVE=REVIEW/'gaslamp_native_isolated_qualification.zip'
assert not ARCHIVE.exists()
members={}
def add(name,path,normalize=False):
    raw=path.read_bytes()
    if normalize:raw=raw.replace(b'\r\n',b'\n')
    assert name not in members
    members[name]=(raw,normalize)
for path in OUT.iterdir():
    if path.suffix in ['.json','.log','.stderr','.txt','.py'] and path.name!='spatial_01.json':
        add('integration/'+path.name,path)
for folder in ['native_review_01','bench_02','bench_03','bench_04','bench_05']:
    for path in (OUT/folder).iterdir():
        if path.suffix=='.json':add('integration/'+folder+'/'+path.name,path)
for path in (OUT/'native_review_01').glob('*.png'):add('integration/native_review_01/'+path.name,path)
for path in (OUT/'bench_02').glob('*.png'):add('original_compressed_failure/'+path.name,path)
for name in ['near.png','lower.png','near_repeat.png','lower_repeat.png']:
    add('integration/bench_03/'+name,OUT/'bench_03'/name)
for name in ['natural_before.png','natural_after.png','natural_narrow_recovery.png','natural_inward_return.png','head_day.png','head_night.png']:
    add('integration/bench_04/'+name,OUT/'bench_04'/name)
add('integration/bench_05/natural_narrow_recovery.png',OUT/'bench_05/natural_narrow_recovery.png')
for path in STUDY.iterdir():
    if path.suffix in ['.json','.log','.py','.png']:add('initial_native_study/'+path.name,path)
for relative in ['art/blender/scripts/build_v2_street_lamps.py','art/blender/scripts/review_v2_street_lamps.py','art/blender/v2_street_lamps_construction.json','art/tools/fix_v2_mesh_imports.py','game/data/orison_v2/exterior/street_lamps.json','game/scripts/building/orison_v2_street_lamps.gd','game/tests/orison_v2_street_lamps_shot.gd','game/assets/props/v2_street_lamps_lod1.glb.import']:
    add('project_source_lf/'+relative,ROOT/relative,normalize=True)
manifest={name:{'bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest(),'lf_normalized_source':normalized} for name,(raw,normalized) in members.items()}
with zipfile.ZipFile(ARCHIVE,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,(raw,_) in sorted(members.items()):z.writestr(name,raw)
with zipfile.ZipFile(ARCHIVE) as z:
    assert z.testzip() is None
    for name,spec in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==spec['raw_sha256']
record={'evidence_class':'INERT','checkpoint':'52828b7af038863fa195df6e9f72a23529b3f408',
        'archive':ARCHIVE.name,'archive_sha256':hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
        'archive_bytes':ARCHIVE.stat().st_size,'member_count':len(manifest),'members':manifest,
        'limits':'Original failures, native and isolated imported diagnostics only. No duplicated blend/glb/material-image assets. No schema-2 composed runtime/access/save, whole-city, budget or artistic acceptance grant.'}
path=REVIEW/'manifest.json';existing=json.loads(path.read_text(encoding='utf8'))
assert 'gaslamp_native_isolated_archive' not in existing
existing['gaslamp_native_isolated_archive']=record
path.write_text(json.dumps(existing,indent=2,ensure_ascii=False)+'\n',encoding='utf8',newline='\n')
(OUT/'archive_summary_01.json').write_text(json.dumps({k:v for k,v in record.items() if k!='members'},indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in record.items() if k!='members'}))
