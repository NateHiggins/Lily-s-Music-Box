from pathlib import Path
import json,struct,hashlib,sys,numpy as np
ROOT=Path('C:/ov/city');OUT=Path(__file__).resolve().parent
def parts(path):
    raw=path.read_bytes();chunks={};i=12
    while i<len(raw):
        n,k=struct.unpack_from('<II',raw,i);chunks[k]=raw[i+8:i+8+n];i+=8+n
    d=json.loads(chunks[0x4e4f534a]);binary=chunks[0x004e4942]
    def array(index):
        a=d['accessors'][index];v=d['bufferViews'][a['bufferView']]
        dt=np.dtype({5126:'<f4',5125:'<u4',5123:'<u2'}[a['componentType']]);w={'VEC2':2,'VEC3':3,'VEC4':4,'SCALAR':1}[a['type']]
        return np.ndarray((a['count'],w),dtype=dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',w*dt.itemsize),dt.itemsize))
    result={};metric=[]
    for mesh in d['meshes']:
        p=mesh['primitives'][0];attrs={k:array(v) for k,v in p['attributes'].items()};attrs['indices']=array(p['indices'])
        result[mesh['name']]={k:hashlib.sha256(v.tobytes()).hexdigest() for k,v in attrs.items()}
        idx=attrs['indices'].astype(int).reshape(-1,3);xyz=attrs['POSITION'][idx].astype(float);uv=attrs['TEXCOORD_0'][idx].astype(float)
        errors=[]
        for i,j in [(0,1),(1,2),(2,0)]:
            length=np.linalg.norm(xyz[:,i]-xyz[:,j],axis=1);tex=np.linalg.norm(uv[:,i]-uv[:,j],axis=1)
            errors.append(float(np.max(abs(tex-length)/length)))
        metric.append({'part':mesh['name'],'max_relative_metric_edge_error':max(errors)})
    return result,metric
old,_=parts(OUT/'before/game/assets/props/v2_street_lamps.glb')
new,near=parts(ROOT/'game/assets/props/v2_street_lamps.glb')
_,far=parts(ROOT/'game/assets/props/v2_street_lamps_lod1.glb')
retained={k:old[k]==new.get(k) for k in old if k.startswith('signal_box_crook__')}
report={'evidence_class':'INERT','retained_signal_partitions':retained,'all_retained_exact':all(retained.values()),'near_metric':near,'lower_metric':far}
target=sys.argv[1] if len(sys.argv)>1 else 'retention_and_metric_02.json'
(OUT/target).write_text(json.dumps(report,indent=2)+'\n')
print('Retained:',retained,'Metric maxima:',max(x['max_relative_metric_edge_error'] for x in near),max(x['max_relative_metric_edge_error'] for x in far))
assert len(retained)==8 and all(retained.values())
