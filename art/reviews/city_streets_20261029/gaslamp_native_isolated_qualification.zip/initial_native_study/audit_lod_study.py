"""Measure retained stock surface error on the saved native study."""
from pathlib import Path
import bpy,json,sys
from mathutils.bvhtree import BVHTree
OUT=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(OUT/'art/blender/gas_streetlamp_lod1.blend'))
def tree(o):
    return BVHTree.FromPolygons([o.matrix_world@v.co for v in o.data.vertices],
        [tuple(p.vertices) for p in o.data.polygons],all_triangles=True)
rows=[]
for high in bpy.data.collections['01_EDITABLE_Stocks'].objects:
    if high.type!='MESH':continue
    low=bpy.data.objects['LOD1_'+high.name]
    ht,lt=tree(high),tree(low)
    forward=max(lt.find_nearest(high.matrix_world@v.co)[3] for v in high.data.vertices)
    backward=max(ht.find_nearest(low.matrix_world@v.co)[3] for v in low.data.vertices)
    rows.append({'stock':high.name,'high_to_low_vertex_surface_error_m':forward,
        'low_to_high_vertex_surface_error_m':backward})
report={'evidence_class':'INERT','stocks':rows,'count':len(rows),
    'max_sampled_surface_error_m':max(max(r['high_to_low_vertex_surface_error_m'],r['low_to_high_vertex_surface_error_m']) for r in rows),
    'limits':'Vertex-to-triangle samples in both directions; not a continuous Hausdorff bound or runtime transition acceptance.'}
(OUT/'surface_error.json').write_text(json.dumps(report,indent=2)+'\n')
print('SURFACE_ERROR',report['count'],report['max_sampled_surface_error_m'])
