"""Native replacement-body study. No production, donor or runtime writes."""
from pathlib import Path
import sys, json, hashlib, math
import bpy, bmesh
from mathutils import Matrix, Vector
from mathutils.bvhtree import BVHTree

ROOT=Path('C:/ov/city')
OUT=Path(__file__).resolve().parent
DONOR=Path('C:/ov/asset-prototypes/gas-streetlamp-20261028/gas_streetlamp.blend')
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from fabrication_native_batch import partition, export

before=hashlib.sha256(DONOR.read_bytes()).hexdigest()
bpy.ops.wm.open_mainfile(filepath=str(DONOR))
bpy.context.preferences.filepaths.save_version=0
source=bpy.data.collections['01_EDITABLE_Stocks']
stocks=[o for o in source.objects if o.type=='MESH']
assert len(stocks)==114
catalog=json.loads((ROOT/'game/data/runtime_material_sets.json').read_bytes())['materials']
mapping={'paint':'post_iron','bare_iron':'cast_iron','mantle':'mantle_lit'}
keys={'post_iron':'iron_blackened','cast_iron':'cast_iron','brass':'brass_dull',
      'ceramic':'porcelain','mantle_lit':'porcelain','glass':'glass_drawn_expressive'}
lower=bpy.data.collections.new('ReplacementBodyLOD1')
bpy.context.scene.collection.children.link(lower)
scratch=bpy.data.collections.new('ReducedClosedStocks')
bpy.context.scene.collection.children.link(scratch)
groups={}; rows=[]; reduced=[]
for original in stocks:
    o=original.copy();o.data=original.data.copy();scratch.objects.link(o)
    o.name='LOD1_'+original.name
    o.data.transform(o.matrix_world);o.matrix_world=Matrix.Identity(4)
    original_faces=len(o.data.polygons)
    if original_faces>64:
        o.hide_set(False);bpy.context.view_layer.objects.active=o
        mod=o.modifiers.new('Replacement body tessellation','DECIMATE')
        mod.ratio=max(.24,48/original_faces);mod.use_collapse_triangulate=True
        bpy.ops.object.modifier_apply(modifier=mod.name)
    bm=bmesh.new();bm.from_mesh(o.data)
    bad=sum(not e.is_manifold for e in bm.edges);bm.free()
    assert not bad,(o.name,bad)
    finish=mapping.get(original.data.materials[0].name,original.data.materials[0].name)
    groups.setdefault(finish,[]).append(o);reduced.append(o)
    rows.append({'stock':original.name,'near_triangles':original_faces,
                 'lower_triangles':len(o.data.polygons),'closed':True})

for finish,objects in sorted(groups.items()):
    # Reuse donor catalogue preview; partition authors new physical metre charts.
    mat=objects[0].data.materials[0]
    partition(lower,'bishops_crook__'+finish,objects,
              {'catalog_key':keys[finish]},mat,Matrix.Identity(4),catalog)

def bvh(objects):
    vertices=[];faces=[]
    for o in objects:
        start=len(vertices);vertices.extend(o.matrix_world@v.co for v in o.data.vertices)
        faces.extend(tuple(start+i for i in p.vertices) for p in o.data.polygons)
    return BVHTree.FromPolygons(vertices,faces,all_triangles=True)

shell=next(o for o in reduced if o.name=='LOD1_Flanged hollow base casting')
tree=bvh([shell]);head=bvh(list(lower.objects))
aperture=tree.ray_cast(Vector((0,.4,.745)),Vector((0,-1,0)),1)[0]
control=tree.ray_cast(Vector((0,.4,.93)),Vector((0,-1,0)),1)[0]
a=math.pi/8
vent=head.ray_cast(Vector((.075*math.cos(a),-.84+.075*math.sin(a),4.063)),
                   Vector((math.cos(a),math.sin(a),0)),.15)[0]
a=math.pi/6
intake=head.ray_cast(Vector((.032*math.cos(a),-.84+.032*math.sin(a),3.55)),
                     Vector((0,0,1)),.06)[0]
rain=head.ray_cast(Vector((.12,-.84,4.20)),Vector((0,0,-1)),.10)[0]
checks={'all_114_stocks_retained':len(rows)==114,
        'open_service_aperture':aperture is not None and aperture.y<0,
        'solid_shell_negative_control':control is not None and control.y>0,
        'open_exhaust':vent is None,'open_lower_intake':intake is None,
        'rain_hood_retained':rain is not None}
report={'evidence_class':'INERT','donor_sha256':before,'checks':checks,'stocks':rows,
        'near_triangles':sum(r['near_triangles'] for r in rows),
        'lower_triangles':sum(len(o.data.polygons) for o in lower.objects),
        'limits':'Native body study only; no loaded precision, runtime LOD, timing or artistic acceptance.'}
(OUT/'native_controls.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
assert all(checks.values()),checks
for folder in ['art/blender','game/assets/props']:(OUT/folder).mkdir(parents=True,exist_ok=True)
for collection in bpy.data.collections:
    if collection not in [lower]:collection.hide_render=True
lower.hide_render=False
proof=export(OUT,'gas_streetlamp_lod1',lower,material_names_only=True)
report['export']=proof
report['donor_unchanged']=hashlib.sha256(DONOR.read_bytes()).hexdigest()==before
assert report['donor_unchanged']
(OUT/'native_controls.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print('GAS_LOD_STUDY',json.dumps({k:v for k,v in report.items() if k!='stocks'}),flush=True)
