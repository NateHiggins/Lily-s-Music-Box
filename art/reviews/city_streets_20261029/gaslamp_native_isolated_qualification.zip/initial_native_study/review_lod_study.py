"""Four native CPU views of complete near/lower bodies; no runtime claim."""
from pathlib import Path
import bpy, json, hashlib
from mathutils import Vector
OUT=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(OUT/'art/blender/gas_streetlamp_lod1.blend'))
scene=bpy.context.scene
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=16
scene.render.threads_mode='FIXED';scene.render.threads=2
scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'
high=bpy.data.collections['02_EXPORT_Batched'];low=bpy.data.collections['ReplacementBodyLOD1']
bpy.data.collections['03_REVIEW_Only'].hide_render=False
camera=scene.camera;camera.data.type='ORTHO';rows=[]
for level,collection in [('near',high),('lower',low)]:
    high.hide_render=collection!=high;low.hide_render=collection!=low
    for name,at,target,scale,size in [
        ('assembly',(7,-9,3.1),(0,-.3,2.5),5.6,(720,900)),
        ('head',(1.3,-2.5,4.35),(0,-.84,3.96),.92,(800,800))]:
        camera.location=at;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
        camera.data.ortho_scale=scale
        scene.render.resolution_x,scene.render.resolution_y=size
        path=OUT/(level+'_'+name+'.png');scene.render.filepath=str(path)
        bpy.ops.render.render(write_still=True)
        rows.append({'path':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(OUT/'native_views.json').write_text(json.dumps({'evidence_class':'INERT','captures':rows,
    'limits':'Native catalogue preview only; loaded material optics, LOD transition and artistic acceptance pending.'},indent=2)+'\n')
