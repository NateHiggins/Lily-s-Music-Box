# Candidate verification - a4798d7099f7

- candidate `a4798d7099f7dc364411ac48899d39dc4af7c8dd`
- base `cb1a69c646cd37ed39ac788fab5b802ddd061192`
- merge-base `cb1a69c646cd37ed39ac788fab5b802ddd061192`
- verified 2026-10-31T05:09:04Z from verifier `a4798d7099f7`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 6 regressions, 4 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 0 |

## Blocking reasons (6)

- regression: spatial: drift.new_reported 0 -> 3
- regression: spatial: new defect new_reported:031426b02a0cd8fa
- regression: spatial: new defect new_reported:b5f596022341a1b1
- regression: spatial: new defect new_reported:e970ca59869eef41
- regression: systemic: drift.new_review 29 -> 30
- regression: systemic: new defect new_review:f7488363144b38aa

## Needs human review (not blocking) (2)

- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (6)

- spatial: drift.new_reported 0 -> 3
- spatial: new defect new_reported:031426b02a0cd8fa
- spatial: new defect new_reported:b5f596022341a1b1
- spatial: new defect new_reported:e970ca59869eef41
- systemic: drift.new_review 29 -> 30
- systemic: new defect new_review:f7488363144b38aa

## Accepted regressions (0)

- none

## Improvements (4)

- v2_surface_qualification: FAIL -> PASS
- v2_surface_qualification: defects 2 -> 0
- v2_surface_qualification: resolved missing or stale rendered review
- v2_surface_qualification: resolved stale surface qualification: rendering inputs changed

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (0)

- none

BLOCKED regression: spatial: drift.new_reported 0 -> 3; regression: spatial: new defect new_reported:031426b02a0cd8fa; regression: spatial: new defect new_reported:b5f596022341a1b1 (+3 more)
