"""Run canonical verification while preserving the known untracked originals."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path('C:/PleaseRemainOnTheLine').resolve()
HERE = Path(__file__).resolve().parent
prior = HERE.parent/'combined_pr103_01'
manifest_path = prior/'candidate_untracked_preservation.json'
archive_path = prior/'candidate_untracked_preservation.zip'
expected = json.loads(manifest_path.read_text())
assert len(expected) == 664
actual = [p.decode('utf-8') for p in subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=ROOT).split(b'\0') if p]
assert set(actual) == set(expected), 'Untracked ownership changed; stop instead of assuming.'
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None and set(archive.namelist()) == set(expected)
    for relative, entry in expected.items():
        path = (ROOT/relative).resolve()
        assert path.is_relative_to(ROOT) and path.is_file()
        data = archive.read(relative)
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
        assert path.read_bytes() == data, f'Current bytes differ: {relative}'
record = {'preserved_files':len(expected), 'existing_archive':str(archive_path),
          'archive_sha256':hashlib.sha256(archive_path.read_bytes()).hexdigest(), 'restored':False}
record_path = HERE/'verification_preservation.json'
record_path.write_text(json.dumps(record, indent=2)+'\n')
removed = []
try:
    for relative in actual:
        path = (ROOT/relative).resolve()
        assert path.is_relative_to(ROOT)
        path.unlink()
        removed.append(relative)
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT).strip()
    result = subprocess.run([sys.executable, 'tools/verify_candidate.py', '53bdd48231f329d7c80cd7fdf8cb00a15ed87401',
                             '--base', 'bbe6b5191ac67207352d30ecf120e66c6f9a21cf', '--no-godot', '--in-place',
                             '--baseline-board', str(HERE/'baseline_bbe6/board.json'), '--out', str(HERE/'candidate_53')], cwd=ROOT)
    record['verifier_exit'] = result.returncode
finally:
    with zipfile.ZipFile(archive_path) as archive:
        for relative in removed:
            path = (ROOT/relative).resolve()
            assert path.is_relative_to(ROOT)
            data = archive.read(relative)
            if path.exists():
                assert path.read_bytes() == data, f'Intervening edit preserved, manual recovery needed: {relative}'
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
        assert all(hashlib.sha256((ROOT/relative).read_bytes()).hexdigest() == entry['sha256'] for relative,entry in expected.items())
    record['restored'] = True
    record['restored_count'] = len(removed)
    record_path.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))
sys.exit(record.get('verifier_exit', 3))
