"""Reproduce bounded route distributions; retain every recorded walking frame."""
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def dist(values):
    values = sorted(values)
    if not values:
        return {"n": 0}
    return {"n": len(values), **{key: values[min(len(values)-1, math.ceil(q*len(values))-1)]
            for key, q in [("p50_ms", .5), ("p95_ms", .95), ("p99_ms", .99), ("max_ms", 1.)]}}


def review(name, folder, log, source):
    probe_path = ROOT/folder/"stutter_probe.json"
    work_path = ROOT/folder/"stutter_work.json"
    probe = json.loads(probe_path.read_text())
    work = json.loads(work_path.read_text())
    receipt = json.loads((ROOT/(log+".receipt.json")).read_text())
    assert receipt["execution"]["completed"] and receipt["execution"]["exit_code"] == 0
    assert not probe["failures"] and len(probe["legs"]) == 6
    assert probe["source_before"] == probe["source_after"]
    assert hashlib.sha256((ROOT/source).read_bytes()).hexdigest() == receipt["source"]["test_sha256"]
    assert not (ROOT/(log+".stderr")).read_bytes()
    frames = probe["frames"]
    phases = []
    for leg in probe["legs"]:
        rows = frames[leg["sample_first"]:leg["sample_first"]+leg["sample_count"]]
        assert rows and all(row["phase"] == leg["phase"] for row in rows)
        phases.append({"phase": leg["phase"], "wall": dist([r["wall_render_draws_primitives"][0] for r in rows]),
                       "main_cpu": dist([r["wall_render_draws_primitives"][1] for r in rows]),
                       "main_gpu": dist([r["wall_render_draws_primitives"][2] for r in rows])})
    counters = work["frames"]
    pipeline = {key: counters[-1]["counters"][key]-counters[0]["counters"][key]
                for key in counters[0]["counters"] if key.startswith("PIPELINE_")}
    pairs = {}
    for begin, end in [("process_begin", "process_end"), ("physics_begin", "physics_end"), ("render_pre", "render_post")]:
        last = None
        values = []
        for row in work["timeline"]:
            if row[4] == begin:
                last = row
            elif row[4] == end and last is not None:
                # Pair same process frame (or physics frame for physics).
                index = 2 if begin.startswith("physics") else 1
                if row[index] == last[index]:
                    values.append((row[0]-last[0])/1000.)
                last = None
        pairs[begin.removesuffix("_begin").removesuffix("_pre")] = dist(values)
    return {"name": name, "source_sha256": receipt["source"]["test_sha256"],
            "files_sha256": {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                             for p in [probe_path, work_path, ROOT/(log+".receipt.json"), ROOT/source]},
            "checks": probe["checks"], "settings": probe["settings"],
            "preparation": probe.get("render_preparation", {}),
            "wall": dist([r["wall_render_draws_primitives"][0] for r in frames]), "phases": phases,
            "frames_over_100ms": sum(r["wall_render_draws_primitives"][0] > 100 for r in frames),
            "pipeline_deltas": pipeline, "callback_brackets": pairs,
            "observer_cost_ms": dist([v/1000. for v in work["probe_post_sample_usec"]]),
            "residency_states": sorted(set(r["residency"] for r in counters)),
            "room_refresh_counts": sorted(set(r["room_refreshes"] for r in counters)),
            "truncated": work["truncated"]}


if __name__ == "__main__":
    runs = [review("original", "route", "route.log", "executed_route_01.gd"),
            review("diner_hidden_then_restored", "diner_hidden_02", "diner_hidden_02.log", "executed_control_02.gd"),
            review("original_visuals_render_preparation", "prepared_03", "prepared_03.log", "executed_prepared_03.gd")]
    expected = {k: v for k, v in runs[0]["settings"].items() if not k.endswith("diagnostic_only")}
    assert all({k: v for k, v in run["settings"].items() if not k.endswith("diagnostic_only")} == expected for run in runs)
    result = {"evidence_class": "INERT", "scope": "Three short actual-world route diagnostics at matched settings; retained driver cache, not randomized ABBA, not input-to-display latency or full-city acceptance. No samples discarded. Callback brackets and asynchronous GPU monitors overlap and must not be summed.", "runs": runs}
    (ROOT/"three_control_comparison.json").write_text(json.dumps(result, indent=2)+"\n")
    for run in runs:
        print(run["name"], run["wall"], "over100", run["frames_over_100ms"], "preparation", run["preparation"], "pipelines", run["pipeline_deltas"])
