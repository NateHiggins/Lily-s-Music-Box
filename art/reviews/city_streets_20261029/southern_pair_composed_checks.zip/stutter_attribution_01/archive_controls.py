"""Append the bounded diagnostic packet, preserving every existing member."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path('C:/PleaseRemainOnTheLine')
HERE = Path(__file__).resolve().parent
manifest_path = ROOT/'art/reviews/city_streets_20261029/manifest.json'
manifest = json.loads(manifest_path.read_text())
entry = manifest['southern_pair_composed_checks']
archive = ROOT/entry['archive']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == entry['sha256']
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    original = {name: hashlib.sha256(z.read(name)).hexdigest() for name in z.namelist()}
assert set(original) == set(entry['members'])
assert all(original[name] == entry['members'][name]['sha256'] for name in original)
files = [p for p in HERE.iterdir() if p.is_file() and p.suffix in ['.json', '.gd', '.py'] or p.is_file() and (p.name.endswith('.log') or p.name.endswith('.stderr'))]
for folder in ['route', 'diner_hidden_02', 'prepared_03']:
    files += list((HERE/folder).iterdir())
additions = {'stutter_attribution_01/'+p.relative_to(HERE).as_posix(): p for p in files}
assert not set(additions).intersection(original)
with zipfile.ZipFile(archive, 'a', zipfile.ZIP_DEFLATED) as z:
    for name, path in sorted(additions.items()):
        z.writestr(name, path.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    hashes = {name: {'bytes': z.getinfo(name).file_size, 'sha256': hashlib.sha256(z.read(name)).hexdigest()} for name in z.namelist()}
    assert all(hashes[name]['sha256'] == digest for name, digest in original.items())
    assert all(hashes[name]['sha256'] == hashlib.sha256(p.read_bytes()).hexdigest() for name, p in additions.items())
entry.update(bytes=archive.stat().st_size, sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), members=hashes)
entry['scope'] += ' Stutter attribution: three INERT six-leg actual-world controls at bbe6b519, original17/0, diner-hidden20/0 and original-visuals renderer preparation19/0; raw executed sources, metrics, logs, wrappers and analysis preserved. No production performance or artistic acceptance.'
manifest_path.write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps({'original_preserved':len(original), 'added':len(additions), 'members':len(hashes), 'bytes':entry['bytes'], 'sha256':entry['sha256']}))
