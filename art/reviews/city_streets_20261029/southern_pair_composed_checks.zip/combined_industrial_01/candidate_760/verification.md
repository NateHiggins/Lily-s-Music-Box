# Candidate verification - 760bfcb7697d

- candidate `760bfcb7697de3a027023410b48e20c5825921b4`
- base `2d7a07726910aa6134e279bf32ea20ef02bc55b1`
- merge-base `2d7a07726910aa6134e279bf32ea20ef02bc55b1`
- verified 2026-10-31T06:22:41Z from verifier `760bfcb7697d`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 0 regressions, 4 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 3 |

## Blocking reasons (0)

- none

## Needs human review (not blocking) (3)

- candidate changes 3 gate file(s); read those diffs before trusting the board
- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (0)

- none

## Accepted regressions (0)

- none

## Improvements (4)

- v2_surface_qualification: FAIL -> PASS
- v2_surface_qualification: defects 2 -> 0
- v2_surface_qualification: resolved missing or stale rendered review
- v2_surface_qualification: resolved stale surface qualification: rendering inputs changed

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (3)

- M tools/orison_spatial_dependency_manifest.json
- M tools/tests/test_systemic_situation_authority.py
- M tools/tests/test_v2_surface_requirements.py

MERGE-CANDIDATE 760bfcb7697de3a027023410b48e20c5825921b4
