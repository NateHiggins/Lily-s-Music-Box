from pathlib import Path
import json,numpy as np,hashlib,math
root=Path('C:/PleaseRemainOnTheLine');out=Path('C:/ov/reports/city_streets_20261029/southern_pair_01')
source=root/'game/data/orison_v2/exterior/regions.json';regions=json.loads(source.read_text())
instances={r['id']:r for r in regions['instances']};templates={r['id']:r for r in regions['surface_templates']}
def pose(identity):
    r=instances[identity];a=math.radians(r.get('local_yaw_degrees',0));c,s=math.cos(a),math.sin(a);rot=np.array([[c,0,s],[0,1,0],[-s,0,c]])
    offset=np.array(r['offset_uvn_m']);owner=r['owner_instance_id']
    if not owner:return rot,np.array([offset[0],offset[2],offset[1]])
    b,t=pose(owner);surf=next(x for x in templates[instances[owner]['template_id']]['surfaces'] if x['id']==r['owner_surface_id'])
    u=b@surf['u_axis'];v=b@surf['v_axis'];n=b@surf['normal'];return np.column_stack((u,n,v))@rot,b@surf['point_m']+t+u*offset[0]+v*offset[1]+n*offset[2]
b,t=pose('ARCADE_PORTAL_01');programme=root/'game/data/orison_v2/exterior/public_region_programmes.json';modules=json.loads(programme.read_text())['modules'];module=next(r for r in modules if r['instance_id']=='ARCADE_PORTAL_01');t=t-b@module['source_origin_m']
gltf=root/'game/assets/building/orison_v2/exterior/passage_gateway.gltf';j=json.loads(gltf.read_text());buffers=[(gltf.parent/r['uri']).resolve().read_bytes() for r in j['buffers']]
def array(index):
    a=j['accessors'][index];v=j['bufferViews'][a['bufferView']];dt={5126:'<f4',5123:'<u2',5125:'<u4'}[a['componentType']];w={'VEC3':3,'SCALAR':1}[a['type']];d=np.dtype(dt)
    return np.ndarray((a['count'],w),dtype=d,buffer=buffers[v['buffer']],offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',w*d.itemsize),d.itemsize)).copy()
node=next(n for n in j['nodes'] if n.get('name','').endswith('gateway_cast_iron-col'));assert not any(k in node for k in ['translation','rotation','scale','matrix'])
triangles=[]
for pr in j['meshes'][node['mesh']]['primitives']:
    p=array(pr['attributes']['POSITION']).astype(float)@b.T+t;idx=array(pr['indices']).reshape(-1,3);triangles.extend(p[idx])
tri=np.array(triangles);street=json.loads((root/'game/data/orison_v2/exterior/street_frame.json').read_text());plan=tri.copy();plan[:,:,1]=-(tri[:,:,2]+street['source_threshold_z']);plan[:,:,2]=tri[:,:,1]
# Source-only conservative bounds around the reported collision; no live query exclusions.
lo=plan.min(axis=1);hi=plan.max(axis=1);selected=(lo[:,0]<.7)&(hi[:,0]>-.7)&(lo[:,2]<1.60)&(hi[:,2]>0.)&(lo[:,1]<-24.)&(hi[:,1]>-29.)
assert selected.any()
points=plan[selected].reshape(-1,3);low=points.min(axis=0);high=points.max(axis=0)
record={'evidence_class':'INERT','scope':'Read-only exported cast-iron collision stock in the actual registered passage frame. Conservative triangle bounds around the failed normal-controller contact; not a floor/capsule or runtime qualification.','source_hashes':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source,programme,gltf]},'passage_basis':b.tolist(),'passage_origin':t.tolist(),'plan_min':low.tolist(),'plan_max':high.tolist(),'triangles_selected':int(selected.sum()),'candidate_detour_plan_y':float(high[1]+.33+.25)}
(out/'gateway_post_survey_01.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(record,indent=2))
