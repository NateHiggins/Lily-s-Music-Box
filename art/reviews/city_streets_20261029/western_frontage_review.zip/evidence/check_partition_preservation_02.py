from pathlib import Path
import struct,json,collections,numpy as np,sys,hashlib
r=Path('C:/ov/city');w=Path('C:/ov/reports/city_streets_20261029/western_frontage_01')
(w/'partition_refusal_01.json').write_text(json.dumps({'evidence_class':'INERT','original_assertion':'All non-target shard partitions remain exactly unchanged','failure':'HORIZON_NEAR_3_2_P1__arcade_brick_bond','finding':'Replacing a9.6m neighbor with a7.25m house exposes a previously covered storey on P1. Only brick,joinery and pane partitions change; all frames/bounds and9other P1/P2 partitions remain exact. Require independent triangle-difference boundary controls, not a blanket exemption.'},indent=2))
def load(p):
 raw=p.read_bytes();size=struct.unpack_from('<I',raw,12)[0];d=json.loads(raw[20:20+size]);binary=raw[28+size:]
 def acc(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];dtype=np.dtype({5121:'u1',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']]);start=v.get('byteOffset',0)+a.get('byteOffset',0)
  return np.ndarray((a['count'],width),dtype=dtype,buffer=binary,offset=start,strides=(v.get('byteStride',width*dtype.itemsize),dtype.itemsize)).astype(float)
 result={}
 for n in d['nodes']:
  if 'mesh' not in n:continue
  records=collections.Counter();material=[]
  for p in d['meshes'][n['mesh']]['primitives']:
   aa=p['attributes'];data=np.concatenate([acc(aa[k]) for k in ['POSITION','NORMAL','TANGENT','TEXCOORD_0']],axis=1);indices=acc(p['indices']).astype(int).reshape(-1,3)
   for triangle in indices:
    corners=tuple(tuple(data[i]) for i in triangle);key=min(corners[i:]+corners[:i] for i in range(3));records[key]+=1
   material.append(d['materials'][p['material']]['name'])
  result[n['name']]={'frame':{k:n[k] for k in ['matrix','translation','rotation','scale'] if k in n},'triangles':records,'materials':material}
 return result
old=load(w/'before_assets/city_horizon_near_3_2.glb');new=load(r/'game/assets/props/city_horizon_near_3_2.glb');target={f'HORIZON_NEAR_3_2_P0R{i}' for i in range(3)};exact=[];boundary=[]
f=json.loads((r/'game/tests/fixtures/orison_city_horizon.json').read_bytes());neighbor=next(x for x in f['buildings'] if x['id']=='HORIZON_NEAR_3_2_P1');datum=neighbor['grade_datum_m']
for name,a in old.items():
 if name.split('__')[0] in target:continue
 b=new[name];assert a['frame']==b['frame'] and a['materials']==b['materials']
 if a['triangles']==b['triangles']:exact.append(name);continue
 assert name.startswith('HORIZON_NEAR_3_2_P1__'),name
 changed=list((a['triangles']-b['triangles']).elements())+list((b['triangles']-a['triangles']).elements())
 # Actual native export uses translation-only part poses; refuse any other frame.
 assert set(a['frame'])<= {'translation'}
 t=np.array(a['frame'].get('translation',[0,0,0]));points=np.array([np.array(c[:3])+t for triangle in changed for c in triangle])
 assert np.max(abs(points[:,2]-neighbor['rect'][1]))<.301,(name,points.min(0),points.max(0))
 assert points[:,1].min()>=datum+9.6-.0001 and points[:,1].max()<=datum+12.8+.0001,(name,points.min(0),points.max(0),datum)
 boundary.append({'part':name,'removed_triangles':sum((a['triangles']-b['triangles']).values()),'added_triangles':sum((b['triangles']-a['triangles']).values()),'difference_bounds':list(points.min(0))+list(points.max(0))})
assert len(boundary)==3 and len(exact)==9
(w/'partition_preservation_02.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Exact cyclic corner-attribute triangle multisets retain winding,UV,normal/tangent,material and pose. Every P1 change is confined to the newly exposed9.6–12.8m storey within301mm of the shared parcel boundary. No other non-target triangles differ.','exact_partitions':exact,'controlled_boundary_changes':boundary},indent=2))
sys.path.insert(0,str(r/'art/blender/scripts'));from check_exported_tangents import validate
checks=[validate(r/'game/assets/props'/name) for name in ['city_horizon_near_3_2.glb','city_horizon_near_3_2_lod1.glb']]
(w/'uv_audit_01.json').write_text(json.dumps({'evidence_class':'INERT','scope':'Raw exported mapping only,not loaded qualification','results':checks},indent=2));print('9non-target partitions exact;3shared-boundary partitions constrained to exposed storey. Both GLBs pass UV derivatives.',[(x['triangles'],x['minimum_tangent_agreement']) for x in checks])
