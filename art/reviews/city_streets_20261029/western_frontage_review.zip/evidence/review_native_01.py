"""Read-only actual native/export review of the Western street-facing row."""
from pathlib import Path
import bpy,collections,json,hashlib
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from bpy_extras.object_utils import world_to_camera_view
root=Path('C:/ov/city');out=Path(__file__).parent/'native_review_01';out.mkdir(exist_ok=False)
ids=[f'HORIZON_NEAR_3_2_P0R{i}' for i in range(3)]
fixture=json.loads((root/'game/tests/fixtures/orison_city_horizon.json').read_bytes());profiles={r['id']:r for r in fixture['buildings']};roundtrips=[];captures=[];contacts=[];bindings={}
def tris(obj):
    obj.data.calc_loop_triangles()
    return collections.Counter(tuple(sorted(tuple(float(c) for c in obj.matrix_world@obj.data.vertices[i].co) for i in t.vertices)) for t in obj.data.loop_triangles)
for family,collection in [('city_horizon_near','CityHorizon_near'),('city_horizon_lod1','CityHorizonReplacementBodies')]:
    native=root/f'art/blender/{family}.blend';bindings[str(native.relative_to(root))]=hashlib.sha256(native.read_bytes()).hexdigest();bpy.ops.wm.open_mainfile(filepath=str(native))
    for col in bpy.data.collections:col.hide_viewport=False
    for obj in bpy.context.scene.objects:obj.hide_viewport=False;obj.hide_render=True
    bpy.context.view_layer.update();original={o.name:o for o in bpy.data.collections[collection].objects if o.name.split('__')[0] in ids};imported={}
    for asset in fixture['assets'].values():
        if Path(asset['native']).stem!=family or not set(asset['buildings'])&set(ids):continue
        path=root/asset['asset'];bindings[str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest();before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(path));bpy.context.view_layer.update()
        for obj in [o for o in bpy.data.objects if o not in before and o.type=='MESH']:
            name=obj.name.split('.')[0];obj.hide_render=name not in original
            if obj.hide_render:continue
            assert name not in imported and tris(obj)==tris(original[name]),(family,name,'world triangles')
            assert len(obj.data.uv_layers)==1
            obj.data.materials.clear();obj.data.materials.append(original[name].data.materials[0]);imported[name]=obj;roundtrips.append(dict(family=family,part=name,exact_world_triangles=True))
    assert set(imported)==set(original),(family,set(original)-set(imported))
    verts=[];faces=[];owners=[]
    for name,obj in imported.items():
        n=len(verts);verts.extend(obj.matrix_world@v.co for v in obj.data.vertices);faces.extend(tuple(n+i for i in p.vertices) for p in obj.data.polygons);owners.extend([name]*len(obj.data.polygons))
    tree=BVHTree.FromPolygons(verts,faces)
    for window in fixture['window_rows']:
        if window['building'] not in ids:continue
        p=Vector(window['point']);normal=Vector(window['normal']);hit,n,index,d=tree.ray_cast(p+normal*.03,-normal,.30)
        assert hit is not None and owners[index]==window['building']+'__mirror_aged' and (hit-(p-normal*window['recess_m'])).length<.0001,(family,'pane',window,owners[index] if index is not None else None)
        contacts.append(dict(family=family,kind='actual_first_pane',building=window['building']))
    # A continuous1.05m minimum parcel-edge lane lies outside every stoop.
    # Full capsule movement is a separate runtime check; these are native rays.
    a,b,c,d=profiles[ids[0]]['rect'];end=profiles[ids[-1]]['rect'][3]
    for i in range(79):
        station=b+.5+(end-b-1)*i/78;x=a+.5;y=-station
        row=next(profiles[identity] for identity in ids if profiles[identity]['rect'][1]<=station<=profiles[identity]['rect'][3])
        datum=float(row['grade_datum_m'])
        hit,n,index,distance=tree.ray_cast(Vector((x,y,datum+.10)),Vector((0,0,-1)),.20)
        assert hit is not None and owners[index].endswith('__concrete') and abs(hit.z-datum)<.0001,(family,'front support',x,y,hit,datum)
        for dx,dy in [(0,0),(.33,0),(-.33,0),(0,.33),(0,-.33)]:
            hit,n,index,distance=tree.ray_cast(Vector((x+dx,y+dy,datum+.03)),Vector((0,0,1)),1.524)
            assert hit is None,(family,'lane clearance',x,y,owners[index] if index is not None else None)
    for image in bpy.data.images:
        if image.source!='FILE' or image.packed_file:continue
        path=root/'game/assets/building/textures'/Path(image.filepath).name;assert path.is_file();image.filepath=str(path);image.reload();assert min(image.size)>0
    scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.cycles.use_denoising=True;scene.cycles.max_bounces=4;scene.render.threads_mode='FIXED';scene.render.threads=2;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX';scene.render.resolution_percentage=100;scene.render.resolution_x=1200;scene.render.resolution_y=950
    world=bpy.data.worlds.new('Western frontage native review');world.use_nodes=True;scene.world=world;world.node_tree.nodes['Background'].inputs[0].default_value=(.18,.21,.27,1);world.node_tree.nodes['Background'].inputs[1].default_value=.7
    sun=bpy.data.objects.new('Diagnostic key',bpy.data.lights.new('Diagnostic key','SUN'));scene.collection.objects.link(sun);sun.rotation_euler=Vector((-1,.35,-.9)).to_track_quat('-Z','Y').to_euler();sun.data.energy=2.5;sun.data.angle=.15
    cam=bpy.data.objects.new('Native review camera',bpy.data.cameras.new('Native review camera'));scene.collection.objects.link(cam);scene.camera=cam;cam.data.type='ORTHO';cam.data.clip_start=.02;cam.data.clip_end=1000
    for label,chosen in [(identity,[identity]) for identity in ids]+[('row_context',ids)]:
        visible=[]
        for name,obj in imported.items():
            obj.hide_render=name.split('__')[0] not in chosen
            if not obj.hide_render:visible.append(obj)
        corners=[o.matrix_world@Vector(c) for o in visible for c in o.bound_box];lo=Vector([min(v[i] for v in corners) for i in range(3)]);hi=Vector([max(v[i] for v in corners) for i in range(3)]);aim=(lo+hi)*.5;cam.location=aim+Vector((-1,.55,.55)).normalized()*90;cam.rotation_euler=(aim-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=max(hi.x-lo.x,hi.y-lo.y,hi.z-lo.z)*1.2
        for attempt in range(24):
            bpy.context.view_layer.update();points=[world_to_camera_view(scene,cam,p) for p in corners]
            if all(p.z>0 and .04<=p.x<=.96 and .04<=p.y<=.96 for p in points):break
            cam.data.ortho_scale*=1.1
        else:raise AssertionError((family,label,'framing'))
        path=out/(family+'_'+label+'.png');scene.render.filepath=str(path);bpy.ops.render.render(write_still=True);captures.append(dict(file=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),whole_selected_geometry_framed=True,buildings=chosen))
for path,digest in bindings.items():assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest
assert len(captures)==8 and len(roundtrips)>30 and len(contacts)>20
(out/'review.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Actual three-body native/export world-triangle,UV-layer,pane first-hit and158front-lane station diagnostics;8CPU renders with registered native materials. Not Godot collision,loaded maps,actual access,performance or artistic acceptance.',roundtrips=roundtrips,contacts=contacts,captures=captures,source_sha256=bindings),indent=2),encoding='utf-8',newline='\n')
print('NATIVE WESTERN FRONTAGE PASS',len(roundtrips),'roundtrips',len(contacts),'pane controls',len(captures),'images',flush=True)
