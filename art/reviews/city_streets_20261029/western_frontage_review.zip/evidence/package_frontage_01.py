from pathlib import Path
import subprocess,json,hashlib,zipfile
root=Path("C:/ov/city"); evidence=Path(__file__).parent
archive=root/"art/reviews/city_streets_20261029/western_frontage_review.zip"
assert archive.resolve().is_relative_to(root.resolve()), "Archive target must remain in isolated worktree"
assert not archive.exists(), "Preserve an existing packet; choose a reviewed replacement explicitly"
assert (evidence/"candidate_board_01/board.json").is_file()
board=json.loads((evidence/"candidate_board_01/board.json").read_bytes())
assert board["comparison"]["comparable"]
assert all("test:test_v2_surface_requirements" in issue for issue in board["comparison"]["regressions"]), "Unresolved full-board change"
retry=json.loads((evidence/"surface_retry_board_01/board.json").read_bytes())
assert len(retry["gates"])==1 and retry["gates"][0]["id"]=="test:test_v2_surface_requirements" and retry["gates"][0]["severity"]=="PASS", "Original timed-out gate requires a real passing retry"
registered=json.loads((evidence/"final_source_board_01/board.json").read_bytes())
assert all(issue.startswith("spatial:") and ("new_reported" in issue or "new defect" in issue) for issue in registered["comparison"]["regressions"]), "Only the retained new camera-station refusal may precede registration"
assert all(row["severity"]=="PASS" for row in registered["gates"]), "All seven final source gates must pass"
spatial_retry=json.loads((evidence/"spatial_retry_board_02/board.json").read_bytes())
assert len(spatial_retry["gates"])==1 and spatial_retry["gates"][0]["id"]=="spatial" and spatial_retry["gates"][0]["severity"]=="PASS"
assert not spatial_retry["comparison"]["regressions"] and not any(spatial_retry["gates"][0]["counts"].values()), "Exact single-record registration requires a fresh clean spatial comparison"
assert (evidence/"world_03/western_frontage_composed.runtime.json").is_file(), "Final actual composed route required"
contract=json.loads((evidence/"world_03/western_frontage_composed.runtime.json").read_bytes())
assert contract["execution"]["completed"] and contract["execution"]["exit_code"]==0 and contract["failures"]==0
receipt=json.loads((evidence/"world_03.log.receipt.json").read_bytes())
assert receipt["execution"]["completed"] and receipt["execution"]["exit_code"]==0 and not receipt["execution"]["timed_out"]
assert (evidence/"world_optical_review_03.json").is_file(), "Inspect actual composed images first"
def sha(raw):return hashlib.sha256(raw).hexdigest()
prior={p.name:sha(p.read_bytes()) for p in archive.parent.glob("*.zip")}
paths=subprocess.check_output(["git","diff","--cached","--name-only","-z"],cwd=root).decode().split("\0")
assets={p:{"bytes":(root/p).stat().st_size,"raw_sha256":sha((root/p).read_bytes())} for p in paths if p and p.endswith((".glb",".blend"))}
members={}
with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(evidence.rglob("*")):
        if not p.is_file() or "__pycache__" in p.parts or p.suffix in [".zip",".pyc"]:continue
        if "before_assets" in p.parts and p.suffix==".glb":continue # Original baseline is recoverable byte-exact from starting Git SHA.
        name="evidence/"+p.relative_to(evidence).as_posix();raw=p.read_bytes();z.writestr(name,raw);members[name]={"bytes":len(raw),"raw_sha256":sha(raw)}
    for relative in paths:
        if not relative or not relative.endswith((".gd",".tscn",".py")):continue
        raw=(root/relative).read_bytes();name="executed_sources/"+relative;z.writestr(name,raw);members[name]={"bytes":len(raw),"raw_sha256":sha(raw)}
    for path in sorted((root/"game/tmp/v2_city_western_frontage_01").glob("*")):
        if path.suffix not in [".gd",".tscn"]:continue
        raw=path.read_bytes();name="isolated_instruments/"+path.name;z.writestr(name,raw);members[name]={"bytes":len(raw),"raw_sha256":sha(raw)}
    index={"evidence_class":"INERT","scope":"Three Western frontage houses: native construction, isolated loaded mapping/mip/full-body and material-part LODs, plus bounded composed access. Original failures and full-board timeout/passing targeted retry remain explicit. No whole-city,saves,artistic acceptance or main merge.","source_checkpoint":subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip(),"members":members,"generated_assets":assets,"prior_archives":prior}
    z.writestr("index.json",json.dumps(index,indent=2))
with zipfile.ZipFile(archive) as z:
    for name,spec in members.items():assert sha(z.read(name))==spec["raw_sha256"]
for name,digest in prior.items():assert sha((archive.parent/name).read_bytes())==digest
manifest_path=archive.parent/"manifest.json";manifest=json.loads(manifest_path.read_bytes())
manifest["western_frontage_archive"]={"evidence_class":"INERT","archive":archive.name,"bytes":archive.stat().st_size,"sha256":sha(archive.read_bytes()),"member_count":len(members)+1,"index":"index.json","prior_archives_preserved":len(prior),"scope":index["scope"]}
manifest_path.write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(manifest["western_frontage_archive"],indent=2))
