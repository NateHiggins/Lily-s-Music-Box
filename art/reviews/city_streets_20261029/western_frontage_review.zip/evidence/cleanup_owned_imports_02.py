from pathlib import Path
import subprocess,json,hashlib,re,zipfile,datetime
root=Path("C:/ov/city").resolve();out=Path(__file__).parent
assert (out/"world_03.log.receipt.json").is_file(), "Own final engine run must be terminal"
receipt=json.loads((out/"world_03.log.receipt.json").read_bytes())
assert receipt["execution"]["completed"]
assert not (out/"cleanup_owned_imports_02.json").exists()
def git(*args):return subprocess.run(["git",*args],cwd=root,capture_output=True,check=True).stdout
index_before=git("write-tree").decode().strip()
stages={}
for row in git("ls-files","--stage","-z").split(b"\0"):
    if row:
        meta,path=row.split(b"\t",1);stages[path.decode()]=meta.split()[1].decode()
def stamp(value):return datetime.datetime.fromisoformat(value.replace("Z","+00:00")).timestamp()
start=stamp(json.loads((out/"import_01.log.receipt.json").read_bytes())["execution"]["started_utc"])-2
end=stamp(receipt["execution"]["finished_utc"])+2
uids=[]
for item in git("ls-files","--others","--exclude-standard","-z").split(b"\0"):
    if not item:continue
    relative=item.decode();assert relative.endswith(".uid"),("unexpected untracked path",relative)
    path=(root/relative).resolve();assert path.is_relative_to(root) and relative[:-4] in stages
    raw=path.read_bytes();assert re.fullmatch(rb"uid://[a-z0-9]+\s*",raw)
    assert start<=path.stat().st_mtime<=end,(relative,"outside owned engine interval")
    uids.append((relative,raw))
imports=[]
for entry in git("status","--porcelain=v1","-z","--untracked-files=no").split(b"\0"):
    if not entry:continue
    status=entry.decode();relative=status[3:]
    if not relative.endswith(".import"):continue
    if status[:2]=="A " and relative=="game/assets/props/city_horizon_near_3_2_lod1.glb.import":continue
    assert status[:2]==" M",status
    assert (root/relative).resolve().is_relative_to(root), (relative,"outside worktree")
    raw=(root/relative).read_bytes();normalized=raw.replace(b"\r\n",b"\n")
    oid=hashlib.sha1(b"blob "+str(len(normalized)).encode()+b"\0"+normalized).hexdigest()
    assert oid==stages[relative],("real import-policy change",relative)
    imports.append((relative,raw))
backup=out/"owned_import_backup_02.zip"
with zipfile.ZipFile(backup,"x",compression=zipfile.ZIP_DEFLATED) as z:
    for relative,raw in uids+imports:z.writestr(relative,raw)
with zipfile.ZipFile(backup) as z:
    for relative,raw in uids+imports:assert z.read(relative)==raw
for relative,raw in uids:
    path=(root/relative).resolve();assert path.is_relative_to(root) and path.read_bytes()==raw;path.unlink()
for i in range(0,len(imports),40):git("restore","--worktree","--",*[r for r,b in imports[i:i+40]])
assert git("write-tree").decode().strip()==index_before
for relative,raw in imports:assert (root/relative).read_bytes().replace(b"\r\n",b"\n")==raw.replace(b"\r\n",b"\n")
record={"evidence_class":"INERT","scope":"Owned import interval and exact index-equivalent filters only; index and all authored/production bytes unchanged.","removed_uid_count":len(uids),"restored_import_count":len(imports),"uid_paths":[r for r,b in uids],"import_paths":[r for r,b in imports],"index_tree_unchanged":index_before,"backup_sha256":hashlib.sha256(backup.read_bytes()).hexdigest()}
(out/"cleanup_owned_imports_02.json").write_text(json.dumps(record,indent=2),encoding="utf-8",newline="\n")
print("Owned cleanup",len(uids),"UIDs",len(imports),"index-equivalent import filters; verified backup/index unchanged")
