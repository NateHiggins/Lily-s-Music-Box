extends "res://tests/v2_grade_owner_survey.gd"
## One actual world for fresh discovery and the new frontage controller route.
const Programme=preload("res://tmp/v2_city_western_frontage_01/Programme.gd")
var captures:Array[String]=[]
func check(ok:bool,label:String)->void:
    _check(ok,label)
func shot(label:String)->void:
    for frame in 4:await RenderingServer.frame_post_draw
    var path:=OS.get_environment("SHOT_DIR").path_join(label+".png")
    _check(get_viewport().get_texture().get_image().save_png(path)==OK,"actual standing capture "+label)
    captures.append(label+".png")
func _after_discovery(world:OrisonV2RuntimeRoot)->void:
    var directory:=OS.get_environment("SHOT_DIR")
    _check(not directory.is_empty() and DisplayServer.get_name()!="headless","graphical output")
    _check(get_viewport().get_visible_rect().size==Vector2(3440,1440),"native fullscreen3440x1440")
    if directory.is_empty():return
    var inputs:Dictionary={}
    for path:String in [get_script().resource_path,"res://tmp/v2_city_western_frontage_01/Programme.gd","res://data/orison_v2/exterior/city_horizon.json","res://tests/fixtures/orison_city_horizon.json","res://assets/props/city_horizon_near_3_2.glb","res://assets/props/city_horizon_near_3_2_lod1.glb","res://assets/props/city_streets.glb","res://assets/props/orison_ground.glb","res://assets/props/city_ground_apron.glb"]:inputs[path]=FileAccess.get_sha256(path)
    var programme:Dictionary=await Programme.new().run(world,self)
    for path:String in inputs:_check(FileAccess.get_sha256(path)==inputs[path],"frozen frontage input "+path)
    var record:Dictionary={"schema_version":2,"evidence_kind":"runtime_contract","selector":"v2","production_runtime":true,"scope":"Actual composed Western frontage:one validated street placement,12connected normal-controller legs,7strict receiving-stock endpoints;fresh actual grade discovery. Stairs/12mm pad-datum transitions use full-capsule400mm support;constant-grade legs and endpoints retain2mm floor checks. No new scenic entry programme,save,450m continuous journey,route-wide performance or artistic acceptance.","execution":{"completed":true,"exit_code":0 if failures==0 else 1,"timed_out":false},"source":{"test_path":"game/"+get_script().resource_path.trim_prefix("res://"),"test_sha256":FileAccess.get_sha256(get_script().resource_path),"runtime_inputs_sha256":initial_inputs.runtime,"test_dependencies":bindings},"checks":checks,"failures":failures,"source_inputs":inputs,"programme":programme,"startup_ms":world.startup_ms,"captures":captures,"contracts":{"western_frontage_access":{"executed":bool(programme.get("movement_attempted",false)),"passed":failures==0 and bool(programme.get("passed",false))}}}
    var file:=FileAccess.open(directory.path_join("western_frontage_composed.runtime.json"),FileAccess.WRITE)
    _check(file!=null,"write composed frontage contract")
    if file!=null:file.store_string(JSON.stringify(record,"\t"));file.close()
