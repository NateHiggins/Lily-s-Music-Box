import json,struct,collections
from pathlib import Path
import numpy as np
root=Path('C:/PleaseRemainOnTheLine'); raw=(root/'game/assets/props/city_elevations.glb').read_bytes(); size=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+size]);data=raw[28+size:]
width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4};kind={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}
def accessor(index):
 a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];assert 'byteStride' not in v
 return np.frombuffer(data,dtype=kind[a['componentType']],count=a['count']*width[a['type']],offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(a['count'],width[a['type']])
groups=collections.defaultdict(list);names=collections.defaultdict(list)
for node in doc['nodes']:
 assert 'matrix' not in node and 'rotation' not in node and 'scale' not in node and 'children' not in node
 identity=node['name'].split('__')[0]
 for primitive in doc['meshes'][node['mesh']]['primitives']:
  xyz=accessor(primitive['attributes']['POSITION']).astype(float)+node.get('translation',[0,0,0]);indices=accessor(primitive['indices']).ravel();tri=xyz[indices].reshape(-1,3,3)
  groups[identity].append(tri);names[identity].extend([node['name']]*len(tri))
def cast(tri,point,normal):
 # Read-only double precision analytic first front-face hit, within original 80mm ray.
 origin=point+normal*3.;direction=-normal;e1=tri[:,1]-tri[:,0];e2=tri[:,2]-tri[:,0];h=np.cross(direction,e2);det=(e1*h).sum(axis=1);ok=det>1e-10
 inv=np.zeros_like(det);inv[ok]=1/det[ok];s=origin-tri[:,0];u=inv*(s*h).sum(axis=1);q=np.cross(s,e1);v=inv*(q*direction).sum(axis=1);t=inv*(q*e2).sum(axis=1)
 ok&=(u>=-1e-8)&(v>=-1e-8)&(u+v<=1+1e-8)&(t>=0)&(t<=6.)
 if not ok.any():return None
 index=int(np.argmin(np.where(ok,t,np.inf)));return index,float(t[index])
f=json.loads((root/'game/tests/fixtures/orison_city_elevations.json').read_text());result=[]
for b in f['buildings']:
 tri=np.concatenate(groups[b['id']]);r=b['main_rect'];rows=[]
 for fraction in [.12,.36,.64,.88]:
  height=b['shaft_bottom']+(b.get('shaft_top',b['setback_height'])-b['shaft_bottom'])*fraction
  stations=[([r[0]+.12,height,-r[1]],[0,0,1]),([r[2]-.12,height,-r[3]],[0,0,-1]),([r[0],height,-r[1]-.12],[-1,0,0]),([r[2],height,-r[3]+.12],[1,0,0])]
  for side,(point,normal) in enumerate(stations):
   hit=cast(tri,np.array(point),np.array(normal));rows.append(dict(fraction=fraction,side=side,point=point,hit=None if hit is None else dict(part=names[b['id']][hit[0]],distance=hit[1],error=abs(hit[1]-3.))))
 result.append(dict(building=b['id'],failed=sum(row['hit'] is None or row['hit']['error']>=.0001 for row in rows),stations=rows))
out=dict(evidence_class='INERT',scope='native read-only analytic source trace, not Godot collision qualification',buildings=result)
Path(__file__).with_name('wall_extended_trace.json').write_text(json.dumps(out,indent=2))
print([(row['building'],row['failed']) for row in result]);print('failures',sum(row['failed'] for row in result))
