from pathlib import Path
import json,struct,hashlib,numpy as np
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent
DT={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'};WD={'SCALAR':1,'VEC3':3}
def read(name):
 p=ROOT/'game/assets/props'/f'{name}.glb';raw=p.read_bytes();off=12
 while off<len(raw):
  n,k=struct.unpack_from('<II',raw,off);off+=8;b=raw[off:off+n];off+=n
  if k==0x4e4f534a:d=json.loads(b)
  elif k==0x004e4942:binary=b
 def acc(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];dt=np.dtype(DT[a['componentType']]);w=WD[a['type']]
  return np.ndarray((a['count'],w),dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',w*dt.itemsize),dt.itemsize)).copy()
 assert all('children' not in n for n in d['nodes']),name
 rows=[]
 for n in d['nodes']:
  if 'mesh' not in n or 'water_clear' in n.get('name',''):continue
  assert not any(k in n for k in ['matrix','rotation','scale']),(name,n)
  for prim in d['meshes'][n['mesh']]['primitives']:
   v=acc(prim['attributes']['POSITION']).astype(float)+n.get('translation',[0,0,0]);i=acc(prim['indices']).ravel().reshape(-1,3)
   # GLB positions are already Godot building-frame XYZ. Registered PI yaw
   # and translation(0,0,-11.65), then invert city street b2g/threshold.
   v[:,0]*=-1;v[:,2]=-v[:,2]-11.65
   v=np.stack([v[:,0],-v[:,2]-9.795,v[:,1]],axis=1)
   tri=v[i];rows.append((n['name'],tri,tri.min(axis=1),tri.max(axis=1)))
 return rows,{'path':str(p),'sha256':hashlib.sha256(raw).hexdigest()}
assets={};bindings=[]
for name in ['orison_ground','city_ground_apron','city_foundations','front_pavement']:
 assets[name],binding=read(name);bindings.append(binding)
def query(x,y):
 hits=[]
 for asset,parts in assets.items():
  for name,tri,lo,hi in parts:
   mask=(lo[:,0]<=x+1e-7)&(hi[:,0]>=x-1e-7)&(lo[:,1]<=y+1e-7)&(hi[:,1]>=y-1e-7)
   t=tri[mask]
   if not len(t):continue
   a=t[:,0];u=t[:,1]-a;v=t[:,2]-a;det=u[:,0]*v[:,1]-u[:,1]*v[:,0];valid=abs(det)>1e-10
   t=t[valid];a=a[valid];u=u[valid];v=v[valid];det=det[valid]
   b=((x-a[:,0])*v[:,1]-(y-a[:,1])*v[:,0])/det;c=(u[:,0]*(y-a[:,1])-u[:,1]*(x-a[:,0]))/det
   valid=(b>=-1e-6)&(c>=-1e-6)&(b+c<=1+1e-6)
   z=a[:,2]+b*u[:,2]+c*v[:,2]
   for value in z[valid]:
    if -4<float(value)<1:hits.append({'asset':asset,'part':name,'z':round(float(value),7)})
 return sorted(hits,key=lambda r:r['z'],reverse=True)

def read_city(name):
 p=ROOT/'game/assets/props'/f'{name}.glb';raw=p.read_bytes();off=12
 while off<len(raw):
  n,k=struct.unpack_from('<II',raw,off);off+=8;b=raw[off:off+n];off+=n
  if k==0x4e4f534a:d=json.loads(b)
  elif k==0x004e4942:binary=b
 def acc(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];dt=np.dtype(DT[a['componentType']]);w=WD[a['type']]
  return np.ndarray((a['count'],w),dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',w*dt.itemsize),dt.itemsize)).copy()
 assert all('children' not in n for n in d['nodes']),name
 rows=[]
 for n in d['nodes']:
  if 'mesh' not in n or not n.get('name','').startswith(('site_nbr_w__','site_nbr_e__')):continue
  assert not any(k in n for k in ['matrix','rotation','scale']),(name,n)
  for prim in d['meshes'][n['mesh']]['primitives']:
   v=acc(prim['attributes']['POSITION']).astype(float)+n.get('translation',[0,0,0]);i=acc(prim['indices']).ravel().reshape(-1,3)
   v=np.stack([v[:,0],-v[:,2],v[:,1]],axis=1)
   if n['name'].startswith('site_nbr_w__'):v+=np.array([-35,35,0])
   tri=v[i];rows.append((n['name'],tri,tri.min(axis=1),tri.max(axis=1)))
 return rows,{'path':str(p),'sha256':hashlib.sha256(raw).hexdigest()}

expected=[]
for t in [.02,.12,.23,.25,.36,.47,.49,.60,.71,.73,.84,.95,1.05,1.30]:
    index=min(3,int(t/.24));z=-.476+(.18+.476)*(index+1)/4 if t<.96 else .18
    expected.append(dict(building='site_nbr_w',xy=[-56.7,23+t],expected_z=.235 if t==1.30 else z,kind='closed_leaf_control' if t==1.30 else 'tread'))
for t in [.21,.70,1.25]:expected.append(dict(building='site_nbr_e',xy=[17.555,-12+t],expected_z=.09 if t==.21 else .235 if t==1.25 else .18,kind='closed_leaf_control' if t==1.25 else 'tread'))
base=dict(assets);results=[]
for lod in ['city_elevations','city_elevations_lod1']:
    assets=dict(base);assets[lod],binding=read_city(lod);bindings.append(binding)
    for row in expected:
        hits=query(*row['xy']);actual=hits[0]['z'] if hits else None
        results.append(dict(**row,lod=lod,actual_z=actual,pass_section=actual is not None and abs(actual-row['expected_z'])<1e-5,hits=hits[:4]))
report=dict(evidence_class='INERT',scope='Actual combined exported ground/foundation/pavement and new body vertical tread sections at both LODs. No runtime capsule, continuous walk, lighting or acceptance.',bindings=bindings,sections=results,failures=[r for r in results if not r['pass_section']])
(OUT/'actual_tread_sections_03.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print('COMBINED_EXPORTED_TREAD_SECTIONS',len(results),'failures',len(report['failures']))
assert not report['failures'],report['failures'][:3]
