from pathlib import Path
import subprocess,os,json,time
root=Path('C:/ov/city');out=Path(__file__).parent
engine='C:/Program Files/Blender Foundation/Blender 5.2/blender.exe'
assert Path(engine).is_file()
rows=[]
for builder in ['build_city_elevations.py','build_city_elevation_lods.py','build_city_streets.py']:
 log=out/(builder+'.final.log');env=os.environ.copy();env['CITY_ELEVATIONS_SKIP_OVERVIEW_RENDERS']='1';env['CITY_ELEVATIONS_REVIEW_DIR']=str(out/'producer')
 start=time.time()
 with log.open('wb') as f:
  result=subprocess.run([engine,'-b','-t','2','--python-exit-code','1','-P',str(root/'art/blender/scripts'/builder)],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 row=dict(builder=builder,exit_code=result.returncode,seconds=time.time()-start,log=str(log));rows.append(row)
 (out/'native_build_04.json').write_text(json.dumps(dict(evidence_class='INERT',runs=rows),indent=2),encoding='utf-8')
 print(row,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
