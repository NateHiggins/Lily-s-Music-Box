"""Actual native/round-trip and retained-equipment review, external only."""
from pathlib import Path
import bpy,json,collections,hashlib,math
from mathutils import Vector
ROOT=Path('C:/ov/city');SOURCE=ROOT;OUT=Path(__file__).parent/'near_native_review_04';OUT.mkdir(exist_ok=False)
bpy.ops.wm.open_mainfile(filepath=str(SOURCE/'art/blender/city_elevations.blend'))
report=json.loads((SOURCE/'art/blender/city_elevations_construction.json').read_bytes())
buildings={r['id']:r for r in report['buildings'] if r['id'] in ['site_nbr_w','site_nbr_e']}
plans={r['id']:r for r in json.loads((ROOT/'art/data/city_elevations/source_plan.json').read_bytes())['buildings']}
native=[o for o in bpy.data.collections['V2CityElevations'].objects if o.name.startswith(('site_nbr_w__','site_nbr_e__'))]
for o in bpy.context.scene.objects:
    if o.type=='MESH':o.hide_render=True
def triangles(o):
    return collections.Counter(tuple(sorted(tuple(float(v) for v in o.matrix_world@o.data.vertices[i].co) for i in f.vertices)) for f in o.data.polygons)
# Reuse the saved native material presets without recreating shader or optical logic.
expected={o.name:triangles(o) for o in native};mats={o.name:o.data.materials[0] for o in native}
before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(SOURCE/'game/assets/props/city_elevations.glb'))
all_imported=[o for o in bpy.data.objects if o not in before and o.type=='MESH']
for o in all_imported:o.hide_render=True
imported=[o for o in all_imported if o.name.startswith(('site_nbr_w__','site_nbr_e__'))]
assert len(imported)==len(native),len(imported)
roundtrip=[]
for o in imported:
    name=o.name.split('.')[0];actual=triangles(o)
    assert actual==expected[name],(name,'changed float32 triangle geometry')
    assert len(o.data.uv_layers)==1,name
    o.data.uv_layers.active.name='Metres';o.data.materials.clear();o.data.materials.append(mats[name])
    roundtrip.append({'name':name,'exact_triangle_positions':True,'triangles':sum(actual.values())})
context=[];context_bindings={}
for family in ['city_masts','city_aerials','city_tanks','city_beacons']:
    path=ROOT/f'art/blender/{family}.blend';context_bindings[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
    with bpy.data.libraries.load(str(path),link=False) as (available,loaded):
        names=list(buildings)
        loaded.objects=[n for n in available.objects if any(n.startswith(k+'__') for k in names) and 'ClosedFabricatedTree' not in n]
    for o in loaded.objects:
        if o.type!='MESH' or o.hide_render:continue
        bpy.context.scene.collection.objects.link(o);o.hide_set(False);o.hide_viewport=False;o.hide_render=False
        context.append(o)
bpy.context.view_layer.update()
for o in native+imported+context:
    identity=o.name.split('__')[0]
    offset=plans[identity].get('assembly_translation_m',[0,0,0]);o.location+=Vector(offset)
section=json.loads((Path(__file__).parent/'ground_section_01.json').read_text(encoding='utf-8'))
support_bindings={}
for building in buildings:
    by_asset={}
    for row in section['sections']:
        if row['building']!=building:continue
        for hit in row['surface_below_1m']:
            by_asset.setdefault(hit['asset'],set()).add(hit['part'])
    for asset,names in by_asset.items():
        source_path=ROOT/'game/assets/props'/f'{asset}.glb'
        support_bindings[str(source_path)]=hashlib.sha256(source_path.read_bytes()).hexdigest()
        before_support=set(bpy.data.objects)
        bpy.ops.import_scene.gltf(filepath=str(source_path))
        bpy.context.view_layer.update()
        from mathutils import Matrix
        registration=Matrix.Translation(Vector((0,1.855,0)))@Matrix.Rotation(math.pi,4,'Z')
        selected=[]
        for obj in [o for o in bpy.data.objects if o not in before_support]:
            if obj.type!='MESH' or obj.name.split('.')[0] not in names:
                bpy.data.objects.remove(obj,do_unlink=True);continue
            obj.matrix_world=registration@obj.matrix_world
            obj.name=building+'__MeasuredSupport_'+obj.name
            obj.hide_set(False);obj.hide_viewport=False;context.append(obj);selected.append(obj)
        assert selected,(asset,names)
for image in bpy.data.images:
    if image.source!='FILE' or image.packed_file:continue
    p=ROOT/'game/assets/building/textures'/Path(image.filepath).name
    assert p.is_file(),p
    image.filepath=str(p);image.reload();assert min(image.size)>0,image.name
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.cycles.use_denoising=True
scene.render.threads_mode='FIXED';scene.render.threads=2
scene.render.resolution_x=1000;scene.render.resolution_y=950;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX'
world=bpy.data.worlds.new('Native northwest review world');scene.world=world;world.use_nodes=True
world.node_tree.nodes['Background'].inputs[0].default_value=(.16,.19,.24,1);world.node_tree.nodes['Background'].inputs[1].default_value=.55
sun=bpy.data.objects.new('Review key',bpy.data.lights.new('Review key','SUN'));scene.collection.objects.link(sun)
sun.rotation_euler=Vector((.4,-.7,-1)).to_track_quat('-Z','Y').to_euler();sun.data.energy=2.5;sun.data.angle=math.radians(15)
bpy.ops.mesh.primitive_plane_add(size=300,location=(-43,0,-.13));floor=bpy.context.object;floor.hide_render=True
floor_mat=bpy.data.materials.new('Neutral review pavement');floor_mat.diffuse_color=(.12,.13,.14,1);floor.data.materials.append(floor_mat)
camera=bpy.data.objects.new('Native northwest camera',bpy.data.cameras.new('Native northwest camera'));scene.collection.objects.link(camera);scene.camera=camera
captures=[]
def shoot(name,visible,roundtripped,at,target,scale=None,resolution=(1000,950)):
    assert len(visible)==1,(name,visible)
    for o in native:o.hide_render=roundtripped or o.name.split('__')[0] not in visible
    for o in imported:o.hide_render=not roundtripped or o.name.split('__')[0] not in visible
    for o in context:o.hide_render=o.name.split('__')[0] not in visible
    sun.rotation_euler=Vector((.4,.7,-1)).to_track_quat('-Z','Y').to_euler()
    camera.location=at;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
    camera.data.type='ORTHO' if scale else 'PERSP';camera.data.ortho_scale=scale or 25;camera.data.lens=38
    scene.render.resolution_x,scene.render.resolution_y=resolution
    from bpy_extras.object_utils import world_to_camera_view
    detail=name in ['linford_entry','hayden_entry','linford_cornice','hayden_order']
    framed=None
    if not detail:
        visible_objects=[o for o in native+imported+context if not o.hide_render]
        assert visible_objects
        for attempt in range(22):
            bpy.context.view_layer.update()
            projected=[world_to_camera_view(scene,camera,o.matrix_world@Vector(corner)) for o in visible_objects for corner in o.bound_box]
            framed=all(p.z>0 and .035<=p.x<=.965 and .035<=p.y<=.965 for p in projected)
            if framed:break
            factor=max(1.08,max(max(abs(p.x-.5),abs(p.y-.5))/.46 for p in projected))
            if scale:camera.data.ortho_scale*=factor
            else:camera.location=Vector(target)+(camera.location-Vector(target))*factor
        assert framed,(name,'complete actual bounds remain outside native review frame')
    scene.render.filepath=str(OUT/(name+'.png'));bpy.ops.render.render(write_still=True)
    p=OUT/(name+'.png');captures.append({'path':p.name,'raw_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'buildings':visible,'roundtrip':roundtripped,'camera':list(camera.location),'ortho_scale':float(camera.data.ortho_scale) if camera.data.type=='ORTHO' else None,'target':list(target),'complete_model_framed':framed,'intentional_detail_crop':detail})
shoot('linford_entry',['site_nbr_w'],True,(-56.7,18,3.1),(-56.7,23.65,.8),5.6,(1000,1100))
result={'evidence_class':'INERT','scope':'Exact native/export round-trip triangle-position multisets and actual targeted native renders, with retained original mast/aerial/tank/beacon hardware as context. Images await actual inspection. No runtime, route, loaded mipmap, cost or artistic acceptance.',
        'roundtrip':roundtrip,'context_bounds':[dict(name=o.name,lo=[min((o.matrix_world@Vector(c))[i] for c in o.bound_box) for i in range(3)],hi=[max((o.matrix_world@Vector(c))[i] for c in o.bound_box) for i in range(3)]) for o in context],'context_meshes':len(context),'context_bindings':context_bindings,'support_bindings':support_bindings,'captures':captures}
(OUT/'native_review.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print('OPPOSING_REVIEW_READY',len(captures),len(context),flush=True)
