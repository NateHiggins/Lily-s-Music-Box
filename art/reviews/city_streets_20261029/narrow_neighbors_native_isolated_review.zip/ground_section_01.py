from pathlib import Path
import json,struct,hashlib,numpy as np
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent
DT={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'};WD={'SCALAR':1,'VEC3':3}
def read(name):
 p=ROOT/'game/assets/props'/f'{name}.glb';raw=p.read_bytes();off=12
 while off<len(raw):
  n,k=struct.unpack_from('<II',raw,off);off+=8;b=raw[off:off+n];off+=n
  if k==0x4e4f534a:d=json.loads(b)
  elif k==0x004e4942:binary=b
 def acc(i):
  a=d['accessors'][i];v=d['bufferViews'][a['bufferView']];dt=np.dtype(DT[a['componentType']]);w=WD[a['type']]
  return np.ndarray((a['count'],w),dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',w*dt.itemsize),dt.itemsize)).copy()
 assert all('children' not in n for n in d['nodes']),name
 rows=[]
 for n in d['nodes']:
  if 'mesh' not in n or 'water_clear' in n.get('name',''):continue
  assert not any(k in n for k in ['matrix','rotation','scale']),(name,n)
  for prim in d['meshes'][n['mesh']]['primitives']:
   v=acc(prim['attributes']['POSITION']).astype(float)+n.get('translation',[0,0,0]);i=acc(prim['indices']).ravel().reshape(-1,3)
   # GLB positions are already Godot building-frame XYZ. Registered PI yaw
   # and translation(0,0,-11.65), then invert city street b2g/threshold.
   v[:,0]*=-1;v[:,2]=-v[:,2]-11.65
   v=np.stack([v[:,0],-v[:,2]-9.795,v[:,1]],axis=1)
   tri=v[i];rows.append((n['name'],tri,tri.min(axis=1),tri.max(axis=1)))
 return rows,{'path':str(p),'sha256':hashlib.sha256(raw).hexdigest()}
assets={};bindings=[]
for name in ['orison_ground','city_ground_apron','city_foundations','front_pavement']:
 assets[name],binding=read(name);bindings.append(binding)
def query(x,y):
 hits=[]
 for asset,parts in assets.items():
  for name,tri,lo,hi in parts:
   mask=(lo[:,0]<=x+1e-7)&(hi[:,0]>=x-1e-7)&(lo[:,1]<=y+1e-7)&(hi[:,1]>=y-1e-7)
   t=tri[mask]
   if not len(t):continue
   a=t[:,0];u=t[:,1]-a;v=t[:,2]-a;det=u[:,0]*v[:,1]-u[:,1]*v[:,0];valid=abs(det)>1e-10
   t=t[valid];a=a[valid];u=u[valid];v=v[valid];det=det[valid]
   b=((x-a[:,0])*v[:,1]-(y-a[:,1])*v[:,0])/det;c=(u[:,0]*(y-a[:,1])-u[:,1]*(x-a[:,0]))/det
   valid=(b>=-1e-6)&(c>=-1e-6)&(b+c<=1+1e-6)
   z=a[:,2]+b*u[:,2]+c*v[:,2]
   for value in z[valid]:
    if -4<float(value)<1:hits.append({'asset':asset,'part':name,'z':round(float(value),7)})
 return sorted(hits,key=lambda r:r['z'],reverse=True)
points=[]
for id,rect in [('site_nbr_w',[-57.8,23,-53.4,47]),('site_nbr_e',[16.455,-12,20.855,12])]:
 for x in np.linspace(rect[0]+.2,rect[2]-.2,5):
  for dy in [-1.5,-.85,-.05,.05,.5]:
   y=rect[1]+dy;hits=query(float(x),y)
   points.append({'building':id,'city_source_xy':[round(float(x),5),y],'surface_below_1m':hits[:8]})
result={'evidence_class':'INERT','method':'Read-only exported solid triangle vertical intersections; no capsule, continuous walk, lighting or runtime acceptance. Water excluded. Duplicate seams retained.','frame_derivation':{'door_center_building':[0,0,-11.65],'inside_center_building':[0,0,-10.45],'surface_point':[0,0,0],'surface_normal':[0,0,1],'outward_building':[0,0,-1],'registered_yaw_radians':'PI','registered_translation':[0,0,-11.65],'street_threshold_z':9.795,'conversion':'building Godot[x,y,z] -> city source[-x,z+1.855,y]'},'bindings':bindings,'sections':points}
(OUT/'ground_section_01.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for id in ['site_nbr_w','site_nbr_e']:
 print(id)
 for r in points:
  if r['building']==id and r['city_source_xy'][0] in [-55.6,18.655]:print(r['city_source_xy'],r['surface_below_1m'][:2])
print('sections',len(points),'written',OUT/'ground_section_01.json')
