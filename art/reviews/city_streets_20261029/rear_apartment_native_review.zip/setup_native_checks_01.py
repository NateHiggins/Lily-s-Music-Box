from pathlib import Path
import json,ast,subprocess
root=Path('C:/ov/city');out=Path(__file__).parent
source=(root/'art/blender/scripts/build_city_elevation_lods.py').read_text(encoding='utf-8').split('vertices=[];faces=[]')[0]
source=source.replace("if r.get('architecture',{}).get('type')=='commercial_front'","if r['id']=='site_back_w'").replace('detail_level=1','detail_level=0')
script="""from pathlib import Path
import json,bpy,bmesh
root=Path('C:/ov/city');out=Path(__file__).parent
"""+"exec(compile("+repr(source)+",str(root/'art/blender/scripts/build_city_elevation_lods.py'),'exec'),dict(__file__=str(root/'art/blender/scripts/build_city_elevation_lods.py')))\n"
# Keep shared globals so the produced actual stock list can be inspected.
script="""from pathlib import Path
import json,bpy,bmesh
root=Path('C:/ov/city');out=Path(__file__).parent
space={'__file__':str(root/'art/blender/scripts/build_city_elevation_lods.py')}
"""+"exec(compile("+repr(source)+",space['__file__'],'exec'),space)\n"+"""rows=[]
for index,(name,key,vv,ff) in enumerate(space['stocks']):
 mesh=bpy.data.meshes.new('StockProof');mesh.from_pydata(vv,[],ff);mesh.update();bm=bmesh.new();bm.from_mesh(mesh);closed=all(e.is_manifold for e in bm.edges);volume=bm.calc_volume(signed=True)
 assert closed and volume>1e-10,(index,key,closed,volume)
 rows.append(dict(index=index,key=key,closed=closed,volume_m3=volume));bm.free();bpy.data.meshes.remove(mesh)
(out/'near_closed_stocks_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Actual new near closed-stock/manifold/signed-volume source checks,not runtime acceptance',stocks=rows,failures=[]),indent=2),encoding='utf-8');print('NEAR_CLOSED_STOCKS',len(rows),flush=True)
"""
(out/'check_near_closed_stocks_01.py').write_text(script,encoding='utf-8',newline='\n')
