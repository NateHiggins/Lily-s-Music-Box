from pathlib import Path
import json,ast,subprocess,sys
root=Path('C:/ov/city');out=Path('C:/ov/reports/city_streets_20261029/rear_apartment_01')
p=root/'art/data/city_elevations/source_plan.json';d=json.loads(p.read_text(encoding='utf-8'));b=next(b for b in d['buildings'] if b['id']=='site_back_w');b['description']='Five-storey AU Hawthorne-derived rear apartment:retained two-storey lower facade,quoined projecting centre,arched upper sash,modillion cornice and real open roof balustrade';b['floor_heights']=[5.94,3.14,3.16,3.16];b['architecture']={'type':'commercial_front','style':'hawthorne','front_side':0,'front_floor_count':4,'front_bays':7,'roof_depth_m':0,'precedent':'INERT:LPC LP1831 PDF124/125,printed117/118,Hawthorne Court,George H.Wells1921-22,five stories. PDF64/printed57 is c1940 entrance detail,not1928view. Upper quoined centre,arched fifth-storey sash,modillion cornice and roof balustrade adapted to18x6.4m parcel. Retained lower two-storey recipe and all original roof deck/plant datums govern the AU transposition. Registered running-bond brick explicitly substitutes for described Flemish bond; no reference pixels,lettering,new entrance or occupied-room authority.'};p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
for rel in ['art/blender/scripts/build_city_elevations.py','art/blender/scripts/build_city_elevation_lods.py']:
 p=root/rel;s=p.read_text(encoding='utf-8');s=s.replace("['site_ne1','site_nbr_w','site_nbr_e','site_sw2']","['site_ne1','site_nbr_w','site_nbr_e','site_sw2','site_back_w']")
 if rel.endswith('build_city_elevations.py'):
  s=s.replace("'hayden113':('roof_bitumen',)","'hayden113':('roof_bitumen',),'hawthorne':('roof_bitumen',)")
  s=s.replace("'hayden113','delano126']))","'hayden113','delano126','hawthorne']))")
 p.write_text(s,encoding='utf-8',newline='\n');ast.parse(s)
ast.parse((root/'art/blender/scripts/city_commercial_architecture.py').read_text(encoding='utf-8'))
s=Path('C:/ov/reports/city_streets_20261029/southwest_carriagehouse_01/run_native_build_01.py').read_text(encoding='utf-8');(out/'run_native_build_01.py').write_text(s,encoding='utf-8',newline='\n');subprocess.run([sys.executable,str(out/'run_native_build_01.py')],cwd=root,check=True)
