from pathlib import Path
import json,hashlib,zipfile,subprocess,sys
root=Path('C:/ov/city');out=Path(__file__).parent
review=json.loads((out/'native_review_01.json').read_text(encoding='utf-8'));assert len(review['captures'])==6 and len(review['roundtrip'])==18
inspection={'evidence_class':'INERT','scope':'Actual native form/UV review; no current loaded Godot/render-cost/collision-route/artistic acceptance.','inspected_images':[],'findings':['All6 current images inspected:two whole near/lower bodies with full original rooftop plant framed,near/lower open crown,retained lower facade,and upperorder.','Five-storey AU composition has two retained lower storeys and three owned upper floors. Central projection/quoins,round-headed top sash,modillion cornice and open stone balustrade are distinct from adjacent completed studies.','Original lower geometry and topcourse remain exactly placed,including all old windows/curtains. Native roof hardware is in the actual+6Y assembly,not the raw source rectangle.','Near31184/lower28048triangles keep all9 material partitions. Near1692stocks closedpositive; full lower12421stocks/595bearings/669panes pass.','Original preservation predicate failure on120upper sole-cap triangles exactly at5.94m retained; revisedlower-volume scope excludesonlythe shared boundaryplane,with2retainedlimestone topcourse triangles independently exact.','No reference photograph/PDF pixels baked,projected,imported or committed. LPC describes surviving1993 fabric andc1940entrance photo,not1928proportions. Exact18x6.4m AU registration and old plant datums govern. Running-bond registered brick explicitly substitutes for described Flemish bond.','Runtime bench updated for94 rear panes/no scenic portal/openrail gap/post/rail controls,not yet compiled/run. Canonical current whole-world OOM failure is unrelated evidence,not a pass or attributed to this asset.'],'static_checks':{'source_preflights':4,'source_preflight_failures':0,'python_city_tools_tests':14,'python_tools_test_failures':0,'uv_assets':2,'uv_surface_failures':0,'reader_new':0,'protected_unchanged':17}}
for c in review['captures']:
 p=out/c['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==c['sha256'];inspection['inspected_images'].append(c)
(out/'actual_native_inspection_01.json').write_text(json.dumps(inspection,indent=2),encoding='utf-8',newline='\n')
files={}
for p in out.iterdir():
 if not p.is_file():continue
 if p.suffix in ['.json','.py','.log'] or (p.suffix=='.png' and p.name.startswith('city_elevations_')):files[p.name]=p.read_bytes()
for rel in ['art/blender/scripts/city_commercial_architecture.py','art/blender/scripts/build_city_elevations.py','art/blender/scripts/build_city_elevation_lods.py','art/blender/scripts/build_city_closure.py','art/data/city_elevations/source_plan.json','game/tests/v2_city_elevation_bench.gd','game/tests/fixtures/orison_city_elevations.json','game/tests/fixtures/orison_city_elevations_lod1.json','game/data/orison_v2/exterior/city_elevations.json']:
 files['frozen_sources/'+rel]=(root/rel).read_bytes()
assert not any(k.endswith('.pdf') or k.startswith('LP1831_page_') or k.endswith('.glb') for k in files)
ziprel='art/reviews/city_streets_20261029/rear_apartment_native_review.zip';zp=root/ziprel
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for k,v in sorted(files.items()):z.writestr(k,v)
with zipfile.ZipFile(zp) as z:
 assert z.testzip() is None
 assert all(z.read(k)==v for k,v in files.items())
entry={'path':ziprel,'sha256':hashlib.sha256(zp.read_bytes()).hexdigest(),'members':len(files),'bytes':zp.stat().st_size,'evidence_class':'INERT','scope':'Native rear-west architecture and exact retained lower geometry proof. No current loaded/route/render-cost or artistic acceptance.','files':{k:{'bytes':len(v),'raw_sha256':hashlib.sha256(v).hexdigest()} for k,v in sorted(files.items())}}
p=root/'art/reviews/city_streets_20261029/manifest.json';m=json.loads(p.read_text(encoding='utf-8'));m['rear_apartment_native_archive']=entry;p.write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8',newline='\n')
p=root/'design/V2_CITY_CONTEXT_REPORT_2026-10-19.md';s=p.read_text(encoding='utf-8');s+='''
REPORT - K-V2-CITY-REVAMP - 2026-10-30

Evidence class: **INERT**. Rear-west native construction,not runtime acceptance.

Starting checkpoint **d3bff66e16baff758922ef3b4480bd49380054fb**. The installed
rear-west18x6.4m apartment lies X[-30,-12]/Y[24.1,30.5],after its retained+6Y
assembly; raw sourceY[18.1,24.5] is not the installed placement. Two retained
lower storeys remain below5.94m. Three owned upper floors end15.4m;old deck
15.4..15.66,bulkhead and9 mast/aerial/beacon contacts keep their original seats.

The AU upper form derives from Hawthorne Court,George H.Wells1921-22:
LPC **LP1831**,PDF124/125 (printed117/118) describes quoined central sections,
arched fifth-storey glazing,modillion cornices and roof balustrades. PDF64 is
an explicitly c1940 entrance detail,not a1928 photograph;no full upper-elevation
photograph was inspected. Exact dimensions follow the installed fictional
parcel. Registered running-bond brick substitutes for described Flemish bond;
no historical bond/height/condition claim. Source photos/PDFs remain external.

Actual native construction includes a slightly projecting centre and closed
returns,alternating stone quoins,six-over-one upper sash,real round-head top
apertures,modillion cornice and an open front stone balustrade with closed
manufactured balusters/posts/rails. Rear/side parapets and old deck remain.
Lower windows use the unchanged existing facade recipe;copying the original
closure base would instead have filled them. No new door,occupied interior,
shop/access/weather/narrative/save/clock/companion authority or material key.

Actual near/lower bodies have **31184/28048 triangles**,nine material parts each.
All6 native views were inspected;18 near/export/lower part comparisons match
exact float32 triangle-position multisets.1692 new near stocks are closed and
positive. Complete lower12421 stocks/595 bearings/669 panes pass;near1205
bearings/2551 panes/126 roof/12 return samples pass. Two GLB UV audits,four
source preflights,14 Python city tools tests,reader NEW0 and17 protected paths
pass/remain unchanged. These are native/static diagnostics,not runtime proof.

Actual retained lower volume preserves **12894 exact world-space triangles**
and two limestone top-course triangles. The first predicate incorrectly counted
120 retired upper-wall sole-cap triangles on the shared5.94m plane as lower
construction;its original failure/script are preserved. Corrected comparison
isolates the lower volume and independently checks the limestone top course;
no tolerance increase or runtime waiver.270 unrelated near and155 existing
lower parts,24 other profiles and five ground/street assets are exact.

Existing isolated bench now expects94 rear panes,zero new portals,and open
balustrade gap/post/rail controls in the installed+6Y placement. It has NOT yet
been compiled/run. Godot/render cost,loaded materials/mips,LOD transitions,
standing collision/access and composed lighting/artistic qualification remain
open. Canonical whole-surface renewal separately failed after255seconds with
Vulkan OUT_OF_DEVICE_MEMORY/native0xc0000005 and no runtime_contract;original
logs/partialframes stay canonical-owned. Do not promote that failure or assign
it to this new native asset. No new texture atlas was allocated here.

Portable **rear_apartment_native_review.zip** indexes every member hash in the
existing manifest;CRC/member bytes verified. Six actual native images,original
comparison failure,source/provenance and UV evidence retained. Source reference
pixels/PDFs and duplicate production meshes excluded. External source evidence
is **C:/ov/reports/city_streets_20261029/rear_apartment_01**. Published tally remains
**21/149** until required canonical publication/qualification is actually done.
''';p.write_text(s,encoding='utf-8',newline='\n')
p=root/'TASKS.md';s=p.read_text(encoding='utf-8');start=s.index('- **K-V2-CITY-REVAMP');end=s.index('\n',start)
line='- **K-V2-CITY-REVAMP — IMMEDIATE PRIORITY: complete the V2 cityscape.** Published canonical **c574d0b8** qualifies **21/149 technical building studies;128 remain**,not full-city/artistic/save acceptance. Work stays in **C:/ov/city**,**codex/v2-city-20261029**,original base3ea80715. Preserve installed Orison,shops/access,traffic,450m temporary radius and all narrative/save/calendar/companion/weather owners. Corrected Bodega+west actual route256/8/0 and isolated7086/0 await canonical publication;whole-surface renewal failed Vulkan OOM/native crash with no contract. SW2 native+isolated packetd3bff66e passes7162/0;39.929ms firstcase wall spike and standing/composed qualification stay open. New rear-west Hawthorne-derived upper body preserves exact lower volume and roof plant;native near/lower31184/28048tri,6 views,UV/preflights/readerNEW0 pass;loaded/LOD/access/cost/artistic checks remain open. Continue remaining buildings/bodyLODs,bridge/Manhattan,elevated station access,yard/steam,waterfront/DutchKills,streets/gaslight and whole-area support/performance/qualification. Canonical439ms walking spike and prior316.861ms/Windows hang remain unresolved;isolated timings are not a city budget. [Construction,evidence and limitations](design/V2_CITY_CONTEXT_REPORT_2026-10-19.md).'
s=s[:start]+line+s[end:];p.write_text(s,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'tools/lint_design_doc.py','design/V2_CITY_CONTEXT_REPORT_2026-10-19.md'],cwd=root,check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
paths=['TASKS.md','design/V2_CITY_CONTEXT_REPORT_2026-10-19.md','art/blender/city_closure.blend','art/blender/city_closure_construction.json','art/blender/city_elevations.blend','art/blender/city_elevations_construction.json','art/blender/city_elevations_lod1.blend','art/blender/city_elevations_lod1_construction.json','art/blender/city_streets.blend','art/blender/city_streets_construction.json','art/blender/scripts/build_city_elevations.py','art/blender/scripts/build_city_elevation_lods.py','art/blender/scripts/city_commercial_architecture.py','art/data/city_elevations/source_plan.json','game/assets/props/city_elevations.glb','game/assets/props/city_elevations_lod1.glb','game/data/orison_v2/exterior/city_elevations.json','game/tests/fixtures/orison_city_closure.json','game/tests/fixtures/orison_city_elevations.json','game/tests/fixtures/orison_city_elevations_lod1.json','game/tests/fixtures/orison_city_streets.json','game/tests/v2_city_elevation_bench.gd',ziprel,'art/reviews/city_streets_20261029/manifest.json']
subprocess.run(['git','add','--']+paths,cwd=root,check=True)
subprocess.run(['git','commit','-m','Build Hawthorne-derived rear apartment above retained lower facade'],cwd=root,check=True)
subprocess.run(['git','push','origin','codex/v2-city-20261029'],cwd=root,check=True)
print('ARCHIVE',entry['members'],entry['bytes'],entry['sha256'],flush=True)
