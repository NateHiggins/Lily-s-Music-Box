from pathlib import Path
import ast,json,struct,hashlib,subprocess,collections,itertools,numpy as np
root=Path('C:/ov/city');out=Path(__file__).parent
s=(out/'check_preservation_02.py').read_text(encoding='utf-8');t=ast.parse(s);exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),'<existing projection/triangle readers>','exec'))
p=Path('C:/ov/reports/city_streets_20261029/bodega_frontage_reconciliation_01/check_preservation_01.py');t=ast.parse(p.read_text(encoding='utf-8-sig'));exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),'<existing accessor projection>','exec'))
baseline=json.loads((out/'baseline_01.json').read_text(encoding='utf-8'));result={'evidence_class':'INERT','scope':'Other building parts exact; changedtarget retainedupper/rear/side geometry compared at existing0.1mmphysicaltolerance,measured actualfloat32recentringerror. Frontlowerintentionalrefitnotpreservationclaim.','parts':{}}
for family in ['city_elevations','city_elevations_lod1']:
 a=baseline['parts'][family];b=projection((root/f'game/assets/props/{family}.glb').read_bytes());keys=[k for k in a if not k.startswith('site_back_w__')];failed=[k for k in keys if a[k]!=b.get(k)];assert not failed,failed;result['parts'][family]={'unaffected_exact':len(keys),'failures':failed}
for family,expected in baseline['assets'].items():assert hashlib.sha256((root/f'game/assets/props/{family}.glb').read_bytes()).hexdigest()==expected,family
result['other_assets_exact']=len(baseline['assets']);old_profiles={b['id']:b for b in baseline['profiles']['buildings']};profiles=json.loads((root/'art/data/city_elevations/source_plan.json').read_text(encoding='utf-8'))['buildings'];assert all(p==old_profiles[p['id']] for p in profiles if p['id']!='site_back_w');result['other_profiles_exact']=24
old=triangles(subprocess.run(['git','show','1a6b09d2:game/assets/props/city_elevations.glb'],cwd=root,capture_output=True,check=True).stdout);new=triangles((root/'game/assets/props/city_elevations.glb').read_bytes())
tol=.0001;shifts=list(itertools.product([-1,0,1],repeat=3));results=[]
for scope,include in [('retained_lower_rear_side',lambda t:min(v[2] for v in t)<5.93999 and max(v[2] for v in t)<=5.94001 and max(v[1] for v in t)>=18.5),('retained_upper_and_crown',lambda t:min(v[2] for v in t)>=5.93999)]:
 for key,tt in old.items():
  a=[np.array(sorted(tuple(v) for v in t)) for t in tt if include(t)];b=[np.array(sorted(tuple(v) for v in t)) for t in new[key] if include(t)]
  if not a:continue
  buckets=collections.defaultdict(list)
  for i,t in enumerate(b):buckets[tuple(np.floor(t.mean(axis=0)/tol).astype(int))].append(i)
  used=set();max_error=0.;missing=0
  for t in a:
   cell=tuple(np.floor(t.mean(axis=0)/tol).astype(int));match=None;best=tol
   for shift in shifts:
    for j in buckets.get(tuple(cell[i]+shift[i] for i in range(3)),[]):
     if j in used:continue
     error=float(np.abs(t-b[j]).max())
     if error<best:best=error;match=j
   if match is None:missing+=1
   else:used.add(match);max_error=max(max_error,best)
  row={'scope':scope,'part':key,'old_triangles':len(a),'new_triangles':len(b),'missing':missing,'unmatched_new':len(b)-len(used),'max_position_difference_m':max_error};results.append(row);assert not missing and len(b)==len(used),row
result['retained_target_geometry']=results;result['max_measured_float32_recentring_m']=max(r['max_position_difference_m'] for r in results)
(out/'preservation_04.json').write_text(json.dumps(result,indent=2),encoding='utf-8',newline='\n');print('PRESERVATION',result['parts'],'targetcomparisons',len(results),'maxerror_m',result['max_measured_float32_recentring_m'])
