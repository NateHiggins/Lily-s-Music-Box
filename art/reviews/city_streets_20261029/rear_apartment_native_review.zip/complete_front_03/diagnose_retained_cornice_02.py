from pathlib import Path
import bpy,bmesh,json,subprocess,ast,struct,hashlib,collections,numpy as np
from mathutils import Vector
root=Path('C:/ov/city');out=Path(__file__).parent
s=(out/'check_preservation_02.py').read_text(encoding='utf-8');t=ast.parse(s);exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='triangles'],type_ignores=[]),'<actual exported triangles>','exec'))
old=triangles(subprocess.run(['git','show','1a6b09d2:game/assets/props/city_elevations.glb'],cwd=root,capture_output=True,check=True).stdout)['site_back_w__limestone']
bpy.ops.wm.open_mainfile(filepath=str(root/'art/blender/city_closure.blend'));bpy.context.view_layer.update();obj=next(o for o in bpy.data.collections['ClosedConstruction'].objects if o.name=='site_back_w_bcorn__RetainedStock');mesh=obj.data.copy();mesh.transform(obj.matrix_world)
points=[tuple(v.co) for v in mesh.vertices];source=set(points);expected=collections.Counter(tuple(sorted(tuple(p) for p in tri)) for tri in old if all(tuple(v) in source for v in tri));print('SOURCE',len(points),len(mesh.polygons),'oldcornice',sum(expected.values()),flush=True);assert expected
rows=[]
for quad in ['BEAUTY','FIXED','ALTERNATE','SHORT_EDGE','LONG_EDGE']:
 for ngon in ['BEAUTY','EAR_CLIP']:
  bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.triangulate(bm,faces=list(bm.faces),quad_method=quad,ngon_method=ngon);bm.verts.ensure_lookup_table();actual=collections.Counter(tuple(sorted(tuple(v.co) for v in f.verts)) for f in bm.faces);bm.free();r=dict(quad=quad,ngon=ngon,triangles=sum(actual.values()),missing=sum((expected-actual).values()),extra=sum((actual-expected).values()));rows.append(r);print(r,flush=True)
mesh.calc_loop_triangles();actual=collections.Counter(tuple(sorted(tuple(mesh.vertices[i].co) for i in t.vertices)) for t in mesh.loop_triangles);rows.append(dict(quad='calc_loop_triangles',triangles=sum(actual.values()),missing=sum((expected-actual).values()),extra=sum((actual-expected).values())))
(out/'retained_cornice_triangulation_diagnostic_02.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Read-only actual frozen exported cornice versus current native closure stock triangulation candidates;no geometry or acceptance modified',source_vertices=len(points),source_faces=len(mesh.polygons),old_triangles=sum(expected.values()),candidates=rows),indent=2),encoding='utf-8');print(rows[-1],flush=True)
