from pathlib import Path
import ast,json,struct,hashlib,numpy as np
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent;DT={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'};WD={'SCALAR':1,'VEC3':3}
s=Path('C:/ov/reports/city_streets_20261029/southwest_carriagehouse_01/measure_installed_sections_01.py').read_text(encoding='utf-8');t=ast.parse(s);exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name in ['read','read_streets','query']],type_ignores=[]),'<actual exported section helpers>','exec'))
s=Path('C:/ov/reports/city_streets_20261029/southwest_carriagehouse_01/check_entry_sections_03.py').read_text(encoding='utf-8');t=ast.parse(s);exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='blocked'],type_ignores=[]),'<actual segment intersection helper>','exec'))
plans={p['id']:p for p in json.loads((ROOT/'art/data/city_elevations/source_plan.json').read_text(encoding='utf-8'))['buildings']};base={};bindings=[]
for name in ['orison_ground','city_ground_apron','city_foundations','front_pavement']:
 base[name],b=read(name);bindings.append(b)
base['city_streets'],b=read_streets('city_streets');bindings.append(b)
sections=[];rays=[]
for family in ['city_elevations','city_elevations_lod1']:
 rows,b=read_streets(family);bindings.append(b);parts=[]
 for name,tri,lo,hi in rows:
  owner=name.split('__')[0];offset=np.array(plans[owner].get('assembly_translation_m',[0,0,0]));tri=tri+offset;parts.append((name,tri,tri.min(axis=1),tri.max(axis=1)))
 assets=dict(base);assets[family]=parts
 stations=[(22.8,-.02175),(23.15,.139125),(23.45,.30),(23.75,.30),(23.90,.30)]
 for yy,zz in stations:
  for dx in [-.45,0,.45]:
   hits=query(-21+dx,yy);actual=hits[0]['z'] if hits else None;ok=actual is not None and abs(actual-zz)<.0001;row=dict(family=family,point=[-21+dx,yy],expected_z=zz,actual_z=actual,pass_section=ok,hits=hits[:3]);sections.append(row)
   assert ok,row
 for yy,zz in stations[1:]:
  a=[-21,20.5,2.0];b=[-21,yy,zz+.001];hits=blocked(a,b,assets);rays.append(dict(family=family,a=a,b=b,blockers=hits));assert not hits,rays[-1]
result=dict(evidence_class='INERT',scope='Actual exported combined ground,registered city bodies and new entry support/optical rays. Uses all source assembly translations. No standing capsule/continuous route/runtime acceptance.',bindings=bindings,sections=sections,optical_rays=rays,failures=[])
(OUT/'actual_entry_sections_02.json').write_text(json.dumps(result,indent=2),encoding='utf-8',newline='\n');print('ENTRY_SECTIONS',len(sections),'OPTICAL_RAYS',len(rays),'failures0')
