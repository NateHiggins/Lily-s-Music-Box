from pathlib import Path
import ast,json,struct,hashlib,subprocess,collections,itertools,numpy as np
root=Path('C:/ov/city');out=Path(__file__).parent
s=(out/'check_preservation_02.py').read_text(encoding='utf-8');t=ast.parse(s);exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),'<existing projection/triangle readers>','exec'))
p=Path('C:/ov/reports/city_streets_20261029/bodega_frontage_reconciliation_01/check_preservation_01.py');t=ast.parse(p.read_text(encoding='utf-8-sig'));exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),'<existing accessor projection>','exec'))
baseline=json.loads((out/'baseline_01.json').read_text(encoding='utf-8'));result={'evidence_class':'INERT','scope':'Other building parts exact; changedtarget retainedupper/rear/side geometry compared at existing0.1mmphysicaltolerance,measured actualfloat32recentringerror. Frontlowerintentionalrefitnotpreservationclaim.','parts':{}}
for family in ['city_elevations','city_elevations_lod1']:
 a=baseline['parts'][family];b=projection((root/f'game/assets/props/{family}.glb').read_bytes());keys=[k for k in a if not k.startswith('site_back_w__')];failed=[k for k in keys if a[k]!=b.get(k)];assert not failed,failed;result['parts'][family]={'unaffected_exact':len(keys),'failures':failed}
for family,expected in baseline['assets'].items():assert hashlib.sha256((root/f'game/assets/props/{family}.glb').read_bytes()).hexdigest()==expected,family
result['other_assets_exact']=len(baseline['assets']);old_profiles={b['id']:b for b in baseline['profiles']['buildings']};profiles=json.loads((root/'art/data/city_elevations/source_plan.json').read_text(encoding='utf-8'))['buildings'];assert all(p==old_profiles[p['id']] for p in profiles if p['id']!='site_back_w');result['other_profiles_exact']=24

from mathutils import Vector
from mathutils.bvhtree import BVHTree
old=triangles(subprocess.run(['git','show','1a6b09d2:game/assets/props/city_elevations.glb'],cwd=root,capture_output=True,check=True).stdout);new=triangles((root/'game/assets/props/city_elevations.glb').read_bytes());results=[]
for scope,include in [('retained_lower_rear_side',lambda t:min(v[2] for v in t)<5.93999 and max(v[2] for v in t)<=5.94001 and max(v[1] for v in t)>=18.5),('retained_upper_and_crown',lambda t:min(v[2] for v in t)>=5.93999)]:
 for key,tt in old.items():
  a=[t for t in tt if include(t)];b=[t for t in new[key] if include(t)]
  if not a:continue
  av={tuple(v) for t in a for v in t};bv={tuple(v) for t in b for v in t};assert av==bv,(scope,key,'vertex positions changed')
  ca=collections.Counter(tuple(sorted(tuple(v) for v in t)) for t in a);cb=collections.Counter(tuple(sorted(tuple(v) for v in t)) for t in b)
  area=lambda ts:sum(float(np.linalg.norm(np.cross(t[1]-t[0],t[2]-t[0]))*.5) for t in ts)
  aa=area(a);ba=area(b);assert abs(aa-ba)<1e-5,(scope,key,aa,ba)
  def bvh(ts):
   vv=[Vector(v) for t in ts for v in t];return BVHTree.FromPolygons(vv,[tuple(range(i,i+3)) for i in range(0,len(vv),3)],all_triangles=True)
  maximum=0.;samples=0
  for src,dst in [(a,b),(b,a)]:
   tree=bvh(dst)
   for tri in src:
    v=[Vector(p) for p in tri]
    for weights in [(1/3,1/3,1/3),(.6,.2,.2),(.2,.6,.2),(.2,.2,.6)]:
     point=sum((v[i]*weights[i] for i in range(3)),Vector());closest,normal,index,distance=tree.find_nearest(point)
     if closest is None or distance>=.0001:
      # Independent float64 point-to-triangle check diagnoses BVH precision;
      # do not change physical tolerance or hide the original BVH result.
      pp=np.array(point,dtype=np.float64);tt=np.array(dst,dtype=np.float64)
      pa,pb,pc=tt[:,0],tt[:,1],tt[:,2];ab=pb-pa;ac=pc-pa;nn=np.cross(ab,ac);n2=np.einsum('ij,ij->i',nn,nn)
      projected=pp-nn*(np.einsum('ij,ij->i',pp-pa,nn)/np.maximum(n2,1e-300))[:,None]
      vp=projected-pa;d00=np.einsum('ij,ij->i',ab,ab);d01=np.einsum('ij,ij->i',ab,ac);d11=np.einsum('ij,ij->i',ac,ac);d20=np.einsum('ij,ij->i',vp,ab);d21=np.einsum('ij,ij->i',vp,ac);den=d00*d11-d01*d01
      bary_v=(d11*d20-d01*d21)/np.maximum(den,1e-300);w=(d00*d21-d01*d20)/np.maximum(den,1e-300);inside=(den>1e-24)&(bary_v>=-1e-10)&(w>=-1e-10)&(bary_v+w<=1+1e-10)
      distances=np.where(inside,np.linalg.norm(projected-pp,axis=1),np.inf)
      for left,right in [(pa,pb),(pb,pc),(pc,pa)]:
       edge=right-left;f=np.clip(np.einsum('ij,ij->i',pp-left,edge)/np.maximum(np.einsum('ij,ij->i',edge,edge),1e-300),0,1);distances=np.minimum(distances,np.linalg.norm(left+edge*f[:,None]-pp,axis=1))
      exact=float(distances.min());print('BVH_DIAGNOSTIC',scope,key,'bvh',distance,'independent_float64',exact,flush=True);assert exact<.0001,(scope,key,list(point),distance,exact);distance=exact
     assert closest is not None and distance<.0001,(scope,key,list(point),distance)
     maximum=max(maximum,distance);samples+=1
  row=dict(scope=scope,part=key,old_triangles=len(a),new_triangles=len(b),exact_world_vertex_positions=len(av),retessellated_triangle_count=sum((ca-cb).values()),old_surface_area_m2=aa,new_surface_area_m2=ba,bidirectional_surface_samples=samples,max_surface_difference_m=maximum);results.append(row)
result['retained_target_geometry']=results;result['scope']='Actual retainedtarget surface comparison at the unchanged0.1mmphysicaltolerance,including exact worldvertexsets,equalarea andbidirectionalBVH interior sampling. NativeBEAUTYretessellation neednot preservecoplanardiagonals. Originalstricttrianglepredicatefailure retained. No runtimeacceptance.'
(out/'preservation_10.json').write_text(json.dumps(result,indent=2),encoding='utf-8',newline='\n');print('PRESERVED_SURFACES',len(results),'samples',sum(r['bidirectional_surface_samples'] for r in results),'retessellated',sum(r['retessellated_triangle_count'] for r in results),'maxdifference_m',max(r['max_surface_difference_m'] for r in results),flush=True)
