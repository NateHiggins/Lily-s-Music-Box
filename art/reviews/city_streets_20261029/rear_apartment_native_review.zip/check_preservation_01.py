from pathlib import Path
import ast,struct,json,hashlib,subprocess,collections,numpy as np
root=Path('C:/ov/city');out=Path(__file__).parent;s=Path('C:/ov/reports/city_streets_20261029/bodega_frontage_reconciliation_01/check_preservation_01.py').read_text(encoding='utf-8-sig');tree=ast.parse(s);exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),'<projection>','exec'))
baseline=json.loads((out/'baseline_01.json').read_text(encoding='utf-8'));result={'evidence_class':'INERT','scope':'Actual export comparison against frozen previous checkpoint; no runtime/acceptance.','parts':{},'other_assets':{}}
for family in ['city_elevations','city_elevations_lod1']:
 a=baseline['parts'][family];b=projection((root/f'game/assets/props/{family}.glb').read_bytes());unchanged=[k for k in a if not k.startswith('site_back_w__')];failed=[k for k in unchanged if a[k]!=b.get(k)];assert not failed,failed;result['parts'][family]={'unaffected_exact':len(unchanged),'added':sorted(b.keys()-a.keys()),'failures':failed}
for family,expected in baseline['assets'].items():
 actual=hashlib.sha256((root/f'game/assets/props/{family}.glb').read_bytes()).hexdigest();assert actual==expected,family;result['other_assets'][family]=actual
actual=json.loads((root/'art/data/city_elevations/source_plan.json').read_text(encoding='utf-8'));old={b['id']:b for b in baseline['profiles']['buildings']};assert all(b==old[b['id']] for b in actual['buildings'] if b['id']!='site_back_w');result['unchanged_profiles']=24

def triangles(raw):
 size=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+size]);binary=raw[28+size:]
 def acc(i):
  a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dt=np.dtype({5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1'}[a['componentType']]);w={'SCALAR':1,'VEC3':3}[a['type']];return np.ndarray((a['count'],w),dt,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',w*dt.itemsize),dt.itemsize)).copy()
 rows={}
 for n in doc['nodes']:
  if 'mesh' not in n or not n['name'].startswith('site_back_w__'):continue
  assert not any(k in n for k in ['matrix','rotation','scale'])
  for prim in doc['meshes'][n['mesh']]['primitives']:
   v=acc(prim['attributes']['POSITION']).astype(float)+n.get('translation',[0,0,0]);i=acc(prim['indices']).ravel().reshape(-1,3);v=np.stack([v[:,0],-v[:,2],v[:,1]],axis=1);rows[n['name']]=v[i]
 return rows
oldraw=subprocess.run(['git','show',baseline['head']+':game/assets/props/city_elevations.glb'],cwd=root,capture_output=True,check=True).stdout;oldtri=triangles(oldraw);newtri=triangles((root/'game/assets/props/city_elevations.glb').read_bytes());base=[]
for key,t in oldtri.items():
 a=collections.Counter(tuple(sorted(tuple(p) for p in tri)) for tri in t if max(v[2] for v in tri)<=5.94001);b=collections.Counter(tuple(sorted(tuple(p) for p in tri)) for tri in newtri.get(key,[]) if max(v[2] for v in tri)<=5.94001);missing=a-b;extra=b-a;unexpected=[tri for tri in extra if not all(abs(v[2]-5.94)<1e-5 for v in tri)];row={'part':key,'original_lower_triangles':sum(a.values()),'missing':sum(missing.values()),'new_boundary_contact_triangles':sum(extra.values()),'unexpected_nonboundary_extra':len(unexpected)};base.append(row)
 if missing or unexpected:
  (out/'lower_preservation_failure_01.json').write_text(json.dumps(row,indent=2),encoding='utf-8');raise AssertionError(row)
result['retained_lower_exact_world_triangles']=base
(out/'preservation_01.json').write_text(json.dumps(result,indent=2),encoding='utf-8',newline='\n');print(result)
