from pathlib import Path
import bpy,json,collections,hashlib,math
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
ROOT=Path('C:/ov/city');OUT=Path(__file__).parent;plans={p['id']:p for p in json.loads((ROOT/'art/data/city_elevations/source_plan.json').read_text(encoding='utf-8'))['buildings']};bindings={};captures=[];roundtrips=[]
for family,collection in [('city_elevations','V2CityElevations'),('city_elevations_lod1','V2CityElevationReplacementBodies')]:
 path=ROOT/f'art/blender/{family}.blend';bindings[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest();bpy.ops.wm.open_mainfile(filepath=str(path))
 native=[o for o in bpy.data.collections[collection].objects if o.name.startswith('site_back_w__')];assert len(native)==9
 def triangles(o):
  o.data.calc_loop_triangles();return collections.Counter(tuple(sorted(tuple(float(c) for c in o.matrix_world@o.data.vertices[i].co) for i in tri.vertices)) for tri in o.data.loop_triangles)
 expected={o.name:triangles(o) for o in native};mats={o.name:o.data.materials[0] for o in native}
 for o in bpy.context.scene.objects:
  if o.type=='MESH':o.hide_render=True
 p=ROOT/f'game/assets/props/{family}.glb';bindings[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest();before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(p));bpy.context.view_layer.update();imported=[]
 for o in [o for o in bpy.data.objects if o not in before and o.type=='MESH']:
  name=o.name.split('.')[0];o.hide_render=not name.startswith('site_back_w__')
  if o.hide_render:continue
  assert triangles(o)==expected[name],(family,name,'roundtrip mismatch');assert len(o.data.uv_layers)==1;o.data.uv_layers.active.name='Metres';o.data.materials.clear();o.data.materials.append(mats[name]);o.location+=Vector(plans['site_back_w']['assembly_translation_m']);imported.append(o);roundtrips.append(dict(family=family,part=name,exact_float32_triangle_positions=True,triangles=sum(expected[name].values())))
 context=[]
 for kind in ['masts','aerials','tanks','beacons']:
  p=ROOT/f'art/blender/city_{kind}.blend';bindings[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
  with bpy.data.libraries.load(str(p),link=False) as (available,loaded):loaded.objects=[n for n in available.objects if n.startswith('site_back_w__') and 'ClosedFabricatedTree' not in n]
  for o in loaded.objects:
   if o.type!='MESH' or o.hide_render:continue
   bpy.context.scene.collection.objects.link(o);o.hide_set(False);o.hide_viewport=False;o.hide_render=False;o.location+=Vector(plans['site_back_w']['assembly_translation_m']);context.append(o)
 for image in bpy.data.images:
  if image.source!='FILE' or image.packed_file:continue
  p=ROOT/'game/assets/building/textures'/Path(image.filepath).name;assert p.is_file(),p;image.filepath=str(p);image.reload();assert min(image.size)>0
 scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.cycles.use_denoising=True;scene.render.threads_mode='FIXED';scene.render.threads=2;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX';scene.render.resolution_percentage=100
 world=bpy.data.worlds.new('Rear apartment review');world.use_nodes=True;scene.world=world;world.node_tree.nodes['Background'].inputs[0].default_value=(.16,.19,.24,1);world.node_tree.nodes['Background'].inputs[1].default_value=.6
 sun=bpy.data.objects.new('Review key',bpy.data.lights.new('Review key','SUN'));scene.collection.objects.link(sun);sun.rotation_euler=Vector((.4,.7,-1)).to_track_quat('-Z','Y').to_euler();sun.data.energy=2.5;sun.data.angle=.18
 camera=bpy.data.objects.new('Rear apartment camera',bpy.data.cameras.new('Rear apartment camera'));scene.collection.objects.link(camera);scene.camera=camera
 # No fabricated ground or gameplay room is introduced as review scenery.
 views=[('front_whole',(-17,9,14),(-21,27,11),29.,(1200,1100),False),('open_crown',(-32,16,23),(-21,26,15.7),22.,(1300,1000),True)]
 if family=='city_elevations':views += [('retained_lower',(-21,16,4),(-21,24.1,3.0),20.,(1400,900),True),('upper_order',(-18,15,13),(-21,24.1,11.9),15.,(1300,1100),True)]
 for label,at,target,scale,res,detail in views:
  camera.location=at;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO';camera.data.ortho_scale=scale;scene.render.resolution_x,scene.render.resolution_y=res;framed=None
  if not detail:
   for attempt in range(20):
    bpy.context.view_layer.update();points=[world_to_camera_view(scene,camera,o.matrix_world@Vector(c)) for o in imported+context for c in o.bound_box];framed=all(p.z>0 and .035<=p.x<=.965 and .035<=p.y<=.965 for p in points)
    if framed:break
    camera.data.ortho_scale*=1.12
   assert framed
  path=OUT/(family+'_'+label+'_01.png');scene.render.filepath=str(path);bpy.ops.render.render(write_still=True);captures.append(dict(path=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),family=family,whole_model_and_roof_framed=framed,intentional_detail_crop=detail,hardware_parts=len(context)))
assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==v for p,v in bindings.items())
(OUT/'native_review_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Actual saved native and exact float32 export review with actual unchanged roof fittings in installed+6Y placement. No ground/contact-controller/loaded material/runtime or artistic acceptance.',bindings=bindings,roundtrip=roundtrips,captures=captures),indent=2),encoding='utf-8',newline='\n');print('NATIVE_REAR_REVIEW',len(captures),len(roundtrips),flush=True)
