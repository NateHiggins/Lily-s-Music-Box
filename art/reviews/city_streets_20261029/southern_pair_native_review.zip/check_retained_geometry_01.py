from pathlib import Path
import ast,json,struct,hashlib,subprocess,collections,itertools,numpy as np
root=Path('C:/ov/city');out=Path(__file__).parent
import sys
identity=sys.argv[1]
p=Path('C:/ov/reports/city_streets_20261029/rear_apartment_01/check_preservation_02.py');t=ast.parse(p.read_text(encoding='utf-8').replace('site_back_w',identity));exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='triangles'],type_ignores=[]),'<existing actual target triangle reader>','exec'))
a=triangles(subprocess.run(['git','show','e8e456c9:game/assets/props/city_elevations.glb'],cwd=root,capture_output=True,check=True).stdout);b=triangles((root/'game/assets/props/city_elevations.glb').read_bytes());old=np.concatenate(list(a.values()));new=np.concatenate(list(b.values()));rows=[];tol=.0001;shifts=list(itertools.product([-1,0,1],repeat=3))
def point_distance(point,tt):
 pa,pb,pc=tt[:,0],tt[:,1],tt[:,2];ab=pb-pa;ac=pc-pa;nn=np.cross(ab,ac);n2=np.einsum('ij,ij->i',nn,nn);projected=point-nn*(np.einsum('ij,ij->i',point-pa,nn)/np.maximum(n2,1e-300))[:,None];vp=projected-pa
 d00=np.einsum('ij,ij->i',ab,ab);d01=np.einsum('ij,ij->i',ab,ac);d11=np.einsum('ij,ij->i',ac,ac);d20=np.einsum('ij,ij->i',vp,ab);d21=np.einsum('ij,ij->i',vp,ac);den=d00*d11-d01*d01;v=(d11*d20-d01*d21)/np.maximum(den,1e-300);w=(d00*d21-d01*d20)/np.maximum(den,1e-300);inside=(den>1e-24)&(v>=-1e-10)&(w>=-1e-10)&(v+w<=1+1e-10);distances=np.where(inside,np.linalg.norm(projected-point,axis=1),np.inf)
 for left,right in [(pa,pb),(pb,pc),(pc,pa)]:
  edge=right-left;f=np.clip(np.einsum('ij,ij->i',point-left,edge)/np.maximum(np.einsum('ij,ij->i',edge,edge),1e-300),0,1);distances=np.minimum(distances,np.linalg.norm(left+edge*f[:,None]-point,axis=1))
 return float(distances.min())
scopes=[('retained_bar_lower',lambda t:(t[:,:,2].max(axis=1)<=5.94001)&(t[:,:,2].min(axis=1)<5.93999))] if identity=='site_nbr_s2' else [('retained_se2_lower_rear_side',lambda t:(t[:,:,2].max(axis=1)<=7.14001)&(t[:,:,2].min(axis=1)<7.13999)&(t[:,:,1].max(axis=1)<-28.82)),('retained_se2_studio_and_upper_roof',lambda t:(t[:,:,2].min(axis=1)>=16.89999)&(t[:,:,2].max(axis=1)>16.90001)&(t[:,:,1].max(axis=1)<-28.82))]
for scope,include in scopes:
 maska=include(old);maskb=include(new)
 aa=old[maska];bb=new[maskb];catalog=[];cells=collections.defaultdict(list);maxvertex=0.
 def vertex_id(v,create):
  global maxvertex
  cell=tuple(np.floor(v/tol).astype(int));best=None;error=tol
  for shift in shifts:
   for j in cells.get(tuple(cell[i]+shift[i] for i in range(3)),[]):
    e=float(np.abs(v-catalog[j]).max())
    if e<error:best=j;error=e
  if best is not None:maxvertex=max(maxvertex,error);return best
  assert create,('retained vertex moved',scope,v.tolist())
  j=len(catalog);catalog.append(v);cells[cell].append(j);return j
 ca=collections.defaultdict(list);cb=collections.defaultdict(list)
 for tri in aa:ca[tuple(sorted(vertex_id(v,True) for v in tri))].append(tri)
 for tri in bb:cb[tuple(sorted(vertex_id(v,False) for v in tri))].append(tri)
 unmatched_a=[];unmatched_b=[];matched=0
 for k in ca.keys()|cb.keys():
  x=ca.get(k,[]);y=cb.get(k,[]);n=min(len(x),len(y));matched+=n;unmatched_a.extend(x[n:]);unmatched_b.extend(y[n:])
 maximum=maxvertex;samples=0
 for src,dst in [(unmatched_a,unmatched_b),(unmatched_b,unmatched_a)]:
  if not src:continue
  tt=np.array(dst);assert len(tt)
  lo=tt.min(axis=1);hi=tt.max(axis=1)
  for tri in src:
   for weights in [(1/3,1/3,1/3),(.6,.2,.2),(.2,.6,.2),(.2,.2,.6)]:
    point=np.array(weights)@tri;mask=np.all(lo<=point+tol,axis=1)&np.all(hi>=point-tol,axis=1);assert mask.any(),(scope,point.tolist());distance=point_distance(point,tt[mask]);assert distance<tol,(scope,point.tolist(),distance);maximum=max(maximum,distance);samples+=1
 rows.append(dict(scope=scope,old_triangles=len(aa),new_triangles=len(bb),matched_triangles_within_tolerance=matched,retessellated_old=len(unmatched_a),retessellated_new=len(unmatched_b),retained_vertex_clusters=len(catalog),max_vertex_recentring_m=maxvertex,surface_samples=samples,max_surface_difference_m=maximum));print(rows[-1],flush=True)
(out/(identity+'_retained_geometry_01.json')).write_text(json.dumps(dict(evidence_class='INERT',scope='Actual frozen old/current exported retained lower surfaces and SE2 studio/upperroof; southeast facade-front0.5m and mainroof crossing planes excluded from this scoped comparison. Same0.1mmphysical tolerance. Exact triangle correspondence where possible;independent float64bidirectional point-to-triangle checks for retessellated faces. Not runtime or artistic acceptance.',rows=rows,failures=[]),indent=2),encoding='utf-8')
