from pathlib import Path
import json,ast,hashlib,struct,collections
root=Path('C:/ov/city');out=Path('C:/ov/reports/city_streets_20261029/southern_pair_01')
s=Path('C:/ov/reports/city_streets_20261029/bodega_frontage_reconciliation_01/check_preservation_01.py').read_text(encoding='utf-8-sig');t=ast.parse(s);exec(compile(ast.Module(body=[n for n in t.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),'<existing accessor reader>','exec'))
a=json.loads((out/'baseline_01.json').read_text(encoding='utf-8'));r={'evidence_class':'INERT','parts':{},'other_assets':{}}
for family in ['city_elevations','city_elevations_lod1']:
 old=a['parts'][family];new=projection((root/f'game/assets/props/{family}.glb').read_bytes());names=[k for k in old if not k.startswith(('site_nbr_s2__','site_se2__'))];bad=[k for k in names if old[k]!=new.get(k)];r['parts'][family]={'unaffected_exact':len(names)-len(bad),'failures':bad};assert not bad,bad
for name,expected in a['assets'].items():
 actual=hashlib.sha256((root/f'game/assets/props/{name}.glb').read_bytes()).hexdigest();assert actual==expected,name;r['other_assets'][name]=actual
old={p['id']:p for p in a['profiles']['buildings']};new=json.loads((root/'art/data/city_elevations/source_plan.json').read_text(encoding='utf-8'))['buildings'];assert all(p==old[p['id']] for p in new if p['id'] not in ['site_nbr_s2','site_se2']);r['unaffected_profiles']=23
(out/'preservation_01.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(r)
f=json.loads((root/'game/tests/fixtures/orison_city_elevations.json').read_text(encoding='utf-8'));print('NEW PANES',collections.Counter(w['building'] for w in f['window_rows'] if w['building'] in ['site_nbr_s2','site_se2']));print('NATIVE',f['native_checks'])
