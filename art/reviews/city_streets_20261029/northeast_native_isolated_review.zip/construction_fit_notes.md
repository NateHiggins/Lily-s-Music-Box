# Northeast block construction fit

Evidence class: **INERT**. Read-only preparation during the canonical lamp/canopy
freeze. No new building implemented, qualified or accepted by these notes.

The next coherent construction target is the four remaining generic northeast
parcels, preserving their installed translations, roofs/plant and adjoining
traffic/access owners. First implement the Faber-derived workshop and Fulton
instrument-house pair; complete the adjacent two parcels in the same block
programme after their retained roof interfaces are surveyed. No new shops,
interiors, financial services, lettering or narrative are implied.

## Actual current source measurements

Derived from the owning elevation source plan, closure original records and
street construction fixture, not historical maps. Source metres, Z up.

| Parcel | Installed XY bounds | Retained body roof | Candidate form |
|---|---|---:|---|
| site_ne1 | 25.78,9.8 to34.38,35.5 |14.7| Four-storey neo-Grec workshop; three front/eight side bays |
| site_ne2 |34.98,9.8 to42.58,33.0|21.5| Six-storey AU instrument house with arched base, double-height recessed arch and two-storey angled bay |
| site_ne3 |43.18,9.8 to53.98,36.0|11.2| Two-storey terra-cotta office candidate; roof/plant fit still unresolved |
| site_ne4 |54.58,9.8 to63.58,34.5|17.8| Four-storey limestone Beaux-Arts frontage with giant order and balustrade |

Current eastern cross-carriageway is X65.2..73.4, not the provisional width
inferred from other station dimensions. Its west-side north pavement reservation
is X62.8..65.2,Y-6.2..25.0. The NE4 body ends at63.58, leaving1.62m to the curb;
the pavement producer clips the occupied footprint. Do not invent a0.65m pinch
or move the row based on the wrong bounds. A new front public walk could join
the eastern pavement just south of Y9.8; substrate and actual collision still
need native/engine checks before construction. Current north main-walk edge
is Y-6.2, leaving a16m setback to the northeast fronts. This is an AU forecourt
opportunity, not evidence of the1928 Queens Plaza layout.

## Specific reference decisions

**NE1:** 37Greenpoint Avenue/90–96West Street, c1881, is a four-storey brick
neo-Grec building with three bays on its short face and eight upper bays on
its long face. Bracketed sills, incised lintels and a bracketed wood cornice
provide useful construction vocabulary. Use original period joinery; omit
modern roll-down gates, later infill and the Faber trademark. The report records
1920s fire escapes, but their actual mounting/clearance must be authored.
[LPC LP-2264, printed16–17](https://s-media.nyc.gov/agencies/lpc/lp/2264.pdf).

**NE2:** The1892–93 Keuffel & Esser building has EIGHT storeys, not six. Its
Fulton façade contains a two-storey arched iron base, a separate transition,
a two-storey recessed round arch, and an upper angled metal bay; the top floor
sets back. For the shorter installed parcel, provisionally omit the neutral
third-storey transition and the eighth-storey setback, retaining the proportions
of the three distinctive two-storey components. This is an explicit six-storey
AU adaptation, not a historical reconstruction or compression of eight floors
into implausible heights. Reference image page1 and description printed5.
[LPC LP-2178](https://s-media.nyc.gov/agencies/lpc/lp/2178.pdf).

**NE3:** The1892 NY Architectural Terra Cotta Works office has two storeys,
stepped roof-end parapets, a pitched tiled roof, an off-centre semicircular bay
and grouped chimney pots. The primary photograph shows a long principal face;
do not squeeze every original bay into the10.8m street front. Decide orientation
and retained rear plant interfaces first; a front/side transposition would be
an AU adaptation requiring explicit documentation. No imported photo pixels.
[LPC LP-1304, printed3–5 and photograph page9](https://s-media.nyc.gov/agencies/lpc/lp/1304.pdf).

**NE4:** The1897–98 Jamaica Savings Bank is four storeys, approximately30ft
wide, with a three-bay limestone façade, rusticated high ground floor and a
giant order above. The photographed roofline is cornice/balustrade, NOT an
assumed mansard. Its approximately9.144m width is a close reference for this
9m parcel. Simplify sculpture as manufactured shallow stock; retain real
recesses, balcony support and fluted columns. No bank gameplay or copied signage.
[LPC LP-2109, printed6–7 and photograph page13](https://s-media.nyc.gov/agencies/lpc/lp/2109.pdf).

Primary PDF/text extracts and inspected pages are external here. Their modern
photographs guide surviving form only. Existing registered materials, native
metric charts and complete replacement LOD bodies remain the fabrication path.
Keep all17 completed studies and the other parcels unchanged; compare actual
exported attributes before reusing their existing review evidence.


## Source-freeze correction before first native build

The preceding provisional suggestion to omit the eighth-storey setback does
not control the current mesh: the installed NE2 mass has an actual17.5m upper
step. The authored six-storey adaptation retains this step,21.5m top and both
original terrace/plant slabs. Floors are4.2/3.5/3.3/3.3/3.2/4.0m; the two upper
oriel storeys share one facet line, exposing more side glass above the step.
No native construction or runtime acceptance is claimed by this correction.
