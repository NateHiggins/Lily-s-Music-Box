"""Closed commercial replacement bodies; near geometry retains collision authority."""
from pathlib import Path
import ast,collections,hashlib,json,math,struct,sys
import bpy,bmesh,numpy as np
from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree
ROOT=Path('C:/ov/city')
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_commercial_architecture import CommercialFronts
from fabrication_native_batch import material,partition,export

source=ROOT/'art/blender/scripts/build_city_elevations.py'
# These geometry functions belong to the elevation producer. Extract definitions
# explicitly; importing that executable would rebuild the entire high city.
names={'box','local_box','profile_stock','arch_stock','turned_stock','roof_panel','clip_roof_polygon','roof_metric_charts','wood_stock_charts'}
tree=ast.parse(source.read_text(encoding='utf-8'))
definitions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
assert {n.name for n in definitions}==names
buffers=collections.defaultdict(lambda:([],[]));stocks=[];roof_samples=[]
def add(name,key,verts,faces):
    vv,ff=buffers[name,key];offset=len(vv);vv.extend(verts);ff.extend(tuple(offset+i for i in f) for f in faces)
    stocks.append((name,key,verts,faces))
exec(compile(ast.Module(body=definitions,type_ignores=[]),str(source),'exec'))
plans=json.loads((ROOT/'art/data/city_elevations/source_plan.json').read_text())
profiles={r['id']:r for r in plans['buildings'] if r['id'] in ['site_ne1','site_ne2']}
assert profiles
records=json.loads((ROOT/'art/blender/city_closure_construction.json').read_text())['original_records']
runtime=json.loads((ROOT/'game/data/orison_v2/exterior/city_elevations.json').read_text())
programme=runtime['body_lod'];assert programme['parts'] and float(programme['error_m'])>0.
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'art/blender/city_closure.blend'))
original={o.name.removesuffix('__RetainedStock'):o for o in bpy.data.collections['ClosedConstruction'].objects}
rings={o.name.removesuffix('__JoinedParapet'):o for o in bpy.data.collections['ClosedParapets'].objects}
owner=CommercialFronts(profiles,records,original,rings,dict(add=add,box=box,profile_stock=profile_stock,arch_stock=arch_stock,turned_stock=turned_stock,roof_panel=roof_panel,clip_roof_polygon=clip_roof_polygon),detail_level=0)
for identity in profiles:owner.build(identity)

rows=[]
for index,(name,key,vv,ff) in enumerate(stocks):
    mesh=bpy.data.meshes.new('HighStockProof');mesh.from_pydata(vv,[],ff);mesh.update()
    bm=bmesh.new();bm.from_mesh(mesh);closed=all(e.is_manifold for e in bm.edges);volume=bm.calc_volume(signed=True)
    assert closed and volume>1e-10,(index,name,key,closed,volume)
    rows.append(dict(index=index,building=name,key=key,closed=closed,volume_m3=volume))
    bm.free();bpy.data.meshes.remove(mesh)
Path('C:/ov/reports/city_streets_20261029/northeast_block_01/near_closed_stocks_03.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Actual new near source stocks manifold and signed-volume controls, no runtime acceptance',stocks=rows,failures=[]),indent=2)+'\n',encoding='utf-8')
print('NE_NEAR_CLOSED_STOCKS',len(rows),flush=True)
