"""Closed commercial replacement bodies; near geometry retains collision authority."""
from pathlib import Path
import ast,collections,hashlib,json,math,struct,sys
import bpy,bmesh,numpy as np
from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree
ROOT=Path('C:/ov/city')
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from city_commercial_architecture import CommercialFronts
from fabrication_native_batch import material,partition,export

source=ROOT/'art/blender/scripts/build_city_elevations.py'
# These geometry functions belong to the elevation producer. Extract definitions
# explicitly; importing that executable would rebuild the entire high city.
names={'box','local_box','profile_stock','arch_stock','turned_stock','roof_panel','clip_roof_polygon','roof_metric_charts'}
tree=ast.parse(source.read_text(encoding='utf-8'))
definitions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
assert {n.name for n in definitions}==names
buffers=collections.defaultdict(lambda:([],[]));stocks=[];roof_samples=[]
def add(name,key,verts,faces):
    vv,ff=buffers[name,key];offset=len(vv);vv.extend(verts);ff.extend(tuple(offset+i for i in f) for f in faces)
    stocks.append((name,key,verts,faces))
exec(compile(ast.Module(body=definitions,type_ignores=[]),str(source),'exec'))
plans=json.loads((ROOT/'art/data/city_elevations/source_plan.json').read_text())
profiles={r['id']:r for r in plans['buildings'] if r.get('architecture',{}).get('type')=='commercial_front'}
assert profiles
records=json.loads((ROOT/'art/blender/city_closure_construction.json').read_text())['original_records']
runtime=json.loads((ROOT/'game/data/orison_v2/exterior/city_elevations.json').read_text())
programme=runtime['body_lod'];assert programme['parts'] and float(programme['error_m'])>0.
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'art/blender/city_closure.blend'))
original={o.name.removesuffix('__RetainedStock'):o for o in bpy.data.collections['ClosedConstruction'].objects}
rings={o.name.removesuffix('__JoinedParapet'):o for o in bpy.data.collections['ClosedParapets'].objects}
owner=CommercialFronts(profiles,records,original,rings,dict(add=add,box=box,profile_stock=profile_stock,arch_stock=arch_stock,turned_stock=turned_stock,roof_panel=roof_panel,clip_roof_polygon=clip_roof_polygon),detail_level=1)
for identity in profiles:owner.build(identity)

raw=(ROOT/'game/assets/props/city_elevations.glb').read_bytes();doc=json.loads(raw[20:20+struct.unpack_from('<I',raw,12)[0]])
frames={n['name']:n.get('translation',[0,0,0]) for n in doc['nodes'] if 'mesh' in n}
rows=[]
for index,(name,key,vv,ff) in enumerate(stocks):
    if (name,key)!=('site_ne2','city_grey_brick'):continue
    t=frames[name+'__'+key];center=Vector((t[0],-t[2],t[1]))
    mesh=bpy.data.meshes.new('Diagnostic');mesh.from_pydata(vv,[],ff);mesh.update()
    for v in mesh.vertices:v.co-=center
    bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.triangulate(bm,faces=list(bm.faces))
    for f in bm.faces:
        if (f.verts[1].co-f.verts[0].co).cross(f.verts[2].co-f.verts[0].co).length_squared==0:
            rows.append(dict(stock=index,face=[list(v.co+center) for v in f.verts],source_vertices=vv,source_faces=ff))
    bm.free();bpy.data.meshes.remove(mesh)
print('COLLAPSED_STOCKS',json.dumps(rows),flush=True)
Path('C:/ov/reports/city_streets_20261029/northeast_block_01/low_collapse_diagnostic_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Failed lower-body float32 face diagnosis, not acceptance',collapsed=rows),indent=2)+'\n',encoding='utf-8')
