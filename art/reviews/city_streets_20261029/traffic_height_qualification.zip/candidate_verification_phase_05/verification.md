# Candidate verification - 6e5e9a7a96e4

- candidate `6e5e9a7a96e46d4925dd5197ea05a25afde276ec`
- base `3ea80715bd201738d5566dea18bc17d4353ca867`
- merge-base `3ea80715bd201738d5566dea18bc17d4353ca867`
- verified 2026-10-30T06:33:59Z from verifier `6e5e9a7a96e4`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 0 regressions, 0 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 3 |

## Blocking reasons (0)

- none

## Needs human review (not blocking) (3)

- candidate changes 3 gate file(s); read those diffs before trusting the board
- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (0)

- none

## Accepted regressions (0)

- none

## Improvements (0)

- none

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (3)

- M tools/orison_spatial_dependency_manifest.json
- M tools/tests/test_city_ground_apron.py
- M tools/tests/test_v2_surface_requirements.py

MERGE-CANDIDATE 6e5e9a7a96e46d4925dd5197ea05a25afde276ec
