from pathlib import Path
import json
from mathutils import Vector
root=Path('C:/ov/city');out=Path(__file__).parent;path=root/'art/blender/scripts/build_city_elevations.py';space={'__file__':str(path),'__name__':'__diagnostic__'}
try:exec(compile(path.read_text(encoding='utf-8'),str(path),'exec'),space)
except AssertionError:
 rows=[]
 for failure in space['native_failures']:
  if failure['kind']!='pane':continue
  w=failure['window'];point=Vector(w['pane_sample']);normal=Vector(w['normal']);hit,n,index,distance=space['bvh'].ray_cast(point+normal*.1,-normal,.4);expected=point-normal*(w['recess_m']+.044);rows.append(dict(window=w,expected=list(expected),hit=list(hit) if hit else None,first_owner=space['face_owners'][index] if index is not None else None,error_m=(hit-expected).length if hit else None))
 (out/'oriel_pane_failure_01.json').write_text(json.dumps(dict(evidence_class='INERT',scope='Actual first-hit sourceBvh diagnosis before repair;noexportoracceptance',failures=rows),indent=2),encoding='utf-8');print('PANE_FAILURES',len(rows),rows[0]['first_owner'],rows[0]['error_m'],flush=True)
else:raise AssertionError('Original failure unexpectedly absent')
