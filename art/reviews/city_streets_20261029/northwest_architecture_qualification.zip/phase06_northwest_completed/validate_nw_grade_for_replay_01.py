"""Require a successful fresh diagnostic before any ground-source replay."""
import hashlib,json,sys
from pathlib import Path
root=Path('C:/ov/city');base=Path(__file__).parent
sys.path.insert(0,str(root/'tools'))
from run_receipt import runtime_inputs_sha256
receipt_path=base/'nw_grade_survey_01.log.receipt.json'
survey_path=base/'nw_grade_survey_01/grade_owners.json'
receipt=json.loads(receipt_path.read_text());survey=json.loads(survey_path.read_text())
assert receipt['execution']['completed'] and receipt['execution']['exit_code']==0 and not receipt['execution']['timed_out']
assert receipt['log']['script_error_count']==0 and not receipt['log']['stale_cache_suspect']
assert survey['evidence_class']=='INERT' and survey['failures']==0 and survey['records']
assert survey['source']['runtime_inputs_sha256']==runtime_inputs_sha256(root),'Fresh survey production inputs changed'
for relative,expected in survey['source']['test_dependencies'].items():
    path=(root/relative).resolve();assert path.is_relative_to(root) and path.is_file(),relative
    raw=path.read_bytes()
    if path.suffix in ['.py','.gd','.tscn','.json']:raw=raw.replace(b'\r\n',b'\n')
    assert hashlib.sha256(raw).hexdigest()==expected,relative
assert 'receiving' in survey['poses']
print('Fresh INERT grade discovery verified:',len(survey['records']),'aligned boxes; not a runtime-contract or artistic acceptance')
