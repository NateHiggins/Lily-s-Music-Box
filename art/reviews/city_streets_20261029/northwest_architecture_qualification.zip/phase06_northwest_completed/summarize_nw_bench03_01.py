"""Summarize immutable diagnostic samples; no runtime/artistic promotion."""
import hashlib,json,math
from pathlib import Path
base=Path(__file__).parent; folder=base/'nw_elevation_bench_03'
target=base/'nw_bench03_diagnostic_summary.json'
assert not target.exists(),'Preserve previous summary'
source=folder/'city_elevation_profile.json';data=json.loads(source.read_text())
receipt=base/'nw_elevation_bench_03.log.receipt.json'
run=json.loads(receipt.read_text())
assert run['execution']['exit_code']==0 and not run['execution']['timed_out']
assert data['checks']==6231 and data['failures']==[]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def stats(values):
    ordered=sorted(values);n=len(ordered)
    return {'samples':n,'median':(ordered[(n-1)//2]+ordered[n//2])*.5,'p95_nearest_rank':ordered[math.ceil(n*.95)-1],'p99_nearest_rank':ordered[math.ceil(n*.99)-1],'maximum':ordered[-1]}
rows=[]
for row in data['observations']:
    result={k:row[k] for k in ['building','id','distance_m','threshold','draws','primitives']}
    result['timing_ms']={key:stats([sample[key] for sample in row['frame_samples']]) for key in ['wall_ms','viewport_cpu_ms','viewport_gpu_ms']}
    rows.append(result)
images=[]
for path in sorted(folder.glob('*.png')):
    images.append({'file':path.name,'sha256':sha(path),'bytes':path.stat().st_size})
assert len(images)==21
result={'evidence_class':'INERT','scope':data['scope'],'source_profile_sha256_raw':sha(source),'wrapper_receipt_sha256_raw':sha(receipt),'checks':data['checks'],'failures':data['failures'],'settings':data['settings'],'cases':rows,'transitions':data['natural_transitions'],'actual_visual_inspection':{'files':images,'finding':'All21 frames inspected. Three whole-front captures and six forced near/far captures retain doors, panes, blinds, cornices and roof forms. Twelve natural frames isolate one material body per building: openings/silhouettes persist across first reduction, narrow FOV restores near indices, inward return repeats before image. Existing roof antenna automatic LOD loses thin wires in forced extreme-far; not repaired by this body change. Controlled lighting/background, no occupied street/world artistic acceptance.'},'limits':['Current isolated buildings/equipment; no matched pre-change baseline or whole-world frame budget.','Ninety warmed frames/case; screenshot work outside timing samples.','Natural transitions are one dominant material-body part each, not complete-world simultaneous selection.','Maximum samples are observed spikes; no causal attribution follows from these counters.']}
target.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for row in rows:
    print(row['building'],row['id'],'draws/primitives',row['draws'],row['primitives'],'GPU',row['timing_ms']['viewport_gpu_ms'],'wall',row['timing_ms']['wall_ms'])
