"""Allow only observed anonymous runtime IDs to differ in physical controls."""
import hashlib,json,re
from pathlib import Path
root=Path('C:/ov/city');base=Path(__file__).parent/'nw_ground_replay_01'
old_path=base/'before/art/data/orison_ground/retained_grade_source.json'
new_path=base/'retained_grade_candidate.json'
old=json.loads(old_path.read_text());new=json.loads(new_path.read_text())
rows=[]
for field in new:
    if field=='bindings':continue
    a=old[field];b=new[field]
    if field not in ['retained_solids','surface_exclusions']:
        assert a==b,field
        rows.append({'field':field,'exact':True});continue
    assert len(a)==len(b),field
    changed=[]
    for index,(before,after) in enumerate(zip(a,b)):
        if before==after:continue
        left=before.copy();right=after.copy()
        left_id=left.pop('id',None);right_id=right.pop('id',None)
        assert left==right,(field,index,before,after)
        assert all(isinstance(value,str) and re.fullmatch(r'@CollisionShape3D@\d+',value) for value in [left_id,right_id]),(field,index)
        changed.append({'index':index,'owner':after['owner'],'before_id':left_id,'after_id':right_id,'bounds':after['bounds']})
    rows.append({'field':field,'count':len(b),'physical_records_identical':True,'anonymous_runtime_id_changes':changed})
report={'evidence_class':'INERT','scope':'Exact full physical control comparison of freshly generated candidate against preserved original. Only anonymous runtime allocation IDs may differ; no tolerance, bounds or owner changes accepted. Not runtime qualification.','before_sha256_raw':hashlib.sha256(old_path.read_bytes()).hexdigest(),'candidate_sha256_raw':hashlib.sha256(new_path.read_bytes()).hexdigest(),'fields':rows,'failures':[]}
target=base/'candidate_physical_comparison.json';assert not target.exists()
target.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('PASS exact physical controls; anonymous IDs:',[(row['field'],len(row.get('anonymous_runtime_id_changes',[]))) for row in rows if 'count' in row])
