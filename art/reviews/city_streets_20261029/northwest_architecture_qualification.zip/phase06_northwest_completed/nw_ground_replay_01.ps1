$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:/ov/city'
$cityEvidence='C:/ov/reports/city_streets_20261029'
$cityBlender='C:/Program Files/Blender Foundation/Blender 5.2/blender.exe'
& python "$cityEvidence/validate_nw_grade_for_replay_01.py"
if($LASTEXITCODE -ne 0){throw 'Fresh survey no longer binds; preserve it'}
$cityActive=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -like '*godot*' -and ($_.CommandLine -like '*C:\ov\city\game*' -or $_.CommandLine -like '*C:/ov/city/game*')})
if($cityActive.Count -gt 0){throw 'Own Godot still active; preserve frozen source inputs'}
# Canonical coordinator released the profiling-only hold after its long-walk
# observer ended. Its independent correctness survey may retain the Godot lane.
if(@(Get-Process blender -ErrorAction SilentlyContinue).Count -gt 0){throw 'Another native Blender process is active'}
function Invoke-CityGroundStep([string]$name,[string]$program,[string[]]$arguments){
    $cityLog="$cityEvidence/$name.log"
    if(Test-Path -LiteralPath $cityLog){throw "Preserve original $name log"}
    & $program @arguments *> $cityLog
    if($LASTEXITCODE -ne 0){throw "$name failed; original log retained"}
    Write-Output "$name PASS"
}
Invoke-CityGroundStep 'nw_foundations_replay_01' $cityBlender @('--background','-t','2','--python-exit-code','1','--python','art/blender/scripts/build_city_foundations.py')
Invoke-CityGroundStep 'nw_bar_reservations_01' 'python' @('art/tools/export_bar_ground_reservations.py')
Invoke-CityGroundStep 'nw_ground_replay_01' $cityBlender @('--background','-t','2','--python-exit-code','1','--python','art/blender/scripts/build_orison_ground.py')
Invoke-CityGroundStep 'nw_apron_replay_01' $cityBlender @('--background','-t','2','--python-exit-code','1','--python','art/blender/scripts/build_city_ground_apron.py')
Invoke-CityGroundStep 'nw_horizon_replay_01' $cityBlender @('--background','-t','2','--python-exit-code','1','--python','art/blender/scripts/build_city_horizon.py')
Invoke-CityGroundStep 'nw_ground_geometry_comparison_01' 'python' @("$cityEvidence/snapshot_nw_ground_inputs_01.py",'compare')
