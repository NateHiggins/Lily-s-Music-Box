param([int]$WaitMinutes=180,[int]$IntervalSeconds=5)
$ErrorActionPreference='Stop'
$cityOutput='C:/ov/reports/city_streets_20261029/nw_resource_process_samples_01.jsonl'
if(Test-Path -LiteralPath $cityOutput){throw 'Preserve original observations'}
function Write-CityObservation($row){$row | ConvertTo-Json -Depth 8 -Compress | Add-Content -LiteralPath $cityOutput -Encoding utf8}
Write-CityObservation ([ordered]@{kind='scope';evidence_class='INERT';observed_utc=[DateTime]::UtcNow.ToString('o');interval_seconds=$IntervalSeconds;scope='Read-only exact city benchmark/grade process observations; standalone city and full-world grade are separate stages, not a matched old/new experiment';limits='Polling/counter overhead is present. Five-second samples are not continuous peaks. Missing counters are not zero usage. Process totals do not attribute memory to body LODs or identify a cause of frame stalls.'})
$cityWaitDeadline=[DateTime]::UtcNow.AddMinutes($WaitMinutes)
foreach($cityScene in @('res://tests/V2CityElevationBench.tscn','res://tests/V2GradeOwnerSurvey.tscn')){
    $cityEngineRecord=$null
    while([DateTime]::UtcNow -lt $cityWaitDeadline){
        $cityEngineRecord=Get-CimInstance Win32_Process -Filter "Name = 'godot.windows.editor.x86_64.llvm.exe'" | Where-Object {
            $_.CommandLine -match '--path\s+"?C:\\ov\\city\\game' -and $_.CommandLine.Contains($cityScene)
        } | Select-Object -First 1
        if($null -ne $cityEngineRecord){break}
        if($cityScene -like '*GradeOwner*' -and -not (Get-Process -Id 31092 -ErrorAction SilentlyContinue)){
            Write-CityObservation @{kind='batch_ended_before_stage';observed_utc=[DateTime]::UtcNow.ToString('o');scene=$cityScene};exit 0
        }
        Start-Sleep -Seconds $IntervalSeconds
    }
    if($null -eq $cityEngineRecord){Write-CityObservation @{kind='not_started';observed_utc=[DateTime]::UtcNow.ToString('o');scene=$cityScene};exit 73}
    $cityObservedPid=[int]$cityEngineRecord.ProcessId
    $cityCreated=$cityEngineRecord.CreationDate.ToUniversalTime()
    Write-CityObservation @{kind='attached_observation';observed_utc=[DateTime]::UtcNow.ToString('o');scene=$cityScene;process_id=$cityObservedPid;creation_utc=$cityCreated.ToString('o');command=$cityEngineRecord.CommandLine}
    $cityActiveDeadline=[DateTime]::UtcNow.AddMinutes(27)
    while([DateTime]::UtcNow -lt $cityActiveDeadline){
        $cityProcess=Get-Process -Id $cityObservedPid -ErrorAction SilentlyContinue
        if($null -eq $cityProcess -or [math]::Abs(($cityProcess.StartTime.ToUniversalTime()-$cityCreated).TotalSeconds) -gt 2){
            Write-CityObservation @{kind='process_gone';observed_utc=[DateTime]::UtcNow.ToString('o');scene=$cityScene;process_id=$cityObservedPid};break
        }
        $citySystem=Get-CimInstance Win32_OperatingSystem
        $cityGpu=@();$cityGpuError=''
        try{
            $cityCounters=Get-Counter -Counter '\GPU Process Memory(*)\Dedicated Usage','\GPU Process Memory(*)\Shared Usage' -MaxSamples 1
            $cityGpu=@($cityCounters.CounterSamples | Where-Object {$_.InstanceName -like "pid_${cityObservedPid}_*"} | ForEach-Object {@{instance=$_.InstanceName;path=$_.Path;bytes=$_.CookedValue;status=$_.Status}})
        }catch{$cityGpuError=$_.Exception.Message}
        Write-CityObservation ([ordered]@{kind='sample';observed_utc=[DateTime]::UtcNow.ToString('o');scene=$cityScene;process_id=$cityObservedPid;cpu_seconds=$cityProcess.CPU;responding=$cityProcess.Responding;working_set_bytes=$cityProcess.WorkingSet64;private_bytes=$cityProcess.PrivateMemorySize64;host_available_kib=[long]$citySystem.FreePhysicalMemory;gpu_sample_count=$cityGpu.Count;gpu=$cityGpu;counter_error=$cityGpuError})
        Start-Sleep -Seconds $IntervalSeconds
    }
}
Write-CityObservation @{kind='observer_complete';observed_utc=[DateTime]::UtcNow.ToString('o');note='Observer exits only itself; Godot and lane untouched'}
