"""Completed sampled process observations, without per-family attribution."""
import hashlib,json
from pathlib import Path
base=Path(__file__).parent;source=base/'nw_resource_process_samples_01.jsonl'
rows=[json.loads(line) for line in source.read_text(encoding='utf-8-sig').splitlines()]
assert rows[-1]['kind']=='observer_complete'
stages=[]
for scene in ['res://tests/V2CityElevationBench.tscn','res://tests/V2GradeOwnerSurvey.tscn']:
    samples=[row for row in rows if row['kind']=='sample' and row['scene']==scene]
    assert samples and all(row['gpu_sample_count']==2 and not row['counter_error'] and all(counter['status']==0 for counter in row['gpu']) for row in samples)
    def gpu(row,kind):return sum(counter['bytes'] for counter in row['gpu'] if counter['path'].endswith('\\'+kind))
    stages.append({'scene':scene,'samples':len(samples),'first_observed_utc':samples[0]['observed_utc'],'last_observed_utc':samples[-1]['observed_utc'],'maximum_sampled_working_set_bytes':max(row['working_set_bytes'] for row in samples),'maximum_sampled_private_bytes':max(row['private_bytes'] for row in samples),'minimum_sampled_host_available_kib':min(row['host_available_kib'] for row in samples),'maximum_sampled_dedicated_gpu_bytes':max(gpu(row,'dedicated usage') for row in samples),'maximum_sampled_shared_gpu_bytes':max(gpu(row,'shared usage') for row in samples)})
target=base/'nw_resources_summary_01.json';assert not target.exists()
target.write_text(json.dumps({'evidence_class':'INERT','scope':rows[0]['scope'],'limits':rows[0]['limits'],'source_sha256_raw':hashlib.sha256(source.read_bytes()).hexdigest(),'stages':stages},indent=2)+'\n',encoding='utf-8')
print(json.dumps(stages,indent=2))
