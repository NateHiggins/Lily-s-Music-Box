"""Three source-fitted northwest buildings. External native construction only."""
from pathlib import Path
import ast,collections,hashlib,json,math,re,sys
import bpy,bmesh,numpy as np
from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree
ROOT=Path('C:/ov/city')
OUT=Path(__file__).parent/'nw_architecture_study_09';OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from fabrication_native_batch import material,partition,export
source=ROOT/'art/blender/scripts/build_city_elevations.py'
tree=ast.parse(source.read_text(encoding='utf-8'))
names={'box','local_box','profile_stock','arch_stock','turned_stock','roof_panel','clip_roof_polygon'}
buffers=collections.defaultdict(lambda:([],[]));stocks=[];roof_samples=[];window_samples=[];copied_stock_diagnostics=[]
def add(name,key,verts,faces):
    start=len(buffers[name,key][0]);buffers[name,key][0].extend(verts)
    buffers[name,key][1].extend(tuple(start+i for i in face) for face in faces)
    stocks.append({'building':name,'key':key,'vertices':verts,'faces':faces})
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),str(source),'exec'))
def local_box(name,key,origin,tangent,out,lo,hi):
    x,y,z=lo;X,Y,Z=hi
    assert X>x and Y>y and Z>z,(name,key,lo,hi)
    vv=[tuple(origin+tangent*a+out*b+Vector((0,0,c))) for a,b,c in [(x,y,z),(X,y,z),(X,Y,z),(x,Y,z),(x,y,Z),(X,y,Z),(X,Y,Z),(x,Y,Z)]]
    ff=[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
    if tangent.cross(out).z<0:ff=[tuple(reversed(f)) for f in ff]
    add(name,key,vv,ff)
catalog=json.loads((ROOT/'game/data/runtime_material_sets.json').read_bytes())['materials']
records=json.loads((ROOT/'art/blender/city_closure_construction.json').read_bytes())['original_records']
plans={p['id']:p for p in json.loads((ROOT/'art/data/city_elevations/source_plan.json').read_bytes())['buildings']}
selected=['site_nw1','site_nw3','site_nw4']
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'art/blender/city_closure.blend'))
original={o.name.removesuffix('__RetainedStock'):o for o in bpy.data.collections['ClosedConstruction'].objects}
rings={o.name.removesuffix('__JoinedParapet'):o for o in bpy.data.collections['ClosedParapets'].objects}
bpy.context.view_layer.update()

variant=Path(__file__).with_name('city_commercial_architecture_window09.py')
scope={}
exec(compile(variant.read_text(),str(variant),'exec'),scope)
builder=scope['CommercialFronts']({n:plans[n] for n in selected},records,original,rings,
    dict(add=add,box=box,profile_stock=profile_stock,arch_stock=arch_stock,
         turned_stock=turned_stock,roof_panel=roof_panel,clip_roof_polygon=clip_roof_polygon))
for name in selected:builder.build(name)
window_samples=builder.window_samples;copied_stock_diagnostics=builder.copied_stock_diagnostics
building_rows=builder.building_rows;specs={n:dict(builder.specs[n],tint=plans[n]['wall_tint']) for n in selected}
# Retained bearing predicates are evaluated against the actual newly built solids.
verts=[];faces=[]
for (name,key),(vv,ff) in buffers.items():
    offset=len(verts);verts.extend(vv);faces.extend(tuple(offset+i for i in face) for face in ff)
bvh=BVHTree.FromPolygons(verts,faces)
failures=[];bearing_samples=0
for family in ['masts','aerials','tanks']:
    data=json.loads((ROOT/f'game/tests/fixtures/orison_city_{family}.json').read_bytes())
    for contact in data['contacts']:
        if not any(contact['owner'].startswith(name+'_') for name in selected):continue
        normal=Vector(contact['normal'])
        for p in [contact['point']]+contact['footprint']:
            point=Vector(p);hit,*_=bvh.ray_cast(point+normal*.03,-normal,.06);bearing_samples+=1
            if hit is None or (hit-point).length>=.0001:failures.append({'kind':'bearing','id':contact['id'],'point':p,'hit':list(hit) if hit is not None else None})
for sample in window_samples:
    point=Vector(sample['point']);normal=Vector(sample['normal'])
    hit,*_=bvh.ray_cast(point+normal*.10,-normal,.20)
    if hit is None or (hit-point).length>=.0001:failures.append({'kind':'pane','sample':sample})
(OUT/'bearing_and_pane_diagnostic.json').write_text(json.dumps({'evidence_class':'INERT','bearing_samples':bearing_samples,'pane_samples':len(window_samples),'copied_stocks':copied_stock_diagnostics,'failures':failures},indent=2)+'\n',encoding='utf-8',newline='\n')
assert not failures,failures[:12]
# Release the retained reference object/data names before creating the portable ABI.
# Those exact native solids are already copied into buffers and checked above.
for obj in list(bpy.data.objects):bpy.data.objects.remove(obj,do_unlink=True)
bpy.data.orphans_purge(do_recursive=True)
exports=bpy.data.collections.new('NWArchitectureExport');bpy.context.scene.collection.children.link(exports)
native_checks=[]
for index,stock in enumerate(stocks):
    mesh=bpy.data.meshes.new('ClosedStock');mesh.from_pydata(stock['vertices'],[],stock['faces']);mesh.update()
    bm=bmesh.new();bm.from_mesh(mesh)
    assert all(e.is_manifold for e in bm.edges),(index,stock['building'],stock['key'],'open stock')
    assert bm.calc_volume(signed=True)>1e-10,(index,stock['building'],stock['key'],'inverted/zero stock',bm.calc_volume(signed=True))
    bm.free();bpy.data.meshes.remove(mesh)
for (name,key),(vv,ff) in sorted(buffers.items()):
    tint=specs[name]['tint'] if key==specs[name]['wall'] else plans[name]['frame_tint'] if key=='door_paint' else [.22,.27,.29,1] if key=='mirror_aged' else [1,1,1,1]
    finish={'catalog_key':key,'tint':tint,'pigment':1.,'normal':.65,'roughness':1.}
    mat=material(ROOT,name+'__'+key,finish,catalog)
    if key=='mirror_aged':
        bsdf=mat.node_tree.nodes['Principled BSDF'];bsdf.inputs['Metallic'].default_value=0;bsdf.inputs['Transmission Weight'].default_value=.5;bsdf.inputs['IOR'].default_value=1.52
    mesh=bpy.data.meshes.new('Raw');mesh.from_pydata(vv,[],ff);mesh.update()
    c=Vector(((min(v[0] for v in vv)+max(v[0] for v in vv))/2,(min(v[1] for v in vv)+max(v[1] for v in vv))/2,0))
    for v in mesh.vertices:v.co-=c
    raw=bpy.data.objects.new('Raw',mesh)
    obj=partition(exports,name+'__'+key,[raw],finish,mat,Matrix.Translation(c),catalog)
    native_checks.append({'name':obj.name,'triangles':len(obj.data.polygons)})
keep=set(exports.objects)
for obj in list(bpy.data.objects):
    if obj not in keep:bpy.data.objects.remove(obj,do_unlink=True)
bpy.data.orphans_purge(do_recursive=True)
packed_images=[]
for image in bpy.data.images:
    if image.source!='FILE':continue
    actual=ROOT/'game/assets/building/textures'/Path(image.filepath).name
    assert actual.is_file(),actual
    image.filepath=str(actual);image.reload();assert image.size[0]>0 and image.size[1]>0,image.name
    image.pack();packed_images.append({'name':image.name,'size':list(image.size)})
for folder in ['art/blender','game/assets/props']:(OUT/folder).mkdir(parents=True,exist_ok=True)
proof=export(OUT,'nw_architecture',exports,material_names_only=True)
report={'evidence_class':'INERT','scope':'Three complete native architectural adaptations, actual retained roof contacts and recessed panes. No gameplay, loaded Godot material, runtime route, performance or artistic acceptance.',
        'buildings':building_rows,'closed_stocks':len(stocks),'bearing_samples':bearing_samples,'window_samples':len(window_samples),'failures':failures,'parts':native_checks,'export':proof,'packed_review_images':packed_images,
        'source_bindings':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source,ROOT/'art/data/city_elevations/source_plan.json',ROOT/'art/blender/city_closure.blend']}}
(OUT/'construction.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print('NW_NATIVE_CONSTRUCTION',json.dumps({k:report[k] for k in ['closed_stocks','bearing_samples','window_samples','export']}),flush=True)

(OUT/'executed_window_helper.py').write_text(variant.read_text(),newline='\n')
