"""Snapshot/compare actual GLB arrays and runtime data around owner replays."""
import hashlib,json,struct,sys
from pathlib import Path
root=Path('C:/ov/city');base=Path(__file__).parent/'nw_dependency_replay_01'
families=['city_shells','city_masts','city_aerials','city_tanks','city_beacons','city_elevations','city_streets','city_streets_lod1','city_foundations']
def digest(raw):return hashlib.sha256(raw).hexdigest()
def glb(path):
    raw=path.read_bytes();size=struct.unpack_from('<I',raw,12)[0]
    doc=json.loads(raw[20:20+size]);binary=raw[28+size:]
    def accessor(i):
        a=doc['accessors'][i];view=doc['bufferViews'][a['bufferView']]
        width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]*{5120:1,5121:1,5122:2,5123:2,5125:4,5126:4}[a['componentType']]
        offset=view.get('byteOffset',0)+a.get('byteOffset',0);stride=view.get('byteStride',width)
        value=b''.join(binary[offset+j*stride:offset+j*stride+width] for j in range(a['count']))
        return {'type':a['type'],'componentType':a['componentType'],'count':a['count'],'sha256':digest(value)}
    nodes={}
    for node in doc.get('nodes',[]):
        if 'mesh' not in node:continue
        parts=[]
        for p in doc['meshes'][node['mesh']]['primitives']:
            parts.append({'attributes':{k:accessor(v) for k,v in p['attributes'].items()},'indices':accessor(p['indices']),'mode':p.get('mode',4)})
        nodes[node['name']]={'parts':parts,'transform':{k:node[k] for k in ['matrix','translation','rotation','scale'] if k in node}}
    return {'file_sha256':digest(raw),'nodes':nodes}
def current():
    return {name:glb(root/'game/assets/props'/f'{name}.glb') for name in families}
mode=sys.argv[1];base.mkdir(exist_ok=True)
if mode=='before':
    path=base/'before.json'
    assert not path.exists(),'Do not overwrite the original snapshot'
    path.write_text(json.dumps(current(),indent=2)+'\n',newline='\n')
    for family in families:
        family='city_closure' if family=='city_shells' else family
        for prefix in ['art/blender/','game/tests/fixtures/orison_']:
            relative=prefix+family+('_construction.json' if prefix=='art/blender/' else '.json')
            p=root/relative
            if p.exists():
                dest=base/'before'/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
    print('Original nine-asset snapshot retained')
elif mode in ['compare','compare_nw']:
    before=json.loads((base/'before.json').read_text());after=current();rows=[]
    for name in families:
        exact=before[name]['nodes']==after[name]['nodes']
        row={'asset':name,'same_file':before[name]['file_sha256']==after[name]['file_sha256'],'same_arrays_indices_and_node_transforms':exact,'parts':len(after[name]['nodes'])}
        if name=='city_elevations' and mode=='compare_nw':
            selected=('site_nw1__','site_nw3__','site_nw4__')
            old={k:v for k,v in before[name]['nodes'].items() if not k.startswith(selected)}
            new={k:v for k,v in after[name]['nodes'].items() if not k.startswith(selected)}
            row.update(intentional_three_building_window_refinement=True,retained_parts=len(new),retained_arrays_indices_and_transforms_exact=old==new)
        rows.append(row)
    failures=[r['asset'] for r in rows if not r.get('retained_arrays_indices_and_transforms_exact',r['same_arrays_indices_and_node_transforms'])]
    report={'evidence_class':'INERT','scope':'Native replay identity for complete imported arrays/indices and node transforms, not renderer or artistic acceptance. Original pre-replay metadata preserved byte-identically.','assets':rows,'failures':failures}
    path=base/('comparison_nw.json' if mode=='compare_nw' else 'comparison.json')
    path.write_text(json.dumps(report,indent=2)+'\n',newline='\n');print(json.dumps(report,indent=2));raise SystemExit(bool(failures))
else:raise ValueError(mode)
