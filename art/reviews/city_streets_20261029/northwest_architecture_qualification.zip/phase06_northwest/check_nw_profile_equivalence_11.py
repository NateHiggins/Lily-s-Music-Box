"""Three source-fitted northwest buildings. External native construction only."""
from pathlib import Path
import ast,collections,hashlib,json,math,re,sys
import bpy,bmesh,numpy as np
from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree
ROOT=Path('C:/ov/city')
OUT=Path(__file__).parent/'nw_profile_equivalence_11';OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from fabrication_native_batch import material,partition,export
source=ROOT/'art/blender/scripts/build_city_elevations.py'
tree=ast.parse(source.read_text(encoding='utf-8'))
names={'box','local_box','profile_stock','arch_stock','turned_stock','roof_panel','clip_roof_polygon'}
buffers=collections.defaultdict(lambda:([],[]));stocks=[];roof_samples=[];window_samples=[];copied_stock_diagnostics=[]
def add(name,key,verts,faces):
    start=len(buffers[name,key][0]);buffers[name,key][0].extend(verts)
    buffers[name,key][1].extend(tuple(start+i for i in face) for face in faces)
    stocks.append({'building':name,'key':key,'vertices':verts,'faces':faces})
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),str(source),'exec'))
def local_box(name,key,origin,tangent,out,lo,hi):
    x,y,z=lo;X,Y,Z=hi
    assert X>x and Y>y and Z>z,(name,key,lo,hi)
    vv=[tuple(origin+tangent*a+out*b+Vector((0,0,c))) for a,b,c in [(x,y,z),(X,y,z),(X,Y,z),(x,Y,z),(x,y,Z),(X,y,Z),(X,Y,Z),(x,Y,Z)]]
    ff=[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
    if tangent.cross(out).z<0:ff=[tuple(reversed(f)) for f in ff]
    add(name,key,vv,ff)
catalog=json.loads((ROOT/'game/data/runtime_material_sets.json').read_bytes())['materials']
records=json.loads((ROOT/'art/blender/city_closure_construction.json').read_bytes())['original_records']
plans={p['id']:p for p in json.loads((ROOT/'art/data/city_elevations/source_plan.json').read_bytes())['buildings']}
selected=['site_nw1','site_nw3','site_nw4']
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'art/blender/city_closure.blend'))
original={o.name.removesuffix('__RetainedStock'):o for o in bpy.data.collections['ClosedConstruction'].objects}
rings={o.name.removesuffix('__JoinedParapet'):o for o in bpy.data.collections['ClosedParapets'].objects}
bpy.context.view_layer.update()


def run(path,level=None):
    global buffers,stocks,roof_samples
    buffers=collections.defaultdict(lambda:([],[]));stocks=[];roof_samples=[]
    scope={};exec(compile(path.read_text(),str(path),'exec'),scope)
    args=({n:plans[n] for n in selected},records,original,rings,dict(add=add,box=box,profile_stock=profile_stock,arch_stock=arch_stock,turned_stock=turned_stock,roof_panel=roof_panel,clip_roof_polygon=clip_roof_polygon))
    owner=scope['CommercialFronts'](*args,**({} if level is None else {'detail_level':level}))
    for name in selected:owner.build(name)
    result={'stocks':stocks,'roof_samples':roof_samples,'windows':owner.window_rows,'panes':owner.window_samples,'portals':owner.portal_rows,'buildings':owner.building_rows}
    return hashlib.sha256(json.dumps(result,sort_keys=True,separators=(',',':')).encode()).hexdigest(),len(stocks)
base=Path(__file__).parent;candidate=base/'city_commercial_architecture_candidate11.py'
rows=[]
for level,original_name in [(0,'city_commercial_architecture_window09.py'),(1,'city_commercial_architecture_body_lod02.py')]:
    expected,count=run(base/original_name);actual,actual_count=run(candidate,level)
    rows.append({'level':level,'original_recipe':original_name,'original_stock_count':count,'candidate_stock_count':actual_count,'original_geometry_and_sample_sha256':expected,'candidate_geometry_and_sample_sha256':actual,'exact':actual==expected})
report={'evidence_class':'INERT','scope':'Exact complete closed-stock vertices/polygons/material identities, roof samples, window/pane/portal probes and building metadata against executed native studies. No export, runtime or artistic acceptance.','levels':rows,'failures':[r['level'] for r in rows if not r['exact']]}
(OUT/'equivalence.json').write_text(json.dumps(report,indent=2)+'\n',newline='\n');print(json.dumps(report,indent=2));assert not report['failures']
