import ast,hashlib,json
from pathlib import Path
base=Path(__file__).parent;root=Path('C:/ov/city')
source=base/'compare_nw_production_02.py'
tree=ast.parse(source.read_text())
body=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name=='read']
scope={};exec(compile(ast.Module(body=body,type_ignores=[]),str(source),'exec'),scope)
actual=root/'game/assets/props/city_elevations_lod1.glb'
old=scope['read'](base/'nw_architecture_body_lod_study_02/game/assets/props/nw_architecture.glb')
new=scope['read'](actual)
assert set(old)==set(new) and len(new)==39
parts=[];failures=[]
for name in sorted(new):
    expected=old[name];current=new[name]
    exact=expected['geometry']==current['geometry']
    metric=current['max_uv_excess_m']<=.00005 and abs(current['widest_above_50um']-1)<.005
    parts.append({'name':name,'exact_reviewed_triangle_positions':exact,'metric_uv_pass':metric,'triangles':sum(p['triangles'] for p in current['parts']),'max_uv_excess_m':current['max_uv_excess_m'],'widest_edge_ratio_above_50um':current['widest_above_50um']})
    if not exact or not metric:failures.append(name)
original_hash=json.loads((base/'nw_lod_source_hash_failure_01/asset_before.json').read_text(encoding='utf-8-sig'))['Hash']
sha=hashlib.sha256(actual.read_bytes()).hexdigest()
report={'evidence_class':'INERT','scope':'Actual owning lower-body export matches all39 reviewed complete replacement material parts. Current source UV metric predicate applied; roof charts now use the owning high producer phase/orientation. No imported Godot precision, LOD selection, rendering-cost or artistic acceptance.','asset_sha256':sha,'unchanged_asset_after_text_only_hash_fix':sha.upper()==original_hash,'triangles':sum(r['triangles'] for r in parts),'parts':parts,'failures':failures}
assert report['unchanged_asset_after_text_only_hash_fix']
(base/'nw_production_03/lower_export_comparison_02.json').write_text(json.dumps(report,indent=2)+'\n',newline='\n')
print(json.dumps({k:v for k,v in report.items() if k!='parts'},indent=2));assert not failures
