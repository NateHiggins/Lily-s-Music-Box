from pathlib import Path
import json,struct,hashlib,collections,numpy as np
ROOT=Path('C:/ov/city');BASE=Path(__file__).parent;OUT=BASE/'nw_production_03'
def read(path):
    raw=path.read_bytes();size=struct.unpack_from('<I',raw,12)[0]
    doc=json.loads(raw[20:20+size]);binary=raw[28+size:]
    def array(i):
        a=doc['accessors'][i];v=doc['bufferViews'][a['bufferView']];dtype=np.dtype({5121:'u1',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']]);width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
        return np.ndarray((a['count'],width),dtype=dtype,buffer=binary,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',width*dtype.itemsize),dtype.itemsize)).copy()
    result={}
    for node in doc['nodes']:
        if 'mesh' not in node:continue
        assert node.get('rotation',[0,0,0,1])==[0,0,0,1] and node.get('scale',[1,1,1])==[1,1,1] and 'matrix' not in node,node
        mesh=doc['meshes'][node['mesh']];parts=[];counter=collections.Counter();worst_uv=0.;widest=0.;excess=0.
        for primitive in mesh['primitives']:
            arrays={k:array(v) for k,v in primitive['attributes'].items()}
            indices=array(primitive['indices']).reshape(-1,3).astype(int)
            parts.append({'attributes':{k:hashlib.sha256(a.tobytes()).hexdigest() for k,a in arrays.items()},'indices':hashlib.sha256(indices.astype('<i8').tobytes()).hexdigest(),'triangles':len(indices)})
            if node['name'].startswith(('site_nw1__','site_nw3__','site_nw4__')):
                world=(arrays['POSITION']+np.asarray(node.get('translation',[0,0,0]),dtype=np.float32)).astype(np.float32)
                for triangle in world[indices]:counter[tuple(sorted(tuple(float(x) for x in p) for p in triangle))]+=1
                points=arrays['POSITION'].astype(float)[indices];uv=arrays['TEXCOORD_0'].astype(float)[indices]
                for a,b in [(0,1),(1,2),(2,0)]:
                    physical=np.linalg.norm(points[:,a]-points[:,b],axis=1);mapped=np.linalg.norm(uv[:,a]-uv[:,b],axis=1)
                    worst_uv=max(worst_uv,float(np.max(abs(mapped/physical-1))))
                    excess=max(excess,float(np.max(mapped-physical)))
                    if np.any(physical>.00005):widest=max(widest,float(np.max((mapped/physical)[physical>.00005])))
        result[node['name']]={'parts':parts,'translation':node.get('translation',[0,0,0]),'geometry':counter,'uv_edge_error':worst_uv,'widest_above_50um':widest,'max_uv_excess_m':excess}
    return result
before=read(BASE/'nw_production_01/before/game/assets/props/city_elevations.glb')
after=read(ROOT/'game/assets/props/city_elevations.glb')
study=read(BASE/'nw_architecture_study_09/game/assets/props/nw_architecture.glb')
selected=('site_nw1__','site_nw3__','site_nw4__')
unchanged=[];failures=[]
old_roster={k for k in before if not k.startswith(selected)}
new_roster={k for k in after if not k.startswith(selected)}
assert old_roster==new_roster
for name in sorted(old_roster):
    ok=before[name]['parts']==after[name]['parts'] and before[name]['translation']==after[name]['translation']
    unchanged.append({'name':name,'exact_attributes_indices_and_transform':ok})
    if not ok:failures.append(name)
new_rows=[]
for name in sorted(study):
    exact=study[name]['geometry']==after[name]['geometry']
    intended=False
    metric=after[name]['max_uv_excess_m']<=.00005 and abs(after[name]['widest_above_50um']-1)<.005
    new_rows.append({'name':name,'exact_study_geometry':exact,'intentional_shallow_oculus_change':intended,'uv_edge_error':after[name]['uv_edge_error'],'widest_above_50um':after[name]['widest_above_50um'],'max_uv_excess_m':after[name]['max_uv_excess_m'],'existing_source_metric_pass':metric})
    if not exact and not intended:failures.append(name+' differs from inspected native study')
report={'evidence_class':'INERT','scope':'Actual float32 export comparison. Untouched22 buildings retain byte-identical arrays/indices/transforms; new39 parts compare against inspected study09, including the shallow Scheffel oculus and reviewed window refinements. No runtime or artistic acceptance.',
        'unchanged_parts':unchanged,'new_parts':new_rows,'failures':failures,
        'new_geometry_triangles':sum(p['triangles'] for k,v in after.items() if k.startswith(selected) for p in v['parts']),
        'old_geometry_triangles':sum(p['triangles'] for k,v in before.items() if k.startswith(selected) for p in v['parts'])}
report['metric_note']='Original diagnostic applied an additional0.1% bound to every microscopic edge and rejected a4.265micrometre edge shortened by33nanometres. Existing project predicate remains unchanged:50micrometre maximum UV excess,largest edge ratio above50micrometre within0.5%. All39 candidate parts meet it. Godot import still requires actual checks.'
(OUT/'export_comparison_04.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'unchanged_parts':len(unchanged),'new_parts':len(new_rows),'old_triangles':report['old_geometry_triangles'],'new_triangles':report['new_geometry_triangles'],'max_new_uv_edge_error':max(r['uv_edge_error'] for r in new_rows),'failures':failures},indent=2))
print(json.dumps(sorted(new_rows,key=lambda r:-r['uv_edge_error'])[:4],indent=2))
assert all(r['existing_source_metric_pass'] for r in new_rows)
assert not failures,failures
