$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:/ov/city'
$cityBlender='C:/Program Files/Blender Foundation/Blender 5.2/blender.exe'
$cityEvidence='C:/ov/reports/city_streets_20261029'
$env:CITY_ELEVATIONS_REVIEW_DIR="$cityEvidence/nw_production_03"
New-Item -ItemType Directory -Path "$cityEvidence/nw_production_03/sources" -Force | Out-Null
foreach($citySource in @('art/blender/scripts/build_city_elevations.py','art/blender/scripts/build_city_elevation_lods.py','art/blender/scripts/city_commercial_architecture.py','art/data/city_elevations/source_plan.json','game/scripts/building/orison_v2_city_shells.gd')){
    $cityTarget=Join-Path "$cityEvidence/nw_production_03/sources" $citySource
    New-Item -ItemType Directory -Path (Split-Path -Parent $cityTarget) -Force | Out-Null
    Copy-Item -LiteralPath $citySource -Destination $cityTarget
}
function Invoke-CityNative([string]$name,[string]$script){
    $cityLog="$cityEvidence/$name.log"
    if(Test-Path -LiteralPath $cityLog){throw "Preserve original log: $cityLog"}
    $cityStarted=[DateTime]::UtcNow.ToString('o')
    & $cityBlender --background -t 2 --python-exit-code 1 --python $script *> $cityLog
    $cityExit=$LASTEXITCODE
    [ordered]@{evidence_class='INERT';script=$script;started_utc=$cityStarted;finished_utc=[DateTime]::UtcNow.ToString('o');exit_code=$cityExit;threads=2} | ConvertTo-Json | Set-Content -Encoding utf8 "$cityEvidence/$name.execution.json"
    if($cityExit -ne 0){throw "$name failed; original output retained"}
    Write-Output "$name PASS"
}
Invoke-CityNative 'nw_masts_replay_01' 'art/blender/scripts/build_city_masts.py'
Invoke-CityNative 'nw_aerials_replay_01' 'art/blender/scripts/build_city_aerials.py'
Invoke-CityNative 'nw_tanks_replay_01' 'art/blender/scripts/build_city_tanks.py'
Invoke-CityNative 'nw_beacons_replay_01' 'art/blender/scripts/build_city_beacons.py'
Invoke-CityNative 'nw_closure_replay_01' 'art/blender/scripts/build_city_closure.py'
Invoke-CityNative 'nw_elevations_production_03' 'art/blender/scripts/build_city_elevations.py'
Invoke-CityNative 'nw_elevation_lods_production_01' 'art/blender/scripts/build_city_elevation_lods.py'
Invoke-CityNative 'nw_streets_replay_01' 'art/blender/scripts/build_city_streets.py'
