"""Actual native/round-trip and retained-equipment review, external only."""
from pathlib import Path
import bpy,json,collections,hashlib,math
from mathutils import Vector
ROOT=Path('C:/ov/city');SOURCE=Path(__file__).parent/'nw_architecture_study_09';OUT=Path(__file__).parent/'nw_window_review_10';OUT.mkdir(exist_ok=False)
bpy.ops.wm.open_mainfile(filepath=str(SOURCE/'art/blender/nw_architecture.blend'))
report=json.loads((SOURCE/'construction.json').read_bytes())
buildings={r['id']:r for r in report['buildings']}
plans={r['id']:r for r in json.loads((ROOT/'art/data/city_elevations/source_plan.json').read_bytes())['buildings']}
native=list(bpy.data.collections['NWArchitectureExport'].objects)
def triangles(o):
    return collections.Counter(tuple(sorted(tuple(float(v) for v in o.matrix_world@o.data.vertices[i].co) for i in f.vertices)) for f in o.data.polygons)
# Rebuild the preview finish from the actual production recipe. Original study09
# omitted alpha and therefore cannot judge the backing/blinds through its glass.
import sys
sys.path.insert(0,str(ROOT/'art/blender/scripts'))
from fabrication_native_batch import material
catalog=json.loads((ROOT/'game/data/runtime_material_sets.json').read_text())['materials']
glass=material(ROOT,'Window_review_production_glass',dict(catalog_key='mirror_aged',tint=[.18,.23,.25,1],pigment=1.,normal=.12,roughness=.45,metallic=0.),catalog)
bsdf=glass.node_tree.nodes['Principled BSDF']
bsdf.inputs['Alpha'].default_value=.28;bsdf.inputs['Transmission Weight'].default_value=.5;bsdf.inputs['IOR'].default_value=1.52
for obj in native:
    if obj.name.endswith('__mirror_aged'):obj.data.materials.clear();obj.data.materials.append(glass)
expected={o.name:triangles(o) for o in native};mats={o.name:o.data.materials[0] for o in native}
before=set(bpy.data.objects);bpy.ops.import_scene.gltf(filepath=str(SOURCE/'game/assets/props/nw_architecture.glb'))
imported=[o for o in bpy.data.objects if o not in before and o.type=='MESH']
assert len(imported)==len(native),len(imported)
roundtrip=[]
for o in imported:
    name=o.name.split('.')[0];actual=triangles(o)
    assert actual==expected[name],(name,'changed float32 triangle geometry')
    assert len(o.data.uv_layers)==1,name
    o.data.uv_layers.active.name='Metres';o.data.materials.clear();o.data.materials.append(mats[name])
    roundtrip.append({'name':name,'exact_triangle_positions':True,'triangles':sum(actual.values())})
context=[];context_bindings={}
for family in ['city_elevations','city_masts','city_aerials','city_tanks']:
    path=ROOT/f'art/blender/{family}.blend';context_bindings[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
    with bpy.data.libraries.load(str(path),link=False) as (available,loaded):
        names=['site_nw2'] if family=='city_elevations' else list(buildings)+['site_nw2']
        loaded.objects=[n for n in available.objects if any(n.startswith(k+'__') for k in names) and 'ClosedFabricatedTree' not in n]
    for o in loaded.objects:
        if o.type!='MESH' or o.hide_render:continue
        bpy.context.scene.collection.objects.link(o);o.hide_set(False);o.hide_viewport=False;o.hide_render=False
        context.append(o)
bpy.context.view_layer.update()
for o in native+imported+context:
    identity=o.name.split('__')[0]
    offset=plans[identity].get('assembly_translation_m',[0,0,0]);o.location+=Vector(offset)
for image in bpy.data.images:
    if image.source!='FILE' or image.packed_file:continue
    p=ROOT/'game/assets/building/textures'/Path(image.filepath).name
    assert p.is_file(),p
    image.filepath=str(p);image.reload();assert min(image.size)>0,image.name
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=12;scene.cycles.use_denoising=True
scene.render.threads_mode='FIXED';scene.render.threads=2
scene.render.resolution_x=1000;scene.render.resolution_y=950;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX'
world=bpy.data.worlds.new('Native northwest review world');scene.world=world;world.use_nodes=True
world.node_tree.nodes['Background'].inputs[0].default_value=(.16,.19,.24,1);world.node_tree.nodes['Background'].inputs[1].default_value=.55
sun=bpy.data.objects.new('Review key',bpy.data.lights.new('Review key','SUN'));scene.collection.objects.link(sun)
sun.rotation_euler=(math.radians(38),math.radians(-24),math.radians(-35));sun.data.energy=2.5;sun.data.angle=math.radians(15)
bpy.ops.mesh.primitive_plane_add(size=300,location=(-43,0,-.13));floor=bpy.context.object
floor_mat=bpy.data.materials.new('Neutral review pavement');floor_mat.diffuse_color=(.12,.13,.14,1);floor.data.materials.append(floor_mat)
camera=bpy.data.objects.new('Native northwest camera',bpy.data.cameras.new('Native northwest camera'));scene.collection.objects.link(camera);scene.camera=camera
captures=[]
def shoot(name,visible,roundtripped,at,target,scale=None,resolution=(1000,950)):
    for o in native:o.hide_render=roundtripped or o.name.split('__')[0] not in visible
    for o in imported:o.hide_render=not roundtripped or o.name.split('__')[0] not in visible
    for o in context:o.hide_render=o.name.split('__')[0] not in visible
    camera.location=at;camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
    camera.data.type='ORTHO' if scale else 'PERSP';camera.data.ortho_scale=scale or 25;camera.data.lens=38
    scene.render.resolution_x,scene.render.resolution_y=resolution
    scene.render.filepath=str(OUT/(name+'.png'));bpy.ops.render.render(write_still=True)
    p=OUT/(name+'.png');captures.append({'path':p.name,'raw_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'buildings':visible,'roundtrip':roundtripped,'camera':list(at),'target':list(target)})
for identity,r in buildings.items():
    x,y,X,Y=r['registered_rect'];dx,dy,dz=r['assembly_translation_m'];cx=(x+X)/2+dx;front=y+dy;top=r['body_top']+dz
    shoot(identity+'_native_front',[identity],False,(cx,front-35,top/2+.6),(cx,front,top/2+.6),top+6)
    shoot(identity+'_roundtrip_street',[identity],True,(cx+9,front-29,1.7),(cx,front+1.0,top/2),None)
shoot('northwest_row_native',['site_nw1','site_nw2','site_nw3','site_nw4'],False,(-42,-48,14),(-42,3,10),46,(1600,900))
shoot('northwest_roofs_native',['site_nw1','site_nw2','site_nw3','site_nw4'],False,(-33,-25,36),(-42,3,15),49,(1600,1000))
result={'evidence_class':'INERT','scope':'Exact native/export round-trip triangle-position multisets and8 actual native renders, with original roof hardware and neighboring Hunters Point study as context. Images await actual inspection. No runtime, route, loaded mipmap, cost or artistic acceptance.',
        'roundtrip':roundtrip,'context_meshes':len(context),'context_bindings':context_bindings,'captures':captures}
(OUT/'native_review.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print('NW_REVIEW_READY',len(captures),len(context),flush=True)
