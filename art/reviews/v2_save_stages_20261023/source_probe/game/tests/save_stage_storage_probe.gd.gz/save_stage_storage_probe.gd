extends "res://scripts/game/reality_save_storage.gd"
## INERT diagnostic: same storage operations, optional sparse UTF-8 candidate.
var fast_utf8 := false
var records: Array = []
var non_ascii := RegEx.new()

func _init() -> void:
	assert(non_ascii.compile("[\\x{80}-\\x{ff}]+") == OK)

func sparse_utf8(bytes: PackedByteArray) -> bool:
	# Latin-1 is only an index-preserving byte map, never decoded save content.
	# Some String implementations stop at NUL; that case keeps the old validator.
	var mapped := bytes.get_string_from_ascii()
	if mapped.length() != bytes.size(): return super._valid_utf8(bytes)
	var at := 0
	var runs := 0
	while at < mapped.length():
		var found := non_ascii.search(mapped, at)
		if found == null: return true
		runs += 1
		if runs > 64: return super._valid_utf8(bytes)
		if not super._valid_utf8(bytes.slice(found.get_start(), found.get_end())): return false
		at = found.get_end()
	return true

func _valid_utf8(bytes: PackedByteArray) -> bool:
	var started := Time.get_ticks_usec()
	var result := sparse_utf8(bytes) if fast_utf8 else super._valid_utf8(bytes)
	records.append({"stage":"utf8", "usec":Time.get_ticks_usec()-started, "bytes":bytes.size()})
	return result

func _decode(bytes: PackedByteArray) -> Dictionary:
	var started := Time.get_ticks_usec()
	var result := super._decode(bytes)
	records.append({"stage":"decode", "usec":Time.get_ticks_usec()-started, "bytes":bytes.size()})
	return result

func _op(stage: String, operation: String, arguments: Dictionary) -> Dictionary:
	var started := Time.get_ticks_usec()
	var result := super._op(stage, operation, arguments)
	records.append({"stage":stage, "operation":operation, "usec":Time.get_ticks_usec()-started})
	return result

func _hash(bytes: PackedByteArray) -> String:
	var started := Time.get_ticks_usec()
	var result := super._hash(bytes)
	records.append({"stage":"hash", "usec":Time.get_ticks_usec()-started, "bytes":bytes.size()})
	return result
