extends Node3D
## INERT exact-engine control for redundant shadow setter invalidation.
var samples: Array=[]
func _ready() -> void:run.call_deferred()
func run() -> void:
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED);Engine.max_fps=0
	var camera:=Camera3D.new();camera.position=Vector3(0,5,7);add_child(camera);camera.look_at(Vector3.ZERO);camera.make_current()
	var light:=OmniLight3D.new();light.position=Vector3(0,3,0);light.omni_range=10.;light.shadow_enabled=true;light.omni_shadow_mode=OmniLight3D.SHADOW_CUBE;add_child(light)
	var mesh:=BoxMesh.new();mesh.size=Vector3(.22,.5,.22)
	for i in 400:
		var draw:=MeshInstance3D.new();draw.mesh=mesh;draw.position=Vector3((i%20-10)*.24,0,(i/20-10)*.24);add_child(draw)
	var rid:=get_viewport().get_viewport_rid();RenderingServer.viewport_set_measure_render_time(rid,true)
	for phase: String in ["stable_a","repeat","stable_b","guarded"]:
		for frame in 40:
			if phase=="repeat":light.shadow_enabled=true
			if phase=="guarded" and not light.shadow_enabled:light.shadow_enabled=true
			await RenderingServer.frame_post_draw
		var before:=Time.get_ticks_usec()
		for frame in 120:
			if phase=="repeat":light.shadow_enabled=true
			if phase=="guarded" and not light.shadow_enabled:light.shadow_enabled=true
			await RenderingServer.frame_post_draw
			var now:=Time.get_ticks_usec()
			samples.append({"phase":phase,"wall_ms":(now-before)/1000.,"shadow":light.shadow_enabled,"shadow_draws":RenderingServer.viewport_get_render_info(rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_SHADOW,RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME),"cpu_ms":RenderingServer.viewport_get_measured_render_time_cpu(rid),"gpu_ms":RenderingServer.viewport_get_measured_render_time_gpu(rid)});before=now
	var out:=OS.get_environment("SHOT_DIR");DirAccess.make_dir_recursive_absolute(out)
	FileAccess.open(out.path_join("setter_control.json"),FileAccess.WRITE).store_string(JSON.stringify({"evidence_class":"INERT","scope":"Static isolated scene, unchanged true shadow flag in every phase. Exact-engine positive control, not V2 performance or human acceptance.","samples":samples},"\t"))
	print("SHADOW SETTER CONTROL: completed ",samples.size()," samples")
	get_tree().quit()
