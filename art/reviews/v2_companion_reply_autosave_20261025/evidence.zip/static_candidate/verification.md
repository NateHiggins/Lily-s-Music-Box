# Candidate verification - f4ea2dba3026

- candidate `f4ea2dba302618d3dd6756430b3d314c522a09f6`
- base `6a0b6d666fe1221629f5af185e23864091a48de2`
- merge-base `6a0b6d666fe1221629f5af185e23864091a48de2`
- verified 2026-10-25T20:42:57Z from verifier `f4ea2dba3026`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 2 regressions, 0 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 0 |

## Blocking reasons (2)

- regression: systemic: drift.new_review 29 -> 30
- regression: systemic: new defect new_review:bc4d5af4323d170e

## Needs human review (not blocking) (2)

- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (2)

- systemic: drift.new_review 29 -> 30
- systemic: new defect new_review:bc4d5af4323d170e

## Accepted regressions (0)

- none

## Improvements (0)

- none

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (0)

- none

BLOCKED regression: systemic: drift.new_review 29 -> 30; regression: systemic: new defect new_review:bc4d5af4323d170e
