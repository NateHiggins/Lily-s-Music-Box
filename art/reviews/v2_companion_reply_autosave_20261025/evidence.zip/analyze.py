import json,sys,math
from pathlib import Path
p=Path(sys.argv[1]); d=json.loads(p.read_text())
def dist(v):
    v=sorted(v)
    if not v:return {}
    return {'n':len(v),**{k:round(v[min(len(v)-1,math.ceil(q*len(v))-1)],3) for k,q in [('p50',.5),('p95',.95),('p99',.99),('max',1)]},'over50':sum(x>50 for x in v),'over100':sum(x>100 for x in v)}
out={'evidence_class':'INERT','source':d['source'],'failures':[c for c in d['checks'] if not c['passed']],'phases':{}}
for phase in dict.fromkeys(x['phase'] for x in d['samples']):
    rows=[x for x in d['samples'] if x['phase']==phase and x['same_phase'] and x['wall_ms'] is not None]
    keys=[x for x in d['events'] if x['phase']==phase and x['kind']=='key' and x['pressed'] and x['code']==4194309]
    out['phases'][phase]={'wall_ms':dist([x['wall_ms'] for x in rows]),'gpu_ms':dist([x['render_gpu_ms'] for x in rows]),'render_cpu_ms':dist([x['render_cpu_ms'] for x in rows]),'enter_dispatch_ms':[round(x['dispatch_usec']/1000,3) for x in keys],'enter_to_postdraw_ms':[round(x['to_post_draw_usec']/1000,3) for x in keys]}
out['largest_intervals']=sorted([x for x in d['samples'] if x['wall_ms'] is not None],key=lambda x:x['wall_ms'],reverse=True)[:15]
p.with_name('analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
