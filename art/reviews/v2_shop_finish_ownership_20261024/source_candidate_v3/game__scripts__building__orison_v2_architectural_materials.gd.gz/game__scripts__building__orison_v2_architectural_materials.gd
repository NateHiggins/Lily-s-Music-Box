extends RefCounted
## Physical materials for the semantic geometry. The review palette is kept
## by the standalone blockout; the playable root explicitly enables this.
var cache: Dictionary = {}
var calibrated_inputs: Dictionary = {}

# Shared catalogue-key finish calibration, reviewed at fixed production light.
# Existing pigment maps, physical tile sizes and material identities remain.
# This only quiets the broad architecture; props retain their own finishes.
const FINISH := {
	"limewash_plaster": {"coverage":0, "has_detail":false, "parallax_mode":0,
		"pigment_variation":1.0, "normal_scale":1.0,
		"mask_amount":Vector4(0.0,0.025,0.0,0.0)},
	"arcade_terrazzo": {"coverage":0, "has_detail":false, "has_mask_tex":false,
		"mask_amount":Vector4.ZERO, "parallax_mode":0, "normal_scale":1.0},
	"door_paint": {"coverage":0, "has_detail":false, "has_mask_tex":false,
		"mask_amount":Vector4.ZERO, "relief_mul":1.0, "normal_scale":1.0},
	"bath_wall_tile": {"coverage":0, "has_detail":false, "has_mask_tex":false,
		"mask_amount":Vector4.ZERO, "relief_mul":1.0, "normal_scale":1.0},
	"bath_floor_tile": {"coverage":0, "has_detail":false, "has_mask_tex":false,
		"mask_amount":Vector4.ZERO, "relief_mul":1.0, "normal_scale":1.0,
		"mesh_uv_scale":Vector2(1.0/.6096,1.0/(.6096*.866025403784))},
	"concrete": {"pigment_variation":0.65, "detail_albedo_strength":0.015,
		"detail_normal_strength":0.10, "normal_scale":0.12,
		"mask_amount":Vector4(0.0,0.05,0.0,0.05)},
	"trim": {"pigment_variation":0.75, "detail_albedo_strength":0.015,
		"detail_normal_strength":0.10, "normal_scale":0.10,
		"mask_amount":Vector4(0.0,0.04,0.0,0.04)},
	"floor_oak": {"pigment_variation":0.55, "detail_albedo_strength":0.025,
		"detail_normal_strength":0.18, "normal_scale":0.20,
		"mask_amount":Vector4(0.0,0.08,0.0,0.06)},
	"plaster_stained": {"pigment_variation":0.60, "detail_albedo_strength":0.025,
		"detail_normal_strength":0.18, "normal_scale":0.20,
		"mask_amount":Vector4(0.0,0.08,0.0,0.06)},
	"terrazzo": {"pigment_variation":0.60, "detail_albedo_strength":0.025,
		"detail_normal_strength":0.18, "normal_scale":0.20,
		"mask_amount":Vector4(0.0,0.08,0.0,0.06)},
}

func key_for(part: String, room_class: String) -> String:
	if part.begins_with("B1_COAL_HEAP_"): return "soot"
	# Dossier slice 68 (ROOF_DECK_WEST-004): the house tank's boards take the catalogue's staved tank finish,
	# the skyline towers' own; plain timber read as brick at the tank's scale. The overflow butt stays timber.
	if part == "ROOF_TANK_BODY": return "tank_staves"
	if part.begins_with("ROOF_TANK_BUTT_"): return "timber"
	if part.begins_with("ROOF_TANK_"): return "cast_iron"
	if part.begins_with("ROOF_PARAPET_"): return "brick"
	if part == "Glazing": return "glass"
	if part == "Leaf": return "wood_dark"
	# Opaque oil paint hides the substrate's grain; the legacy trim library
	# reads as bare striped timber at window and door inspection distances.
	if part.begins_with("Jamb") or part.begins_with("Frame") or part == "Head": return "door_paint"
	if "Guard" in part: return "metal"
	if "Step" in part or part == "HalfLanding": return "stair"
	if part == "Floor":
		if room_class == "wet": return "bath_floor_tile"
		if room_class in ["public", "core"]: return "arcade_terrazzo"
		if room_class in ["service", "unresolved"]: return "concrete"
		return "floor_oak"
	if part == "Ceiling": return "limewash_plaster"
	if part == "ExteriorSoffit": return "concrete"
	if part == "BathroomTileWainscot": return "bath_wall_tile"
	if room_class == "wet": return "limewash_plaster"
	if room_class == "service": return "concrete"
	return "limewash_plaster"

func material_for(part: String, room_class: String) -> Material:
	var key := key_for(part,room_class)
	if key == "glass":
		if not cache.has(key):
			var glass := ShaderMaterial.new()
			glass.shader = preload("res://shaders/lamp_glass_surface.gdshader")
			preload("res://scripts/building/v2_clear_glass_finish.gd").apply(glass)
			cache[key] = glass
		return cache[key]
	var family := "walls"
	if part == "Floor": family = "floors"
	elif part in ["Ceiling", "ExteriorSoffit"]: family = "ceiling"
	elif key == "stair": family = "stairs"
	elif key in ["trim", "door_paint", "wood_dark", "metal"]: family = "trim"
	var recipe: Dictionary = {}
	for entry: Dictionary in SurfacePass.CLASSES:
		if entry.key == family:
			recipe = entry.recipe.duplicate()
			break
	if FINISH.has(key): recipe.merge(FINISH[key],true)
	var base := MatLib.get_mat(key)
	if key in ["stair", "concrete", "bath_wall_tile", "bath_floor_tile", "door_paint", "limewash_plaster", "arcade_terrazzo"]:
		# A semantic material needs the same catalogue identity as an imported
		# catalogue surface, otherwise its authored height map is never bound.
		# Keep the named copy stable without changing MatLib's shared resource.
		if not calibrated_inputs.has(key):
			var named := base.duplicate() as StandardMaterial3D
			named.resource_name = "M_" + key
			calibrated_inputs[key] = named
		base = calibrated_inputs[key]
	return SurfacePass.surface_for(base,recipe,key+":"+family,cache)
