# Gate board - 48da899cac85

- commit `48da899cac8565f69ab1ca264716e84e2be93ec0`
- tree `4fdc45b62eb3492a0997d8385b10ad5ad4d0c6f8`
- created 2026-10-22T21:03:00Z
- dirty paths: 2641

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| physical_import_sources | PASS | 0 | 0.34 | no defects counted |
| spatial | PASS | 0 | 5.2 | drift.new_reported 7 |
| reader | PASS | 0 | 3.45 | unread 1108; vs frozen baseline: new 0, resolved 200 |
| test:test_nook_readable_books | PASS | 0 | 0.12 | ran 4, failed 0 |
