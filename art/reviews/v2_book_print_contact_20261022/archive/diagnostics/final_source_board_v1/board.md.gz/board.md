# Gate board - 48da899cac85

- commit `48da899cac8565f69ab1ca264716e84e2be93ec0`
- tree `4fdc45b62eb3492a0997d8385b10ad5ad4d0c6f8`
- created 2026-10-22T20:56:38Z
- dirty paths: 2640

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| physical_import_sources | PASS | 0 | 0.36 | no defects counted |
| spatial | PASS | 0 | 5.16 | drift.new_reported 8 |
| reader | PASS | 0 | 3.42 | unread 1108; vs frozen baseline: new 0, resolved 200 |
| test:test_nook_readable_books | PASS | 0 | 0.16 | ran 4, failed 0 |
