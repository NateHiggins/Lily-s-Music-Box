# WHERE THINGS ARE WRITTEN DOWN

Seventy-odd documents live in this repository and another twenty-five in the
world compiler next door. This file is the map. **If you do not know where to
look, look here first.**

## Precedence â€” who wins when two documents disagree

1. **`design/ORISON_BIBLE.md`** â€” the covenant. It says so itself: where any
   other text disagrees, the Bible prevails until amended.
2. **The newest dated ruling** inside the Bible (`Â§VIII` carries them).
3. **This map**, for anything about where documents live.
4. Everything else.

A disagreement you cannot resolve is not a bug to paper over â€” the Bible has a
**Â§VI Disputed Texts** section for exactly that. Add to it rather than picking a
side quietly.

## The six kinds of document

Knowing which kind you are reading tells you how much to trust it.

| Kind | What it means | Where |
|---|---|---|
| **Covenant** | Rules. Binding until amended by the owner. | `design/ORISON_BIBLE.md` and the other `*_BIBLE.md` |
| **Reference** | How a subsystem actually works. Kept current. | `game/docs/`, `art/docs/`, `docs/` |
| **Brief / proposal** | **Not canon until ruled.** Says so at the top. | `design/*_BRIEF.md`, `docs/songbook_brief.md` |
| **Prompt sheet** | Inputs to asset generation. Historical once used. | `design/*_PROMPTS.md`, `*_PROMPT_SHEET.md` |
| **Brief in data shape** | Design written as JSON but read by nobody. Lives in `design/` so it is not mistaken for game data | `design/resident_decor_profiles.json` |
| **Queue** | Open work, one line each. Deleted when done. | `TASKS.md` |
| **Audit** | Evidence with a method and confidence levels. Findings graduate to the queue; the audit stays as the record | `design/AUDIT_*.md` |
| **Build guide** | How to build and verify. Mechanics only. | `HANDOFF.md`, `art/README.md`, `game/README.md` |

## Where to look forâ€¦

| If you want to knowâ€¦ | Read |
| Continuous paperback covers, bowed attached pages, editorial formats and measured book input costs | `design/V2_BOOK_EDITORIAL_AND_BINDING_2026-10-22.md` |
| Remade nook plant, fitted woven rug and actual-input entry/exit | `design/V2_NOOK_REVAMP_2026-10-22.md` |
| Shared native nook bindings, static lending spots and paired local world timings | `design/V2_NOOK_BINDINGS_2026-10-22.md` |
| Thin bookend sole collision repair and the combined 2,182-check library diagnostic | `design/V2_BOOKEND_BEARING_2026-10-22.md` |
| Static book placement, held stock, floating inspection and removal of the photographic lamp overlay | `design/V2_BOOK_SLOTS_AND_LIGHT_REMOVAL_2026-10-22.md` |
| World-fitting unracked hose, actual removal, bare-end targeting and remaining installation requirements | `design/V2_UNRACKED_HOSE_WORLD_FIT_2026-10-22.md` |
| Static-rack removal, a simpler full-length round-hose candidate and the remaining world-layout repair | `design/V2_UNRACKED_HOSE_2026-10-22.md` |
| Retired stored-hose simulation diagnostics and the owner's static-rack/simple-extended-hose direction | `design/V2_STORED_HOSE_DIAGNOSTICS_2026-10-22.md` |
| Repaired candidate hose skin, pending-grab feedback, expensive release and remaining installed water work | `design/V2_HOSE_SKIN_REPAIR_2026-10-22.md` |
| Full-length hose input, reduced rack, retained deformed-skin failure and remaining release/spray work | `design/V2_HOSE_FOLLOWER_STUDY_2026-10-22.md` |
| V2 player-only fire-door contact, transform drift, measured tail improvement and p95 tradeoff | `design/V2_FIRE_PLAYER_CONTACT_2026-10-21.md` |
| Uninstalled full-length hose candidate, physical support, release costs and remaining spray work | `design/V2_DEPLOYABLE_HOSE_STUDY_2026-10-21.md` |
| Fire-cabinet step-query repair, reduced hose density, paired frame distributions and remaining deployment work | `design/V2_HOSE_RESPONSIVENESS_2026-10-21.md` |
| Rejected exact-triangle stair acceleration, paired frame distributions and retained failures | `design/V2_STAIR_TRIANGLE_DIAGNOSIS_2026-10-21.md` |
| V2 physical caption-calibrator construction, exact spring return and current renewal status | `design/V2_CASE_CALIBRATOR_2026-10-21.md` |
| Corrected played profiling: diagnostic capture overhead at the hardware counter | `design/V2_COUNTER_CAPTURE_DIAGNOSIS_2026-10-21.md` |
| Final V2 performance distributions, part targeting, native leaf repairs and renewed qualifications | `design/V2_SHOP_DOOR_REPAIR_2026-10-21.md` |
| Measured V2 stutter diagnosis, restrained part targeting and remaining repair coverage | `design/V2_RESPONSIVENESS_REPAIR_2026-10-21.md` |
| Current main integration comparison, retained passing checks and explicit blockers | `design/V2_MAIN_INTEGRATION_REVIEW_2026-10-21.md` |
|---|---|
| Renewed upper-room and roof access, library shadow diagnosis and remaining full-shift work | `design/V2_UPPER_ACCESS_AND_LIBRARY_SHADOW_2026-10-21.md` |
| Renewed composed UV/PBR/mip qualification, native provenance and remaining visual work | `design/V2_SURFACE_RENEWAL_2026-10-21.md` |
| Fired-clay stove masonry, recessed joints and loaded surface qualification | `design/V2_STOVE_MASONRY_FINISH_2026-10-21.md` |
| Installed five-room stove stack, physical flue transmission and remaining appearance work | `design/V2_C_STOVE_INSTALLATION_2026-10-21.md` |
| C-room stove-stack candidate, rejected bays and actual-world construction discovery | `design/V2_C_STOVE_STACK_STUDY_2026-10-20.md` |
| Native sealed stove fitting, hand inspection and remaining C-stack installation | `design/V2_FLUE_BREAST_FITTING_2026-10-20.md` |
| Fresh terrain/footing sources, texture phase and fixed current roof ownership | `design/V2_GRADE_SOURCE_RENEWAL_2026-10-20.md` |
| Boiler chimney/roof airway, native sleeve and remaining apartment flue migration | `design/V2_FLUE_AIRWAY_2026-10-20.md` |
| Current single workspace and recovery of retired October worktrees | `design/WORKSPACE_CLEANUP_2026-10-20.md` |
| V2 parallel heating transmission, passive junctions and native route survey | `design/V2_ACOUSTIC_HEATING_2026-10-20.md` |
| V2 physical ventilation topology, scoped propagation and partial-network proof | `design/V2_ACOUSTIC_VENTILATION_2026-10-20.md` |
| Clean-checkout image import settings and retained original surface proof | `design/V2_PORTABLE_IMPORT_SETTINGS_2026-10-20.md` |
| Qualified native fittings, readable library and glass integration into main | `design/V2_NATIVE_FITTINGS_INTEGRATION_2026-10-20.md` |
| Measured roof-cabinet bypass, world-space lamp checks and checked spatial publication | `design/V2_ROOF_ACCESS_REPAIR_2026-10-20.md` |
| Current composed surface qualification and remaining source-bound route renewal | `design/V2_QUALIFICATION_RENEWAL_2026-10-20.md` |
| Glass refraction diagnosis and the retained loose reading-nook collection | `design/V2_NOOK_AND_GLASS_2026-10-20.md` |
| Unbounded physical library carry, distant native reconstruction and physical event origins | `design/V2_LIBRARY_WORLD_CARRY_2026-10-20.md` |
| Native library contact, inspection and installed-handling diagnostics | `design/V2_LIBRARY_HANDLING_2026-10-20.md` |
| Original book illustrations, thirty physical spreads and unfinished bookshelf interaction qualification | `design/V2_READABLE_LIBRARY_2026-10-20.md` |
| Construction-specific normal recipes, expressive cabinet glass and current qualification | `design/V2_CONSTRUCTION_NORMALS_2026-10-20.md` |
| Loaded handheld/character mip repair and remaining world qualification | `design/V2_SURFACE_MIP_REPAIR_2026-10-19.md` |
| Fitted native kitchen services, stop controls and installed diagnostics | `design/V2_KITCHEN_PLUMBING_2026-10-19.md` |
| Retired eye-level wall rail, retained trim and source renewal | `design/V2_EYE_RAIL_REMOVAL_2026-10-19.md` |
| Period-informed preparation surfaces, loose food tools and all 18 kitchen programmes | `design/V2_KITCHEN_PREPARATION_2026-10-19.md` |
| Faster native hose warm start, matched physical trajectory and remaining bottlenecks | `design/V2_FIRE_HOSE_WARM_START_2026-10-19.md` |
| Bounded floor-release bench, numerical regression runner and remaining hose physics | `design/V2_FIRE_HOSE_RELEASE_BENCH_2026-10-19.md` |
| Native hollow-cloth world contact, swept obstruction checks and remaining physics | `design/V2_FIRE_HOSE_WORLD_CONTACT_REVIEW_2026-10-19.md` |
| Native full-length hose skin, actual constrained hand motion and remaining physical integration | `design/V2_FIRE_HOSE_MOTION_REVIEW_2026-10-19.md` |
| Reduced full-length hose mesh, authored metre charts and loaded voxel-light surface review | `design/V2_FIRE_CAPACITY_SURFACE_REVIEW_2026-10-19.md` |
| Uninstalled full-length hose, taller rack bearings and remaining UV/deployment work | `design/V2_FIRE_HOSE_CAPACITY_STUDY_2026-10-19.md` |
| Thin native cabinet coatings, loaded PBR checks and retained steel support | `design/V2_FIRE_CASE_COATINGS_2026-10-19.md` |
| Eight installed fire-cabinet hand programmes, precise native contacts and remaining work | `design/V2_FIRE_INSTALLED_HAND_REVIEW_2026-10-19.md` |
| Native fire-cabinet floor refit, stable loose stock and preceding diagnostic failures | `design/V2_FIRE_FLOOR_AND_HAND_REVIEW_2026-10-19.md` |
| Current native fire-fitting checkpoint, verified scope and remaining merge qualification | `design/V2_FIRE_CHECKPOINT_2026-10-19.md` |
| Native nozzle entry guide, phase-driven thread pickup and release without snapping | `design/V2_FIRE_NOZZLE_PICKUP_2026-10-19.md` |
| Carried voxel light offset, smaller beam and lower intensity comparisons | `design/V2_CARRIED_LIGHT_OFFSET_2026-10-19.md` |
| Current city massing, recessed windows, retained roof contacts and qualification | `design/V2_CITY_ELEVATIONS_2026-10-18.md` |
| Qualified period-informed city context, original six-run proof and remaining appearance work | `design/V2_CITY_CONTEXT_REPORT_2026-10-19.md` |
| Period sources and applied November 1928 Queens skyline direction | `design/V2_QUEENS_1928_CITY_REFERENCE_2026-10-18.md` |
| Follow-up city visibility, distant native grade and varied window stock candidate | `design/V2_CITY_VISIBILITY_AND_GRADE_2026-10-18.md` |
| Repaired service approaches, retained heating ports and native operable core doors | `design/V2_SERVICE_CIRCULATION_2026-10-18.md` |
| Completed service qualification, clean regression comparison and remaining V2 blockers | `design/V2_SERVICE_CIRCULATION_REPORT_2026-10-18.md` |
| Original basement-to-roof-and-back room access and six independently validated direct service thresholds | `design/ORISON_V2_SERVICE_SPATIAL_ACCESS_CHECKPOINT_2026-10-18.md` |
| Six supported public landing programmes, fitted signs, repaired F01 passage and completed automated qualification | `design/V2_PUBLIC_LANDING_INTEGRATION_2026-10-18.md` |
| Original single-placement six-floor played landing access; separate broader and human gates | `design/ORISON_V2_PUBLIC_LANDING_SPATIAL_ACCESS_CHECKPOINT_2026-10-18.md` |
| Measured public landing platform unions and unsupported legacy shells | `design/V2_PUBLIC_LANDING_FOOTPRINTS_2026-10-18.md` |
| Wall-stock fitting, native hanging supports, doorstep stock and current clearance qualification | `design/V2_WALL_STOCK_CLEARANCE_2026-10-18.md` |
| Original six-region continuous played access, strict regional admission and remaining V2 blockers | `design/V2_EXTERIOR_REGION_REPORT_2026-10-19.md` |
| Retained public-region ownership, actual street/arcade/dogleg walks and deferred hand/audio lifecycle repairs | `design/V2_PUBLIC_REGION_OWNERSHIP_2026-10-18.md` |
| Measured V2 startup costs and exact comparison of bounded room-trim fitting | `design/V2_STARTUP_TRIM_CULLING_2026-10-18.md` |
| Current four-face arcade clock installation and pending composed qualification | `design/V2_ARCADE_CLOCK_INSTALL_2026-10-18.md` |
| Earlier uninstalled arcade clock kit and native comparisons | `design/V2_ARCADE_CLOCK_CANDIDATE_2026-10-18.md` |
| Folded arcade lantern roof, real top-light well and retained clock hanger | `design/V2_ARCADE_LANTERN_2026-10-18.md` |
| Finished-wall furniture fitting, retained service access and installed native arcade fabric | `design/V2_FINISHED_WALL_CLEARANCE_2026-10-18.md` |
| Native work-lamp source apertures and controlled storefront reflection diagnosis | `design/V2_WORK_LIGHT_APERTURES_2026-10-18.md` |
| Bodega tile scale/stock, registered limestone, lower fascia emission and optical controls | `design/V2_STREET_FINISH_2026-10-18.md` |
| Played-home proof renewal, finite stock identity audit and main regression repair | `design/V2_MAIN_REGRESSION_REPAIR_2026-10-18.md` |
| Native construction shed, custom mirrored softwood, retained dogleg and current qualification | `design/V2_CONSTRUCTION_SHED_2026-10-18.md` |
| Physical Lena service round, actual workshop-part delivery, disk rebuild and geometry-bound proof | `design/V2_PHYSICAL_SERVICE_ROUND_2026-10-17.md` |
| Cast radiator rim profiles, retained sealing datums and current joint review | `design/V2_RADIATOR_SECTION_JOINTS_2026-10-17.md` |
| Worked control shading, calibrated resin migration, switch UVs and retained curved textile charts | `design/V2_CONTROL_FINISH_2026-10-17.md` |
| Native porter-board dispatch keys, real lift binding, disk restoration and remaining appearance work | `design/V2_ANNUNCIATOR_DISPATCH_2026-10-17.md` |
| Current bounded room reflections, ceiling shadow repair and loaded surface qualification, with remaining appearance work | `design/V2_REFLECTION_INSTALL_2026-10-17.md` |
| Rounded sewn seating panels, retained loose-cushion bearings and current verification | `design/V2_SEATING_POLISH_2026-10-17.md` |
| Earlier loaded normal frames, room-reflection comparisons and the unmounted lighting prototype | `design/V2_ROOM_REFLECTION_REVIEW_2026-10-17.md` |
| Current opal car-indicator lenses, seated bezels and retained lamp-material ownership | `design/V2_ANNUNCIATOR_LAMPS_2026-10-17.md` |
| Native annunciator bezels, axles, eased reset stock and scoped detail review | `design/V2_ANNUNCIATOR_DETAIL_2026-10-17.md` |
| Native annunciator service, actual input and serviced-board disk reconstruction, with unfinished dispatch and appearance work | `design/V2_ANNUNCIATOR_PHYSICAL_SERVICE_2026-10-17.md` |
| Matched native vent threads, physical cap travel, legacy depth migration and lengthwise timber grain | `design/V2_RADIATOR_THREADED_VENT_2026-10-17.md` |
| Native radiator repair observation, preserved job/custody authorities, porter intervention history and pending route qualification | `design/V2_RADIATOR_PHYSICAL_REPAIR_2026-10-17.md` |
| Local WIP native radiator cutover, partial physical controls, scoped checks and remaining repair work | `art/reviews/v2_radiator_cutover_20261017/README.txt` |
| Portable native radiator refit kit, clean-checkout publication verification and pending game installation | `design/V2_RADIATOR_NATIVE_KIT_2026-10-17.md` |
| Four additional radiator installations, portable native refit, clearance discoveries and pending verification | `design/V2_HEATING_REFIT_2026-10-17.md` |
| Current restored-front lighting installation, physical switches, disk reconstruction and open fitting/qualification work | `design/V2_FRONT_LIGHTING_INSTALL_2026-10-17.md` |
| Verified native front-lighting exports, support optimization and remaining game integration | `design/V2_FRONT_LIGHTING_EXPORT_2026-10-17.md` |
| Earlier restored-front fitting prototype and rejected export attempts | `design/V2_FRONT_LIGHTING_NATIVE_2026-10-16.md` |
| Current nineteen-emitter installation, shared lobby takeoff, waiting-bay clearance, qualified contracts and remaining V2 work | `design/V2_LOBBY_HEATING_2026-10-16.md` |
| Eighteen-emitter native heating foundation, supported mains, floor sleeves and radiator tailpieces | `design/V2_HEATING_DISTRIBUTION_2026-10-16.md` |
| Native patrol station transmission, crank lockout, source-bound checks and remaining work | `design/V2_STATION_TRANSMISSION_2026-10-16.md` |
| Patrol instrument direct manipulation, native detector and register changes, current verification and remaining polish | `design/V2_PATROL_CONTROLS_2026-10-16.md` |
| Physical roof-tank and dumbwaiter controls, native fitting and save verification | `design/V2_SERVICE_CONTROLS_2026-10-13.md` |
| Physical fuse replacement, cabinet/main controls, loose-part handling and current validation status | `design/V2_PHYSICAL_FUSE_REPAIR_2026-10-13.md` |
| Played access to 60 rooms in the remaining nine apartments, with 5B furniture circulation repaired | `design/ORISON_V2_REMAINING_APARTMENT_SPATIAL_ACCESS_CHECKPOINT_2026-10-13.md` and `design/V2_APARTMENT_CLEARANCE_2026-10-13.md` |
| Click-to-grab physical interaction and retirement of toggles/minigames | `design/DIRECT_MANIPULATION_2026-10-12.md` and Bible §VIII.5.l |
| Registered bathroom tile PBR, continuous grout UVs and clean floor repetition | `design/V2_BATHROOM_TILES_2026-10-12.md` |
| Current roof program access, guarded lift motion and source-owned plant purposes | `design/ORISON_V2_ROOF_PROGRAM_SPATIAL_ACCESS_CHECKPOINT_2026-10-12.md` |
| Bedding folds, sewn edges, eased timber and current installed-bed verification | `design/V2_BEDDING_POLISH_2026-10-12.md` |
| Played spatial access proof for 43 further rooms across six apartments and staff facilities | `design/ORISON_V2_COMPLETION_SPATIAL_ACCESS_CHECKPOINT_2026-10-12.md` |
| Played spatial access proof for 19 rooms in 2A, 2B and 4B, with automatic proof expiry | `design/ORISON_V2_APARTMENT_SPATIAL_ACCESS_CHECKPOINT_2026-10-12.md` |
| Native cast sink bowls, open drains, movable plugs and rounded water surfaces | `design/V2_KITCHEN_CASTINGS_2026-10-12.md` |
| Native kitchen faucets, fitted sink frames and independent hot/cold checks | `design/V2_KITCHEN_SINKS_2026-10-12.md` |
| Native raised-panel doors, actual keyways and fitted entrance hardware | `design/V2_DOOR_POLISH_2026-10-12.md` |
| Physical roof lighting supply, wall ports and supported overhead bridge | `design/V2_ROOF_LIGHTING_SUPPLY_2026-10-12.md` |
| Current recheck of the historical public-stair route failures | `design/V2_PUBLIC_STAIR_ROUTE_RECHECK_2026-10-12.md` |
| External receiver battery trays, terminal bores and fitted four-lead supplies | `design/V2_MEDIA_BATTERY_SUPPLY_2026-10-12.md` |
| Fitted AC receiver/projector leads, clips and floor receptacles | `design/V2_MEDIA_AC_SUPPLY_2026-10-12.md` |
| Native active household radio families and projector machines | `design/V2_ACTIVE_HOUSEHOLD_MEDIA_2026-10-12.md` |
| Roof plant metal calibration and two native switched cage fixtures | `design/V2_ROOF_PLANT_FINISH_LIGHTING_2026-10-12.md` |
| Actual V2 UV sampling, metre architectural charts and scoped roof access | `design/V2_UV_APPLICATION_2026-10-12.md` and `design/ORISON_V2_ROOF_ACCESS_CHECKPOINT_2026-10-12.md` |
| Native basement resident cages, retained stock fit and all-eighteen access | `design/V2_BASEMENT_STORAGE_2026-10-11.md` and `design/ORISON_V2_BASEMENT_STORAGE_CHECKPOINT_2026-10-11.md` |
| First-slice runtime contracts, actual save/reconstruction and remaining V2 blockers | `design/V2_FIRST_SLICE_CONTRACTS_2026-10-11.md` and `design/ORISON_V2_FIRST_SLICE_RUNTIME_COMPOSITION_CHECKPOINT_2026-10-11.md` |
| Native hollow mail compartments, delivery stock and retained 4B controls | `design/V2_NATIVE_MAIL_BANK_2026-10-11.md` |
| Source-owned panel-to-riser branch, real wall ports and relocated enamel inspection marks | `design/V2_ELECTRICAL_CONNECTIONS_2026-10-11.md` |
| Supported native electrical riser, real slab sleeves and retained fuse authority | `design/V2_ELECTRICAL_SERVICE_2026-10-11.md` |
| Native fire-service stations, retained maintenance controls and delayed software PBR | `design/V2_FIRE_SERVICE_2026-10-11.md` |
| Four native Edison fuse seats and telephone request-lamp PBR retention | `design/V2_FUSE_BLOCK_2026-10-11.md` |
| Clear upper B entry fittings, six private entry routes and explicit clothing/records storage | `design/ORISON_V2_UPPER_ENTRY_STORAGE_CHECKPOINT_2026-10-11.md` and `design/V2_UPPER_ENTRY_STORAGE_2026-10-11.md` |
| Native upper household materials, desk supports and production-size approach checks | `design/V2_UPPER_HOUSEHOLD_CHECKS_2026-10-11.md` |
| Native apartment partitions, active PBR bindings and retained control/teardown checks | `design/V2_NATIVE_APARTMENT_CHECKS_2026-10-11.md` |
| Corrected shaft-clear review routes and retained continuous traversal checks | `design/V2_ROUTE_FIXTURES_2026-10-11.md` |
| Adjustable resident blinds, curtain variants, saved settings and reviewed window stock | `game/docs/V2_WINDOW_TREATMENTS.md` and `design/V2_WINDOW_TREATMENTS_2026-10-11.md` |
| Continuous millwork and seasonal NYC weather integration | `game/docs/V2_MILLWORK_AND_WEATHER.md` and `design/V2_MILLWORK_WEATHER_2026-10-11.md` |
| Integrated V2 dossier follow-ups, remaining failures and final merge verification | `design/V2_DOSSIER_FOLLOWUPS_INTEGRATION_2026-10-11.md` and `design/V2_ENVIRONMENT_DOSSIER_FOLLOWUPS_REPORT_2026-10-10.md` |
| Courtyard and city-ground asphalt finish, retained native geometry and collision | `design/V2_GROUND_FINISH_2026-10-08.md` |
| Neighboring city galvanized roof finish and retained parapet/hardware checks | `design/V2_CITY_ROOF_FINISH_2026-10-08.md` |
| Rear service alley coping, neutral iron and retained geometry | `design/V2_ALLEY_FINISH_2026-10-08.md` |
| Native street paving detail, fitted curb endpoint and original street crossing | `design/V2_STREET_PAVING_2026-10-08.md` and `art/blender/street_paving_details.md` |
| Next V1-to-V2 import batch, discovery baseline and dossier closeout | `design/V2_IMPORT_RESUME_2026-10-08.md` |
| Completed owner 40-card dossier scope, 39 reviewed items and conditional G15 | `design/ORISON_V2_OWNER_BUILDING_FINISHES_2026-10-08.md` and `output/pdf/V2_dossier_implementation_review.pdf` |
| Current room/city geometry and texture review, fitted door motion and honest ledger refresh | `design/V2_BUILDING_SURFACE_FINISH_2026-10-05.md` and `art/blender/building_surface_finish.md` |
| Pawnbroker original passive clock wall, fitted cases/dials and real party-wall bearings | `art/blender/pawn_clocks.md` and `design/V2_PAWN_CLOCKS_2026-10-07.md` |
| Pawnbroker hollow display cases, supported passive window stock and local clear glazing | `art/blender/pawn_display.md` and `design/V2_PAWN_DISPLAY_2026-10-07.md` |
| Fast geometry/texture batches, changed-input planning and one-world validation | `art/blender/v2_batch_workflow.md` |
| Five native task-lamp variants and the existing V2 bench lamp | `art/blender/task_lamps.md` |
| Original basement reading nook and all five fitted task lamps | `art/blender/reading_nook.md` |
| Native household shelves, sink frames, wall cupboards and twelve sliding preparation cabinets | `art/blender/domestic_storage.md` and `design/V2_DOMESTIC_STORAGE_2026-10-07.md` |
| All 21 native wardrobes, original hinges and copied basement repair bench | `art/blender/household_wardrobes.md` and `design/V2_HOUSEHOLD_WARDROBES_2026-10-07.md` |
- **art/blender/household_objects_radios.md** — source-owned passive objects and five original radio mechanisms; scoped geometry/texture review.
| Shared native variants for all 103 apartment seating, tables and nightstands | `art/blender/domestic_furniture.md` and `design/V2_APARTMENT_FURNITURE_2026-10-07.md` |
| All 55 tabletop props, native Vantry and five-lamp surface refinement | `art/blender/desktop_stock.md` and `design/V2_DESKTOP_STOCK_2026-10-07.md` |
| Five fitted apartment work tables and strictly additive material reuse | `art/blender/work_tables.md` and `design/V2_WORK_TABLES_2026-10-07.md` |
| Pawnbroker parcel racks, grille counter, safe and remaining passive stock | `art/blender/pawn_fittings.md` |
| Model Laundry parcel shelves, ticket wire and transaction furniture | `art/blender/laundry_trade.md` |
| Nine-family slender-stock grain repair and proven reuse of unchanged dependencies | `design/V2_WOOD_GRAIN_2026-10-07.md` |
| Eleven fitted closed shop back doors and the empty funeral window stand | `art/blender/shop_joinery.md` and `design/V2_SHOP_JOINERY_2026-10-07.md` |
| Corrected linked native context, fitted furniture edges and dependent support checks | `design/V2_CONTEXT_FITS_2026-10-07.md` |
| Original high-level shop glazing, split sash members and rebated plaster | `art/blender/shop_clerestories.md` |
| Fitted Keys Cut board, passive machinery, supported display and unchanged copying authority | `art/blender/locksmith_fittings.md` and `design/V2_LOCKSMITH_FITTINGS_2026-10-05.md` |
| Fitted cobbler machines, open paired shoes, fine dust finish and sampled rear approach | `art/blender/cobbler_fittings.md` and `design/V2_COBBLER_FITTINGS_2026-10-05.md` |
| Source-owned News/Cigars papers, glazed stock, pipe bowls, counter and seated proprietor stool | `art/blender/news_fittings.md` and `design/V2_NEWS_CIGARS_FITTINGS_2026-10-05.md` |
| Original Hardware/Paint ordered drawer wall, aisle-facing panels and supported paint bench | `art/blender/hardware_drawers.md` and `design/V2_HARDWARE_DRAWERS_2026-10-05.md` |
| Original Hardware/Paint passive balance, unloaded shaker and supported mixing paddle | `art/blender/hardware_apparatus.md` and `design/V2_HARDWARE_APPARATUS_2026-10-05.md` |
| Original Hardware/Paint bins, open coupling stock, window stand and service counter | `art/blender/hardware_stock.md` |
| Original Hardware/Paint glass stand, seven tools with one empty silhouette, and leaning ladder | `art/blender/hardware_tools.md` and `design/V2_HARDWARE_TOOLS_2026-10-05.md` |
| Three original expensive photographic cameras and their supported window stand | `art/blender/photo_cameras.md` and `design/V2_PHOTO_CAMERA_DISPLAY_2026-10-05.md` |
| Photo's closed double-curtain darkroom, actor-controlled red lamp and Radio's supported window stand | `art/blender/photo_radio_fittings.md` |
| Original photographic counter, thin glass display chamber and seated ledger | `art/blender/photo_counter.md` and `design/V2_PHOTO_COUNTER_2026-10-05.md` |
| Original photographic rear shelves and fifteen seated supply cartons | `art/blender/photo_stock.md` and `design/V2_PHOTO_STOCK_2026-10-05.md` |
| Three original second-hand photographic enlargers and their supported high shelf | `art/blender/photo_enlargers.md` and `design/V2_PHOTO_ENLARGERS_2026-10-05.md` |
| Original photographic trays, tanks, dryer, folded tripods and supported flash tins | `art/blender/photo_process.md` and `design/V2_PHOTO_PROCESS_2026-10-05.md` |
| Seven source-owned unclaimed photographic prints, seated rail and local generated image content | `art/blender/photo_portraits.md` and `design/V2_PHOTO_PORTRAITS_2026-10-05.md` |
| Original photographic fixed glazing and declared local counter optics | `art/blender/photo_glazing.md` and `design/V2_PHOTO_GLAZING_2026-10-05.md` |
| Original Otis & Son counter and supported 54-drawer cabinet | `art/blender/druggist_drawers.md` and `design/V2_DRUGGIST_DRAWERS_2026-10-06.md` |
| Original druggist telephone and ledger, seated clear of the fitted drawer bank | `art/blender/druggist_counter.md` and `design/V2_DRUGGIST_COUNTER_2026-10-06.md` |
| Original druggist marble mortar and pestle, seated clear of retained stock | `art/blender/druggist_mortar.md` and `design/V2_DRUGGIST_MORTAR_2026-10-06.md` |
| Original druggist dispensary bench, balance case and raised round ranks | `art/blender/druggist_dispensary.md` and `design/V2_DRUGGIST_DISPENSARY_2026-10-06.md` |
| Original druggist poison cupboard and tactile bottles | `art/blender/druggist_cupboard.md` and `design/V2_DRUGGIST_CUPBOARD_2026-10-06.md` |
| Original druggist hero carboys and fitted window display | `art/blender/druggist_carboys.md` and `design/V2_DRUGGIST_CARBOYS_2026-10-06.md` |
| Original druggist unused soda fountain | `art/blender/druggist_fountain.md` and `design/V2_DRUGGIST_FOUNTAIN_2026-10-06.md` |
| Original funeral parlour lectern and deliberately empty bier | `art/blender/funeral_fittings.md` and `design/V2_FUNERAL_FITTINGS_2026-10-06.md` |
| Original funeral fixed curtain runs and ceiling-seated suspension | `art/blender/funeral_drapes.md` and `design/V2_FUNERAL_DRAPES_2026-10-06.md` |
| Original funeral potted palms and supported laid wreaths | `art/blender/funeral_foliage.md` and `design/V2_FUNERAL_FOLIAGE_2026-10-06.md` |
| Original Radio Service alignment bench and supported side leaf | `art/blender/radio_bench.md` and `design/V2_RADIO_BENCH_2026-10-06.md` |
| Radio Service fitted counter, seated ledger and pavement-facing horn/cone window display | `art/blender/radio_display.md` and `design/V2_RADIO_DISPLAY_2026-10-06.md` |
| Original Radio Service passive aerial-wire reels and supported iron ring | `art/blender/radio_wire.md` and `design/V2_RADIO_WIRE_2026-10-06.md` |
| Source-owned Radio Service charging jars, fitted rack and cabinet clearance | `art/blender/radio_battery.md` and `design/V2_RADIO_BATTERY_2026-10-06.md` |
| Seven passage receiving owners, keyboard play and persistent/unloaded board lifecycle | `art/blender/passage_receivers.md` and `design/V2_PASSAGE_RECEIVERS_2026-10-06.md` |
| Fitted receiving programme panel, actual window resizing and retained keyboard/owned teardown | `design/V2_RECEIVING_PANEL_2026-10-06.md` |
| Radio Service period receiving chassis, exact assembled-source ownership and retained programme | `art/blender/radio_receiving.md` and `design/V2_RADIO_RECEIVING_2026-10-06.md` |
| Original Radio Service four-level rack and fourteen seated stored valves | `art/blender/radio_stock.md` and `design/V2_RADIO_STOCK_2026-10-06.md` |
| Original Radio Service test instruments, seated valves and retained literal display | `art/blender/radio_apparatus.md` and `design/V2_RADIO_APPARATUS_2026-10-06.md` |
| Source-owned bodega stock, display case, icebox, practicals and preserved depletion | `art/blender/bodega_fittings.md` |
| Restored central front volume, connected galleries, coherent facade and refitted canopy | `design/V2_FRONT_VOLUME_RESTORATION_2026-10-13.md` |
| Source-fitted Orison front entrance, glazed oak leaf, original marquee and seated neon blade | `art/blender/front_facade.md` |
| Verified front-door routes, arrival correction, ledger refresh and retained street views | `design/V2_FRONT_FACADE_PROGRESS_2026-10-05.md` |
| Controlled front-faÃ§ade air finish, current key contract and remaining roof lighting check | `design/V2_FRONT_FACADE_AIR_FINISH_2026-10-05.md` |
| Fitted steel beneath the front-court roof and calibrated exterior soffit finish | `art/blender/front_court_roof.md` |
| Verified front-court roof contacts, strict landing envelopes and current ledger provenance | `design/V2_FRONT_COURT_ROOF_PROGRESS_2026-10-05.md` |
| Equal-output lamp comparison, waking V2 surface detail balance and current scoped contract | `design/V2_LAMP_SURFACE_BALANCE_2026-10-05.md` |
| Fixed interior and passage lights with retained source controls | `art/blender/fixed_lighting.md` |
| Native household refrigerators, source inventory and retained moving owners | `art/blender/household_fridges.md` |
| Native household stoves and fitted source service stock | `art/blender/household_stoves.md` |
| Fitted household toasters, medicine cabinets and source-owned moving stock | `art/blender/household_accessories.md` |
| Source-fitted bar gallery, original atlas, seated picture attachments and retained observations | `art/blender/bar_gallery.md` |
| Fitted Harukiya curtain folds, cloth-covered fascia and wall-supported rail | `art/blender/bar_stage.md` |
| Quiet trowelled concrete/slab maps, physical height calibration and retained city geometry | `art/blender/concrete_trowelled.md` |
| Source-owned public light court, fitted stairs/supports, pitched skylight and bounded roof weathering | `art/blender/light_court.md` |
| Fitted roof-wall base flashings, retained door apertures and single-owner deck/wall contacts | `art/blender/roof_base_flashings.md` |
| Fitted roof field, closed native finish, catalogue PBR maps and retained flat datum | `art/blender/roof_membrane.md` |
| Neighboring city parapet corner unions, original source stocks and local metre charts | `art/blender/city_closure.md` |
| October 1 composed city/bar batch, bound verification and next service connections | `design/V2_CITY_COMPOSITION_HANDOFF_2026-10-01.md` and `design/V2_CITY_PRODUCTION_MAP_2026-10-01.md` |
| Retained bar restroom clearance, working sink input and pool inspection fit | `art/blender/bar_service_access.md` |
| Supported bodega receiving room, fitted delivery leaf and sales-aisle route | `art/blender/bodega_receiving.md` |
| Fitted bodega display frame, upper lights and original hinged-leaf infill | `art/blender/bodega_frontage.md` |
| Resident original keys, permission at Keys Cut and saved hinged-door locks | `art/blender/resident_keys.md` |
| Fitted front public slab, retained room/shop/shed floor ownership and paving validation | `art/blender/front_pavement.md` |
| Bounded Orison subgrade, graded alley, boiler well and construction-stage drain collector | `art/blender/groundworks.md` |
| Operating boiler-well window, fitted hardware, physical panes and household setting | `art/blender/boiler_window.md` |
| Registered neighboring foundations, retained-slab fit and expanded terrain joins | `art/blender/city_foundations.md` |
| All ground-level city bases, southwest assembly separation and finite distant grade | `art/blender/city_grade.md` |
| Source-owned rooftop masts, supported guy anchors and exact city bearing checks | `art/blender/city_masts.md` |
| Original roof aerial frames, curved collectors and supported downlead terminals | `art/blender/city_aerials.md` |
| Original red mast-head beacon housings | `art/blender/city_beacons.md` |
| Calibrated local bronze, galvanized roof hardware and red lacquer | `art/blender/city_hardware_finishes.md` |
| Original neighbouring roof tanks, fitted hardware clearance and calibrated stave finish | `art/blender/city_tanks.md` |
| Common surface charts for fixed city roof hardware, with exact unchanged-geometry comparison | `art/blender/city_hardware_uvs.md` |
| Sloped service-bulkhead cover, open gutter outlet and fitted external rainleader | `art/blender/roof_service_weathering.md` |
| All eleven arcade thresholds, source parked leaves and closed-hours survey | `art/blender/arcade_thresholds.md` |
| Existing ventilation branch hangers, ceiling contact and mapped steel fittings | `art/blender/duct_supports.md` |
| Radiator wall-tie seating, slotted plates and retained service mechanisms | `art/blender/radiator_wall_ties.md` |
| Hollow ventilation sheets, seam airways and fitted fan slab/curb throats | `art/blender/ventilation_throats.md` |
| Ventilation storey slab ports, shared sleeve linings and upper branch clearance | `art/blender/ventilation_slab_ports.md` |
| Ventilation wall/chase/masonry ports, fitted steel linings and full-bore inspection | `art/blender/ventilation_fabric_ports.md` |
| Independent bodega lighting intake, supported conduit and fitted wall sleeves | `art/blender/bodega_power.md` |
| V2 city architecture/infrastructure continuation by location and transition | `design/V2_CITYSCAPE_CONTINUATION_PROMPT_2026-10-01.md` |
| Blender exterior masonry, deeper reveals and narrow light-slot preservation | `art/blender/exterior_masonry.md` |
| September 29 boiler fixes, verified commits, full-pass exceptions and continuation | `design/V2_FABRICATION_HANDOFF_2026-09-29.md` |
| Full V2 geometry work index, coverage decisions and pending material families | `art/blender/v2_fabrication_coverage.md` |
| Original shop chairs, chapel benches and soda-counter stools | `art/blender/shop_seating.md` |
| Original Diner griddle, soda pumps and supported mixer | `design/V2_DINER_APPARATUS_2026-10-06.md` |
| Original Diner hollow urns and empty pie display | `design/V2_DINER_URNS_2026-10-06.md` |
| Original Diner rear serving bench, narrow shelves and owned room reflection | `design/V2_DINER_BACKBAR_2026-10-06.md` |
| Original Diner clerk-facing mechanical register and thin empty cigar display | `design/V2_DINER_TILL_2026-10-06.md` |
| Original Diner supported serving counter, folded kickplate and seated ledger | `design/V2_DINER_COUNTER_2026-10-06.md` |
| Diner fitted tall/compact receiving pair and both original keyboard owners | `design/V2_DINER_RECEIVING_2026-10-06.md` |
| Temporary removal of seven passage shop cabinets, verified reconstruction and fitted Diner overhead | `design/V2_PASSAGE_CABINETS_PAUSED_2026-10-07.md` and `art/blender/diner_overhead.md` |
| Pawn Shop native period receiving cabinet and ordinary TOWER OF ASH input | `design/V2_PAWN_RECEIVING_2026-10-06.md` |
| News Cigars native period receiving cabinet and ordinary OUTER RIM input | `design/V2_NEWS_RECEIVING_2026-10-06.md` |
| Photo Supplies native period receiving cabinet and ordinary COUNTY LEAGUE input | `design/V2_PHOTO_RECEIVING_2026-10-06.md` |
| Photo Supplies passive print dryer clear of the complete original receiving hull | `design/V2_PHOTO_RECEIVING_CLEARANCE_2026-10-06.md` |
| Model Laundry native period receiving cabinet and ordinary NIGHT MAIL input | `design/V2_LAUNDRY_RECEIVING_2026-10-06.md` |
| Model Laundry ironing furniture clear of its intact original receiving hull | `design/V2_LAUNDRY_RECEIVING_CLEARANCE_2026-10-06.md` |
| Wrapped hand-laundry parcels, hung shirts, supported rail and ironing furniture | `art/blender/laundry_fittings.md` |
| Open laundry tubs, opposed-roll wringer, flat irons and supported drying racks | `art/blender/laundry_apparatus.md` |
| Fitted Harukiya pool frame, six open pockets and five original balls | `art/blender/bar_pool.md` |
| Source-fitted Harukiya light mounts, inward sconces and canopy stays | `art/blender/bar_fixture_mounts.md` |
| Source-fitted Harukiya ceiling-pipe split collars, bolts and bearing plates | `art/blender/bar_pipe_supports.md` |
| Local smoke-film ceiling finish with exact original faces and physical ownership | `art/blender/bar_ceiling_finish.md` |
| All 200 production room overviews, capture method and concrete follow-ups | `art/blender/v2_space_sweep.md` |
| Rear service door, receiving approach and continuous street-connected alley | `art/blender/service_alley.md` |
| Boiler instrument mounts, guards and moving-handle clearance | `art/blender/boiler_instruments.md` |
| Boiler steam header, exposed equalizer, discharge and fitted supports | `art/blender/boiler_pipework.md` |
| Retained steam inlet wall/chase sleeves, fitted plates and opened internal tee | `art/blender/boiler_inlet.md` |
| Source-bound one-pipe distribution, structural ports and open support/access construction | `art/blender/heating_distribution.md` |
| Roof slab-edge support, retained parapet bearing and open shell-readiness findings | `art/blender/roof_edge_support.md` |
| Roof bulkhead upper closures, retained ceiling faces and physical wall contacts | `art/blender/roof_bulkhead_caps.md` |
| Source-derived foundation stems, basement footings and retained occupied volumes | `art/blender/orison_foundations.md` |
| Uncovered ceiling upper closures and single-owner floor, landing and alley interfaces | `art/blender/ceiling_top_closures.md` |
| Fitted frame beneath the shifted ground stair-core wall, retained basement landings and west passage | `art/blender/ground_core_transfer.md` |
| Fitted first-upper A rear-wing beams, posts, storage seats and independent external footings | `art/blender/rear_wing_a_support.md` |
| Fitted first-upper C rear-wing beams, posts, retained basement roof seats and external footings | `art/blender/rear_wing_c_support.md` |
| First-upper hall brackets, fitted beam seats and retained watch-wall toe ledger | `art/blender/first_upper_hall_seats.md` |
| Repeated upper-core wall transfers and fitted C west toe against its retained inner wall | `art/blender/upper_wall_seats.md` |
| Remaining F03â€“F05 wall transfers, connected T frames and retained wet-stack/light-slot boundaries | `art/blender/remaining_upper_transfers.md` |
| Exposed landing soffits, retained slab bodies and single-owner ceiling interfaces | `art/blender/landing_soffits.md` |
| Exposed room-slab soffits, retained apertures and roof-wall contact observations | `art/blender/room_slab_soffits.md` |
| Fabricated bedding, preserved frames and fitted collision on fourteen beds | `art/blender/bedding.md` |
| Lobby waiting benches and fixed parcel shelving | `art/blender/public_furnishings.md` |
| Basement stair foundation and Blender coal pile | `art/blender/basement_fabrication.md` |
| Blender common-room reading table, chairs, bookcases and walking clearance | `art/blender/reading_furniture.md` |
| Blender boiler breeching, open gores, collar seating and bend collision | `art/blender/breeching.md` |
| Blender boiler casing, recessed firebox/ash pit, grate and matching fixed collision | `art/blender/boiler_body.md` |
| Boiler firing/ash door outward swing and matching moving plate collision | `art/blender/boiler_door_swing.md` |
| Blender room millwork, wainscot, door casings, service frames and brass lift reveals | `art/blender/millwork_profile.md` |
| Blender lift call plates, seated wall mounting and mechanical button caps | `art/blender/lift_call_plate.md` |
| Blender lift handrails, wall-mounted supports and fasteners | `art/blender/lift_handrails.md` |
| Fitted Blender cab panels, control clearances and rear enamel field | `art/blender/lift_joinery.md` |
| Fitted Blender lift ceiling lamp, opal bowl and retaining hardware | `art/blender/lift_ceiling_lamp.md` |
| Blender passive bathroom grilles, folded louvers and plenum seating | `art/blender/vent_register.md` |
| Blender shared roof ventilators, motor housings and live rotor/shutter pivots | `art/blender/roof_ventilator.md` |
| Blender bonded chimney masonry, mortar joints and open stone coping | `art/blender/chimney_crown.md` |
| Blender roof tank, timber staves, binding hardware and retained maintenance | `art/blender/house_tank.md` |
| Blender roof coping, mitered corners, weather slopes and drip grooves | `art/blender/roof_coping.md` |
| Architecture batch handoff, validation locations and remaining work | `design/V2_ARCHITECTURE_HANDOFF_2026-09-27.md` |
| Blender V2 mortise knobs, fitted backplates and clear lock stiles | `art/blender/door_knob_set.md` |
| Blender butt hinges, fixed/moving halves and opposite-swing axis alignment | `art/blender/door_butt_hinge.md` |
| Complete Blender V2 window frames, sash fields and projecting sills | `art/blender/window_joinery.md` |
| Blender lift mirror surround and shared live reflection | `art/blender/lift_mirror.md` |
| Blender lift floor dial, ceiling mounts and height-driven needle | `art/blender/lift_indicator.md` |
| Blender cab control board, collars and working button presentation | `art/blender/lift_cab_controls.md` |
| Blender sliding lift leaves, clear vision apertures and retained shaft barriers | `art/blender/lift_panels.md` |
| Articulated Blender car gate, fixed-thickness links and landing-door separation | `art/blender/lift_gate.md` |
| Blender enamel floor signs, mounting spacers and readable runtime lettering | `art/blender/wayfinding_plate.md` |
| Blender stair rails, tread stringers and landing support geometry | `art/blender/stair_ironwork.md` |
| Honed stair marble, independent physical microrelief and real semantic shader binding | `art/blender/stair_honed.md` |
| Editable Blender light switches, moving toggles and preserved V2 circuit ownership | `art/blender/light_switch.md` |
| How to test all sixteen critters and live encroachment in Mina's actual V2 apartment | `game/docs/mina_debug_infestation.md` |
| Which checkout to use and where retired worktrees were preserved | `design/WORKTREE_CONSOLIDATION_2026-09-21.md` |
| Household inspection, preventative care, tips and low-pressure rent | `game/docs/caretaking_and_economy.md` and `design/ORISON_V2_CARE_ECONOMY_PROGRESS_2026-09-26.md` |
| Floor plates in both V2 stair cores and lamp-readable lettering | `design/ORISON_V2_WAYFINDING_PROGRESS_2026-09-26.md` |
| Connected boiler flue, roof chimney and saved water-column service | `design/ORISON_V2_BOILER_FLUE_PROGRESS_2026-09-26.md` |
| Wider sixteen-metre service light and physical lamp aim toward nearby controls | `design/ORISON_V2_LAMP_COVERAGE_PROGRESS_2026-09-26.md` |
| Grounded V2 boiler, clear firing aisle, physical door/damper controls and water-column route | `design/ORISON_V2_BOILER_ACCESS_PROGRESS_2026-09-26.md` |
| Continuous V2 opening-shift regression, natural dream onset and conversation field-copy readability | `design/ORISON_V2_CONTINUOUS_SHIFT_PROGRESS_2026-09-26.md` |
| Completed V2 fuse and roof-tank repairs across saves and building reconstruction | `design/ORISON_V2_SERVICE_SAVE_PROGRESS_2026-09-26.md` |
| V2 lift ropes, deflectors, counterweight, guide channels and guarded roof penetrations | `design/ORISON_V2_LIFT_SUSPENSION_PROGRESS_2026-09-26.md` |
| V2 four physical ventilation stacks, bathroom branches and geographic motor ownership | `design/ORISON_V2_SHARED_DUCTWORK_PROGRESS_2026-09-26.md` |
| V2 street coal cover, gravity delivery chute and raised basement aperture | `design/ORISON_V2_COAL_DELIVERY_PROGRESS_2026-09-26.md` |
| Guarded roof lift machinery driven by the existing passenger car | `design/ORISON_V2_LIFT_DRIVE_PROGRESS_2026-09-26.md` |
| Basement electrical, workshop, coal, storage and lower service-stair construction | `design/ORISON_V2_BASEMENT_PROGRESS_2026-09-26.md` |
| Occupied-home radiators, brighter service light and zoo optical-source ownership | `design/ORISON_V2_HEATING_AND_PRIMARY_LIGHT_PROGRESS_2026-09-25.md` |
| How to launch the V2 default, use V1 rollback, and walk into or inspect the Dream zoo | `game/docs/v2_launch.md` |
| V2 remaining homes, passenger lift, shared roof ventilation and scoped route checks | `design/ORISON_V2_HOMES_AND_LIFT_PROGRESS_2026-09-25.md` |
| Spatial-only evidence for the six added homes and staff restroom | `design/ORISON_V2_COMPLETION_INTERIORS_CHECKPOINT_2026-09-25.md` |
| The landed V2 roof-access shell, Mina's door passages, and remaining architecture/lighting work | `design/ORISON_V2_ROOF_AND_RESIDENT_PROGRESS_2026-09-25.md` |
| The V2 roof water tank, production maintenance approach and scoped validation | `design/ORISON_V2_ROOF_PLANT_PROGRESS_2026-09-25.md` |
| What is true about this world | `design/ORISON_BIBLE.md` |
| How to work in this repository: git in a shared tree, the Godot lane, what counts as proof | `AGENTS.md` (Claude reads it through `CLAUDE.md`) |
| Whether a change made anything worse, and whether a branch is mergeable | `tools/PIPELINE_TOOLS.md`: gate board, run receipts, candidate verifier |
| Where the v2 rebuild stands and what the ledger will accept as evidence | `python tools/audit_orison_v2_completeness.py`, `design/ORISON_V2_COMPLETENESS_LEDGER_GUIDE.md`, and the current snapshot in `design/orison_v2_completeness_reports/ORISON_V2_COMPLETENESS_LEDGER.md` |
| Which standing ruling a brief or review cites as RUL-nnn | `design/RULINGS.json` *(an index with sources; the Bible and the cited source win)* |
| How V2 household authoring metadata becomes shipped data and test proofs | `art/data/orison_v2/AUTHORING_PROJECTIONS.md`, then `tools/build_v2_authoring_projection.py` |
| How each prop compares with the real object, and which to rebuild first | `design/PROP_MODELING_TEXTURING_BRIEF_2026-09-18.md`, then `tools/prop_reference/README.md` |
| What the game loop is and which milestone comes next | `design/CLAUDE_LIVING_ORISON_EXECUTION_PLAN.md`, then `design/next_session_plan.md` |
| The final playable map: three zones, the Passage, measured perf baseline | `design/FINAL_MAP_REDESIGN_BRIEF.md` |
| Why an object looks forty years early | Bible Â§VIII.2, the Rule of Signal |
| What is open right now, and who has it | `TASKS.md` |
| Whether a system is actually used | `design/AUDIT_UNUSED_SYSTEMS_REPORT.md` |
| How to build the layout â†’ Blender â†’ Godot chain | `HANDOFF.md` |
| How to run a test, and which ones exist | `HANDOFF.md`, then `game/tests/` |
| What phase the art is in | `art/docs/photoreal_target.md` |
| Who lives in a flat and what their wound is | Bible Â§IV, then `game/docs/resident_character_cast.md` |
| How a prop should be built | `design/PROP_ART_BRIEF.md`, `design/PROP_REFERENCE_NOTES.md` |
| What a prop *does* | `design/PROP_ACTIVITIES.md` |
| Which foreground props and set heroes receive E, inspection, refusal or stay ambient | `design/PROP_SET_INTERACTION_MATRIX.md` |
| Where service-wire object facts and card sources live | `design/PROP_TRIVIA_RESEARCH.md`, then `game/data/prop_service_wire.json` |
| How the complete maintenance/case/dream-request loop is wired | `game/docs/core_loop.md` |
| How the bar works | `docs/harukiya_reference_notes.md` |
| How the karaoke/song system works | `docs/songbook_brief.md` |
| The machines in the bar | `game/docs/arcade_cabinets.md`, ruled in Bible Â§VIII.5.g |
| The proposed basement studio | `design/ORISON_STUDIO_BRIEF.md` *(proposal)* |
| The narcolepsy dream / the maze | `design/ORISON_MAZE_BRIEF.md` *(ruled production design)*, then `game/docs/dream_boundary.md` for the landed scene/save seam and `game/docs/dream_onset.md` for the protected onset owner |
| The ruled dream flora/fauna ecosystem and landed FA1â€“FA2 slices | `design/DREAM_FAUNA_BRIEF.md`, then `art/renders/dream_fauna_f1/README.md` and `art/renders/dream_fauna_fa2/README.md` |
| How the sixteen warehouse critters will be rebuilt from the biology dossier with continuous Blender anatomy and preserved behaviors | `design/astra/DREAM_CRITTER_BLENDER_REBUILD_2026-09-19_BRIEF.md`, with `design/astra/DREAM_CRITTER_REFERENCE_MAP_2026-09-19.json` *(INERT analysis, implementation proposal and reference map)* |
| Editable Blender sources, native warehouse gallery and completed verification for all sixteen critters | `design/astra/DREAM_CRITTER_BLENDER_REBUILD_2026-09-19.md` *(INERT implementation report)* |
| Recovered hero source, live organelle warehouse station and reserved zoo bays | `design/astra/DREAM_ZOO_WAREHOUSE_RESCUE_2026-09-19.md` *(INERT debug implementation and source-recovery report)* |
| The six case-specific dream surface incarnations and AI-plate boundary | `design/SIX_INCARNATIONS.md` *(owner-approved; shared data seam landed)* |
| Image references for Dream anatomy: real specimens, period plates, motion and artistic interpretations, with licences | `design/DREAM_BIOLOGY_REFERENCE_DOSSIER_2026-09-19.md` *(reference, not canon)* |
| Which real specimen each landed Dream organ is grown from, at what scale and era, and what the being misreads about it | `design/DREAM_TEMPORAL_SPECIMEN_LEDGER.md` *(audit)*, over the doctrine it classifies: `design/DREAM_TEMPORAL_BIOLOGY.md`, `design/DREAM_ORGANELLE_COMMUNICATION.md`, `design/DREAM_ECOLOGY_ARCHITECTURE.md` |
| Ruled waking-world vermin, birds and invasive flora | `design/ORISON_COMMENSALS_BRIEF.md` *(C1 landed; later breadth gated)* |
| The no-screen radio and attached work light in the player's hand | `design/VANTRY_SERVICE_RADIOPHONE_BRIEF.md`, `game/docs/service_set.md` *(ruled and landed)* |
| The HUD, telegram paper, type hierarchy and institutional world text | Bible Â§VIII.5.k, then `game/docs/telegram_style.md` *(ruled and landed)* |
| How sound moves through the building | `game/data/acoustic_graph.json`, `game/docs/sanity_system.md` |
| Why a texture tiles badly | `art/tools/ingest_material_sources.py`, and the compiler's `docs/provider-api.md` |
| What clothes people wear | `design/ORISON_WARDROBE_BIBLE.md` |
| What appliances exist | `design/ORISON_APPLIANCE_BIBLE.md` |
| How a household decorates | `design/resident_decor_profiles.json` *(brief, not loaded)* |

## The two repositories

| | |
|---|---|
| `C:\PleaseRemainOnTheLine` | this one. The game, the art pipeline, the design canon. Git-backed. |
| `C:\FPSengine01` | the **Semantic World Compiler**, which builds the machines in the bar. |

The compiler is a separate project that produces a build output consumed here
(`game/assets/arcade/`). It shares a *format* with this repo, not code. Its own
map is its `README.md`, and its cross-project contract is
`docs/orison-arcade.md`.

> **`C:\FPSengine01` is not a git repository.** Everything in it is unversioned
> files on disk. This is tracked as **H2** in `TASKS.md` and is the largest
> single risk on that list.

## Two names for the same thing

`arcade` is the **subsystem**; the **signal parlour** is the fiction. The code
says `arcade_*` throughout because that is the lineage it grew from; the world
says receivers and programme cards because the Bible rules it so (Â§VIII.5.g).
They agree. See the note in `game/docs/arcade_cabinets.md`.

## Three "status" documents, three jobs

They have collided before. They do not overlap:

`design/CLAUDE_LIVING_ORISON_EXECUTION_PLAN.md` is not a fourth status ledger.
It defines product direction, milestone order and acceptance gates; it changes
only when the product plan changes.

- **`art/docs/photoreal_target.md`** â€” the eight-phase art roadmap and its
  per-phase assessment. Long-lived.
- **`TASKS.md`** â€” the live queue. One line per open task, anyone may add,
  deleted when done.
- **`HANDOFF.md`** â€” how to build and verify, and nothing else.

Do not duplicate status between them. Two copies of a status always disagree,
and the reader has no way to tell which one is lying.

## Adding a document

- **A rule** goes in the Bible as a dated ruling, not in a new file. A
  standing process ruling may also be indexed in `design/RULINGS.json` with
  its source, so reviews can cite it by id; the index never replaces the
  Bible.
- **A design document** states its class in an `Evidence class:` header in
  its first 30 lines; run `python tools/lint_design_doc.py <path>` before
  committing it (`AGENTS.md`).
- **A proposal** goes in `design/` ending `_BRIEF.md`, and says at the top that
  it is not canon.
- **A task** goes in `TASKS.md` as one line. If it needs a paragraph, it needs a
  brief.
- **A subsystem explanation** goes in `game/docs/` or `art/docs/` next to the
  thing it explains.
- **Then add it to the table above**, or nobody will find it.

## Known gaps in the documentation itself

- The eleven shops, the archived phone OS and the case network have reference
  docs of uneven depth. The carried-device migration is recorded in
  `design/VANTRY_SERVICE_RADIOPHONE_BRIEF.md` and `game/docs/service_set.md`;
  the old phone documents are historical inputs, not production authority.
- `docs/harukiya_reference_notes.md` owes an asset manifest and an interaction
  manifest, deliberately unwritten so far.
- Bible Â§VI holds eight disputed texts awaiting a ruling. They are disputes, not
  oversights.
- An audit is not a queue. `AUDIT_UNUSED_SYSTEMS_REPORT.md` carries the evidence
  and its findings live in `TASKS.md` Â§U; if the two ever disagree, the audit is
  the older document and the queue is what is being worked.
