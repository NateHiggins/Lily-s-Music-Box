# Gate board - 71f8889cd32a

- commit `71f8889cd32ae542d20c3dac8f68939e7f65c90c`
- tree `30f4606aeb13aa15a6a6de35cc1c155c038a9890`
- created 2026-10-22T21:10:48Z
- dirty paths: 2744

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| physical_import_sources | PASS | 0 | 0.42 | no defects counted |
| spatial | PASS | 0 | 5.38 | drift.new_reported 7 |
| reader | PASS | 0 | 3.42 | unread 1108; vs frozen baseline: new 0, resolved 200 |
| test:test_nook_readable_books | PASS | 0 | 0.16 | ran 4, failed 0 |
