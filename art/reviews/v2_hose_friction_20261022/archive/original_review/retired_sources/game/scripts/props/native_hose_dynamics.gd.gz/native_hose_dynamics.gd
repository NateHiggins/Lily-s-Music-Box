extends RefCounted
## Candidate inextensible release dynamics. Actual annular shell contact planes
## constrain each ring; the final native swept-shell query prevents tunnelling.
## No self-contact, held-end constraint, maintenance facts or installed ownership.
const STEP_S:=1./120.
const MAX_SUBDIVISION_DEPTH:=4
const MAX_STEP_ATTEMPTS:=31
var rig: RefCounted
var contact: RefCounted
var velocities:=PackedVector3Array()
var error:=""
var response_iterations:=0
var contacts_resolved:=0
var projection_error:=""
var response_history: Array[Dictionary]=[]
var last_contacts: Array=[]
var last_proposed:=PackedVector3Array()
var last_energy_delta:=0.
var masses:=PackedFloat64Array()
var kernel:=preload("res://scripts/props/hose_mass_constraints.gd").new()
var step_attempts:=0
var accepted_substeps:=0
var advanced_time_s:=0.
var last_attempt_delta_s:=0.
var _accepted_contacts:=0
var profile_usec: Dictionary={}
var projection_calls:=0
var last_contact_energy_removed:=0.
var use_follow_projection:=false
var follow_successes:=0
var follow_fallbacks:=0
var follow_iterations:=0
var last_follow_error:=""
var last_internal_energy_removed:=0.
var _last_projection_followed:=false
var pin_outlet_direction:=false
var native_skin_bends:=false
var refresh_section_support:=false
var contact_friction:=false
var last_friction_energy_removed:=0.
var record_projection_cases:=false
var follow_cases: Array[Dictionary]=[]
var joint_contact_first:=false
var original_contact_seed:=false
var directional_skin_bends:=false
var _minimum_radii:=PackedFloat64Array()
var directional_bend_updates:=0
var _fixed_rings:=PackedInt32Array()
func _profile(category: String,started: int) -> void:
	profile_usec[category]=int(profile_usec.get(category,0))+Time.get_ticks_usec()-started
func configure(owner_rig: RefCounted,owner_contact: RefCounted) -> bool:
	if rig!=null or owner_rig==null or not owner_rig.configured or owner_contact==null or not owner_contact.ready:return false
	if owner_contact.rig!=owner_rig:return false
	var radii:=PackedFloat64Array()
	if native_skin_bends:
		radii=preload("res://scripts/props/native_hose_bend_limits.gd").for_contact(owner_contact)
		if radii.size()!=owner_rig.rest.size():return false
	if directional_skin_bends and not native_skin_bends:return false
	_minimum_radii=radii.duplicate()
	if not kernel.configure(owner_rig.strand.lengths,owner_rig.rest,radii):return false
	if pin_outlet_direction:
		_fixed_rings=PackedInt32Array([owner_rig.rest.size()-3,owner_rig.rest.size()-2])
		if not kernel.pin_rings(_fixed_rings):return false
	rig=owner_rig;contact=owner_contact
	velocities.resize(rig.strand.points.size());velocities.fill(Vector3.ZERO)
	masses.resize(velocities.size())
	for i in masses.size():
		masses[i]=(rig.strand.lengths[i-1]*.5 if i>0 else 0.)+(rig.strand.lengths[i]*.5 if i<rig.strand.lengths.size() else 0.)
	return true
func reset_velocity() -> void:velocities.fill(Vector3.ZERO)
func _merge(planes: Dictionary,ring: int,normal: Vector3,offset: float) -> void:
	if not planes.has(ring):planes[ring]=[]
	for old: Dictionary in planes[ring]:
		# Similar normals are not interchangeable: their offsets are measured
		# against the model origin. Merging them without changing that datum
		# can leave a persistent penetration even on an almost-flat contact.
		if (old.normal-normal).length_squared()<1e-14:
			old.offset=maxf(old.offset,offset);return
	planes[ring].append({"normal":normal,"offset":offset})
func _project(target: PackedVector3Array,planes: Dictionary) -> PackedVector3Array:
	var started: int=Time.get_ticks_usec();projection_calls+=1
	var result:=PackedVector3Array()
	_last_projection_followed=false
	var initial_joint: bool=use_follow_projection and joint_contact_first and not planes.is_empty()
	if initial_joint:
		var initial_started: int=Time.get_ticks_usec()
		result=kernel.project(target,rig.strand.anchor,planes)
		_profile("contact_joint_initial",initial_started)
	if use_follow_projection and result.is_empty():
		var pins: Dictionary={}
		for ring: int in _fixed_rings:pins[ring]=rig.strand.points[ring]
		var following_started: int=Time.get_ticks_usec()
		result=kernel.follow(target,rig.strand.anchor,planes,pins)
		_profile("follow_projection",following_started);follow_iterations+=kernel.iterations
		if result.is_empty():follow_fallbacks+=1;last_follow_error=kernel.error
		else:follow_successes+=1;_last_projection_followed=true
		if result.is_empty() and record_projection_cases and follow_cases.size()<2:
			follow_cases.append({"target":target.duplicate(),"warm":kernel.coupled.last_iterate.duplicate(),"planes":planes.duplicate(true),"pins":pins.duplicate(),"error":kernel.error,"lengths":kernel.lengths.duplicate(),"spans":kernel.bend_spans.duplicate(),"inverse":kernel.inverse.duplicate(),"bend_error_m":kernel.bend_error_m})
	if not use_follow_projection:result=kernel.project(target,rig.strand.anchor,planes)
	elif result.is_empty():
		var fallback_started: int=Time.get_ticks_usec()
		var seed: PackedVector3Array=kernel.coupled.last_iterate
		# The failed fast solve still supplies a finite, fixed-neck seed.
		# The original joint solve validates every material/support bound.
		result=kernel.project(target if original_contact_seed and not initial_joint else seed if seed.size()==target.size() else target,rig.strand.anchor,planes)
		_profile("fallback_projection",fallback_started)
	_profile("position_projection",started)
	profile_usec["joint_projection"]=int(profile_usec.get("joint_projection",0))+kernel.joint_usec
	projection_error=kernel.error
	return result
func _energy_change(before: PackedVector3Array,speed: PackedVector3Array,gravity: Vector3) -> float:
	var result:=0.
	for i in velocities.size():
		var old_world: Vector3=rig.model.global_basis*speed[i]
		var next_world: Vector3=rig.model.global_basis*velocities[i]
		result+=masses[i]*((next_world.length_squared()-old_world.length_squared())*.5-gravity.dot(rig.model.global_basis*(rig.strand.points[i]-before[i])))
	return result
func _rollback(points: PackedVector3Array,speed: PackedVector3Array,bends: PackedFloat64Array=PackedFloat64Array()) -> void:
	var started: int=Time.get_ticks_usec()
	rig.strand.points=points.duplicate();velocities=speed.duplicate()
	if not rig.apply_points(points):error="native dynamics rollback failed"
	if not bends.is_empty() and not kernel.restore_bend_spans(bends):error="native bend-state rollback failed"
	_profile("rollback_skin",started)
func _integrate(delta: float,gravity: Vector3,depth: int) -> bool:
	if step_attempts>=MAX_STEP_ATTEMPTS:error="bounded release work ceiling";return false
	step_attempts+=1;last_attempt_delta_s=delta
	var before: PackedVector3Array=rig.strand.points.duplicate();var speed:=velocities.duplicate()
	var before_bends: PackedFloat64Array=kernel.bend_spans.duplicate() if directional_skin_bends else PackedFloat64Array()
	var previous_count: int=accepted_substeps;var previous_time: float=advanced_time_s;var previous_contacts: int=_accepted_contacts
	var previous_dissipation: float=last_contact_energy_removed
	var previous_internal_dissipation: float=last_internal_energy_removed
	var previous_friction: float=last_friction_energy_removed
	if _advance(delta,gravity):
		accepted_substeps+=1;advanced_time_s+=delta;_accepted_contacts+=contacts_resolved
		return true
	var failure: String=error
	_rollback(before,speed,before_bends)
	last_contact_energy_removed=previous_dissipation
	last_internal_energy_removed=previous_internal_dissipation
	last_friction_energy_removed=previous_friction
	if depth<MAX_SUBDIVISION_DEPTH:
		if _integrate(delta*.5,gravity,depth+1) and _integrate(delta*.5,gravity,depth+1):
			var change: float=_energy_change(before,speed,gravity)
			if change<=rig.strand.total_length*gravity.length()*.00002:return true
			failure="subdivided release injects aggregate energy: "+str(change)
		else:failure=error
	_rollback(before,speed,before_bends)
	accepted_substeps=previous_count;advanced_time_s=previous_time;_accepted_contacts=previous_contacts
	last_contact_energy_removed=previous_dissipation
	last_internal_energy_removed=previous_internal_dissipation
	last_friction_energy_removed=previous_friction
	error=failure
	return false
func step(delta: float,world_gravity: Vector3=Vector3(0,-9.81,0)) -> bool:
	step_attempts=0;accepted_substeps=0;advanced_time_s=0.;_accepted_contacts=0
	profile_usec={};projection_calls=0
	last_contact_energy_removed=0.
	last_internal_energy_removed=0.
	last_friction_energy_removed=0.
	follow_cases.clear()
	directional_bend_updates=0
	follow_successes=0;follow_fallbacks=0;follow_iterations=0;last_follow_error=""
	if rig==null or not is_finite(delta) or delta<=0. or delta>STEP_S+.00000001 or not world_gravity.is_finite():
		error="invalid bounded dynamics step";return false
	var before: PackedVector3Array=rig.strand.points.duplicate();var speed:=velocities.duplicate()
	var before_bends: PackedFloat64Array=kernel.bend_spans.duplicate() if directional_skin_bends else PackedFloat64Array()
	if not _integrate(delta,world_gravity,0):return false
	last_energy_delta=_energy_change(before,speed,world_gravity)
	if absf(advanced_time_s-delta)>.0000000001 or last_energy_delta>rig.strand.total_length*world_gravity.length()*.00002:
		_rollback(before,speed,before_bends);accepted_substeps=0;advanced_time_s=0.;error="release aggregate time/energy contract failed";return false
	contacts_resolved=_accepted_contacts;error=""
	return true
func _advance(delta: float,world_gravity: Vector3) -> bool:
	error="";response_iterations=0;contacts_resolved=0;response_history.clear();last_contacts.clear();last_energy_delta=0.
	if rig==null or not is_finite(delta) or delta<=0. or delta>STEP_S+.00000001 or not world_gravity.is_finite():
		error="invalid bounded dynamics step";return false
	var before: PackedVector3Array=rig.strand.points.duplicate()
	var predicted:=before.duplicate()
	var gravity: Vector3=rig.model.global_basis.inverse()*world_gravity
	var damping: float=exp(-3.*delta)
	for i in range(predicted.size()-1):
		if kernel.inverse[i]>0.:predicted[i]+=velocities[i]*delta*damping+gravity*delta*delta
	var planes: Dictionary={}
	var support_records: Array=[]
	var constraint_pose:=predicted
	for iteration in 32:
		response_iterations=iteration+1
		if refresh_section_support:
			var reframe_started: int=Time.get_ticks_usec()
			var reframed: Dictionary=contact.reframe_support(support_records,constraint_pose)
			_profile("support_reframe",reframe_started)
			if not reframed.valid:error="invalid native section support";return false
			planes=reframed.planes
		var proposed:=_project(predicted,planes)
		if proposed.is_empty() or not rig.strand._valid_positions(proposed):
			error="infeasible length/support constraints: "+projection_error
			if not proposed.is_empty():
				var total:=0.;var widest:=0.
				for i in rig.strand.lengths.size():
					var length: float=proposed[i].distance_to(proposed[i+1]);total+=length;widest=maxf(widest,absf(length-rig.strand.lengths[i]))
				error+=" length errors "+str([widest,total-rig.strand.total_length])
			return false
		if directional_skin_bends:
			var bending_started: int=Time.get_ticks_usec()
			var radii: PackedFloat64Array=preload("res://scripts/props/native_hose_bend_limits.gd").for_pose(contact,proposed,_minimum_radii)
			if radii.is_empty() or not kernel.update_bend_radii(radii):error="invalid directional native bend constraints";return false
			_profile("directional_bends",bending_started)
			if kernel._bend_error(proposed)>kernel.bend_error_m:
				directional_bend_updates+=1
				constraint_pose=proposed;predicted=proposed;continue
		var contact_started: int=Time.get_ticks_usec()
		var result: Dictionary=contact.motion_constraints(before,proposed,4096)
		_profile("world_contact",contact_started)
		last_proposed=proposed;last_contacts=result.planes.duplicate(true)
		if not result.valid or result.truncated:
			error="invalid or truncated native contact response: "+str([result.valid,result.truncated,result.error]);return false
		if result.planes.is_empty():
			var sweep_started: int=Time.get_ticks_usec()
			# A successful full motion query already covered every moving and
			# still native cell in this same synchronous world state. Reuse its
			# explicit proof in the opt-in model; never cache collision answers
			# between steps. Legacy mass-model checks retain their original path.
			var blocked: bool=false if use_follow_projection and bool(result.get("sweep_clear",false)) else contact.veto(before,proposed)
			_profile("final_sweep",sweep_started)
			if blocked:error="native swept shell blocked release step";return false
			var next_velocity:=PackedVector3Array();next_velocity.resize(velocities.size())
			for i in velocities.size():
				next_velocity[i]=(proposed[i]-before[i])/delta
			var velocity_started: int=Time.get_ticks_usec()
			next_velocity=kernel.project_velocity(proposed,next_velocity,planes)
			_profile("velocity_projection",velocity_started)
			if next_velocity.is_empty():error="mass velocity projection: "+kernel.error;return false
			if contact_friction and not support_records.is_empty():
				var friction_started: int=Time.get_ticks_usec()
				var incoming:=PackedVector3Array();incoming.resize(velocities.size())
				for i in incoming.size():incoming[i]=velocities[i]*damping+gravity*delta if kernel.inverse[i]>0. else Vector3.ZERO
				var friction: Dictionary=preload("res://scripts/props/hose_contact_friction.gd").apply(rig,contact,support_records,proposed,incoming,next_velocity,kernel.inverse)
				if not friction.valid:error="invalid static contact friction";return false
				var reduced: PackedVector3Array=kernel.project_velocity(proposed,friction.velocities,planes)
				if reduced.is_empty():error="friction material velocity projection: "+kernel.error;return false
				var removed:=0.
				for i in velocities.size():removed+=masses[i]*((rig.model.global_basis*next_velocity[i]).length_squared()-(rig.model.global_basis*reduced[i]).length_squared())*.5
				if removed<0.:
					# Roundoff in the homogeneous material projection must not
					# manufacture kinetic energy. Reuse the existing dissipative
					# velocity-only cap; positions and every physical bound stay.
					var capped: Dictionary=preload("res://scripts/props/hose_contact_energy.gd").dissipate(proposed,next_velocity,proposed,reduced,masses,rig.model.global_basis,Vector3.ZERO)
					if not capped.valid:error="invalid friction energy cap";return false
					reduced=capped.velocities;removed=0.
					for i in velocities.size():removed+=masses[i]*((rig.model.global_basis*next_velocity[i]).length_squared()-(rig.model.global_basis*reduced[i]).length_squared())*.5
					if removed<-.000000001:error="friction cap injects kinetic energy";return false
				last_friction_energy_removed+=maxf(0.,removed);next_velocity=reduced
				_profile("contact_friction",friction_started)
			for i in velocities.size():
				var old_world: Vector3=rig.model.global_basis*velocities[i]
				var next_world: Vector3=rig.model.global_basis*next_velocity[i]
				last_energy_delta+=masses[i]*((next_world.length_squared()-old_world.length_squared())*.5-world_gravity.dot(rig.model.global_basis*(proposed[i]-before[i])))
			# Static-world release cannot manufacture energy. Reject the whole
			# proposal while the candidate's mass/bending solve remains unfinished.
			# The allowance is only the existing20micrometre positional precision;
			# it is translation-independent, unlike a percentage of altitude.
			if last_energy_delta>rig.strand.total_length*world_gravity.length()*.00002:
				var external_contact: bool=not planes.is_empty() and contacts_resolved>0
				# The opt-in follower is a dissipative geometric constraint
				# model. Its internal length/bend correction can also require
				# velocity loss without a world impact. The mass model's free
				# release policy is unchanged. Neither model can buy an elevated
				# pose with unavailable energy; the same final budget still gates.
				var internal_projection: bool=use_follow_projection and _last_projection_followed
				if not external_contact and not internal_projection:
					error="release proposal injects mechanical energy: "+str(last_energy_delta);return false
				# Positional contact projection can create an excessive derived
				# velocity. An inelastic impact dissipates it; the same strict
				# positional, swept-contact and energy bounds still gate acceptance.
				# Uniform scaling preserves homogeneous tangent/contact velocity
				# constraints and zero velocity at the pinned outlet.
				var impact: Dictionary=preload("res://scripts/props/hose_contact_energy.gd").dissipate(before,velocities,proposed,next_velocity,masses,rig.model.global_basis,world_gravity)
				if not impact.valid:error="contact pose exceeds available mechanical energy";return false
				next_velocity=impact.velocities
				if external_contact:last_contact_energy_removed+=impact.removed
				else:last_internal_energy_removed+=impact.removed
				last_energy_delta=0.
				for i in velocities.size():last_energy_delta+=masses[i]*(((rig.model.global_basis*next_velocity[i]).length_squared()-(rig.model.global_basis*velocities[i]).length_squared())*.5-world_gravity.dot(rig.model.global_basis*(proposed[i]-before[i])))
				if last_energy_delta>rig.strand.total_length*world_gravity.length()*.00002:error="dissipated contact exceeds unchanged energy bound";return false
			var skin_started: int=Time.get_ticks_usec()
			var applied: bool=rig.apply_points(proposed)
			_profile("accepted_skin",skin_started)
			if not applied:error="native skin rejected release pose";return false
			rig.strand.points=proposed
			velocities=next_velocity
			velocities[-1]=Vector3.ZERO
			return true
		contacts_resolved+=result.planes.size()
		var deepest: float=-INF
		for plane: Dictionary in result.planes:deepest=maxf(deepest,plane.offset-plane.normal.dot(proposed[plane.ring]))
		response_history.append({"iteration":iteration,"planes":result.planes.size(),"required_correction":deepest})
		for plane: Dictionary in result.planes:
			var ring: int=plane.ring
			if ring==before.size()-1 or ring in _fixed_rings:error="fixed outlet intersects world";return false
			if refresh_section_support:
				if not contact.remember_support(support_records,plane):error="invalid native surface support";return false
			else:_merge(planes,ring,plane.normal,plane.offset)
		constraint_pose=proposed
		if refresh_section_support:predicted=proposed
	error="native response did not converge: "+str(response_history.slice(-4));return false
