extends RefCounted
## Lower bend-radius bound from the actual imported outer section. A flattened
## ribbon may bend about its thin axis; a round fitting neck may not collapse
## to that same radius. Direction-dependent/self-contact protection is separate.
static func for_contact(contact: RefCounted) -> PackedFloat64Array:
 var result:=PackedFloat64Array()
 if contact==null or not contact.ready or contact.sections.size()<3:return result
 for section: Dictionary in contact.sections:
  var radius:=INF
  if section.outer.size()!=32:return PackedFloat64Array()
  for vertex: Vector3 in section.outer:
   if not vertex.is_finite():return PackedFloat64Array()
   radius=minf(radius,vertex.length())
  if not is_finite(radius) or radius<=0.:return PackedFloat64Array()
  result.append(maxf(.003,radius*1.02+.0001))
 return result
static func for_pose(contact: RefCounted,points: PackedVector3Array,minimum: PackedFloat64Array) -> PackedFloat64Array:
 if contact==null or minimum.size()!=points.size() or points.size()!=contact.sections.size():return PackedFloat64Array()
 var frames: Array[Transform3D]=contact.rig.model_frames(points)
 if frames.size()!=points.size():return PackedFloat64Array()
 var result:=minimum.duplicate()
 for i in range(1,points.size()-1):
  var before: Vector3=points[i]-points[i-1];var after: Vector3=points[i+1]-points[i]
  if before.length_squared()<1e-14 or after.length_squared()<1e-14:return PackedFloat64Array()
  var curvature: Vector3=after.normalized()-before.normalized()
  if curvature.length_squared()<1e-12:continue
  curvature=curvature.normalized()
  for vertex: Vector3 in contact.sections[i].outer:
   result[i]=maxf(result[i],absf(curvature.dot(frames[i].basis*vertex))*1.02+.0001)
 return result
