extends "res://tests/v2_hose_follower_programme.gd"
## Longer uninstalled fixture diagnostic. Solver work is not played frame time.
func run(holder: PlayerController) -> bool:
	if not await super.run(holder):return false
	await _settle()
	return failures.is_empty()
func _settle() -> void:
	var saved: Dictionary=rig.snapshot();var initial: PackedVector3Array=rig.strand.points.duplicate()
	var dynamics:=preload("res://scripts/props/native_hose_dynamics.gd").new()
	dynamics.use_follow_projection=true;dynamics.pin_outlet_direction=true;dynamics.native_skin_bends=true
	dynamics.refresh_section_support=true
	dynamics.contact_friction=OS.get_environment("ORISON_HOSE_CONTACT_FRICTION")=="1"
	dynamics.record_projection_cases=OS.get_environment("ORISON_HOSE_RECORD_PROJECTIONS")=="1"
	dynamics.joint_contact_first=OS.get_environment("ORISON_HOSE_JOINT_CONTACT_FIRST")=="1"
	dynamics.original_contact_seed=dynamics.joint_contact_first
	dynamics.directional_skin_bends=OS.get_environment("ORISON_HOSE_DIRECTIONAL_BENDS")=="1"
	if not check_configuration(dynamics):return
	var frames: Array[Transform3D]=rig.model_frames(initial);var lowest:=INF
	for i in initial.size():
		for point: Vector3 in contact.sections[i].outer:lowest=minf(lowest,(frames[i]*point).y)
	var floor:=StaticBody3D.new();var leaf:=CollisionShape3D.new();var box:=BoxShape3D.new()
	box.size=Vector3(4,.04,4);leaf.shape=box;floor.add_child(leaf);add_child(floor)
	floor.global_transform=rig.model.global_transform*Transform3D(Basis.IDENTITY,Vector3(0,lowest-.025,.1))
	await get_tree().physics_frame;await get_tree().physics_frame
	check(not contact.intersects_pose(initial),"long release floor begins outside the actual skin")
	var physics: bool=player.is_physics_processing();player.set_physics_process(false)
	var records: Array=[];var success:=true
	var saved_cases:=false
	for step in 120:
		var before: PackedVector3Array=rig.strand.points.duplicate();var speed: PackedVector3Array=dynamics.velocities.duplicate()
		var start: int=Time.get_ticks_usec();var accepted: bool=dynamics.step(dynamics.STEP_S)
		var elapsed: float=(Time.get_ticks_usec()-start)/1000.
		records.append({"step":step,"solver_ms":elapsed,"accepted":accepted,"error":dynamics.error,"profile_usec":dynamics.profile_usec.duplicate(),"follow_successes":dynamics.follow_successes,"follow_fallbacks":dynamics.follow_fallbacks,"last_follow_error":dynamics.last_follow_error,"attempts":dynamics.step_attempts,"advanced_time_s":dynamics.advanced_time_s,"energy_delta":dynamics.last_energy_delta,"internal_energy_removed":dynamics.last_internal_energy_removed})
		records.back()["follow_iterations"]=dynamics.follow_iterations
		records.back()["friction_energy_removed"]=dynamics.last_friction_energy_removed
		records.back()["directional_bend_updates"]=dynamics.directional_bend_updates
		if not saved_cases and elapsed>50. and not dynamics.follow_cases.is_empty():
			_save_projection_cases(dynamics.follow_cases);saved_cases=true
		if not accepted:
			preload("res://tests/v2_fire_hose_gravity_programme.gd").new().save_case(dynamics)
			check(rig.strand.points==before and dynamics.velocities==speed and dynamics.advanced_time_s==0. and _pose_matches(),"rejected long release preserves pose, skin, speed and time atomically")
			success=false;break
		if step%2==1:await get_tree().physics_frame
	check(success and records.size()==120,"full native strand advances all120steps across60real physics frames")
	check(rig.strand._valid_positions(rig.strand.points) and dynamics.kernel._bend_error(rig.strand.points)<=.00002 and not contact.intersects_pose(rig.strand.points),"long release retains material, bending and real world clearance")
	var final_frames: Array[Transform3D]=rig.model_frames(rig.strand.points)
	var port:=true
	for i in range(initial.size()-3,initial.size()):port=port and rig.strand.points[i]==initial[i] and dynamics.velocities[i]==Vector3.ZERO
	check(port,"long release preserves the fixed fitting neck")
	var out: String=OS.get_environment("SHOT_DIR")
	if not out.is_empty():
		var bind: Array=[];var current: Array=[]
		for i in final_frames.size():
			bind.append(frame_row(rig.original_frames[i]));current.append(frame_row(final_frames[i]))
		FileAccess.open(out.path_join("settling.json"),FileAccess.WRITE).store_string(JSON.stringify({"evidence_class":"INERT","scope":"Uninstalled fixture solver costs, not played frame time or full deployment. No self-contact or water authority.","configuration":{"contact_friction":dynamics.contact_friction,"joint_contact_first":dynamics.joint_contact_first,"directional_skin_bends":dynamics.directional_skin_bends,"delta_s":dynamics.STEP_S},"steps":records,"pose":rig.snapshot(),"bind_frames":bind,"frames":current,"failures":failures},"\t"))
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(out.path_join("settling_final.png"))
	floor.free();await get_tree().physics_frame
	check(rig.restore(saved),"long release diagnostic restores the original pose")
	_sync();player.set_physics_process(physics)
func check_configuration(dynamics: RefCounted) -> bool:
	var configured: bool=dynamics.configure(rig,contact)
	check(configured,"long release binds the source-owned native solver and shell")
	return configured
func frame_row(frame: Transform3D) -> Array:
	return [[frame.basis.x.x,frame.basis.x.y,frame.basis.x.z],[frame.basis.y.x,frame.basis.y.y,frame.basis.y.z],[frame.basis.z.x,frame.basis.z.y,frame.basis.z.z],[frame.origin.x,frame.origin.y,frame.origin.z]]
func _save_projection_cases(cases: Array[Dictionary]) -> void:
	var rows: Array=[]
	for value: Dictionary in cases:
		var row: Dictionary={"error":value.error,"lengths":Array(value.lengths),"spans":Array(value.spans),"inverse":Array(value.inverse),"bend_error_m":value.bend_error_m,"planes":[],"pins":{}}
		for key: String in ["target","warm"]:
			row[key]=[]
			for point: Vector3 in value[key]:row[key].append([point.x,point.y,point.z])
		for ring: int in value.planes:
			for plane: Dictionary in value.planes[ring]:row.planes.append({"ring":ring,"normal":[plane.normal.x,plane.normal.y,plane.normal.z],"offset":plane.offset})
		for ring: int in value.pins:
			var point: Vector3=value.pins[ring];row.pins[str(ring)]=[point.x,point.y,point.z]
		rows.append(row)
	var out: String=OS.get_environment("SHOT_DIR")
	if not out.is_empty():FileAccess.open(out.path_join("projection_cases.json"),FileAccess.WRITE).store_string(JSON.stringify({"evidence_class":"INERT","cases":rows},"\t"))
