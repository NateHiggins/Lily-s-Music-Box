extends RefCounted
## Optional static-world Coulomb impulse. Positions and contact predicates stay
## with the native shell owner; the caller reprojects material velocities.
static func apply(rig: RefCounted,contact: RefCounted,records: Array,points: PackedVector3Array,incoming: PackedVector3Array,speed: PackedVector3Array,inverse: PackedFloat64Array) -> Dictionary:
 var result:=speed.duplicate()
 var frames: Array[Transform3D]=rig.model_frames(points)
 if frames.size()!=points.size() or incoming.size()!=points.size() or speed.size()!=points.size():return {"valid":false}
 var basis: Basis=rig.model.global_basis;var into: Basis=basis.inverse();var normals: Basis=basis.transposed().inverse()
 var coefficients: Dictionary={};var seen: Dictionary={};var impulses:=0
 for plane: Dictionary in records:
  var ring: int=plane.ring
  if inverse[ring]<=0.:continue
  var rid: RID=plane.rid
  if not coefficients.has(rid):
   coefficients[rid]=0.
   if rid.is_valid() and PhysicsServer3D.body_get_mode(rid)==PhysicsServer3D.BODY_MODE_STATIC:
    var coefficient: float=absf(float(PhysicsServer3D.body_get_param(rid,PhysicsServer3D.BODY_PARAM_FRICTION)))
    if not is_finite(coefficient):return {"valid":false}
    coefficients[rid]=clampf(coefficient,0.,1.)
  var friction: float=coefficients[rid]
  if friction<=0.:continue
  var support:=INF
  for point: Vector3 in contact.sections[ring].outer:support=minf(support,plane.normal.dot(frames[ring].basis*point))
  var gap: float=plane.normal.dot(points[ring])-(plane.surface-support+plane.clearance)
  if gap>.000002:continue
  if not seen.has(ring):seen[ring]=[]
  var duplicate:=false
  for previous: Vector3 in seen[ring]:
   if previous.dot(plane.normal)>.999999:duplicate=true;break
  if duplicate:continue
  seen[ring].append(plane.normal)
  var normal: Vector3=(normals*plane.normal).normalized()
  var velocity: Vector3=basis*result[ring]
  var normal_impulse: float=maxf(0.,normal.dot(basis*(speed[ring]-incoming[ring])))
  var tangent: Vector3=velocity-normal*normal.dot(velocity)
  var length: float=tangent.length()
  if length<=.00000001 or normal_impulse<=0.:continue
  velocity-=tangent*(minf(length,friction*normal_impulse)/length)
  result[ring]=into*velocity;impulses+=1
 return {"valid":true,"velocities":result,"impulses":impulses}
