extends Node
## INERT numerical reproduction. Completion does not mean a solver accepted
## these deliberately failed attempts, nor that any runtime contract passed.
func _ready() -> void:_run.call_deferred()
func _points(rows: Array) -> PackedVector3Array:
 var result:=PackedVector3Array()
 for row: Array in rows:result.append(Vector3(row[0],row[1],row[2]))
 return result
func _run() -> void:
 var path: String=OS.get_environment("ORISON_HOSE_PROJECT_CASES")
 var data: Variant=JSON.parse_string(FileAccess.get_file_as_string(path))
 if data is not Dictionary or data.get("cases") is not Array:
  push_error("Projection diagnostic input is missing");get_tree().quit(1);return
 var results: Array=[]
 for index in data.cases.size():
  var value: Dictionary=data.cases[index]
  var planes: Dictionary={};var pins: Dictionary={}
  for plane: Dictionary in value.planes:
   var ring: int=plane.ring
   if not planes.has(ring):planes[ring]=[]
   planes[ring].append({"normal":Vector3(plane.normal[0],plane.normal[1],plane.normal[2]),"offset":plane.offset})
  for key: String in value.pins:
   var row: Array=value.pins[key];pins[int(key)]=Vector3(row[0],row[1],row[2])
  for mode: String in ["follow","project_target","project_warm"]:
   var kernel:=preload("res://scripts/props/hose_contact_projection.gd").new()
   var weights:=PackedFloat64Array(value.inverse)
   for i in weights.size()-1:
    if weights[i]==0.:
     var mass: float=(float(value.lengths[i-1])*.5 if i>0 else 0.)+float(value.lengths[i])*.5
     weights[i]=1./mass
   kernel.configure(PackedFloat64Array(value.lengths),PackedFloat64Array(value.spans),weights)
   if kernel.backend_name!="native" or not kernel.set_bend_error(value.bend_error_m):
    push_error("Projection diagnostic native binding failed");get_tree().quit(1);return
   var fixed:=PackedInt32Array()
   for i in value.inverse.size():
    if value.inverse[i]==0.:fixed.append(i)
   if not kernel.pin_rings(fixed):get_tree().quit(1);return
   var target:=_points(value.target);var warm:=_points(value.warm)
   var started: int=Time.get_ticks_usec()
   var result: PackedVector3Array=kernel.follow(target,target[-1],planes,pins) if mode=="follow" else kernel.project(warm if mode=="project_warm" else target,target[-1],planes)
   var elapsed: float=(Time.get_ticks_usec()-started)/1000.
   var record: Dictionary={"case":index,"mode":mode,"accepted":not result.is_empty(),"ms":elapsed,"iterations":kernel.iterations,"qp_iterations":kernel.qp_iterations,"error":kernel.error}
   results.append(record);print("HOSE CASE DIAGNOSTIC: ",record)
 var out: String=OS.get_environment("SHOT_DIR")
 if not out.is_empty():
  DirAccess.make_dir_recursive_absolute(out)
  FileAccess.open(out.path_join("projection_diagnostic.json"),FileAccess.WRITE).store_string(JSON.stringify({"evidence_class":"INERT","scope":"Reproduces failed numerical attempts; completion grants no acceptance.","input":path,"results":results},"\t"))
 print("HOSE CASE DIAGNOSTIC COMPLETE: ",results.size()," attempts")
 get_tree().quit(0)
