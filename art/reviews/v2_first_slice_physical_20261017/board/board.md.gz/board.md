# Gate board - a9f61f8bfa30

- commit `a9f61f8bfa3021c0762c2acc05c75ba7914755e4`
- tree `7429a0ad4fae6a28231460230c8f297cff1223ba`
- created 2026-10-18T03:03:44Z
- dirty paths: 1410

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| v2_recipe_projections | PASS | 0 | 0.67 | no defects counted |
| v2_surface_qualification | PASS | 0 | 5.28 | no defects counted |
| v2_mesh_uv_imports | PASS | 0 | 0.09 | no defects counted |
| v2_surface_imports | PASS | 0 | 0.83 | no defects counted |
| ledger | INCOMPLETE | 2 | 17.2 | blockers 0 / 1 / 114 / 35 / 131 / 133; requirements 240 |
| spatial | FAIL | 5 | 8.97 | drift.new_failing 28, drift.new_reported 51, drift.stale_preserved 1 |
| systemic | PASS | 0 | 8.75 | drift.new_review 26 |
| period | PASS | 0 | 1.19 | no defects counted |
| reader | PASS | 0 | 3.61 | unread 1115; vs frozen baseline: new 0, resolved 193 |
| carriers | PASS | 0 | 0.76 | ambiguous_dynamic 2 |
| rulings | PASS | 0 | 198.84 | no defects counted |
| test:test_additive_material_rebind | PASS | 0 | 0.14 | ran 5, failed 0 |
| test:test_astra_packet | PASS | 0 | 2.53 | ran 10, failed 0 |
| test:test_audio_emitters | PASS | 0 | 5.28 | ran 6, failed 0 |
| test:test_check_rulings | PASS | 0 | 0.86 | ran 6, failed 0 |
| test:test_data_consumption | PASS | 0 | 8.67 | ran 28, failed 0 |
| test:test_gate_board | PASS | 0 | 0.23 | ran 15, failed 0 |
| test:test_heating_pipe_fittings | PASS | 0 | 0.14 | ran 3, failed 0 |
| test:test_honed_stone_maps | PASS | 0 | 0.83 | ran 4, failed 0 |
| test:test_ingest_retirement | PASS | 0 | 0.55 | ran 3, failed 0 |
| test:test_interaction_implementors | PASS | 0 | 1.02 | ran 31, failed 0 |
| test:test_interaction_prompt_carriers | PASS | 0 | 1.08 | ran 28, failed 0 |
| test:test_lanes | PASS | 0 | 2.38 | ran 6, failed 0 |
| test:test_lint_design_doc | PASS | 0 | 0.23 | ran 9, failed 0 |
| test:test_m11c0_floor01_harness_contract | PASS | 0 | 0.23 | ran 5, failed 0 |
| test:test_m11c1_floor01_source_ownership | PASS | 0 | 3.47 | ran 27, failed 0 |
| test:test_m11c1_owner_first_export | PASS | 0 | 0.47 | ran 11, failed 0 |
| test:test_m11c1_runtime_rehearsal | PASS | 0 | 8.3 | ran 19, failed 0 |
| test:test_m11c1_scanner_consumer_adapter | PASS | 0 | 0.17 | ran 7, failed 0 |
| test:test_m11c2_floor01_production_export | PASS | 0 | 0.72 | ran 11, failed 0 |
| test:test_m11c2_production_harness_contract | PASS | 0 | 0.28 | ran 22, failed 0 |
| test:test_material_catalog_persistence | PASS | 0 | 0.23 | ran 1, failed 0 |
| test:test_orison_floor01_source_ownership | PASS | 0 | 0.36 | ran 13, failed 0 |
| test:test_orison_spatial_dependencies | FAIL | 1 | 6.91 | ran 56, failed 1 |
| test:test_orison_v2_completeness | PASS | 0 | 78.17 | ran 108, failed 0 |
| test:test_period_dates | PASS | 0 | 0.61 | ran 4, failed 0 |
| test:test_prop_reference | PASS | 0 | 0.52 | ran 23, failed 0 |
| test:test_prop_review | PASS | 0 | 0.31 | ran 4, failed 0 |
| test:test_rehearse_orison_floor01_partition | PASS | 0 | 0.38 | ran 5, failed 0 |
| test:test_room_checkpoint_linter | PASS | 0 | 2.2 | ran 29, failed 0 |
| test:test_room_checkpoint_reconciler | PASS | 0 | 0.94 | ran 38, failed 0 |
| test:test_room_evidence_verifier | PASS | 0 | 13.38 | ran 34, failed 0 |
| test:test_room_gate_hook | PASS | 0 | 125.77 | ran 24, failed 0 |
| test:test_room_layout_workbench | PASS | 0 | 20.59 | ran 35, failed 0 |
| test:test_room_reconstruction_gate | PASS | 0 | 129.09 | ran 26, failed 0 |
| test:test_room_reconstruction_progress | PASS | 0 | 92.27 | ran 24, failed 0 |
| test:test_run_receipt | PASS | 0 | 1.62 | ran 10, failed 0 |
| test:test_runtime_source_projections | PASS | 0 | 0.17 | ran 4, failed 0 |
| test:test_spatial_access_evidence | PASS | 0 | 0.41 | ran 8, failed 0 |
| test:test_spatial_binding_preflight | PASS | 0 | 0.25 | ran 7, failed 0 |
| test:test_systemic_situation_authority | PASS | 0 | 7.58 | ran 59, failed 0 |
| test:test_upper_daylight_contract | PASS | 0 | 0.2 | ran 1, failed 0 |
| test:test_v2_acoustic_ownership | PASS | 0 | 0.16 | ran 15, failed 0 |
| test:test_v2_acoustic_ventilation | PASS | 0 | 0.27 | ran 5, failed 0 |
| test:test_v2_audit_digest_snapshot | PASS | 0 | 0.36 | ran 8, failed 0 |
| test:test_v2_authoring_projection | PASS | 0 | 1.52 | ran 8, failed 0 |
| test:test_v2_boiler_inlet_projection | PASS | 0 | 0.38 | ran 3, failed 0 |
| test:test_v2_completion_projection | PASS | 0 | 0.44 | ran 4, failed 0 |
| test:test_v2_fabrication_batch | PASS | 0 | 0.58 | ran 6, failed 0 |
| test:test_v2_front_lighting_plan | PASS | 0 | 0.33 | ran 9, failed 0 |
| test:test_v2_front_lighting_projection | PASS | 0 | 0.69 | ran 7, failed 0 |
| test:test_v2_front_trim | PASS | 0 | 0.78 | ran 5, failed 0 |
| test:test_v2_heating_branch_supports | PASS | 0 | 0.17 | ran 3, failed 0 |
| test:test_v2_heating_envelopes | PASS | 0 | 0.22 | ran 8, failed 0 |
| test:test_v2_heating_interfaces | PASS | 0 | 0.2 | ran 10, failed 0 |
| test:test_v2_heating_refit_projection | PASS | 0 | 0.36 | ran 10, failed 0 |
| test:test_v2_heating_routes | PASS | 0 | 0.16 | ran 8, failed 0 |
| test:test_v2_heating_takeoff | PASS | 0 | 0.25 | ran 7, failed 0 |
| test:test_v2_physical_inputs | PASS | 0 | 1.72 | ran 11, failed 0 |
| test:test_v2_radiator_vent_thread | PASS | 0 | 0.12 | ran 2, failed 0 |
| test:test_v2_recipe_projections | PASS | 0 | 0.25 | ran 4, failed 0 |
| test:test_v2_roof | PASS | 0 | 0.53 | ran 4, failed 0 |
| test:test_v2_surface_publication | PASS | 0 | 0.34 | ran 6, failed 0 |
| test:test_v2_surface_requirements | PASS | 0 | 79.52 | ran 25, failed 0 |
| test:test_v2_ventilation_fabric_projection | PASS | 0 | 0.42 | ran 3, failed 0 |
| test:test_verify_candidate | PASS | 0 | 3.39 | ran 19, failed 0 |

## Against 29226611b5be

Verdict: **REGRESSED**

requirements_changed: ['contract.B1_BOILER_01', 'contract.F02_B_RADIATOR_01', 'job.lena_radiator_round_2b', 'ritual.F01_NIGHT_REGISTER', 'ritual.F01_SIGNAL_REGISTER', 'ritual.F01_TOUR_KEY_GUARD', 'ritual.F01_WATCHMAN_DETECTOR']

### Regressions (9)

- spatial: drift.new_reported 43 -> 51
- spatial: new defect new_reported:2e98b400e7a0878c
- spatial: new defect new_reported:4c50ae0025a0e11e
- spatial: new defect new_reported:7b85219bb71c55d6
- spatial: new defect new_reported:bb2140176209900e
- spatial: new defect new_reported:ceff8b92c40b4135
- spatial: new defect new_reported:d4c4355f1d02a353
- spatial: new defect new_reported:d7ffb2e5981902ea
- spatial: new defect new_reported:f2696c399919f010

### Improvements (15)

- ledger: blockers.FIRST_SLICE_TECHNICAL 7 -> 0
- ledger: blockers.FULL_BUILDING_RUNTIME 42 -> 35
- ledger: blockers.GOLDEN_SHIFT_V2 8 -> 1
- ledger: blockers.PRODUCTION_CUTOVER 138 -> 131
- ledger: blockers.V1_RETIREMENT 140 -> 133
- ledger: contract.B1_BOILER_01 SPATIALLY_PROVEN -> RUNTIME_PROVEN
- ledger: contract.F02_B_RADIATOR_01 SPATIALLY_PROVEN -> RUNTIME_PROVEN
- ledger: job.lena_radiator_round_2b PROGRAMMED -> RUNTIME_PROVEN
- ledger: ritual.F01_NIGHT_REGISTER SPATIALLY_PROVEN -> RUNTIME_PROVEN
- ledger: ritual.F01_SIGNAL_REGISTER SPATIALLY_PROVEN -> RUNTIME_PROVEN
- ledger: ritual.F01_TOUR_KEY_GUARD SPATIALLY_PROVEN -> RUNTIME_PROVEN
- ledger: ritual.F01_WATCHMAN_DETECTOR SPATIALLY_PROVEN -> RUNTIME_PROVEN
- test:test_orison_v2_completeness: FAIL -> PASS
- test:test_orison_v2_completeness: failed 1 -> 0
- test:test_orison_v2_completeness: resolved test_live_first_slice_current_checkpoint_has_executed_contracts (__main__.LiveRepoSmokeTests.test_live_first_slice_current_checkpoint_has_executed_contracts)

### Other changes (1)

- test:test_v2_physical_inputs: new gate (PASS, exit 0)

