# Gate board - a9f61f8bfa30

- commit `a9f61f8bfa3021c0762c2acc05c75ba7914755e4`
- tree `7429a0ad4fae6a28231460230c8f297cff1223ba`
- created 2026-10-18T03:06:34Z
- dirty paths: 1411

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| spatial | FAIL | 5 | 4.86 | drift.new_failing 28, drift.new_reported 43, drift.stale_preserved 1 |
| test:test_orison_spatial_dependencies | FAIL | 1 | 5.69 | ran 56, failed 1 |

## Against 29226611b5be

Verdict: **NO REGRESSIONS**

requirements_changed: []

### Regressions (0)

- none

### Improvements (0)

- none

### Other changes (73)

- carriers: not run on this board
- ledger: not run on this board
- period: not run on this board
- reader: not run on this board
- rulings: not run on this board
- systemic: not run on this board
- test:test_additive_material_rebind: not run on this board
- test:test_astra_packet: not run on this board
- test:test_audio_emitters: not run on this board
- test:test_check_rulings: not run on this board
- test:test_data_consumption: not run on this board
- test:test_gate_board: not run on this board
- test:test_heating_pipe_fittings: not run on this board
- test:test_honed_stone_maps: not run on this board
- test:test_ingest_retirement: not run on this board
- test:test_interaction_implementors: not run on this board
- test:test_interaction_prompt_carriers: not run on this board
- test:test_lanes: not run on this board
- test:test_lint_design_doc: not run on this board
- test:test_m11c0_floor01_harness_contract: not run on this board
- test:test_m11c1_floor01_source_ownership: not run on this board
- test:test_m11c1_owner_first_export: not run on this board
- test:test_m11c1_runtime_rehearsal: not run on this board
- test:test_m11c1_scanner_consumer_adapter: not run on this board
- test:test_m11c2_floor01_production_export: not run on this board
- test:test_m11c2_production_harness_contract: not run on this board
- test:test_material_catalog_persistence: not run on this board
- test:test_orison_floor01_source_ownership: not run on this board
- test:test_orison_v2_completeness: not run on this board
- test:test_period_dates: not run on this board
- test:test_prop_reference: not run on this board
- test:test_prop_review: not run on this board
- test:test_rehearse_orison_floor01_partition: not run on this board
- test:test_room_checkpoint_linter: not run on this board
- test:test_room_checkpoint_reconciler: not run on this board
- test:test_room_evidence_verifier: not run on this board
- test:test_room_gate_hook: not run on this board
- test:test_room_layout_workbench: not run on this board
- test:test_room_reconstruction_gate: not run on this board
- test:test_room_reconstruction_progress: not run on this board
- test:test_run_receipt: not run on this board
- test:test_runtime_source_projections: not run on this board
- test:test_spatial_access_evidence: not run on this board
- test:test_spatial_binding_preflight: not run on this board
- test:test_systemic_situation_authority: not run on this board
- test:test_upper_daylight_contract: not run on this board
- test:test_v2_acoustic_ownership: not run on this board
- test:test_v2_acoustic_ventilation: not run on this board
- test:test_v2_audit_digest_snapshot: not run on this board
- test:test_v2_authoring_projection: not run on this board
- test:test_v2_boiler_inlet_projection: not run on this board
- test:test_v2_completion_projection: not run on this board
- test:test_v2_fabrication_batch: not run on this board
- test:test_v2_front_lighting_plan: not run on this board
- test:test_v2_front_lighting_projection: not run on this board
- test:test_v2_front_trim: not run on this board
- test:test_v2_heating_branch_supports: not run on this board
- test:test_v2_heating_envelopes: not run on this board
- test:test_v2_heating_interfaces: not run on this board
- test:test_v2_heating_refit_projection: not run on this board
- test:test_v2_heating_routes: not run on this board
- test:test_v2_heating_takeoff: not run on this board
- test:test_v2_radiator_vent_thread: not run on this board
- test:test_v2_recipe_projections: not run on this board
- test:test_v2_roof: not run on this board
- test:test_v2_surface_publication: not run on this board
- test:test_v2_surface_requirements: not run on this board
- test:test_v2_ventilation_fabric_projection: not run on this board
- test:test_verify_candidate: not run on this board
- v2_mesh_uv_imports: not run on this board
- v2_recipe_projections: not run on this board
- v2_surface_imports: not run on this board
- v2_surface_qualification: not run on this board

