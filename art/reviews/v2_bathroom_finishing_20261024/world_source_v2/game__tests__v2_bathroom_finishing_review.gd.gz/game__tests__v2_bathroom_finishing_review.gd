extends "res://tests/v2_bathroom_paper_review.gd"
## INERT combined installed geometry/material inspection and actual curtain input.
func _init() -> void:route_label="V2 BATHROOM FINISHING REVIEW"
func _route() -> void:
	var output:=OS.get_environment("SHOT_DIR");DirAccess.make_dir_recursive_absolute(output)
	var inspector:=preload("res://tests/orison_v2_surface_inventory.gd").new()
	var metric:=preload("res://tests/orison_v2_roof_bulkhead_caps_test.gd").new()
	var draws: Array=[];var meshes: Dictionary={};var materials: Dictionary={};var contacts: Array=[]
	var rooms:=0;var showers:=0
	for record: Dictionary in world.layout.spaces:
		if record.get("class","")!="wet" or record.get("open_shell",false):continue
		rooms+=1
		var room:=world.adapter.resolve(str(record.id)) as Node3D
		_require(room!=null,"wet room exists: "+str(record.id))
		if room==null:continue
		_require(room.get_node_or_null("HistoricMillwork")==null,"wet room floor joints replace wooden skirting: "+str(record.id))
		for label: String in ["BathroomTileWainscot","BathroomGroutJoints"]:
			var draw:=room.get_node_or_null(label) as MeshInstance3D
			if not _require(draw!=null,"installed architectural finish: "+str(record.id)+"/"+label):continue
			_require(draw.get_child_count()==0,"finish adds no collision or process owner")
			var key: String=str(record.id)+"/"+label
			meshes[key]=inspector._mesh(draw.mesh);materials[key]=inspector._material(draw.get_active_material(0));draws.append({"path":str(draw.get_path()),"mesh":key,"materials":[key],"records":draw.get_meta("finish_records")})
			metric._check_cap_mapping(draw.mesh,true)
	_require(rooms==19,"all nineteen existing wet rooms receive the finish pass")
	for source: Dictionary in world.bathroom_moisture._sources:
		var tap: TapProp=source.tap;showers+=1
		var model:=tap.get_node("StaticFixture").get_child(0) as Node3D
		var support: Node3D
		var visible:=0
		for depth: int in [360,380,400,430,440,480]:
			var node:=model.find_child("WallMount%03d"%depth,true,false) as Node3D
			if node!=null and node.visible:visible+=1;support=node
		_require(visible==1,"exactly one measured native support set: "+str(tap.graph_node_id))
		if support==null:continue
		for at: Vector2 in [Vector2(-.34,2.02),Vector2(.34,2.02),Vector2(-.34,2.19),Vector2(.34,2.19),Vector2(-.095,.98),Vector2(.095,.98),Vector2(0,1.18),Vector2(0,1.65)]:
			var depth: float=tap.shower_wall_setback
			var ray:=PhysicsRayQueryParameters3D.create(tap.to_global(Vector3(at.x,at.y,depth-.03)),tap.to_global(Vector3(at.x,at.y,depth+.02)),1,[player.get_rid()])
			var hit:=world.get_world_3d().direct_space_state.intersect_ray(ray)
			var error:=INF if hit.is_empty() else absf(tap.to_local(hit.position).z-depth)
			_require(error<.002,"native shower plate has actual structural wall backing")
			contacts.append({"tap":str(tap.graph_node_id),"at":at,"wall_depth":depth,"error":error,"finish_inset":tap.shower_finish_inset})
		for draw: MeshInstance3D in model.find_children("*","MeshInstance3D",true,false):
			if not draw.is_visible_in_tree():continue
			var key:=str(draw.get_path());meshes[key]=inspector._mesh(draw.mesh);materials[key]=inspector._material(draw.get_active_material(0));draws.append({"path":key,"mesh":key,"materials":[key]})
	_require(showers==18,"all eighteen installed showers use fitted supports")
	_require(metric.failures.is_empty(),"imported architectural UV/normal/tangent checks: "+str(metric.failures))
	metric.free()
	for path: String in inspector.texture_rows:
		var row: Dictionary=inspector.texture_rows[path]
		var size:=maxi(int(row.width),int(row.height))
		var expected:=int(log(float(size))/log(2.0)+.000001)
		_require(bool(row.mips) and int(row.mip_levels)==expected,"loaded full finish mip chain: "+path)
	_tap=world.adapter.resolve("F04_4B_SHOWER_01") as TapProp
	player.global_position=_tap.to_global(Vector3(0,.02,-.9));player.velocity=Vector3.ZERO
	for frame in 3:await get_tree().physics_frame
	await _shot("bathroom_finish_drawn",_tap.to_global(Vector3(0,1.8,.20)))
	if await _drag_part(_tap,_tap.to_global(Vector3(0,1.18,-.32)),1.78,"finishing_curtain_open"):
		await _shot("bathroom_finish_gathered",_tap.to_global(Vector3(.3,1.95,.2)))
		await _drag_part(_tap,_tap.to_global(Vector3(0,1.18,-.32)),0.0,"finishing_curtain_close")
	var casings:=preload("res://tests/orison_v2_door_casings_test.gd").new()
	casings.set_meta("shared_world_validation",true);add_child(casings)
	await casings.inspect_world(world)
	for failure: String in casings.failures:_require(false,"casing: "+failure)
	_require(casings.batch_checks>1000 and casings.failures.is_empty(),"retained installed casing/contact checks: "+str(casings.batch_checks))
	casings.queue_free()
	FileAccess.open(output.path_join("finishes.json"),FileAccess.WRITE).store_string(JSON.stringify({"evidence_class":"INERT","scope":"Combined actual-world geometry and curtain input diagnostic, no runtime_contract or human acceptance","rooms":rooms,"showers":showers,"contacts":contacts,"draws":draws,"meshes":meshes,"materials":materials,"textures":inspector.texture_rows,"failures":failures},"\t"))
	inspector.free()
