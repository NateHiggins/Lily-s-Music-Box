extends Node3D
## Development-only Orison v2 gray-box. One semantic JSON record owns spaces,
## doors, stairs, risers and anchors; every visible/collision node derives from it.

@export_file("*.json") var layout_path := "res://data/orison_v2_blockout.json"
@export var show_ceilings := true
@export var show_clearance_anchors := true
## Keep semantic bounds while production hides nonphysical reservation meshes.
@export var show_reservation_volumes := true
@export var hold_route_doors_open := true
@export var production_materials := false
var architectural_materials := preload("res://scripts/building/orison_v2_architectural_materials.gd").new()
## A composed exterior may own an open review space's physical geometry.
@export var space_geometry_exclusions: Array[String] = []

var layout: Dictionary = {}
var level_y: Dictionary = {}
var materials: Dictionary = {}
var fabricated_fixtures: Dictionary = {}
var failures: Array[String] = []
const SemanticAnchor := preload("res://scripts/building/orison_v2_semantic_anchor.gd")
## Matches the tolerance the committed suite already used for overlaps.
const OVERLAP_TOLERANCE_M2 := 0.0001

func _ready() -> void:
	layout = _load_layout(layout_path)
	if layout.is_empty():
		return
	_validate_layout()
	for identity: String in space_geometry_exclusions:
		var matches := 0
		for space: Dictionary in layout.get("spaces", []):
			if str(space.id) == identity and bool(space.get("open_shell", false)):
				matches += 1
		if matches != 1:
			failures.append("geometry exclusion must name one open-shell space: " + identity)
	if not failures.is_empty():
		for failure in failures:
			push_error("ORISON V2: " + failure)
		push_error("ORISON V2 BLOCKOUT REFUSED: %d validation failure(s) in %s;"
				% [failures.size(), layout_path]
				+ " no geometry was built and the selector group was not joined.")
		return
	_build_palette()
	_build_spaces()
	_build_single_owner_opening_frames()
	_build_doors()
	_build_windows()
	_build_envelopes()
	_build_fixtures()
	_build_platforms()
	_build_lift_landings()
	_build_stairs()
	_build_risers()
	_build_anchors()
	add_to_group("orison_v2_blockout")
	print("ORISON V2 BLOCKOUT: %d spaces / %d doors / %d anchors" % [
		layout.spaces.size(), layout.doors.size(), layout.anchors.size()])

func _load_layout(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		push_error("ORISON V2 layout missing: " + path)
		return {}
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if not parsed is Dictionary:
		push_error("ORISON V2 layout is not a JSON object")
		return {}
	return parsed

static func valid_space_unit(space: Dictionary) -> bool:
	# The same authored unit is handed to apartment door/program owners later.
	# Reject a malformed or foreign-floor owner before building its geometry.
	if not space.has("unit"): return true
	if space.unit is not String: return false
	var identity := RegEx.create_from_string("^([1-9][0-9]*)([A-Z])$")
	var matched := identity.search(space.unit)
	return matched != null and space.get("level") == "F%02d" % int(matched.get_string(1))

func _validate_layout() -> void:
	if int(layout.get("schema_version", 0)) != 1:
		failures.append("unsupported schema_version")
	if bool(layout.get("production_default", true)):
		failures.append("development blockout may not be production_default")
	var ids := {}
	for level: Dictionary in layout.get("levels", []):
		var ident := str(level.get("id", ""))
		if ident.is_empty() or level_y.has(ident):
			failures.append("invalid or duplicate level id: " + ident)
		level_y[ident] = float(level.get("y", 0.0))
	for table in ["spaces", "doors", "openings", "windows", "envelopes", "fixtures", "platforms",
			"lift_landings",
			"anchors", "capsule_stations", "stairs", "risers", "route_edges",
			"service_connections", "slab_openings", "riser_openings", "wall_service_openings", "masonry_service_openings"]:
		for record: Dictionary in layout.get(table, []):
			var ident := str(record.get("id", ""))
			if ident.is_empty() or ids.has(ident):
				failures.append("invalid or duplicate id: " + ident)
			ids[ident] = table
			if record.has("level") and not level_y.has(str(record.level)):
				failures.append("%s references missing level %s" % [ident, record.level])
	for space: Dictionary in layout.get("spaces", []):
		if not valid_space_unit(space):
			failures.append("invalid apartment unit for space level: " + str(space.get("id", "?")))
		if not _valid_rect(space.get("rect", [])):
			failures.append("invalid space rect: " + str(space.get("id", "?")))
		for fault: String in preload("res://scripts/building/orison_v2_space_footprints.gd").programme_errors(layout,space):
			failures.append(str(space.get("id","?"))+": "+fault)
	for opening: Dictionary in layout.get("slab_openings", []):
		if opening.get("surface","") not in ["Floor","Ceiling"] or not _valid_rect(opening.get("rect",[])):
			failures.append("invalid slab opening: " + str(opening.get("id","?")))
	for table: String in ["wall_service_openings","masonry_service_openings"]:
		for opening: Dictionary in layout.get(table,[]):
			if not _valid_service_bounds(opening.get("bounds",[])):
				failures.append("invalid service volume: "+str(opening.get("id","?")))
			if table=="wall_service_openings" and opening.get("side","") not in ["north","south","west","east"]:
				failures.append("invalid service wall side: "+str(opening.get("id","?")))
			if table=="masonry_service_openings" and opening.get("owner","")!="ExteriorMasonry":
				failures.append("invalid exterior-leaf service owner: "+str(opening.get("id","?")))
	for opening: Dictionary in layout.get("riser_openings", []):
		var bounds: Array=opening.get("bounds",[])
		if bounds.size()!=6 or bounds[0]>=bounds[3] or bounds[1]>=bounds[4] or bounds[2]>=bounds[5]:
			failures.append("invalid riser opening: "+str(opening.get("id","?")))
	for riser: Dictionary in layout.get("risers", []):
		if not _valid_rect(riser.get("rect", [])):
			failures.append("invalid riser rect: " + str(riser.get("id", "?")))
	for envelope: Dictionary in layout.get("envelopes", []):
		if not _valid_rect(envelope.get("rect", [])):
			failures.append("invalid envelope rect: " + str(envelope.get("id", "?")))
	for platform: Dictionary in layout.get("platforms", []):
		if not _valid_rect(platform.get("rect", [])):
			failures.append("invalid platform rect: " + str(platform.get("id", "?")))
	_validate_references(ids)
	_validate_room_overlaps()
	_validate_wall_extensions()
	_validate_single_owner_openings()
	for required in ["F01_DOOR_06", "F02_DOOR_02", "F04_DOOR_03",
			"F02_A_MAIN_VANTRY_POINT", "F04_B_MONITOR_01", "F04_B_BED",
			"F01_WATCHMAN_DETECTOR", "F01_NIGHT_REGISTER",
			"F01_SIGNAL_REGISTER", "F01_TOUR_KEY_GUARD",
			"F02_B_RADIATOR_01", "B1_BOILER_01"]:
		if not ids.has(required):
			failures.append("required compatibility id missing: " + required)

## Every cross-record reference must name a record the layout declares.
## Nothing checked them before, and both failure modes were silent: a leaf
## whose `connects` named a missing space built as a frame against the solid
## wall it should have pierced, and a stair whose `from` named a missing
## level threw inside _build_u_stair - which aborts only that one call, so
## the build continued, printed its success census, joined the selector
## group and exited 0 with the stair simply absent.
func _validate_references(ids: Dictionary) -> void:
	for opening: Dictionary in layout.get("wall_service_openings",[]):
		_require_record(ids,str(opening.get("id","?")),str(opening.get("space","")),"spaces","service wall owner")
		var room:=_space_by_id(str(opening.get("space","")))
		if room.is_empty() or not _valid_service_bounds(opening.get("bounds",[])) or opening.get("side","") not in ["north","south","west","east"]: continue
		var owned:=_service_wall_bounds(room,str(opening.side))
		if not owned.grow(.00001).encloses(_service_box(opening.bounds)):
			failures.append("service wall opening exceeds its owner: "+str(opening.id))
	for opening: Dictionary in layout.get("riser_openings", []):
		_require_record(ids,str(opening.get("id","?")),str(opening.get("riser","")),"risers","riser owner")
		for riser: Dictionary in layout.risers:
			if str(riser.id)!=str(opening.get("riser","")) or opening.get("bounds",[]).size()!=6: continue
			var cut: Array=opening.bounds
			if cut[0]<riser.rect[0] or cut[2]<riser.rect[1] or cut[3]>riser.rect[2] or cut[5]>riser.rect[3] or cut[1]<riser.from_y or cut[4]>riser.to_y:
				failures.append("riser opening exceeds its owner: "+str(opening.id))
	for opening: Dictionary in layout.get("slab_openings", []):
		_require_record(ids,str(opening.get("id","?")),str(opening.get("space","")),"spaces","slab owner")
		for space: Dictionary in layout.spaces:
			if str(space.id)!=str(opening.get("space","")) or not _valid_rect(opening.get("rect",[])): continue
			var cut: Array=opening.rect
			if cut[0]<space.rect[0] or cut[1]<space.rect[1] or cut[2]>space.rect[2] or cut[3]>space.rect[3]:
				failures.append("slab opening exceeds its owner: "+str(opening.id))
	for door: Dictionary in layout.get("doors", []):
		for target: Variant in door.get("connects", []):
			_require_record(ids, str(door.get("id", "?")), str(target),
					"spaces", "door connects")
	for opening: Dictionary in layout.get("openings", []):
		if opening.get("axis", "") not in ["x", "z"]:
			failures.append("invalid opening axis: " + str(opening.get("id", "?")))
		var sill := float(opening.get("sill", 0.0))
		if not is_finite(sill) or sill < 0.0 or sill + float(opening.get("height", 0.0)) > float(layout.dimensions.clear_height):
			failures.append("invalid opening sill: " + str(opening.get("id", "?")))
		for target: Variant in opening.get("connects", []):
			_require_record(ids, str(opening.get("id", "?")), str(target),
					"spaces", "opening connects")
	for window: Dictionary in layout.get("windows", []):
		_require_record(ids, str(window.get("id", "?")),
				str(window.get("space", "")), "spaces", "window space")
	for landing: Dictionary in layout.get("lift_landings", []):
		_require_record(ids, str(landing.get("id", "?")),
				str(landing.get("shaft", "")), "risers", "lift landing shaft")
	for stair: Dictionary in layout.get("stairs", []):
		for key: String in ["from", "to"]:
			_require_level(str(stair.get("id", "?")), str(stair.get(key, "")),
					"stair " + key)
	for edge: Dictionary in layout.get("route_edges", []):
		for key: String in ["from", "to", "via"]:
			_require_record(ids, str(edge.get("id", "?")), str(edge.get(key, "")),
					"", "route edge " + key)
	for connection: Dictionary in layout.get("service_connections", []):
		for key: String in ["from", "to"]:
			_require_record(ids, str(connection.get("id", "?")),
					str(connection.get(key, "")), "", "service connection " + key)

## `table` empty means "any declared record"; otherwise the reference must
## also come from that table, so a door cannot connect to a riser.
func _require_record(ids: Dictionary, owner: String, value: String,
		table: String, what: String) -> void:
	if value.is_empty():
		failures.append("%s has an empty %s reference" % [owner, what])
	elif not ids.has(value):
		failures.append("%s %s references undeclared record %s"
				% [owner, what, value])
	elif not table.is_empty() and str(ids[value]) != table:
		failures.append("%s %s must name a %s record, but %s is declared in %s"
				% [owner, what, table, value, ids[value]])

func _require_level(owner: String, value: String, what: String) -> void:
	if value.is_empty():
		failures.append("%s has an empty %s reference" % [owner, what])
	elif not level_y.has(value):
		failures.append("%s %s references missing level %s" % [owner, what, value])

## Two rooms on one level may not interpenetrate. Overlap used to be checked
## only in the test suite and only for hardcoded id prefixes (F04_B_*, and
## B1_*/F02_B_*), so a newly built floor got no check at all.
##
## Spaces conflict only when BOTH of them build walls. An `open_shell` space
## builds no enclosure (see _build_spaces): it is a declared zone, and the
## street/rear aprons and the F02/F04 landing decision zones deliberately lie
## inside a core. Marking a room open_shell to dodge this check is not a free
## pass - the completeness ledger reports an open_shell space as SHELL_ONLY,
## which blocks structural readiness for its floor and its unit.
func _validate_room_overlaps() -> void:
	var walled: Array[Dictionary] = []
	for space: Dictionary in layout.get("spaces", []):
		if bool(space.get("open_shell", false)):
			continue
		if _valid_rect(space.get("rect", [])):
			walled.append(space)
	for i in walled.size():
		for j in range(i + 1, walled.size()):
			var a: Dictionary = walled[i]
			var b: Dictionary = walled[j]
			if str(a.get("level", "")) != str(b.get("level", "")):
				continue
			var overlap := _rect_overlap_area(a.rect, b.rect)
			if overlap > OVERLAP_TOLERANCE_M2:
				failures.append("%s overlaps %s on level %s by %.3f m2"
						% [str(a.id), str(b.id), str(a.get("level", "?")), overlap])

## A `shared_wall_owner` opening is a single-partition contract. Adjacent room
## shells may each describe their full perimeter, but only the named owner may
## construct the shared overlap and subtract the aperture. The other shell
## omits only that shared interval; its wall beyond the shared boundary remains.
## This lets a second floor use the same data path without duplicating a wall,
## guessing a cut, or erasing an unrelated run of enclosure.
func _validate_single_owner_openings() -> void:
	var spaces := {}
	var contracts := {}
	for space: Dictionary in layout.get("spaces", []):
		spaces[str(space.get("id", ""))] = space
	for opening: Dictionary in layout.get("openings", []):
		if not opening.has("shared_wall_owner"):
			continue
		var ident := str(opening.get("id", "?"))
		var connects: Array = opening.get("connects", [])
		if connects.size() != 2:
			failures.append("%s single-owner opening must connect exactly two spaces" % ident)
			continue
		var a_id := str(connects[0])
		var b_id := str(connects[1])
		if not spaces.has(a_id) or not spaces.has(b_id):
			# Missing endpoints are already reported by _validate_references.
			continue
		var a: Dictionary = spaces[a_id]
		var b: Dictionary = spaces[b_id]
		var owner := str(opening.get("shared_wall_owner", ""))
		if owner not in [a_id, b_id]:
			failures.append("%s shared_wall_owner must name one connected space" % ident)
			continue
		var pair := [a_id, b_id]
		pair.sort()
		var contract_key := "%s:%s:%s" % [str(opening.get("level", "")),
				str(pair[0]), str(pair[1])]
		if contracts.has(contract_key):
			var prior: Dictionary = contracts[contract_key]
			if str(prior.owner) != owner:
				failures.append("%s conflicts with %s shared-wall owner" % [
						ident, str(prior.ident)])
		else:
			contracts[contract_key] = {"ident": ident, "owner": owner,
					"endpoint_ids": pair, "intervals": []}
		if str(a.get("level", "")) != str(opening.get("level", "")) \
				or str(b.get("level", "")) != str(opening.get("level", "")):
			failures.append("%s endpoints must share its declared level" % ident)
		var boundary := _shared_boundary(a, b)
		if boundary.is_empty():
			failures.append("%s endpoints do not share a positive-length wall" % ident)
			continue
		if str(opening.get("axis", "")) != str(boundary.axis):
			failures.append("%s axis does not match its shared wall" % ident)
		var center: Array = opening.get("center", [])
		if center.size() != 2:
			failures.append("%s has no valid center" % ident)
			continue
		var fixed := float(center[1] if str(boundary.axis) == "x" else center[0])
		var along := float(center[0] if str(boundary.axis) == "x" else center[1])
		var width := float(opening.get("width", 0.0))
		var height := float(opening.get("height", 0.0))
		if not is_equal_approx(fixed, float(boundary.fixed)):
			failures.append("%s is not on its endpoints' shared wall" % ident)
		if width < 0.91 or height < 2.13:
			failures.append("%s is smaller than the maintenance-route minimum" % ident)
		if height > float(layout.dimensions.clear_height) + 0.001:
			failures.append("%s exceeds the clear storey height" % ident)
		if along - width * 0.5 < float(boundary.start) - 0.001 \
				or along + width * 0.5 > float(boundary.finish) + 0.001:
			failures.append("%s does not lie entirely on the shared boundary" % ident)
		var contract: Dictionary = contracts[contract_key]
		var interval := Vector2(along - width * 0.5, along + width * 0.5)
		for prior_interval: Vector2 in contract.intervals:
			if minf(interval.y, prior_interval.y) \
					- maxf(interval.x, prior_interval.x) > 0.001:
				failures.append("%s overlaps another single-owner aperture" % ident)
		contract.intervals.append(interval)
		var owner_space: Dictionary = spaces[owner]
		var owner_side := str(boundary.a_side if owner == a_id else boundary.b_side)
		if not _space_owns_side(owner_space, owner_side):
			failures.append("%s named owner does not author the shared wall side" % ident)
	_validate_single_owner_partition_apertures(contracts, spaces)

func _validate_single_owner_partition_apertures(contracts: Dictionary,
		spaces: Dictionary) -> void:
	for key: String in contracts:
		var contract: Dictionary = contracts[key]
		var endpoint_ids: Array = contract.endpoint_ids
		var boundary := _shared_boundary(spaces[str(endpoint_ids[0])],
				spaces[str(endpoint_ids[1])])
		if boundary.is_empty():
			continue
		for door: Dictionary in layout.get("doors", []):
			if _record_cuts_contract_partition(door, endpoint_ids, boundary):
				failures.append("%s conflicts with %s single-owner partition" % [
						str(door.get("id", "?")), str(contract.ident)])
		for opening: Dictionary in layout.get("openings", []):
			if opening.has("shared_wall_owner"):
				continue
			if _record_cuts_contract_partition(opening, endpoint_ids, boundary):
				failures.append("%s conflicts with %s single-owner partition" % [
						str(opening.get("id", "?")), str(contract.ident)])
		for window: Dictionary in layout.get("windows", []):
			if str(window.get("space", "")) not in endpoint_ids:
				continue
			if _record_on_boundary(window, boundary):
				failures.append("%s conflicts with %s single-owner partition" % [
						str(window.get("id", "?")), str(contract.ident)])

func _record_cuts_contract_partition(record: Dictionary, endpoint_ids: Array,
		boundary: Dictionary) -> bool:
	var connects: Array = record.get("connects", [])
	if not connects.any(func(endpoint: Variant) -> bool:
			return str(endpoint) in endpoint_ids):
		return false
	return _record_on_boundary(record, boundary)

func _record_on_boundary(record: Dictionary, boundary: Dictionary) -> bool:
	var center: Array = record.get("center", [])
	if center.size() != 2:
		return false
	if record.has("axis") and str(record.get("axis", "")) != str(boundary.axis):
		return false
	var fixed := float(center[1] if str(boundary.axis) == "x" else center[0])
	if not is_equal_approx(fixed, float(boundary.fixed)):
		return false
	var along := float(center[0] if str(boundary.axis) == "x" else center[1])
	var half_width := float(record.get("width", 0.0)) * 0.5
	return minf(along + half_width, float(boundary.finish)) \
			- maxf(along - half_width, float(boundary.start)) > 0.001

func _space_owns_side(space: Dictionary, side: String) -> bool:
	return not bool(space.get("open_shell", false)) \
			and side in space.get("wall_sides", ["south", "north", "west", "east"])

func _shared_boundary(a: Dictionary, b: Dictionary) -> Dictionary:
	var ar: Array = a.get("rect", [])
	var br: Array = b.get("rect", [])
	if not _valid_rect(ar) or not _valid_rect(br):
		return {}
	var z_start := maxf(float(ar[1]), float(br[1]))
	var z_finish := minf(float(ar[3]), float(br[3]))
	if z_finish - z_start > 0.001 and is_equal_approx(float(ar[2]), float(br[0])):
		return {"a_side": "east", "b_side": "west", "axis": "z",
				"fixed": float(ar[2]), "start": z_start, "finish": z_finish}
	if z_finish - z_start > 0.001 and is_equal_approx(float(ar[0]), float(br[2])):
		return {"a_side": "west", "b_side": "east", "axis": "z",
				"fixed": float(ar[0]), "start": z_start, "finish": z_finish}
	var x_start := maxf(float(ar[0]), float(br[0]))
	var x_finish := minf(float(ar[2]), float(br[2]))
	if x_finish - x_start > 0.001 and is_equal_approx(float(ar[3]), float(br[1])):
		return {"a_side": "north", "b_side": "south", "axis": "x",
				"fixed": float(ar[3]), "start": x_start, "finish": x_finish}
	if x_finish - x_start > 0.001 and is_equal_approx(float(ar[1]), float(br[3])):
		return {"a_side": "south", "b_side": "north", "axis": "x",
				"fixed": float(ar[1]), "start": x_start, "finish": x_finish}
	return {}

func _rect_overlap_area(a: Array, b: Array) -> float:
	var across := minf(float(a[2]), float(b[2])) - maxf(float(a[0]), float(b[0]))
	var deep := minf(float(a[3]), float(b[3])) - maxf(float(a[1]), float(b[1]))
	return maxf(0.0, across) * maxf(0.0, deep)

func _valid_rect(value: Variant) -> bool:
	return value is Array and value.size() == 4 \
			and float(value[0]) < float(value[2]) and float(value[1]) < float(value[3])

func _validate_wall_extensions() -> void:
	var edges: Array[Dictionary] = []
	for space: Dictionary in layout.get("spaces", []):
		if not _valid_rect(space.get("rect", [])): continue
		var extensions: Variant = space.get("wall_extensions", [])
		if extensions is not Array:
			failures.append(str(space.id) + " wall_extensions must be an array")
			continue
		if bool(space.get("open_shell", false)):
			if not extensions.is_empty(): failures.append(str(space.id) + " open shell cannot own wall extensions")
			continue
		var sides: Array = space.get("wall_sides", ["south", "north", "west", "east"])
		for side: String in sides:
			var edge := _wall_edge(space.rect, side)
			edges.append({"owner":space.id, "level":space.level, "axis":"z" if side in ["west","east"] else "x",
					"fixed":edge.x, "start":edge.y, "end":edge.z, "extension":false})
		for extension: Variant in extensions:
			if extension is not Dictionary or extension.get("side") not in ["south","north","west","east"]:
				failures.append(str(space.id) + " invalid wall extension side")
				continue
			var valid := true
			for field in ["start", "end"]:
				var value: Variant = extension.get(field)
				if typeof(value) not in [TYPE_FLOAT, TYPE_INT] or not is_finite(float(value)): valid = false
			if not valid:
				failures.append(str(space.id) + " invalid wall extension interval")
				continue
			var edge := _wall_edge(space.rect, str(extension.side))
			if extension.side in sides or float(extension.start) < edge.y - .0001 or float(extension.end) > edge.z + .0001 \
					or float(extension.end) <= float(extension.start):
				failures.append(str(space.id) + " wall extension exceeds or duplicates its edge")
				continue
			edges.append({"owner":space.id, "level":space.level, "axis":"z" if extension.side in ["west","east"] else "x",
					"fixed":edge.x, "start":extension.start, "end":extension.end, "extension":true})
	for i in edges.size():
		if not bool(edges[i].extension): continue
		for j in edges.size():
			if i == j or edges[i].level != edges[j].level or edges[i].axis != edges[j].axis \
					or not is_equal_approx(float(edges[i].fixed), float(edges[j].fixed)): continue
			if minf(float(edges[i].end),float(edges[j].end)) > maxf(float(edges[i].start),float(edges[j].start)) + .0001:
				failures.append("%s wall extension overlaps wall owned by %s" % [edges[i].owner, edges[j].owner])

func _wall_edge(rect: Array, side: String) -> Vector3:
	if side == "west": return Vector3(rect[0],rect[1],rect[3])
	if side == "east": return Vector3(rect[2],rect[1],rect[3])
	if side == "south": return Vector3(rect[1],rect[0],rect[2])
	return Vector3(rect[3],rect[0],rect[2])

func _build_palette() -> void:
	for key: String in layout.get("palette", {}):
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color.html(str(layout.palette[key]))
		mat.roughness = 0.9
		if key in ["clearance", "interaction", "unresolved"]:
			mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			mat.albedo_color.a = 0.32
		materials[key] = mat

func _build_spaces() -> void:
	var dims: Dictionary = layout.dimensions
	var clear_h := float(dims.clear_height)
	var slab_t := float(dims.slab_thickness)
	var soffits:=preload("res://scripts/building/orison_v2_platform_soffits.gd")
	var floor_owners: Array[Dictionary]=soffits.ceiling_owners(layout,level_y,space_geometry_exclusions,show_ceilings)
	# Platforms retain their already accepted underside ownership. Room slabs
	# fill only exposed gaps, and earlier room slabs own overlapping footprints.
	for platform: Dictionary in layout.get("platforms",[]):floor_owners.append_array(soffits.floor_owners(platform,layout,level_y))
	for space: Dictionary in layout.spaces:
		var rect: Array = space.rect
		var y := float(level_y[space.level])
		var cls := str(space.get("class", "unresolved"))
		var parent := Node3D.new()
		parent.name = str(space.id)
		parent.set_meta("purpose", str(space.get("purpose", "")))
		parent.set_meta("room_id", str(space.id))
		if space.has("floor_platforms"):
			parent.set_meta("floor_platforms",space.floor_platforms.duplicate())
			parent.set_meta("landing_core",str(space.landing_core))
			parent.set_meta("programme_anchors",space.programme_anchors.duplicate())
		add_child(parent)
		if str(space.id) in space_geometry_exclusions:
			parent.set_meta("geometry_owned_by_exterior", true)
			continue
		if not bool(space.get("no_floor", false)):
			_build_slab(parent, "Floor", rect, y - slab_t * .5, slab_t, cls, true)
			if production_materials:
				soffits.append(parent.get_node("Floor"),space,layout,level_y,floor_owners,architectural_materials.material_for("Ceiling",cls),true)
				floor_owners.append_array(soffits.floor_owners(space,layout,level_y))
		if show_ceilings and not bool(space.get("no_ceiling", false)):
			_build_slab(parent, "Ceiling", rect, y + clear_h + slab_t * .5, slab_t, cls, false)
		if not bool(space.get("open_shell", false)):
			# Open stair volumes have no ceiling slab to close the 200 mm
			# storey band. Their walls must continue to the next walking level.
			var wall_h := float(dims.floor_to_floor) if bool(space.get("no_ceiling", false)) else clear_h
			_build_space_outline(parent, str(space.id), rect, y, wall_h, cls,
					space.get("wall_sides", ["south", "north", "west", "east"]))
			for index in space.get("wall_extensions", []).size():
				var extension: Dictionary = space.wall_extensions[index]
				var side := str(extension.side)
				var edge := _wall_edge(rect, side)
				_wall_with_openings(parent, str(space.id), side.capitalize() + "Extension%02d" % index,
						"z" if side in ["west","east"] else "x", edge.x,
						float(extension.start), float(extension.end), y, wall_h,
						float(layout.dimensions.partition_wall), cls)
	# Shared wall owners must all exist before fitting either room-facing side.
	if production_materials:
		var millwork := preload("res://scripts/building/orison_v2_millwork.gd")
		var wall_stock := millwork.collect_wall_stock(self)
		for space: Dictionary in layout.spaces:
			if str(space.id) in space_geometry_exclusions: continue
			var room := get_node_or_null(str(space.id)) as Node3D
			if room==null: continue
			var finish_clearances: Array[AABB] = preload("res://scripts/building/orison_v2_window_joinery.gd").clearance_boxes(self,space)
			for mount: Dictionary in layout.anchors:
				if str(mount.get("space","")) != str(space.id) or not mount.has("finish_bounds"): continue
				var box := _service_box(mount.finish_bounds)
				box.position.y += float(level_y[space.level])
				finish_clearances.append(box)
			millwork.build(room,space,float(level_y[space.level]),clear_h,float(dims.partition_wall),
				architectural_materials.material_for("FrameTrim",str(space.get("class","private"))),
				architectural_materials.material_for("Leaf",str(space.get("class","private"))),layout.doors,
				finish_clearances,wall_stock)

## A single slab render/collision owner retains the original stable node path.
## Only explicit, owner-bounded service apertures change its physical surface.
func _build_slab(parent: Node3D, label: String, rect: Array, y: float, thickness: float, cls: String, collision: bool) -> void:
	var bounds:=AABB(Vector3(rect[0],y-thickness*.5,rect[1]),Vector3(_rect_w(rect),thickness,_rect_d(rect)))
	var pieces: Array[AABB]=[bounds]
	for opening: Dictionary in layout.get("slab_openings",[]):
		if str(opening.space)!=str(parent.name) or str(opening.surface)!=label: continue
		var cut: Array=opening.rect
		var aperture:=AABB(Vector3(cut[0],bounds.position.y-.001,cut[1]),Vector3(cut[2]-cut[0],thickness+.002,cut[3]-cut[1]))
		var remaining: Array[AABB]=[]
		for piece: AABB in pieces: remaining.append_array(_subtract_box(piece,aperture))
		pieces=remaining
	if pieces.size()==1 and pieces[0]==bounds:
		_box(parent,label,bounds.get_center(),bounds.size,cls,collision)
		return
	var draw:=MeshInstance3D.new()
	draw.name=label
	var surface:=SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	var body:=StaticBody3D.new() if collision else null
	if body!=null: body.name="Collision"
	for piece: AABB in pieces:
		var box:=BoxMesh.new()
		box.size=piece.size
		var mesh: Mesh=_slab_faces(box,label=="Floor") if production_materials else box
		surface.append_from(mesh,0,Transform3D(Basis.IDENTITY,piece.get_center()))
		if body!=null:
			var shape_node:=CollisionShape3D.new()
			var shape:=BoxShape3D.new()
			shape.size=piece.size
			shape_node.shape=shape
			shape_node.position=piece.get_center()
			body.add_child(shape_node)
	draw.mesh=surface.commit()
	if production_materials: draw.mesh=_architectural_chart(draw.mesh,parent,Vector3.ZERO,cls)
	draw.material_override=architectural_materials.material_for(label,cls) if production_materials else materials.get(cls)
	if production_materials: draw.set_meta("v2_material_key",architectural_materials.key_for(label,cls))
	parent.add_child(draw)
	if body!=null: draw.add_child(body)

func _build_space_outline(parent: Node3D, space_id: String, rect: Array, y: float,
		height: float, cls: String, sides: Array) -> void:
	var t := float(layout.dimensions.partition_wall)
	if "south" in sides:
		_wall_with_openings(parent, space_id, "South", "x", float(rect[1]),
				float(rect[0]), float(rect[2]), y, height, t, cls)
	if "north" in sides:
		_wall_with_openings(parent, space_id, "North", "x", float(rect[3]),
				float(rect[0]), float(rect[2]), y, height, t, cls)
	if "west" in sides:
		_wall_with_openings(parent, space_id, "West", "z", float(rect[0]),
				float(rect[1]), float(rect[3]), y, height, t, cls)
	if "east" in sides:
		_wall_with_openings(parent, space_id, "East", "z", float(rect[2]),
				float(rect[1]), float(rect[3]), y, height, t, cls)

func _wall_with_openings(parent: Node3D, space_id: String, label: String,
		axis: String, fixed: float, start: float, finish: float, y: float,
		height: float, thickness: float, cls: String) -> void:
	var openings: Array[Dictionary] = []
	for door: Dictionary in layout.doors:
		if not space_id in door.connects:
			continue
		var on_wall := (is_equal_approx(float(door.center[1]), fixed) if axis == "x"
				else is_equal_approx(float(door.center[0]), fixed))
		if on_wall:
			openings.append({"center": float(door.center[0] if axis == "x" else door.center[1]),
					"width": float(door.width), "height": float(door.height), "sill": 0.0})
	var omitted_shared_walls := {}
	for opening: Dictionary in layout.get("openings", []):
		if not space_id in opening.connects or str(opening.axis) != axis:
			continue
		if opening.has("shared_wall_owner") \
				and str(opening.shared_wall_owner) != space_id:
			var omission := _shared_wall_omission(opening, space_id, axis, fixed)
			if not omission.is_empty():
				var omission_key := "%s:%.4f:%.4f" % [axis,
						float(omission.center), float(omission.width)]
				if not omitted_shared_walls.has(omission_key):
					openings.append(omission)
					omitted_shared_walls[omission_key] = true
			continue
		var fixed_value := float(opening.center[1] if axis == "x" else opening.center[0])
		if is_equal_approx(fixed_value, fixed):
			openings.append({"center": float(opening.center[0] if axis == "x" else opening.center[1]),
					"width": float(opening.width), "height": float(opening.height), "sill": float(opening.get("sill", 0.0))})
	for window: Dictionary in layout.get("windows", []):
		if str(window.space) != space_id or str(window.axis) != axis:
			continue
		var fixed_value := float(window.center[1] if axis == "x" else window.center[0])
		if is_equal_approx(fixed_value, fixed):
			openings.append({"center": float(window.center[0] if axis == "x" else window.center[1]),
					"width": float(window.width), "height": float(window.height),
					"sill": float(window.sill)})
	openings.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		return float(a.center) < float(b.center))
	var cursor := start
	var part := 0
	for opening: Dictionary in openings:
		var lo := maxf(start, float(opening.center) - float(opening.width) * 0.5)
		var hi := minf(finish, float(opening.center) + float(opening.width) * 0.5)
		# Partial edges share their owner's complete aperture roster. An opening
		# outside this segment must not produce geometry past either endpoint.
		if hi <= lo + 0.001:
			continue
		if lo > cursor + 0.001:
			_wall_segment(parent, "Wall%s_%02d" % [label, part], axis, fixed,
					cursor, lo, y, height, thickness, cls)
			part += 1
		var sill := float(opening.get("sill", 0.0))
		if sill > 0.001:
			_wall_segment(parent, "Wall%s_Sill%02d" % [label, part], axis, fixed,
					lo, hi, y, sill, thickness, cls)
			part += 1
		var head_base := sill + float(opening.height)
		var head_h := height - head_base
		if head_h > 0.001:
			_wall_segment(parent, "Wall%s_Head%02d" % [label, part], axis, fixed,
					lo, hi, y + head_base, head_h, thickness, cls)
			part += 1
		cursor = maxf(cursor, hi)
	if cursor < finish - 0.001:
		_wall_segment(parent, "Wall%s_%02d" % [label, part], axis, fixed,
				cursor, finish, y, height, thickness, cls)

func _shared_wall_omission(opening: Dictionary, space_id: String,
		axis: String, fixed: float) -> Dictionary:
	var connects: Array = opening.get("connects", [])
	if connects.size() != 2:
		return {}
	var other_id := str(connects[1] if str(connects[0]) == space_id else connects[0])
	var here := _space_by_id(space_id)
	var other := _space_by_id(other_id)
	if here.is_empty() or other.is_empty():
		return {}
	var boundary := _shared_boundary(here, other)
	if boundary.is_empty() or str(boundary.axis) != axis \
			or not is_equal_approx(float(boundary.fixed), fixed):
		return {}
	return {"center": (float(boundary.start) + float(boundary.finish)) * 0.5,
			"width": float(boundary.finish) - float(boundary.start),
			"height": float(layout.dimensions.clear_height), "sill": 0.0}

func _space_by_id(space_id: String) -> Dictionary:
	for space: Dictionary in layout.get("spaces", []):
		if str(space.get("id", "")) == space_id:
			return space
	return {}

## A leafless maintenance opening still needs to read as a deliberate cased
## connection. These three non-colliding reveal pieces are derived from the
## same generic record that cuts the owner wall; they add no second collision
## authority and cannot narrow the declared clear aperture.
func _build_single_owner_opening_frames() -> void:
	var wall_depth := float(layout.dimensions.partition_wall) + 0.04
	var reveal_width := 0.09
	for opening: Dictionary in layout.get("openings", []):
		if not opening.has("shared_wall_owner"):
			continue
		var parent := Node3D.new()
		parent.name = str(opening.id)
		parent.position = Vector3(float(opening.center[0]),
				float(level_y[opening.level]), float(opening.center[1]))
		parent.set_meta("connects", opening.connects)
		parent.set_meta("shared_wall_owner", str(opening.shared_wall_owner))
		parent.set_meta("non_colliding_reveal", true)
		add_child(parent)
		var width := float(opening.width)
		var height := float(opening.height)
		if str(opening.axis) == "x":
			_box(parent, "RevealA", Vector3(-width * 0.5 - reveal_width * 0.5,
					height * 0.5, 0.0), Vector3(reveal_width, height, wall_depth),
					"opening", false)
			_box(parent, "RevealB", Vector3(width * 0.5 + reveal_width * 0.5,
					height * 0.5, 0.0), Vector3(reveal_width, height, wall_depth),
					"opening", false)
			_box(parent, "RevealHead", Vector3(0.0, height + reveal_width * 0.5,
					0.0), Vector3(width + reveal_width * 2.0, reveal_width,
					wall_depth), "opening", false)
		else:
			_box(parent, "RevealA", Vector3(0.0, height * 0.5,
					-width * 0.5 - reveal_width * 0.5),
					Vector3(wall_depth, height, reveal_width), "opening", false)
			_box(parent, "RevealB", Vector3(0.0, height * 0.5,
					width * 0.5 + reveal_width * 0.5),
					Vector3(wall_depth, height, reveal_width), "opening", false)
			_box(parent, "RevealHead", Vector3(0.0, height + reveal_width * 0.5,
					0.0), Vector3(wall_depth, reveal_width,
					width + reveal_width * 2.0), "opening", false)
		_build_service_opening_practical(parent, opening)

## A source-owned bulkhead practical makes a leafless service connection read
## as maintained circulation in the actual blockout, not only in a capture.
## It is derived for every single-owner opening and carries no collision.
func _build_service_opening_practical(parent: Node3D,
		opening: Dictionary) -> void:
	var practical := Node3D.new()
	practical.name = "ServicePractical"
	practical.position.y = minf(float(opening.height) + 0.16,
			float(layout.dimensions.clear_height) - 0.16)
	practical.set_meta("source_owned_service_practical", true)
	parent.add_child(practical)
	var wall_axis := str(opening.axis)
	var backplate_size := Vector3(0.12, 0.20, 0.46) \
			if wall_axis == "z" else Vector3(0.46, 0.20, 0.12)
	var lens_size := Vector3(0.18, 0.12, 0.30) \
			if wall_axis == "z" else Vector3(0.30, 0.12, 0.18)
	_box(practical, "Backplate", Vector3.ZERO, backplate_size,
			"service", false)
	var lens := _box(practical, "OpalLens", Vector3(0.0, -0.12, 0.0),
			lens_size, "opening", false)
	var lens_material := StandardMaterial3D.new()
	lens_material.albedo_color = Color(0.92, 0.72, 0.46)
	lens_material.roughness = 0.72
	lens_material.emission_enabled = true
	lens_material.emission = Color(1.0, 0.62, 0.30)
	lens_material.emission_energy_multiplier = 1.5
	(lens.mesh as BoxMesh).material = lens_material
	var light := OmniLight3D.new()
	light.name = "WarmServiceLight"
	light.position = Vector3(0.0, -0.22, 0.0)
	light.light_color = Color(1.0, 0.72, 0.45)
	light.light_energy = 3.2
	light.omni_range = 4.8
	light.omni_attenuation = 1.25
	light.shadow_enabled = true
	practical.add_child(light)

func _wall_segment(parent: Node3D, node_name: String, axis: String, fixed: float,
		start: float, finish: float, y: float, height: float, thickness: float,
		cls: String) -> void:
	var center := (start + finish) * 0.5
	var at:=Vector3(center,y+height*.5,fixed) if axis=="x" else Vector3(fixed,y+height*.5,center)
	var size:=Vector3(finish-start,height,thickness) if axis=="x" else Vector3(thickness,height,finish-start)
	var bounds:=AABB(at-size*.5,size)
	var pieces: Array[AABB]=[bounds]
	# This perpendicular corner stock reaches into the already-authored shop
	# aperture. Fit that existing opening through the touching boiler return.
	if str(parent.name)=="B1_BOILER_ROOM":
		for door: Dictionary in layout.doors:
			if str(door.id)!="B1_SHOP_STAIR_DOOR": continue
			var yaw:=float(door.yaw)
			var width:=float(door.width);var head:=float(door.height)
			var aperture_size:=Vector3(absf(cos(yaw))*width+absf(sin(yaw))*thickness,
					head,absf(sin(yaw))*width+absf(cos(yaw))*thickness)
			var aperture_center:=Vector3(float(door.center[0]),float(level_y[str(door.level)])+head*.5,float(door.center[1]))
			var aperture:=AABB(aperture_center-aperture_size*.5,aperture_size)
			# Its source-owned outward leaf turns beside this perpendicular
			# return. Include the retained hardware envelope, through 85 degrees.
			var yaw_basis:=Basis(Vector3.UP,yaw)
			var pivot:=Vector3(float(door.center[0]),0,float(door.center[1]))+yaw_basis*Vector3(-width*.5,0,.026)
			var owner:=PackedVector2Array([Vector2(bounds.position.x,bounds.position.z),Vector2(bounds.end.x,bounds.position.z),Vector2(bounds.end.x,bounds.end.z),Vector2(bounds.position.x,bounds.end.z)])
			var points: PackedVector2Array=[]
			for step in range(341):
				var basis:=Basis(Vector3.UP,yaw-deg_to_rad(float(step)*.25))
				var footprint: PackedVector2Array=[]
				for uv: Vector2 in [Vector2(0,-.106),Vector2(width,-.106),Vector2(width,.054),Vector2(0,.054)]:
					var point:=pivot+basis*Vector3(uv.x,0,uv.y)
					footprint.append(Vector2(point.x,point.z))
				for intersection: PackedVector2Array in Geometry2D.intersect_polygons(footprint,owner):points.append_array(intersection)
			if not points.is_empty():
				var low:=points[0];var high:=points[0]
				for point: Vector2 in points:
					low=low.min(point);high=high.max(point)
				aperture=aperture.merge(AABB(Vector3(low.x-.002,aperture.position.y,low.y-.002),Vector3(high.x-low.x+.004,head,high.y-low.y+.004)))
			var remaining: Array[AABB]=[]
			for piece: AABB in pieces:remaining.append_array(_subtract_box(piece,aperture))
			pieces=remaining
	for opening: Dictionary in layout.get("wall_service_openings",[]):
		if str(opening.space)!=str(parent.name) or not node_name.begins_with("Wall"+str(opening.side).capitalize()): continue
		var remaining: Array[AABB]=[]
		for piece: AABB in pieces: remaining.append_array(_subtract_box(piece,_service_box(opening.bounds)))
		pieces=remaining
	var draw:=_box(parent,node_name,at,size,cls,true)
	_far_face_skin(parent,node_name,axis,fixed,at,size,pieces,cls)
	if pieces.size()==1 and pieces[0]==bounds: return
	var body:=draw.get_node("Collision") as StaticBody3D
	for shape: CollisionShape3D in body.get_children(): shape.free()
	if pieces.is_empty():
		draw.visible=false
		return
	var surface:=SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	for piece: AABB in pieces:
		var box:=BoxMesh.new()
		box.size=piece.size
		var local:=piece.get_center()-at
		surface.append_from(box,0,Transform3D(Basis.IDENTITY,local))
		var shape:=CollisionShape3D.new()
		var box_shape:=BoxShape3D.new()
		box_shape.size=piece.size
		shape.shape=box_shape
		shape.position=local
		body.add_child(shape)
	draw.mesh=surface.commit()
	if production_materials: draw.mesh=_architectural_chart(draw.mesh,parent,at,cls)

## Dossier BW-004: a wet room's wall carries tile on both faces, so the hall or
## bedroom beyond sees subway tile. A 4 mm skin on the far face takes the
## neighbouring space's finish, cut by the same openings. Exterior and
## service-opening walls are left alone; the skin has no collision.
## Slice 44 (F05_C_BATH-003): the reverse case too. A wall a dry room owns
## and shares with a bath gets a wet skin on its bath face, so tile no longer
## stops at the corner of a bath whose fourth wall belongs to its neighbour.
func _far_face_skin(parent: Node3D, node_name: String, axis: String, fixed: float,
		at: Vector3, size: Vector3, pieces: Array[AABB], cls: String) -> void:
	var owner: Dictionary = {}
	for space: Dictionary in layout.get("spaces", []):
		if str(space.id) == str(parent.name): owner = space
	if owner.is_empty(): return
	var r: Array = owner.rect
	var centre_fixed: float = (float(r[1]) + float(r[3])) * .5 if axis == "x" else (float(r[0]) + float(r[2])) * .5
	var outward: float = 1.0 if fixed > centre_fixed else -1.0
	var start: float = (at.x - size.x * .5) if axis == "x" else (at.z - size.z * .5)
	var finish: float = (at.x + size.x * .5) if axis == "x" else (at.z + size.z * .5)
	var neighbour := ""
	# Dossier slice 44: a dry owner's wall can face several rooms (a stair core's
	# wall runs past a vestibule, a bath and a kitchen). Tile every bath span on
	# it, not only the first neighbour found.
	var wet_spans: Array = []
	for space: Dictionary in layout.spaces:
		if str(space.level) != str(owner.level) or str(space.id) == str(owner.id): continue
		var q: Array = space.rect
		var edge: float = (float(q[1]) if outward > 0.0 else float(q[3])) if axis == "x" else (float(q[0]) if outward > 0.0 else float(q[2]))
		if not is_equal_approx(edge, fixed): continue
		var lo: float = float(q[0]) if axis == "x" else float(q[1])
		var hi: float = float(q[2]) if axis == "x" else float(q[3])
		if hi <= start + .05 or lo >= finish - .05: continue
		var found := str(space.get("class", "private"))
		if neighbour.is_empty(): neighbour = found
		if found == "wet": wet_spans.append(Vector2(maxf(lo, start), minf(hi, finish)))
	if neighbour.is_empty(): return
	if cls == "wet":
		if neighbour == cls: return
	else:
		if wet_spans.is_empty(): return
		neighbour = "wet"
	var thickness: float = size.z if axis == "x" else size.x
	var shift: float = outward * (thickness * .5 + .002)
	var skin_at := at + (Vector3(0, 0, shift) if axis == "x" else Vector3(shift, 0, 0))
	var skin_size := Vector3(size.x, size.y, .004) if axis == "x" else Vector3(.004, size.y, size.z)
	var skin := _box(parent, node_name + "_FarSkin", skin_at, skin_size, neighbour, false)
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	var appended := 0
	for source_piece: AABB in pieces:
		# A dry owner's wall may run past the bath: tile only each bath's own span.
		var spans: Array = wet_spans if cls != "wet" else [Vector2(-INF, INF)]
		for span: Vector2 in spans:
			var piece := source_piece
			if cls != "wet":
				var p0: float = piece.position.x if axis == "x" else piece.position.z
				var p1: float = piece.end.x if axis == "x" else piece.end.z
				var c0 := maxf(p0, span.x)
				var c1 := minf(p1, span.y)
				if c1 - c0 < .01: continue
				if axis == "x":
					piece.position.x = c0; piece.size.x = c1 - c0
				else:
					piece.position.z = c0; piece.size.z = c1 - c0
			var box := BoxMesh.new()
			box.size = Vector3(piece.size.x, piece.size.y, .004) if axis == "x" else Vector3(.004, piece.size.y, piece.size.z)
			var local := piece.get_center() - at
			if axis == "x": local.z = 0.0
			else: local.x = 0.0
			surface.append_from(box, 0, Transform3D(Basis.IDENTITY, local))
			appended += 1
	if appended == 0:
		skin.free()
		return
	skin.mesh = surface.commit()
	if production_materials: skin.mesh=_architectural_chart(skin.mesh,parent,skin_at,neighbour)

static func _valid_service_bounds(bounds: Variant) -> bool:
	if bounds is not Array or bounds.size()!=6: return false
	for value: Variant in bounds:
		if typeof(value) not in [TYPE_FLOAT,TYPE_INT] or not is_finite(float(value)): return false
	return bounds[0]<bounds[3] and bounds[1]<bounds[4] and bounds[2]<bounds[5]

static func _service_box(bounds: Array) -> AABB:
	return AABB(Vector3(bounds[0],bounds[1],bounds[2]),Vector3(bounds[3]-bounds[0],bounds[4]-bounds[1],bounds[5]-bounds[2]))

func _service_wall_bounds(room: Dictionary,side: String) -> AABB:
	var r: Array=room.rect
	var y: float=level_y[str(room.level)]
	var height: float=layout.dimensions.floor_to_floor if room.get("no_ceiling",false) else layout.dimensions.clear_height
	var half: float=layout.dimensions.partition_wall*.5
	if side in ["south","north"]:
		var z: float=r[1] if side=="south" else r[3]
		return AABB(Vector3(r[0],y,z-half),Vector3(r[2]-r[0],height,half*2))
	var x: float=r[0] if side=="west" else r[2]
	return AABB(Vector3(x-half,y,r[1]),Vector3(half*2,height,r[3]-r[1]))

func _build_doors() -> void:
	for door: Dictionary in layout.doors:
		var parent := Node3D.new()
		parent.name = str(door.id)
		parent.set_meta("connects", door.connects)
		parent.set_meta("hinge", str(door.hinge))
		parent.set_meta("swing", str(door.swing))
		var y := float(level_y[door.level])
		parent.position = Vector3(float(door.center[0]), y, float(door.center[1]))
		parent.rotation.y = float(door.yaw)
		add_child(parent)
		var width := float(door.width)
		var height := float(door.height)
		var hinge := Node3D.new()
		hinge.name = "Hinge"
		var hinge_sign := -1.0 if str(door.hinge) == "left" else 1.0
		hinge.position.x = hinge_sign * width * 0.5
		if hold_route_doors_open:
			hinge.rotation.y = hinge_sign * PI * 0.5
		parent.add_child(hinge)
		var latch := Marker3D.new()
		latch.name = "Latch"
		latch.position = Vector3(-hinge_sign * width * 0.5, height * 0.5, 0.0)
		parent.add_child(latch)
		_box(hinge, "Leaf", Vector3(-hinge_sign * width * 0.5, height * 0.5, 0.0),
				Vector3(width, height, 0.045), "opening", not hold_route_doors_open)
		_box(parent, "FrameLeft", Vector3(-width * 0.5 - 0.045, height * 0.5, 0.0),
				Vector3(0.09, height, 0.10), "core", false)
		_box(parent, "FrameRight", Vector3(width * 0.5 + 0.045, height * 0.5, 0.0),
				Vector3(0.09, height, 0.10), "core", false)
		_box(parent, "FrameHead", Vector3(0.0, height + 0.045, 0.0),
				Vector3(width + 0.18, 0.09, 0.10), "core", false)

func _build_windows() -> void:
	for window: Dictionary in layout.get("windows", []):
		var parent := Node3D.new()
		parent.name = str(window.id)
		var y := float(level_y[window.level])
		parent.position = Vector3(float(window.center[0]), y, float(window.center[1]))
		add_child(parent)
		var width := float(window.width)
		var height := float(window.height)
		var sill := float(window.sill)
		var size := (Vector3(width, height, 0.025) if str(window.axis) == "x"
				else Vector3(0.025, height, width))
		_box(parent, "Glazing", Vector3(0.0, sill + height * 0.5, 0.0),
				size, "opening", false)
		var jamb_size := (Vector3(0.07, height, 0.10) if str(window.axis) == "x"
				else Vector3(0.10, height, 0.07))
		var offset_a := (Vector3(-width * 0.5, sill + height * 0.5, 0.0)
				if str(window.axis) == "x" else Vector3(0.0, sill + height * 0.5, -width * 0.5))
		var offset_b := -offset_a + Vector3(0.0, (sill + height * 0.5) * 2.0, 0.0)
		# The second expression above preserves the same Y while mirroring only plan offset.
		offset_b.y = offset_a.y
		_box(parent, "JambA", offset_a, jamb_size, "core", false)
		_box(parent, "JambB", offset_b, jamb_size, "core", false)

func _build_envelopes() -> void:
	for envelope: Dictionary in layout.get("envelopes", []):
		var rect: Array = envelope.rect
		var height := float(envelope.get("height", 0.02))
		var y := float(level_y[envelope.level])
		var node := _box(self, str(envelope.id), _rect_center(rect, y + height * 0.5),
				Vector3(_rect_w(rect), height, _rect_d(rect)),
				str(envelope.get("class", "unresolved")), false)
		node.set_meta("purpose", str(envelope.get("purpose", "")))
		node.set_meta("surface_role", "reservation_debug")
		node.visible = show_reservation_volumes

func _build_fixtures() -> void:
	for fixture: Dictionary in layout.get("fixtures", []):
		var p: Array = fixture.position
		var s: Array = fixture.size
		var node := _box(self, str(fixture.id), Vector3(float(p[0]),
				float(level_y[fixture.level]) + float(p[1]), float(p[2])),
				Vector3(float(s[0]), float(s[1]), float(s[2])),
				str(fixture.get("class", "unresolved")),
				bool(fixture.get("collision", true)))
		node.set_meta("purpose", str(fixture.get("purpose", "")))
		var family := str(fixture.get("fabrication",""))
		if not family.is_empty():
			node.set_meta("fabrication_part",str(fixture.get("fabrication_part","")))
			node.set_meta("fabrication_floor_y",float(level_y[fixture.level]))
			if not fabricated_fixtures.has(family): fabricated_fixtures[family]=[]
			fabricated_fixtures[family].append(node)

func _build_platforms() -> void:
	var slab_t := float(layout.dimensions.slab_thickness)
	var soffits:=preload("res://scripts/building/orison_v2_platform_soffits.gd")
	var ceiling_owners: Array[Dictionary]=soffits.ceiling_owners(layout,level_y,space_geometry_exclusions,show_ceilings)
	for platform: Dictionary in layout.get("platforms", []):
		var rect: Array = platform.rect
		var y := float(level_y[platform.level])
		var draw:=_box(self, str(platform.id), _rect_center(rect, y - slab_t * 0.5),
				Vector3(_rect_w(rect), slab_t, _rect_d(rect)),
				str(platform.get("class", "core")), true, "Floor")
		if production_materials:
			soffits.append(draw,platform,layout,level_y,ceiling_owners,architectural_materials.material_for("Ceiling",str(platform.get("class","core"))))

func _build_lift_landings() -> void:
	for landing: Dictionary in layout.get("lift_landings", []):
		var parent := Node3D.new()
		parent.name = str(landing.id)
		parent.position = Vector3(float(landing.center[0]), float(level_y[landing.level]),
				float(landing.center[1]))
		parent.rotation.y = float(landing.yaw)
		parent.set_meta("shaft", str(landing.shaft))
		add_child(parent)
		var width := float(landing.width)
		var height := float(landing.height)
		_box(parent, "JambL", Vector3(-width * 0.5 - 0.045, height * 0.5, 0.0),
				Vector3(0.09, height, 0.10), "core", false)
		_box(parent, "JambR", Vector3(width * 0.5 + 0.045, height * 0.5, 0.0),
				Vector3(0.09, height, 0.10), "core", false)
		_box(parent, "Head", Vector3(0.0, height + 0.045, 0.0),
				Vector3(width + 0.18, 0.09, 0.10), "core", false)
		var clearance := _box(parent, "Clearance", Vector3(0.0, 0.01, float(landing.clear_depth) * 0.5),
				Vector3(maxf(width, 1.5), 0.02, float(landing.clear_depth)),
				"clearance", false)
		clearance.set_meta("surface_role", "reservation_debug")
		clearance.visible = show_reservation_volumes

func _build_stairs() -> void:
	for stair: Dictionary in layout.stairs:
		var parent := Node3D.new()
		parent.name = str(stair.id)
		add_child(parent)
		if str(stair.get("kind", "")) == "u":
			_build_u_stair(parent, stair)

func _build_u_stair(parent: Node3D, stair: Dictionary) -> void:
	var base_y := float(level_y[stair.from])
	var rise := float(stair.rise)
	var tread := float(stair.tread)
	var count := int(stair.risers_per_flight)
	var width := float(stair.width)
	var gap := float(stair.gap)
	var x0 := float(stair.origin[0])
	var z0 := float(stair.origin[1])
	var run := tread * count
	var half_rise := rise * count
	var guard_h := float(stair.guard_height)
	# Bound each tread to one riser's thickness. Filling it down to base_y
	# creates a false low ceiling beneath the next stacked flight.
	for i in count:
		var step_h := rise * (i + 1)
		var z := z0 + tread * (i + 0.5)
		var step_a := _box(parent, "FlightA_Step%02d" % i,
				Vector3(x0 + width * 0.5, base_y + step_h - rise * 0.5, z),
				Vector3(width, rise, tread), "core", true)
		if production_materials: step_a.mesh = _dished_tread(Vector3(width, rise, tread), 1.0)
		var guard_a := _box(parent, "FlightA_Guard%02d" % i,
				Vector3(x0 + 0.025, base_y + step_h + guard_h * 0.5, z),
				Vector3(0.05, guard_h, tread), "core", false)
		guard_a.visible = not production_materials
	_ramp_collision(parent, "FlightATraversalRamp",
			Vector3(x0 + width * 0.5, base_y + half_rise * 0.5,
					z0 + run * 0.5), width, run, half_rise, -1.0)
	var landing_depth := float(stair.landing_depth)
	# A body needs clear standing room beyond the return flight's first nosing in
	# order to execute the U-turn; the semantic depth describes the clear landing.
	var turn_clearance := 0.7
	_box(parent, "HalfLanding",
			Vector3(x0 + width + gap * 0.5, base_y + half_rise - 0.1,
					z0 + run + (landing_depth + turn_clearance) * 0.5),
			Vector3(width * 2.0 + gap, 0.2, landing_depth + turn_clearance), "core", true)
	var landing_guard := _box(parent, "HalfLandingGuard",
			Vector3(x0 + width + gap * 0.5, base_y + half_rise + guard_h * 0.5,
					z0 + run + landing_depth + turn_clearance - 0.025),
			Vector3(width * 2.0 + gap, guard_h, 0.05), "core", false)
	landing_guard.visible = not production_materials
	var x_b := x0 + width + gap
	var north_start := z0 + run + landing_depth
	for i in count:
		var step_h := rise * (i + 1)
		var z := north_start - tread * (i + 0.5)
		var step_b := _box(parent, "FlightB_Step%02d" % i,
				Vector3(x_b + width * 0.5, base_y + half_rise + step_h - rise * 0.5, z),
				Vector3(width, rise, tread), "core", true)
		if production_materials: step_b.mesh = _dished_tread(Vector3(width, rise, tread), -1.0)
		var guard_b := _box(parent, "FlightB_Guard%02d" % i,
				Vector3(x_b + width - 0.025,
						base_y + half_rise + step_h + guard_h * 0.5, z),
				Vector3(0.05, guard_h, tread), "core", false)
		guard_b.visible = not production_materials
	_ramp_collision(parent, "FlightBTraversalRamp",
			Vector3(x_b + width * 0.5, base_y + half_rise + half_rise * 0.5,
					north_start - run * 0.5), width, run, half_rise, 1.0)
	if production_materials:
		var ironwork := preload("res://scripts/building/orison_v2_stair_ironwork.gd").new()
		if not ironwork.mount(parent,stair,base_y):
			failures.append("unsupported ironwork dimensions: "+str(stair.id))

## Dossier slice 50: inherited dishing on the honed treads. Only the visible top face
## dips, 5 mm at most, along the walking line and deepest just behind the nosing; it is
## zero at every edge so no face separates. Physics keeps the original full BoxShape3D.
## `travel` is +1 when the flight climbs toward +z (nosing at -z), -1 otherwise.
const TREAD_DISH := 0.005

func _tread_dip(x: float, z: float, size: Vector3, travel: float) -> float:
	var u := clampf(x / size.x + 0.5, 0.0, 1.0)
	var t := clampf((z * travel + size.z * 0.5) / size.z, 0.0, 1.0)
	var across := sin(PI * u) * exp(-pow((u - 0.5) / 0.24, 2.0))
	var along := pow(sin(PI * t), 0.8) * (1.25 - 0.5 * t)
	return TREAD_DISH * across * along

func _dished_tread(size: Vector3, travel: float) -> ArrayMesh:
	var box := BoxMesh.new()
	box.size = size
	box.subdivide_width = 16
	box.subdivide_depth = 6
	var arrays := box.surface_get_arrays(0)
	var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var normals: PackedVector3Array = arrays[Mesh.ARRAY_NORMAL]
	var e := 0.002
	for i in vertices.size():
		if normals[i].y < 0.9: continue
		var v := vertices[i]
		v.y -= _tread_dip(v.x, v.z, size, travel)
		vertices[i] = v
		var dx := (_tread_dip(v.x + e, v.z, size, travel) - _tread_dip(v.x - e, v.z, size, travel)) / (2.0 * e)
		var dz := (_tread_dip(v.x, v.z + e, size, travel) - _tread_dip(v.x, v.z - e, size, travel)) / (2.0 * e)
		normals[i] = Vector3(dx, 1.0, dz).normalized()
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh

func _ramp_collision(parent: Node3D, node_name: String, at: Vector3,
		width: float, run: float, rise: float, direction: float) -> void:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = at
	body.rotation.x = direction * atan2(rise, run)
	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(width - 0.04, 0.05, sqrt(run * run + rise * rise))
	shape_node.shape = shape
	body.add_child(shape_node)
	parent.add_child(body)

func _build_risers() -> void:
	for riser: Dictionary in layout.risers:
		var rect: Array = riser.rect
		var y0 := float(riser.from_y)
		var y1 := float(riser.to_y)
		var bounds := AABB(Vector3(rect[0],y0,rect[1]),Vector3(_rect_w(rect),y1-y0,_rect_d(rect)))
		var pieces: Array[AABB]=[bounds]
		for opening: Dictionary in layout.get("riser_openings",[]):
			if str(opening.riser)!=str(riser.id): continue
			var at: Array=opening.bounds
			var cut:=AABB(Vector3(at[0],at[1],at[2]),Vector3(at[3]-at[0],at[4]-at[1],at[5]-at[2]))
			var remaining: Array[AABB]=[]
			for piece: AABB in pieces: remaining.append_array(_subtract_box(piece,cut))
			pieces=remaining
		for window: Dictionary in layout.windows:
			if not _window_meets_riser(window,riser): continue
			var along_x := str(window.axis)=="x"
			var low := float(level_y[window.level])+float(window.sill)
			var cut := AABB(Vector3(float(window.center[0])-float(window.width)*.5,low,bounds.position.z),Vector3(float(window.width),float(window.height),bounds.size.z)) if along_x else AABB(Vector3(bounds.position.x,low,float(window.center[1])-float(window.width)*.5),Vector3(bounds.size.x,float(window.height),float(window.width)))
			var remaining: Array[AABB]=[]
			for piece: AABB in pieces: remaining.append_array(_subtract_box(piece,cut))
			pieces=remaining
		if pieces.size()!=1 or pieces[0]!=bounds:
			var parent := Node3D.new()
			parent.name=str(riser.id)
			add_child(parent)
			for i in pieces.size():
				_box(parent,"RevealSection%d" % i,pieces[i].get_center(),pieces[i].size,str(riser.get("class","service")),bool(riser.get("solid",true)))
			continue
		_box(self, str(riser.id), _rect_center(rect, (y0 + y1) * 0.5),
				Vector3(_rect_w(rect), y1 - y0, _rect_d(rect)),
				str(riser.get("class", "service")), bool(riser.get("solid", true)))

## Shaft/court windows must pass through the adjacent service chase as well
## as the room wall. Retain solid chase volume everywhere outside the aperture.
func _window_meets_riser(window: Dictionary,riser: Dictionary) -> bool:
	if not bool(riser.get("solid",true)): return false
	var rect: Array=riser.rect
	var along_x := str(window.axis)=="x"
	var fixed := float(window.center[1 if along_x else 0])
	var start := float(rect[1 if along_x else 0])
	var finish := float(rect[3 if along_x else 2])
	if fixed<start-.001 or fixed>finish+.001: return false
	var along := float(window.center[0 if along_x else 1])
	if along+float(window.width)*.5<=float(rect[0 if along_x else 1]) or along-float(window.width)*.5>=float(rect[2 if along_x else 3]): return false
	var low := float(level_y[window.level])+float(window.sill)
	return low<float(riser.to_y) and low+float(window.height)>float(riser.from_y)

func window_reveal_span(window: Dictionary) -> Vector2:
	var along_x := str(window.axis)=="x"
	var fixed := float(window.center[1 if along_x else 0])
	var half := float(layout.dimensions.partition_wall)*.5
	var span := Vector2(fixed-half,fixed+half)
	span=preload("res://scripts/generated/v2_exterior_masonry.gd").WINDOW_SPANS.get(str(window.id),span)
	for riser: Dictionary in layout.risers:
		if _window_meets_riser(window,riser):
			span.x=minf(span.x,float(riser.rect[1 if along_x else 0]))
			span.y=maxf(span.y,float(riser.rect[3 if along_x else 2]))
	return span

static func _subtract_box(box: AABB,cut: AABB) -> Array[AABB]:
	const CONSTRUCTION_EPS := .00001
	if minf(box.size.x,minf(box.size.y,box.size.z))<=CONSTRUCTION_EPS:return []
	if not box.intersects(cut): return [box]
	var overlap := box.intersection(cut)
	var result: Array[AABB]=[]
	var middle := box
	# Vector3 stores single-precision coordinates. Decimal owner boundaries
	# can otherwise leave sub-micrometre closing plates across a real opening.
	# Ten micrometres is below any authored construction detail; never emit
	# these numerical slivers as either visible boxes or collision shapes.
	for axis in 3:
		if overlap.position[axis]-middle.position[axis]>CONSTRUCTION_EPS:
			var low := middle
			low.size[axis]=overlap.position[axis]-middle.position[axis]
			result.append(low)
		if middle.end[axis]-overlap.end[axis]>CONSTRUCTION_EPS:
			var high := middle
			high.position[axis]=overlap.end[axis]
			high.size[axis]=middle.end[axis]-overlap.end[axis]
			result.append(high)
		middle.position[axis]=overlap.position[axis]
		middle.size[axis]=overlap.size[axis]
	# A tiny overlap on one axis becomes the middle for later axes. Testing
	# only the current split distance still emitted zero-width reveal pieces.
	var valid: Array[AABB]=[]
	for piece: AABB in result:
		if minf(piece.size.x,minf(piece.size.y,piece.size.z))>CONSTRUCTION_EPS:valid.append(piece)
	return valid

func _build_anchors() -> void:
	for anchor: Dictionary in layout.anchors:
		var node := SemanticAnchor.new()
		node.name = str(anchor.id)
		var p: Array = anchor.position
		node.position = Vector3(float(p[0]), float(level_y[anchor.level]) + float(p[1]),
				float(p[2]))
		node.rotation.y = float(anchor.get("yaw", 0.0))
		node.set_meta("anchor_kind", str(anchor.kind))
		add_child(node)
		if show_clearance_anchors and str(anchor.kind) in ["interaction", "clearance"]:
			_box(node, "Envelope", Vector3(0.0, 0.01, 0.0), Vector3(0.9, 0.02, 0.9),
					"interaction" if str(anchor.kind) == "interaction" else "clearance", false)

## All wet-room pieces and continuous wet chases share building grout courses.
## Other architectural charts retain their local, precision-preserving origin.
func _architectural_chart(mesh: Mesh, parent: Node, at: Vector3, cls: String) -> ArrayMesh:
	var origin := Vector3.ZERO
	if cls == "wet":
		origin = at
	return preload("res://scripts/building/v2_metre_box_uv.gd").chart(mesh,origin)

func _box(parent: Node, node_name: String, at: Vector3, size: Vector3,
		material_key: String, collision: bool, slab_part: String = "") -> MeshInstance3D:
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh.material = materials.get(material_key, materials.get("unresolved"))
	mesh_node.mesh = mesh
	# Adjacent storeys share slab volume, but never a render face. A full
	# lower ceiling box put its top exactly on the next floor's walking plane.
	var part := slab_part if not slab_part.is_empty() else node_name
	if production_materials and part.begins_with("Wall"):
		# Solid partitions must occlude from either side even when a nearby
		# ceiling fixture reverses shadow culling to suit the slab underside.
		# Otherwise its far wall face leaves a bright line at the ceiling joint.
		mesh_node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_DOUBLE_SIDED
	if production_materials and part in ["Floor","Ceiling"]:
		mesh_node.mesh=_slab_faces(mesh,part=="Floor")
	if production_materials and (part in ["Floor","Ceiling"] or part.begins_with("Wall") or material_key=="wet"):
		mesh_node.mesh=_architectural_chart(mesh_node.mesh,parent,at,material_key)
	if production_materials and material_key not in ["clearance", "interaction", "unresolved"]:
		mesh_node.material_override = architectural_materials.material_for(node_name,material_key)
		mesh_node.set_meta("v2_material_key",architectural_materials.key_for(node_name,material_key))
	mesh_node.position = at
	parent.add_child(mesh_node)
	if collision:
		var body := StaticBody3D.new()
		body.name = "Collision"
		var shape_node := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		shape_node.shape = shape
		body.add_child(shape_node)
		mesh_node.add_child(body)
	return mesh_node

## Keep BoxMesh UVs, normals and tangents; change only face ownership. Physics
## remains the original full BoxShape3D. Review-only blockouts retain their boxes.
func _slab_faces(box: BoxMesh, floor_surface: bool) -> ArrayMesh:
	var arrays := box.surface_get_arrays(0)
	var normals: PackedVector3Array=arrays[Mesh.ARRAY_NORMAL]
	var original: PackedInt32Array=arrays[Mesh.ARRAY_INDEX]
	var indices := PackedInt32Array()
	for start in range(0,original.size(),3):
		var underside := normals[original[start]].y < -.9
		if underside==floor_surface: continue
		for offset in range(3): indices.append(original[start+offset])
	arrays[Mesh.ARRAY_INDEX]=indices
	var result := ArrayMesh.new()
	result.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays)
	result.surface_set_material(0,box.material)
	return result

func _rect_center(rect: Array, y: float) -> Vector3:
	return Vector3((float(rect[0]) + float(rect[2])) * 0.5, y,
			(float(rect[1]) + float(rect[3])) * 0.5)

func _rect_w(rect: Array) -> float:
	return float(rect[2]) - float(rect[0])

func _rect_d(rect: Array) -> float:
	return float(rect[3]) - float(rect[1])
