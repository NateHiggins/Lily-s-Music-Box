extends Node3D
## INERT actual shell architecture stock; no gameplay acceptance.
func _ready() -> void:call_deferred("_run")
func _run() -> void:
	var shell:=preload("res://scripts/building/orison_v2_blockout.gd").new()
	shell.production_materials=true;shell.show_clearance_anchors=false;shell.show_reservation_volumes=false
	add_child(shell)
	preload("res://scripts/building/orison_v2_bathroom_finishes.gd").build(shell,shell.layout,shell.level_y,shell.architectural_materials,preload("res://scripts/building/orison_v2_millwork.gd").collect_wall_stock(shell))
	var metric:=preload("res://tests/orison_v2_roof_bulkhead_caps_test.gd").new()
	var count:=0
	var bad: Array=[]
	for draw: MeshInstance3D in shell.find_children("Bathroom*","MeshInstance3D",true,false):
		metric._check_cap_mapping(draw.mesh,true);count+=1
		var arrays:=draw.mesh.surface_get_arrays(0)
		var vertices: PackedVector3Array=arrays[Mesh.ARRAY_VERTEX];var uv: PackedVector2Array=arrays[Mesh.ARRAY_TEX_UV];var normals: PackedVector3Array=arrays[Mesh.ARRAY_NORMAL];var tangents: PackedFloat32Array=arrays[Mesh.ARRAY_TANGENT];var indices: PackedInt32Array=arrays[Mesh.ARRAY_INDEX]
		for offset in range(0,indices.size(),3):
			var a:=indices[offset];var b:=indices[offset+1];var c:=indices[offset+2]
			if absf((uv[b]-uv[a]).cross(uv[c]-uv[a]))<=1e-12:
				bad.append({"path":str(draw.get_path()),"points":[vertices[a],vertices[b],vertices[c]],"uv":[uv[a],uv[b],uv[c]],"normals":[normals[a],normals[b],normals[c]],"tangents":[tangents.slice(a*4,a*4+4),tangents.slice(b*4,b*4+4),tangents.slice(c*4,c*4+4)]})
	var source:=preload("res://assets/props/bath_shower.glb").instantiate()
	var native:=0
	for draw: MeshInstance3D in source.find_children("*","MeshInstance3D",true,false):
		metric._check_cap_mapping(draw.mesh,true);native+=1
	source.free()
	metric.check(native==19,"all nineteen native shower material stocks pass imported UV and basis checks")
	metric.check(count==38,"all nineteen wet rooms contain both fixed finish batches")
	var output:=OS.get_environment("SHOT_DIR");DirAccess.make_dir_recursive_absolute(output)
	FileAccess.open(output.path_join("stock.json"),FileAccess.WRITE).store_string(JSON.stringify({"evidence_class":"INERT","scope":"Static original shell finish stock, no interactions/runtime qualification","draws":count,"bad":bad,"failures":metric.failures},"\t"))
	print("BATH FINISH STOCK: ",count," draws; ",metric.failures.size()," failures")
	var failed: bool=not metric.failures.is_empty()
	metric.free();shell.free();get_tree().quit(1 if failed else 0)
