extends RefCounted
## Static room-facing tile and narrow mortar joints on actual cut wall stock.
## Original wall meshes, collision owners, openings and door mechanisms remain.
const Millwork=preload("res://scripts/building/orison_v2_millwork.gd")
const WAINSCOT:=1.22
const SHOWER_HEIGHT:=2.13
const SKIN:=.0045
const BEAD:=.003

static func build(shell: Node3D,layout: Dictionary,levels: Dictionary,materials: RefCounted,stock: Array[Dictionary]) -> void:
	for record: Dictionary in layout.spaces:
		if record.get("class","")!="wet" or record.get("open_shell",false):continue
		var room:=shell.get_node_or_null(str(record.id)) as Node3D
		if room==null:continue
		var floor_y: float=levels[str(record.level)]
		var faces:=Millwork._room_wall_faces(record,Millwork.wall_stock_for_band(stock,floor_y,floor_y+float(layout.dimensions.clear_height)),float(layout.dimensions.partition_wall))
		var shower_boxes: Array[AABB]=[]
		for anchor: Dictionary in layout.anchors:
			if str(anchor.get("space",""))==str(record.id) and "SHOWER" in str(anchor.id) and not "STANCE" in str(anchor.id):
				var at:=Vector3(anchor.position[0],floor_y,anchor.position[2])
				shower_boxes.append(AABB(at-Vector3(.46,0,.46),Vector3(.92,SHOWER_HEIGHT,.92)))
		var tiles:=SurfaceTool.new();tiles.begin(Mesh.PRIMITIVE_TRIANGLES)
		var grout:=SurfaceTool.new();grout.begin(Mesh.PRIMITIVE_TRIANGLES)
		var patches: Array=[];var joints: Array=[];var corners: Dictionary={}
		for face: Dictionary in faces:
			# End-grain/reveal faces stay plaster: tile belongs to room wall planes.
			var source_x: bool="WallNorth" in str(face.source) or "WallSouth" in str(face.source)
			if source_x!=bool(face.along_x):continue
			var low:=maxf(floor_y,float(face.low));var high:=minf(floor_y+WAINSCOT,float(face.high))
			var sections: Array[Rect2]=[]
			if high-low>.001:sections.append(Rect2(float(face.start),low,float(face.finish)-float(face.start),high-low))
			var tall: Array[Vector2]=[]
			for box: AABB in shower_boxes:
				var fixed_low: float=box.position.z if face.along_x else box.position.x
				var fixed_high: float=box.end.z if face.along_x else box.end.x
				if float(face.face)<fixed_low or float(face.face)>fixed_high:continue
				var start:=maxf(float(face.start),box.position.x if face.along_x else box.position.z)
				var finish:=minf(float(face.finish),box.end.x if face.along_x else box.end.z)
				var bottom:=maxf(floor_y+WAINSCOT,float(face.low));var top:=minf(floor_y+SHOWER_HEIGHT,float(face.high))
				if finish-start>.001 and top-bottom>.001:sections.append(Rect2(start,bottom,finish-start,top-bottom));tall.append(Vector2(start,finish))
			var normal:=Vector3(0,0,float(face.inward)) if face.along_x else Vector3(float(face.inward),0,0)
			for section: Rect2 in sections:
				var a:=_point(face,section.position.x,section.position.y)+normal*SKIN
				var b:=_point(face,section.end.x,section.position.y)+normal*SKIN
				var c:=_point(face,section.end.x,section.end.y)+normal*SKIN
				var d:=_point(face,section.position.x,section.end.y)+normal*SKIN
				_quad(tiles,a,b,c,d,normal)
				patches.append({"source":face.source,"along_x":face.along_x,"plane":face.face,"inward":face.inward,"rect":[section.position.x,section.position.y,section.end.x,section.end.y]})
				# Close exposed tile top; no cap crosses a tall shower continuation.
				var caps: Array[Vector2]=[Vector2(section.position.x,section.end.x)]
				if absf(section.end.y-floor_y-WAINSCOT)<.001:
					for cut: Vector2 in tall:caps=_subtract(caps,cut)
				for cap: Vector2 in caps:
					var left:=_point(face,cap.x,section.end.y);var right:=_point(face,cap.y,section.end.y)
					_quad(tiles,left,right,right+normal*SKIN,left+normal*SKIN,Vector3.UP)
			if float(face.low)<=floor_y+.001 and float(face.high)>floor_y+.01:
				var a:=_point(face,float(face.start),floor_y)+normal*SKIN
				var b:=_point(face,float(face.finish),floor_y)+normal*SKIN
				_bead(grout,a,b,normal,Vector3.UP)
				joints.append({"kind":"floor","a":a,"b":b,"source":face.source})
			# Only actual perpendicular wall pairs create vertical room joints.
			for other: Dictionary in faces:
				if bool(face.along_x)==bool(other.along_x):continue
				var at: float=other.face
				if minf(absf(at-float(face.start)),absf(at-float(face.finish)))>.001:continue
				if float(face.face)<float(other.start)-.001 or float(face.face)>float(other.finish)+.001:continue
				var bottom:=maxf(floor_y,maxf(float(face.low),float(other.low)))
				var top:=minf(floor_y+WAINSCOT,minf(float(face.high),float(other.high)))
				var foot:=_point(face,at,floor_y)
				for box: AABB in shower_boxes:
					if box.grow(.01).has_point(foot+Vector3.UP*.01):top=minf(floor_y+SHOWER_HEIGHT,minf(float(face.high),float(other.high)))
				var key: String="%.4f:%.4f:%.4f:%.4f"%[foot.x,foot.z,bottom,top]
				if top-bottom<.001 or corners.has(key):continue
				corners[key]=true
				var second:=Vector3(0,0,float(other.inward)) if other.along_x else Vector3(float(other.inward),0,0)
				var a:=_point(face,at,bottom)+(normal+second)*SKIN
				var b:=Vector3(a.x,top,a.z)
				_bead(grout,a,b,normal,second);joints.append({"kind":"corner","a":a,"b":b,"source":face.source,"other":other.source})
		_emit(room,"BathroomTileWainscot",tiles,materials.material_for("BathroomTileWainscot","wet"),patches)
		_emit(room,"BathroomGroutJoints",grout,MatLib.get_mat("arcade_lime_mortar"),joints)

static func _point(face: Dictionary,along: float,y: float) -> Vector3:
	return Vector3(along,y,float(face.face)) if face.along_x else Vector3(float(face.face),y,along)

static func _subtract(spans: Array[Vector2],cut: Vector2) -> Array[Vector2]:
	var result: Array[Vector2]=[]
	for span: Vector2 in spans:
		if cut.y<=span.x or cut.x>=span.y:result.append(span);continue
		if cut.x>span.x:result.append(Vector2(span.x,cut.x))
		if cut.y<span.y:result.append(Vector2(cut.y,span.y))
	return result

static func _quad(surface: SurfaceTool,a: Vector3,b: Vector3,c: Vector3,d: Vector3,normal: Vector3) -> void:
	var chart_u: Vector3=(b-a).normalized()
	_triangle(surface,a,b,c,normal,chart_u);_triangle(surface,a,c,d,normal,chart_u)

static func _triangle(surface: SurfaceTool,a: Vector3,b: Vector3,c: Vector3,normal: Vector3,chart_u: Vector3=Vector3.ZERO) -> void:
	if (b-a).cross(c-a).dot(normal)>0.0:
		var swap:=b
		b=c;c=swap
	var u: Vector3=(b-a).normalized() if chart_u==Vector3.ZERO else chart_u
	var v:=normal.cross(u)
	for point: Vector3 in [a,b,c]:
		surface.set_normal(normal);surface.set_uv(Vector2(point.dot(u),point.dot(v)));surface.add_vertex(point)

static func _bead(surface: SurfaceTool,a: Vector3,b: Vector3,first: Vector3,second: Vector3) -> void:
	for index in 4:
		var angle:=float(index)*PI/8.0;var next:=float(index+1)*PI/8.0
		var p: Vector3=(first*cos(angle)+second*sin(angle))*BEAD
		var q: Vector3=(first*cos(next)+second*sin(next))*BEAD
		var normal: Vector3=(p+q).normalized()
		_quad(surface,a+p,b+p,b+q,a+q,normal)
	var direction: Vector3=(b-a).normalized()
	for end: Vector3 in [a,b]:
		for index in 4:
			var p: Vector3=(first*cos(float(index)*PI/8.0)+second*sin(float(index)*PI/8.0))*BEAD
			var q: Vector3=(first*cos(float(index+1)*PI/8.0)+second*sin(float(index+1)*PI/8.0))*BEAD
			_triangle(surface,end,end+p,end+q,-direction if end==a else direction)

static func _emit(room: Node3D,label: String,surface: SurfaceTool,material: Material,records: Array) -> void:
	if records.is_empty():return
	surface.generate_tangents()
	var draw:=MeshInstance3D.new();draw.name=label;draw.mesh=surface.commit();draw.material_override=material
	draw.set_meta("finish_records",records);room.add_child(draw)
