extends RefCounted
## Conservative swept shell cells derived from the actual imported skin.
## Keeps the bore open. Covers linear travel of the skinned vertices between
## endpoint poses, not arbitrary rigid rotation arcs or cloth self-contact.
const RESPONSE_CLEARANCE_M:=.0001
var rig: RefCounted
var sections: Array[Dictionary]=[]
var exclusions: Array[RID]=[]
var space: PhysicsDirectSpaceState3D
var ready:=false
var error:=""
var broad_queries:=0
var shell_queries:=0
var chunked:=true
var analytic_boxes:=false
var capsule_broadphase:=false
var capsule_queries:=0
var capsule_clears:=0
var _capsule:=CapsuleShape3D.new()
var _capsule_query:=PhysicsShapeQueryParameters3D.new()
var analytic_segments:=0
var _box_support:=preload("res://scripts/props/native_hose_box_support.gd").new()
var last_collider: Object
var _radius:=0.0
var _box:=BoxShape3D.new()
var _shell:=ConvexPolygonShape3D.new()
var _query:=PhysicsShapeQueryParameters3D.new()
var _response_planes: Array[Dictionary]=[]
var _response_valid:=false
var _response_truncated:=false
var _response_limit:=128
var _response_error:=""
func _fail(message: String) -> bool:
	error=message;return false
func set_exclusions(exclude: Array[RID]) -> void:
	exclusions=exclude.duplicate()
	_query.exclude=exclusions;_capsule_query.exclude=exclusions
func floor_supports(points: PackedVector3Array,source: Dictionary) -> Array[Dictionary]:
	var result: Array[Dictionary]=[]
	if not ready or not source.has_all(["normal","surface","rid"]):return result
	var world: Transform3D=rig.model.global_transform
	var normal: Vector3=(world.basis.inverse().transposed()*source.normal).normalized()
	if normal.dot(Vector3.UP)<.999:return result
	var frames: Array[Transform3D]=rig.model_frames(points)
	if frames.size()!=sections.size():return result
	for ring in points.size():
		var foot: Vector3=world*(points[ring]+source.normal*(source.surface-source.normal.dot(points[ring])))
		var ray:=PhysicsRayQueryParameters3D.create(foot+normal*.1,foot-normal*.1,1,exclusions)
		var hit: Dictionary=space.intersect_ray(ray)
		# A matching plane is not an infinite floor: retain the actual footprint,
		# holes and intervening bodies using a fresh query on the same collider.
		if hit.is_empty() or hit.rid!=source.rid or hit.normal.dot(normal)<.999 or absf(normal.dot(hit.position-foot))>.0001:continue
		var plane: Dictionary=_contact_plane(ring,frames[ring],world,{"normal":hit.normal,"point":hit.position,"rid":hit.rid},false)
		if not plane.is_empty():result.append(plane)
	return result
func configure(owner_rig: RefCounted,world: PhysicsDirectSpaceState3D,exclude: Array[RID]) -> bool:
	if ready or owner_rig==null or not owner_rig.configured:return _fail("unconfigured or already bound hose")
	rig=owner_rig;space=world;exclusions=exclude.duplicate()
	_box.margin=.000001;_shell.margin=.000001;_query.margin=0.
	_query.collision_mask=1;_query.collide_with_areas=false;_query.exclude=exclusions
	_capsule_query.collision_mask=1;_capsule_query.collide_with_areas=false;_capsule_query.exclude=exclusions
	_capsule_query.margin=0.;_capsule_query.shape=_capsule
	var draws: Array[Node]=rig.model.find_children("*","MeshInstance3D",true,false)
	if draws.size()!=1:return _fail("expected one native cloth skin")
	var draw: MeshInstance3D=draws[0]
	if draw.skin==null or draw.mesh.get_surface_count()!=1:return _fail("missing native skin")
	var groups: Array[Dictionary]=[]
	for i in rig.indices.size():groups.append({})
	var bind_ring:=PackedInt32Array();bind_ring.resize(draw.skin.get_bind_count());bind_ring.fill(-1)
	for i in bind_ring.size():
		var name: StringName=draw.skin.get_bind_name(i)
		var bone: int=rig.skeleton.find_bone(str(name)) if not name.is_empty() else draw.skin.get_bind_bone(i)
		bind_ring[i]=rig.indices.find(bone)
	var arrays: Array=draw.mesh.surface_get_arrays(0)
	var vertices: PackedVector3Array=arrays[Mesh.ARRAY_VERTEX]
	var bones: PackedInt32Array=arrays[Mesh.ARRAY_BONES]
	var weights: PackedFloat32Array=arrays[Mesh.ARRAY_WEIGHTS]
	if vertices.is_empty() or bones.size()!=weights.size() or bones.size()%vertices.size()!=0:return _fail("invalid native weights")
	var slots: int=bones.size()/vertices.size()
	var into_model: Transform3D=rig.model.global_transform.affine_inverse()*draw.global_transform
	for i in vertices.size():
		var ring: int=-1;var influences:=0
		for slot in slots:
			var at: int=i*slots+slot
			if weights[at]<=.000001:continue
			if absf(weights[at]-1.)>.000001 or bones[at]<0 or bones[at]>=bind_ring.size():return _fail("cloth is not single-ring weighted")
			ring=bind_ring[bones[at]];influences+=1
		if influences!=1 or ring<0:return _fail("unmapped ring influence")
		var point: Vector3=rig.original_frames[ring].affine_inverse()*(into_model*vertices[i])
		if not point.is_finite() or absf(point.y)>.000002:return _fail("imported ring is not in its native plane")
		groups[ring][point]=true
	for ring in groups.size():
		var points: Array=groups[ring].keys()
		if points.size()!=64:return _fail("expected64actual inner/outer section vertices: "+str([ring,points.size()]))
		var radii:=Vector2.ZERO
		for p: Vector3 in points:radii=radii.max(Vector2(absf(p.x),absf(p.z)))
		if radii.x<=0. or radii.y<=0.:return _fail("collapsed native section")
		var outer: Array[Vector3]=[];var inner: Array[Vector3]=[]
		for p: Vector3 in points:
			if Vector2(p.x/radii.x,p.z/radii.y).length()>.9999:outer.append(p)
			else:inner.append(p)
		if outer.size()!=32 or inner.size()!=32:return _fail("invalid annular native section: "+str(ring))
		var inner_radii:=Vector2.ZERO
		for p: Vector3 in inner:inner_radii=inner_radii.max(Vector2(absf(p.x),absf(p.z)))
		var sorted_outer:=PackedVector3Array();var sorted_inner:=PackedVector3Array();sorted_outer.resize(32);sorted_inner.resize(32)
		var seen: Dictionary={}
		for p: Vector3 in outer:
			var index: int=posmod(roundi(atan2(p.z/radii.y,p.x/radii.x)*32./TAU),32)
			if seen.has(index):return _fail("duplicate native outer angle")
			seen[index]=true;sorted_outer[index]=p
		seen.clear()
		for p: Vector3 in inner:
			var index: int=posmod(roundi(atan2(p.z/inner_radii.y,p.x/inner_radii.x)*32./TAU),32)
			if seen.has(index):return _fail("duplicate native inner angle")
			seen[index]=true;sorted_inner[index]=p
		var bounds:=AABB(points[0],Vector3.ZERO)
		for p: Vector3 in points:
			bounds=bounds.expand(p);_radius=maxf(_radius,(rig.original_frames[ring].basis*p).length())
		var section_radius:=0.
		for point: Vector3 in points:section_radius=maxf(section_radius,point.length())
		sections.append({"outer":sorted_outer,"inner":sorted_inner,"bounds":bounds,"radius":section_radius})
	ready=sections.size()==rig.indices.size()
	return ready
func _hits_box(bounds: AABB) -> bool:
	_box.size=Vector3(maxf(bounds.size.x,.000002),maxf(bounds.size.y,.000002),maxf(bounds.size.z,.000002))
	_query.shape=_box;_query.transform=Transform3D(Basis.IDENTITY,bounds.get_center())
	return not space.intersect_shape(_query,1).is_empty()

func _basis_radius_bound(basis: Basis) -> float:
	# Largest absolute row sum of B'B bounds its largest eigenvalue. This
	# remains conservative for nonuniform scale and shear, not only rotations.
	var xy:=absf(basis.x.dot(basis.y));var xz:=absf(basis.x.dot(basis.z));var yz:=absf(basis.y.dot(basis.z))
	return sqrt(maxf(basis.x.length_squared()+xy+xz,maxf(basis.y.length_squared()+xy+yz,basis.z.length_squared()+xz+yz)))

func _capsule_sweep_clear(world: Transform3D,old: Array[Transform3D],next: Array[Transform3D],index: int) -> bool:
	var a: Vector3=world*old[index].origin;var b: Vector3=world*old[index+1].origin
	var c: Vector3=world*next[index].origin;var d: Vector3=world*next[index+1].origin
	var length: float=a.distance_to(b)
	if length<.000001:return false
	var radius:=0.
	for ring: int in [index,index+1]:
		for pose: Transform3D in [old[ring],next[ring]]:
			radius=maxf(radius,float(sections[ring].radius)*_basis_radius_bound(world.basis*pose.basis))
	# Every intermediate centreline lies within max endpoint displacement of
	# the old segment. Each native vertex lies within the section radius.
	# A clear envelope therefore proves the entire swept native shell clear.
	radius+=maxf(a.distance_to(c),b.distance_to(d))+.00002
	if not is_finite(radius) or not is_finite(length+2.*radius) or not a.is_finite() or not b.is_finite() or not c.is_finite() or not d.is_finite():return false
	_capsule.radius=radius;_capsule.height=length+2.*radius
	var y: Vector3=(b-a)/length
	var reference:=Vector3.RIGHT if absf(y.dot(Vector3.UP))>.95 else Vector3.UP
	var x: Vector3=reference.cross(y).normalized()
	_capsule_query.transform=Transform3D(Basis(x,y,x.cross(y)),(a+b)*.5)
	capsule_queries+=1
	var clear: bool=space.intersect_shape(_capsule_query,1).is_empty()
	if clear:capsule_clears+=1
	return clear
func veto(before: PackedVector3Array,after: PackedVector3Array) -> bool:return _test(before,after,false)
func intersects_pose(points: PackedVector3Array) -> bool:return _test(points,points,true)
func contact_constraints(points: PackedVector3Array,limit: int=128) -> Dictionary:
	# Native shell contacts supply tangent half-spaces for the response solver.
	# These are local contact constraints, not a replacement collision test.
	_response_limit=clampi(limit,1,4096)
	_test(points,points,true,true)
	return {"valid":_response_valid,"truncated":_response_truncated,"planes":_response_planes.duplicate(true),"error":_response_error}
func motion_constraints(before: PackedVector3Array,after: PackedVector3Array,limit: int=128) -> Dictionary:
	_response_limit=clampi(limit,1,4096)
	var blocked: bool=_test(before,after,true,true)
	return {"valid":_response_valid,"truncated":_response_truncated,"planes":_response_planes.duplicate(true),"error":_response_error,"sweep_clear":not blocked and _response_valid and not _response_truncated}
func _cell_hull(posed: Array[PackedVector3Array],sector: int,origin: Vector3,fraction: float) -> PackedVector3Array:
	var hull:=PackedVector3Array()
	for row in 4:
		for index in [sector,(sector+1)%32,sector+32,(sector+1)%32+32]:
			var p: Vector3=posed[row][index]
			if row>=2:p=posed[row-2][index].lerp(p,fraction)
			hull.append(p-origin)
	return hull
func _contact_plane(ring: int,frame: Transform3D,world: Transform3D,info: Dictionary,refine: bool=true) -> Dictionary:
	if info.is_empty():return {}
	var normal: Vector3=info.normal
	var point: Vector3=info.point
	if not normal.is_finite() or not point.is_finite() or normal.length_squared()<.99:return {}
	# Refine the manifold's approximate normal on the actual collider surface.
	# Nearly parallel numerical normals must not pin three degrees of freedom
	# on what is physically one flat floor. Retain the manifold if the local
	# ray does not hit that same body or describes a different-facing surface.
	var ray:=PhysicsRayQueryParameters3D.create(point+normal*.005,point-normal*.005,1,exclusions)
	var hit: Dictionary=space.intersect_ray(ray) if refine else {}
	if not hit.is_empty() and hit.rid==info.rid and normal.dot(hit.normal)>.9:
		normal=hit.normal;point=hit.position
	var local: Vector3=world.basis.transposed()*normal
	var scale: float=local.length()
	if not is_finite(scale) or scale<.000001:return {}
	local/=scale
	var surface: float=(normal.dot(point)-normal.dot(world.origin))/scale
	var support:=INF
	for p: Vector3 in sections[ring].outer:support=minf(support,local.dot(frame.basis*p))
	# A0.1mm stand-off prevents resting contact chatter. This moves cloth away
	# from the obstacle; narrow/swept collision margins remain at1micrometre.
	return {"ring":ring,"normal":local,"offset":surface-support+RESPONSE_CLEARANCE_M/scale,"rid":info.rid,"surface":surface,"clearance":RESPONSE_CLEARANCE_M/scale}
func remember_support(records: Array,plane: Dictionary) -> bool:
	if not plane.has_all(["ring","normal","surface","clearance","rid"]):return false
	var ring: int=plane.ring
	var normal: Vector3=plane.normal
	if ring<0 or ring>=sections.size() or not normal.is_finite() or absf(normal.length_squared()-1.)>.000001:return false
	if not is_finite(plane.surface) or not is_finite(plane.clearance) or plane.clearance<=0.:return false
	for old: Dictionary in records:
		if old.ring==ring and old.rid==plane.rid and (old.normal-normal).length_squared()<1e-14 and absf(old.surface-plane.surface)<.000002:
			old.surface=maxf(old.surface,plane.surface);return true
	records.append(plane.duplicate());return true
func reframe_support(records: Array,points: PackedVector3Array) -> Dictionary:
	var planes: Dictionary={}
	if records.is_empty():return {"valid":true,"planes":planes}
	var frames: Array[Transform3D]=rig.model_frames(points)
	if frames.size()!=sections.size():return {"valid":false,"planes":{}}
	for plane: Dictionary in records:
		var ring: int=plane.ring
		var support:=INF
		for point: Vector3 in sections[ring].outer:support=minf(support,plane.normal.dot(frames[ring].basis*point))
		var offset: float=plane.surface-support+plane.clearance
		if not is_finite(offset):return {"valid":false,"planes":{}}
		if not planes.has(ring):planes[ring]=[]
		var merged:=false
		for old: Dictionary in planes[ring]:
			if (old.normal-plane.normal).length_squared()<1e-14:
				old.offset=maxf(old.offset,offset);merged=true;break
		if not merged:planes[ring].append({"normal":plane.normal,"offset":offset})
	return {"valid":true,"planes":planes}
func _test(before: PackedVector3Array,after: PackedVector3Array,include_still: bool,collect: bool=false) -> bool:
	broad_queries=0;shell_queries=0;last_collider=null
	analytic_segments=0
	if analytic_boxes:_box_support.begin_test()
	_response_planes.clear();_response_valid=false;_response_truncated=false
	_response_error=""
	if not ready or before.size()!=sections.size() or after.size()!=sections.size():return true
	var moving: bool=before!=after
	var world: Transform3D=rig.model.global_transform
	var whole:=AABB(before[0],Vector3.ZERO)
	for i in before.size():
		if not before[i].is_finite() or not after[i].is_finite():_response_error="nonfinite native coordinate";return true
		var a: Vector3=before[mini(i+1,before.size()-1)]-before[maxi(i-1,0)]
		var b: Vector3=after[mini(i+1,after.size()-1)]-after[maxi(i-1,0)]
		if not is_finite(a.length_squared()) or not is_finite(b.length_squared()) or a.length_squared()<1e-14 or b.length_squared()<1e-14:
			_response_error="collapsed native tangent at ring "+str(i);return true
		whole=whole.expand(before[i]).expand(after[i])
	_response_valid=true
	broad_queries+=1
	if not _hits_box(world*whole.grow(_radius+.000002)):return false
	var old: Array[Transform3D]=rig.model_frames(before);var next: Array[Transform3D]=rig.model_frames(after)
	if old.is_empty() or next.is_empty():_response_valid=false;return true
	# Chunk bounds avoid thousands of native shape queries on long, clear
	# spans. Every occupied chunk still gets the original per-cell narrow test.
	var bounds_by_segment: Array[AABB]=[];bounds_by_segment.resize(sections.size()-1)
	var old_bounds_by_segment: Array[AABB]=[];old_bounds_by_segment.resize(sections.size()-1)
	var next_bounds_by_segment: Array[AABB]=[];next_bounds_by_segment.resize(sections.size()-1)
	var occupied:=PackedByteArray();occupied.resize(sections.size()-1);occupied.fill(0)
	for start in range(0,sections.size()-1,32):
		var chunk:=AABB(world*old[start].origin,Vector3.ZERO)
		for i in range(start,mini(start+32,sections.size()-1)):
			var bounds: AABB=(world*old[i])*sections[i].bounds
			bounds=bounds.merge((world*old[i+1])*sections[i+1].bounds)
			if analytic_boxes:old_bounds_by_segment[i]=bounds
			var first: AABB=(world*next[i])*sections[i].bounds
			var second: AABB=(world*next[i+1])*sections[i+1].bounds
			if analytic_boxes:next_bounds_by_segment[i]=first.merge(second)
			bounds=bounds.merge(first).merge(second)
			bounds_by_segment[i]=bounds;chunk=chunk.merge(bounds)
		if chunked:broad_queries+=1
		if not chunked or _hits_box(chunk.grow(.000002)):
			for i in range(start,mini(start+32,sections.size()-1)):occupied[i]=1
	for i in range(sections.size()-1):
		if occupied[i]==0:continue
		if not include_still and old[i]==next[i] and old[i+1]==next[i+1]:continue
		if capsule_broadphase and _capsule_sweep_clear(world,old,next,i):continue
		var bounds: AABB=bounds_by_segment[i]
		broad_queries+=1
		if not _hits_box(bounds.grow(.000002)):continue
		if analytic_boxes:
			# _hits_box left the same conservative broad-phase box in _query.
			var broad_hits: Array[Dictionary]=space.intersect_shape(_query,65)
			var shortcut: Dictionary=_box_support.segment(self,broad_hits,bounds,old_bounds_by_segment[i],next_bounds_by_segment[i],world,old,next,i)
			if shortcut.handled:
				analytic_segments+=1
				if shortcut.planes.is_empty():continue
				last_collider=shortcut.collider
				if not collect:return true
				for plane: Dictionary in shortcut.planes:
					_response_planes.append(plane)
					if _response_planes.size()>=_response_limit:_response_truncated=true;return true
				continue
		var posed: Array[PackedVector3Array]=[]
		for frame: Transform3D in [world*old[i],world*old[i+1],world*next[i],world*next[i+1]]:
			var index: int=i if posed.size()%2==0 else i+1
			var points:=PackedVector3Array()
			for layer: String in ["outer","inner"]:
				for p: Vector3 in sections[index][layer]:
					points.append(frame*p)
			posed.append(points)
		var origin: Vector3=bounds.get_center()
		for sector in 32:
			_shell.points=_cell_hull(posed,sector,origin,1.);_query.shape=_shell;_query.transform=Transform3D(Basis.IDENTITY,origin)
			shell_queries+=1
			var hits: Array[Dictionary]=space.intersect_shape(_query,1)
			if hits.is_empty():continue
			last_collider=hits[0].collider
			if not collect:return true
			var contact_fraction:=1.
			if moving:
				# Locate first contact on the conservative linear-vertex sweep.
				# A final-pose manifold can report the underside of a thin wall
				# after tunnelling, giving the response solver the wrong normal.
				var low:=0.;var high:=1.
				for refinement in 14:
					var middle: float=(low+high)*.5
					_shell.points=_cell_hull(posed,sector,origin,middle)
					if space.intersect_shape(_query,1).is_empty():low=middle
					else:high=middle
				contact_fraction=high
				_shell.points=_cell_hull(posed,sector,origin,contact_fraction)
			var info: Dictionary=space.get_rest_info(_query)
			if info.is_empty() and moving:
				# A boolean hit at the bisection boundary can be too shallow
				# to provide a manifold. Advance its prefix by at most10um of
				# actual vertex travel, without changing the collision predicate.
				var travel:=0.
				for row in 2:
					for vertex in posed[row].size():travel=maxf(travel,posed[row][vertex].distance_to(posed[row+2][vertex]))
				if travel>0.:
					_shell.points=_cell_hull(posed,sector,origin,minf(1.,contact_fraction+.00001/travel))
					info=space.get_rest_info(_query)
			for ring: int in [i,i+1]:
				var plane: Dictionary=_contact_plane(ring,next[ring],world,info)
				if plane.is_empty():
					_response_error="missing native manifold "+str([i,sector,contact_fraction,info])
					_response_valid=false;return true
				_response_planes.append(plane)
			if _response_planes.size()>=_response_limit:_response_truncated=true;return true
			# One tangent support per segment is re-evaluated after response;
			# corners and curved obstacles may need several solver iterations.
			break
	return not _response_planes.is_empty()
