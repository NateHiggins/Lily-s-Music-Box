extends RefCounted
## Actual FPS input on an isolated collision-bearing floor. Not building qualification.
func _aim_error(player: Node3D,joint: Node3D) -> float:
	return rad_to_deg(acos(clampf((-player.camera.global_basis.z).dot(joint.body.global_basis.y),-1.,1.)))
func _hand_distance(player: Node3D,actor: Node3D,joint: Node3D) -> float:
	return actor.to_global(joint.receiver.origin).distance_to(player.camera.to_global(Vector3(.17,-.16,-.48)))
func _points(rows: PackedVector3Array) -> Array:
	var result: Array=[]
	for point: Vector3 in rows:result.append([point.x,point.y,point.z])
	return result
func _planes(rows: Array) -> Array:
	var result: Array=[]
	for row: Dictionary in rows:result.append({"ring":row.ring,"normal":[row.normal.x,row.normal.y,row.normal.z],"offset":row.offset})
	return result
func _settle(bench: Node,hose: Node3D,actor: Node3D,joint: Node3D,milliseconds: int) -> void:
	var until: int=Time.get_ticks_msec()+milliseconds
	while Time.get_ticks_msec()<until and bench.player._grab.holding_pickup():
		if not hose.tether.pending and _hand_distance(bench.player,actor,joint)<.025 and _aim_error(bench.player,joint)<1.:return
		await bench.get_tree().process_frame
func run(bench: Node,actor: Node3D,hose: Node3D,joint: Node3D) -> void:
	var player: Node3D=bench.player
	if player._grab.active():bench.click()
	hose.fps_aim_enabled=true;hose.fps_once_per_frame=true;hose.local_contacts_enabled=true
	hose.contact.capsule_broadphase=true
	if not bench.check(hose.set_local_follow(true),"full FPS payout prepares local contact-aware following"):return
	if OS.get_environment("ORISON_HOSE_FINE_PAYOUT")=="1":hose.tether.substep_m=.008
	# One initial fixture placement, before pickup. All payout travel below uses
	# the normal character controller and original collision capsule.
	player.global_position=Vector3(-.4,.02,1.15);player.velocity=Vector3.ZERO
	player.collision_layer=1;player.collision_mask=2097153;player.set_physics_process(true)
	player.face_world_point(joint.body.global_position)
	for frame in 8:await bench.get_tree().physics_frame
	bench.check(not player.noclip and player.is_physics_processing() and (player.collision_mask&1)==1,"payout uses the live player capsule and ordinary ground collision")
	if not bench.check(await bench._aim_nozzle_surface(actor,joint,false),"FPS payout targets the actual nozzle without relocating the player"):return
	bench.click()
	if not bench.check(player._grab.holding_pickup() and player.held_stock_body()==joint.body,"actual primary click acquires the FPS nozzle and its physical body"):return
	var auxiliary: Array=hose._auxiliary_contacts.duplicate(true)
	var auxiliary_paths: Array=[]
	for row: Dictionary in auxiliary:auxiliary_paths.append(str(row.body.get_path()))
	bench.check(not auxiliary.is_empty() and auxiliary.all(func(row: Dictionary):return player.get_collision_exceptions().has(row.body)),"held hose assembly includes attached auxiliary bodies in carrier exclusions")
	await _settle(bench,hose,actor,joint,3000)
	bench.check(hose.error.is_empty() and _hand_distance(player,actor,joint)<.025 and _aim_error(player,joint)<1.,"FPS nozzle initially settles at the camera hand pose")
	var sensitivity: float=clampf(float(GameBoot.settings.get("look_sensitivity",1.)),.25,2.)
	# Actual mouse input turns the held nozzle and character toward the clear
	# floor route; no carrier transform is assigned after pickup.
	for step in 100:
		var turn: float=wrapf(PI*.5-player.rotation.y,-PI,PI)
		var pitch: float=player.camera.rotation.x
		if absf(turn)<.001 and absf(pitch)<.001:break
		var event:=InputEventMouseMotion.new()
		event.relative=Vector2(-clampf(turn,-.08,.08),clampf(pitch,-.08,.08))/(player.MOUSE_SENS*sensitivity)
		player._unhandled_input(event)
		await bench.get_tree().physics_frame
	await _settle(bench,hose,actor,joint,3000)
	var rows: Array=[];var started: int=Time.get_ticks_msec();var stalls:=0
	var previous_span: float=hose.rig.strand.points[0].distance_to(hose.rig.strand.anchor)
	for step in 500:
		if not player._grab.holding_pickup() or Time.get_ticks_msec()-started>90000:break
		var span: float=hose.rig.strand.points[0].distance_to(hose.rig.strand.anchor)
		if span>=15.09:break
		var before: Vector3=player.global_position
		var tick: int=Time.get_ticks_msec()
		var during_contacts: Dictionary={}
		Input.action_press("move_forward",.4)
		while player.global_position.distance_to(before)<.06 and Time.get_ticks_msec()-tick<1000 and player._grab.holding_pickup():
			await bench.get_tree().physics_frame
			for index in player.get_slide_collision_count():
				var body: Object=player.get_slide_collision(index).get_collider()
				if body is Node:during_contacts[str(body.get_path())]=true
		Input.action_release("move_forward")
		await bench.get_tree().physics_frame
		await _settle(bench,hose,actor,joint,1500)
		span=hose.rig.strand.points[0].distance_to(hose.rig.strand.anchor)
		var contacts: Array=[]
		for index in player.get_slide_collision_count():
			var collider: Object=player.get_slide_collision(index).get_collider()
			contacts.append(str(collider.get_path()) if collider is Node else str(collider))
		var row: Dictionary={"step":step,"span_m":span,"elapsed_ms":Time.get_ticks_msec()-tick,"player":[player.global_position.x,player.global_position.y,player.global_position.z],"held":player._grab.holding_pickup(),"aim_degrees":_aim_error(player,joint),"hand_distance_m":_hand_distance(player,actor,joint),"error":hose.error,"feedback":player._grab.feedback({}).state,"player_contacts":contacts,"during_contacts":during_contacts.keys(),"fitting_blocker":hose.last_fitting_blocker,"supported_rings":hose.tether.last_support_rings.duplicate(),"profile":hose.last_motion_profile.duplicate(true),"escape":hose.tether.last_escape_attempts.duplicate(true)}
		rows.append(row)
		if step%25==0:print("FPS PAYOUT: ",JSON.stringify(row))
		stalls=stalls+1 if span-previous_span<.001 else 0;previous_span=span
		if stalls>=3:break
	Input.action_release("move_forward")
	var final_span: float=hose.rig.strand.points[0].distance_to(hose.rig.strand.anchor)
	print("FPS PAYOUT FINAL: span=",final_span," steps=",rows.size()," last=",JSON.stringify(rows.back() if not rows.is_empty() else {}))
	bench.check(player._grab.holding_pickup() and final_span>=15.09,"actual FPS walking pays out all15.24m within the original150mm rigid-end span allowance")
	bench.check(hose.rig.strand._valid_positions(hose.rig.strand.points) and hose._physical_bends_clear(hose.rig.strand.points) and not hose.contact.intersects_pose(hose.rig.strand.points) and hose._nozzle_clear(joint.receiver),"full FPS payout retains material, bends and native world/fitting clearance")
	bench.check(_aim_error(player,joint)<1.,"fully paid-out FPS nozzle still aims along the reticle")
	bench.check(rows.all(func(row: Dictionary):return row.during_contacts.all(func(path: String):return path not in auxiliary_paths)),"actual payout walking never collides with attached carried hose parts")
	if player._grab.active():bench.click()
	bench.check(not player._grab.active() and hose.contact.exclusions==hose._contact_exclusions,"next actual click releases full payout and restores query ownership")
	bench.check(auxiliary.all(func(row: Dictionary):return (not row.holder_added or not player.get_collision_exceptions().has(row.body)) and (not row.part_added or not row.body.get_collision_exceptions().has(player))),"release restores only the auxiliary collision exceptions owned by the hose")
	var directory:=OS.get_environment("SHOT_DIR")
	if not directory.is_empty():
		DirAccess.make_dir_recursive_absolute(directory)
		var file:=FileAccess.open(directory.path_join("fps_payout.json"),FileAccess.WRITE)
		if not bench.check(file!=null,"FPS payout diagnostic destination is writable"):return
		var escape_poses: Array=[]
		for pose: PackedVector3Array in hose.tether.last_escape_points:escape_poses.append(_points(pose))
		file.store_string(JSON.stringify({"evidence_class":"INERT","scope":"Actual walking and FPS input on an isolated collision-bearing floor; no building, water, save or release-dynamics qualification.","span_m":final_span,"material_m":hose.rig.strand.total_length,"elapsed_ms":Time.get_ticks_msec()-started,"steps":rows,"pose":hose.rig.snapshot(),"escape_poses":escape_poses,"response":{"kind":hose.tether.last_rejection_kind,"world_planes":_planes(hose.tether.last_world_planes),"self_planes":_planes(hose.tether.last_self_planes),"candidate":_points(hose.tether.last_candidate)},"failures":bench.failures},"\t"));file.close()
