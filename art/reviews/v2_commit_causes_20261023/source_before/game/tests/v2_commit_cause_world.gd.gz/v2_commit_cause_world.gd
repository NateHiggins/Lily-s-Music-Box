extends "res://tests/v2_hose_work_attribution.gd"
## INERT same played route. No commit scheduling or durability changes.
func _save_reload(wanted: Dictionary) -> void:
	profile_active=false
	var owner: Node=world.household_state
	var causes: Array=owner.profile_causes.duplicate(true)
	var useful:=not causes.is_empty()
	for row: Dictionary in causes:
		useful=useful and not row.changed.is_empty() and not row.stack.is_empty()
	_check(useful,"diagnostic commit origins identify changed subjects and call stacks")
	FileAccess.open(OS.get_environment("SHOT_DIR").path_join("commit_causes.json"),FileAccess.WRITE).store_string(JSON.stringify({"evidence_class":"INERT","scope":"Changed IDs and call origins for synchronous household commits in the actual route. No scheduling change. CPU overhead separately recorded; render CPU/GPU measurements lag their frame.","causes":causes},"\t"))
	await super._save_reload(wanted)
