# Gate board - 4e928ecc3634

- commit `4e928ecc363445150e8ac887cf09c8edaaf84158`
- tree `1adca5b6ddf3db1c995147c658d435afc4c8f094`
- created 2026-10-22T16:39:45Z
- dirty paths: 2747

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| physical_import_sources | PASS | 0 | 0.7 | no defects counted |
| spatial | PASS | 0 | 5.16 | drift.new_reported 8 |
| reader | PASS | 0 | 3.45 | unread 1108; vs frozen baseline: new 0, resolved 200 |
| test:test_nook_readable_books | PASS | 0 | 0.14 | ran 4, failed 0 |
