extends "res://tests/v2_hose_installed_world.gd"
## The same ten-waypoint repaired-hose input route and real disk reconstruction.
var work_probe: Node
func _ready() -> void:
	work_probe=preload("res://tests/v2_frame_work_probe.gd").new();work_probe.host=self;add_child(work_probe)
	super._ready()
func _play_route() -> void:
	world.household_state.profiling=true
	player._grab.profiling=true
	await super._play_route()
func _save_reload(wanted: Dictionary) -> void:
	profile_active=false
	work_probe.write(OS.get_environment("SHOT_DIR").path_join("work_trace.json"))
	await _paired_unchanged_control()
	await super._save_reload(wanted)

func _paired_unchanged_control() -> void:
	# Outside route timing. Identical current payload, real production owner;
	# original/cached/restored/cached order controls CPU drift and saved authority.
	var owner: Node=world.household_state
	var phases: Array=[]
	for index in 4:
		owner.reuse_unchanged_validation=index%2==1
		var rows: Array=[];var preserved:=true
		for sample in 20:
			await get_tree().process_frame
			var document: Dictionary=RealityState.data
			var saved: Dictionary=owner._saved_value().duplicate(true)
			var previous: Dictionary=owner._last_saved.duplicate(true)
			var first: int=owner.profile_records.size()
			var started:=Time.get_ticks_usec();owner._on_state_changed();var elapsed:=Time.get_ticks_usec()-started
			var unchanged: bool=is_same(document,RealityState.data) and saved==owner._saved_value() and previous==owner._last_saved and not owner._blocked
			preserved=preserved and unchanged
			var stages: Array=[]
			for row: Dictionary in owner.profile_records.slice(first):stages.append(row.stage)
			rows.append({"elapsed_usec":elapsed,"authority_preserved":unchanged,"stages":stages})
		phases.append({"index":index,"reuse":owner.reuse_unchanged_validation,"samples":rows})
		_check(preserved,"paired unchanged notification preserves the campaign document and household payload: "+str(index))
	owner.reuse_unchanged_validation=true
	FileAccess.open(OS.get_environment("SHOT_DIR").path_join("unchanged_pairs.json"),FileAccess.WRITE).store_string(JSON.stringify({"evidence_class":"INERT","scope":"Interleaved direct notification CPU controls after the actual route, before disk rebuild. Not player-input or whole-frame gain proof.","phases":phases},"\t"))
