extends "res://tests/v2_hose_installed_world.gd"
## The same ten-waypoint repaired-hose input route and real disk reconstruction.
var work_probe: Node
func _ready() -> void:
	work_probe=preload("res://tests/v2_frame_work_probe.gd").new();work_probe.host=self;add_child(work_probe)
	super._ready()
func _play_route() -> void:
	world.household_state.profiling=true
	player._grab.profiling=true
	await super._play_route()
func _save_reload(wanted: Dictionary) -> void:
	profile_active=false
	work_probe.write(OS.get_environment("SHOT_DIR").path_join("work_trace.json"))
	await super._save_reload(wanted)
