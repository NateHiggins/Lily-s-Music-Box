# Gate board - 20af7fdd2eb3

- commit `20af7fdd2eb3d9b71e618f7cfde8739a6997b780`
- tree `84e5f70f709b3661f4da7ad01bfc858a9bb019bb`
- created 2026-10-22T16:07:57Z
- dirty paths: 2450

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| spatial | PASS | 0 | 5.42 | drift.new_reported 8 |
| reader | PASS | 0 | 3.61 | unread 1108; vs frozen baseline: new 0, resolved 200 |
| test:test_orison_spatial_dependencies | PASS | 0 | 6.42 | ran 59, failed 0 |
