# Gate board - b98efbd32763

- commit `b98efbd32763a5061b99dcd3ccdd78a0b972bc63`
- tree `d6ffb85e7d329ee1d17229d5079992b8b088a5ad`
- created 2026-10-22T15:51:52Z
- dirty paths: 2247

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| spatial | PASS | 0 | 5.45 | drift.new_reported 8 |
| reader | PASS | 0 | 3.59 | unread 1108; vs frozen baseline: new 0, resolved 200 |
| test:test_nook_readable_books | PASS | 0 | 0.25 | ran 4, failed 0 |
| test:test_orison_spatial_dependencies | PASS | 0 | 6.09 | ran 59, failed 0 |
