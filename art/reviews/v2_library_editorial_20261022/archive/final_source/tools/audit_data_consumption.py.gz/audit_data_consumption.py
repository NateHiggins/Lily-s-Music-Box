#!/usr/bin/env python3
"""Find shipped data and durable numeric fields that have no real consumer.

This is deliberately source-only and conservative. JSON prose never counts as
proof of consumption. A file needs a production GDScript path reference; each
field needs a production token reader. Durable numeric fields retain their
full nested schema path; path-aware aliases, constant keys and generic
container iteration are followed. Fields whose only read is self-feedback in
their own monotonic assignment are reported separately.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path

TOOL_VERSION = 4
DEFAULT_EXCEPTIONS = "tools/data_consumption_exceptions.json"
DEFAULT_BASELINE = "tools/data_consumption_baseline.json"
BASELINE_SCHEMA = "orison.data-consumption-baseline.v1"
PATH_RE = re.compile(r"res://data/([A-Za-z0-9_./-]+\.json)")
STRING_RE = re.compile(r"['\"]([A-Za-z_][A-Za-z0-9_]*)['\"]")
DOT_RE = re.compile(r"\.(?P<key>[A-Za-z_][A-Za-z0-9_]*)\b")
STATE_RE = re.compile(r"RealityState\.data(?:\.([A-Za-z_][A-Za-z0-9_]*))")
DEFAULT_FIELD_RE = re.compile(
    r'^(?P<indent>\s*)"(?P<field>[A-Za-z_][A-Za-z0-9_]*)"\s*:\s*(?P<value>.*)$')
NUMBER_RE = re.compile(
    r"^[+-]?(?:(?:\d(?:_?\d)*)?(?:\.\d(?:_?\d)*)|"
    r"\d(?:_?\d)*)(?:e[+-]?\d(?:_?\d)*)?$", re.IGNORECASE)
CONST_STRING_RE = re.compile(
    r"^\s*const\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)"
    r"(?:\s*:\s*[^=]+)?\s*(?::=|=)\s*['\"](?P<value>[^'\"]+)['\"]")
CONST_NUMBER_RE = re.compile(
    r"^\s*const\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)"
    r"(?:\s*:\s*[^=]+)?\s*(?::=|=)\s*(?P<value>[^#]+?)\s*$")
ASSIGNMENT_RE = re.compile(r"(?<![=!<>])(?P<op>\+=|-=|\*=|/=|=(?!=))")

# These containers are schema-declared identity maps: their keys are authored
# record identities, not independently consumable schema fields.  Their values
# are still traversed, so a new field inside an alias target remains visible to
# the audit.  Keep this closed over explicit schema identities; an unfamiliar
# document or container continues to fail conservatively.
DYNAMIC_MAP_PATHS_BY_SCHEMA = {
    "orison.floor01.cell-registry.v1": frozenset({
        "compatibility_alias_index",
        "semantic_owner_index",
    }),
}


# Existing catalogs without a unique schema string need an exact game/data
# relative path, never a basename or a globally recognized container name.
# These declarations classify record identities only. They grant neither a
# FILE reader nor a reader for any field in a record value.
DYNAMIC_MAP_PATHS_BY_FILE = {
    # Readable library cache resolves authored stock/finish/plate identities;
    # record values still need ordinary production field readers.
    "orison_v2/readable_library.json": frozenset({"parts", "books", "cases", "bookends", "finishes", "illustrations", "page_designs", "formats", "publishers", "publication_layouts", "decorations"}),
    "orison_v2/nook_readable_books.json": frozenset({"books", "parts"}),
    "orison_v2/book_spreads.json": frozenset({"spreads"}),
    # FunctionalProp._ready: _catalog.get(prop_type).
    "prop_catalog.json": frozenset({""}),
    # RealityCaseManager/RealityRuleDirector: definitions.get(case_id).
    "reality_cases.json": frozenset({""}),
    "reality_rules.json": frozenset({""}),
    # OrisonMusicDirector: tracks[track_id], residents.get(resident_id).
    "music_catalog.json": frozenset({"tracks", "residents"}),
    # ScheduleDirector: data.residents[raw_slug].
    "resident_schedules.json": frozenset({"residents"}),
    # MaintenanceActivityLibrary: authored[activity_id].
    "maintenance_activities.json": frozenset({"activities"}),
    # OrisonV2UpperFloorDoors: source.doors[identity].
    "orison_v2/upper_floor_programs.json": frozenset({"doors"}),
    # OrisonV2MinaRoutine: places.get(destination).
    "orison_v2/mina_routine.json": frozenset({"places"}),
    # Build-time mirror: finish IDs produced by generate_runtime_materials.py.
    # Its FILE_UNREAD and unread value schema remain reported independently.
    "runtime_material_sets.json": frozenset({"materials"}),
}


def json_fields(value, prefix="", dynamic_map_paths=frozenset()):
    out = Counter()
    if isinstance(value, dict):
        if prefix in dynamic_map_paths:
            for child in value.values():
                out.update(json_fields(
                    child, prefix + "[]", dynamic_map_paths))
            return out
        for key, child in value.items():
            path = f"{prefix}.{key}" if prefix else key
            out[path] += 1
            out.update(json_fields(child, path, dynamic_map_paths))
    elif isinstance(value, list):
        for child in value:
            out.update(json_fields(child, prefix + "[]", dynamic_map_paths))
    return out


def data_json_fields(value, rel_data=None):
    schema = value.get("schema") if isinstance(value, dict) else None
    dynamic_map_paths = DYNAMIC_MAP_PATHS_BY_SCHEMA.get(
        schema, frozenset()) | DYNAMIC_MAP_PATHS_BY_FILE.get(
        rel_data, frozenset())
    return json_fields(value, dynamic_map_paths=dynamic_map_paths)


def production_sources(root: Path):
    return sorted(p for p in (root / "game/scripts").rglob("*.gd")
                  if "/tests/" not in p.as_posix())


def load_exceptions(path: Path):
    if not path.exists():
        return {"files": {}, "fields": {}}
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("exceptions root must be an object")
    return value


def source_constants(text: str):
    strings = {}
    numbers = {}
    for line in text.splitlines():
        string_match = CONST_STRING_RE.match(line)
        if string_match:
            strings[string_match.group("name")] = string_match.group("value")
        number_match = CONST_NUMBER_RE.match(line)
        if not number_match:
            continue
        value = number_match.group("value").strip().rstrip(",")
        if NUMBER_RE.fullmatch(value):
            numbers[number_match.group("name")] = value
    return strings, numbers


def durable_numeric_defaults(state_text: str):
    """Return numeric defaults from RealityState._fresh_data by full path.

    The durable state is a nested dictionary, even though most of today's
    top-level owners begin as empty maps.  Indentation is authoritative inside
    this literal: it lets the audit follow future bucket schemas without
    mistaking dynamic dictionaries declared elsewhere for global save facts.
    """
    marker = "func _fresh_data()"
    if marker not in state_text:
        raise ValueError("RealityState has no _fresh_data durable schema")
    fresh = state_text.partition(marker)[2]
    fresh = fresh.partition("\nfunc ")[0]
    if not re.search(r"\breturn\s*\{", fresh):
        raise ValueError("RealityState._fresh_data has no dictionary literal")
    _strings, numeric_constants = source_constants(state_text)
    stack = []
    numeric = {}
    for line in fresh.splitlines():
        match = DEFAULT_FIELD_RE.match(line)
        if not match:
            continue
        indent = len(match.group("indent").expandtabs(4))
        while stack and indent <= stack[-1][0]:
            stack.pop()
        field = match.group("field")
        value = match.group("value").split("#", 1)[0].strip().rstrip(",")
        prefix = tuple(segment for _indent, segments in stack
                       for segment in segments)
        path = prefix + (field,)
        if value == "{":
            stack.append((indent, (field,)))
        elif value == "[":
            stack.append((indent, (field, "*")))
        elif NUMBER_RE.fullmatch(value) or value in numeric_constants:
            numeric[path] = value
        elif ((value.startswith("{") and value != "{}") or
              (value.startswith("[") and value != "[]")):
            raise ValueError(
                f"inline durable container for {'.'.join(path)} is not auditable")
        elif re.search(r"\d", value) and not re.fullmatch(r"['\"].*['\"]", value):
            raise ValueError(
                f"unsupported numeric durable default for {'.'.join(path)}: {value}")
    if not numeric:
        raise ValueError("RealityState._fresh_data declares no numeric fields")
    return numeric


def _matching_close(text: str, start: int, opening: str, closing: str):
    depth = 0
    quote = ""
    for index in range(start, len(text)):
        char = text[index]
        if quote:
            if char == quote and (index == 0 or text[index - 1] != "\\"):
                quote = ""
            continue
        if char in "'\"":
            quote = char
        elif char == opening:
            depth += 1
        elif char == closing:
            depth -= 1
            if depth == 0:
                return index
    return -1


def _key_value(token: str, constants):
    token = token.strip()
    if len(token) >= 2 and token[0] == token[-1] and token[0] in "'\"":
        return token[1:-1]
    if token in constants:
        return constants[token]
    if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", token):
        return "*"
    return None


def _parse_access_tail(text: str, start: int, base, constants):
    path = list(base)
    index = start
    while index < len(text):
        if text.startswith(".get", index):
            open_at = text.find("(", index + 4)
            if open_at < 0:
                break
            close_at = _matching_close(text, open_at, "(", ")")
            if close_at < 0:
                break
            first_arg = text[open_at + 1:close_at].split(",", 1)[0]
            key = _key_value(first_arg, constants)
            if key is None:
                break
            path.append(key)
            index = close_at + 1
            continue
        if text.startswith(".values()", index) or text.startswith(".keys()", index):
            index += len(".values()")
            break
        dot = re.match(r"\.([A-Za-z_][A-Za-z0-9_]*)", text[index:])
        if dot:
            if index + dot.end() < len(text) and text[index + dot.end()] == "(":
                break
            path.append(dot.group(1))
            index += dot.end()
            continue
        if text[index] == "[":
            close_at = _matching_close(text, index, "[", "]")
            if close_at < 0:
                break
            key = _key_value(text[index + 1:close_at], constants)
            if key is None:
                break
            path.append(key)
            index = close_at + 1
            continue
        break
    return tuple(path), index


def _string_spans(text: str):
    spans = []
    start = -1
    quote = ""
    for index, char in enumerate(text):
        if quote:
            if char == quote and (index == 0 or text[index - 1] != "\\"):
                spans.append((start, index + 1))
                quote = ""
        elif char in "'\"":
            start = index
            quote = char
    if quote:
        spans.append((start, len(text)))
    return spans


def assignment_match(statement: str):
    strings = _string_spans(statement)
    for match in ASSIGNMENT_RE.finditer(statement):
        if not any(lo <= match.start() < hi for lo, hi in strings):
            return match
    return None


def access_chains(text: str, aliases, constants):
    found = []
    occupied = []
    strings = _string_spans(text)
    inside_string = lambda position: any(lo <= position < hi for lo, hi in strings)
    for match in re.finditer(r"RealityState\.data\b", text):
        if inside_string(match.start()):
            continue
        path, end = _parse_access_tail(text, match.end(), (), constants)
        if path:
            found.append(path)
            occupied.append((match.start(), end))
    for alias, base in sorted(aliases.items(), key=lambda item: -len(item[0])):
        for match in re.finditer(rf"\b{re.escape(alias)}\b", text):
            if inside_string(match.start()) or any(
                    lo <= match.start() < hi for lo, hi in occupied):
                continue
            path, end = _parse_access_tail(text, match.end(), base, constants)
            if len(path) >= len(base):
                found.append(path)
    return found


def path_matches(declared, accessed):
    return len(declared) == len(accessed) and all(
        expected == actual or expected == "*" or actual == "*"
        for expected, actual in zip(declared, accessed))


def _binding(statement: str):
    return re.match(
        r"^(?:var\s+|const\s+)?(?P<name>[A-Za-z_][A-Za-z0-9_]*)"
        r"(?:\s*:\s*[^:=]+)?\s*(?::=|=)(?!=)\s*(?P<rhs>.+)$", statement)


def _member_names(text: str):
    return set(re.findall(
        r"^(?:@[A-Za-z_][A-Za-z0-9_]*(?:\([^\n]*\))?\s+)*"
        r"var\s+([A-Za-z_][A-Za-z0-9_]*)\b", text, re.MULTILINE))


def _string_binding(rhs: str):
    match = re.fullmatch(r"\s*(['\"])(?P<value>.*)\1\s*", rhs)
    return match.group("value") if match else None


def binding_access_paths(rhs: str, aliases, constants):
    """Only a direct state expression establishes a durable alias.

    State passed to a constructor is read, but its returned value is not an
    alias to that argument. General reads still use access_chains separately.
    """
    expression = rhs.strip()
    direct = re.match(r"RealityState\.data\b", expression)
    if not direct:
        direct = any(re.match(rf"{re.escape(name)}\b", expression)
                     for name in aliases)
    return access_chains(expression, aliases, constants) if direct else []


def _numeric_source_pass(text: str, root_aliases, member_aliases):
    class_constants, _numbers = source_constants(text)
    constants = class_constants.copy()
    members = _member_names(text)
    root_aliases = dict(root_aliases or {})
    aliases = {**root_aliases, **member_aliases}
    events = []
    for statement in logical_statements(text):
        if statement.startswith("func "):
            aliases = {**root_aliases, **member_aliases}
            constants = class_constants.copy()
        assignment = assignment_match(statement)
        if assignment:
            lhs = statement[:assignment.start()]
            rhs = statement[assignment.end():]
            lhs_paths = access_chains(lhs, aliases, constants)
            rhs_paths = access_chains(rhs, aliases, constants)
            op = assignment.group("op")
        else:
            lhs_paths = []
            rhs_paths = access_chains(statement, aliases, constants)
            op = ""
        for path in lhs_paths:
            self_read = any(path_matches(path, candidate) for candidate in rhs_paths)
            monotonic = op in {"+=", "-="} or (self_read and (
                "+" in rhs or "clampf(" in rhs or "maxf(" in rhs or "minf(" in rhs))
            events.append((path, "monotonic" if monotonic else "write"))
        for path in rhs_paths:
            if not any(path_matches(path, target) for target in lhs_paths):
                events.append((path, "read"))
        binding = _binding(statement)
        if binding:
            name = binding.group("name")
            bound_paths = binding_access_paths(binding.group("rhs"), aliases, constants)
            string_value = _string_binding(binding.group("rhs"))
            if name in root_aliases:
                aliases[name] = root_aliases[name]
            elif bound_paths:
                aliases[name] = bound_paths[0]
                if name in members:
                    previous = member_aliases.get(name)
                    if previous is not None and previous != bound_paths[0]:
                        raise ValueError(
                            f"ambiguous durable member alias {name}: "
                            f"{'.'.join(previous)} vs {'.'.join(bound_paths[0])}")
                    member_aliases[name] = bound_paths[0]
            else:
                aliases.pop(name, None)
                # Runtime teardown may clear a member after its consumer has
                # run. Static ownership is a set of possible valid bindings,
                # not the final source-order assignment, so a non-state clear
                # cannot erase a binding already proved elsewhere.
            if string_value is not None:
                constants[name] = string_value
            elif name not in class_constants:
                constants.pop(name, None)
        loop_binding = re.match(
            r"^for\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s+in\s+(?P<rhs>.+):$",
            statement)
        if loop_binding:
            bound_paths = access_chains(loop_binding.group("rhs"), aliases, constants)
            if bound_paths:
                aliases[loop_binding.group("name")] = bound_paths[0] + ("*",)
    return events, member_aliases


def numeric_source_events(text: str, root_aliases=None):
    root_aliases = dict(root_aliases or {})
    member_aliases = {}
    for _attempt in range(4):
        before = member_aliases.copy()
        _events, member_aliases = _numeric_source_pass(
            text, root_aliases, member_aliases)
        if member_aliases == before:
            break
    events, _member_aliases = _numeric_source_pass(
        text, root_aliases, member_aliases)
    return events


def logical_statements(text: str):
    """Yield small GDScript statements with multiline calls kept together."""
    pending = []
    depth = 0
    for line in text.splitlines():
        code = line.split("#", 1)[0].strip()
        if not code and not pending:
            continue
        pending.append(code)
        depth += sum(code.count(char) for char in "([{")
        depth -= sum(code.count(char) for char in ")]}")
        if depth <= 0:
            yield " ".join(part for part in pending if part)
            pending = []
            depth = 0
    if pending:
        yield " ".join(part for part in pending if part)


def numeric_state_records(texts, numeric):
    records = []
    state_file = "game/scripts/game/reality_game_state.gd"
    events = []
    for source, text in texts.items():
        root_aliases = {"data": ()} if source.as_posix().endswith(
            "/game/reality_game_state.gd") else {}
        events.extend((source, path, kind)
                      for path, kind in numeric_source_events(text, root_aliases))
    for path, _default in sorted(numeric.items()):
        display = ".".join(path)
        matching = [(source, kind) for source, accessed, kind in events
                    if path_matches(path, accessed)]
        if not matching:
            records.append({"kind": "DURABLE_NUMERIC_UNREAD", "file": state_file,
                            "field": display,
                            "detail": "zero production readers or writers",
                            "excepted": False})
            continue
        kinds = {kind for _source, kind in matching}
        if "read" not in kinds and "monotonic" in kinds:
            records.append({"kind": "DURABLE_NUMERIC_MONOTONIC_ONLY",
                            "file": state_file, "field": display,
                            "detail": "only self-feedback in monotonic writes",
                            "excepted": False})
        elif "read" not in kinds and "write" in kinds:
            records.append({"kind": "DURABLE_NUMERIC_UNREAD",
                            "file": state_file, "field": display,
                            "detail": "written but never read by production",
                            "excepted": False})
    return records


def _split_call_arguments(text: str):
    """Split a call without mistaking nested calls or literals for arguments."""
    arguments = []
    start = 0
    depth = 0
    strings = _string_spans(text)
    for index, char in enumerate(text):
        if any(lo <= index < hi for lo, hi in strings):
            continue
        if char in "([{":
            depth += 1
        elif char in ")]}":
            depth -= 1
        elif char == "," and depth == 0:
            arguments.append(text[start:index].strip())
            start = index + 1
    if text[start:].strip():
        arguments.append(text[start:].strip())
    return arguments


def _script_functions(text: str):
    definitions = list(re.finditer(
        r"^(?:static\s+)?func\s+(\w+)\s*\(([^\n]*)\)[^\n]*:\s*$",
        text, re.MULTILINE))
    functions = {}
    for index, match in enumerate(definitions):
        end = definitions[index + 1].start() if index + 1 < len(definitions) else len(text)
        parameters = [re.match(r"\w+", p).group(0)
                      for p in _split_call_arguments(match.group(2))
                      if re.match(r"\w+", p)]
        functions[match.group(1)] = (parameters, text[match.start():end])
    return functions


def _direct_json_alias(expression: str, aliases, constants):
    expression = expression.strip()
    for name, base in sorted(aliases.items(), key=lambda item: -len(item[0])):
        match = re.match(rf"{re.escape(name)}\b", expression)
        if not match:
            continue
        path, end = _parse_access_tail(expression, match.end(), base, constants)
        if not expression[end:].strip():
            return path
    return None


def _parameter_accesses(text, aliases, constants):
    strings = _string_spans(text)
    for name, base in aliases.items():
        for match in re.finditer(rf"(?<![\w.]){re.escape(name)}\b", text):
            if any(lo <= match.start() < hi for lo, hi in strings):
                continue
            path, _end = _parse_access_tail(text, match.end(), base, constants)
            yield path


def _parameter_reads(body, parameter, origin):
    """Read only local aliases descending from the passed helper parameter."""
    aliases = {parameter: origin}
    constants = {}
    for statement in logical_statements(body):
        if statement.startswith(("func ", "static func ")):
            continue
        assignment = assignment_match(statement)
        rhs = statement[assignment.end():] if assignment else statement
        yield from _parameter_accesses(rhs, aliases, constants)
        binding = _binding(statement)
        if binding:
            name, expression = binding.group("name"), binding.group("rhs")
            bound = _direct_json_alias(expression, aliases, constants)
            if bound:
                aliases[name] = bound
            else:
                aliases.pop(name, None)
            literal = _string_binding(expression)
            if literal is not None:
                constants[name] = literal
            else:
                constants.pop(name, None)
        loop = re.match(r"^for\s+(\w+)(?:\s*:\s*\w+)?\s+in\s+(.+):$", statement)
        if loop:
            bound = _direct_json_alias(loop.group(2), aliases, constants)
            if bound:
                aliases[loop.group(1)] = bound + ("*",)
            else:
                aliases.pop(loop.group(1), None)


def inherited_parameter_reads(root: Path, texts):
    """Follow one direct argument into a method in the literal base chain.

    Only an actual JSON parse creates file identity. A direct alias or array
    item can reach a non-overridden inherited method, where reads must descend
    from its matching parameter. Constructors, general return values, unrelated
    dictionaries and entire base-file token lists grant no credit.
    """
    reads = {}
    for caller, text in texts.items():
        parent = re.search(r'^extends\s+["\']res://(scripts/[^"\']+\.gd)["\']',
                           text, re.MULTILINE)
        if not parent:
            continue
        parent_path = root / "game" / parent.group(1)
        if parent_path not in texts:
            continue
        methods = {}
        visited = {caller}
        # Resolve the nearest implementation, including intermediate overrides.
        # Cycles and bases outside the scanned production sources stop traversal.
        while parent_path in texts and parent_path not in visited:
            visited.add(parent_path)
            base_text = texts[parent_path]
            for name, definition in _script_functions(base_text).items():
                methods.setdefault(name, definition)
            ancestor = re.search(r'^extends\s+["\']res://(scripts/[^"\']+\.gd)["\']',
                                 base_text, re.MULTILINE)
            if not ancestor:
                break
            parent_path = root / "game" / ancestor.group(1)
        overrides = _script_functions(text)
        class_constants, _numbers = source_constants("\n".join(
            line for line in text.splitlines() if not line[:1].isspace()))
        constants = class_constants.copy()
        aliases = {}
        for statement in logical_statements(text):
            if statement.startswith(("func ", "static func ")):
                aliases = {}
                constants = class_constants.copy()
                continue
            binding = _binding(statement)
            if binding:
                name, rhs = binding.group("name"), binding.group("rhs")
                parsed = re.fullmatch(
                    r"JSON\.parse_string\(\s*FileAccess\.get_file_as_string\((.*?)\)\s*\)",
                    rhs.strip())
                source = None
                if parsed:
                    argument = parsed.group(1).strip()
                    value = constants.get(argument, _string_binding(argument))
                    source = PATH_RE.fullmatch(value) if isinstance(value, str) else None
                bound = (source.group(1),) if source else _direct_json_alias(rhs, aliases, constants)
                if bound:
                    aliases[name] = bound
                else:
                    aliases.pop(name, None)
                literal = _string_binding(rhs)
                if literal is not None:
                    constants[name] = literal
                else:
                    constants.pop(name, None)
            loop = re.match(r"^for\s+(\w+)(?:\s*:\s*\w+)?\s+in\s+(.+):$", statement)
            if loop:
                bound = _direct_json_alias(loop.group(2), aliases, constants)
                if bound:
                    aliases[loop.group(1)] = bound + ("*",)
                else:
                    aliases.pop(loop.group(1), None)
            strings = _string_spans(statement)
            for call in re.finditer(r"(?<![\w.])(\w+)\s*\(", statement):
                if any(lo <= call.start() < hi for lo, hi in strings):
                    continue
                name = call.group(1)
                if name not in methods or name in overrides:
                    continue
                opening = statement.find("(", call.start())
                closing = _matching_close(statement, opening, "(", ")")
                if closing < 0:
                    continue
                parameters, body = methods[name]
                arguments = _split_call_arguments(statement[opening + 1:closing])
                for parameter, argument in zip(parameters, arguments):
                    bound = _direct_json_alias(argument, aliases, constants)
                    if not bound:
                        continue
                    for path in _parameter_reads(body, parameter, bound):
                        if len(path) > 1:
                            reads.setdefault(path[0], set()).add(path[1:])
    return reads


def scan(root: Path, exception_path: Path):
    exceptions = load_exceptions(exception_path)
    sources = production_sources(root)
    texts = {p: p.read_text(encoding="utf-8", errors="replace") for p in sources}
    path_users = {}
    token_users = {}
    for path, text in texts.items():
        rel = path.relative_to(root).as_posix()
        for match in PATH_RE.finditer(text):
            path_users.setdefault(match.group(1), set()).add(rel)
        for match in STRING_RE.finditer(text):
            token_users.setdefault(match.group(1), set()).add(rel)
        for match in DOT_RE.finditer(text):
            token_users.setdefault(match.group("key"), set()).add(rel)

    inherited_reads = inherited_parameter_reads(root, texts)
    records = []
    data_root = root / "game/data"
    # Recursive: game/data/ has subdirectories (songbook/), and PATH_RE
    # already accepts a nested res://data/<dir>/<file>.json reference, so a
    # flat glob silently passed every file the loader could legitimately name.
    for path in sorted(data_root.rglob("*.json")):
        rel_data = path.relative_to(data_root).as_posix()
        rel_repo = path.relative_to(root).as_posix()
        try:
            parsed = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            records.append({"kind": "MALFORMED", "file": rel_repo,
                            "detail": str(exc)})
            continue
        readers = sorted(path_users.get(rel_data, set()))
        file_exception = exceptions.get("files", {}).get(rel_repo)
        if not readers:
            records.append({"kind": "FILE_UNREAD", "file": rel_repo,
                            "detail": file_exception or "no production path reader",
                            "excepted": bool(file_exception)})
        fields = data_json_fields(parsed, rel_data)
        # Declared identity-map keys have already been removed above. The
        # existing token-reader rule reports remaining schema leaves per
        # file, retaining their occurrence counts.
        leaves = Counter()
        for field, occurrences in fields.items():
            leaves[field.replace("[]", "").rsplit(".", 1)[-1]] += occurrences
        for leaf, occurrences in sorted(leaves.items()):
            field = leaf
            # A same-named token in an unrelated subsystem is not a reader.
            # Field proof must occur in a source that opens this exact file.
            users = sorted(set(token_users.get(leaf, set())) & set(readers))
            # Inherited helper credit is path/parameter-specific, never every
            # token present in the parent script. Preserve the existing leaf
            # reporting format after proving an actual matching JSON path.
            forwarded = any(
                candidate.replace("[]", "").rsplit(".", 1)[-1] == leaf
                and path_matches(tuple(candidate.replace("[]", ".*").strip(".").split(".")),
                                 accessed[:len(candidate.replace("[]", ".*").strip(".").split("."))])
                for candidate in fields for accessed in inherited_reads.get(rel_data, ()))
            key = f"{rel_repo}:{field}"
            field_exception = exceptions.get("fields", {}).get(key)
            if not users and not forwarded:
                records.append({"kind": "FIELD_UNREAD", "file": rel_repo,
                                "field": field, "occurrences": occurrences,
                                "detail": field_exception or "zero production token readers",
                                "excepted": bool(field_exception)})

    state_file = root / "game/scripts/game/reality_game_state.gd"
    state_text = state_file.read_text(encoding="utf-8")
    numeric = durable_numeric_defaults(state_text)
    records.extend(numeric_state_records(texts, numeric))
    return records


def record_key(record: dict) -> str:
    """Stable identity of a finding: kind, file and (for fields) the path.

    Occurrence counts and prose details are deliberately not part of the key,
    so a baseline survives a reader being added elsewhere in the same file.
    """
    return "|".join([record["kind"], record["file"], record.get("field") or ""])


def load_baseline(path: Path) -> set[str]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("schema") != BASELINE_SCHEMA or             not isinstance(data.get("records"), list):
        raise ValueError(f"baseline {path} is not {BASELINE_SCHEMA}")
    return {str(key) for key in data["records"]}


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--exceptions", default=DEFAULT_EXCEPTIONS)
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--baseline", nargs="?", const=DEFAULT_BASELINE, default=None,
                        help="report-and-fail only on findings absent from this "
                             "frozen baseline (default %s); a baseline is a "
                             "snapshot of known debt, never an exception" % DEFAULT_BASELINE)
    parser.add_argument("--write-baseline", nargs="?", const=DEFAULT_BASELINE, default=None,
                        help="freeze the current non-excepted findings and exit 0")
    args = parser.parse_args(argv)
    root = Path(args.root).resolve()

    def rooted(value: str) -> Path:
        path = Path(value)
        return path if path.is_absolute() else root / path

    try:
        records = scan(root, rooted(args.exceptions))
        baseline = load_baseline(rooted(args.baseline)) if args.baseline else None
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"MALFORMED: {exc}", file=sys.stderr)
        return 4
    blockers = [r for r in records if not r.get("excepted")]
    if args.write_baseline:
        target = rooted(args.write_baseline)
        target.write_text(json.dumps({
            "schema": BASELINE_SCHEMA, "tool_version": TOOL_VERSION,
            "note": "Known unread data frozen as a snapshot so new work can be "
                    "held to zero NEW findings. Triage is still owed; a key "
                    "here is debt, not permission.",
            "records": sorted({record_key(r) for r in blockers}),
        }, indent=1) + "\n", encoding="utf-8", newline="\n")
        print(f"wrote {len(blockers)} findings to {target}")
        return 0
    new = blockers if baseline is None else         [r for r in blockers if record_key(r) not in baseline]
    resolved = [] if baseline is None else         sorted(baseline - {record_key(r) for r in blockers})
    payload = {"tool_version": TOOL_VERSION, "records": records,
               "summary": dict(Counter(r["kind"] for r in records)),
               "blocking": len(new)}
    if baseline is not None:
        payload["baseline"] = {"known": len(blockers) - len(new),
                               "new": [record_key(r) for r in new],
                               "resolved": resolved}
    if args.json:
        print(json.dumps(payload, indent=1, sort_keys=True))
    else:
        print("data consumption audit")
        for key, count in sorted(payload["summary"].items()):
            print(f"  {key}: {count}")
        if baseline is not None:
            print(f"  known (in baseline): {len(blockers) - len(new)}")
            print(f"  resolved since baseline: {len(resolved)}")
            print(f"  NEW: {len(new)}")
        else:
            print(f"  blocking: {len(blockers)}")
        for record in new[:80]:
            suffix = f":{record['field']}" if record.get("field") else ""
            print(f"  - {record['kind']} {record['file']}{suffix} ({record['detail']})")
    return 1 if new else 0


if __name__ == "__main__":
    raise SystemExit(main())
