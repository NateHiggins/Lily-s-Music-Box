# Candidate verification - 1c3b214b3775

- candidate `1c3b214b3775958025d31a1cac3712473ac627ef`
- base `b0708b7e0f31aeb3af9ee55373609800a2cc33d6`
- merge-base `b0708b7e0f31aeb3af9ee55373609800a2cc33d6`
- verified 2026-10-31T18:45:03Z from verifier `1c3b214b3775`

| check | result |
|---|---|
| checkout mode | fresh |
| checkout clean | yes |
| gate board vs merge-base | 0 regressions, 0 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 2 |

## Blocking reasons (0)

- none

## Needs human review (not blocking) (2)

- candidate changes 2 gate file(s); read those diffs before trusting the board
- Godot suites were not run (--no-godot)

## Regressions (0)

- none

## Accepted regressions (0)

- none

## Improvements (0)

- none

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (2)

- M tools/orison_spatial_dependency_manifest.json
- A tools/tests/test_city_horizon_shards.py

MERGE-CANDIDATE 1c3b214b3775958025d31a1cac3712473ac627ef
