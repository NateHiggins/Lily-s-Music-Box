# Candidate verification - f5082fcf3aff

- candidate `f5082fcf3aff88de70f36d323a2636da0b7aaa2c`
- base `b0708b7e0f31aeb3af9ee55373609800a2cc33d6`
- merge-base `b0708b7e0f31aeb3af9ee55373609800a2cc33d6`
- verified 2026-10-31T18:33:44Z from verifier `f5082fcf3aff`

| check | result |
|---|---|
| checkout mode | fresh |
| checkout clean | yes |
| gate board vs merge-base | 2 regressions, 0 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 2 |

## Blocking reasons (2)

- regression: spatial: drift.new_reported 0 -> 1
- regression: spatial: new defect new_reported:e2dc4971ff3c5327

## Needs human review (not blocking) (2)

- candidate changes 2 gate file(s); read those diffs before trusting the board
- Godot suites were not run (--no-godot)

## Regressions (2)

- spatial: drift.new_reported 0 -> 1
- spatial: new defect new_reported:e2dc4971ff3c5327

## Accepted regressions (0)

- none

## Improvements (0)

- none

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (2)

- M tools/orison_spatial_dependency_manifest.json
- A tools/tests/test_city_horizon_shards.py

BLOCKED regression: spatial: drift.new_reported 0 -> 1; regression: spatial: new defect new_reported:e2dc4971ff3c5327
