extends "res://tests/v2_bathroom_optics_profile.gd"
## INERT occupied-world curtain profile. Exact same fixture before/after.
var curtain_inputs: Array[Dictionary]=[]

func _init() -> void: route_label="V2 CURTAIN WORLD PROFILE"

func _ready() -> void:
	GameBoot.launch_mode=GameBoot.LaunchMode.CINEMATIC
	GameBoot.settings.weather_network_enabled=false
	OS.set_environment("WEATHER_SIMULATE","")
	super._ready()

func _route() -> void:
	for driver: CampaignClockDriver in get_tree().get_nodes_in_group("campaign_time_owner"):
		driver.set_frozen_for_tests(true)
	player.camera.fov=75.0
	var switches: SwitchSystem=world.get_node("V2RoomSwitches")
	var original: Dictionary=switches.room_snapshot("F04_B_BATH")
	var lit: Dictionary={}
	for id: String in original: lit[id]=true
	switches.restore_room("F04_B_BATH",lit)
	await _profile_route()
	switches.restore_room("F04_B_BATH",original)
	var directory:=OS.get_environment("SHOT_DIR")
	FileAccess.open(directory.path_join("curtain_input.json"),FileAccess.WRITE).store_string(JSON.stringify({
		"evidence_class":"INERT","scope":"actual occupied 4B bath, original door/walking approach then repeated primary grab/motion/release; no full V2 qualification",
		"clock":world.campaign_clock.datetime_string(),"resolution":str(get_viewport().get_visible_rect().size),
		"fov":player.camera.fov,"settings":{"render_method":RenderingServer.get_current_rendering_method(),
			"quality":int(GameBoot.settings.get("quality",0)),"msaa_3d":get_viewport().msaa_3d,
			"taa":get_viewport().use_taa,"vsync":false},
		"drawn_source_sha256":FileAccess.get_sha256("res://assets/props/bath_shower.glb"),
		"motion_source_sha256":FileAccess.get_sha256("res://scripts/props/shower_curtain_motion.gd"),
		"phases":curtain_inputs,"failures":failures},"\t"))

func _wet_route(shower: TapProp) -> bool:
	if not _require(is_zero_approx(shower._curtain_hand.travel),"curtain starts closed through its actual owner"):return false
	await _measure("curtain_idle_before",shower.to_global(Vector3(0,1.18,-.32)),3.0)
	for round_index in 3:
		for opening: bool in [true,false]:
			var goal:=1.78 if opening else 0.0
			var label:="curtain_%s_%d"%["open" if opening else "close",round_index+1]
			var aim: Vector3=shower.to_global(Vector3(0,1.18,-.32)) if opening else shower._curtain_hand.hand.global_position
			_phase=label
			player._grab.profile_records.clear()
			var before: Dictionary=shower.mechanism_snapshot().duplicate(true)
			var started:=Time.get_ticks_usec()
			var ok:=await _drag_part(shower,aim,goal,label)
			curtain_inputs.append({"phase":label,"ok":ok,"wall_ms":(Time.get_ticks_usec()-started)/1000.0,
				"aim":[aim.x,aim.y,aim.z],"before":before,"after":shower.mechanism_snapshot(),
				"callbacks":player._grab.profile_records.duplicate(true),"physics_frame":Engine.get_physics_frames()})
			if not ok:return false
			await _measure(label+"_settled",shower._curtain_hand.hand.global_position,1.0)
	await _measure("curtain_idle_after",shower.to_global(Vector3(0,1.18,-.32)),3.0)
	return _require(not player._grab.active() and not shower._curtain_hand.held,"three complete real opening/closing pairs release their owner")
