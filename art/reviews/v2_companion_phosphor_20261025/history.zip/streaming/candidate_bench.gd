extends "res://tests/v2_native_fit_job_bench.gd"
## INERT exact component comparison; played streaming route remains separate.
const Carboys := preload("res://scripts/building/orison_v2_druggist_carboys.gd")
const Dispensary := preload("res://scripts/building/orison_v2_druggist_dispensary.gd")
var texture_measurements := {}

func optical_value(value: Variant) -> Variant:
	if value is Texture2D:
		if texture_measurements.has(value.get_instance_id()): return texture_measurements[value.get_instance_id()]
		var image: Image = value.get_image()
		var measured := {"class":value.get_class(),"path":value.resource_path,"image":image.get_data().hex_encode().sha256_text() if image != null else ""}
		texture_measurements[value.get_instance_id()] = measured
		return measured
	if value is Resource: return {"class":value.get_class(),"path":value.resource_path}
	return value

func snapshot(cell: Node3D) -> Dictionary:
	var result := super.snapshot(cell)
	var extras := {}
	for node: Node in cell.find_children("*", "Node", true, false):
		var path := str(cell.get_path_to(node))
		if node is SpotLight3D:
			extras[path] = {"pose":node.transform,"color":node.light_color,"energy":node.light_energy,"shadow":node.shadow_enabled,"range":node.spot_range,"angle":node.spot_angle,"attenuation":node.spot_attenuation}
		if node is MeshInstance3D:
			var material: Material = node.get_active_material(0)
			if material is ShaderMaterial:
				var uniforms := {}
				for uniform: Dictionary in material.shader.get_shader_uniform_list():
					uniforms[str(uniform.name)] = optical_value(material.get_shader_parameter(uniform.name))
				extras[path] = {"shader":material.shader.resource_path,"uniforms":uniforms}
			elif material is BaseMaterial3D:
				extras[path] = {"emission":material.emission,"emission_enabled":material.emission_enabled,"emission_energy":material.emission_energy_multiplier}
	result["optical_and_lighting"] = extras
	return result

func fresh() -> Node3D:
	var cell := packed.instantiate() as Node3D
	cell.name = "shop_otis_son"
	if cache != null:
		cell.set_meta("native_collision_paths", cache.paths)
		cell.set_meta("native_collision_shapes", cache.shapes.duplicate())
	add_child(cell)
	return cell

func run() -> void:
	DirAccess.make_dir_recursive_absolute(OS.get_environment("SHOT_DIR"))
	RealityState.persistence_enabled = false
	layout = JSON.parse_string(FileAccess.get_file_as_string("res://data/building_layout.json"))
	packed = load("res://assets/building/floor_01_cells/shop_otis_son.gltf")
	for kind: String in ["druggist_carboys", "druggist_dispensary"]:
		cache = null
		var wrapper: Script = Carboys if kind == "druggist_carboys" else Dispensary
		var reference := fresh()
		check(bool(wrapper.call("mount_cell",reference,layout)),kind + " synchronous production wrapper accepts original shipping cell")
		var expected := snapshot(reference)
		cache = Cache.new()
		check(cache.seed({"shop_otis_son":reference}),kind + " original fitted collisions seed cache")
		# Preserve the authored cell identity for each independent instance.
		remove_child(reference)
		var cell := fresh()
		var before := snapshot(cell)
		var job: RefCounted = Fitter.begin_streamed_fitting(kind,cell,layout)
		if job == null:
			check(false,kind + " cooperative recipe exists");cell.free();reference.free();cache.dispose();continue
		job.advance(1)
		check(not job.done and job.prepared and snapshot(cell)==before,kind + " preparation leaves source buffers and public hierarchy unchanged")
		var private_model: WeakRef = weakref(job.model)
		job.cancel()
		check(job.done and not job.ok and private_model.get_ref()==null and snapshot(cell)==before,kind + " cancelled preparation retires private geometry without touching source")
		job = Fitter.begin_streamed_fitting(kind,cell,layout)
		var unpublished := true
		var calls := 0
		while not job.done and calls < 2000:
			job.advance(500);calls += 1
			if not job.done: unpublished = unpublished and snapshot(cell)==before
			await get_tree().process_frame
		check(job.done and job.ok and calls>2 and unpublished,kind + " fitting yields privately until complete")
		if job.ok:
			cell.set_meta("prepared_native_fit",job)
			check(bool(wrapper.call("mount_cell",cell,layout)) and not cell.has_meta("prepared_native_fit"),kind + " original optical/light wrapper consumes exact prepared result")
			check(snapshot(cell)==expected,kind + " exact meshes, UVs, normals, transforms, PBR, collision faces, shader parameters and show-globe lights match synchronous result")
			check(not bool(wrapper.call("mount_cell",cell,layout)),kind + " duplicate mount remains refused")
		job = null;cell.free();reference.free();cache.dispose();cache = null
	finish()
