# Gate board - 7c442119bd5f

- commit `7c442119bd5f90aeed0535a457d0db3ce2726b44`
- tree `b39d7b23cfbc6c03fa5e0734b1c5a485d58c00a0`
- created 2026-10-25T22:13:06Z
- dirty paths: 623

| gate | severity | exit | seconds | headline |
|---|---|---:|---:|---|
| spatial | PASS | 0 | 6.56 | no defects counted |
| systemic | PASS | 0 | 3.47 | drift.new_review 30 |
| reader | PASS | 0 | 5.33 | unread 1102; vs frozen baseline: new 0, resolved 206 |
| carriers | PASS | 0 | 0.86 | ambiguous_dynamic 2 |
