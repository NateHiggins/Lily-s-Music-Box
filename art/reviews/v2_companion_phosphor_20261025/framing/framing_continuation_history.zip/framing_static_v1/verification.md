# Candidate verification - c3e748246cdf

- candidate `c3e748246cdf78710199c52c99055ca7baf75728`
- base `20b7fee5f2122dd44065623e0d13b47794a56fc8`
- merge-base `20b7fee5f2122dd44065623e0d13b47794a56fc8`
- verified 2026-10-25T22:27:09Z from verifier `c3e748246cdf`

| check | result |
|---|---|
| checkout mode | in-place |
| checkout clean | yes |
| gate board vs merge-base | 0 regressions, 0 improvements |
| ledger before | {'FIRST_SLICE_TECHNICAL': 7, 'FULL_BUILDING_RUNTIME': 42, 'FULL_BUILDING_STRUCTURAL': 110, 'GOLDEN_SHIFT_V2': 8, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| ledger after | {'FIRST_SLICE_TECHNICAL': 7, 'GOLDEN_SHIFT_V2': 8, 'FULL_BUILDING_STRUCTURAL': 110, 'FULL_BUILDING_RUNTIME': 42, 'PRODUCTION_CUTOVER': 134, 'V1_RETIREMENT': 136} |
| requirements_changed | [] |
| protected | 17/17 unchanged vs merge-base; 0 authorized selector change(s) |
| selector | v2 |
| design doc lint errors | 0 |
| gates changed by candidate | 2 |

## Blocking reasons (0)

- none

## Needs human review (not blocking) (3)

- candidate changes 2 gate file(s); read those diffs before trusting the board
- Godot suites were not run (--no-godot)
- Verified the clean canonical checkout; fresh-checkout import and autocrlf behavior are outside this in-place verification

## Regressions (0)

- none

## Accepted regressions (0)

- none

## Improvements (0)

- none

## Report claims contradicted (0)

- none

## Design doc lint (0)

- none

## Gates changed by the candidate (2)

- M tools/audit_systemic_situation_authority.py
- M tools/tests/test_systemic_situation_authority.py

MERGE-CANDIDATE c3e748246cdf78710199c52c99055ca7baf75728
