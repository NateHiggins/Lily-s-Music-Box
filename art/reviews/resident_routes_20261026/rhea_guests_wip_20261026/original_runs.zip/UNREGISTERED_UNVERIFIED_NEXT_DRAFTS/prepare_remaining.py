import json,pathlib,subprocess
root=pathlib.Path(__file__).parent/'next_drafts'
root.mkdir(exist_ok=True)
names=['jonah_price','cal_dwyer','nadia_quell','malcolm_reed','juno_kells','iris_bell','mae_kessler','cam_ortiz','noel_price','omar_bell','peter_wren','teresa_vale']
notes=[]
for who in names:
    source=json.loads(subprocess.check_output(['git','show','claude/all-resident-bodies:game/data/orison_v2/'+who+'_routine.json'],text=True))
    y=source['paths'][0][0][2]
    changes=[]
    if who in ['jonah_price','cal_dwyer']:
        for chain in source['paths']:
            if chain[0][0]=='vestibule' and any(row[0]=='entry_in' for row in chain):
                i=next(i for i,row in enumerate(chain) if row[0]=='entry_in')
                chain[:i]=[chain[0],['entry_tip_clear',-7.1,y,2.0]]
        changes.append('Pass beyond the open entry-leaf tip before approaching its crossing.')
    if who=='cal_dwyer':
        for chain in source['paths']:
            for row in chain:
                if row[0]=='main':row[1]=-13.0
            if chain[0][0]=='vestibule' and chain[-1][0]=='main':
                chain[3:]=[['dining_north',-13.0,y,1.85],chain[-1]]
            elif chain[0][0]=='main':
                i=next(i for i,row in enumerate(chain) if 'main_private_hall_opening_a' in row[0] and '_via_' not in row[0])
                chain[:i]=[chain[0],['deck_north_west',-13.0,y,4.15],['deck_north_east',-10.05,y,4.15],['deck_east',-10.05,y,5.65]]
        changes.append('Move main stance off dining chair; approach north of dining stock and east of deck table. Source furniture bounds used; live probe still required.')
    if who=='nadia_quell':
        for chain in source['paths']:
            if chain[0][0]=='main' and any('main_bed_door_a' in r[0] for r in chain):
                i=next(i for i,r in enumerate(chain) if 'main_bed_door_a' in r[0] and '_via_' not in r[0])
                chain[:i]=[chain[0],['plant_table_east_north',-11.05,y,-3.475],['plant_table_east_south',-11.05,y,-5.65]]
        changes.append('Go east around plant table rather than crossing its top.')
    if who=='malcolm_reed':
        for chain in source['paths']:
            if chain[-1][0]=='bed':
                chain[:]=chain[:4]+[['bed',-13.0,y,8.35]]
        changes.append('Stand north of bed foot; retain the first already-clear doorway bypass.')
    if who in ['juno_kells','iris_bell','mae_kessler','cam_ortiz','noel_price']:
        for chain in source['paths']:
            if chain[-1][0] in ['bed1','bed2']:
                name=chain[-1][0]
                i=next(i for i,r in enumerate(chain) if ('private_hall_'+name+'_door_b') in r[0] and '_via_' not in r[0])
                chain[i+1:]=[[name,2.5 if name=='bed1' else 5.8,y,9.0]]
            elif chain[0][0]=='main' and any('main_private_hall_opening_a' in r[0] for r in chain):
                i=next(i for i,r in enumerate(chain) if 'main_private_hall_opening_a' in r[0] and '_via_' not in r[0])
                chain[:i]=[chain[0],['dining_aisle',-2.4,y,7.1]]
        changes.append('Use standing stances ahead of each bed foot, on the side clear of its open door; use the aisle north of dining chairs.')
    if who in ['omar_bell','peter_wren','teresa_vale']:
        for chain in source['paths']:
            if chain[0][0]=='vestibule' and any(row[0]=='entry_in' for row in chain):
                i=next(i for i,row in enumerate(chain) if row[0]=='entry_in')
                chain[:i]=[chain[0],['entry_tip_clear',10.95,y,-2.5],['entry_tip_south',10.95,y,-3.35]]
            elif who in ['peter_wren','teresa_vale'] and chain[0][0]=='bed':
                i=next(i for i,row in enumerate(chain) if '_bed_door_a' in row[0] and '_via_' not in row[0])
                chain[:i]=[['bed',11.0,y,-9.35]]
            elif who=='omar_bell' and chain[-1][0]=='alcove':
                i=next(i for i,row in enumerate(chain) if '_alcove_door_b' in row[0] and '_via_' not in row[0])
                chain[i+1:]=[['alcove',11.2,y,-9.1]]
            elif who=='omar_bell' and chain[0][0]=='main':
                i=next(i for i,row in enumerate(chain) if '_main_hall_opening_a' in row[0] and '_via_' not in row[0])
                chain[:i]=[chain[0],['dining_west',12.6,y,-4.15]]
            elif who=='teresa_vale' and any(row[0]=='f01_core_service_opening_b' for row in chain):
                i=next(i for i,row in enumerate(chain) if row[0]=='f01_core_service_opening_b')
                chain[i+1:]=[['core_stair_east',4.81,y,-3.2],['basement_stair_top_clear',4.06,y,-3.2]]
        changes.append('East-entry tip bypass and bed-foot stances; Omar uses a west dining approach; Teresa joins the already-used public stair-clear point from the east. All new edges remain unprobed.')
    path=root/(who+'.json')
    path.write_text(json.dumps(source,indent=2)+'\n')
    notes.append({'resident':who,'status':'UNPROBED, UNREGISTERED authoring candidate','changes':changes})
(root/'notes.json').write_text(json.dumps(notes,indent=2)+'\n')
print('Prepared',len(notes),'external authoring candidates; no runtime files changed.')
